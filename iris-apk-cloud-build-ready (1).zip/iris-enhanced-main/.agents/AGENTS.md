# IRIS Enhanced Agent Development Rules & Design System Guidelines

## 1. Material 3 Expressive (Google Pixel Style) Rules

- **Header Sizing & Compactness**:
  - Always enforce compact bounds ($70\text{dp}–110\text{dp}$) with `MainAxisSize.min` and tight vertical padding (`18, 12, 18, 12`).
  - Never introduce giant canvases or empty vertical gaps ($> 12\text{dp}$) in M3 mode.
  - Tightly pair typography (title + subtitle/date) with an inline or tightly stacked status pill.
- **Bottom Navigation**:
  - The bottom navigation bar (`IrisExpressiveNavBar`) must strictly maintain a symmetrical 4-tab layout: **Schedule (Home)**, **Portal**, **Tools**, and **Settings**.
  - Never put theme, color palette, or customization triggers on the bottom navbar (they belong exclusively in Settings / Iris Hub).
- **Animation & Physics**:
  - **Page Switches**: Use `irisPageRoute` or `IrisExpressivePageRoute` with Android 15 shared-axis Z zoom-fade curve (`Curves.fastOutSlowIn`, 320ms forward / 260ms reverse), or `pushGlassContainerMorphRoute` for card container morphing.
  - **Toggle Switches**: Use `IrisGlassSwitch` which automatically routes to an authentic M3 capsule-stretching thumb animation with checkmark indicators.
  - **Dropdowns & Popups**: Use `IrisExpressiveDropdownTrigger` / `M3EMenu` with spring scale-fade expansion (`Curves.easeOutBack`).
  - **Interactive Press**: Wrap interactive cards, chips, and buttons in `ExpressiveInteractivePress` (0.94 spring compression scale) or `IrisLiquidButton`.
- **Card Hierarchy**:
  - Use Monet tonal container tokens (`surfaceContainerLow`, `surfaceContainer`, `surfaceContainerHigh`) with crisp outer elevation drop shadows. Never apply dark inner inset vignettes in M3 mode.

## 2. Liquid Glass Component Selection Rules

- **Context & Popup Menus**: Always use `lgw.GlassMenu` from `package:liquid_glass_widgets/liquid_glass_widgets.dart` with `lgw.GlassMenuItem`.
  - **Icons**: Pass distinct icons directly to `icon:` parameter (e.g. `Icons.school_rounded`, `Icons.auto_stories_rounded`). Do NOT put duplicate emoji characters inside the `title:` string.
  - **Triggers**: Use `triggerBuilder` with `GestureDetector(onTap: toggleMenu)` to ensure tap events cleanly toggle the glass morph controller.
- **Segmented Toggles**: Use `lgw.GlassSegmentedControl` for multi-option filters (e.g. Daily / Weekly / Monthly).
- **Toggle Switches**: Use `lgw.GlassSwitch` for binary settings in Liquid Glass mode.
- **Modals & Action Sheets**: Use `lgw.GlassModalSheet` / `lgw.GlassActionSheet` for bottom sheets.
- **Preservation Contract**: Never alter or degrade Liquid Glass assets, comic artwork hero canvases (`HeaderAtmosphereWrapper`), specular rim borders, or Lissajous mesh shaders when implementing M3 enhancements.

## 3. Performance & Smoothness Standards (60-120 FPS)

- **Adaptive Blur Levels**: Always wrap glass settings in `IrisGlass.widgetsSettings(context, blur: 16.0)` or `IrisGlass.settings(...)` so blur levels scale adaptively down to 12.0–16.0. Avoid hardcoding `blur > 25.0` on frequently rebuilt widgets.
- **Import Collisions**: Always import `package:liquid_glass_widgets/liquid_glass_widgets.dart hide GlassCard;` alongside `import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;` to prevent symbol collisions with `lib/widgets/glass_card.dart`.
- **Over-The-Air Patch Safety**: Never modify the `pubspec.yaml` version number (`1.0.3+4`). All over-the-air patches must be published via `shorebird patch android --release-version=1.0.3+4 --allow-asset-diffs`.

## 4. Codebase Architecture & Placement Standards

- **Domain Directory Organization**:
  - `lib/screens/` is organized strictly into domain subdirectories: `academics/`, `faculty/`, `onboarding/`, `settings/`, `student/`, and `tools/`. Only shell containers (`app_root.dart`, `dashboard_screen.dart`, `portal_screen.dart`, `tools_screen.dart`) and the barrel facade (`screens.dart`) reside at the root of `screens/`.
  - `lib/widgets/` is organized strictly into functional subdirectories: `cards/`, `controls/`, `dashboard/`, `department_classes/`, `document/`, `effects/`, `faculty/`, `makeup/`, `navigation/`, `portal/`, `room_finder/`, `schedule_views/`, and `setup/`. Only design system primitives (`glass_card.dart`, `iris_components.dart`, `smart_widgets.dart`) and the barrel facade (`widgets.dart`) reside at the root of `widgets/`.
- **Canonical Imports**:
  - Always use canonical package imports (e.g. `import 'package:iris/widgets/controls/iris_liquid_button.dart';`) or top-level barrel facades (`import 'package:iris/widgets/widgets.dart';` / `import 'package:iris/screens/screens.dart';`).
- **No Prototype Naming**:
  - Never introduce temporary prototype naming patterns (such as `concept2_...`, `temp_...`, `draft_...`) into production filenames or class definitions. Always use clean, expressive names (e.g., `ScheduleDaySelector`).
