import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Design Tokens & Classical Broadsheet Typographic System for the Almanac Theme
/// (Modeled directly after Almanac · Light.png and Almanac · Dark.png).
class AlmanacTokens {
  // --- Canvas & Surfaces ---
  static Color canvas(bool isDark) =>
      isDark ? const Color(0xFF111110) : const Color(0xFFEFECE6);

  static Color cardSurface(bool isDark) =>
      isDark ? const Color(0xFF191816) : const Color(0xFFFAF7F2);

  // --- Hairline Borders & Broadside Rules ---
  static Color inkRule(bool isDark) =>
      isDark ? const Color(0xFFEAE6DF) : const Color(0xFF111111);

  static Color inkRuleSubtle(bool isDark) =>
      isDark ? const Color(0xFFEAE6DF).withValues(alpha: 0.22) : const Color(0xFF111111).withValues(alpha: 0.20);

  // --- Accent & Subtitle Ink (Terracotta / Coral Rust) ---
  static Color accentTerracotta(bool isDark) =>
      isDark ? const Color(0xFFE06D53) : const Color(0xFFC84B31);

  // --- Typography Inks ---
  static Color inkHeading(bool isDark) =>
      isDark ? const Color(0xFFEAE6DF) : const Color(0xFF111111);

  static Color inkBody(bool isDark) =>
      isDark ? const Color(0xFFD6D1C7) : const Color(0xFF222222);

  static Color inkMuted(bool isDark) =>
      isDark ? const Color(0xFF9E9E9E) : const Color(0xFF666666);

  // --- Bottom Navigation Colors ---
  static Color navBarBackground(bool isDark) =>
      isDark ? const Color(0xFF121212) : const Color(0xFFEFECE6);

  static Color navActivePill(bool isDark) =>
      isDark ? const Color(0xFFEAE6DF) : const Color(0xFF111111);

  static Color navActiveText(bool isDark) =>
      isDark ? const Color(0xFF111111) : const Color(0xFFFFFFFF);

  static Color navInactiveText(bool isDark) =>
      isDark ? const Color(0xFFA0A0A0) : const Color(0xFF111111);

  // --- Typographic Scales (Classical Scotch Roman + Monospace) ---
  static TextStyle heroDayTitle(bool isDark) {
    return GoogleFonts.playfairDisplay(
      fontSize: 48,
      fontWeight: FontWeight.w700,
      letterSpacing: -1.2,
      height: 1.06,
      color: inkHeading(isDark),
    );
  }

  static TextStyle heroDateSubtitle(bool isDark) {
    return GoogleFonts.playfairDisplay(
      fontSize: 22,
      fontStyle: FontStyle.italic,
      fontWeight: FontWeight.w400,
      letterSpacing: -0.2,
      height: 1.18,
      color: accentTerracotta(isDark),
    );
  }

  static TextStyle countdownNumbers(bool isDark) {
    return GoogleFonts.playfairDisplay(
      fontSize: 42,
      fontWeight: FontWeight.w700,
      letterSpacing: -0.8,
      height: 1.04,
      color: inkHeading(isDark),
    );
  }

  static TextStyle countdownNarrative(bool isDark) {
    return GoogleFonts.playfairDisplay(
      fontSize: 18,
      fontStyle: FontStyle.italic,
      fontWeight: FontWeight.w400,
      height: 1.35,
      color: isDark ? const Color(0xFFB0AAA0) : const Color(0xFF555555),
    );
  }

  static TextStyle subjectTitle(bool isDark) {
    return GoogleFonts.playfairDisplay(
      fontSize: 18,
      fontWeight: FontWeight.w600,
      height: 1.25,
      letterSpacing: -0.2,
      color: inkHeading(isDark),
    );
  }

  static TextStyle serifHeadline(
    bool isDark, {
    double fontSize = 18,
    FontWeight fontWeight = FontWeight.w700,
    double letterSpacing = -0.2,
    FontStyle fontStyle = FontStyle.normal,
    Color? color,
  }) {
    return GoogleFonts.playfairDisplay(
      fontSize: fontSize,
      fontWeight: fontWeight,
      letterSpacing: letterSpacing,
      fontStyle: fontStyle,
      color: color ?? inkHeading(isDark),
    );
  }

  static TextStyle monoHeader(
    bool isDark, {
    double fontSize = 11,
    FontWeight fontWeight = FontWeight.w700,
    double letterSpacing = 1.4,
    Color? color,
  }) {
    return GoogleFonts.spaceMono(
      fontSize: fontSize,
      fontWeight: fontWeight,
      letterSpacing: letterSpacing,
      color: color ?? inkMuted(isDark),
    );
  }

  static TextStyle monoMeta(
    bool isDark, {
    double fontSize = 13,
    FontWeight fontWeight = FontWeight.w700,
    Color? color,
  }) {
    return GoogleFonts.spaceMono(
      fontSize: fontSize,
      fontWeight: fontWeight,
      letterSpacing: 0.2,
      color: color ?? inkHeading(isDark),
    );
  }

  static TextStyle navLabel({required bool isActive, required bool isDark}) {
    return GoogleFonts.spaceMono(
      fontSize: 11,
      fontWeight: FontWeight.w700,
      letterSpacing: 1.3,
      color: isActive ? navActiveText(isDark) : navInactiveText(isDark),
    );
  }

  /// Format e.g. 19 Oct 2026 -> "nineteenth of October"
  static String formatSpelledOutDate(DateTime date) {
    const ordinals = [
      '',
      'first',
      'second',
      'third',
      'fourth',
      'fifth',
      'sixth',
      'seventh',
      'eighth',
      'ninth',
      'tenth',
      'eleventh',
      'twelfth',
      'thirteenth',
      'fourteenth',
      'fifteenth',
      'sixteenth',
      'seventeenth',
      'eighteenth',
      'nineteenth',
      'twentieth',
      'twenty-first',
      'twenty-second',
      'twenty-third',
      'twenty-fourth',
      'twenty-fifth',
      'twenty-sixth',
      'twenty-seventh',
      'twenty-eighth',
      'twenty-ninth',
      'thirtieth',
      'thirty-first',
    ];
    const months = [
      '',
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    final dayOrdinal = (date.day >= 1 && date.day <= 31)
        ? ordinals[date.day]
        : '${date.day}th';
    final monthName = (date.month >= 1 && date.month <= 12)
        ? months[date.month]
        : '';
    return '$dayOrdinal of $monthName';
  }
}
