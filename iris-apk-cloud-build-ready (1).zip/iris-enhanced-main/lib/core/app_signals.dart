import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// App-wide reactive state bus for instantaneous, zero-restart updates across
/// roles ('student' / 'faculty'), active batch, student/faculty display names,
/// and custom repeater schedules.
class AppSignals {
  static final ValueNotifier<String?> roleNotifier = ValueNotifier(null);
  static final ValueNotifier<String> activeRole = ValueNotifier('student');
  static final ValueNotifier<String> activeBatch = ValueNotifier('');
  static final ValueNotifier<String> activeUserName = ValueNotifier('');
  static final ValueNotifier<String> activeTeacherName = ValueNotifier('');
  static final ValueNotifier<int> stateRevision = ValueNotifier(0);

  static Future<void> syncFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final role = prefs.getString('user_role') ?? prefs.getString('active_role') ?? 'student';
    final batch = prefs.getString('user_batch') ??
        prefs.getString('student_batch') ??
        prefs.getString('selected_batch') ??
        '';
    final teacher = prefs.getString('faculty_user_name') ??
        prefs.getString('faculty_teacher') ??
        '';
    final studentName = prefs.getString('student_user_name') ??
        prefs.getString('student_name') ??
        'Student';
    final name = role == 'faculty'
        ? (teacher.isNotEmpty ? teacher : 'Faculty Member')
        : (studentName.isNotEmpty ? studentName : 'Student');
    activeRole.value = role;
    if (batch.isNotEmpty) activeBatch.value = batch;
    if (teacher.isNotEmpty) activeTeacherName.value = teacher;
    if (name.isNotEmpty) activeUserName.value = name;
    stateRevision.value++;
  }

  static Future<void> setRole(String role, {String? userName}) async {
    // 1. Update reactive ValueNotifiers synchronously on Frame 1!
    activeRole.value = role;
    if (userName != null && userName.trim().isNotEmpty) {
      activeUserName.value = userName.trim();
      if (role == 'faculty') {
        activeTeacherName.value = userName.trim();
      }
    } else if (role == 'faculty' && activeTeacherName.value.isNotEmpty) {
      activeUserName.value = activeTeacherName.value;
    }
    roleNotifier.value = role;
    stateRevision.value++;

    // 2. Persist to SharedPreferences asynchronously without blocking Frame 1 UI
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_role', role);
    await prefs.setString('active_role', role);
    if (userName != null && userName.trim().isNotEmpty) {
      if (role == 'faculty') {
        await prefs.setString('faculty_user_name', userName.trim());
        await prefs.setString('faculty_teacher', userName.trim());
      } else {
        await prefs.setString('student_user_name', userName.trim());
        await prefs.setString('student_name', userName.trim());
      }
    } else {
      final savedName = role == 'faculty'
          ? (prefs.getString('faculty_user_name') ?? prefs.getString('faculty_teacher') ?? '')
          : (prefs.getString('student_user_name') ?? prefs.getString('student_name') ?? '');
      if (savedName.isNotEmpty && activeUserName.value != savedName) {
        activeUserName.value = savedName;
        if (role == 'faculty') activeTeacherName.value = savedName;
        stateRevision.value++;
      }
    }
  }

  static Future<void> setBatch(String batch) async {
    final trimmed = batch.trim();
    if (trimmed.isEmpty) return;
    // Synchronous Frame-1 signal update
    activeBatch.value = trimmed;
    stateRevision.value++;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_batch', trimmed);
    await prefs.setString('student_batch', trimmed);
    await prefs.setString('selected_batch', trimmed);
  }

  static Future<void> setTeacher(String teacherName) async {
    final trimmed = teacherName.trim();
    if (trimmed.isEmpty) return;
    activeTeacherName.value = trimmed;
    if (activeRole.value == 'faculty') {
      activeUserName.value = trimmed;
    }
    stateRevision.value++;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('faculty_user_name', trimmed);
    await prefs.setString('faculty_teacher', trimmed);
  }

  static Future<void> setUserName(String name, {String? role}) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    final effectiveRole = role ?? activeRole.value;
    activeUserName.value = trimmed;
    if (effectiveRole == 'faculty') {
      activeTeacherName.value = trimmed;
    }
    stateRevision.value++;

    final prefs = await SharedPreferences.getInstance();
    if (effectiveRole == 'faculty') {
      await prefs.setString('faculty_user_name', trimmed);
      await prefs.setString('faculty_teacher', trimmed);
    } else {
      await prefs.setString('student_user_name', trimmed);
      await prefs.setString('student_name', trimmed);
    }
  }
}
