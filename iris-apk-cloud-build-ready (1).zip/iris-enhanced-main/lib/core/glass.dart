import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import 'tokens.dart';
import 'theme_signals.dart';
import 'material_you_theme.dart';

export 'package:liquid_glass_widgets/liquid_glass_widgets.dart'
    show
        LiquidGlassSettings,
        LiquidRoundedSuperellipse,
        GlassQuality,
        GlassBodyMode,
        GlassSpecularSharpness,
        GlassSheetState;

class IrisGlass {
  static final ValueNotifier<bool> isFastScrolling = ValueNotifier<bool>(false);

  static bool reduceEffects(BuildContext context) {
    return ThemeSignals.useMinimalTheme.value ||
        !ThemeSignals.isFluidGlass ||
        ThemeSignals.glassTransparency.value <= 0.08;
  }

  /// Dynamically resolves the optimal [lgw.GlassQuality] tier for `liquid_glass_widgets`:
  /// - [lgw.GlassQuality.minimal]: Zero fragment shader cost during Eco mode or Opaque Glass.
  /// - [lgw.GlassQuality.premium]: Full multi-pass shader refraction & chromatic aberration for fixed chrome & hero surfaces (navbars, headers, modal sheets, buttons).
  /// - [lgw.GlassQuality.standard]: Fast single-pass hardware shader for scrollable list cards inside CustomScrollView / ListView (locked 120 FPS).
  static lgw.GlassQuality adaptiveQuality(
    BuildContext context, {
    bool isStaticHero = false,
  }) {
    if (!ThemeSignals.isFluidGlass ||
        ThemeSignals.useMinimalTheme.value ||
        ThemeSignals.glassTransparency.value <= 0.08) {
      return lgw.GlassQuality.minimal;
    }
    return lgw.GlassQuality.premium;
  }

  static Widget backdropFilter({
    required double sigmaX,
    required double sigmaY,
    required Widget child,
  }) {
    if (!ThemeSignals.isFluidGlass || (sigmaX <= 0.001 && sigmaY <= 0.001)) {
      return child;
    }
    return BackdropFilter(
      filter: ui.ImageFilter.blur(sigmaX: sigmaX, sigmaY: sigmaY),
      child: child,
    );
  }

  static double adaptiveBlur(
    BuildContext context,
    double base, {
    double min = 8.0,
  }) {
    if (ThemeSignals.useMinimalTheme.value || !ThemeSignals.isFluidGlass) {
      return 0.0;
    }
    final transparency = ThemeSignals.glassTransparency.value;
    if (transparency <= 0.08) {
      return 0.0;
    }
    if (isFastScrolling.value) {
      return math.min(base, min);
    }
    if (transparency <= 0.5) {
      final t = (transparency - 0.08) / (0.5 - 0.08);
      return ui.lerpDouble(8.0, base, t.clamp(0.0, 1.0))!;
    } else {
      final t = (transparency - 0.5) / 0.5;
      return ui.lerpDouble(base, base * 1.25, t.clamp(0.0, 1.0))!;
    }
  }

  static double adaptiveAmbient(BuildContext context, double base) {
    if (ThemeSignals.useMinimalTheme.value || !ThemeSignals.isFluidGlass) {
      return 0.0;
    }
    final transparency = ThemeSignals.glassTransparency.value;
    if (transparency <= 0.08) return 0.0;
    if (transparency <= 0.5) {
      final t = (transparency - 0.08) / (0.5 - 0.08);
      return ui.lerpDouble(0.35, base, t.clamp(0.0, 1.0))!;
    } else {
      final t = (transparency - 0.5) / 0.5;
      return ui.lerpDouble(
        base,
        math.min(1.0, base * 1.20),
        t.clamp(0.0, 1.0),
      )!;
    }
  }

  static double adaptiveThickness(
    BuildContext context,
    double base, {
    double min = 8.0,
  }) {
    if (ThemeSignals.useMinimalTheme.value || !ThemeSignals.isFluidGlass) {
      return 0.0;
    }
    final transparency = ThemeSignals.glassTransparency.value;
    if (transparency <= 0.08) return 0.0;
    if (transparency <= 0.5) {
      final t = (transparency - 0.08) / (0.5 - 0.08);
      return ui.lerpDouble(min, base, t.clamp(0.0, 1.0))!;
    } else {
      final t = (transparency - 0.5) / 0.5;
      return ui.lerpDouble(base, base * 1.25, t.clamp(0.0, 1.0))!;
    }
  }

  static Color adaptiveGlassColor(
    BuildContext context, {
    Color? dark,
    Color? light,
    double darkAlpha = 0.0,
    double lightAlpha = 0.0,
  }) {
    final isMinimal = ThemeSignals.useMinimalTheme.value;
    final isMaterialYou = ThemeSignals.isMaterialYou;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    if (isMaterialYou) {
      return MaterialYouTokens.surfaceContainer(
        isDark ? Brightness.dark : Brightness.light,
      );
    }

    if (isMinimal) {
      return isDark
          ? (dark ?? IrisTokens.surfaceDarkElevated)
          : (light ?? Colors.white);
    }

    final base = isDark
        ? (dark ?? const Color(0xFF131C2E))
        : (light ?? Colors.white);

    final transparency = ThemeSignals.glassTransparency.value;
    final defaultTargetAlpha = isDark ? 0.38 : 0.62;
    final effectiveTargetAlpha = (darkAlpha > 0.0 || lightAlpha > 0.0)
        ? (isDark ? darkAlpha : lightAlpha)
        : defaultTargetAlpha;

    final alpha = ui
        .lerpDouble(0.94, effectiveTargetAlpha, transparency)!
        .clamp(0.10, 0.96);
    return base.withValues(alpha: alpha);
  }

  static lgw.LiquidGlassSettings settings(
    BuildContext context, {
    double blur = 18.0,
    double ambientStrength = 0.84,
    double lightAngle = 1.35,
    double thickness = 14.0,
    Color? glassColor,
    double minBlur = 8.0,
    double minThickness = 6.0,
    double? lightIntensity,
    double refractiveIndex = 1.18,
    double chromaticAberration = 0.012,
    double saturation = 1.15,
    lgw.GlassSpecularSharpness specularSharpness =
        lgw.GlassSpecularSharpness.sharp,
    lgw.GlassBodyMode? bodyMode,
  }) {
    final isMinimal = ThemeSignals.useMinimalTheme.value;
    final isMaterialYou = ThemeSignals.isMaterialYou;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final transparency = ThemeSignals.glassTransparency.value;

    Color effectiveColor;
    if (isMaterialYou) {
      effectiveColor = glassColor != null && glassColor.a >= 0.85
          ? glassColor
          : MaterialYouTokens.surfaceContainer(
              isDark ? Brightness.dark : Brightness.light,
            );
    } else if (isMinimal || transparency <= 0.08) {
      effectiveColor = isDark ? IrisTokens.surfaceDarkElevated : Colors.white;
    } else if (glassColor != null) {
      // Honor caller-provided translucent glassColor (e.g. IrisLiquidButton / Navbar lens 0.12-0.55 alpha)
      // without clamping it to an opaque white slab.
      effectiveColor = glassColor;
    } else {
      final base = isDark ? const Color(0xFF131C2E) : Colors.white;
      final targetA = isDark ? 0.38 : 0.62;
      final resolvedA =
          ui.lerpDouble(0.92, targetA, transparency)!.clamp(0.16, 0.95);
      effectiveColor = base.withValues(alpha: resolvedA);
    }

    final resolvedBlur = adaptiveBlur(context, blur, min: minBlur);
    final resolvedThickness =
        adaptiveThickness(context, thickness, min: minThickness);
    final resolvedAmbient = adaptiveAmbient(context, ambientStrength);
    final resolvedBodyMode = bodyMode ?? lgw.GlassBodyMode.adaptive;

    return lgw.LiquidGlassSettings(
      blur: resolvedBlur,
      ambientStrength: resolvedAmbient,
      lightAngle: lightAngle,
      glassColor: effectiveColor,
      thickness: resolvedThickness,
      lightIntensity: lightIntensity ?? (isDark ? 0.95 : 1.05),
      refractiveIndex: refractiveIndex,
      chromaticAberration: resolvedBlur > 0 ? chromaticAberration : 0.0,
      saturation: resolvedBlur > 0 ? saturation : 1.0,
      specularSharpness: specularSharpness,
      bodyMode: resolvedBodyMode,
    );
  }

  static lgw.LiquidGlassSettings widgetsSettings(
    BuildContext context, {
    double blur = 18.0,
    double ambientStrength = 0.84,
    double lightAngle = 1.35,
    double thickness = 14.0,
    Color? glassColor,
    double minBlur = 8.0,
    double minThickness = 6.0,
    double? lightIntensity,
    double refractiveIndex = 1.18,
    double chromaticAberration = 0.012,
    double saturation = 1.15,
    lgw.GlassSpecularSharpness specularSharpness =
        lgw.GlassSpecularSharpness.sharp,
    lgw.GlassBodyMode? bodyMode,
  }) {
    return settings(
      context,
      blur: blur,
      ambientStrength: ambientStrength,
      lightAngle: lightAngle,
      thickness: thickness,
      glassColor: glassColor,
      minBlur: minBlur,
      minThickness: minThickness,
      lightIntensity: lightIntensity,
      refractiveIndex: refractiveIndex,
      chromaticAberration: chromaticAberration,
      saturation: saturation,
      specularSharpness: specularSharpness,
      bodyMode: bodyMode,
    );
  }

  static lgw.LiquidRoundedSuperellipse shape(
    double radius, {
    BorderSide side = BorderSide.none,
  }) {
    return lgw.LiquidRoundedSuperellipse(
      borderRadius: math.max(0.0, radius),
      side: side,
    );
  }
}
