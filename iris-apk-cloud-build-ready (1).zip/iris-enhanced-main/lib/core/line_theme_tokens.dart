import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Design tokens, authentic subway rail track painters, and spatial metro navigation
/// for the Line / Transit Theme (Modeled with 100% fidelity after Line · Light.png & Line · Dark.png).
class LineTokens {
  // --- Canvas & Surfaces ---
  static Color canvas(bool isDark) =>
      isDark ? const Color(0xFF101317) : const Color(0xFFF3EFE6);

  static Color cardSurface(bool isDark) =>
      isDark ? const Color(0xFF161A20) : Colors.white;

  // --- Subway Rail Line Colors ---
  static const Color subwayRed = Color(0xFFE03E2D);
  static const Color subwayYellow = Color(0xFFFBBF24);
  static const Color subwayCobalt = Color(0xFF2563EB);
  static const Color subwayGreen = Color(0xFF10B981);

  /// Primary rail line color for active track:
  /// In light mode: Red Subway Line (`#E03E2D`).
  /// In dark mode: Illuminated Golden-Yellow Subway Line (`#FBBF24`).
  static Color railLine(bool isDark) =>
      isDark ? subwayYellow : subwayRed;

  // --- Typography & Text Inks ---
  static Color inkHeading(bool isDark) =>
      isDark ? const Color(0xFFFFFFFF) : const Color(0xFF0F1419);

  static Color inkBody(bool isDark) =>
      isDark ? const Color(0xFFCBD5E1) : const Color(0xFF1E293B);

  static Color inkMuted(bool isDark) =>
      isDark ? const Color(0xFF8A99AD) : const Color(0xFF5A6675);

  // --- Platform LED Sign & Badges ---
  static const Color ledAmber = Color(0xFFFBBF24);
  static const Color ledBlack = Color(0xFF0F1419);

  // --- Bottom Navigation Colors ---
  static Color navBarBackground(bool isDark) =>
      isDark ? const Color(0xFF101317) : const Color(0xFFF3EFE6);

  static Color navBarTopRail(bool isDark) => railLine(isDark);

  static Color navActivePill(bool isDark) => subwayYellow;

  static Color navActiveText(bool isDark) => const Color(0xFF0F1419);

  static Color navInactiveText(bool isDark) =>
      isDark ? const Color(0xFFD1D5DB) : const Color(0xFF334155);

  // --- Grotesque Wayfinding Typography Scales ---
  static TextStyle heroMonDate(bool isDark) {
    return GoogleFonts.archivoBlack(
      fontSize: 42,
      fontWeight: FontWeight.w900,
      letterSpacing: -1.2,
      height: 1.02,
      color: inkHeading(isDark),
    );
  }

  static TextStyle lineTag(bool isDark) {
    return GoogleFonts.spaceMono(
      fontSize: 11.5,
      fontWeight: FontWeight.w700,
      letterSpacing: 1.0,
      color: inkMuted(isDark),
    );
  }

  static TextStyle stationName(bool isDark) {
    return GoogleFonts.archivoBlack(
      fontSize: 20,
      fontWeight: FontWeight.w900,
      letterSpacing: -0.4,
      height: 1.14,
      color: inkHeading(isDark),
    );
  }

  static TextStyle departureTime(bool isDark) {
    return GoogleFonts.archivoBlack(
      fontSize: 18,
      fontWeight: FontWeight.w900,
      letterSpacing: -0.2,
      color: railLine(isDark),
    );
  }

  static TextStyle stationMeta(bool isDark) {
    return GoogleFonts.plusJakartaSans(
      fontSize: 14,
      fontWeight: FontWeight.w600,
      color: inkMuted(isDark),
    );
  }
}

// =============================================================================
// 1. ELEVATED 3D SUBWAY RAIL TRACK PAINTER
// =============================================================================

/// Renders a spatial 3D transit rail track with dual-side rail shadow, center beveled core,
/// and circular station stops that break free from standard container boxes.
class SubwayRailTrackPainter extends CustomPainter {
  final bool isDark;
  final double railX;
  final double topOffset;
  final double bottomOffset;

  SubwayRailTrackPainter({
    required this.isDark,
    this.railX = 36.0,
    this.topOffset = 0.0,
    this.bottomOffset = 0.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final startY = topOffset;
    final endY = size.height - bottomOffset;
    if (startY >= endY) return;

    final railColor = LineTokens.railLine(isDark);

    // 1. Outer ambient shadow of the elevated 3D track
    final shadowPaint = Paint()
      ..color = (isDark ? Colors.black : Colors.black).withValues(alpha: isDark ? 0.45 : 0.12)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4.0)
      ..strokeWidth = 12.0
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    canvas.drawLine(Offset(railX + 1.5, startY + 2), Offset(railX + 1.5, endY + 2), shadowPaint);

    // 2. Main solid rail line (8dp wide)
    final railPaint = Paint()
      ..color = railColor
      ..strokeWidth = 8.0
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    canvas.drawLine(Offset(railX, startY), Offset(railX, endY), railPaint);

    // 3. Subtle 3D inner specular highlight line running along track center
    final highlightPaint = Paint()
      ..color = Colors.white.withValues(alpha: isDark ? 0.35 : 0.28)
      ..strokeWidth = 1.8
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    canvas.drawLine(Offset(railX - 1.2, startY + 4), Offset(railX - 1.2, endY - 4), highlightPaint);
  }

  @override
  bool shouldRepaint(covariant SubwayRailTrackPainter oldDelegate) {
    return oldDelegate.isDark != isDark ||
        oldDelegate.railX != railX ||
        oldDelegate.topOffset != topOffset ||
        oldDelegate.bottomOffset != bottomOffset;
  }
}

// =============================================================================
// 2. 3D CIRCULAR STATION STOP NODE
// =============================================================================

/// Circular station ring node that straddles the subway track.
class StationStopNode extends StatelessWidget {
  final bool isCurrentPosition; // "YOU ARE HERE" station
  final bool isDark;
  final double size;

  const StationStopNode({
    super.key,
    this.isCurrentPosition = false,
    required this.isDark,
    this.size = 22.0,
  });

  @override
  Widget build(BuildContext context) {
    final railColor = LineTokens.railLine(isDark);
    final bgColor = LineTokens.canvas(isDark);

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: bgColor,
        shape: BoxShape.circle,
        border: Border.all(
          color: isDark ? Colors.white : const Color(0xFF0F1419),
          width: 3.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.2),
            offset: const Offset(0, 2),
            blurRadius: 3,
          ),
        ],
      ),
      child: isCurrentPosition
          ? Center(
              child: Container(
                width: size * 0.45,
                height: size * 0.45,
                decoration: BoxDecoration(
                  color: railColor,
                  shape: BoxShape.circle,
                ),
              ),
            )
          : null,
    );
  }
}
