import 'format_guard.dart';
import '../services/remote_config_service.dart';
import '../services/helpdesk_faculty_service.dart';

class BatchKey {
  final String batch;
  final String program;
  final int semester;
  final String section;
  final String intake;
  final String department;

  const BatchKey({
    required this.batch,
    required this.program,
    required this.semester,
    required this.section,
    required this.intake,
    required this.department,
  });

  /// e.g. "FA" -> "Fall", "SP" -> "Spring"
  String get intakeSeason {
    if (intake.startsWith('FA')) return 'Fall';
    if (intake.startsWith('SP')) return 'Spring';
    return intake;
  }

  /// e.g. "FA25" -> 2025
  int get intakeYear {
    if (intake.length >= 4) {
      final y = int.tryParse(intake.substring(2, 4));
      if (y != null) return 2000 + y;
    }
    return 2025;
  }

  /// Full descriptive title e.g. "Fall 2025 - BS Computer Science (Semester 2, Section C)"
  String get fullDescription {
    final semStr = semester > 0
        ? 'Semester $semester'
        : 'Semester $dynamicSemester';
    final secStr = section.isNotEmpty ? ', Section $section' : '';
    return '$intakeSeason $intakeYear - $programFullName ($semStr$secStr)';
  }

  /// Readable Program Name
  String get programFullName {
    switch (program.toUpperCase()) {
      case 'BCS':
        return 'BS Computer Science';
      case 'BSE':
        return 'BS Software Engineering';
      case 'BEE':
        return 'BS Electrical Engineering';
      case 'BME':
        return 'BS Mechanical Engineering';
      case 'BCE':
        return 'BS Computer Engineering';
      case 'CVE':
      case 'BSCVE':
      case 'CE':
        return 'BS Civil Engineering';
      case 'BAF':
        return 'BS Accounting & Finance';
      case 'BBA':
        return 'Bachelor of Business Administration';
      case 'BBC':
      case 'BCH':
        return 'BS Biochemistry';
      case 'BTY':
        return 'BS Biotechnology';
      case 'FSN':
        return 'BS Food Science & Nutrition';
      case 'HND':
      case 'BHD':
        return 'BS Human Nutrition & Dietetics';
      case 'RHND':
      case 'RHD':
        return 'MS Human Nutrition & Dietetics';
      case 'RBS':
        return 'MS Biosciences';
      case 'PMI':
        return 'PhD Microbiology & Immunology';
      case 'BSM':
        return 'BS Mathematics';
      case 'BMD':
        return 'BS Mathematics with Data Science';
      case 'RMT':
        return 'MS Mathematics';
      case 'PMT':
        return 'PhD Mathematics';
      case 'BEN':
        return 'BS English';
      case 'MCS':
      case 'MSCS':
      case 'RCS':
        return 'MS Computer Science';
      case 'PCS':
        return 'PhD Computer Science';
      case 'MSSE':
        return 'MS Software Engineering';
      case 'MSEE':
      case 'REE':
        return 'MS Electrical Engineering';
      case 'MSME':
        return 'MS Mechanical Engineering';
      case 'MSMS':
      case 'RMS':
      case 'MBA':
        return 'MS Management Sciences';
      default:
        return 'BS $program';
    }
  }

  static String normalizeProgram(String prog) {
    final p = prog.toUpperCase().trim();
    if (p == 'CS' || p == 'BCS' || p == 'BSCS') return 'BCS';
    if (p == 'SE' || p == 'BSE' || p == 'BSSE') return 'BSE';
    if (p == 'EE' || p == 'BEE' || p == 'BSEE') return 'BEE';
    if (p == 'ME' || p == 'BME' || p == 'BSME') return 'BME';
    if (p == 'CE' || p == 'CVE' || p == 'BSCVE' || p == 'BSCE') return 'CVE';
    if (p == 'HND' || p == 'BHD' || p == 'BSHND') return 'HND';
    if (p == 'RHND' || p == 'RHD' || p == 'MSHND') return 'RHND';
    return p;
  }

  static String resolveDepartment(String prog) {
    switch (prog.toUpperCase()) {
      case 'SE':
      case 'BSE':
      case 'MSSE':
        return 'Software Engineering';
      case 'CS':
      case 'BCS':
      case 'BSCS':
      case 'MCS':
      case 'MSCS':
      case 'PCS':
      case 'RCS':
      case 'BAI':
      case 'BSAI':
      case 'BDS':
      case 'BSDS':
      case 'BCY':
      case 'BSCYS':
        return 'Computer Science';
      case 'BCE':
        return 'Computer Engineering';
      case 'EE':
      case 'BEE':
      case 'REE':
      case 'MSEE':
      case 'BSEE':
        return 'Electrical Engineering';
      case 'ME':
      case 'BME':
      case 'MSME':
      case 'BSME':
        return 'Mechanical Engineering';
      case 'CVE':
      case 'BSCVE':
      case 'CE':
      case 'MSCE':
      case 'BSCE':
        return 'Civil Engineering';
      case 'BAF':
      case 'AF':
        return 'Accounting & Finance';
      case 'BBA':
      case 'BBS':
      case 'MS':
      case 'MSMS':
      case 'MBA':
      case 'RMS':
      case 'PMS':
        return 'Management Sciences';
      case 'BTY':
        return 'Biotechnology';
      case 'BBC':
      case 'BCH':
        return 'Biochemistry';
      case 'FSN':
        return 'Food Science & Nutrition';
      case 'HND':
      case 'BHD':
      case 'RHND':
      case 'RHD':
        return 'Human Nutrition & Dietetics';
      case 'RBS':
      case 'PMI':
      case 'BI':
        return 'Biosciences';
      case 'BEN':
      case 'ENG':
      case 'HUM':
        return 'Humanities';
      case 'MT':
      case 'MTH':
      case 'BSM':
      case 'BMD':
      case 'RMT':
      case 'PMT':
        return 'Mathematics';
      case 'VS':
        return 'Visiting Faculty';
      default:
        return prog.trim().isNotEmpty ? prog.trim().toUpperCase() : 'General';
    }
  }

  int get dynamicSemester => calculateSemester(intake);

  static int calculateSemester(String intake, {DateTime? now}) {
    final current = now ?? DateTime.now();
    if (intake.length < 4) return 1;
    final term = intake.substring(0, 2).toUpperCase();
    final yearSuffix = intake.substring(2, 4);
    final yearShort = int.tryParse(yearSuffix);
    if (yearShort == null) return 1;
    final intakeYear = 2000 + yearShort;

    final currentYear = current.year;
    final currentMonth = current.month;

    // Term Index Calculation:
    // Spring (Mar-Aug) = year * 2
    // Fall (Sep-Feb) = year * 2 + 1
    final intakeIndex = (intakeYear * 2) + (term == 'FA' ? 1 : 0);

    int currentAcademicYear = currentYear;
    bool isFall = false;

    if (currentMonth >= 9) {
      // Sep-Dec: Fall of current year
      isFall = true;
      currentAcademicYear = currentYear;
    } else if (currentMonth <= 2) {
      // Jan-Feb: Fall of previous year
      isFall = true;
      currentAcademicYear = currentYear - 1;
    } else {
      // Mar-Aug: Spring of current year
      isFall = false;
      currentAcademicYear = currentYear;
    }

    final currentIndex = (currentAcademicYear * 2) + (isFall ? 1 : 0);
    final sem = currentIndex - intakeIndex + 1;
    return sem.clamp(1, 8);
  }

  static final Map<String, BatchKey> _batchKeyCache = {};

  factory BatchKey.parse(String batch) {
    final cached = _batchKeyCache[batch];
    if (cached != null) return cached;

    final result = _parseInternal(batch);
    if (_batchKeyCache.length > 2500) {
      _batchKeyCache.clear();
    }
    _batchKeyCache[batch] = result;
    return result;
  }

  static BatchKey _parseInternal(String batch) {
    var raw = batch.replaceAll(RegExp(r'\(.*?\)'), '').trim();
    final fullBatchMatch = RegExp(
      r'^[A-Za-z0-9]+(?:-[A-Za-z0-9]+)+',
      caseSensitive: false,
    ).firstMatch(raw);
    if (fullBatchMatch != null) {
      raw = fullBatchMatch.group(0)!;
    }
    if (raw.toUpperCase() == 'SP26-BBA') {
      raw = 'SP26-BBA-B38';
    }

    final parts = raw.split('-');
    if (parts.length == 1) {
      final prog = normalizeProgram(parts[0]);
      return BatchKey(
        batch: raw,
        program: prog,
        semester: 1,
        section: 'A',
        intake: '',
        department: resolveDepartment(prog),
      );
    }

    if (parts.length == 2) {
      final p0 = parts[0].toUpperCase();
      final p1 = parts[1].toUpperCase();

      // Check if p0 is intake (e.g. FA21-BCS)
      if (RegExp(r'^(?:FA|SP)\d{2}$').hasMatch(p0)) {
        final prog = normalizeProgram(p1);
        final sem = calculateSemester(p0);
        return BatchKey(
          batch: raw,
          program: prog,
          semester: sem,
          section: 'A',
          intake: p0,
          department: resolveDepartment(prog),
        );
      }

      // Short batch format e.g. BCS-6A or BCS-A or BCS-6
      final prog = normalizeProgram(p0);
      final semMatch = RegExp(r'^(\d+)').firstMatch(p1);
      int sem = 1;
      String sec = 'A';
      if (semMatch != null) {
        sem = int.tryParse(semMatch.group(1)!) ?? 1;
        final remainder = p1.substring(semMatch.group(1)!.length).trim();
        if (remainder.isNotEmpty) {
          sec = remainder;
        }
      } else {
        sec = p1.isNotEmpty ? p1 : 'A';
      }

      return BatchKey(
        batch: raw,
        program: prog,
        semester: sem,
        section: sec,
        intake: '',
        department: resolveDepartment(prog),
      );
    }

    final intake = parts[0].toUpperCase();
    final program = normalizeProgram(parts[1]);
    final dept = resolveDepartment(program);

    // Case 1: 4-part batch e.g. "FA25-BCS-3-C", "FA26-BCS-1-A", or "FA23-BSME-B19-A"
    if (parts.length >= 4) {
      final isCohortPart = RegExp(r'^B\d+$', caseSensitive: false).hasMatch(parts[2]);
      final semParsed = int.tryParse(parts[2]) ?? calculateSemester(intake);
      final rawSec = parts[3];
      final secMatch = RegExp(r'^[A-Za-z0-9]{1,3}').firstMatch(rawSec);
      final section = secMatch != null
          ? secMatch.group(0)!.toUpperCase()
          : rawSec.toUpperCase();
      final canonical = isCohortPart
          ? '$intake-$program-${parts[2].toUpperCase()}-$section'
          : '$intake-$program-$semParsed-$section';
      return BatchKey(
        batch: canonical,
        program: program,
        semester: semParsed,
        section: section,
        intake: intake,
        department: dept,
      );
    }

    // Case 2: 3-part batch e.g. "FA26-BCS-1", "FA24-BSE-A" or "SP23-FSN-B"
    final lastPart = parts[2];
    final semMatch = RegExp(r'^\d+').firstMatch(lastPart);
    int semParsed = calculateSemester(intake);
    String section = 'A';

    if (semMatch != null) {
      semParsed = int.tryParse(semMatch.group(0)!) ?? semParsed;
      final secRem = lastPart.substring(semMatch.group(0)!.length);
      if (secRem.isNotEmpty) {
        section = secRem.toUpperCase();
      }
    } else {
      final secMatch = RegExp(r'^[A-Za-z0-9]{1,3}').firstMatch(lastPart);
      section = secMatch != null
          ? secMatch.group(0)!.toUpperCase()
          : lastPart.toUpperCase();
    }

    // If explicit semester digit was provided without section letter (e.g. FA26-BCS-1), construct full 4-part
    final canonical = semMatch != null
        ? '$intake-$program-$semParsed-$section'
        : '$intake-$program-$section';

    return BatchKey(
      batch: canonical,
      program: program,
      semester: semParsed,
      section: section,
      intake: intake,
      department: dept,
    );
  }

  static final Map<String, bool> _batchMatchCache = {};

  /// Comprehensive, mistake-proof matching between a student's batch and an exam batch
  static bool isBatchMatch(String studentBatchRaw, String examBatchRaw) {
    if (studentBatchRaw.isEmpty || examBatchRaw.isEmpty) return false;
    final sClean = studentBatchRaw.trim().toLowerCase();
    final eClean = examBatchRaw.trim().toLowerCase();
    if (sClean == eClean || sClean == 'all' || eClean == 'all') return true;

    final cacheKey = '$sClean|$eClean';
    final cached = _batchMatchCache[cacheKey];
    if (cached != null) return cached;

    final result = _isBatchMatchInternal(studentBatchRaw, examBatchRaw);
    if (_batchMatchCache.length > 3000) {
      _batchMatchCache.clear();
    }
    _batchMatchCache[cacheKey] = result;
    return result;
  }

  static (String, String, String, int) _extractCanonicalExamKey(String rawBatch) {
    final parts = rawBatch
        .trim()
        .toUpperCase()
        .split('-')
        .map((p) => p.trim())
        .where((p) => p.isNotEmpty)
        .toList();
    if (parts.isEmpty) return ('', '', '', 0);

    final hasIntake = RegExp(r'^(?:FA|SP)\d{2}$').hasMatch(parts[0]);
    final intake = hasIntake ? parts[0] : '';
    final rawProg = hasIntake ? (parts.length > 1 ? parts[1] : '') : parts[0];
    final prog = normalizeProgram(rawProg);

    String trueSection = '';
    int explicitSem = 0;
    final startIdx = hasIntake ? 2 : 1;
    for (int i = startIdx; i < parts.length; i++) {
      final token = parts[i];
      if (RegExp(r'^\d+$').hasMatch(token)) {
        explicitSem = int.tryParse(token) ?? 0;
        continue;
      }
      // Cohort numbers like B33, B35, B12, B01, B19 are degree batch numbers, NOT A-F sections
      if (RegExp(r'^B\d+$').hasMatch(token)) {
        continue;
      }
      // Combined token like "6A"
      final semSec = RegExp(r'^(\d+)([A-Z])$').firstMatch(token);
      if (semSec != null) {
        explicitSem = int.tryParse(semSec.group(1)!) ?? explicitSem;
        trueSection = semSec.group(2)!;
        continue;
      }
      if (RegExp(r'^[A-Z]$').hasMatch(token)) {
        trueSection = token;
      }
    }
    return (intake, prog, trueSection, explicitSem);
  }

  static bool _isBatchMatchInternal(String studentBatchRaw, String examBatchRaw) {
    final expandedExamBatches = FormatGuard.expandBatchSections(examBatchRaw);
    final expandedStudentBatches = FormatGuard.expandBatchSections(studentBatchRaw);

    for (final eBatch in expandedExamBatches) {
      final eLower = eBatch.trim().toLowerCase();
      for (final sBatch in expandedStudentBatches) {
        final sLower = sBatch.trim().toLowerCase();
        if (eLower == sLower) return true;

        final (sIntake, sProg, sSec, sExplicitSem) = _extractCanonicalExamKey(sBatch);
        final (eIntake, eProg, eSec, eExplicitSem) = _extractCanonicalExamKey(eBatch);

        if (sProg.isEmpty || eProg.isEmpty || sProg != eProg) continue;

        // If either batch omits a section letter (e.g. FA24-BBA, FA24-BBA-B35, SP26-BSE, SP23-BCS),
        // it applies to the entire intake cohort for that program.
        final secMatch = sSec.isEmpty || eSec.isEmpty || sSec == eSec;
        if (!secMatch) continue;

        if (sIntake.isNotEmpty && eIntake.isNotEmpty && sIntake != 'NA' && eIntake != 'NA') {
          if (sIntake == eIntake) {
            return true;
          }
          continue;
        }

        // Fallback when one side omitted intake (e.g. "BCS-6A"): compare semester
        final sKey = BatchKey.parse(sBatch);
        final eKey = BatchKey.parse(eBatch);
        final sSem = sExplicitSem > 0 ? sExplicitSem : (sKey.semester > 0 ? sKey.semester : sKey.dynamicSemester);
        final eSem = eExplicitSem > 0 ? eExplicitSem : (eKey.semester > 0 ? eKey.semester : eKey.dynamicSemester);
        if (sSem == 0 || eSem == 0 || sSem == eSem) {
          return true;
        }
      }
    }
    return false;
  }
}

class ClassSession {
  final String id;
  final BatchKey batchKey;
  final int dayIndex;
  final String startTime;
  final String endTime;
  final String subject;
  final String teacher;
  final String room;
  final bool isBreak;
  final DateTime? specificDate;
  final List<String>? combinedBatches;
  final double? _startVal;
  final double? _endVal;
  final double? _actualEndVal;

  const ClassSession({
    required this.id,
    required this.batchKey,
    required this.dayIndex,
    required this.startTime,
    required this.endTime,
    required this.subject,
    required this.teacher,
    required this.room,
    this.isBreak = false,
    this.specificDate,
    this.combinedBatches,
    double? startVal,
    double? endVal,
    double? actualEndVal,
  })  : _startVal = startVal,
        _endVal = endVal,
        _actualEndVal = actualEndVal;

  String get displayBatch {
    if (combinedBatches != null && combinedBatches!.length > 1) {
      return combinedBatches!.join(' + ');
    }
    return batchKey.batch;
  }

  bool get isCombinedLecture =>
      combinedBatches != null && combinedBatches!.length > 1;

  double get safeStartVal => _startVal ?? FormatGuard.toDecimalTime(startTime);
  double get safeEndVal => _endVal ?? FormatGuard.toDecimalTime(endTime);

  bool get isOneHourLecture {
    return subject.toLowerCase().contains('(1 hr)') ||
        subject.toLowerCase().contains('(1hr)') ||
        subject.toLowerCase().contains('1 hr)');
  }

  double get actualEndVal {
    if (_actualEndVal != null) return _actualEndVal;
    if (isOneHourLecture) {
      return safeStartVal + 1.0;
    }
    return safeEndVal;
  }

  bool isLive(DateTime now) {
    if (specificDate != null) {
      final isSameDay = specificDate!.year == now.year &&
          specificDate!.month == now.month &&
          specificDate!.day == now.day;
      if (!isSameDay) return false;
    }
    final currentT = now.hour + (now.minute / 60.0);
    return dayIndex == now.weekday &&
        currentT >= safeStartVal &&
        currentT < actualEndVal;
  }

  // Check if this session is consecutive with another
  bool isConsecutiveWith(ClassSession other) {
    return dayIndex == other.dayIndex &&
        subject.trim().toLowerCase() == other.subject.trim().toLowerCase() &&
        teacher.trim().toLowerCase() == other.teacher.trim().toLowerCase() &&
        FormatGuard.sanitizeRoom(room) ==
            FormatGuard.sanitizeRoom(other.room) &&
        ((actualEndVal - other.safeStartVal).abs() < 0.1 ||
            (safeEndVal - other.safeStartVal).abs() < 0.1);
  }

  // Check if two sessions are the same lecture (for merging)
  bool isSameLectureAs(ClassSession other) {
    return dayIndex == other.dayIndex &&
        subject.trim().toLowerCase() == other.subject.trim().toLowerCase() &&
        teacher.trim().toLowerCase() == other.teacher.trim().toLowerCase() &&
        FormatGuard.sanitizeRoom(room) == FormatGuard.sanitizeRoom(other.room);
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'batch': batchKey.batch,
    'day': FormatGuard.normalizeDay(dayIndex),
    'start': startTime,
    'end': endTime,
    'subject': subject,
    'teacher': teacher,
    'room': room,
    if (isBreak) 'is_break': true,
    if (specificDate != null) 'date': specificDate!.toIso8601String(),
    if (combinedBatches != null && combinedBatches!.isNotEmpty)
      'combined_batches': combinedBatches,
  };

  static ClassSession fromJson(Map<String, dynamic> json) {
    final batchStr = (json['batch'] ??
            json['class_name'] ??
            json['section'] ??
            json['Program / Section'] ??
            json['program_section'] ??
            'UNKNOWN')
        .toString();
    final batchKey = BatchKey.parse(batchStr);

    // Parse start and end times, supporting 'period', 'Time Slot', or 'time' splits
    String start = '00:00';
    String end = '00:00';

    if (json['start'] != null && json['end'] != null) {
      start = json['start'].toString();
      end = json['end'].toString();
    } else {
      final timeStr = (json['time'] ??
              json['period'] ??
              json['Time Slot'] ??
              json['time_slot'] ??
              '')
          .toString();
      if (timeStr.isNotEmpty) {
        final parts = timeStr.split('-');
        if (parts.length >= 2) {
          start = parts[0].trim();
          end = parts[1].trim();
        } else if (parts.isNotEmpty) {
          start = parts[0].trim();
        }
      }
    }

    final dayStr = (json['day'] ??
            json['weekday'] ??
            json['Day'] ??
            'Monday')
        .toString();
    var subjectStr = (json['subject'] ??
            json['course'] ??
            json['title'] ??
            json['Subject Name'] ??
            json['subject_name'] ??
            'Unknown')
        .toString();
    var teacherStr = (json['teacher'] ??
            json['instructor'] ??
            json['staff'] ??
            json['Teacher Name'] ??
            json['teacher_name'] ??
            'Unknown')
        .toString();
    final roomStr = (json['room'] ??
            json['location'] ??
            json['Room / Lab'] ??
            json['room_lab'] ??
            'TBD')
        .toString();

    final teacherLower = teacherStr.toLowerCase().trim();
    final isTeacherPlaceholder = teacherLower == 'unknown' ||
        teacherLower == 'staff' ||
        teacherLower == 'to be announced' ||
        teacherLower == 'tba' ||
        teacherLower == 'tbd' ||
        teacherLower == '-' ||
        teacherLower.isEmpty;

    if (isTeacherPlaceholder) {
      // Case 1: Parenthesized instructor e.g. "CS314 AI (Dr. Shahzad Ali)"
      if (subjectStr.contains('(')) {
        final parenMatch = RegExp(
          r'\(((?:Dr\.?|Prof\.?|Engr\.?|Mr\.?|Ms\.?|Mrs\.?|Sir|Mam|[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)[^)]*)\)',
          caseSensitive: false,
        ).firstMatch(subjectStr);
        if (parenMatch != null) {
          teacherStr = parenMatch.group(1)!.trim();
        }
      }

      // Case 2: Embedded teacher prefix e.g. "ME MR Shamaim Technical and Business Writing" or "MR Shamaim ..."
      final prefixTeacherMatch = RegExp(
        r'^(?:(?:ME|CS|SE|EE|BBA|CE|AI|DS|HUM|BCE|BEE|BSCS|BSSE)\s+)?((?:Dr\.?|Prof\.?|Engr\.?|Mr\.?|Ms\.?|Mrs\.?|Sir|Mam)\s+[A-Za-z]+)\s+(.+)$',
        caseSensitive: false,
      ).firstMatch(subjectStr);
      if (prefixTeacherMatch != null) {
        teacherStr = prefixTeacherMatch.group(1)!.trim();
        subjectStr = prefixTeacherMatch.group(2)!.trim();
      }
    }

    // If subject indicates (1 hr) and duration exceeds 1 hour (e.g. regular 1.5-hr slot), clamp duration to 1 hour
    if (RegExp(
      r'\(1\s*(?:hr|hour)\)',
      caseSensitive: false,
    ).hasMatch(subjectStr)) {
      final startDec = FormatGuard.toDecimalTime(start);
      final endDec = FormatGuard.toDecimalTime(end);
      if (endDec - startDec > 1.05) {
        final newEndDec = startDec + 1.0;
        final endH = newEndDec.toInt();
        final endM = ((newEndDec - endH) * 60).round();
        final origH = int.tryParse(start.split(RegExp(r'[:.]'))[0]) ?? 0;
        final adjustedH = origH + 1;
        end =
            '${adjustedH.toString().padLeft(2, '0')}:${endM.toString().padLeft(2, '0')}';
      }
    }

    final cleanSub = FormatGuard.sanitizeSubject(subjectStr);
    final rawType = (json['Type'] ?? json['type'] ?? '').toString().toLowerCase();
    final isBreak = rawType == 'break' ||
        json['is_break'] == true ||
        cleanSub.toLowerCase().contains('prayer break') ||
        cleanSub.toLowerCase().contains('fehm ul quran');

    final startDec = FormatGuard.toDecimalTime(start);
    final endDec = FormatGuard.toDecimalTime(end);
    final is1Hr = cleanSub.toLowerCase().contains('(1 hr)') ||
        cleanSub.toLowerCase().contains('(1hr)') ||
        cleanSub.toLowerCase().contains('1 hr)');
    final actualEndDec = is1Hr ? startDec + 1.0 : endDec;
    final combinedBatches = (json['combined_batches'] as List<dynamic>?)
        ?.map((e) => e.toString())
        .toList();

    return ClassSession(
      id: json['id'] as String? ?? '${batchKey.batch}-$dayStr-$start',
      batchKey: batchKey,
      dayIndex: FormatGuard.dayIndex(dayStr),
      startTime: start,
      endTime: end,
      subject: cleanSub,
      teacher: FormatGuard.formatTeacherName(teacherStr),
      room: FormatGuard.sanitizeRoom(roomStr),
      isBreak: isBreak,
      combinedBatches: combinedBatches,
      startVal: startDec,
      endVal: endDec,
      actualEndVal: actualEndDec,
    );
  }

  static final RegExp _examTagRegex = RegExp(r'\[EXAM\]', caseSensitive: false);
  static final RegExp _parenthesesRegex = RegExp(
    r'\(.*?\)',
    caseSensitive: false,
  );

  static String _resolveExamInvigilator(
    Map<String, dynamic> json,
    BatchKey batchKey,
    String rawSubject,
    UniversityMemory? memory,
  ) {
    var rawTeacher =
        (json['invigilator'] ??
                json['invigilator_name'] ??
                json['invigilators'] ??
                json['teacher'] ??
                json['instructor'] ??
                json['faculty'] ??
                json['duty'] ??
                json['supervised_by'] ??
                json['supervisor'] ??
                '')
            .toString()
            .trim();

    if (rawTeacher.isNotEmpty &&
        rawTeacher.toLowerCase() != 'invigilator assigned' &&
        rawTeacher.toLowerCase() != 'tbd' &&
        rawTeacher.toLowerCase() != 'unknown') {
      return FormatGuard.formatTeacherName(rawTeacher);
    }

    if (memory != null) {
      return memory.resolveTeacherForSubject(batchKey, rawSubject, rawTeacher);
    }

    return rawTeacher.isNotEmpty
        ? FormatGuard.formatTeacherName(rawTeacher)
        : 'Invigilator Assigned';
  }

  static ClassSession fromExamJson(
    Map<String, dynamic> json, {
    int index = 0,
    UniversityMemory? memory,
  }) {
    final batchStr =
        (json['batch'] ?? json['session'] ?? json['class_name'] ?? 'ALL')
            .toString();
    final batchKey = BatchKey.parse(batchStr);

    String start = '09:00 AM';
    String end = '12:00 PM';
    final timeStr = (json['time'] ?? '').toString();
    if (timeStr.isNotEmpty) {
      final parts = timeStr.split('-');
      if (parts.length >= 2) {
        start = parts[0].trim();
        end = parts[1].trim();
      } else if (parts.isNotEmpty) {
        start = parts[0].trim();
      }
    }

    final dateStr = (json['date'] ?? '').toString().trim();
    int dayIdx = DateTime.now().weekday;
    final parsedDt = FormatGuard.parseDate(dateStr);
    if (parsedDt != null) {
      dayIdx = parsedDt.weekday;
    } else {
      final lowerDate = dateStr.toLowerCase();
      if (lowerDate.contains('mon')) {
        dayIdx = 1;
      } else if (lowerDate.contains('tue')) {
        dayIdx = 2;
      } else if (lowerDate.contains('wed')) {
        dayIdx = 3;
      } else if (lowerDate.contains('thu')) {
        dayIdx = 4;
      } else if (lowerDate.contains('fri')) {
        dayIdx = 5;
      } else if (lowerDate.contains('sat')) {
        dayIdx = 6;
      } else if (lowerDate.contains('sun')) {
        dayIdx = 7;
      }
    }

    final rawSubject = (json['subject'] ?? json['course'] ?? 'EXAM').toString();
    final subjectStr = rawSubject.startsWith('[EXAM]')
        ? rawSubject
        : '[EXAM] $rawSubject';
    final teacherStr = _resolveExamInvigilator(
      json,
      batchKey,
      rawSubject,
      memory,
    );
    final roomStr = (json['room'] ?? json['hall'] ?? 'Exam Hall').toString();
    final startDec = FormatGuard.toDecimalTime(start);
    final endDec = FormatGuard.toDecimalTime(end);

    return ClassSession(
      id: 'exam_${batchKey.batch}_${index}_$start',
      batchKey: batchKey,
      dayIndex: dayIdx,
      startTime: start,
      endTime: end,
      subject: subjectStr,
      teacher: teacherStr,
      room: FormatGuard.sanitizeRoom(roomStr),
      specificDate: parsedDt,
      startVal: startDec,
      endVal: endDec,
      actualEndVal: endDec,
    );
  }
}

class UniversityMemory {
  final List<ClassSession> sessions;

  UniversityMemory([this.sessions = const []]);

  List<ClassSession>? _cachedActiveSessions;
  String? _cachedPeriodKey;
  int? _cachedExamsHash;
  Map<String, String>? _teacherByBatchSubjectMap;
  Map<String, String>? _teacherBySubjectMap;

  final Map<String, Map<String, List<ClassSession>>> _cachedByBatchMap = {};
  final Map<String, Map<String, List<ClassSession>>> _cachedByTeacherMap = {};
  final Map<String, Map<String, List<ClassSession>>> _cachedByProgramMap = {};
  List<String>? _cachedAllBatches;
  List<String>? _cachedPrograms;
  final Map<String, List<String>> _cachedAllRooms = {};
  final Map<String, List<String>> _cachedAllTeachers = {};
  final Map<String, List<int>> _cachedSemesters = {};
  final Map<String, List<String>> _cachedIntakes = {};
  final Map<String, List<String>> _cachedSectionsForIntake = {};
  final Map<String, List<String>> _cachedSections = {};

  void _initTeacherLookups() {
    if (_teacherByBatchSubjectMap != null) return;
    final bMap = <String, String>{};
    final sMap = <String, String>{};

    for (final s in sessions) {
      if (s.teacher.isEmpty || s.teacher.toLowerCase() == 'unknown') continue;
      final cleanSub = s.subject
          .replaceAll(ClassSession._parenthesesRegex, '')
          .trim()
          .toLowerCase();
      if (cleanSub.isEmpty) continue;

      final formatted = FormatGuard.formatTeacherName(s.teacher);
      final bKey = s.batchKey.batch.toLowerCase();
      bMap['${bKey}_$cleanSub'] = formatted;
      sMap[cleanSub] = formatted;
    }
    _teacherByBatchSubjectMap = bMap;
    _teacherBySubjectMap = sMap;
  }

  String resolveTeacherForSubject(BatchKey batchKey, String rawSubject, String rawTeacher) {
    if (rawTeacher.isNotEmpty &&
        rawTeacher.toLowerCase() != 'invigilator assigned' &&
        rawTeacher.toLowerCase() != 'tbd' &&
        rawTeacher.toLowerCase() != 'unknown') {
      return FormatGuard.formatTeacherName(rawTeacher);
    }

    _initTeacherLookups();
    final cleanSubject = rawSubject
        .replaceAll(ClassSession._examTagRegex, '')
        .replaceAll(ClassSession._parenthesesRegex, '')
        .trim()
        .toLowerCase();

    if (cleanSubject.isNotEmpty) {
      final key = '${batchKey.batch.toLowerCase()}_$cleanSubject';
      final match = _teacherByBatchSubjectMap![key] ?? _teacherBySubjectMap![cleanSubject];
      if (match != null) return match;
    }

    return rawTeacher.isNotEmpty
        ? FormatGuard.formatTeacherName(rawTeacher)
        : 'Invigilator Assigned';
  }

  void clearCaches() {
    _cachedActiveSessions = null;
    _cachedPeriodKey = null;
    _cachedExamsHash = null;
    _teacherByBatchSubjectMap = null;
    _teacherBySubjectMap = null;
    _cachedByBatchMap.clear();
    _cachedByTeacherMap.clear();
    _cachedByProgramMap.clear();
    _cachedAllBatches = null;
    _cachedPrograms = null;
    _cachedAllRooms.clear();
    _cachedAllTeachers.clear();
    _cachedSemesters.clear();
    _cachedIntakes.clear();
    _cachedSectionsForIntake.clear();
    _cachedSections.clear();
  }

  List<ClassSession> _synthesizeExamSessionsFromTimetable(String period) {
    final isMid = period == 'midterms';
    final seenCoursePerBatch = <String>{};
    final synthesized = <ClassSession>[];
    int idx = 0;

    for (final s in sessions) {
      if (s.isBreak) continue;
      final cleanSub = s.subject
          .replaceAll(RegExp(r'\(Lab\)', caseSensitive: false), '')
          .replaceAll(ClassSession._parenthesesRegex, '')
          .trim();
      if (cleanSub.isEmpty) continue;
      final key = '${s.batchKey.batch.toLowerCase()}|${cleanSub.toLowerCase()}';
      if (!seenCoursePerBatch.add(key)) continue;

      final dayIdx = ((synthesized.length) % 5) + 1;
      final isMorning = (s.batchKey.semester % 2 == 1) || (synthesized.length % 2 == 0);
      final start = isMorning
          ? (isMid ? '09:00 AM' : '09:00 AM')
          : (isMid ? '01:30 PM' : '01:30 PM');
      final end = isMorning
          ? (isMid ? '10:30 AM' : '12:00 PM')
          : (isMid ? '03:00 PM' : '04:30 PM');
      final startDec = FormatGuard.toDecimalTime(start);
      final endDec = FormatGuard.toDecimalTime(end);

      synthesized.add(
        ClassSession(
          id: 'exam_${period}_${s.batchKey.batch}_$idx',
          batchKey: s.batchKey,
          dayIndex: dayIdx,
          startTime: start,
          endTime: end,
          subject: '[EXAM] $cleanSub',
          teacher: s.teacher,
          room: s.room.isNotEmpty ? s.room : 'Exam Hall A',
          startVal: startDec,
          endVal: endDec,
          actualEndVal: endDec,
        ),
      );
      idx++;
    }
    return synthesized.isNotEmpty ? synthesized : sessions;
  }

  List<ClassSession> _toRamadanSessions(List<ClassSession> regularSessions) {
    return regularSessions.map((s) {
      String newStart = s.startTime;
      String newEnd = s.endTime;

      final isMultiSlot = (s.safeEndVal - s.safeStartVal) > 2.0;

      if (s.startTime.contains('08:30') || s.startTime.contains('8:30')) {
        newStart = '08:30 AM';
        newEnd = isMultiSlot ? '10:30 AM' : '09:30 AM';
      } else if (s.startTime.contains('09:55') ||
          s.startTime.contains('9:55') ||
          s.startTime.contains('10:00')) {
        newStart = '09:30 AM';
        newEnd = isMultiSlot ? '11:30 AM' : '10:30 AM';
      } else if (s.startTime.contains('11:20') ||
          s.startTime.contains('11:30')) {
        newStart = '10:30 AM';
        newEnd = isMultiSlot ? '12:30 PM' : '11:30 AM';
      } else if (s.startTime.contains('01:40') ||
          s.startTime.contains('1:40') ||
          s.startTime.contains('13:40') ||
          s.startTime.contains('01:30') ||
          s.startTime.contains('1:30') ||
          s.startTime.contains('13:30')) {
        newStart = '11:30 AM';
        newEnd = isMultiSlot ? '01:30 PM' : '12:30 PM';
      } else if (s.startTime.contains('03:05') ||
          s.startTime.contains('3:05') ||
          s.startTime.contains('15:05') ||
          s.startTime.contains('03:00') ||
          s.startTime.contains('3:00') ||
          s.startTime.contains('15:00')) {
        newStart = '12:30 PM';
        newEnd = '01:30 PM';
      }

      final startDec = FormatGuard.toDecimalTime(newStart);
      final endDec = FormatGuard.toDecimalTime(newEnd);

      return ClassSession(
        id: s.id.endsWith('_ramadan') ? s.id : '${s.id}_ramadan',
        batchKey: s.batchKey,
        dayIndex: s.dayIndex,
        startTime: newStart,
        endTime: newEnd,
        subject: s.subject,
        teacher: s.teacher,
        room: s.room,
        isBreak: s.isBreak,
        specificDate: s.specificDate,
        combinedBatches: s.combinedBatches,
        startVal: startDec,
        endVal: endDec,
        actualEndVal: endDec,
      );
    }).toList();
  }

  List<ClassSession> activeSessions({
    String? overridePeriod,
    List<dynamic>? customMidterms,
    List<dynamic>? customFinals,
  }) {
    final period =
        overridePeriod ?? RemoteConfigService.activeAcademicPeriod.value;
    final rawExams = period == 'midterms'
        ? (customMidterms ?? RemoteConfigService.midtermExams.value)
        : (period == 'finals'
              ? (customFinals ?? RemoteConfigService.finalExams.value)
              : null);

    final examsHash = rawExams != null
        ? Object.hash(rawExams.length, rawExams.hashCode)
        : 0;
    final periodKey = '${period}_$overridePeriod';

    if (_cachedActiveSessions != null &&
        _cachedPeriodKey == periodKey &&
        _cachedExamsHash == examsHash) {
      return _cachedActiveSessions!;
    }

    List<ClassSession> result;
    if ((period == 'midterms' || period == 'finals') &&
        rawExams != null &&
        rawExams.isNotEmpty) {
      final parsed = <ClassSession>[];
      for (int i = 0; i < rawExams.length; i++) {
        final item = rawExams[i];
        final map = item is Map<String, dynamic>
            ? item
            : (item is Map ? Map<String, dynamic>.from(item) : null);
        if (map == null) continue;

        final batchRaw =
            (map['batch'] ?? map['session'] ?? map['class_name'] ?? 'ALL')
                .toString();
        final expanded = FormatGuard.expandBatchSections(batchRaw);
        if (expanded.length > 1) {
          for (int b = 0; b < expanded.length; b++) {
            final cloned = Map<String, dynamic>.from(map);
            cloned['batch'] = expanded[b];
            parsed.add(
              ClassSession.fromExamJson(
                cloned,
                index: i * 100 + b,
                memory: this,
              ),
            );
          }
        } else {
          parsed.add(ClassSession.fromExamJson(map, index: i, memory: this));
        }
      }
      result = parsed.isNotEmpty ? parsed : _synthesizeExamSessionsFromTimetable(period);
    } else if (period == 'midterms' || period == 'finals') {
      result = _synthesizeExamSessionsFromTimetable(period);
    } else if (period == 'ramadan') {
      result = _toRamadanSessions(sessions);
    } else {
      result = sessions;
    }

    _cachedActiveSessions = result;
    _cachedPeriodKey = periodKey;
    _cachedExamsHash = examsHash;
    _cachedByBatchMap.remove(periodKey);
    _cachedByTeacherMap.remove(periodKey);
    _cachedByProgramMap.remove(periodKey);
    return result;
  }

  List<String> get allBatches {
    if (_cachedAllBatches != null) return _cachedAllBatches!;
    final batches = sessions.map((s) => s.batchKey.batch).toSet().toList();
    batches.sort();
    _cachedAllBatches = batches;
    return batches;
  }

  Map<String, List<ClassSession>> byBatch({String? overridePeriod}) {
    final periodKey = overridePeriod ?? 'default';
    final cached = _cachedByBatchMap[periodKey];
    if (cached != null) return cached;

    final map = <String, List<ClassSession>>{};
    for (final session in activeSessions(overridePeriod: overridePeriod)) {
      map.putIfAbsent(session.batchKey.batch, () => []).add(session);
    }
    _cachedByBatchMap[periodKey] = map;
    return map;
  }

  Map<String, List<ClassSession>> byTeacher({String? overridePeriod}) {
    final periodKey = overridePeriod ?? 'default';
    final cached = _cachedByTeacherMap[periodKey];
    if (cached != null) return cached;

    final map = <String, List<ClassSession>>{};
    for (final session in activeSessions(overridePeriod: overridePeriod)) {
      final rawTeacher = session.teacher.trim();
      final individualTeachers = rawTeacher.contains(',')
          ? [rawTeacher, ...rawTeacher.split(',').map((p) => p.trim()).where((p) => p.isNotEmpty)]
          : [rawTeacher];
      for (final t in individualTeachers) {
        final rawKey = t.toLowerCase();
        if (rawKey.isNotEmpty && rawKey != 'unknown' && rawKey != 'na' && rawKey != 'staff' && rawKey != 'to be announced') {
          map.putIfAbsent(rawKey, () => []).add(session);
          final cleanKey = FormatGuard.formatTeacherName(t).toLowerCase();
          if (cleanKey != rawKey && cleanKey.isNotEmpty && cleanKey != 'staff') {
            map.putIfAbsent(cleanKey, () => []).add(session);
          }
          final strippedKey = HelpdeskFacultyService.stripDepartmentPrefix(t).toLowerCase();
          if (strippedKey != rawKey && strippedKey != cleanKey && strippedKey.isNotEmpty && strippedKey != 'staff') {
            map.putIfAbsent(strippedKey, () => []).add(session);
          }
        }
      }
    }
    _cachedByTeacherMap[periodKey] = map;
    return map;
  }

  Map<String, List<ClassSession>> byProgram(
    String program, {
    String? overridePeriod,
  }) {
    final progUpper = program.toUpperCase().trim();
    final periodKey = '${overridePeriod ?? "default"}_$progUpper';
    final cached = _cachedByProgramMap[periodKey];
    if (cached != null) return cached;

    final map = <String, List<ClassSession>>{};
    for (final session in activeSessions(
      overridePeriod: overridePeriod,
    ).where((s) => s.batchKey.program.toUpperCase().trim() == progUpper)) {
      map.putIfAbsent(session.batchKey.batch, () => []).add(session);
    }
    _cachedByProgramMap[periodKey] = map;
    return map;
  }

  List<String> programs() {
    if (_cachedPrograms != null) return _cachedPrograms!;
    final items = sessions
        .map((s) => s.batchKey.program.toUpperCase().trim())
        .where(
          (p) =>
              p.isNotEmpty &&
              p != 'UNKNOWN' &&
              p != 'NA' &&
              !RegExp(r'^(FA|SP)\d{2}$').hasMatch(p),
        )
        .toSet()
        .toList();
    items.sort();
    _cachedPrograms = items;
    return items;
  }

  List<int> semesters(String program) {
    final progUpper = program.toUpperCase().trim();
    final cached = _cachedSemesters[progUpper];
    if (cached != null) return cached;

    final items = sessions
        .where((s) => s.batchKey.program.toUpperCase().trim() == progUpper)
        .map((s) => s.batchKey.semester)
        .where((sem) => sem > 0)
        .toSet()
        .toList();
    items.sort();
    _cachedSemesters[progUpper] = items;
    return items;
  }

  List<String> intakes(String program) {
    final progUpper = program.toUpperCase().trim();
    final cached = _cachedIntakes[progUpper];
    if (cached != null) return cached;

    final items = sessions
        .where((s) => s.batchKey.program.toUpperCase().trim() == progUpper)
        .map((s) => s.batchKey.intake.toUpperCase().trim())
        .where(
          (intake) =>
              intake.isNotEmpty && intake != 'UNKNOWN' && intake != 'NA',
        )
        .toSet()
        .toList();
    items.sort((a, b) {
      final aYear =
          int.tryParse(RegExp(r'\d+').firstMatch(a)?.group(0) ?? '') ?? 0;
      final bYear =
          int.tryParse(RegExp(r'\d+').firstMatch(b)?.group(0) ?? '') ?? 0;
      if (aYear != bYear) return bYear.compareTo(aYear);
      return b.compareTo(a);
    });
    _cachedIntakes[progUpper] = items;
    return items;
  }

  List<String> sectionsForIntake(String program, String intake) {
    final progUpper = program.toUpperCase().trim();
    final intakeUpper = intake.toUpperCase().trim();
    final cacheKey = '${progUpper}_$intakeUpper';
    final cached = _cachedSectionsForIntake[cacheKey];
    if (cached != null) return cached;

    final items = sessions
        .where(
          (s) =>
              s.batchKey.program.toUpperCase().trim() == progUpper &&
              s.batchKey.intake.toUpperCase().trim() == intakeUpper,
        )
        .map((s) {
          final sec = s.batchKey.section.trim();
          final m = RegExp(r'^[A-Za-z0-9]{1,3}').firstMatch(sec);
          return m != null ? m.group(0)!.toUpperCase() : sec.toUpperCase();
        })
        .where((s) => s.isNotEmpty && s != 'UNKNOWN' && s != 'NA')
        .toSet()
        .toList();
    items.sort();
    _cachedSectionsForIntake[cacheKey] = items;
    return items;
  }

  List<String> sections(String program, int semester) {
    final progUpper = program.toUpperCase().trim();
    final cacheKey = '${progUpper}_$semester';
    final cached = _cachedSections[cacheKey];
    if (cached != null) return cached;

    final items = sessions
        .where(
          (s) =>
              s.batchKey.program.toUpperCase().trim() == progUpper &&
              s.batchKey.semester == semester,
        )
        .map((s) {
          final sec = s.batchKey.section.trim();
          final m = RegExp(r'^[A-Za-z0-9]{1,3}').firstMatch(sec);
          return m != null ? m.group(0)!.toUpperCase() : sec.toUpperCase();
        })
        .where((s) => s.isNotEmpty && s != 'UNKNOWN' && s != 'NA')
        .toSet()
        .toList();
    items.sort();
    _cachedSections[cacheKey] = items;
    return items;
  }

  List<String> allRooms({String? overridePeriod}) {
    final periodKey = overridePeriod ?? 'default';
    final cached = _cachedAllRooms[periodKey];
    if (cached != null) return cached;

    final rooms = <String>{};
    for (final session in activeSessions(overridePeriod: overridePeriod)) {
      final r = session.room.trim();
      if (r.isNotEmpty &&
          r.toLowerCase() != 'unknown' &&
          r.toLowerCase() != 'na') {
        rooms.add(r);
      }
    }
    final sorted = rooms.toList()..sort();
    _cachedAllRooms[periodKey] = sorted;
    return sorted;
  }

  List<String> allTeachers({String? overridePeriod}) {
    final periodKey = overridePeriod ?? 'default';
    final cached = _cachedAllTeachers[periodKey];
    if (cached != null) return cached;

    final nameMap = <String, String>{};
    for (final session in activeSessions(overridePeriod: overridePeriod)) {
      final raw = session.teacher.trim();
      if (raw.isEmpty ||
          raw.toLowerCase() == 'unknown' ||
          raw.toLowerCase() == 'na' ||
          raw.toLowerCase() == 'staff' ||
          raw.toLowerCase().startsWith('tbd')) {
        continue;
      }
      final clean = FormatGuard.formatTeacherName(raw);
      if (clean.isEmpty || clean.toLowerCase() == 'staff') continue;

      final normKey = HelpdeskFacultyService.normalizeFacultyName(clean);
      final title = HelpdeskFacultyService.extractHonorificCategory(clean);
      final existing = nameMap[normKey];
      if (existing == null) {
        nameMap[normKey] = clean;
      } else {
        final existingTitle = HelpdeskFacultyService.extractHonorificCategory(existing);
        if (HelpdeskFacultyService.areHonorificsConflicting(title, existingTitle)) {
          nameMap['${title}_$normKey'] = clean;
        } else if (title.isNotEmpty && existingTitle.isEmpty) {
          nameMap[normKey] = clean;
        }
      }
    }
    final sorted = nameMap.values.toSet().toList()..sort();
    _cachedAllTeachers[periodKey] = sorted;
    return sorted;
  }
}

class Room {
  final String id;
  final String building;
  final int capacity;
  final List<String> amenities;
  final DateTime registeredAt;

  Room({
    required this.id,
    required this.building,
    required this.capacity,
    required this.amenities,
    required this.registeredAt,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'building': building,
    'capacity': capacity,
    'amenities': amenities,
    'registeredAt': registeredAt.toIso8601String(),
  };

  factory Room.fromJson(Map<String, dynamic> json) => Room(
    id: FormatGuard.sanitizeRoom((json['id'] ?? '').toString()),
    building: (json['building'] ?? '').toString(),
    capacity: (json['capacity'] as num?)?.toInt() ?? 40,
    amenities: List<String>.from(json['amenities'] as List? ?? const []),
    registeredAt: DateTime.tryParse((json['registeredAt'] ?? '').toString()) ?? DateTime.now(),
  );
}

class Department {
  final String id;
  final String name;
  final DateTime registeredAt;

  Department({
    required this.id,
    required this.name,
    required this.registeredAt,
  });
}

class RoomAvailability {
  final String roomId;
  final String building;
  final int capacity;
  final List<String> amenities;
  final bool isAvailable;
  final double? occupiedUntil;
  final String? occupiedBy;
  final String? occupiedByTeacher;
  final double? nextSessionAt;
  final String? nextSessionSubject;
  final int? minulesFreeUntilNextSession;
  final double studyScore;
  final List<bool>? slotOccupancy;
  final String? formattedLocation;

  RoomAvailability({
    required this.roomId,
    required this.building,
    required this.capacity,
    required this.amenities,
    required this.isAvailable,
    this.occupiedUntil,
    this.occupiedBy,
    this.occupiedByTeacher,
    this.nextSessionAt,
    this.nextSessionSubject,
    this.minulesFreeUntilNextSession,
    required this.studyScore,
    this.slotOccupancy,
    this.formattedLocation,
  });
}

class RoomConflict {
  final String room;
  final ClassSession session1;
  final ClassSession session2;
  final int overlapMinutes;
  final String severity; // HIGH, MEDIUM, LOW

  RoomConflict({
    required this.room,
    required this.session1,
    required this.session2,
    required this.overlapMinutes,
    required this.severity,
  });
}

class RoomRecommendation {
  final RoomAvailability? recommended;
  final String reason;
  final List<RoomAvailability> alternatives;

  RoomRecommendation({
    required this.recommended,
    required this.reason,
    required this.alternatives,
  });
}

// Lightweight compatibility helper
class LectureDuration {
  static double getActualDuration(ClassSession session) {
    return (session.safeEndVal - session.safeStartVal).abs();
  }

  static double getActualEndTime(ClassSession session) {
    return session.safeEndVal;
  }
}

class TimeSlot {
  final double start;
  final double end;
  
  const TimeSlot(this.start, this.end);

  String formatLabel(int index) {
    return 'Slot ${index + 1} (${formatTime(start)} - ${formatTime(end)})';
  }

  static String formatTime(double hourVal) {
    int h = hourVal.floor();
    int m = ((hourVal - h) * 60).round();
    final ampm = h >= 12 ? 'PM' : 'AM';
    if (h > 12) h -= 12;
    if (h == 0) h = 12;
    final mStr = m.toString().padLeft(2, '0');
    return '${h.toString().padLeft(2, '0')}:$mStr $ampm';
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is TimeSlot &&
          runtimeType == other.runtimeType &&
          start == other.start &&
          end == other.end;

  @override
  int get hashCode => start.hashCode ^ end.hashCode;
}

class CampusBuilding {
  final String name;
  final String type; // 'academic', 'administrative', 'cafeteria', 'library', 'sports', 'amenity'
  final double latitude;
  final double longitude;
  final List<String> departments;
  final List<CampusFloor> floors;

  const CampusBuilding({
    required this.name,
    required this.type,
    required this.latitude,
    required this.longitude,
    required this.departments,
    required this.floors,
  });
}

class CampusFloor {
  final String level;
  final List<CampusRoom> rooms;

  const CampusFloor({
    required this.level,
    required this.rooms,
  });
}

class CampusRoom {
  final String code;
  final String name;
  final String type; // 'classroom', 'lab', 'office', 'amenity'
  final String? attendant;
  final String? mobile;

  const CampusRoom({
    required this.code,
    required this.name,
    required this.type,
    this.attendant,
    this.mobile,
  });
}

