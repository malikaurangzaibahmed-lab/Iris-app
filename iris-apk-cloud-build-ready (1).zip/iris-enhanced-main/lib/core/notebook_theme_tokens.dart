import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Design tokens, authentic graph paper painters, and tactile 3D physical widgets
/// for the Notebook / Stationery Theme (Modeled after Notebook · Light.png & Notebook · Dark.png).
class NotebookTokens {
  // --- Canvas & Surfaces ---
  static Color canvas(bool isDark) =>
      isDark ? const Color(0xFF1B2520) : const Color(0xFFFBF9F3);

  static Color cardSurface(bool isDark) =>
      isDark ? const Color(0xFF23302A) : Colors.white;

  // --- Sticky Note Colors ---
  static const Color stickyYellowLight = Color(0xFFFEE871);
  static const Color stickyYellowDark = Color(0xFFFDE047);
  static Color stickyNote(bool isDark) =>
      isDark ? const Color(0xFF284B3C) : const Color(0xFFFEE871);

  // --- Graph Paper & Grid Lines ---
  static Color gridLine(bool isDark) =>
      isDark ? const Color(0xFF2F453B).withValues(alpha: 0.45) : const Color(0xFF2D7D46).withValues(alpha: 0.14);

  static Color marginRule(bool isDark) =>
      isDark ? const Color(0xFFFF6B6B).withValues(alpha: 0.70) : const Color(0xFFE55353).withValues(alpha: 0.85);

  // --- Doodle & Ink Colors ---
  static Color redDoodle(bool isDark) =>
      isDark ? const Color(0xFFFF6E6E) : const Color(0xFFD63B38);

  static Color highlighterPink = const Color(0xFFFF74B1);
  static Color highlighterYellow = const Color(0xFFFDE047);

  static Color inkHeading(bool isDark) =>
      isDark ? const Color(0xFFF4F6F4) : const Color(0xFF1A1F1C);

  static Color inkBody(bool isDark) =>
      isDark ? const Color(0xFFD0D7D2) : const Color(0xFF2C3530);

  static Color inkMuted(bool isDark) =>
      isDark ? const Color(0xFF8B9E93) : const Color(0xFF6B7A70);

  // --- Washi Tape Colors ---
  static const Color tapeFrosted = Color(0x99FFFFFF);
  static const Color tapeYellow = Color(0xD9FDE68A);
  static const Color tapeMint = Color(0xC0A7F3D0);
  static const Color tapeCoral = Color(0xC0FECDD3);

  // --- Bottom Navigation Colors ---
  static Color navBarBackground(bool isDark) =>
      isDark ? const Color(0xFF161F1A) : const Color(0xFFF7F5EE);

  static Color navBarBorder(bool isDark) =>
      isDark ? const Color(0xFF2F453B) : const Color(0xFFBDC7BC);

  static Color navActivePill(bool isDark) =>
      isDark ? const Color(0xFFFEE871) : const Color(0xFFFEE871);

  static Color navActiveText(bool isDark) => const Color(0xFF1A1F1C);

  static Color navInactiveText(bool isDark) =>
      isDark ? const Color(0xFFE2EBE5) : const Color(0xFF2C3530);

  // --- Handwritten Typography ---
  static TextStyle headerDate(bool isDark) {
    return GoogleFonts.kalam(
      fontSize: 34,
      fontWeight: FontWeight.w700,
      letterSpacing: -0.5,
      height: 1.1,
      color: inkHeading(isDark),
    );
  }

  static TextStyle cursiveGreeting(bool isDark) {
    return GoogleFonts.caveat(
      fontSize: 22,
      fontWeight: FontWeight.w600,
      letterSpacing: 0.2,
      color: inkMuted(isDark),
    );
  }

  static TextStyle boldScript(
    bool isDark, {
    double fontSize = 18,
    Color? color,
    FontWeight fontWeight = FontWeight.w700,
  }) {
    return GoogleFonts.kalam(
      fontSize: fontSize,
      fontWeight: fontWeight,
      letterSpacing: -0.2,
      color: color ?? inkHeading(isDark),
    );
  }

  static TextStyle handwrittenBody(
    bool isDark, {
    double fontSize = 14,
    Color? color,
    FontWeight fontWeight = FontWeight.w600,
  }) {
    return GoogleFonts.patrickHand(
      fontSize: fontSize,
      fontWeight: fontWeight,
      letterSpacing: 0.1,
      color: color ?? inkBody(isDark),
    );
  }

  static TextStyle monoTimestamp(bool isDark) {
    return GoogleFonts.spaceMono(
      fontSize: 10,
      fontWeight: FontWeight.w500,
      letterSpacing: 0.5,
      color: inkMuted(isDark),
    );
  }
}

// =============================================================================
// 1. ISOMETRIC GRAPH PAPER BACKGROUND PAINTER
// =============================================================================

/// Renders authentic student graph paper with grid squares and a left red margin rule.
class NotebookGraphPaperPainter extends CustomPainter {
  final bool isDark;
  final double gridSize;
  final double marginX;

  NotebookGraphPaperPainter({
    required this.isDark,
    this.gridSize = 22.0,
    this.marginX = 42.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    // 1. Fill base paper color
    final bgPaint = Paint()..color = NotebookTokens.canvas(isDark);
    canvas.drawRect(Offset.zero & size, bgPaint);

    // 2. Draw subtle grid lines
    final gridPaint = Paint()
      ..color = NotebookTokens.gridLine(isDark)
      ..strokeWidth = 0.75
      ..style = PaintingStyle.stroke;

    // Vertical grid lines
    for (double x = 0; x < size.width; x += gridSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }

    // Horizontal grid lines
    for (double y = 0; y < size.height; y += gridSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    // 3. Draw authentic red student notebook margin line on left
    final marginPaint = Paint()
      ..color = NotebookTokens.marginRule(isDark)
      ..strokeWidth = 1.3
      ..style = PaintingStyle.stroke;

    canvas.drawLine(Offset(marginX, 0), Offset(marginX, size.height), marginPaint);
  }

  @override
  bool shouldRepaint(covariant NotebookGraphPaperPainter oldDelegate) {
    return oldDelegate.isDark != isDark ||
        oldDelegate.gridSize != gridSize ||
        oldDelegate.marginX != marginX;
  }
}

// =============================================================================
// 2. SPATIAL 3D METALLIC SPIRAL BINDER RINGS
// =============================================================================

/// Realistic 3D metallic wire coils looping over the top edge of the notebook pad.
/// Breaks out of standard flat bounds with realistic metallic specular highlight and cast shadows.
class NotebookSpiralRings extends StatelessWidget {
  final int ringCount;
  final bool isDark;

  const NotebookSpiralRings({
    super.key,
    this.ringCount = 14,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 24,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final ringSpacing = constraints.maxWidth / (ringCount + 1);
          return Stack(
            clipBehavior: Clip.none,
            children: List.generate(ringCount, (index) {
              final xPos = ringSpacing * (index + 1) - 6;
              return Positioned(
                left: xPos,
                top: -6,
                child: CustomPaint(
                  size: const Size(12, 28),
                  painter: _SpiralRingPainter(isDark: isDark),
                ),
              );
            }),
          );
        },
      ),
    );
  }
}

class _SpiralRingPainter extends CustomPainter {
  final bool isDark;
  _SpiralRingPainter({required this.isDark});

  @override
  void paint(Canvas canvas, Size size) {
    // 1. Hole punch hole (dark elliptical shadow)
    final holePaint = Paint()
      ..color = isDark ? const Color(0xFF0F1512) : const Color(0xFF4A443B).withValues(alpha: 0.35)
      ..style = PaintingStyle.fill;
    canvas.drawOval(Rect.fromLTWH(2, size.height - 8, 8, 6), holePaint);

    // 2. Cast drop shadow of the metallic coil
    final shadowPaint = Paint()
      ..color = Colors.black.withValues(alpha: 0.22)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.5)
      ..strokeWidth = 3.5
      ..style = PaintingStyle.stroke;

    final path = Path()
      ..moveTo(size.width * 0.25, 0)
      ..cubicTo(
        -2, size.height * 0.3,
        -2, size.height * 0.7,
        size.width * 0.5, size.height - 4,
      );
    canvas.drawPath(path, shadowPaint);

    // 3. Metallic ring coil with shiny metallic gradient
    final ringPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: isDark
            ? [
                const Color(0xFFC0C7C3),
                const Color(0xFF8E9993),
                const Color(0xFF4E5752),
                const Color(0xFFB0B8B3),
              ]
            : [
                const Color(0xFFFFFFFF),
                const Color(0xFFB8C0BA),
                const Color(0xFF707A74),
                const Color(0xFFD6DDD8),
              ],
        stops: const [0.0, 0.35, 0.7, 1.0],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..strokeWidth = 3.2
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    canvas.drawPath(path, ringPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// =============================================================================
// 3. WASHI TAPE OVERHANG (BREAKS OUT OF CARD BOUNDS)
// =============================================================================

/// Authentic translucent washi tape strip with jagged serrated ends.
/// Positioned with negative offsets so it physically hangs over the card boundary!
class WashiTapeOverhang extends StatelessWidget {
  final double width;
  final double height;
  final Color color;
  final double rotation;

  const WashiTapeOverhang({
    super.key,
    this.width = 72,
    this.height = 20,
    this.color = NotebookTokens.tapeFrosted,
    this.rotation = -0.03, // Slight natural manual tilt
  });

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: rotation,
      child: CustomPaint(
        size: Size(width, height),
        painter: _WashiTapePainter(color: color),
      ),
    );
  }
}

class _WashiTapePainter extends CustomPainter {
  final Color color;
  _WashiTapePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    // 1. Soft drop shadow cast by the tape
    final shadowPaint = Paint()
      ..color = Colors.black.withValues(alpha: 0.12)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.0);

    final path = Path();
    // Top edge
    path.moveTo(3, 0);
    path.lineTo(size.width - 3, 0);

    // Right torn serrated edge
    const jaggedSteps = 5;
    final stepH = size.height / jaggedSteps;
    for (int i = 0; i < jaggedSteps; i++) {
      final y = (i + 1) * stepH;
      final x = (i % 2 == 0) ? size.width : size.width - 2.5;
      path.lineTo(x, y);
    }

    // Bottom edge
    path.lineTo(3, size.height);

    // Left torn serrated edge
    for (int i = jaggedSteps; i > 0; i--) {
      final y = (i - 1) * stepH;
      final x = (i % 2 == 0) ? 0.0 : 2.5;
      path.lineTo(x, y);
    }
    path.close();

    // Draw shadow
    canvas.save();
    canvas.translate(0, 1.5);
    canvas.drawPath(path, shadowPaint);
    canvas.restore();

    // 2. Draw semi-transparent washi tape body
    final tapePaint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;
    canvas.drawPath(path, tapePaint);

    // 3. Subtle fibrous texture line across tape
    final fiberPaint = Paint()
      ..color = Colors.white.withValues(alpha: 0.25)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;
    canvas.drawLine(
      Offset(4, size.height * 0.35),
      Offset(size.width - 4, size.height * 0.35),
      fiberPaint,
    );
    canvas.drawLine(
      Offset(6, size.height * 0.65),
      Offset(size.width - 6, size.height * 0.65),
      fiberPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// =============================================================================
// 4. 3D CURLED PAPER CORNER PAINTER
// =============================================================================

/// Renders an authentic lifted 3D curled paper corner with cast shadow on the bottom right.
class CurledPaperCorner extends StatelessWidget {
  final double size;
  final bool isDark;
  final Color paperColor;

  const CurledPaperCorner({
    super.key,
    this.size = 24.0,
    required this.isDark,
    required this.paperColor,
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(size, size),
      painter: _CurledPaperCornerPainter(
        isDark: isDark,
        paperColor: paperColor,
      ),
    );
  }
}

class _CurledPaperCornerPainter extends CustomPainter {
  final bool isDark;
  final Color paperColor;

  _CurledPaperCornerPainter({
    required this.isDark,
    required this.paperColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // 1. Shadow underneath the curl
    final shadowPaint = Paint()
      ..color = Colors.black.withValues(alpha: 0.28)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3.0);

    final shadowPath = Path()
      ..moveTo(0, h)
      ..lineTo(w, 0)
      ..lineTo(w * 0.8, h * 0.8)
      ..close();
    canvas.drawPath(shadowPath, shadowPaint);

    // 2. The curled flap folded backward (slightly darker shade of paper)
    final curlPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          paperColor.withValues(alpha: 0.85),
          Color.lerp(paperColor, Colors.black, 0.18)!,
        ],
      ).createShader(Rect.fromLTWH(0, 0, w, h))
      ..style = PaintingStyle.fill;

    final curlPath = Path()
      ..moveTo(0, h)
      ..quadraticBezierTo(w * 0.45, h * 0.45, w, 0)
      ..quadraticBezierTo(w * 0.95, h * 0.65, w * 0.88, h * 0.88)
      ..quadraticBezierTo(w * 0.65, h * 0.95, 0, h)
      ..close();
    canvas.drawPath(curlPath, curlPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// =============================================================================
// 5. FLUORESCENT HIGHLIGHTER SWASH
// =============================================================================

/// Organic fluorescent marker streak painted behind text.
class HighlighterSwash extends StatelessWidget {
  final Widget child;
  final Color color;
  final double verticalPadding;

  const HighlighterSwash({
    super.key,
    required this.child,
    this.color = const Color(0xFFFF74B1),
    this.verticalPadding = 2.0,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      alignment: Alignment.center,
      children: [
        Positioned.fill(
          top: 6,
          bottom: verticalPadding,
          left: -4,
          right: -4,
          child: CustomPaint(
            painter: _HighlighterPainter(color: color),
          ),
        ),
        child,
      ],
    );
  }
}

class _HighlighterPainter extends CustomPainter {
  final Color color;
  _HighlighterPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withValues(alpha: 0.48)
      ..style = PaintingStyle.fill;

    // Organic rounded rectangle with slight hand-drawn asymmetry
    final rrect = RRect.fromRectAndCorners(
      Rect.fromLTWH(0, 0, size.width, size.height),
      topLeft: const Radius.circular(4),
      topRight: const Radius.circular(7),
      bottomLeft: const Radius.circular(6),
      bottomRight: const Radius.circular(3),
    );
    canvas.drawRRect(rrect, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// =============================================================================
// 6. HAND-DRAWN DOODLE SHAPES
// =============================================================================

/// Loose red hand-drawn circle around the active day in the calendar.
class HandDrawnDayCirclePainter extends CustomPainter {
  final Color color;
  final double strokeWidth;

  HandDrawnDayCirclePainter({
    required this.color,
    this.strokeWidth = 1.8,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    final center = Offset(size.width / 2, size.height / 2);
    final rx = (size.width / 2) - 1.5;
    final ry = (size.height / 2) - 1.0;

    final path = Path();
    // Loose hand-drawn oval that overlaps slightly at the end
    path.moveTo(center.dx + rx * 0.9, center.dy - ry * 0.3);
    path.cubicTo(
      center.dx + rx, center.dy + ry * 0.8,
      center.dx - rx * 0.8, center.dy + ry * 1.05,
      center.dx - rx * 0.95, center.dy + ry * 0.2,
    );
    path.cubicTo(
      center.dx - rx * 1.05, center.dy - ry * 0.7,
      center.dx + rx * 0.6, center.dy - ry * 1.05,
      center.dx + rx * 0.85, center.dy - ry * 0.45,
    );
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Hand-drawn doodle box for batch codes (e.g. `FA25-BCS-3-C`).
class HandDrawnBatchBoxPainter extends CustomPainter {
  final Color color;
  final double strokeWidth;

  HandDrawnBatchBoxPainter({
    required this.color,
    this.strokeWidth = 1.6,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;

    final path = Path();
    // Slightly organic wobbly rectangle
    path.moveTo(4, 2);
    path.lineTo(size.width - 3, 1);
    path.lineTo(size.width - 1.5, size.height - 3);
    path.lineTo(3, size.height - 1.5);
    path.lineTo(2, 3);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Hand-drawn squiggly wavy underline below the header date.
class HandDrawnSquiggleUnderlinePainter extends CustomPainter {
  final Color color;
  final double strokeWidth;

  HandDrawnSquiggleUnderlinePainter({
    required this.color,
    this.strokeWidth = 2.4,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    final path = Path();
    path.moveTo(0, size.height / 2);

    const waveCount = 5;
    final waveW = size.width / waveCount;
    for (int i = 0; i < waveCount; i++) {
      final startX = i * waveW;
      final midX = startX + waveW / 2;
      final endX = (i + 1) * waveW;
      path.quadraticBezierTo(
        startX + waveW / 4,
        (i % 2 == 0) ? -2 : size.height + 2,
        midX,
        size.height / 2,
      );
      path.quadraticBezierTo(
        midX + waveW / 4,
        (i % 2 == 0) ? size.height + 2 : -2,
        endX,
        size.height / 2,
      );
    }
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
