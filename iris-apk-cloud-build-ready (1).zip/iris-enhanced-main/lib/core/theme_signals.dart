import 'package:flutter/material.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import 'package:shared_preferences/shared_preferences.dart';

import 'glass.dart';
import 'tokens.dart';
import 'material_you_theme.dart';
import 'editorial_theme_tokens.dart';
import 'almanac_theme_tokens.dart';
import 'notebook_theme_tokens.dart';
import 'line_theme_tokens.dart';
import 'poster_theme_tokens.dart';
import 'package:iris/widgets/cards/vital_card.dart';

/// Supported visual styles in IRIS:
/// - [fluidGlass]: Signature liquid glass, optical refraction, specular reflections, and ambient auroras.
/// - [materialYou]: Android 14/15 Material 3 Monet design system with solid tonal surface containers, 120 FPS flat rasterization, and zero blurs.
/// - [almanac]: Theme 4 classical newspaper broadside with double horizontal hairline rules, Scotch Roman typography, and 3-column timetable.
enum IrisThemeStyle {
  fluidGlass,
  materialYou,
  almanac,
  editorialAcademic,
  notebook,
  line,
  poster,
}

/// Discrete operational glass presets for liquid theme.
enum IrisGlassLevel {
  opaque(0.0, 'Opaque Glass', 'Solid surface, zero blur & maximum contrast'),
  medium(0.5, 'Medium Glass', 'Balanced frosted refraction & clean readability'),
  maximum(1.0, 'Maximum Glass', 'Translucent luminous glass & deep refraction');

  final double value;
  final String label;
  final String description;

  const IrisGlassLevel(this.value, this.label, this.description);

  static IrisGlassLevel fromValue(double v) {
    if (v <= 0.25) return IrisGlassLevel.opaque;
    if (v >= 0.75) return IrisGlassLevel.maximum;
    return IrisGlassLevel.medium;
  }
}

/// Global signals used to toggle visual languages and themes at runtime.
class ThemeSignals {
  /// Active visual theme style — unified onto OPPO ColorOS 17 Aquamorphic Liquid Glass.
  static final ValueNotifier<IrisThemeStyle> themeStyle =
      ValueNotifier<IrisThemeStyle>(IrisThemeStyle.fluidGlass);

  static bool get isMaterialYou => false;
  static bool get isFluidGlass => true;
  static bool get isAlmanac => false;
  static bool get isEditorialAcademic => false;
  static bool get isEditorial => false;
  static bool get isNotebook => false;
  static bool get isLine => false;
  static bool get isPoster => false;

  /// Legacy flags maintained for backward compatibility.
  /// [useVitalTheme] defaults to false so [IrisThemeStyle.fluidGlass] renders genuine
  /// refractive Liquid Glass surfaces rather than opaque VitalCard containers.
  static final ValueNotifier<bool> useMinimalTheme = ValueNotifier<bool>(false);
  static final ValueNotifier<bool> useVitalTheme = ValueNotifier<bool>(false);

  /// Default Material Expressive Seed Color (Iris Monet Blue).
  static const Color defaultM3ESeedColor = Color(0xFF0061A4);

  /// Active Material Expressive Seed Color signal.
  static final ValueNotifier<Color> m3eSeedColor =
      ValueNotifier<Color>(defaultM3ESeedColor);

  /// Change and persist active seed color for Material Expressive theme.
  static Future<void> setSeedColor(Color color) async {
    m3eSeedColor.value = color;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('app_m3e_seed_color', color.toARGB32());
    } catch (_) {}
  }

  /// Global glass transparency modifier for liquid themes (0.0 to 1.0)
  static final ValueNotifier<double> glassTransparency = ValueNotifier<double>(1.0);

  /// Change and persist glass transparency.
  static Future<void> setGlassTransparency(double value) async {
    final clamped = value.clamp(0.0, 1.0);
    glassTransparency.value = clamped;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble('app_glass_transparency', clamped);
    } catch (_) {}
  }

  /// Change glass level using discrete presets (Opaque, Medium, Maximum).
  static Future<void> setGlassLevel(IrisGlassLevel level) async {
    await setGlassTransparency(level.value);
  }

  /// Current active glass level.
  static IrisGlassLevel get activeGlassLevel =>
      IrisGlassLevel.fromValue(glassTransparency.value);

  /// Change and persist active theme style (locked to ColorOS 17 Aquamorphic Liquid Glass).
  static Future<void> setThemeStyle(IrisThemeStyle style) async {
    themeStyle.value = IrisThemeStyle.fluidGlass;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('app_theme_style', IrisThemeStyle.fluidGlass.name);
    } catch (_) {}
  }

  /// Callback handler wired to global ThemeMorphController.
  static Future<void> Function({
    required IrisThemeStyle targetStyle,
    Rect? originRect,
    GlobalKey? originKey,
    BuildContext? context,
  })? morphTransitionHandler;

  /// Switch theme style with the authentic dual-theme container morphing animation.
  static Future<void> switchThemeWithMorph(
    BuildContext? context, {
    required IrisThemeStyle style,
    Rect? originRect,
    GlobalKey? originKey,
  }) async {
    if (morphTransitionHandler != null) {
      await morphTransitionHandler!(
        targetStyle: style,
        originRect: originRect,
        originKey: originKey,
        context: context,
      );
    } else {
      await setThemeStyle(style);
    }
  }

  /// Quick-toggle cycles ColorOS 17 Aquamorphic Glass refraction depth preset.
  static Future<void> toggleThemeStyle({
    BuildContext? context,
    Rect? originRect,
    GlobalKey? originKey,
  }) async {
    themeStyle.value = IrisThemeStyle.fluidGlass;
    final current = glassTransparency.value;
    final nextVal = current >= 0.85 ? 0.55 : (current >= 0.40 ? 0.0 : 1.0);
    await setGlassTransparency(nextVal);
  }

  /// Initialize theme style and seed color from local storage.
  /// Always enforces the unified ColorOS 17 Aquamorphic Liquid Glass theme.
  static Future<void> loadSavedThemeStyle() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      themeStyle.value = IrisThemeStyle.fluidGlass;
      await prefs.setString('app_theme_style', IrisThemeStyle.fluidGlass.name);

      final savedSeed = prefs.getInt('app_m3e_seed_color');
      if (savedSeed != null) {
        m3eSeedColor.value = Color(savedSeed);
      }

      final savedTransparency = prefs.getDouble('app_glass_transparency');
      if (savedTransparency != null) {
        glassTransparency.value = savedTransparency;
      }
    } catch (_) {}
  }
}

/// A polymorphic surface that renders authentic aesthetics for all 7 IRIS themes:
/// 1. Material You: Flat tonal M3 surface container with zero blur (120 FPS).
/// 2. Almanac: Newsprint surface with clean broadside hairline rules and zero blur.
/// 3. Editorial Academic: Warm parchment surface with subtle border and drop shadow.
/// 4. Notebook: Graph-paper stationery card with subtle ink rule.
/// 5. Line: Subway transit card with crisp rail outline.
/// 6. Poster: Monolithic Swiss brutalist block with hard 3D shadow.
/// 7. Fluid Glass: Genuine `liquid_glass_widgets` 1.14.2 `AdaptiveLiquidGlassLayer` with
///    superellipse geometry, specular rim reflections, and adaptive quality scaling.
class GlassSurface extends StatelessWidget {
  final lgw.LiquidGlassSettings settings;
  final double radius;
  final Widget child;
  final bool applyInLayer;
  final lgw.GlassQuality? quality;
  final BorderSide? borderSide;

  const GlassSurface({
    super.key,
    required this.settings,
    required this.radius,
    required this.child,
    this.applyInLayer = true,
    this.quality,
    this.borderSide,
  });

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, currentStyle, _) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final isCustomColor =
            settings.glassColor != Colors.transparent && settings.glassColor.a > 0;

        if (currentStyle == IrisThemeStyle.materialYou) {
          return Container(
            decoration: BoxDecoration(
              color: isCustomColor && settings.glassColor.a >= 0.85
                  ? settings.glassColor
                  : MaterialYouTheme.surfaceContainer(context),
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(
                color: MaterialYouTheme.borderStroke(context),
                width: 1.0,
              ),
            ),
            child: child,
          );
        }

        if (currentStyle == IrisThemeStyle.almanac) {
          return Container(
            decoration: BoxDecoration(
              color: AlmanacTokens.cardSurface(isDark),
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(
                color: AlmanacTokens.inkRuleSubtle(isDark),
                width: 1.0,
              ),
            ),
            child: child,
          );
        }

        if (currentStyle == IrisThemeStyle.editorialAcademic) {
          return Container(
            decoration: BoxDecoration(
              color: EditorialTokens.cardSurface(isDark),
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(
                color: EditorialTokens.cardBorder(isDark),
                width: 1.0,
              ),
              boxShadow: EditorialTokens.cardShadow(isDark),
            ),
            child: child,
          );
        }

        if (currentStyle == IrisThemeStyle.notebook) {
          return Container(
            decoration: BoxDecoration(
              color: NotebookTokens.cardSurface(isDark),
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(
                color: isDark ? const Color(0xFF2F453B) : const Color(0xFFE5E0D6),
                width: 1.0,
              ),
            ),
            child: child,
          );
        }

        if (currentStyle == IrisThemeStyle.line) {
          return Container(
            decoration: BoxDecoration(
              color: LineTokens.cardSurface(isDark),
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(
                color: LineTokens.railLine(isDark),
                width: 1.4,
              ),
            ),
            child: child,
          );
        }

        if (currentStyle == IrisThemeStyle.poster) {
          return Container(
            decoration: BoxDecoration(
              color: PosterTokens.cardSurface(isDark),
              border: Border.all(
                color: PosterTokens.inkBorder(isDark),
                width: 2.2,
              ),
              boxShadow: PosterTokens.extrudedBlockShadow(isDark, offset: 3.0),
            ),
            child: child,
          );
        }

        // Fluid Glass (IrisThemeStyle.fluidGlass) powered by liquid_glass_widgets
        return ValueListenableBuilder<double>(
          valueListenable: ThemeSignals.glassTransparency,
          builder: (context, transparency, _) {
            return ValueListenableBuilder<bool>(
              valueListenable: ThemeSignals.useMinimalTheme,
              builder: (context, useMinimal, _) {
                final isOpaque = transparency <= 0.08;
                if (useMinimal || isOpaque) {
                  return Container(
                    decoration: BoxDecoration(
                      color: isDark
                          ? IrisTokens.surfaceDarkElevated
                          : Colors.white,
                      borderRadius: BorderRadius.circular(radius),
                      border: Border.all(
                        color: borderSide?.color ??
                            (isDark
                                ? const Color(0xFF1E2433)
                                : const Color(0xFFE2E8F0)),
                        width: borderSide?.width ?? 1.0,
                      ),
                    ),
                    child: child,
                  );
                }

                // Always use full multi-pass GlassQuality.premium shader in Fluid Glass mode
                final resolvedQuality = quality ?? lgw.GlassQuality.premium;

                final effectiveSide = borderSide ??
                    (isDark
                        ? BorderSide(
                            color: Colors.white.withValues(
                              alpha: 0.16 + (0.08 * transparency),
                            ),
                            width: 1.0,
                          )
                        : BorderSide(
                            color: const Color(0xFF94A3B8).withValues(alpha: 0.42),
                            width: 1.1,
                          ));

                return ClipRRect(
                  borderRadius: BorderRadius.circular(radius),
                  child: lgw.AdaptiveLiquidGlassLayer(
                    settings: settings,
                    quality: resolvedQuality,
                    shape: IrisGlass.shape(radius, side: effectiveSide),
                    blendAmount: 0.0,
                    child: child,
                  ),
                );
              },
            );
          },
        );
      },
    );
  }
}
