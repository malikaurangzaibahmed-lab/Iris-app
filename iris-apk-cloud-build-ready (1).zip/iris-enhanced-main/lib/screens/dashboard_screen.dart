import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import 'package:shared_preferences/shared_preferences.dart';

import '../services/helpdesk_faculty_service.dart';

import '../core/animations.dart';
import '../core/format_guard.dart';
import '../core/glass.dart';
import '../core/models.dart';
import '../core/app_signals.dart';
import '../core/omni_brain.dart';
import '../core/theme_signals.dart';
import '../core/tokens.dart';
import '../core/vital_theme.dart';
import '../services/notification_service.dart';
import '../services/remote_config_service.dart';
import '../services/session_refresher_service.dart';
import '../services/ui_feedback.dart';
import '../services/widget_service.dart';
import 'package:iris/widgets/controls/batch_selector.dart';
import 'package:iris/widgets/schedule_views/exam_schedule_view.dart';
import 'package:iris/widgets/schedule_views/exam_sticky_header.dart';
import '../widgets/glass_card.dart';
import 'package:iris/widgets/effects/glass_container_transform.dart';
import '../widgets/iris_components.dart';
import 'package:iris/widgets/navigation/iris_expressive_nav_bar.dart';
import 'package:iris/widgets/navigation/almanac_nav_bar.dart';
import 'package:iris/widgets/navigation/editorial_nav_bar.dart';
import 'package:iris/widgets/navigation/notebook_nav_bar.dart';
import 'package:iris/widgets/navigation/line_nav_bar.dart';
import 'package:iris/widgets/navigation/poster_nav_bar.dart';
import 'package:iris/widgets/schedule_views/almanac_schedule_view.dart';
import 'package:iris/widgets/schedule_views/editorial_schedule_view.dart';
import 'package:iris/widgets/schedule_views/notebook_schedule_view.dart';
import 'package:iris/widgets/schedule_views/line_schedule_view.dart';
import 'package:iris/widgets/schedule_views/poster_schedule_view.dart';
import 'package:iris/widgets/navigation/liquid_glass_sticky_header.dart';
import 'package:iris/widgets/dashboard/live_class_hub_sheet.dart';
import 'package:iris/widgets/controls/m3e_color_selector.dart';
import 'package:iris/widgets/schedule_views/vacation_schedule_view.dart';
import 'package:iris/widgets/schedule_views/vacation_sticky_header.dart';
import 'package:iris/widgets/cards/contextual_timeline_card.dart';
import 'package:iris/screens/settings/about_screen.dart';
import 'package:iris/screens/settings/announcements_screen.dart';
import 'package:iris/screens/student/cgpa_calculator_screen.dart';
import 'portal_screen.dart';
import 'tools_screen.dart';
import 'package:iris/screens/academics/room_finder_screen.dart';
import '../widgets/dashboard/dashboard_widgets.dart';
import 'package:google_fonts/google_fonts.dart';
import '../core/sticker_tokens.dart';
import '../widgets/cards/sticker_card.dart';
import '../widgets/controls/doodle_speech_bubble.dart';
import '../widgets/controls/tactile_stationery.dart';
import '../widgets/effects/doodle_mascots.dart';
class Dashboard extends StatefulWidget {
  final UniversityMemory memory;
  final OmniBrain brain;
  final String batch;
  final VoidCallback onToggleTheme;
  final Future<void> Function(String mode) onSetThemeMode;
  final String currentThemeMode;
  final VoidCallback onChangeBatch;
  final String? userName;
  final ValueChanged<String>? onUserNameChanged;
  final ValueChanged<String>? onRoleChanged;
  final ValueChanged<String>? onBatchChanged;

  const Dashboard({
    required this.memory,
    required this.brain,
    required this.batch,
    required this.onToggleTheme,
    required this.onSetThemeMode,
    required this.currentThemeMode,
    required this.onChangeBatch,
    this.userName,
    this.onUserNameChanged,
    this.onRoleChanged,
    this.onBatchChanged,
    super.key,
  });

  @override
  State<Dashboard> createState() => _DashboardState();
}

// Student Dashboard

class _DashboardState extends State<Dashboard>
    with SingleTickerProviderStateMixin {
  static const String _customMakeupSessionsPrefsKey = 'custom_makeup_sessions';
  late Timer _ticker;
  String? _dismissedAnnouncementText;
  ClassSession? _previousClass;
  int? _previousProgressPercent;
  String? _previousNotificationHash;
  String? _previousWidgetHash;
  int? _overrideDayIndex;
  int _bottomNavIndex = 0;
  final Set<int> _mountedTabs = {0};
  int _studentTabSlideDirection = 1;
  List<ClassSession> _cachedSchedule = [];
  DateTime? _lastScheduleUpdate;
  int? _lastMinute;
  TemporalInsight? _cachedInsight;
  int? _lastInsightMinute;
  bool _isRefreshing = false;
  List<String> _pendingTimetableChanges = [];
  final Map<String, List<ClassSession>> _makeupReplacementHistory = {};

  final ScrollController _scrollController = ScrollController();
  final ScrollController _toolsScrollController = ScrollController();
  final ScrollController _aboutScrollController = ScrollController();
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();

  bool _isMiniMode = false;
  bool _isSearching = false;
  String _homeSearchQuery = '';
  String _toolsSearchQuery = '';
  Timer? _searchDebounceTimer;

  ScrollController? get _activeScrollController {
    switch (_bottomNavIndex) {
      case 0:
        return _scrollController;
      case 1:
        return null;
      case 2:
        return _toolsScrollController;
      case 3:
        return _aboutScrollController;
      default:
        return null;
    }
  }

  void _onScroll() {
    final ctrl = _activeScrollController;
    if (ctrl == null) return;
    final canCollapse = _bottomNavIndex == 0 || _bottomNavIndex == 2;
    final mini = canCollapse && ctrl.hasClients && ctrl.offset > 50;
    if (mini == _isMiniMode) return;
    setState(() => _isMiniMode = mini);
  }

  void _onFocusChange() {
    setState(() {});
  }

  void _updateMiniModeForActiveTab() {
    final ctrl = _activeScrollController;
    final canCollapse = _bottomNavIndex == 0 || _bottomNavIndex == 2;
    final mini =
        canCollapse && ctrl != null && ctrl.hasClients && ctrl.offset > 50;
    if (mini != _isMiniMode) {
      setState(() => _isMiniMode = mini);
    }
  }

  Future<void> _triggerBatchSelector() async {
    final result = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) =>
          BatchSelectorSheet(memory: widget.memory, selected: widget.batch),
    );

    if (result != null && result != widget.batch) {
      widget.onBatchChanged?.call(result);
      IrisHaptics.actionHeavy();
      if (mounted) {
        showIrisFrostedSnackBar(
          context,
          content: Text('Batch updated to $result'),
        );
      }
    }
  }

  bool _isMakeupSession(ClassSession session) =>
      session.id.startsWith('makeup_');

  Future<void> _loadCustomMakeupSessions() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_customMakeupSessionsPrefsKey);
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is List) {
          final existingIds = widget.memory.sessions.map((s) => s.id).toSet();
          var changed = false;

          for (final entry in decoded) {
            if (entry is! Map<String, dynamic>) continue;
            final session = ClassSession.fromJson(entry);
            if (existingIds.contains(session.id)) continue;
            widget.memory.sessions.add(session);
            existingIds.add(session.id);
            changed = true;
          }

          if (changed && mounted) {
            widget.memory.clearCaches();
            widget.brain.clearAllCaches();
            _updateScheduleCache();
            setState(() {});
          }
        }
      }

      final rawHistory = prefs.getString('makeup_replacement_history');
      if (rawHistory != null && rawHistory.isNotEmpty) {
        final decodedHistory = jsonDecode(rawHistory);
        if (decodedHistory is Map<String, dynamic>) {
          _makeupReplacementHistory.clear();
          for (final entry in decodedHistory.entries) {
            if (entry.value is List) {
              _makeupReplacementHistory[entry.key] = (entry.value as List)
                  .whereType<Map<String, dynamic>>()
                  .map((m) => ClassSession.fromJson(m))
                  .toList();
            }
          }
        }
      }
    } catch (e) {
      debugPrint('⚠️ Failed to load custom makeup sessions: $e');
    }
  }

  Future<void> _checkPendingTimetableChanges() async {
    final prefs = await SharedPreferences.getInstance();
    final promotedFrom = prefs.getString('promoted_from_batch');
    if (promotedFrom != null && promotedFrom.isNotEmpty) {
      await prefs.remove('promoted_from_batch');
      if (mounted) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) {
            showIrisFrostedSnackBar(
              context,
              tint: const Color(0xFF10B981),
              content: Text(
                '🎉 Welcome to your new semester! Promoted to ${widget.batch} (from $promotedFrom)',
              ),
            );
          }
        });
      }
    }

    final raw = prefs.getString('ota_timetable_changes');
    if (raw != null && raw.isNotEmpty) {
      try {
        final List<dynamic> decoded = jsonDecode(raw);
        if (mounted && decoded.isNotEmpty) {
          setState(() {
            _pendingTimetableChanges = List<String>.from(decoded);
          });
        }
      } catch (_) {}
    }
  }

  Future<void> _clearPendingTimetableChanges() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('ota_timetable_changes');
    if (mounted) {
      setState(() {
        _pendingTimetableChanges = [];
      });
    }
  }

  Future<void> _persistCustomMakeupSessions() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final custom = widget.memory.sessions
          .where(_isMakeupSession)
          .map((s) => s.toJson())
          .toList();
      await prefs.setString(_customMakeupSessionsPrefsKey, jsonEncode(custom));

      final serializedHistory = _makeupReplacementHistory.map(
        (key, list) => MapEntry(key, list.map((s) => s.toJson()).toList()),
      );
      await prefs.setString(
        'makeup_replacement_history',
        jsonEncode(serializedHistory),
      );
    } catch (e) {
      debugPrint('⚠️ Failed to persist custom makeup sessions: $e');
    }
  }

  bool _sessionsOverlap(ClassSession a, ClassSession b) {
    if (a.dayIndex != b.dayIndex) return false;
    return a.safeStartVal < b.safeEndVal && b.safeStartVal < a.safeEndVal;
  }

  bool _sameSessionSignature(ClassSession a, ClassSession b) {
    return a.batchKey.batch == b.batchKey.batch &&
        a.dayIndex == b.dayIndex &&
        a.startTime == b.startTime &&
        a.endTime == b.endTime &&
        a.teacher.trim().toLowerCase() == b.teacher.trim().toLowerCase() &&
        a.subject.trim().toLowerCase() == b.subject.trim().toLowerCase();
  }

  Future<void> _addMakeupSession(ClassSession session) async {
    if (session.batchKey.batch != widget.batch) {
      if (!mounted) return;
      showIrisFrostedSnackBar(
        context,
        dedupeKey: 'makeup_different_batch',
        content: Text('This makeup class belongs to a different batch.'),
      );
      return;
    }

    final duplicate = widget.memory.sessions.any(
      (s) => s.id == session.id || _sameSessionSignature(s, session),
    );
    if (duplicate) {
      if (!mounted) return;
      showIrisFrostedSnackBar(
        context,
        dedupeKey: 'makeup_duplicate',
        content: Text('That makeup class is already in your timeline.'),
      );
      return;
    }

    final batchSessions = widget.memory.sessions
        .where((s) => s.batchKey.batch == widget.batch)
        .toList();

    final overlaps = batchSessions
        .where((s) => _sessionsOverlap(s, session))
        .toList();
    final regularConflict = overlaps
        .where((s) => !_isMakeupSession(s))
        .toList();
    if (regularConflict.isNotEmpty) {
      final conflict = regularConflict.first;
      if (!mounted) return;
      showIrisFrostedSnackBar(
        context,
        dedupeKey: 'makeup_conflict_${conflict.id}',
        content: Text(
          'Conflicts with ${conflict.subject} (${conflict.startTime}-${conflict.endTime}). Pick another slot.',
        ),
      );
      return;
    }

    // Intelligent behavior: replace overlapping makeup slots and preserve history for safe restore.
    final makeupOverlaps = overlaps.where(_isMakeupSession).toList();
    if (makeupOverlaps.isNotEmpty) {
      final overlapIds = makeupOverlaps.map((s) => s.id).toSet();
      final removedSnapshots = <ClassSession>[];

      for (final replaced in makeupOverlaps) {
        removedSnapshots.add(replaced);
        final nestedHistory =
            _makeupReplacementHistory.remove(replaced.id) ??
            const <ClassSession>[];
        removedSnapshots.addAll(nestedHistory);
      }

      final unique = <String, ClassSession>{};
      for (final item in removedSnapshots) {
        unique[item.id] = item;
      }
      _makeupReplacementHistory[session.id] = unique.values.toList();

      widget.memory.sessions.removeWhere((s) => overlapIds.contains(s.id));
    }

    widget.memory.sessions.add(session);
    widget.memory.clearCaches();
    widget.brain.clearAllCaches();
    await _persistCustomMakeupSessions();

    if (!mounted) return;
    _updateScheduleCache();
    setState(() {});
    _updateWidgetIfNeeded();
    _updatePersistentNotificationIfNeeded();

    showIrisFrostedSnackBar(
      context,
      dedupeKey: 'makeup_added_${session.id}',
      content: Text(
        makeupOverlaps.isNotEmpty
            ? 'Added ${session.subject} (${session.startTime}-${session.endTime}) and replaced ${makeupOverlaps.length} overlapping makeup slot${makeupOverlaps.length == 1 ? '' : 's'}.'
            : 'Added makeup class: ${session.subject} (${session.startTime}-${session.endTime})',
      ),
    );
  }

  Future<void> _removeMakeupSession(ClassSession session) async {
    if (!_isMakeupSession(session)) return;

    final restoreCandidates =
        _makeupReplacementHistory.remove(session.id) ?? const <ClassSession>[];

    final before = widget.memory.sessions.length;
    widget.memory.sessions.removeWhere((s) => s.id == session.id);
    final removed = before - widget.memory.sessions.length;
    if (removed <= 0) return;

    var restored = 0;
    for (final candidate in restoreCandidates) {
      final duplicate = widget.memory.sessions.any(
        (s) => s.id == candidate.id || _sameSessionSignature(s, candidate),
      );
      if (duplicate) continue;

      final overlap = widget.memory.sessions.any(
        (s) =>
            s.batchKey.batch == widget.batch && _sessionsOverlap(s, candidate),
      );
      if (overlap) continue;

      widget.memory.sessions.add(candidate);
      restored += 1;
    }

    widget.memory.clearCaches();
    widget.brain.clearAllCaches();
    await _persistCustomMakeupSessions();

    if (!mounted) return;
    _updateScheduleCache();
    setState(() {});
    _updateWidgetIfNeeded();
    _updatePersistentNotificationIfNeeded();

    showIrisFrostedSnackBar(
      context,
      dedupeKey: 'makeup_removed_${session.id}',
      content: Text(
        restored > 0
            ? 'Removed makeup class. Restored $restored previously replaced slot${restored == 1 ? '' : 's'}.'
            : 'Removed makeup class from timeline.',
      ),
    );
  }

  Future<void> _confirmAndRemoveMakeupSession(ClassSession session) async {
    if (!_isMakeupSession(session) || !mounted) return;
    final now = DateTime.now();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isLive = session.isLive(now);
    final currentTime = now.hour + (now.minute / 60.0);
    final minutesToStart = ((session.safeStartVal - currentTime) * 60).round();

    final isM3 = ThemeSignals.isMaterialYou;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) {
        final dialog = AlertDialog(
          backgroundColor: isM3
              ? null
              : (isDark ? const Color(0xFF111827) : Colors.white).withValues(
                  alpha: isDark ? 0.88 : 0.92,
                ),
          surfaceTintColor: Colors.transparent,
          shape: isM3
              ? null
              : RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                  side: BorderSide(
                    color: (isDark ? Colors.white : Colors.black).withValues(
                      alpha: 0.12,
                    ),
                  ),
                ),
          title: const Text('Remove makeup class?'),
          content: Text(
            isLive
                ? 'This class is live right now. Remove it from your timeline?'
                : minutesToStart >= 0 && minutesToStart <= 15
                ? 'This class starts in $minutesToStart min. Remove it anyway?'
                : 'Remove ${session.subject} (${session.startTime}-${session.endTime}) from your timeline?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('Cancel'),
            ),
            isM3
                ? FilledButton(
                    onPressed: () => Navigator.of(ctx).pop(true),
                    style: FilledButton.styleFrom(
                      backgroundColor: Theme.of(ctx).colorScheme.error,
                      foregroundColor: Theme.of(ctx).colorScheme.onError,
                    ),
                    child: const Text('Remove'),
                  )
                : ElevatedButton(
                    onPressed: () => Navigator.of(ctx).pop(true),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: IrisTokens.error,
                    ),
                    child: const Text('Remove'),
                  ),
          ],
        );

        if (isM3) return dialog;

        return GlassSurface(
          settings: IrisGlass.settings(
            ctx,
            blur: 16,
            ambientStrength: 0.70,
            lightAngle: 0.15 * math.pi,
            thickness: 15,
            glassColor: Colors.black.withValues(alpha: 0.05),
            minBlur: 10,
            minThickness: 12,
          ),
          radius: 20,
          child: dialog,
        );
      },
    );

    if (confirm == true) {
      await _removeMakeupSession(session);
    }
  }

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
    _toolsScrollController.addListener(_onScroll);
    _aboutScrollController.addListener(_onScroll);
    _searchFocusNode.addListener(_onFocusChange);
    _loadDismissedAnnouncement();
    _checkPendingTimetableChanges();

    // Start remote Firestore listener for real-time announcements, modes & OTA timetable upgrades
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        RemoteConfigService.startRemoteListener(context);

        // Background session warming on startup
        unawaited(
          SessionRefresherService.warmSession(
            'swl-sis.comsats.edu.pk',
            'student',
          ),
        );
        unawaited(HelpdeskFacultyService().fetchOfflineOnly());
      }
    });
    _updateScheduleCache();
    _loadCustomMakeupSessions();
    _lastMinute = DateTime.now().minute;

    RemoteConfigService.activeAcademicPeriod.addListener(_onGlobalAcademicStateChanged);
    RemoteConfigService.midtermExams.addListener(_onGlobalAcademicStateChanged);
    RemoteConfigService.finalExams.addListener(_onGlobalAcademicStateChanged);
    RemoteConfigService.lastTimetableUpdateTime.addListener(_onGlobalAcademicStateChanged);
    AppSignals.stateRevision.addListener(_onGlobalAcademicStateChanged);

    // Schedule class reminders for today
    _scheduleClassReminders();

    // Start foreground service if notifications enabled
    _startForegroundServiceIfNeeded();

    _ticker = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) {
        final now = DateTime.now();
        final current = widget.brain.getCurrentClass(widget.batch, now);
        final minuteChanged = _lastMinute != now.minute;
        if (current != _previousClass || minuteChanged) {
          setState(() {
            _lastMinute = now.minute;
            _previousClass = current;
          });
          // Update notifications and widget only when the visible schedule state changes.
          unawaited(_updatePersistentNotificationIfNeeded());
          unawaited(_updateWidgetIfNeeded());
        }
      }
    });
    unawaited(_updatePersistentNotificationIfNeeded());
    unawaited(_updateWidgetIfNeeded());
  }

  Future<void> _startForegroundServiceIfNeeded() async {
    final prefs = await SharedPreferences.getInstance();

    // Keep the foreground service aligned with the active batch without
    // overwriting the app persona.
    await prefs.setString('student_batch', widget.batch);

    final notificationEnabled =
        prefs.getBool('persistent_notification_enabled') ?? false;

    if (notificationEnabled) {
      // Always restart to ensure correct role data
      await _startForegroundService();
    } else {
      // If notifications disabled, stop any running service
      if (await FlutterForegroundTask.isRunningService) {
        await FlutterForegroundTask.stopService();
      }
    }
  }

  Future<void> _startForegroundService() async {
    final isRunning = await FlutterForegroundTask.isRunningService;

    // Store timetable data for TaskHandler to use
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('student_batch', widget.batch);
    if (AppSignals.activeRole.value == 'student') {
      await prefs.setString('user_role', 'student');
    }

    // Serialize timetable data
    final timetableData = {
      'sessions': widget.memory
          .activeSessions()
          .map((s) => s.toJson())
          .toList(),
    };
    await prefs.setString('timetable_data', jsonEncode(timetableData));

    // Calculate initial notification
    final now = DateTime.now();
    final current = widget.brain.getCurrentClass(widget.batch, now);
    final next = widget.brain.getNextClass(widget.batch, now);
    final currentTime = now.hour + (now.minute / 60.0);
    final dayIndex = now.weekday;

    final todayAll = widget.brain
        .getMergedDaySchedule(widget.batch, dayIndex);

    String notifTitle = 'IRIS Class Tracker';
    String notifBody = 'Keeping your class schedule handy';

    if (current != null && current.isLive(now)) {
      final duration = LectureDuration.getActualDuration(current);
      final actualEndTime = LectureDuration.getActualEndTime(current);
      final progress = ((currentTime - current.safeStartVal) / duration).clamp(
        0.0,
        1.0,
      );
      final progressPercent = (progress * 100).toInt();

      final minutesRemaining = ((actualEndTime - currentTime) * 60)
          .round()
          .clamp(0, (duration * 60).round());
      final hoursRemaining = minutesRemaining ~/ 60;
      final minsRemaining = minutesRemaining % 60;

      String timeLeft = hoursRemaining > 0
          ? '${hoursRemaining}h ${minsRemaining}m left'
          : minsRemaining > 0
          ? '${minsRemaining}m left'
          : 'Ending now';

      final remaining = todayAll
          .where((s) => s.safeStartVal > currentTime)
          .length;
      final classCount = remaining > 0
          ? ' • $remaining more today'
          : ' • Last session today';

      final cleanSub = current.subject.replaceAll('[EXAM]', '').trim();
      notifTitle = '🎓 $cleanSub • $progressPercent%';
      notifBody =
          '⏱️ $timeLeft (${current.startTime} - ${current.endTime})$classCount\n📍 ${current.room} • ${current.teacher}';
    } else if (next != null) {
      int daysAhead = 0;
      if (next.dayIndex != dayIndex) {
        daysAhead = (next.dayIndex - dayIndex + 7) % 7;
        if (daysAhead == 0) daysAhead = 7;
      }
      final totalMinutesUntil = daysAhead > 0
          ? ((24.0 - currentTime) * 60 +
                    (daysAhead - 1) * 24 * 60 +
                    next.safeStartVal * 60)
                .round()
          : ((next.safeStartVal - currentTime) * 60).round();
      final hoursUntil = totalMinutesUntil ~/ 60;
      final minsUntil = totalMinutesUntil % 60;

      String timeUntil = '';
      String emoji = '📌';
      if (daysAhead > 0) {
        const dayNames = ['', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        final nextDayName = dayNames[next.dayIndex];
        final startHour = next.safeStartVal.floor();
        final startMin = ((next.safeStartVal - startHour) * 60).round();
        final displayHour = startHour > 12 ? startHour - 12 : startHour;
        final amPm = startHour >= 12 ? 'PM' : 'AM';
        timeUntil =
            '$nextDayName $displayHour:${startMin.toString().padLeft(2, '0')} $amPm';
        emoji = '📅';
      } else if (hoursUntil > 0) {
        timeUntil = '${hoursUntil}h ${minsUntil}m';
        emoji = '⏳';
      } else if (minsUntil > 10) {
        timeUntil = '$minsUntil min';
        emoji = '⏳';
      } else if (minsUntil > 0) {
        timeUntil = '$minsUntil min';
        emoji = '⚡';
      } else {
        timeUntil = 'now';
        emoji = '🔔';
      }

      final remainingToday = todayAll
          .where((s) => s.safeStartVal > currentTime)
          .length;

      String classInfo;
      if (daysAhead > 0) {
        classInfo = 'Done for today ✓';
      } else if (remainingToday > 1) {
        classInfo = '$remainingToday classes left';
      } else {
        classInfo = 'Last class today';
      }

      notifTitle = '$emoji ${next.subject} in $timeUntil';
      notifBody = '$classInfo\n📍 ${next.room} · ${next.teacher}';
    } else {
      final weekday = now.weekday;
      if (weekday == 6 || weekday == 7) {
        notifTitle = '🎉 Weekend Mode';
        notifBody = 'No classes — enjoy your break!';
      } else {
        notifTitle = '✓ All done for today';
        notifBody = 'No more classes scheduled';
      }
    }

    await prefs.setString('notification_title', notifTitle);
    await prefs.setString('notification_body', notifBody);

    if (isRunning) {
      await FlutterForegroundTask.updateService(
        notificationTitle: notifTitle,
        notificationText: notifBody,
        notificationButtons: const [
          NotificationButton(id: 'open', text: 'Open IRIS'),
        ],
      );
    } else {
      await FlutterForegroundTask.startService(
        serviceId: 256,
        notificationTitle: notifTitle,
        notificationText: notifBody,
        notificationIcon: null,
        notificationButtons: const [
          NotificationButton(id: 'open', text: 'Open IRIS'),
        ],
        callback: startClassNotificationTask,
      );
    }
  }

  @override
  void didUpdateWidget(Dashboard oldWidget) {
    super.didUpdateWidget(oldWidget);

    // Detect batch change and refresh everything
    if (widget.batch != oldWidget.batch || widget.userName != oldWidget.userName) {
      _cachedInsight = null;
      _updateScheduleCache();
      _previousClass = null;
      // Force rebuild of timeline cards and UI
      setState(() {});
      _scheduleClassReminders();
      _updatePersistentNotificationIfNeeded();
      _updateWidgetIfNeeded();
    }
  }

  String _formatDateLabel(DateTime now) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    final dayName = days[(now.weekday - 1) % 7];
    final monthName = months[(now.month - 1).clamp(0, 11)];
    return '$dayName, $monthName ${now.day}';
  }

  void _updateScheduleCache() {
    final now = DateTime.now();
    _cachedSchedule = _buildTimelineSchedule(now);
    _lastScheduleUpdate = now;
  }

  void _scheduleClassReminders() {
    try {
      SharedPreferences.getInstance().then((prefs) {
        final remindersEnabled =
            prefs.getBool('lecture_reminders_enabled') ?? false;
        if (!remindersEnabled) {
          NotificationService().cancelScheduledClassReminders();
          return;
        }

        // Get today's classes for the student's batch
        final todayClasses = widget.brain
            .getMergedDaySchedule(widget.batch, DateTime.now().weekday);

        if (todayClasses.isNotEmpty) {
          NotificationService().scheduleClassReminders(todayClasses);
        }
      });
    } catch (e) {
      // Silently handle scheduling errors - non-critical feature
      debugPrint('⚠️ Failed to schedule class reminders: $e');
    }
  }

  void _onGlobalAcademicStateChanged() {
    if (!mounted) return;
    _cachedInsight = null;
    widget.memory.clearCaches();
    widget.brain.clearAllCaches();
    _updateScheduleCache();
    setState(() {});
    unawaited(_updatePersistentNotificationIfNeeded());
    unawaited(_updateWidgetIfNeeded());
  }

  @override
  void dispose() {
    RemoteConfigService.activeAcademicPeriod.removeListener(_onGlobalAcademicStateChanged);
    RemoteConfigService.midtermExams.removeListener(_onGlobalAcademicStateChanged);
    RemoteConfigService.finalExams.removeListener(_onGlobalAcademicStateChanged);
    RemoteConfigService.lastTimetableUpdateTime.removeListener(_onGlobalAcademicStateChanged);
    AppSignals.stateRevision.removeListener(_onGlobalAcademicStateChanged);
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    _toolsScrollController.removeListener(_onScroll);
    _toolsScrollController.dispose();
    _aboutScrollController.removeListener(_onScroll);
    _aboutScrollController.dispose();
    _searchController.dispose();
    _searchFocusNode.removeListener(_onFocusChange);
    _searchFocusNode.dispose();
    _searchDebounceTimer?.cancel();
    _ticker.cancel();
    // Don't stop foreground service here - it should persist
    super.dispose();
  }

  Future<void> _handleRefresh() async {
    if (_isRefreshing) return;
    IrisHaptics.refreshStart();

    setState(() => _isRefreshing = true);

    // Background session warming on pull-to-refresh
    unawaited(
      SessionRefresherService.warmSession('swl-sis.comsats.edu.pk', 'student'),
    );

    // Simulate data refresh delay
    await Future.delayed(const Duration(milliseconds: 800));

    // Refresh schedule cache
    _updateScheduleCache();

    // Check for pending timetable changes
    await _checkPendingTimetableChanges();

    // Update widget and notifications
    _updateWidgetIfNeeded();
    _updatePersistentNotificationIfNeeded();

    setState(() => _isRefreshing = false);
    IrisHaptics.refreshSuccess();

    // Show success feedback
    if (mounted) {
      showIrisFrostedSnackBar(
        context,
        dedupeKey: 'schedule_refreshed_faculty',
        content: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.white, size: 20),
            SizedBox(width: 12),
            Text(
              'Schedule refreshed',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
          ],
        ),
        tint: IrisTokens.success,
        duration: const Duration(seconds: 2),
      );
    }
  }

  Future<void> _updatePersistentNotificationIfNeeded() async {
    final now = DateTime.now();
    final prefs = await SharedPreferences.getInstance();
    final notificationEnabled =
        prefs.getBool('persistent_notification_enabled') ?? false;

    if (!notificationEnabled) return;

    // Check current academic period for vacation
    final academicPeriod = RemoteConfigService.activeAcademicPeriod.value;
    if (academicPeriod == 'vacation' || academicPeriod == 'break') {
      const notifTitle = '🏖️ Vacation Mode Active';
      const notifBody = '🌴 Campus in recess — Enjoy your break!';

      if (_previousNotificationHash == 'vacation_$notifTitle') return;
      _previousNotificationHash = 'vacation_$notifTitle';

      try {
        await prefs.setString('notification_title', notifTitle);
        await prefs.setString('notification_body', notifBody);

        if (await FlutterForegroundTask.isRunningService) {
          await FlutterForegroundTask.updateService(
            notificationTitle: notifTitle,
            notificationText: notifBody,
            notificationButtons: const [
              NotificationButton(id: 'open', text: 'Open IRIS'),
            ],
          );
        }
      } catch (e) {
        debugPrint('❌ Vacation notification update failed: $e');
      }
      return;
    }

    // Check current academic period for exams
    if (academicPeriod == 'midterms' || academicPeriod == 'finals') {
      final examInsight = widget.brain.buildExamTemporalInsight(
        widget.batch,
        now,
        academicPeriod,
      );
      final examLabel = academicPeriod == 'midterms'
          ? 'Midterm Exam'
          : 'Final Exam';
      final notifTitle =
          '📝 ${examInsight.subject} • ${examInsight.timeInfo ?? "SCHEDULED"}';
      final venue = (examInsight.room != null && examInsight.room!.isNotEmpty)
          ? examInsight.room!
          : "Academic Block";
      final notifBody = '🏛️ Venue: $venue · $examLabel';

      if (_previousNotificationHash == '$notifTitle|$notifBody') return;
      _previousNotificationHash = '$notifTitle|$notifBody';

      try {
        await prefs.setString('notification_title', notifTitle);
        await prefs.setString('notification_body', notifBody);

        if (await FlutterForegroundTask.isRunningService) {
          await FlutterForegroundTask.updateService(
            notificationTitle: notifTitle,
            notificationText: notifBody,
            notificationButtons: const [
              NotificationButton(id: 'open', text: 'Open IRIS'),
            ],
          );
        }
      } catch (e) {
        debugPrint('❌ Persistent notification update failed: $e');
      }
      return;
    }

    // Health check: restart service if it should be running but isn't
    final isRunning = await FlutterForegroundTask.isRunningService;
    if (!isRunning) {
      debugPrint('⚠️ Service not running but should be - restarting...');
      await _startForegroundService();
      return; // Service will update on its own after start
    }

    final current = widget.brain.getCurrentClass(widget.batch, now);
    final next = widget.brain.getNextClass(widget.batch, now);
    final currentTime = now.hour + (now.minute / 60.0);
    final dayIndex = now.weekday;

    // Calculate state hash to determine if update is needed
    String generateStateHash() {
      if (current != null && current.isLive(now)) {
        final duration = LectureDuration.getActualDuration(current);
        final progress = ((currentTime - current.safeStartVal) / duration)
            .clamp(0.0, 1.0);
        final progressPercent = (progress * 100).toInt();
        return 'live_${current.subject}_$progressPercent';
      } else if (next != null) {
        return 'next_${next.subject}_${next.safeStartVal}';
      }
      return 'idle';
    }

    final currentHash = generateStateHash();

    // Only update if state changed significantly (class changed or progress milestone reached)
    if (_previousNotificationHash == currentHash && current == _previousClass) {
      return; // No meaningful change, skip update
    }

    _previousNotificationHash = currentHash;

    final todayAll = widget.brain
        .getMergedDaySchedule(widget.batch, dayIndex);

    try {
      String notifTitle = '';
      String notifBody = '';

      if (current != null && current.isLive(now)) {
        final duration = LectureDuration.getActualDuration(current);
        final actualEndTime = LectureDuration.getActualEndTime(current);
        final progress = ((currentTime - current.safeStartVal) / duration)
            .clamp(0.0, 1.0);
        final progressPercent = (progress * 100).toInt();

        final minutesRemaining = ((actualEndTime - currentTime) * 60)
            .round()
            .clamp(0, (duration * 60).round());
        final hoursRemaining = minutesRemaining ~/ 60;
        final minsRemaining = minutesRemaining % 60;

        String timeLeft = hoursRemaining > 0
            ? '${hoursRemaining}h ${minsRemaining}m left'
            : minsRemaining > 0
            ? '${minsRemaining}m left'
            : 'Ending now';

        final remaining = todayAll
            .where((s) => s.safeStartVal > currentTime)
            .length;
        final classCount = remaining > 0
            ? ' • $remaining more today'
            : ' • Last session today';

        final cleanSub = current.subject.replaceAll('[EXAM]', '').trim();
        notifTitle = '🎓 $cleanSub • $progressPercent%';
        notifBody =
            '⏱️ $timeLeft (${current.startTime} - ${current.endTime})$classCount\n📍 ${current.room} • ${current.teacher}';
      } else if (next != null) {
        int daysAhead = 0;
        if (next.dayIndex != dayIndex) {
          daysAhead = (next.dayIndex - dayIndex + 7) % 7;
          if (daysAhead == 0) daysAhead = 7;
        }
        final totalMinutesUntil = daysAhead > 0
            ? ((24.0 - currentTime) * 60 +
                      (daysAhead - 1) * 24 * 60 +
                      next.safeStartVal * 60)
                  .round()
            : ((next.safeStartVal - currentTime) * 60).round();
        final hoursUntil = totalMinutesUntil ~/ 60;
        final minsUntil = totalMinutesUntil % 60;

        String timeUntil = '';
        String emoji = '📌';
        if (daysAhead > 0) {
          const dayNames = [
            '',
            'Mon',
            'Tue',
            'Wed',
            'Thu',
            'Fri',
            'Sat',
            'Sun',
          ];
          final nextDayName = dayNames[next.dayIndex];
          final startHour = next.safeStartVal.floor();
          final startMin = ((next.safeStartVal - startHour) * 60).round();
          final displayHour = startHour > 12 ? startHour - 12 : startHour;
          final amPm = startHour >= 12 ? 'PM' : 'AM';
          timeUntil =
              '$nextDayName $displayHour:${startMin.toString().padLeft(2, '0')} $amPm';
          emoji = '📅';
        } else if (hoursUntil > 0) {
          timeUntil = '${hoursUntil}h ${minsUntil}m';
          emoji = '⏳';
        } else if (minsUntil > 10) {
          timeUntil = '$minsUntil min';
          emoji = '⏳';
        } else if (minsUntil > 0) {
          timeUntil = '$minsUntil min';
          emoji = '⚡';
        } else {
          timeUntil = 'now';
          emoji = '🔔';
        }

        final remainingToday = todayAll
            .where((s) => s.safeStartVal > currentTime)
            .length;

        // Break info
        String breakInfo = '';
        if (daysAhead == 0) {
          final prevClasses = todayAll
              .where((s) => s.safeEndVal <= currentTime)
              .toList();
          if (prevClasses.isNotEmpty) {
            prevClasses.sort((a, b) => b.safeEndVal.compareTo(a.safeEndVal));
            final breakMins =
                ((next.safeStartVal - prevClasses.first.safeEndVal) * 60)
                    .round();
            if (breakMins > 0 && breakMins < 180) {
              breakInfo = ' · ${breakMins}m break';
            }
          }
        }

        String classInfo;
        if (daysAhead > 0) {
          classInfo = 'Done for today ✓';
        } else if (remainingToday > 1) {
          classInfo = '$remainingToday classes left';
        } else {
          classInfo = 'Last class today';
        }

        notifTitle = '$emoji ${next.subject} in $timeUntil';
        notifBody = '$classInfo$breakInfo\n📍 ${next.room} · ${next.teacher}';
      } else {
        final weekday = now.weekday;
        if (weekday == 6 || weekday == 7) {
          notifTitle = '🎉 Weekend Mode';
          notifBody = 'No classes — enjoy your break!';
        } else {
          notifTitle = '✓ All done for today';
          notifBody = 'No more classes scheduled';
        }
      }

      // Store notification content for foreground service to read
      await prefs.setString('notification_title', notifTitle);
      await prefs.setString('notification_body', notifBody);

      // Update foreground service notification if running
      if (await FlutterForegroundTask.isRunningService) {
        await FlutterForegroundTask.updateService(
          notificationTitle: notifTitle,
          notificationText: notifBody,
          notificationButtons: [
            NotificationButton(id: 'open', text: 'Open IRIS'),
          ],
        );
      }
    } catch (e) {
      debugPrint('❌ Persistent notification update failed: $e');
    }
  }

  /// Update home widget with temporal insight data
  Future<void> _updateWidgetIfNeeded() async {
    try {
      final now = DateTime.now();

      // Check current academic period
      final academicPeriod = RemoteConfigService.activeAcademicPeriod.value;
      if (academicPeriod == 'vacation' || academicPeriod == 'break') {
        final vacationInsight = widget.brain.buildVacationTemporalInsight(
          widget.batch,
          now,
        );

        final currentHash =
            'vacation_${academicPeriod}_${vacationInsight.subject}_${vacationInsight.timeInfo}';
        if (_previousWidgetHash == currentHash) {
          return;
        }
        _previousWidgetHash = currentHash;
        _previousProgressPercent = 0;

        await WidgetService.updateWidgetWithInsight(
          headline: vacationInsight.headline,
          subline: vacationInsight.subline,
          timeInfo: vacationInsight.timeInfo ?? 'RECHARGE & UNWIND',
          teacherInfo: '',
          isLive: false,
          isUrgent: false,
          progressPercentage: 0,
          subject: vacationInsight.subject,
          room: vacationInsight.room,
          startTime: vacationInsight.startTime,
          activeMode: 'vacation',
          activeRole: 'student',
          batch: widget.batch,
        );
        return;
      }

      if (academicPeriod == 'midterms' || academicPeriod == 'finals') {
        final examInsight = widget.brain.buildExamTemporalInsight(
          widget.batch,
          now,
          academicPeriod,
        );

        final currentHash =
            'exam_${academicPeriod}_${examInsight.subject}_${examInsight.timeInfo}';
        if (_previousWidgetHash == currentHash) {
          return;
        }
        _previousWidgetHash = currentHash;
        _previousProgressPercent = 0;

        await WidgetService.updateWidgetWithInsight(
          headline: examInsight.headline,
          subline: examInsight.subline,
          timeInfo: examInsight.timeInfo ?? 'ACTIVE',
          teacherInfo: '',
          isLive: examInsight.isLive,
          isUrgent: false,
          progressPercentage: 0,
          subject: examInsight.subject,
          room: examInsight.room,
          startTime: examInsight.startTime,
          activeMode: academicPeriod,
          activeRole: 'student',
          batch: widget.batch,
        );
        return;
      }

      final insight = widget.brain.buildTemporalInsight(widget.batch, now);

      // Calculate progress percentage if live
      int progressPercent = 0;
      if (insight.isLive) {
        final current = widget.brain.getCurrentClass(widget.batch, now);
        if (current != null) {
          final currentTime = now.hour + (now.minute / 60.0);
          final duration = LectureDuration.getActualDuration(current);
          final progress = ((currentTime - current.safeStartVal) / duration)
              .clamp(0.0, 1.0);
          progressPercent = (progress * 100).toInt();
        }
      }

      // Generate state hash to determine if widget update is needed
      String generateWidgetHash() {
        return '${academicPeriod}_${insight.headline}_${insight.subject}_${insight.isLive}_${progressPercent}_${insight.isUrgent}';
      }

      final currentHash = generateWidgetHash();

      // Only update widget if state changed (smarter updates to save battery)
      if (_previousWidgetHash == currentHash &&
          progressPercent == _previousProgressPercent) {
        return; // No meaningful change, skip widget update
      }

      _previousWidgetHash = currentHash;
      _previousProgressPercent = progressPercent;

      // Update widget with insight data
      await WidgetService.updateWidgetWithInsight(
        headline: insight.headline,
        subline: insight.subline,
        timeInfo: insight.timeInfo ?? '--',
        teacherInfo: insight.teacherInfo ?? '',
        isLive: insight.isLive,
        isUrgent: insight.isUrgent,
        progressPercentage: progressPercent,
        subject: insight.subject,
        room: insight.room,
        startTime: insight.startTime,
        activeMode: academicPeriod,
        activeRole: 'student',
        batch: widget.batch,
      );
    } catch (e) {
      debugPrint('⚠️ Widget update failed: $e');
    }
  }

  void _onBottomNavTap(int index) {
    if (!mounted) return;
    final previousIndex = _bottomNavIndex;
    if (index == previousIndex) {
      unawaited(IrisHaptics.navTransition(from: previousIndex, to: index));
      return;
    }

    // Fire navigation feedback unawaited for zero latency
    unawaited(IrisHaptics.navTransition(from: previousIndex, to: index));
    unawaited(IrisHaptics.destinationOpen(destination: index));

    setState(() {
      _studentTabSlideDirection = index > previousIndex ? 1 : -1;
      _bottomNavIndex = index;
      _mountedTabs.add(index);
      _isSearching = false;
      _searchController.clear();
      _homeSearchQuery = '';
      _toolsSearchQuery = '';
    });
    _updateMiniModeForActiveTab();

    if (index == 0) {
      _updateScheduleCache();
    }
  }

  Future<void> _loadDismissedAnnouncement() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        _dismissedAnnouncementText = prefs.getString(
          'iris_dismissed_announcement',
        );
      });
    }
  }

  Future<void> _dismissAnnouncement(String text) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('iris_dismissed_announcement', text);
    if (mounted) {
      setState(() {
        _dismissedAnnouncementText = text;
      });
    }
    IrisHaptics.actionSoft();
  }

  Widget _buildAnnouncementBanner(
    BuildContext context,
    Map<String, dynamic> announcement,
  ) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return CampusAnnouncementBanner(
      announcement: announcement,
      isDark: isDark,
      dismissedAnnouncementText: _dismissedAnnouncementText,
      onDismiss: _dismissAnnouncement,
    );
  }

  Widget _buildPersistentAnnouncementCard(BuildContext context, bool isDark) {
    return ValueListenableBuilder<Map<String, dynamic>?>(
      valueListenable: RemoteConfigService.liveAnnouncement,
      builder: (context, announcement, _) {
        return ValueListenableBuilder<List<Map<String, dynamic>>>(
          valueListenable: RemoteConfigService.liveNotices,
          builder: (context, adminNotices, _) {
            final card = _buildRealNoticeboardCard(
              context,
              isDark,
              announcement: announcement,
              adminNotices: adminNotices,
            );
            if (card is SizedBox &&
                (card.width == null || card.width == 0.0) &&
                (card.height == null || card.height == 0.0)) {
              return const SliverToBoxAdapter(child: SizedBox.shrink());
            }
            return SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
              sliver: SliverToBoxAdapter(child: card),
            );
          },
        );
      },
    );
  }

  Widget _buildRealNoticeboardCard(
    BuildContext context,
    bool isDark, {
    Map<String, dynamic>? announcement,
    List<Map<String, dynamic>> adminNotices = const [],
  }) {
    return CampusNoticeboardCard(
      announcement: announcement,
      adminNotices: adminNotices,
      isDark: isDark,
      dismissedAnnouncementText: _dismissedAnnouncementText,
    );
  }

  void _showAboutContextSheet(bool isDark) {
    AboutContextSheet.show(context, isDark);
  }

  Widget _buildStudentBottomNavBar(bool isDark) {
    return IrisExpressiveNavBar(
      selectedIndex: _bottomNavIndex,
      onDestinationSelected: _onBottomNavTap,
      isSearchActive: _isSearching,
      onSearchToggle: (active) {
        if (active) {
          if (_bottomNavIndex == 3) {
            _showAboutContextSheet(isDark);
            return;
          }
        }
        setState(() {
          _isSearching = active;
        });
        if (!active) {
          _searchController.clear();
          setState(() {
            _homeSearchQuery = '';
            _toolsSearchQuery = '';
          });
          _updateScheduleCache();
        }
      },
      searchController: _searchController,
      searchFocusNode: _searchFocusNode,
      onSearchChanged: (val) {
        _searchDebounceTimer?.cancel();
        _searchDebounceTimer = Timer(const Duration(milliseconds: 140), () {
          if (!mounted) return;
          setState(() {
            if (_bottomNavIndex == 0) {
              _homeSearchQuery = val;
              _updateScheduleCache();
            } else if (_bottomNavIndex == 2) {
              _toolsSearchQuery = val;
            }
          });
        });
      },
      searchHint: _bottomNavIndex == 0 ? 'Search classes...' : 'Search tools...',
      onOpenPaletteCustomizer: () => showM3EColorSelectorSheet(context),
    );
  }

  Widget _buildSystemUpdateBanner(
    BuildContext context,
    Map<String, dynamic> update,
  ) {
    return SystemUpdateBanner(update: update);
  }

  Widget _buildTimetableDiffCard(bool isDark) {
    return TimetableDiffCard(
      isDark: isDark,
      changes: _pendingTimetableChanges,
      onDismiss: _clearPendingTimetableChanges,
    );
  }

  Widget _buildScheduleDaySelector(BuildContext context, bool isDark) {
    return ScheduleDaySelector(
      isDark: isDark,
      overrideDayIndex: _overrideDayIndex,
      onDayChanged: (newDay) {
        setState(() {
          _overrideDayIndex = newDay;
          _updateScheduleCache();
        });
      },
    );
  }

  /// Authentic Google Pixel / Material 3 Expressive Home Header.
  Widget _buildMaterialExpressiveHomeHeader({
    required BuildContext context,
    required bool isDark,
    required DateTime now,
    required String displayName,
    required String greetingText,
    required String period,
    required TemporalInsight insight,
    required List<ClassSession> schedule,
    required List<ClassSession> filteredSchedule,
  }) {
    return MaterialExpressiveHomeHeader(
      isDark: isDark,
      now: now,
      displayName: displayName,
      greetingText: greetingText,
      period: period,
      insight: insight,
      schedule: schedule,
      filteredSchedule: filteredSchedule,
      brain: widget.brain,
      batch: widget.batch,
      memory: widget.memory,
      onTriggerBatchSelector: _triggerBatchSelector,
      onBatchChanged: widget.onBatchChanged,
      onRoleChanged: widget.onRoleChanged,
    );
  }

  Widget _buildM3TimetableSyncedBar(bool isDark) {
    final cs = Theme.of(context).colorScheme;
    return ValueListenableBuilder<DateTime?>(
      valueListenable: RemoteConfigService.lastTimetableUpdateTime,
      builder: (context, lastSync, _) {
        final syncTime = lastSync ?? RemoteConfigService.lastConfigUpdateTime.value;
        final syncTimeStr = syncTime != null
            ? RemoteConfigService.formatTimestamp(syncTime)
            : 'Live';
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: cs.surfaceContainerLow,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55),
              width: 1.0,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 7,
                height: 7,
                decoration: const BoxDecoration(
                  color: Color(0xFF10B981),
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'Timetable synced',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: cs.onSurface,
                ),
              ),
              const Spacer(),
              Flexible(
                child: Text(
                  syncTimeStr,
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w500,
                    color: cs.onSurfaceVariant,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildM3BentoCards(BuildContext context, bool isDark, DateTime now) {
    final cs = Theme.of(context).colorScheme;
    final allSessions = widget.memory.activeSessions();
    final uniqueRooms = allSessions
        .map((s) => s.room)
        .where((r) => r.isNotEmpty && r != 'TBD')
        .toSet();
    final allRooms = widget.memory.allRooms();
    final totalRooms = uniqueRooms.isNotEmpty
        ? uniqueRooms.length
        : (allRooms.isNotEmpty ? allRooms.length : 0);

    final isWeekend = now.weekday == DateTime.saturday || now.weekday == DateTime.sunday;
    final currentHourFraction = now.hour + (now.minute / 60.0);
    final isCampusHours = !isWeekend && currentHourFraction >= 8.5 && currentHourFraction <= 16.5;

    int freeRoomsCount;
    if (!isCampusHours) {
      freeRoomsCount = totalRooms;
    } else {
      final occupiedRooms = allSessions
          .where((s) => s.dayIndex == now.weekday && s.isLive(now))
          .map((s) => s.room)
          .toSet();
      freeRoomsCount = (totalRooms - occupiedRooms.length).clamp(0, totalRooms);
    }

    final currentLiveClass = widget.brain.getCurrentClass(widget.batch, now);
    final nextUpcomingClass = widget.brain.getNextClass(widget.batch, now);

    String alertTitle;
    if (currentLiveClass != null && currentLiveClass.isLive(now)) {
      alertTitle = 'In Class • ${currentLiveClass.room}';
    } else if (nextUpcomingClass != null) {
      final isToday = nextUpcomingClass.dayIndex == now.weekday;
      const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      final dayStr = days[(nextUpcomingClass.dayIndex - 1) % 7];
      alertTitle = isToday
          ? 'Next • ${nextUpcomingClass.startTime}'
          : '$dayStr • ${nextUpcomingClass.startTime}';
    } else {
      alertTitle = 'All Clear Today';
    }

    return Row(
      children: [
        Expanded(
          child: ExpressiveInteractivePress(
            onTap: () {
              IrisHaptics.actionSoft();
              pushGlassContainerMorphRoute(
                context,
                page: RoomFinderScreen(
                  memory: widget.memory,
                ),
                accentColor: cs.primary,
              );
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              decoration: BoxDecoration(
                color: cs.surfaceContainer,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55),
                  width: 1.0,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: cs.primaryContainer,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                      Icons.meeting_room_outlined,
                      size: 18,
                      color: cs.onPrimaryContainer,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          '$freeRoomsCount Free',
                          style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w800,
                            color: cs.onSurface,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          'Room Finder',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: cs.onSurfaceVariant,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: ExpressiveInteractivePress(
            onTap: () {
              IrisHaptics.actionSoft();
              final hero = currentLiveClass ?? nextUpcomingClass;
              if (hero != null) {
                IrisModalSheet.show(
                  context: context,
                  initialState: lgw.GlassSheetState.half,
                  builder: (sheetContext) => LiveClassHubSheet(
                    brain: widget.brain,
                    memory: widget.memory,
                    batch: widget.batch,
                    sessions: widget.memory.sessions
                        .where((s) => s.batchKey.batch == widget.batch)
                        .toList(),
                  ),
                );
              } else {
                showIrisFrostedSnackBar(
                  context,
                  content: const Text('No classes scheduled right now.'),
                );
              }
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              decoration: BoxDecoration(
                color: cs.surfaceContainer,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55),
                  width: 1.0,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: cs.secondaryContainer,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                      Icons.schedule_rounded,
                      size: 18,
                      color: cs.onSecondaryContainer,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          alertTitle,
                          style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w800,
                            color: cs.onSurface,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          'Live Status',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: cs.onSurfaceVariant,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildHomeDashboard(
    BuildContext context,
    bool isDark,
    DateTime now,
    String dateLabel,
    TemporalInsight insight,
    List<ClassSession> filteredSchedule,
    List<ClassSession> schedule,
  ) {
    return ValueListenableBuilder<String>(
      valueListenable: RemoteConfigService.activeAcademicPeriod,
      builder: (context, activePeriod, _) {
        final isStudentsWeek = activePeriod == 'sports_week';
        final isVacation =
            activePeriod == 'vacation' || activePeriod == 'break';
        final isMidterms = activePeriod == 'midterms';
        final isFinals = activePeriod == 'finals';
        final isExamPeriod = isMidterms || isFinals;

        // 1. EXAM MODE (Midterms or Finals)
        if (isExamPeriod) {
          final periodKey = isMidterms ? 'midterms' : 'finals';
          final accentColor = isMidterms
              ? const Color(0xFFF59E0B)
              : const Color(0xFF8B5CF6);

          return SafeArea(
            child: IrisRefreshIndicator(
              onRefresh: _handleRefresh,
              color: accentColor,
              child: NotificationListener<ScrollNotification>(
                onNotification: (notification) {
                  if (notification is ScrollUpdateNotification) {
                    final delta = notification.scrollDelta?.abs() ?? 0.0;
                    final fast = delta > 16.0;
                    if (IrisGlass.isFastScrolling.value != fast) {
                      IrisGlass.isFastScrolling.value = fast;
                    }
                  } else if (notification is ScrollEndNotification) {
                    if (IrisGlass.isFastScrolling.value) {
                      IrisGlass.isFastScrolling.value = false;
                    }
                  }
                  return false;
                },
                child: ValueListenableBuilder<List<dynamic>>(
                  valueListenable: isMidterms
                      ? RemoteConfigService.midtermExams
                      : RemoteConfigService.finalExams,
                  builder: (context, rawExams, _) {
                    final matchedExams = rawExams.where((exam) {
                      final examBatchRaw = (exam['batch'] ?? '').toString();
                      return BatchKey.isBatchMatch(widget.batch, examBatchRaw);
                    }).toList();

                    List<String> extractRooms(dynamic roomData) {
                      if (roomData == null) return [];
                      final List<String> result = [];
                      if (roomData is List) {
                        for (final item in roomData) {
                          final s = item?.toString().trim() ?? '';
                          if (s.isNotEmpty) {
                            final parts = s.split(RegExp(r'[,/&+;\n]'));
                            for (final p in parts) {
                              final clean = p.trim();
                              if (clean.isNotEmpty && !result.contains(clean)) {
                                result.add(clean);
                              }
                            }
                          }
                        }
                      } else {
                        final s = roomData.toString().trim();
                        if (s.isNotEmpty) {
                          final parts = s.split(RegExp(r'[,/&+;\n]'));
                          for (final p in parts) {
                            final clean = p.trim();
                            if (clean.isNotEmpty && !result.contains(clean)) {
                              result.add(clean);
                            }
                          }
                        }
                      }
                      return result;
                    }

                    final Map<String, Map<String, dynamic>> grouped = {};
                    for (final exam in matchedExams) {
                      final date = (exam['date'] ?? '').toString().trim();
                      final time = (exam['time'] ?? '').toString().trim();
                      final subject = (exam['subject'] ?? '').toString().trim();
                      final extracted = extractRooms(
                        exam['rooms'] ?? exam['room'],
                      );

                      final key = '${date}_${time}_$subject';
                      if (grouped.containsKey(key)) {
                        final existingRooms =
                            grouped[key]!['rooms'] as List<String>;
                        for (final r in extracted) {
                          if (!existingRooms.contains(r)) {
                            existingRooms.add(r);
                          }
                        }
                      } else {
                        grouped[key] = {
                          'date': date,
                          'time': time,
                          'subject': subject,
                          'rooms': extracted.isEmpty
                              ? ['Main Hall']
                              : extracted,
                        };
                      }
                    }

                    var allExamsList = grouped.values.toList();
                    allExamsList.sort((a, b) {
                      final dateA =
                          FormatGuard.parseDate(a['date'] ?? '') ??
                          DateTime(3000);
                      final dateB =
                          FormatGuard.parseDate(b['date'] ?? '') ??
                          DateTime(3000);
                      if (dateA != dateB) {
                        return dateA.compareTo(dateB);
                      }
                      final timeA = (a['time'] ?? '').toString();
                      final timeB = (b['time'] ?? '').toString();
                      return timeA.compareTo(timeB);
                    });

                    final totalExams = allExamsList.length;
                    int completedExams = 0;
                    int todayExams = 0;
                    Map<String, dynamic>? nextExam;
                    int daysToNextExam = -1;

                    final now = DateTime.now();
                    final today = DateTime(now.year, now.month, now.day);

                    for (final exam in allExamsList) {
                      final parsedDate = FormatGuard.parseDate(
                        exam['date'] ?? '',
                      );
                      if (parsedDate != null) {
                        final examDay = DateTime(
                          parsedDate.year,
                          parsedDate.month,
                          parsedDate.day,
                        );
                        if (examDay.isBefore(today)) {
                          completedExams++;
                        } else if (examDay.isAtSameMomentAs(today)) {
                          todayExams++;
                          if (nextExam == null) {
                            nextExam = exam;
                            daysToNextExam = 0;
                          }
                        } else {
                          if (nextExam == null) {
                            nextExam = exam;
                            daysToNextExam = examDay.difference(today).inDays;
                          }
                        }
                      }
                    }

                    return Align(
                      alignment: Alignment.topCenter,
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 840),
                        child: CustomScrollView(
                          controller: _scrollController,
                          physics: const ButterScrollPhysics(),
                          cacheExtent: 450.0,
                          slivers: [
                            if (_pendingTimetableChanges.isNotEmpty)
                              SliverToBoxAdapter(
                                child: Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                    20,
                                    16,
                                    20,
                                    0,
                                  ),
                                  child: _buildTimetableDiffCard(isDark),
                                ),
                              ),
                            ValueListenableBuilder<Map<String, dynamic>?>(
                              valueListenable:
                                  RemoteConfigService.latestApkUpdate,
                              builder: (context, updateInfo, _) {
                                if (updateInfo == null) {
                                  return const SliverToBoxAdapter(
                                    child: SizedBox.shrink(),
                                  );
                                }
                                return SliverToBoxAdapter(
                                  child: Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                      20,
                                      16,
                                      20,
                                      0,
                                    ),
                                    child: _buildSystemUpdateBanner(
                                      context,
                                      updateInfo,
                                    ),
                                  ),
                                );
                              },
                            ),
                            SliverPersistentHeader(
                              pinned: true,
                              delegate: ExamStickyHeaderDelegate(
                                batch: widget.batch,
                                period: periodKey,
                                daysToNextExam: daysToNextExam,
                                nextExamSubject: nextExam?['subject']
                                    ?.toString(),
                                totalExams: totalExams,
                                completedExams: completedExams,
                                todayExams: todayExams,
                                onRefresh: () => _handleRefresh(),
                              ),
                            ),
                            SliverToBoxAdapter(
                              child: ExamScheduleView(
                                period: periodKey,
                                batch: widget.batch,
                                showHeroBanner: false,
                                onToggleTheme: widget.onToggleTheme,
                              ),
                            ),
                            const SliverPadding(
                              padding: EdgeInsets.only(bottom: 110),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          );
        }

        // 2. VACATION MODE
        if (isVacation) {
          return SafeArea(
            child: IrisRefreshIndicator(
              onRefresh: _handleRefresh,
              color: const Color(0xFFF43F5E),
              child: NotificationListener<ScrollNotification>(
                onNotification: (notification) {
                  if (notification is ScrollUpdateNotification) {
                    final delta = notification.scrollDelta?.abs() ?? 0.0;
                    final fast = delta > 16.0;
                    if (IrisGlass.isFastScrolling.value != fast) {
                      IrisGlass.isFastScrolling.value = fast;
                    }
                  } else if (notification is ScrollEndNotification) {
                    if (IrisGlass.isFastScrolling.value) {
                      IrisGlass.isFastScrolling.value = false;
                    }
                  }
                  return false;
                },
                child: Align(
                  alignment: Alignment.topCenter,
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 840),
                    child: CustomScrollView(
                      controller: _scrollController,
                      physics: const ButterScrollPhysics(),
                      cacheExtent: 450.0,
                      slivers: [
                        if (_pendingTimetableChanges.isNotEmpty)
                          SliverToBoxAdapter(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                              child: _buildTimetableDiffCard(isDark),
                            ),
                          ),
                        ValueListenableBuilder<Map<String, dynamic>?>(
                          valueListenable: RemoteConfigService.latestApkUpdate,
                          builder: (context, updateInfo, _) {
                            if (updateInfo == null) {
                              return const SliverToBoxAdapter(
                                child: SizedBox.shrink(),
                              );
                            }
                            return SliverToBoxAdapter(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                  20,
                                  16,
                                  20,
                                  0,
                                ),
                                child: _buildSystemUpdateBanner(
                                  context,
                                  updateInfo,
                                ),
                              ),
                            );
                          },
                        ),
                        ValueListenableBuilder<Map<String, dynamic>?>(
                          valueListenable: RemoteConfigService.vacationSchedule,
                          builder: (context, vacSchedule, _) {
                            final now = DateTime.now();
                            final defaultTargetSem = now.month >= 8
                                ? 'Spring ${now.year + 1}'
                                : 'Fall ${now.year}';
                            final targetSem =
                                vacSchedule?['target_semester']?.toString() ??
                                defaultTargetSem;
                            int daysLeft = -1;
                            final resumptionStr =
                                vacSchedule?['resumption_date']?.toString();
                            if (resumptionStr != null &&
                                resumptionStr.isNotEmpty) {
                              final parsed = DateTime.tryParse(resumptionStr);
                              if (parsed != null) {
                                daysLeft =
                                    DateTime(
                                          parsed.year,
                                          parsed.month,
                                          parsed.day,
                                        )
                                        .difference(
                                          DateTime(
                                            now.year,
                                            now.month,
                                            now.day,
                                          ),
                                        )
                                        .inDays;
                              }
                            }

                            return SliverPersistentHeader(
                              pinned: true,
                              delegate: VacationStickyHeaderDelegate(
                                batch: widget.batch,
                                daysLeft: daysLeft,
                                targetSemester: targetSem,
                                onNoticeTap: () => _handleRefresh(),
                              ),
                            );
                          },
                        ),
                        ValueListenableBuilder<Map<String, dynamic>?>(
                          valueListenable: RemoteConfigService.vacationSchedule,
                          builder: (context, vacSchedule, _) {
                            final milestones =
                                vacSchedule?['milestones'] as List<dynamic>?;

                            return SliverToBoxAdapter(
                              child: VacationScheduleView(
                                batch: widget.batch,
                                brain: widget.brain,
                                milestones: milestones,
                                onOpenPortal: () {
                                  pushGlassContainerMorphRoute(
                                    context,
                                    page: const PortalScreen(
                                      url: 'https://swl-sis.comsats.edu.pk/',
                                      title: 'COMSATS Student Portal',
                                      sessionScope: 'student',
                                    ),
                                    accentColor: const Color(0xFF10B981),
                                  );
                                },
                                onOpenCgpa: () {
                                  pushGlassContainerMorphRoute(
                                    context,
                                    page: const CgpaCalculatorScreen(),
                                  );
                                },
                              ),
                            );
                          },
                        ),
                        const SliverPadding(
                          padding: EdgeInsets.only(bottom: 110),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        }

        // 3. NORMAL CLASSES (Almanac, Editorial Academic, or M3/Liquid Glass)
        if (ThemeSignals.isAlmanac) {
          return AlmanacScheduleView(
            brain: widget.brain,
            batch: widget.batch,
            activeDayIndex: _overrideDayIndex ?? now.weekday,
            onDaySelected: (newDay) {
              setState(() {
                _overrideDayIndex = newDay;
                _updateScheduleCache();
              });
            },
            onRefresh: () async {
              await _handleRefresh();
            },
            onOpenBatchSelector: _triggerBatchSelector,
            pendingChanges: _pendingTimetableChanges,
            onDismissChanges: _clearPendingTimetableChanges,
          );
        }

        if (ThemeSignals.isEditorialAcademic) {
          return EditorialScheduleView(
            brain: widget.brain,
            batch: widget.batch,
            activeDayIndex: _overrideDayIndex ?? now.weekday,
            onDaySelected: (newDay) {
              setState(() {
                _overrideDayIndex = newDay;
                _updateScheduleCache();
              });
            },
            onRefresh: () async {
              await _handleRefresh();
            },
            onOpenBatchSelector: _triggerBatchSelector,
            pendingChanges: _pendingTimetableChanges,
            onDismissChanges: _clearPendingTimetableChanges,
            userName: widget.userName,
            onToggleTheme: widget.onToggleTheme,
          );
        }

        if (ThemeSignals.isNotebook) {
          return NotebookScheduleView(
            brain: widget.brain,
            batch: widget.batch,
            activeDayIndex: _overrideDayIndex ?? now.weekday,
            onDaySelected: (newDay) {
              setState(() {
                _overrideDayIndex = newDay;
                _updateScheduleCache();
              });
            },
            onRefresh: () async {
              await _handleRefresh();
            },
            onOpenBatchSelector: _triggerBatchSelector,
            pendingChanges: _pendingTimetableChanges,
            onDismissChanges: _clearPendingTimetableChanges,
            userName: widget.userName,
          );
        }

        if (ThemeSignals.isLine) {
          return LineScheduleView(
            brain: widget.brain,
            batch: widget.batch,
            activeDayIndex: _overrideDayIndex ?? now.weekday,
            onDaySelected: (newDay) {
              setState(() {
                _overrideDayIndex = newDay;
                _updateScheduleCache();
              });
            },
            onRefresh: () async {
              await _handleRefresh();
            },
            onOpenBatchSelector: _triggerBatchSelector,
            pendingChanges: _pendingTimetableChanges,
            onDismissChanges: _clearPendingTimetableChanges,
            userName: widget.userName,
          );
        }

        if (ThemeSignals.isPoster) {
          return PosterScheduleView(
            brain: widget.brain,
            batch: widget.batch,
            activeDayIndex: _overrideDayIndex ?? now.weekday,
            onDaySelected: (newDay) {
              setState(() {
                _overrideDayIndex = newDay;
                _updateScheduleCache();
              });
            },
            onRefresh: () async {
              await _handleRefresh();
            },
            onOpenBatchSelector: _triggerBatchSelector,
            pendingChanges: _pendingTimetableChanges,
            onDismissChanges: _clearPendingTimetableChanges,
            userName: widget.userName,
          );
        }

        return SafeArea(
          top: ThemeSignals.isMaterialYou,
          child: IrisRefreshIndicator(
            onRefresh: _handleRefresh,
            color: isStudentsWeek ? const Color(0xFF10B981) : null,
            child: NotificationListener<ScrollNotification>(
              onNotification: (notification) {
                if (ThemeSignals.isFluidGlass) {
                  if (notification is ScrollUpdateNotification) {
                    final delta = notification.scrollDelta?.abs() ?? 0.0;
                    final fast = delta > 16.0;
                    if (IrisGlass.isFastScrolling.value != fast) {
                      IrisGlass.isFastScrolling.value = fast;
                    }
                  } else if (notification is ScrollEndNotification) {
                    if (IrisGlass.isFastScrolling.value) {
                      IrisGlass.isFastScrolling.value = false;
                    }
                  }
                }
                return false;
              },
              child: Align(
                alignment: Alignment.topCenter,
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 840),
                  child: CustomScrollView(
                    controller: _scrollController,
                    physics: const ButterScrollPhysics(),
                    cacheExtent: 450.0,
                    slivers: [
                      // 1. Home Header: Pinned Sticky Collapsing Canopy for Liquid Glass, Expressive for M3
                      if (ThemeSignals.isMaterialYou) ...[
                        if (_pendingTimetableChanges.isNotEmpty)
                          SliverToBoxAdapter(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                              child: _buildTimetableDiffCard(isDark),
                            ),
                          ),
                        ValueListenableBuilder<Map<String, dynamic>?>(
                          valueListenable: RemoteConfigService.latestApkUpdate,
                          builder: (context, updateInfo, _) {
                            if (updateInfo == null) {
                              return const SliverToBoxAdapter(
                                child: SizedBox.shrink(),
                              );
                            }
                            return SliverToBoxAdapter(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                                child: _buildSystemUpdateBanner(
                                  context,
                                  updateInfo,
                                ),
                              ),
                            );
                          },
                        ),
                        SliverToBoxAdapter(
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                            child: ValueListenableBuilder<String>(
                              valueListenable:
                                  RemoteConfigService.activeAcademicPeriod,
                              builder: (context, period, _) {
                                String displayName = (widget.userName != null && widget.userName!.trim().isNotEmpty)
                                    ? widget.userName!.trim().toUpperCase()
                                    : 'STUDENT';
                                final nameParts = displayName.split(
                                  RegExp(r'\s+'),
                                );
                                if (nameParts.length > 2 &&
                                    displayName.length > 18) {
                                  displayName = '${nameParts[0]} ${nameParts[1]}';
                                }
                                final greetingWord = _getSmartGreeting(
                                  now.hour,
                                ).toUpperCase();
                                final greetingText = 'GOOD $greetingWord';

                                return _buildMaterialExpressiveHomeHeader(
                                  context: context,
                                  isDark: isDark,
                                  now: now,
                                  displayName: displayName,
                                  greetingText: greetingText,
                                  period: period,
                                  insight: insight,
                                  schedule: schedule,
                                  filteredSchedule: filteredSchedule,
                                );
                              },
                            ),
                          ),
                        ),
                      ] else ...[
                        // Liquid Glass Pinned Collapsing Header (Flush to top screen, rounded bottom, collapses smoothly)
                        ValueListenableBuilder<String>(
                          valueListenable:
                              RemoteConfigService.activeAcademicPeriod,
                          builder: (context, period, _) {
                            final hour = now.hour;
                            final isNightArtwork =
                                (period == 'sports_week' ||
                                    period == 'ramadan')
                                ? false
                                : (hour < 6 || hour >= 18);
                            final String imageAsset = (period == 'sports_week')
                                ? 'assets/headers/header_sports_gala.jpg'
                                : (period == 'ramadan')
                                    ? 'assets/headers/header_ramadan_mode.jpg'
                                    : (period == 'midterms')
                                        ? 'assets/headers/header_midterms_mode.jpg'
                                        : (period == 'finals')
                                            ? 'assets/headers/header_finals_week.jpg'
                                            : (isNightArtwork
                                                ? 'assets/headers/header_classes_night.jpg'
                                                : 'assets/headers/header_classes_day.jpg');

                            String displayName = (widget.userName != null && widget.userName!.trim().isNotEmpty)
                                ? widget.userName!.trim().toUpperCase()
                                : 'STUDENT';
                            final nameParts = displayName.split(
                                RegExp(r'\s+'),
                            );
                            if (nameParts.length > 2 &&
                                displayName.length > 18) {
                              displayName = '${nameParts[0]} ${nameParts[1]}';
                            }
                            final greetingWord = _getSmartGreeting(
                              now.hour,
                            ).toUpperCase();
                            final greetingText = 'GOOD $greetingWord';

                            return SliverPersistentHeader(
                              pinned: true,
                              delegate: HomeLiquidGlassStickyHeaderDelegate(
                                topPadding: MediaQuery.paddingOf(context).top,
                                displayName: displayName,
                                greetingText: greetingText,
                                batch: widget.batch,
                                period: period,
                                accentColor: (period == 'sports_week' ||
                                        period == 'ramadan')
                                    ? const Color(0xFF10B981)
                                    : (period == 'midterms' ||
                                            period == 'finals')
                                        ? const Color(0xFFF59E0B)
                                        : IrisTokens.brand,
                                imageAsset: imageAsset,
                                isDark: isDark,
                                brain: widget.brain,
                                memory: widget.memory,
                                schedule: schedule,
                                insight: insight,
                                onRoleChanged: widget.onRoleChanged,
                                onBatchTap: _triggerBatchSelector,
                                onToggleTheme: widget.onToggleTheme,
                                onAnnouncementsTap: () {
                                  IrisHaptics.actionSoft();
                                  pushGlassContainerMorphRoute(
                                    context,
                                    page: const AnnouncementsScreen(),
                                    accentColor: const Color(0xFF00E5FF),
                                  );
                                },
                                onInsightTap: () {
                                  if (insight.isLive || insight.isUrgent) {
                                    IrisHaptics.actionSoft();
                                    IrisModalSheet.show(
                                      context: context,
                                      initialState: lgw.GlassSheetState.half,
                                      settings: IrisGlass.widgetsSettings(
                                        context,
                                        blur: 16.0,
                                        thickness: 15.0,
                                        ambientStrength: isDark ? 0.65 : 0.72,
                                        lightAngle: 1.5,
                                        glassColor: isDark
                                            ? Colors.black.withValues(
                                                alpha: 0.20,
                                              )
                                            : Colors.white.withValues(
                                                alpha: 0.15,
                                              ),
                                      ),
                                      builder: (sheetContext) =>
                                          LiveClassHubSheet(
                                            brain: widget.brain,
                                            memory: widget.memory,
                                            batch: widget.batch,
                                            sessions: schedule,
                                          ),
                                    );
                                  }
                                },
                              ),
                            );
                          },
                        ),
                        if (_pendingTimetableChanges.isNotEmpty)
                          SliverToBoxAdapter(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
                              child: _buildTimetableDiffCard(isDark),
                            ),
                          ),
                        ValueListenableBuilder<Map<String, dynamic>?>(
                          valueListenable: RemoteConfigService.latestApkUpdate,
                          builder: (context, updateInfo, _) {
                            if (updateInfo == null) {
                              return const SliverToBoxAdapter(
                                child: SizedBox.shrink(),
                              );
                            }
                            return SliverToBoxAdapter(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
                                child: _buildSystemUpdateBanner(
                                  context,
                                  updateInfo,
                                ),
                              ),
                            );
                          },
                        ),
                      ],

                      // SliverToBoxAdapter(child: PortalSyncCard(isDark: isDark)), // Disabled portal intelligence card for now
                      _buildPersistentAnnouncementCard(context, isDark),
                      if (isStudentsWeek)
                        const SliverToBoxAdapter(
                          child: Padding(
                            padding: EdgeInsets.only(top: 12),
                            child: StudentsWeekInfoCard(isFaculty: false),
                          ),
                        ),
                      SliverToBoxAdapter(
                        child: _buildScheduleDaySelector(context, isDark),
                      ),
                      if (!ThemeSignals.isMaterialYou)
                        SliverToBoxAdapter(
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(22, 8, 22, 4),
                            child: Row(
                              children: [
                                Text(
                                  'TIMELINE (${filteredSchedule.length})',
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.1,
                                    color: (isDark ? Colors.white : const Color(0xFF0F172A))
                                        .withValues(alpha: 0.62),
                                  ),
                                ),
                                const Spacer(),
                                ValueListenableBuilder<DateTime?>(
                                  valueListenable:
                                      RemoteConfigService.lastTimetableUpdateTime,
                                  builder: (context, lastSync, _) {
                                    if (lastSync == null) {
                                      return const SizedBox.shrink();
                                    }
                                    return Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Container(
                                          width: 6,
                                          height: 6,
                                          decoration: const BoxDecoration(
                                            color: Color(0xFF10B981),
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                        const SizedBox(width: 6),
                                        Text(
                                          'Synced ${RemoteConfigService.formatTimestamp(lastSync)}',
                                          style: TextStyle(
                                            fontSize: 10.5,
                                            fontWeight: FontWeight.w600,
                                            color: isDark ? Colors.white60 : Colors.black54,
                                          ),
                                        ),
                                      ],
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                      SliverPadding(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        sliver: filteredSchedule.isEmpty
                            ? SliverToBoxAdapter(
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 20,
                                    vertical: 8,
                                  ),
                                  child: ThemeSignals.isMaterialYou
                                      ? Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              width: double.infinity,
                                              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
                                              decoration: BoxDecoration(
                                                color: Theme.of(context).colorScheme.surfaceContainer,
                                                borderRadius: BorderRadius.circular(24),
                                                border: Border.all(
                                                  color: Theme.of(context).colorScheme.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55),
                                                  width: 1.0,
                                                ),
                                              ),
                                              child: Row(
                                                children: [
                                                  Container(
                                                    width: 44,
                                                    height: 44,
                                                    decoration: BoxDecoration(
                                                      color: Theme.of(context).colorScheme.primaryContainer,
                                                      borderRadius: BorderRadius.circular(14),
                                                    ),
                                                    child: Icon(
                                                      _homeSearchQuery.isNotEmpty
                                                          ? Icons.search_off_rounded
                                                          : Icons.event_available_rounded,
                                                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                                                      size: 22,
                                                    ),
                                                  ),
                                                  const SizedBox(width: 14),
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          _homeSearchQuery.isNotEmpty
                                                              ? 'No classes match "$_homeSearchQuery"'
                                                              : 'No classes scheduled',
                                                          style: TextStyle(
                                                            fontSize: 15.5,
                                                            fontWeight: FontWeight.w800,
                                                            color: Theme.of(context).colorScheme.onSurface,
                                                          ),
                                                        ),
                                                        const SizedBox(height: 2),
                                                        Text(
                                                          _homeSearchQuery.isNotEmpty
                                                              ? 'Try searching for a different subject or room'
                                                              : (now.weekday >= 6 ? 'Enjoy your weekend break' : 'No sessions scheduled for this day'),
                                                          style: TextStyle(
                                                            fontSize: 12.5,
                                                            fontWeight: FontWeight.w500,
                                                            color: Theme.of(context).colorScheme.onSurfaceVariant,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            const SizedBox(height: 12),
                                            _buildM3TimetableSyncedBar(isDark),
                                            const SizedBox(height: 16),
                                            Text(
                                              'Quick Campus Status',
                                              style: TextStyle(
                                                fontSize: 14.5,
                                                fontWeight: FontWeight.w700,
                                                color: Theme.of(context).colorScheme.onSurface,
                                              ),
                                            ),
                                            const SizedBox(height: 8),
                                            _buildM3BentoCards(context, isDark, now),
                                          ],
                                        )
                                      : GlassCard(
                                          child: Column(
                                            children: [
                                              const SizedBox(height: 12),
                                              Container(
                                                padding: const EdgeInsets.all(20),
                                                decoration: BoxDecoration(
                                                  gradient: LinearGradient(
                                                    begin: Alignment.topLeft,
                                                    end: Alignment.bottomRight,
                                                    colors: [
                                                      IrisTokens.brand.withValues(
                                                        alpha: 0.15,
                                                      ),
                                                      IrisTokens.brandLight
                                                          .withValues(alpha: 0.08),
                                                    ],
                                                  ),
                                                  shape: BoxShape.circle,
                                                  boxShadow: [
                                                    BoxShadow(
                                                      color: IrisTokens.brand
                                                          .withValues(alpha: 0.14),
                                                      blurRadius: 8,
                                                      spreadRadius: -4,
                                                    ),
                                                  ],
                                                ),
                                                child: Icon(
                                                  Icons.beach_access_rounded,
                                                  size: 40,
                                                  color: IrisTokens.brand.withValues(
                                                    alpha: 0.8,
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(height: 20),
                                              Text(
                                                'No classes scheduled',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w900,
                                                  fontSize: 17,
                                                  letterSpacing: 0.3,
                                                  color: (isDark
                                                          ? Colors.white
                                                          : Colors.black)
                                                      .withValues(alpha: 0.85),
                                                ),
                                              ),
                                              const SizedBox(height: 8),
                                              Text(
                                                'Enjoy your free time! 🎉',
                                                style: TextStyle(
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.4,
                                                  color: (isDark
                                                          ? Colors.white
                                                          : Colors.black)
                                                      .withValues(alpha: 0.55),
                                                ),
                                              ),
                                              const SizedBox(height: 12),
                                            ],
                                          ),
                                        ),
                                ),
                              )
                            : SliverList(
                                delegate: SliverChildBuilderDelegate(
                                  (ctx, index) {
                                    final session = filteredSchedule[index];
                                    final fullIndex = schedule.indexOf(session);
                                    final nextSession =
                                        (fullIndex >= 0 &&
                                            fullIndex + 1 < schedule.length)
                                        ? schedule[fullIndex + 1]
                                        : null;
                                    return StaggeredListItem(
                                      index: index,
                                      child: RepaintBoundary(
                                          child: ClassCard(
                                            key: ValueKey(
                                              session.id.isNotEmpty
                                                  ? 'class_${session.id}'
                                                  : 'class_${session.subject}_${session.startTime}_${session.room}_${session.dayIndex}',
                                            ),
                                          session: session,
                                          nextSession: nextSession,
                                          isFacultyView: false,
                                          onRemoveMakeup:
                                              _isMakeupSession(session)
                                              ? () =>
                                                    _confirmAndRemoveMakeupSession(
                                                      session,
                                                    )
                                              : null,
                                        ),
                                      ),
                                    );
                                  },
                                  childCount: filteredSchedule.length,
                                  addAutomaticKeepAlives: false,
                                ),
                              ),
                      ),
                      if (filteredSchedule.isNotEmpty && ThemeSignals.isMaterialYou)
                        SliverToBoxAdapter(
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(20, 10, 20, 16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                _buildM3TimetableSyncedBar(isDark),
                                const SizedBox(height: 14),
                                Text(
                                  'Quick Campus Status',
                                  style: TextStyle(
                                    fontSize: 14.5,
                                    fontWeight: FontWeight.w700,
                                    color: Theme.of(context).colorScheme.onSurface,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                _buildM3BentoCards(context, isDark, now),
                              ],
                            ),
                          ),
                        ),
                      SliverToBoxAdapter(
                        child: SizedBox(
                          height: 140.0 + MediaQuery.paddingOf(context).bottom,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final now = DateTime.now();
    final dateLabel = _formatDateLabel(now);
    if (_cachedInsight == null || _lastInsightMinute != now.minute) {
      _cachedInsight = widget.brain.buildTemporalInsight(widget.batch, now);
      _lastInsightMinute = now.minute;
    }
    final insight = _cachedInsight!;

    // Update cache if day changed or first load
    if (_lastScheduleUpdate == null || _lastScheduleUpdate!.day != now.day) {
      _updateScheduleCache();
    }
    final schedule = _cachedSchedule;
    final q = _homeSearchQuery.trim().toLowerCase();
    final filteredSchedule = q.isEmpty
        ? schedule
        : schedule.where((s) {
            return s.subject.toLowerCase().contains(q) ||
                s.room.toLowerCase().contains(q) ||
                s.teacher.toLowerCase().contains(q);
          }).toList();

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: IrisSpatialDepthWrapper(
        child: Stack(
          children: [
          Positioned.fill(
            child: RepaintBoundary(child: ObsidianPulse(isDark: isDark)),
          ),
          Positioned.fill(
            child: IrisExpressiveTabStack(
              index: _bottomNavIndex,
              slideDirection: _studentTabSlideDirection,
              children: [
                ValueListenableBuilder<String>(
                  valueListenable: RemoteConfigService.activeAcademicPeriod,
                  builder: (context, period, _) {
                    return ValueListenableBuilder<IrisThemeStyle>(
                      valueListenable: ThemeSignals.themeStyle,
                      builder: (context, style, _) {
                        return KeyedSubtree(
                          key: ValueKey('home-$period-${style.name}'),
                          child: _buildHomeDashboard(
                            context,
                            isDark,
                            now,
                            dateLabel,
                            insight,
                            filteredSchedule,
                            schedule,
                          ),
                        );
                      },
                    );
                  },
                ),
                _mountedTabs.contains(1) || _bottomNavIndex == 1
                    ? TickerMode(
                        enabled: _bottomNavIndex == 1,
                        child: const PortalScreen(
                          key: PageStorageKey<String>('student_tab_portal'),
                          url: 'https://swl-sis.comsats.edu.pk/',
                          title: 'COMSATS Student Portal',
                          sessionScope: 'student',
                          showBackButton: false,
                        ),
                      )
                    : const SizedBox.shrink(),
                _mountedTabs.contains(2) || _bottomNavIndex == 2
                    ? ValueListenableBuilder<IrisThemeStyle>(
                        valueListenable: ThemeSignals.themeStyle,
                        builder: (context, style, _) {
                          return ValueListenableBuilder<int>(
                            valueListenable: AppSignals.stateRevision,
                            builder: (context, rev, _) {
                              return ToolsScreen(
                                key: ValueKey('student_tab_tools_${style.name}_${widget.batch}'),
                                memory: widget.memory,
                                batch: widget.batch,
                                brain: widget.brain,
                                onRoleChanged: widget.onRoleChanged,
                                onBatchChanged: widget.onBatchChanged,
                                onAddMakeupClass: _addMakeupSession,
                                onRemoveMakeupClass: _removeMakeupSession,
                                scrollController: _toolsScrollController,
                                searchQuery: _toolsSearchQuery,
                              );
                            },
                          );
                        },
                      )
                    : const SizedBox.shrink(),
                _mountedTabs.contains(3) || _bottomNavIndex == 3
                    ? ValueListenableBuilder<IrisThemeStyle>(
                        valueListenable: ThemeSignals.themeStyle,
                        builder: (context, style, _) {
                          return ValueListenableBuilder<int>(
                            valueListenable: AppSignals.stateRevision,
                            builder: (context, rev, _) {
                              return AboutScreen(
                                key: ValueKey('student_tab_about_${style.name}'),
                                memory: widget.memory,
                                onRoleChanged: widget.onRoleChanged,
                                onBatchChanged: widget.onBatchChanged,
                                scrollController: _aboutScrollController,
                                onToggleTheme: widget.onToggleTheme,
                                currentThemeMode: widget.currentThemeMode,
                                onSetThemeMode: widget.onSetThemeMode,
                                onBackPressed: () => _onBottomNavTap(0),
                              );
                            },
                          );
                        },
                      )
                    : const SizedBox.shrink(),
              ],
            ),
          ),
          Positioned(
            top: 16,
            left: 0,
            right: 0,
            child: SafeArea(
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 840),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: ValueListenableBuilder<Map<String, dynamic>?>(
                      valueListenable: RemoteConfigService.liveAnnouncement,
                      builder: (context, announcement, _) {
                        if (announcement != null) {
                          return _buildAnnouncementBanner(
                            context,
                            announcement,
                          );
                        }
                        return const SizedBox.shrink();
                      },
                    ),
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: ValueListenableBuilder<IrisThemeStyle>(
              valueListenable: ThemeSignals.themeStyle,
              builder: (context, style, child) {
                if (style == IrisThemeStyle.almanac) {
                  return AlmanacNavBar(
                    selectedIndex: _bottomNavIndex,
                    onDestinationSelected: _onBottomNavTap,
                  );
                }
                if (style == IrisThemeStyle.editorialAcademic) {
                  return EditorialNavBar(
                    selectedIndex: _bottomNavIndex,
                    onDestinationSelected: _onBottomNavTap,
                  );
                }
                if (style == IrisThemeStyle.notebook) {
                  return NotebookNavBar(
                    activeIndex: _bottomNavIndex,
                    onTabSelected: _onBottomNavTap,
                    isDark: isDark,
                  );
                }
                if (style == IrisThemeStyle.line) {
                  return LineNavBar(
                    activeIndex: _bottomNavIndex,
                    onTabSelected: _onBottomNavTap,
                    isDark: isDark,
                  );
                }
                if (style == IrisThemeStyle.poster) {
                  return PosterNavBar(
                    activeIndex: _bottomNavIndex,
                    onTabSelected: _onBottomNavTap,
                    isDark: isDark,
                  );
                }
                return RepaintBoundary(
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 580),
                      child: _buildStudentBottomNavBar(isDark),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    ),
  );
  }

  List<ClassSession> _buildTimelineSchedule(DateTime now) {
    final dayToLoad = _overrideDayIndex ?? now.weekday;
    final mergedSchedule = widget.brain.getMergedDaySchedule(widget.batch, dayToLoad);

    if (_homeSearchQuery.isNotEmpty) {
      final query = _homeSearchQuery.toLowerCase();
      return mergedSchedule
          .where(
            (s) =>
                s.subject.toLowerCase().contains(query) ||
                s.teacher.toLowerCase().contains(query) ||
                s.room.toLowerCase().contains(query),
          )
          .toList();
    }

    return mergedSchedule;
  }

  String _timelineSubtitle(
    List<ClassSession> schedule,
    DateTime now,
    int? overrideDay,
  ) {
    final period = RemoteConfigService.activeAcademicPeriod.value;
    if (schedule.isEmpty && overrideDay != null) {
      if (period == 'midterms' || period == 'finals') {
        return 'No exam papers scheduled • All clear! 🎉';
      }
      if (period == 'sports_week') {
        return 'No classes scheduled • Enjoy! 🎉';
      }
      return 'No classes scheduled • Free day! 🎉';
    }
    if (schedule.isEmpty) return 'No sessions in the registry';

    final dayIndex = overrideDay ?? schedule.first.dayIndex;
    final currentTime = now.hour + (now.minute / 60.0);

    final noun = period == 'midterms' || period == 'finals'
        ? 'paper'
        : 'class';
    final nouns = period == 'midterms' || period == 'finals'
        ? 'papers'
        : 'classes';

    if (dayIndex == now.weekday) {
      final current = widget.brain.getCurrentClass(widget.batch, now);

      if (current != null && current.isLive(now)) {
        final remaining = schedule
            .where((s) => s.safeStartVal > currentTime)
            .length;
        final classesLeft = remaining > 0
            ? '$remaining ${remaining == 1 ? noun : nouns} left'
            : 'Last $noun today';
        return '${current.subject} • $classesLeft';
      } else {
        final nextClass = schedule.firstWhere(
          (s) => s.safeStartVal > currentTime,
          orElse: () => schedule.first,
        );

        if (nextClass.safeStartVal > currentTime) {
          final minutesUntil = ((nextClass.safeStartVal - currentTime) * 60)
              .round();

          final prefix = period == 'midterms' || period == 'finals'
              ? 'Paper'
              : 'Next';
          if (minutesUntil > 60) {
            return '${(minutesUntil / 60).floor()}h ${minutesUntil % 60}m free • $prefix: ${nextClass.subject}';
          } else if (minutesUntil > 15) {
            return '$minutesUntil min break • ${nextClass.subject} in ${nextClass.room}';
          } else {
            return 'Starting soon: ${nextClass.subject} in ${nextClass.room} ⚡';
          }
        }
      }

      return '${schedule.length} ${schedule.length == 1 ? noun : nouns} today';
    }

    return '${schedule.length} ${schedule.length == 1 ? noun : nouns} scheduled';
  }

  String _getSmartGreeting(int hour) {
    if (hour >= 5 && hour < 12) return 'MORNING';
    if (hour >= 12 && hour < 17) return 'AFTERNOON';
    if (hour >= 17 && hour < 21) return 'EVENING';
    return 'NIGHT';
  }

  Color _getTimelineStatusColor(OmniBrain brain, String batch, DateTime now) {
    final current = brain.getCurrentClass(batch, now);
    if (current != null && current.isLive(now)) {
      // Green - lectures are active
      return IrisTokens.success;
    }

    // Check if there's a class starting soon (within next 15 minutes)
    final next = brain.getNextClass(batch, now);
    if (next != null && next.dayIndex == now.weekday) {
      final currentTime = now.hour + (now.minute / 60.0);
      if (next.safeStartVal > currentTime && next.safeStartVal - currentTime <= 0.25) {
        // Blue - lectures about to start
        return IrisTokens.blue;
      }
    }

    // Neutral accent - no active lectures
    return IrisTokens.brand;
  }
}
