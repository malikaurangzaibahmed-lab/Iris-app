import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:home_widget/home_widget.dart';

import '../../core/theme_signals.dart';
import '../../core/models.dart';
import '../../core/app_signals.dart';
import '../../core/omni_brain.dart';
import '../../core/vital_theme.dart';
import '../../services/ui_feedback.dart';
import '../../services/helpdesk_faculty_service.dart';
import '../../services/analytics_manager.dart';
import '../../services/remote_config_service.dart';
import '../../services/widget_service.dart';
import 'package:iris/widgets/effects/glass_container_transform.dart';
import 'package:iris/widgets/navigation/iris_expressive_nav_bar.dart';
import 'package:iris/widgets/controls/m3e_color_selector.dart';
import '../../widgets/smart_widgets.dart';
import 'package:iris/widgets/navigation/almanac_nav_bar.dart';
import 'package:iris/widgets/navigation/editorial_nav_bar.dart';
import 'package:iris/widgets/navigation/notebook_nav_bar.dart';
import 'package:iris/widgets/navigation/line_nav_bar.dart';
import 'package:iris/widgets/navigation/poster_nav_bar.dart';
import '../portal_screen.dart';
import 'package:iris/screens/settings/about_screen.dart';
import 'package:iris/screens/faculty/faculty_directory_screen.dart';
import 'faculty_schedule_view.dart';
import 'faculty_tools_screen.dart';

class FacultyDashboard extends SmartStatefulWidget {
  final OmniBrain brain;
  final String teacherName;
  final VoidCallback onToggleTheme;
  final Future<void> Function(String mode)? onSetThemeMode;
  final String currentThemeMode;
  final ValueChanged<String>? onRoleChanged;
  final ValueChanged<String>? onBatchChanged;
  final ValueChanged<String>? onTeacherChanged;

  const FacultyDashboard({
    required this.brain,
    this.teacherName = '',
    required this.onToggleTheme,
    this.onSetThemeMode,
    this.currentThemeMode = 'system',
    this.onRoleChanged,
    this.onBatchChanged,
    this.onTeacherChanged,
    super.key,
  });

  @override
  State<FacultyDashboard> createState() => _FacultyDashboardState();
}

class _FacultyDashboardState extends SmartState<FacultyDashboard> {
  late String? _selectedTeacher;
  int? _overrideDayIndex;
  List<ClassSession> _cachedSchedule = [];
  List<FacultyProfile> _facultyProfiles = [];
  FacultyProfile? _cachedProfile;
  final GlobalKey _facultyChangeTeacherKey = GlobalKey();
  Timer? _ticker;
  int? _lastMinute;
  String? _previousNotificationHash;
  int _bottomNavIndex = 0;
  int _tabSlideDirection = 1;
  final Set<int> _mountedTabs = {0};

  final ScrollController _scrollController = ScrollController();
  final ScrollController _toolsScrollController = ScrollController();
  final ScrollController _aboutScrollController = ScrollController();
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();
  bool _isSearching = false;
  String _searchQuery = '';
  Timer? _searchDebounceTimer;

  late final VoidCallback _remoteConfigListener;

  @override
  void initState() {
    super.initState();
    AnalyticsManager().trackScreenView('faculty_dashboard');
    final allTeachers = widget.brain.allTeachers();
    if (widget.teacherName.isNotEmpty &&
        widget.teacherName != 'Faculty Member' &&
        widget.teacherName != 'Student' &&
        (allTeachers.isEmpty || allTeachers.contains(widget.teacherName))) {
      _selectedTeacher = widget.teacherName;
    } else if (AppSignals.activeTeacherName.value.isNotEmpty &&
        (allTeachers.isEmpty || allTeachers.contains(AppSignals.activeTeacherName.value))) {
      _selectedTeacher = AppSignals.activeTeacherName.value;
    } else {
      _selectedTeacher = allTeachers.isNotEmpty ? allTeachers.first : 'Faculty Member';
    }
    if (HelpdeskFacultyService.hasCachedPureTimetableProfiles) {
      _facultyProfiles = HelpdeskFacultyService.cachedPureTimetableProfiles;
    }
    _updateCachedProfile();
    _updateScheduleCache();

    _remoteConfigListener = () {
      if (mounted) {
        if (AppSignals.activeTeacherName.value.isNotEmpty &&
            AppSignals.activeTeacherName.value != _selectedTeacher) {
          _selectedTeacher = AppSignals.activeTeacherName.value;
        }
        widget.brain.memory.clearCaches();
        widget.brain.clearAllCaches();
        setState(() {
          _updateCachedProfile();
          _updateScheduleCache();
        });
        _updateForegroundServiceAndWidget();
      }
    };

    RemoteConfigService.activeAcademicPeriod.addListener(_remoteConfigListener);
    RemoteConfigService.midtermExams.addListener(_remoteConfigListener);
    RemoteConfigService.finalExams.addListener(_remoteConfigListener);
    RemoteConfigService.lastTimetableUpdateTime.addListener(_remoteConfigListener);
    AppSignals.stateRevision.addListener(_remoteConfigListener);

    _initFacultyData();
  }

  @override
  void dispose() {
    RemoteConfigService.activeAcademicPeriod.removeListener(_remoteConfigListener);
    RemoteConfigService.midtermExams.removeListener(_remoteConfigListener);
    RemoteConfigService.finalExams.removeListener(_remoteConfigListener);
    RemoteConfigService.lastTimetableUpdateTime.removeListener(_remoteConfigListener);
    AppSignals.stateRevision.removeListener(_remoteConfigListener);
    _scrollController.dispose();
    _toolsScrollController.dispose();
    _aboutScrollController.dispose();
    _searchFocusNode.dispose();
    _searchController.dispose();
    _searchDebounceTimer?.cancel();
    _ticker?.cancel();
    super.dispose();
  }

  @override
  void didUpdateWidget(FacultyDashboard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.teacherName.isNotEmpty &&
        widget.teacherName != oldWidget.teacherName &&
        widget.teacherName != _selectedTeacher) {
      setState(() {
        _selectedTeacher = widget.teacherName;
        _updateCachedProfile();
        _updateScheduleCache();
      });
      _updateForegroundServiceAndWidget();
    }
  }

  Future<void> _initFacultyData() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('faculty_user_name') ?? prefs.getString('faculty_teacher') ?? '';

    if (mounted) {
      setState(() {
        final allTeachers = widget.brain.allTeachers();
        if (saved.isNotEmpty &&
            saved != 'Faculty Member' &&
            saved != 'Student' &&
            (allTeachers.isEmpty || allTeachers.contains(saved))) {
          _selectedTeacher = saved;
        } else if (_selectedTeacher == null ||
            _selectedTeacher!.isEmpty ||
            _selectedTeacher == 'Faculty Member' ||
            _selectedTeacher == 'Student' ||
            (allTeachers.isNotEmpty && !allTeachers.contains(_selectedTeacher))) {
          if (allTeachers.isNotEmpty) {
            _selectedTeacher = allTeachers.first;
          }
        }
        if (HelpdeskFacultyService.hasCachedPureTimetableProfiles) {
          _facultyProfiles = HelpdeskFacultyService.cachedPureTimetableProfiles;
        }
        _updateCachedProfile();
        _updateScheduleCache();
      });

      // Warm-up profiles in background
      _loadFacultyProfiles();
      Future.microtask(() {
        if (mounted) {
          _updateForegroundServiceAndWidget();
        }
      });

      _lastMinute = DateTime.now().minute;
      _ticker = Timer.periodic(const Duration(seconds: 30), (_) {
        if (mounted) {
          final now = DateTime.now();
          if (_lastMinute != now.minute) {
            setState(() {
              _lastMinute = now.minute;
              _updateScheduleCache();
            });
            _updateForegroundServiceAndWidget();
          }
        }
      });
    }
  }

  Future<void> _updateForegroundServiceAndWidget() async {
    final teacher = _selectedTeacher;
    if (teacher == null || teacher.isEmpty) return;
    try {
      final prefs = await SharedPreferences.getInstance();

      await prefs.setString('faculty_teacher', teacher);
      await prefs.setString('faculty_user_name', teacher);
      if (prefs.getString('user_role') != 'faculty') return; // Don't override if user switched to student

      final academicPeriod = RemoteConfigService.activeAcademicPeriod.value;
      if (prefs.getString('timetable_data') == null) {
        final timetableData = {
          'sessions': widget.brain.memory
              .activeSessions()
              .map((s) => s.toJson())
              .toList(),
        };
        await prefs.setString('timetable_data', jsonEncode(timetableData));
      }
      if (academicPeriod != 'classes' && academicPeriod != 'ramadan') {
        String notifTitle = '';
        String notifBody = '';
        String headline = '';
        String subline = '';

        if (academicPeriod == 'sports_week') {
          notifTitle = '🏆 Sports Week active';
          notifBody = '🏅 Sports Week Mode · Active classes & gala schedule!';
          headline = 'Sports Week';
          subline = 'Active classes & gala schedule!';
        } else if (academicPeriod == 'midterms') {
          notifTitle = '✍️ Midterms active';
          notifBody = '📝 Midterm Exams Mode · Good luck!';
          headline = 'Midterm Exams';
          subline = 'Good luck!';
        } else if (academicPeriod == 'finals') {
          notifTitle = '🎓 Finals active';
          notifBody = '📝 Final Exams Mode · Finish strong!';
          headline = 'Final Exams';
          subline = 'Finish strong!';
        } else if (academicPeriod == 'vacation' || academicPeriod == 'break') {
          notifTitle = '🌴 Semester Break';
          notifBody = '🏖️ Vacation Mode · Recharge & relax!';
          headline = 'Semester Break';
          subline = 'Recharge & relax!';
        }

        await HomeWidget.saveWidgetData<bool>('flutter.is_class_live', false);
        await HomeWidget.saveWidgetData<String>('flutter.widget_headline', headline);
        await HomeWidget.saveWidgetData<String>('flutter.widget_subline', subline);
        await HomeWidget.saveWidgetData<String>('flutter.current_class_teacher', '');
        await HomeWidget.saveWidgetData<int>('flutter.progress_percentage', 0);
        await HomeWidget.saveWidgetData<String>('flutter.time_info', 'Active');
        await HomeWidget.saveWidgetData<bool>('flutter.is_urgent', false);

        await HomeWidget.updateWidget(
          name: 'ClassTrackerWidget',
          androidName: 'ClassTrackerWidget',
        );

        await prefs.setString('notification_title', notifTitle);
        await prefs.setString('notification_body', notifBody);

        if (_previousNotificationHash != '$notifTitle|$notifBody') {
          _previousNotificationHash = '$notifTitle|$notifBody';
          if (await FlutterForegroundTask.isRunningService) {
            await FlutterForegroundTask.updateService(
              notificationTitle: notifTitle,
              notificationText: notifBody,
              notificationButtons: [
                const NotificationButton(id: 'open', text: 'Open IRIS'),
              ],
            );
          }
        }
        return;
      }

      final now = DateTime.now();
      final dayIndex = now.weekday;
      final currentTime = now.hour + (now.minute / 60.0);

      final allSessions = widget.brain.scheduleForTeacher(teacher);
      final todaySessions = allSessions.where((s) => s.dayIndex == dayIndex).toList();

      final sorted = List<ClassSession>.from(todaySessions)
        ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));

      final mergedToday = <ClassSession>[];
      ClassSession? currentMerged;
      for (final session in sorted) {
        if (currentMerged == null) {
          currentMerged = session;
          continue;
        }
        if (currentMerged.isConsecutiveWith(session)) {
          currentMerged = ClassSession(
            id: currentMerged.id,
            batchKey: currentMerged.batchKey,
            dayIndex: currentMerged.dayIndex,
            startTime: currentMerged.startTime,
            endTime: session.endTime,
            subject: currentMerged.subject,
            teacher: currentMerged.teacher,
            room: currentMerged.room,
          );
        } else {
          mergedToday.add(currentMerged);
          currentMerged = session;
        }
      }
      if (currentMerged != null) {
        mergedToday.add(currentMerged);
      }

      ClassSession? currentLive;
      for (final s in mergedToday) {
        if (currentTime >= s.safeStartVal && currentTime < s.safeEndVal) {
          currentLive = s;
          break;
        }
      }

      ClassSession? nextClass;
      final upcomingToday = mergedToday.where((s) => s.safeStartVal > currentTime).toList()
        ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));

      if (upcomingToday.isNotEmpty) {
        nextClass = upcomingToday.first;
      } else {
        for (int daysAhead = 1; daysAhead <= 6; daysAhead++) {
          final targetDay = ((dayIndex + daysAhead - 1) % 7) + 1;
          final daySessions = allSessions.where((s) => s.dayIndex == targetDay).toList();
          if (daySessions.isNotEmpty) {
            final sortedDay = List<ClassSession>.from(daySessions)
              ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));
            final mergedDay = <ClassSession>[];
            ClassSession? curMerged;
            for (final s in sortedDay) {
              if (curMerged == null) { curMerged = s; continue; }
              if (curMerged.isConsecutiveWith(s)) {
                curMerged = ClassSession(
                  id: curMerged.id,
                  batchKey: curMerged.batchKey,
                  dayIndex: curMerged.dayIndex,
                  startTime: curMerged.startTime,
                  endTime: s.endTime,
                  subject: curMerged.subject,
                  teacher: curMerged.teacher,
                  room: curMerged.room,
                );
              } else {
                mergedDay.add(curMerged);
                curMerged = s;
              }
            }
            if (curMerged != null) mergedDay.add(curMerged);
            mergedDay.sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));
            nextClass = mergedDay.first;
            break;
          }
        }
      }

      String notifTitle = 'IRIS Faculty Tracker';
      String notifBody = 'No classes scheduled';

      if (currentLive != null) {
        final duration = (currentLive.safeEndVal - currentLive.safeStartVal).abs();
        final progress = ((currentTime - currentLive.safeStartVal) / duration).clamp(0.0, 1.0);
        final progressPercent = (progress * 100).toInt();

        final minutesRemaining = ((currentLive.safeEndVal - currentTime) * 60).round().clamp(0, (duration * 60).round());
        final hoursRemaining = minutesRemaining ~/ 60;
        final minsRemaining = minutesRemaining % 60;

        final timeLeft = hoursRemaining > 0
            ? '${hoursRemaining}h ${minsRemaining}m left'
            : minsRemaining > 0
                ? '${minsRemaining}m left'
                : 'Ending now';

        final remaining = mergedToday.where((s) => s.safeStartVal > currentTime).length;
        final classCount = remaining > 0 ? ' • $remaining more today' : ' • Last session today';

        final cleanSub = currentLive.subject.replaceAll('[EXAM]', '').trim();
        notifTitle = '🎓 $cleanSub • $progressPercent%';
        notifBody = '⏱️ $timeLeft (${currentLive.startTime} - ${currentLive.endTime})$classCount\n📍 ${currentLive.room} • ${currentLive.batchKey.batch}';

        final displayTime = '${currentLive.startTime} - ${currentLive.endTime}';
        await WidgetService.updateWidgetWithInsight(
          headline: currentLive.subject,
          subline: currentLive.room,
          timeInfo: displayTime,
          teacherInfo: currentLive.batchKey.batch,
          isLive: true,
          isUrgent: false,
          progressPercentage: progressPercent,
          subject: currentLive.subject,
          room: currentLive.room,
          startTime: currentLive.startTime,
          activeMode: academicPeriod,
          activeRole: 'faculty',
          batch: currentLive.batchKey.batch,
        );
      } else if (nextClass != null) {
        int daysAhead = 0;
        if (nextClass.dayIndex != dayIndex) {
          daysAhead = (nextClass.dayIndex - dayIndex + 7) % 7;
          if (daysAhead == 0) daysAhead = 7;
        }

        final totalMinutesUntil = daysAhead > 0
            ? ((24.0 - currentTime) * 60 + (daysAhead - 1) * 24 * 60 + nextClass.safeStartVal * 60).round()
            : ((nextClass.safeStartVal - currentTime) * 60).round();

        final hoursUntil = totalMinutesUntil ~/ 60;
        final minsUntil = totalMinutesUntil % 60;

        String timeUntil = '';
        String emoji = '📌';
        if (daysAhead > 0) {
          const dayNames = ['', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
          final nextDayName = dayNames[nextClass.dayIndex];
          final startHour = nextClass.safeStartVal.floor();
          final startMin = ((nextClass.safeStartVal - startHour) * 60).round();
          final displayHour = startHour > 12 ? startHour - 12 : startHour;
          final amPm = startHour >= 12 ? 'PM' : 'AM';
          timeUntil = '$nextDayName $displayHour:${startMin.toString().padLeft(2, '0')} $amPm';
          emoji = '📅';
        } else if (hoursUntil > 0) {
          timeUntil = '${hoursUntil}h ${minsUntil}m';
          emoji = '⏳';
        } else if (minsUntil > 10) {
          timeUntil = '$minsUntil min';
          emoji = '⏳';
        } else if (minsUntil > 0) {
          timeUntil = '$minsUntil min';
          emoji = '⚡';
        } else {
          timeUntil = 'now';
          emoji = '🔔';
        }

        final remainingToday = mergedToday.where((s) => s.safeStartVal > currentTime).length;

        String breakInfo = '';
        if (daysAhead == 0) {
          final prevClasses = mergedToday.where((s) => s.safeEndVal <= currentTime).toList();
          if (prevClasses.isNotEmpty) {
            prevClasses.sort((a, b) => b.safeEndVal.compareTo(a.safeEndVal));
            final breakMins = ((nextClass.safeStartVal - prevClasses.first.safeEndVal) * 60).round();
            if (breakMins > 0 && breakMins < 180) {
              breakInfo = ' · ${breakMins}m break';
            }
          }
        }

        String classInfo = daysAhead > 0
            ? 'Done for today ✓'
            : remainingToday > 1
                ? '$remainingToday classes left'
                : 'Last class today';

        notifTitle = '$emoji ${nextClass.subject} in $timeUntil';
        notifBody = '$classInfo$breakInfo\n📍 ${nextClass.room} · ${nextClass.batchKey.batch}';

        final isUrgent = daysAhead == 0 && totalMinutesUntil < 15;
        final displayTime = '${nextClass.startTime} - ${nextClass.endTime}';
        await WidgetService.updateWidgetWithInsight(
          headline: nextClass.subject,
          subline: nextClass.room,
          timeInfo: displayTime,
          teacherInfo: nextClass.batchKey.batch,
          isLive: false,
          isUrgent: isUrgent,
          progressPercentage: 0,
          subject: nextClass.subject,
          room: nextClass.room,
          startTime: nextClass.startTime,
          activeMode: academicPeriod,
          activeRole: 'faculty',
          batch: nextClass.batchKey.batch,
        );
      } else {
        if (dayIndex == 6 || dayIndex == 7) {
          notifTitle = '🎉 Weekend Mode';
          notifBody = 'No classes — enjoy your break!';
        } else {
          notifTitle = '✓ All done for today';
          notifBody = 'No more classes scheduled';
        }

        await WidgetService.updateWidgetWithInsight(
          headline: 'System Idle',
          subline: 'No active class',
          timeInfo: 'Ready',
          teacherInfo: '',
          isLive: false,
          isUrgent: false,
          progressPercentage: 0,
          activeMode: academicPeriod,
          activeRole: 'faculty',
          batch: '',
        );
      }

      await prefs.setString('notification_title', notifTitle);
      await prefs.setString('notification_body', notifBody);

      if (_previousNotificationHash != '$notifTitle|$notifBody') {
        _previousNotificationHash = '$notifTitle|$notifBody';
        if (await FlutterForegroundTask.isRunningService) {
          await FlutterForegroundTask.updateService(
            notificationTitle: notifTitle,
            notificationText: notifBody,
            notificationButtons: [
              const NotificationButton(id: 'open', text: 'Open IRIS'),
            ],
          );
        }
      }
    } catch (e) {
      debugPrint('Error in _updateForegroundServiceAndWidget: $e');
    }
  }

  void _updateScheduleCache() {
    if (_selectedTeacher == null) return;
    final now = DateTime.now();
    final dayToLoad = _overrideDayIndex ?? (now.weekday <= 5 ? now.weekday : 1);
    final mergedSchedule = widget.brain.getMergedDayScheduleForTeacher(
      _selectedTeacher!,
      dayToLoad,
    );

    final query = _searchQuery.trim().toLowerCase();
    final filteredSchedule = query.isEmpty
        ? mergedSchedule
        : mergedSchedule.where((s) =>
            s.subject.toLowerCase().contains(query) ||
            s.room.toLowerCase().contains(query) ||
            s.batchKey.batch.toLowerCase().contains(query)
          ).toList();

    _cachedSchedule = filteredSchedule;
  }

  Future<void> _addMakeupSession(ClassSession session) async {
    final duplicate = widget.brain.memory.sessions.any(
      (s) => s.id == session.id || (s.dayIndex == session.dayIndex && s.startTime == session.startTime && s.room == session.room),
    );
    if (duplicate) {
      if (!mounted) return;
      showIrisFrostedSnackBar(
        context,
        content: const Text('That makeup class is already scheduled.'),
      );
      return;
    }
    widget.brain.memory.sessions.add(session);
    widget.brain.memory.clearCaches();
    widget.brain.clearAllCaches();
    if (mounted) {
      setState(() {
        _updateScheduleCache();
      });
      _updateForegroundServiceAndWidget();
      showIrisFrostedSnackBar(
        context,
        content: Text('Makeup lecture scheduled for ${session.batchKey.batch}!'),
      );
    }
  }

  Future<void> _removeMakeupSession(ClassSession session) async {
    widget.brain.memory.sessions.removeWhere((s) => s.id == session.id);
    widget.brain.memory.clearCaches();
    widget.brain.clearAllCaches();
    if (mounted) {
      setState(() {
        _updateScheduleCache();
      });
      _updateForegroundServiceAndWidget();
      showIrisFrostedSnackBar(
        context,
        content: const Text('Makeup class cancelled.'),
      );
    }
  }

  Future<void> _loadFacultyProfiles() async {
    try {
      if (HelpdeskFacultyService.hasCachedPureTimetableProfiles) {
        if (mounted) {
          setState(() {
            _facultyProfiles = HelpdeskFacultyService.cachedPureTimetableProfiles;
            _updateCachedProfile();
          });
        }
        return;
      }

      final service = HelpdeskFacultyService();
      final enrichment = await service.fetchOfflineOnly();

      final teacher = _selectedTeacher;
      if (teacher != null && teacher.trim().isNotEmpty && _cachedProfile == null) {
        final singleMatch = HelpdeskFacultyService.matchFacultyProfile(teacher, enrichment);
        if (singleMatch != null && mounted) {
          setState(() {
            _cachedProfile = singleMatch;
          });
        }
      }

      final timetableTeachers = widget.brain.allTeachers();
      final roomsMap = widget.brain.getTeacherRoomsMap();
      final deptsMap = widget.brain.getTeacherDepartmentsMap();

      final profiles = HelpdeskFacultyService.buildPureTimetableProfiles(
        timetableTeachers: timetableTeachers,
        departmentLookup: (t) {
          final key = t.trim().toLowerCase();
          final stripped = HelpdeskFacultyService.stripDepartmentPrefix(t).trim().toLowerCase();
          return deptsMap[key] ?? deptsMap[stripped] ?? widget.brain.departmentForTeacher(t);
        },
        roomsLookup: (t) {
          final key = t.trim().toLowerCase();
          final stripped = HelpdeskFacultyService.stripDepartmentPrefix(t).trim().toLowerCase();
          final set = roomsMap[key] ?? roomsMap[stripped];
          return set?.toList() ?? const [];
        },
        enrichmentProfiles: enrichment,
      );

      if (mounted) {
        setState(() {
          _facultyProfiles = profiles;
          _updateCachedProfile();
        });
      }
    } catch (_) {}
  }

  void _updateCachedProfile() {
    final teacher = _selectedTeacher;
    if (teacher == null || teacher.trim().isEmpty) {
      _cachedProfile = null;
    } else {
      final roster = _facultyProfiles.isNotEmpty
          ? _facultyProfiles
          : HelpdeskFacultyService.cachedPureTimetableProfiles;
      _cachedProfile = HelpdeskFacultyService.matchFacultyProfile(
        teacher,
        roster,
      );
    }
  }

  FacultyProfile? _matchSelectedFacultyProfile() {
    if (_cachedProfile != null) return _cachedProfile;
    _updateCachedProfile();
    return _cachedProfile;
  }

  Future<void> _handleRefresh() async {
    IrisHaptics.refreshStart();
    await _loadFacultyProfiles();
    if (mounted) {
      setState(() {
        _updateScheduleCache();
      });
    }
    IrisHaptics.refreshSuccess();
  }

  void _openTeacherPicker({GlobalKey? originKey}) {
    pushGlassContainerMorphRoute(
      context,
      originKey: originKey ?? _facultyChangeTeacherKey,
      page: FacultyDirectoryScreen(
        brain: widget.brain,
        isSelectionMode: true,
        onTeacherSelected: (teacherName) async {
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString('faculty_user_name', teacherName);
          await prefs.setString('faculty_teacher', teacherName);
          await prefs.setString('user_role', 'faculty');
          if (mounted) {
            setState(() {
              _selectedTeacher = teacherName;
              _updateCachedProfile();
              _updateScheduleCache();
            });
          }
          widget.onTeacherChanged?.call(teacherName);
          await _updateForegroundServiceAndWidget();
        },
      ),
      accentColor: const Color(0xFF8B5CF6),
    );
  }

  String _formatDateLabel(DateTime now) {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return '${days[(now.weekday - 1) % 7]}, ${months[now.month - 1]} ${now.day}';
  }

  Future<void> _onBottomNavTap(int index) async {
    if (!mounted) return;
    final previousIndex = _bottomNavIndex;
    if (index == previousIndex) {
      IrisHaptics.navTransition(from: previousIndex, to: index);
      return;
    }

    IrisHaptics.navTransition(from: previousIndex, to: index);
    IrisHaptics.destinationOpen(destination: index);

    setState(() {
      _tabSlideDirection = index > previousIndex ? 1 : -1;
      _mountedTabs.add(index);
      _bottomNavIndex = index;
      _isSearching = false;
      _searchController.clear();
      _searchQuery = '';
      if (index == 0) {
        _updateScheduleCache();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final now = DateTime.now();
    final teacher = _selectedTeacher ?? 'Faculty Member';
    final dateLabel = _formatDateLabel(now);
    final insight = widget.brain.buildTeacherTemporalInsight(teacher, now);

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: IrisSpatialDepthWrapper(
        child: Stack(
          children: [
          RepaintBoundary(child: ObsidianPulse(isDark: isDark)),
          Positioned.fill(
            child: IrisExpressiveTabStack(
              index: _bottomNavIndex,
              slideDirection: _tabSlideDirection,
              children: [
                // Tab 0: Schedule / Home (reactive to ThemeSignals & AppSignals)
                _mountedTabs.contains(0) || _bottomNavIndex == 0
                    ? TickerMode(
                        enabled: _bottomNavIndex == 0,
                        child: ValueListenableBuilder<IrisThemeStyle>(
                          valueListenable: ThemeSignals.themeStyle,
                          builder: (context, style, _) {
                            final q = _searchQuery.trim().toLowerCase();
                            final filteredFacultySchedule = q.isEmpty
                                ? _cachedSchedule
                                : _cachedSchedule.where((s) {
                                    return s.subject.toLowerCase().contains(q) ||
                                        s.room.toLowerCase().contains(q) ||
                                        s.batchKey.batch.toLowerCase().contains(q);
                                  }).toList();
                            return FacultyScheduleView(
                              key: ValueKey('faculty_tab_schedule_${style.name}_$teacher'),
                              brain: widget.brain,
                              teacherName: teacher,
                              profile: _matchSelectedFacultyProfile(),
                              schedule: filteredFacultySchedule,
                              now: now,
                              dateLabel: dateLabel,
                              insight: insight,
                              overrideDayIndex: _overrideDayIndex,
                              onSelectDay: (dayIndex) {
                                setState(() {
                                  _overrideDayIndex = dayIndex;
                                  _updateScheduleCache();
                                });
                              },
                              onOpenTeacherPicker: _openTeacherPicker,
                              onRefresh: _handleRefresh,
                              scrollController: _scrollController,
                              onBatchChanged: widget.onBatchChanged,
                              onAddMakeupClass: _addMakeupSession,
                              onToggleTheme: widget.onToggleTheme,
                              onRoleChanged: widget.onRoleChanged,
                            );
                          },
                        ),
                      )
                    : const SizedBox.shrink(),

                // Tab 1: Faculty Portal
                _mountedTabs.contains(1) || _bottomNavIndex == 1
                    ? TickerMode(
                        enabled: _bottomNavIndex == 1,
                        child: const PortalScreen(
                          key: PageStorageKey<String>('faculty_tab_portal'),
                          url: 'https://faculty.comsats.edu.pk/Home/login?returnUrl=https://faculty.comsats.edu.pk/',
                          title: 'COMSATS Faculty Portal',
                          sessionScope: 'faculty',
                          showBackButton: false,
                        ),
                      )
                    : const SizedBox.shrink(),

                // Tab 2: Faculty Academic Tools Suite
                _mountedTabs.contains(2) || _bottomNavIndex == 2
                    ? ValueListenableBuilder<IrisThemeStyle>(
                        valueListenable: ThemeSignals.themeStyle,
                        builder: (context, style, _) {
                          return FacultyToolsScreen(
                            key: ValueKey('faculty_tab_tools_${style.name}_$teacher'),
                            brain: widget.brain,
                            memory: widget.brain.memory,
                            teacherName: teacher,
                            profile: _matchSelectedFacultyProfile(),
                            onRoleChanged: widget.onRoleChanged,
                            onBatchChanged: widget.onBatchChanged,
                            onAddMakeupClass: _addMakeupSession,
                            onRemoveMakeupClass: _removeMakeupSession,
                            onTeacherChanged: (newTeacher) {
                              AppSignals.setTeacher(newTeacher);
                              setState(() {
                                _selectedTeacher = newTeacher;
                                _updateCachedProfile();
                                _updateScheduleCache();
                              });
                              widget.onTeacherChanged?.call(newTeacher);
                              _updateForegroundServiceAndWidget();
                            },
                            scrollController: _toolsScrollController,
                          );
                        },
                      )
                    : const SizedBox.shrink(),

                // Tab 3: Settings / Iris Hub
                _mountedTabs.contains(3) || _bottomNavIndex == 3
                    ? ValueListenableBuilder<IrisThemeStyle>(
                        valueListenable: ThemeSignals.themeStyle,
                        builder: (context, style, _) {
                          return ValueListenableBuilder<int>(
                            valueListenable: AppSignals.stateRevision,
                            builder: (context, rev, _) {
                              return AboutScreen(
                                key: ValueKey('faculty_tab_about_${style.name}'),
                                memory: widget.brain.memory,
                                onRoleChanged: widget.onRoleChanged,
                                onBatchChanged: widget.onBatchChanged,
                                scrollController: _aboutScrollController,
                                onToggleTheme: widget.onToggleTheme,
                                currentThemeMode: widget.currentThemeMode,
                                onSetThemeMode: widget.onSetThemeMode,
                                onBackPressed: () => _onBottomNavTap(0),
                              );
                            },
                          );
                        },
                      )
                    : const SizedBox.shrink(),
              ],
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: ValueListenableBuilder<IrisThemeStyle>(
              valueListenable: ThemeSignals.themeStyle,
              builder: (context, style, _) {
                if (style == IrisThemeStyle.almanac) {
                  return AlmanacNavBar(
                    selectedIndex: _bottomNavIndex,
                    onDestinationSelected: _onBottomNavTap,
                  );
                }
                if (style == IrisThemeStyle.editorialAcademic) {
                  return EditorialNavBar(
                    selectedIndex: _bottomNavIndex,
                    onDestinationSelected: _onBottomNavTap,
                  );
                }
                if (style == IrisThemeStyle.notebook) {
                  return NotebookNavBar(
                    activeIndex: _bottomNavIndex,
                    onTabSelected: _onBottomNavTap,
                    isDark: isDark,
                  );
                }
                if (style == IrisThemeStyle.line) {
                  return LineNavBar(
                    activeIndex: _bottomNavIndex,
                    onTabSelected: _onBottomNavTap,
                    isDark: isDark,
                  );
                }
                if (style == IrisThemeStyle.poster) {
                  return PosterNavBar(
                    activeIndex: _bottomNavIndex,
                    onTabSelected: _onBottomNavTap,
                    isDark: isDark,
                  );
                }
                return RepaintBoundary(
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 580),
                      child: _buildBottomNavBar(isDark),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    ),
  );
  }

  Widget _buildBottomNavBar(bool isDark) {
    return IrisExpressiveNavBar(
      selectedIndex: _bottomNavIndex,
      onDestinationSelected: _onBottomNavTap,
      isFaculty: true,
      isSearchActive: _isSearching,
      onSearchToggle: (active) {
        if (active && _bottomNavIndex != 0) return;
        setState(() {
          _isSearching = active;
        });
        if (!active) {
          _searchController.clear();
          setState(() {
            _searchQuery = '';
            _updateScheduleCache();
          });
        }
      },
      searchController: _searchController,
      searchFocusNode: _searchFocusNode,
      onSearchChanged: (val) {
        _searchDebounceTimer?.cancel();
        _searchDebounceTimer = Timer(const Duration(milliseconds: 140), () {
          if (!mounted) return;
          setState(() {
            _searchQuery = val;
            _updateScheduleCache();
          });
        });
      },
      searchHint: 'Search schedule...',
      onOpenPaletteCustomizer: () => showM3EColorSelectorSheet(context),
    );
  }
}
