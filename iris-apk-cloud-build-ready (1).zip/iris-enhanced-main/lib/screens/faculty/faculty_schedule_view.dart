import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import '../../core/tokens.dart';
import '../../core/vital_theme.dart';
import '../../core/theme_signals.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../../core/animations.dart';
import '../../core/glass.dart';
import '../../core/models.dart';
import '../../core/omni_brain.dart';
import '../../services/ui_feedback.dart';
import '../../services/remote_config_service.dart';
import '../../services/helpdesk_faculty_service.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/iris_components.dart';
import 'package:iris/widgets/effects/glass_container_transform.dart';
import 'package:iris/widgets/schedule_views/vacation_sticky_header.dart';
import 'package:iris/widgets/schedule_views/exam_sticky_header.dart';
import 'package:iris/widgets/faculty/faculty_mode_views.dart';
import 'package:iris/widgets/navigation/liquid_glass_sticky_header.dart';
import 'package:iris/screens/academics/room_finder_screen.dart';
import 'package:iris/screens/academics/department_classes_screen.dart';
import 'package:iris/screens/academics/makeup_lecture_scheduler_screen.dart';
import '../portal_screen.dart';
import 'package:iris/screens/settings/announcements_screen.dart';
import 'package:iris/widgets/cards/contextual_timeline_card.dart';
import 'package:iris/widgets/schedule_views/almanac_schedule_view.dart';
import 'package:iris/widgets/schedule_views/editorial_schedule_view.dart';
import 'package:iris/widgets/schedule_views/notebook_schedule_view.dart';
import 'package:iris/widgets/schedule_views/line_schedule_view.dart';
import 'package:iris/widgets/schedule_views/poster_schedule_view.dart';

class NextLectureInfo {
  final ClassSession session;
  final bool isLive;
  final int minutesUntil;
  final int minutesRemaining;
  final String timingLabel;
  final bool isToday;

  const NextLectureInfo({
    required this.session,
    required this.isLive,
    required this.minutesUntil,
    required this.minutesRemaining,
    required this.timingLabel,
    required this.isToday,
  });
}

class FacultyScheduleView extends StatelessWidget {
  final OmniBrain brain;
  final String teacherName;
  final FacultyProfile? profile;
  final List<ClassSession> schedule;
  final DateTime now;
  final String dateLabel;
  final TemporalInsight insight;
  final int? overrideDayIndex;
  final ValueChanged<int> onSelectDay;
  final VoidCallback onOpenTeacherPicker;
  final Future<void> Function() onRefresh;
  final ScrollController scrollController;
  final ValueChanged<String>? onBatchChanged;
  final Future<void> Function(ClassSession session)? onAddMakeupClass;
  final VoidCallback? onToggleTheme;
  final ValueChanged<String>? onRoleChanged;

  const FacultyScheduleView({
    super.key,
    required this.brain,
    required this.teacherName,
    this.profile,
    required this.schedule,
    required this.now,
    required this.dateLabel,
    required this.insight,
    this.overrideDayIndex,
    required this.onSelectDay,
    required this.onOpenTeacherPicker,
    required this.onRefresh,
    required this.scrollController,
    this.onBatchChanged,
    this.onAddMakeupClass,
    this.onToggleTheme,
    this.onRoleChanged,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    return NotificationListener<ScrollNotification>(
      onNotification: (notification) {
        if (ThemeSignals.isFluidGlass) {
          if (notification is ScrollUpdateNotification) {
            final speed = notification.scrollDelta?.abs() ?? 0.0;
            final fast = speed > 10.0;
            if (IrisGlass.isFastScrolling.value != fast) {
              IrisGlass.isFastScrolling.value = fast;
            }
          } else if (notification is ScrollEndNotification) {
            if (IrisGlass.isFastScrolling.value) {
              IrisGlass.isFastScrolling.value = false;
            }
          }
        }
        return false;
      },
      child: ValueListenableBuilder<String>(
        valueListenable: RemoteConfigService.activeAcademicPeriod,
        builder: (context, period, _) {
          final isVacation = period == 'vacation' || period == 'break';
          final isMidterms = period == 'midterms';
          final isFinals = period == 'finals';
          final isExamPeriod = isMidterms || isFinals;
          final isStudentsWeek = period == 'sports_week';
          final isRamadan = period == 'ramadan';

          if (isVacation) {
            final vacationSchedule = RemoteConfigService.vacationSchedule.value;
            final resumptionDateStr = vacationSchedule?['resumption_date']?.toString() ?? '2026-09-01';
            final targetSemester = vacationSchedule?['target_semester']?.toString() ?? 'Fall 2026';

            int daysLeft = 0;
            try {
              final targetDate = DateTime.parse(resumptionDateStr);
              daysLeft = targetDate.difference(DateTime(now.year, now.month, now.day)).inDays;
            } catch (_) {
              daysLeft = 7;
            }

            return SafeArea(
              bottom: false,
              child: RefreshIndicator(
                onRefresh: onRefresh,
                color: const Color(0xFFF43F5E),
                backgroundColor: isDark ? IrisTokens.surfaceDarkElevated : Colors.white,
                child: Align(
                  alignment: Alignment.topCenter,
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 840),
                    child: CustomScrollView(
                      controller: scrollController,
                      physics: ScrollConfiguration.of(context).getScrollPhysics(context),
                      cacheExtent: 450.0,
                      slivers: [
                        SliverPersistentHeader(
                          pinned: true,
                          delegate: VacationStickyHeaderDelegate(
                            batch: 'Faculty Member',
                            daysLeft: daysLeft,
                            targetSemester: targetSemester,
                            onNoticeTap: () {},
                          ),
                        ),
                        SliverToBoxAdapter(
                          child: RepaintBoundary(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                              child: isM3
                                  ? _buildMaterialExpressiveFacultyHeader(
                                      context,
                                      isDark,
                                      cs,
                                      null,
                                    )
                                  : _buildLiquidGlassFacultyTopRow(
                                      context,
                                      isDark,
                                      cs,
                                    ),
                            ),
                          ),
                        ),
                        const SliverToBoxAdapter(child: SizedBox(height: 16)),
                        SliverToBoxAdapter(
                          child: FacultyVacationView(
                            teacherName: teacherName,
                            onRefresh: onRefresh,
                          ),
                        ),
                        const SliverToBoxAdapter(child: SizedBox(height: 110)),
                      ],
                    ),
                  ),
                ),
              ),
            );
          }

          if (isExamPeriod) {
            return SafeArea(
              bottom: false,
              child: RefreshIndicator(
                onRefresh: onRefresh,
                color: isMidterms ? const Color(0xFFF59E0B) : const Color(0xFF8B5CF6),
                backgroundColor: isDark ? IrisTokens.surfaceDarkElevated : Colors.white,
                child: Align(
                  alignment: Alignment.topCenter,
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 840),
                    child: CustomScrollView(
                      controller: scrollController,
                      physics: ScrollConfiguration.of(context).getScrollPhysics(context),
                      cacheExtent: 450.0,
                      slivers: [
                        SliverPersistentHeader(
                          pinned: true,
                          delegate: ExamStickyHeaderDelegate(
                            batch: 'Faculty',
                            period: period,
                            daysToNextExam: 0,
                            nextExamSubject: 'Official Examination Period Active',
                            totalExams: 0,
                            completedExams: 0,
                            todayExams: 0,
                            onGuidelinesTap: () {},
                            onShareTap: () {},
                            onRefresh: onRefresh,
                          ),
                        ),
                        SliverToBoxAdapter(
                          child: RepaintBoundary(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                              child: isM3
                                  ? _buildMaterialExpressiveFacultyHeader(
                                      context,
                                      isDark,
                                      cs,
                                      null,
                                    )
                                  : _buildLiquidGlassFacultyTopRow(
                                      context,
                                      isDark,
                                      cs,
                                    ),
                            ),
                          ),
                        ),
                        const SliverToBoxAdapter(child: SizedBox(height: 16)),
                        SliverToBoxAdapter(
                          child: FacultyExamPeriodView(
                            teacherName: teacherName,
                            period: period,
                            brain: brain,
                          ),
                        ),
                        const SliverToBoxAdapter(child: SizedBox(height: 110)),
                      ],
                    ),
                  ),
                ),
              ),
            );
          }

          // Regular, Ramadan & Students Week classes mode
          final activeDay = overrideDayIndex ?? now.weekday;

          if (ThemeSignals.isAlmanac) {
            return AlmanacScheduleView(
              brain: brain,
              batch: teacherName,
              isFaculty: true,
              teacherName: teacherName,
              activeDayIndex: activeDay,
              onDaySelected: onSelectDay,
              onRefresh: onRefresh,
              onOpenBatchSelector: onOpenTeacherPicker,
            );
          }

          if (ThemeSignals.isEditorialAcademic) {
            return EditorialScheduleView(
              brain: brain,
              batch: teacherName,
              isFaculty: true,
              teacherName: teacherName,
              userName: teacherName,
              activeDayIndex: activeDay,
              onDaySelected: onSelectDay,
              onRefresh: onRefresh,
              onOpenBatchSelector: onOpenTeacherPicker,
              onToggleTheme: onToggleTheme,
            );
          }

          if (ThemeSignals.isNotebook) {
            return NotebookScheduleView(
              brain: brain,
              batch: teacherName,
              isFaculty: true,
              teacherName: teacherName,
              userName: teacherName,
              scrollController: scrollController,
              activeDayIndex: activeDay,
              onDaySelected: onSelectDay,
              onRefresh: onRefresh,
              onOpenBatchSelector: onOpenTeacherPicker,
            );
          }

          if (ThemeSignals.isLine) {
            return LineScheduleView(
              brain: brain,
              batch: teacherName,
              isFaculty: true,
              teacherName: teacherName,
              userName: teacherName,
              scrollController: scrollController,
              activeDayIndex: activeDay,
              onDaySelected: onSelectDay,
              onRefresh: onRefresh,
              onOpenBatchSelector: onOpenTeacherPicker,
            );
          }

          if (ThemeSignals.isPoster) {
            return PosterScheduleView(
              brain: brain,
              batch: teacherName,
              isFaculty: true,
              teacherName: teacherName,
              userName: teacherName,
              scrollController: scrollController,
              activeDayIndex: activeDay,
              onDaySelected: onSelectDay,
              onRefresh: onRefresh,
              onOpenBatchSelector: onOpenTeacherPicker,
            );
          }

          final isThemeGreen = isRamadan || isStudentsWeek;

          // Find live or next upcoming class for unified executive header (memoized 120 FPS)
          final nextLectureInfo = _findNextOrLiveLecture(now);

          return SafeArea(
            top: isM3,
            bottom: false,
            child: RefreshIndicator(
              onRefresh: onRefresh,
              color: isThemeGreen ? const Color(0xFF10B981) : IrisTokens.brand,
              backgroundColor: isDark ? IrisTokens.surfaceDarkElevated : Colors.white,
              child: Align(
                alignment: Alignment.topCenter,
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 840),
                  child: CustomScrollView(
                    controller: scrollController,
                    physics: ScrollConfiguration.of(context).getScrollPhysics(context),
                    cacheExtent: 450.0,
                    slivers: [
                      if (isM3)
                        SliverToBoxAdapter(
                          child: RepaintBoundary(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                              child: _buildMaterialExpressiveFacultyHeader(
                                context,
                                isDark,
                                cs,
                                nextLectureInfo,
                              ),
                            ),
                          ),
                        )
                      else
                        SliverPersistentHeader(
                          pinned: true,
                          delegate: FacultyLiquidGlassStickyHeaderDelegate(
                            topPadding: MediaQuery.paddingOf(context).top,
                            teacherName: teacherName,
                            profile: profile,
                            schedule: schedule,
                            now: now,
                            dateLabel: dateLabel,
                            insight: insight,
                            nextLectureInfo: nextLectureInfo,
                            period: period,
                            isDark: isDark,
                            brain: brain,
                            onOpenTeacherPicker: onOpenTeacherPicker,
                            onToggleTheme: onToggleTheme,
                            onRefresh: onRefresh,
                            onRoleChanged: onRoleChanged,
                            onBatchChanged: onBatchChanged,
                            onAddMakeupClass: onAddMakeupClass,
                          ),
                        ),
                      const SliverToBoxAdapter(
                        child: SizedBox(height: 14),
                      ),
                      if (isStudentsWeek)
                        const SliverToBoxAdapter(
                          child: StudentsWeekInfoCard(isFaculty: true),
                        ),
                      SliverToBoxAdapter(
                        child: RepaintBoundary(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: _buildDaySelector(context, isDark, isM3, cs),
                          ),
                        ),
                      ),
                      if (nextLectureInfo == null)
                        SliverToBoxAdapter(
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                            child: ContextualTimelineCard.resolve(
                              now: now,
                              activeDayIndex: activeDay,
                              todaySessions: schedule,
                              currentClass: brain.getCurrentClassForTeacher(teacherName, now),
                              nextClass: brain.getNextClassForTeacher(teacherName, now),
                              isFaculty: true,
                              isDark: isDark,
                              teacherName: teacherName,
                            ),
                          ),
                        ),
                      SliverPadding(
                        padding: const EdgeInsets.fromLTRB(20, 16, 20, 110),
                        sliver: _buildFacultyTimelineSliver(context, isDark, isM3, cs),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  static final Map<String, (int, NextLectureInfo?)> _nextLectureCache = {};
  static (int, int)? _cachedFreeLabs;
  static Set<String>? _cachedLabRooms;

  static int _getFreeLabsCount(UniversityMemory memory, DateTime now) {
    final minuteKey = now.millisecondsSinceEpoch ~/ 60000;
    if (_cachedFreeLabs != null && _cachedFreeLabs!.$1 == minuteKey) {
      return _cachedFreeLabs!.$2;
    }
    try {
      _cachedLabRooms ??= memory.sessions
          .map((s) => FormatGuard.sanitizeRoom(s.room))
          .where((r) =>
              r.isNotEmpty &&
              r != 'TBD' &&
              r != 'TBA' &&
              (r.toLowerCase().contains('lab') || r.toLowerCase().contains('workshop')))
          .toSet();

      final currentHour = now.hour + (now.minute / 60.0);
      final occupiedLabs = memory.activeSessions()
          .where((s) {
            final cleanR = FormatGuard.sanitizeRoom(s.room);
            return s.dayIndex == now.weekday &&
                s.safeStartVal <= currentHour &&
                currentHour < s.actualEndVal &&
                _cachedLabRooms!.contains(cleanR);
          })
          .map((s) => FormatGuard.sanitizeRoom(s.room))
          .toSet();

      final count = (_cachedLabRooms!.length - occupiedLabs.length).clamp(
        0,
        _cachedLabRooms!.isEmpty ? 6 : _cachedLabRooms!.length,
      );
      _cachedFreeLabs = (minuteKey, count);
      return count;
    } catch (_) {
      return 0;
    }
  }

  static final Map<String, (int, Map<int, double>, Map<int, int>)> _dayStatsCache = {};

  (Map<int, double>, Map<int, int>) _getDayStats() {
    final minuteKey = now.millisecondsSinceEpoch ~/ 60000;
    final cacheKey = '$teacherName|$minuteKey';
    final cached = _dayStatsCache[cacheKey];
    if (cached != null && cached.$1 == minuteKey) {
      return (cached.$2, cached.$3);
    }
    if (_dayStatsCache.length > 100) _dayStatsCache.clear();

    final weeklyHours = brain.getWeeklyDayHoursForTeacher(teacherName);
    final dayCounts = <int, int>{};
    for (int d = 1; d <= 7; d++) {
      dayCounts[d] = brain.getMergedDayScheduleForTeacher(teacherName, d).length;
    }
    _dayStatsCache[cacheKey] = (minuteKey, weeklyHours, dayCounts);
    return (weeklyHours, dayCounts);
  }

  NextLectureInfo? _findNextOrLiveLecture(DateTime now) {
    final minuteKey = now.millisecondsSinceEpoch ~/ 60000;
    final cacheKey = '$teacherName|${profile?.department ?? ""}|$minuteKey';
    final cached = _nextLectureCache[cacheKey];
    if (cached != null && cached.$1 == minuteKey) {
      return cached.$2;
    }
    if (_nextLectureCache.length > 200) {
      _nextLectureCache.clear();
    }

    final allTeacherSessions = brain.scheduleForTeacher(teacherName);
    if (allTeacherSessions.isEmpty) return null;

    final validSessions = allTeacherSessions.where((s) => !s.isBreak).toList();
    if (validSessions.isEmpty) {
      _nextLectureCache[cacheKey] = (minuteKey, null);
      return null;
    }

    final currentT = now.hour + (now.minute / 60.0);

    // 1. Is there a lecture currently LIVE right now?
    for (final s in validSessions) {
      if (s.isLive(now)) {
        final remainingMins = ((s.actualEndVal - currentT) * 60).round().clamp(0, 300);
        final info = NextLectureInfo(
          session: s,
          isLive: true,
          minutesUntil: 0,
          minutesRemaining: remainingMins,
          timingLabel: remainingMins > 0 ? '$remainingMins min left' : 'Ending soon',
          isToday: true,
        );
        _nextLectureCache[cacheKey] = (minuteKey, info);
        return info;
      }
    }

    // 2. Is there an upcoming lecture later TODAY?
    final todayUpcoming = validSessions
        .where((s) => s.dayIndex == now.weekday && s.safeStartVal > currentT)
        .toList()
      ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));

    if (todayUpcoming.isNotEmpty) {
      final nextToday = todayUpcoming.first;
      final minsUntil = ((nextToday.safeStartVal - currentT) * 60).round().clamp(0, 1440);
      String label;
      if (minsUntil <= 60) {
        label = minsUntil <= 1 ? 'Starting now' : 'Starts in $minsUntil min';
      } else {
        final hours = minsUntil ~/ 60;
        final mins = minsUntil % 60;
        label = mins > 0 ? 'In ${hours}h ${mins}m' : 'In ${hours}h';
      }
      final info = NextLectureInfo(
        session: nextToday,
        isLive: false,
        minutesUntil: minsUntil,
        minutesRemaining: 0,
        timingLabel: label,
        isToday: true,
      );
      _nextLectureCache[cacheKey] = (minuteKey, info);
      return info;
    }

    // 3. Find next upcoming class in future days (tomorrow, day after, etc.)
    for (int offset = 1; offset <= 7; offset++) {
      final targetDay = ((now.weekday - 1 + offset) % 7) + 1;
      final daySessions = validSessions
          .where((s) => s.dayIndex == targetDay)
          .toList()
        ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));

      if (daySessions.isNotEmpty) {
        final nextSession = daySessions.first;
        final dayName = _dayShortName(targetDay);
        final label = offset == 1
            ? 'Tomorrow · ${nextSession.startTime}'
            : '$dayName · ${nextSession.startTime}';
        final info = NextLectureInfo(
          session: nextSession,
          isLive: false,
          minutesUntil: -1,
          minutesRemaining: 0,
          timingLabel: label,
          isToday: false,
        );
        _nextLectureCache[cacheKey] = (minuteKey, info);
        return info;
      }
    }

    _nextLectureCache[cacheKey] = (minuteKey, null);
    return null;
  }

  String _dayShortName(int dayIndex) {
    switch (dayIndex) {
      case 1:
        return 'Mon';
      case 2:
        return 'Tue';
      case 3:
        return 'Wed';
      case 4:
        return 'Thu';
      case 5:
        return 'Fri';
      case 6:
        return 'Sat';
      case 7:
        return 'Sun';
      default:
        return '';
    }
  }

  String _getInitials(String? name) {
    if (name == null || name.trim().isEmpty) return 'FM';
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.length == 1) {
      if (parts[0].length >= 2) {
        return parts[0].substring(0, 2).toUpperCase();
      }
      return parts[0].toUpperCase();
    }
    final first = parts.first.isNotEmpty
        ? parts.first.substring(0, 1).toUpperCase()
        : '';
    final last = parts.last.isNotEmpty
        ? parts.last.substring(0, 1).toUpperCase()
        : '';
    return '$first$last';
  }

  String _getSmartGreeting(int hour) {
    if (hour >= 5 && hour < 12) return 'MORNING';
    if (hour >= 12 && hour < 17) return 'AFTERNOON';
    if (hour >= 17 && hour < 21) return 'EVENING';
    return 'NIGHT';
  }

  Widget _buildMaterialExpressiveFacultyHeader(
    BuildContext context,
    bool isDark,
    ColorScheme cs,
    NextLectureInfo? nextLecture,
  ) {
    final dept = profile?.department.isNotEmpty == true
        ? profile!.department
        : 'Department of Computer Science';
    final designation = profile?.designation.isNotEmpty == true
        ? profile!.designation
        : 'Tenured Professor';
    final initials = _getInitials(teacherName);
    final smartGreeting = _getSmartGreeting(now.hour);

    // Compute today's sessions and live room metrics
    final todayDayIndex = overrideDayIndex ?? now.weekday;
    final todaySessions = schedule.where((s) => s.dayIndex == todayDayIndex).toList();

    // Real campus free labs computation (memoized 120 FPS lookup)
    final freeLabsCount = _getFreeLabsCount(brain.memory, now);

    final isLive = nextLecture?.isLive == true;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        // 1. Spacious Executive Google Pixel Top App Bar
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Squircle Avatar with Verified Gold Badge & Menu
            IrisGlassMenu(
              autoAdjustToScreen: true,
              menuPadding: const EdgeInsets.all(14),
              menuWidth: 230,
              menuBorderRadius: 24.0,
              itemBorderRadius: 18.0,
              triggerBuilder: (menuContext, toggleMenu) {
                return ExpressiveInteractivePress(
                  onTap: toggleMenu,
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              const Color(0xFF0F766E),
                              const Color(0xFF0D9488),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: const Color(0xFF2DD4BF).withValues(
                              alpha: isDark ? 0.40 : 0.25,
                            ),
                            width: 1.2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(
                                alpha: isDark ? 0.25 : 0.06,
                              ),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Center(
                          child: Text(
                            initials,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 18,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        right: -2,
                        bottom: -2,
                        child: Container(
                          width: 18,
                          height: 18,
                          decoration: BoxDecoration(
                            color: const Color(0xFFF59E0B),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: isDark ? cs.surface : Colors.white,
                              width: 2.0,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFFF59E0B).withValues(alpha: 0.5),
                                blurRadius: 4,
                              ),
                            ],
                          ),
                          child: const Center(
                            child: Icon(
                              Icons.check_rounded,
                              size: 11,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
              items: [
                lgw.GlassMenuItem(
                  title: 'Faculty Mode',
                  titleStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13.5,
                    color: cs.primary,
                  ),
                  isSelected: true,
                  icon: const Icon(Icons.badge_rounded, size: 18),
                  onTap: () {},
                ),
                lgw.GlassMenuItem(
                  title: 'Student Mode',
                  titleStyle: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 13.5,
                    color: isDark ? Colors.white70 : Colors.black87,
                  ),
                  isSelected: false,
                  icon: const Icon(Icons.school_rounded, size: 18),
                  onTap: () {
                    onRoleChanged?.call('student');
                  },
                ),
                const lgw.GlassMenuDivider(),
                lgw.GlassMenuItem(
                  title: 'Select Faculty Profile',
                  titleStyle: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 13.5,
                    color: isDark ? Colors.white70 : Colors.black87,
                  ),
                  icon: const Icon(Icons.people_outline_rounded, size: 18),
                  onTap: () {
                    onOpenTeacherPicker();
                  },
                ),
                const lgw.GlassMenuDivider(),
                lgw.GlassMenuItem(
                  title: 'Switch to Liquid Glass',
                  titleStyle: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 13.5,
                    color: VitalTokens.purple,
                  ),
                  icon: const Icon(
                    Icons.water_drop_rounded,
                    size: 18,
                    color: VitalTokens.purple,
                  ),
                  onTap: () {
                    ThemeSignals.switchThemeWithMorph(
                      context,
                      style: IrisThemeStyle.fluidGlass,
                    );
                  },
                ),
              ],
            ),
            const SizedBox(width: 14),
            // Greeting, Teacher Name & Affiliation Pill Chip
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Good $smartGreeting,',
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w600,
                      color: cs.onSurface.withValues(alpha: 0.85),
                      letterSpacing: -0.2,
                    ),
                  ),
                  Text(
                    teacherName,
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -0.5,
                      color: cs.onSurface,
                      height: 1.15,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 5),
                  ExpressiveInteractivePress(
                    onTap: () {
                      IrisHaptics.chipSelect();
                      onOpenTeacherPicker();
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 9.0,
                        vertical: 3.5,
                      ),
                      decoration: BoxDecoration(
                        color: cs.surfaceContainerHighest.withValues(
                          alpha: isDark ? 0.75 : 0.85,
                        ),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: cs.outlineVariant.withValues(
                            alpha: isDark ? 0.35 : 0.45,
                          ),
                          width: 1.0,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Flexible(
                            child: Text(
                              '$dept • $designation',
                              style: TextStyle(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w700,
                                color: cs.onSurfaceVariant,
                                letterSpacing: 0.1,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          const SizedBox(width: 3),
                          Icon(
                            Icons.arrow_forward_ios_rounded,
                            size: 7.5,
                            color: cs.onSurfaceVariant.withValues(alpha: 0.6),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            // Action Cluster: Notifications Bell & Filter Trigger
            ExpressiveInteractivePress(
              onTap: () {
                IrisHaptics.actionSoft();
                pushGlassContainerMorphRoute(
                  context,
                  page: const AnnouncementsScreen(),
                  accentColor: cs.primary,
                );
              },
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: cs.surfaceContainerHigh,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: cs.outlineVariant.withValues(
                          alpha: isDark ? 0.35 : 0.50,
                        ),
                        width: 1.0,
                      ),
                    ),
                    child: Center(
                      child: Icon(
                        Icons.notifications_none_rounded,
                        size: 20,
                        color: cs.onSurfaceVariant,
                      ),
                    ),
                  ),
                  ValueListenableBuilder<List<Map<String, dynamic>>>(
                    valueListenable: RemoteConfigService.liveNotices,
                    builder: (context, notices, _) {
                      return ValueListenableBuilder<Map<String, dynamic>?>(
                        valueListenable: RemoteConfigService.liveAnnouncement,
                        builder: (context, broadcast, _) {
                          final hasNotices = notices.isNotEmpty ||
                              (broadcast != null && broadcast['enabled'] == true);
                          if (!hasNotices) return const SizedBox.shrink();
                          return Positioned(
                            top: 2,
                            right: 2,
                            child: Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: cs.error,
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: isDark ? cs.surface : Colors.white,
                                  width: 1.5,
                                ),
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            ExpressiveInteractivePress(
              onTap: () {
                IrisHaptics.actionSoft();
                onOpenTeacherPicker();
              },
              child: Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: cs.surfaceContainerHigh,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: cs.outlineVariant.withValues(
                      alpha: isDark ? 0.35 : 0.50,
                    ),
                    width: 1.0,
                  ),
                ),
                child: Center(
                  child: Icon(
                    Icons.tune_rounded,
                    size: 20,
                    color: cs.onSurfaceVariant,
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        // 2. Spacious Hero "Next Teaching Session" Card
        ExpressiveInteractivePress(
          onTap: () {
            if (nextLecture != null) {
              IrisHaptics.actionSoft();
              pushGlassContainerMorphRoute(
                context,
                page: DepartmentClassesScreen(
                  memory: brain.memory,
                  brain: brain,
                  currentBatch: nextLecture.session.batchKey.batch,
                  showBatchShortcut: true,
                  showBackButton: true,
                  onBatchChanged: onBatchChanged,
                  onRoleChanged: onRoleChanged,
                ),
                accentColor: const Color(0xFF10B981),
              );
            }
          },
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF0D2523) : const Color(0xFFE8F7F4),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: const Color(0xFF10B981).withValues(
                  alpha: isDark ? 0.35 : 0.40,
                ),
                width: 1.0,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: isDark ? 0.32 : 0.08),
                  blurRadius: 18,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                // Top Row: "Next Teaching Session" & Live Status Badge
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      'Next Teaching Session',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.5,
                        color: isDark ? const Color(0xFF5EEAD4) : const Color(0xFF0F766E),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFF10B981).withValues(alpha: isDark ? 0.25 : 0.15),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: const Color(0xFF10B981).withValues(alpha: 0.40),
                          width: 1.0,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 6,
                            height: 6,
                            decoration: const BoxDecoration(
                              color: Color(0xFF10B981),
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 5),
                          Text(
                            isLive
                                ? 'Live Now'
                                : (nextLecture != null
                                    ? 'Live In ${nextLecture.minutesUntil} Min'
                                    : 'Done For Today'),
                            style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: Color(0xFF10B981),
                              letterSpacing: 0.2,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                // Course Subject Title
                Text(
                  nextLecture != null
                      ? nextLecture.session.subject
                      : 'No More Teaching Sessions Today',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -0.4,
                    color: isDark ? Colors.white : const Color(0xFF0F172A),
                    height: 1.2,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 8),
                // Time & Room
                Row(
                  children: [
                    Icon(
                      Icons.schedule_rounded,
                      size: 14,
                      color: isDark ? const Color(0xFF99F6E4) : const Color(0xFF0F766E),
                    ),
                    const SizedBox(width: 5),
                    Text(
                      nextLecture != null
                          ? '${nextLecture.session.startTime} - ${nextLecture.session.endTime}'
                          : 'Enjoy your free time',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: isDark ? Colors.white70 : const Color(0xFF334155),
                      ),
                    ),
                    if (nextLecture != null) ...[
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 7),
                        child: Text(
                          '•',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: isDark ? Colors.white38 : Colors.black38,
                          ),
                        ),
                      ),
                      Icon(
                        Icons.meeting_room_rounded,
                        size: 14,
                        color: isDark ? const Color(0xFF99F6E4) : const Color(0xFF0F766E),
                      ),
                      const SizedBox(width: 4),
                      Flexible(
                        child: Text(
                          nextLecture.session.subject.toLowerCase().contains('lab')
                              ? 'Lab ${nextLecture.session.room}'
                              : 'Room ${nextLecture.session.room}',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: isDark ? Colors.white : const Color(0xFF0F172A),
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ],
                ),
                if (nextLecture != null) ...[
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          'Section: ${nextLecture.session.displayBatch}',
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                            color: isDark ? Colors.white60 : const Color(0xFF475569),
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (nextLecture.session.isCombinedLecture) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFF10B981).withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                              color: const Color(0xFF10B981).withValues(alpha: 0.35),
                              width: 0.8,
                            ),
                          ),
                          child: const Text(
                            'COMBINED',
                            style: TextStyle(
                              fontSize: 9.5,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.5,
                              color: Color(0xFF10B981),
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
                const SizedBox(height: 16),
                // Action Buttons Row
                Row(
                  children: [
                    Expanded(
                      child: ExpressiveInteractivePress(
                        onTap: () {
                          IrisHaptics.actionMedium();
                          pushGlassContainerMorphRoute(
                            context,
                            page: const PortalScreen(
                              url: 'https://faculty.comsats.edu.pk/Home/login?returnUrl=https://faculty.comsats.edu.pk/',
                              title: 'CUOnline Faculty Portal',
                              sessionScope: 'faculty',
                              showBackButton: true,
                            ),
                            accentColor: const Color(0xFF10B981),
                          );
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                            color: const Color(0xFF10B981),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.check_rounded, size: 16, color: Colors.white),
                              SizedBox(width: 6),
                              Text(
                                'Mark Attendance',
                                style: TextStyle(
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: ExpressiveInteractivePress(
                        onTap: () {
                          IrisHaptics.actionMedium();
                          pushGlassContainerMorphRoute(
                            context,
                            page: RoomFinderScreen(memory: brain.memory),
                            accentColor: cs.primary,
                          );
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                            color: isDark
                                ? Colors.white.withValues(alpha: 0.10)
                                : Colors.black.withValues(alpha: 0.06),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: isDark
                                  ? Colors.white.withValues(alpha: 0.15)
                                  : Colors.black.withValues(alpha: 0.12),
                              width: 1.0,
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.radar_rounded,
                                size: 16,
                                color: isDark ? Colors.white : const Color(0xFF0F172A),
                              ),
                              const SizedBox(width: 6),
                              Text(
                                'Free Lab Radar',
                                style: TextStyle(
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w800,
                                  color: isDark ? Colors.white : const Color(0xFF0F172A),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        // 3. 3-Column Metric Bento Cards
        Row(
          children: [
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
                decoration: BoxDecoration(
                  color: isDark ? cs.surfaceContainer : cs.surfaceContainerHigh,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.50),
                    width: 1.0,
                  ),
                ),
                child: Column(
                  children: [
                    Text(
                      '${todaySessions.length}',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        color: cs.onSurface,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Classes Today',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: cs.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
                decoration: BoxDecoration(
                  color: isDark ? cs.surfaceContainer : cs.surfaceContainerHigh,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.50),
                    width: 1.0,
                  ),
                ),
                child: Column(
                  children: [
                    Text(
                      '$freeLabsCount',
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF10B981),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Free Labs',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: cs.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildLiquidGlassFacultyTopRow(
    BuildContext context,
    bool isDark,
    ColorScheme cs,
  ) {
    final dept = profile?.department.isNotEmpty == true
        ? profile!.department
        : 'Faculty Hub';
    final location = profile?.location.isNotEmpty == true && profile!.location != 'Not Specified'
        ? (profile!.location.toLowerCase().contains('room') || profile!.location.toLowerCase().contains('cabin')
            ? profile!.location
            : 'Cabin ${profile!.location}')
        : 'Campus Office';
    final designation = profile?.designation.isNotEmpty == true
        ? profile!.designation
        : 'Faculty Member';
    final initials = _getInitials(teacherName);
    final greetingWord = _getSmartGreeting(now.hour);
    final greetingText = 'GOOD $greetingWord';
    final primaryTextColor = isDark ? Colors.white : const Color(0xFF0F172A);
    final secondaryTextColor = isDark ? Colors.white.withValues(alpha: 0.78) : const Color(0xFF475569);

    return GlassCard(
      borderRadius: 24,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      enableOverlay: true,
      child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Circular Avatar with Menu
            IrisGlassMenu(
              autoAdjustToScreen: true,
              menuPadding: const EdgeInsets.all(16),
              menuWidth: 230,
              menuBorderRadius: 28.0,
              itemBorderRadius: 20.0,
              settings: IrisGlass.widgetsSettings(
                context,
                blur: 16.0,
                ambientStrength: 0.7,
                lightAngle: 0.15 * math.pi,
                thickness: 18.0,
              ),
              triggerBuilder: (menuContext, toggleMenu) {
                return GestureDetector(
                  onTap: toggleMenu,
                  child: Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.95),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.12),
                          blurRadius: 10,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Center(
                      child: Text(
                        initials,
                        style: const TextStyle(
                          color: Color(0xFF1E293B),
                          fontWeight: FontWeight.w900,
                          fontSize: 17,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ),
                );
              },
              items: [
                lgw.GlassMenuItem(
                  title: 'Faculty Mode',
                  titleStyle: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: Color(0xFF8B5CF6),
                  ),
                  isSelected: true,
                  icon: const Icon(Icons.badge_rounded, size: 18),
                  onTap: () {},
                ),
                lgw.GlassMenuItem(
                  title: 'Student Mode',
                  titleStyle: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: isDark ? Colors.white.withValues(alpha: 0.9) : Colors.black87,
                  ),
                  isSelected: false,
                  icon: const Icon(Icons.school_rounded, size: 18),
                  onTap: () {
                    onRoleChanged?.call('student');
                  },
                ),
                const lgw.GlassMenuDivider(),
                lgw.GlassMenuItem(
                  title: 'Select Faculty Profile',
                  titleStyle: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: isDark ? Colors.white.withValues(alpha: 0.9) : Colors.black87,
                  ),
                  icon: const Icon(Icons.people_outline_rounded, size: 18),
                  onTap: () {
                    onOpenTeacherPicker();
                  },
                ),
                const lgw.GlassMenuDivider(),
                lgw.GlassMenuItem(
                  title: 'Material You Theme',
                  titleStyle: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: isDark ? Colors.white.withValues(alpha: 0.9) : Colors.black87,
                  ),
                  icon: const Icon(
                    Icons.auto_awesome_rounded,
                    size: 18,
                    color: VitalTokens.cyan,
                  ),
                  onTap: () {
                    ThemeSignals.switchThemeWithMorph(
                      context,
                      style: IrisThemeStyle.materialYou,
                    );
                  },
                ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    greetingText,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: primaryTextColor.withValues(alpha: 0.75),
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    teacherName,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -0.3,
                      color: primaryTextColor,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 1),
                  Text(
                    '$designation · $dept',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: secondaryTextColor,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            InkWell(
              onTap: () {
                IrisHaptics.actionSoft();
                pushGlassContainerMorphRoute(
                  context,
                  page: const AnnouncementsScreen(),
                  accentColor: const Color(0xFF10B981),
                );
              },
              borderRadius: BorderRadius.circular(20),
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.16),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.28),
                        width: 1.2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.08),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Center(
                      child: Icon(
                        Icons.notifications_none_rounded,
                        size: 18,
                        color: primaryTextColor,
                      ),
                    ),
                  ),
                  ValueListenableBuilder<List<Map<String, dynamic>>>(
                    valueListenable: RemoteConfigService.liveNotices,
                    builder: (context, notices, _) {
                      return ValueListenableBuilder<Map<String, dynamic>?>(
                        valueListenable: RemoteConfigService.liveAnnouncement,
                        builder: (context, broadcast, _) {
                          final hasNotices = notices.isNotEmpty ||
                              (broadcast != null && broadcast['enabled'] == true);
                          if (!hasNotices) return const SizedBox.shrink();
                          return Positioned(
                            top: 2,
                            right: 2,
                            child: Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: const Color(0xFFEF4444),
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Colors.white,
                                  width: 1.5,
                                ),
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            if (onToggleTheme != null)
              InkWell(
                onTap: () {
                  IrisHaptics.actionMedium();
                  onToggleTheme!();
                },
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.16),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.28),
                      width: 1.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.08),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Center(
                    child: Icon(
                      isDark ? Icons.light_mode_rounded : Icons.dark_mode_rounded,
                      size: 18,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 6),
        Padding(
          padding: const EdgeInsets.only(left: 60.0),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Cabin Chip
                ExpressiveInteractivePress(
                  onTap: () {
                    IrisHaptics.chipSelect();
                    pushGlassContainerMorphRoute(
                      context,
                      page: RoomFinderScreen(memory: brain.memory),
                      accentColor: const Color(0xFF00E5FF),
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.92),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.white, width: 1.2),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.08),
                          blurRadius: 6,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.location_on_rounded,
                          size: 12,
                          color: Color(0xFF0F172A),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          location,
                          style: const TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF0F172A),
                            letterSpacing: 0.2,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // Duty Status Beacon
                _buildSmartDutyBadge(isDark, false, cs),
                const SizedBox(width: 8),
                // Switch Teacher Button
                ExpressiveInteractivePress(
                  onTap: () {
                    IrisHaptics.selectionClick();
                    onOpenTeacherPicker();
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.18),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.40),
                        width: 1.0,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.08),
                          blurRadius: 6,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.swap_horiz_rounded,
                          size: 13,
                          color: primaryTextColor,
                        ),
                        SizedBox(width: 4),
                        Text(
                          'Switch Faculty',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: primaryTextColor,
                            letterSpacing: 0.2,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
      ),
    );
  }

  // ignore: unused_element
  Widget _buildLiquidGlassFacultyLiveWidget(
    BuildContext context,
    bool isDark,
    ColorScheme cs,
    NextLectureInfo? nextLecture,
  ) {
    if (nextLecture == null) {
      final period = RemoteConfigService.activeAcademicPeriod.value;
      final String topLabel;
      final String headline;
      final String subline;

      if (period == 'vacation') {
        topLabel = 'Semester Vacation · Academic Recess';
        headline = 'Recess Period Active ☀️';
        subline = 'Campus will resume regular schedule on resumption date.';
      } else if (period == 'midterms' || period == 'finals') {
        topLabel = 'Official Examination Period';
        headline = 'Exam Invigilation & Review 📝';
        subline = 'Check examination invigilation rosters and grading duties.';
      } else {
        topLabel = 'Free Schedule · All done for today';
        headline = 'No classes scheduled today 🎉';
        subline = 'Great time for office hours, research, or student consultations.';
      }

      return ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: IrisGlass.backdropFilter(
          sigmaX: IrisGlass.adaptiveBlur(context, 16.0),
          sigmaY: IrisGlass.adaptiveBlur(context, 16.0),
          child: Container(
            decoration: BoxDecoration(
              color: isDark
                  ? const Color(0xFF02160F).withValues(alpha: 0.65)
                  : Colors.white.withValues(alpha: 0.52),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.28),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.12),
                  blurRadius: 16,
                  spreadRadius: -2,
                ),
              ],
            ),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  topLabel,
                  style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600,
                    color: isDark ? Colors.white70 : const Color(0xFF334155),
                    letterSpacing: 0.2,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  headline,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -0.3,
                    height: 1.22,
                    color: isDark ? Colors.white : const Color(0xFF0F172A),
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  subline,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    height: 1.4,
                    color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.55),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    final s = nextLecture.session;
    final isLive = nextLecture.isLive;
    final statusText = isLive
        ? 'Ongoing Lecture · ${nextLecture.timingLabel}'
        : 'Upcoming Lecture · ${nextLecture.timingLabel}';
    final accentGreen = const Color(0xFF34D399);

    return GestureDetector(
      onTap: () => _showSessionDetailsSheet(context, s, isDark, false, cs),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: IrisGlass.backdropFilter(
          sigmaX: IrisGlass.adaptiveBlur(context, 16.0),
          sigmaY: IrisGlass.adaptiveBlur(context, 16.0),
          child: Container(
            decoration: BoxDecoration(
              color: isDark
                  ? const Color(0xFF02160F).withValues(alpha: 0.65)
                  : Colors.white.withValues(alpha: 0.52),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color: isLive
                    ? accentGreen.withValues(alpha: isDark ? 0.85 : 0.90)
                    : Colors.white.withValues(alpha: 0.28),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: (isLive ? accentGreen : Colors.black).withValues(alpha: isLive ? 0.25 : 0.12),
                  blurRadius: 16,
                  spreadRadius: -2,
                ),
              ],
            ),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                // 1. Status line
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (isLive) ...[
                      Container(
                        width: 6.5,
                        height: 6.5,
                        decoration: BoxDecoration(
                          color: accentGreen,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: accentGreen,
                              blurRadius: 4,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 6),
                    ],
                    Text(
                      statusText,
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                        color: isLive
                            ? accentGreen
                            : (isDark ? Colors.white70 : const Color(0xFF334155)),
                        letterSpacing: 0.2,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
                const SizedBox(height: 6),

                // 2. Bold Subject Title
                Text(
                  s.subject,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -0.3,
                    height: 1.22,
                    color: isDark ? Colors.white : const Color(0xFF0F172A),
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 5),

                // 3. Schedule Time, Room & Teaching Batch
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        '${s.startTime} - ${s.endTime} · Room ${s.room} · ${s.displayBatch}',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.65),
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (s.isCombinedLecture) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                        decoration: BoxDecoration(
                          color: const Color(0xFF10B981).withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(
                            color: const Color(0xFF10B981).withValues(alpha: 0.35),
                            width: 0.8,
                          ),
                        ),
                        child: const Text(
                          'COMBINED',
                          style: TextStyle(
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.5,
                            color: Color(0xFF10B981),
                          ),
                        ),
                      ),
                    ],
                    const SizedBox(width: 6),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      size: 12,
                      color: isDark ? Colors.white54 : Colors.black38,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSmartDutyBadge(bool isDark, bool isM3, ColorScheme cs) {
    Color badgeColor;
    String badgeText;
    IconData badgeIcon;

    final currentTime = now.hour + (now.minute / 60.0);
    final isToday = (overrideDayIndex == null || overrideDayIndex == now.weekday);

    if (isToday && insight.isLive) {
      badgeColor = const Color(0xFF10B981);
      badgeText = insight.timeInfo != null ? 'Teaching · ${insight.timeInfo}' : 'Teaching Now';
      badgeIcon = Icons.sensors_rounded;
    } else if (isToday && insight.headline == 'Break') {
      badgeColor = const Color(0xFF00E5FF);
      badgeText = insight.timeInfo != null ? 'Break · ${insight.timeInfo}' : 'On Break';
      badgeIcon = Icons.coffee_rounded;
    } else if (isToday && insight.isUrgent) {
      badgeColor = const Color(0xFFF59E0B);
      badgeText = 'Starting Soon';
      badgeIcon = Icons.bolt_rounded;
    } else if (isToday && schedule.isNotEmpty && schedule.any((s) => s.safeStartVal > currentTime)) {
      badgeColor = const Color(0xFF8B5CF6);
      badgeText = 'Next Class Today';
      badgeIcon = Icons.schedule_rounded;
    } else if (isToday && schedule.isNotEmpty) {
      badgeColor = isDark ? Colors.white60 : Colors.black54;
      badgeText = 'Day Complete ✓';
      badgeIcon = Icons.check_circle_outline_rounded;
    } else {
      badgeColor = const Color(0xFF10B981);
      badgeText = 'Free Day';
      badgeIcon = Icons.spa_rounded;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: badgeColor.withValues(alpha: isDark ? 0.18 : 0.12),
        borderRadius: BorderRadius.circular(999),
        border: isM3
            ? Border.all(
                color: badgeColor.withValues(alpha: isDark ? 0.35 : 0.25),
                width: 1.0,
              )
            : null,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(badgeIcon, size: 11, color: badgeColor),
          const SizedBox(width: 4),
          Text(
            badgeText,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              color: badgeColor,
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDaySelector(
    BuildContext context,
    bool isDark,
    bool isM3,
    ColorScheme cs,
  ) {
    final stats = _getDayStats();
    final weeklyHours = stats.$1;
    final dayCounts = stats.$2;
    final currentDay = overrideDayIndex ?? (now.weekday <= 5 ? now.weekday : 1);
    final hasSaturday = (weeklyHours[6] ?? 0.0) > 0;
    final hasSunday = (weeklyHours[7] ?? 0.0) > 0;
    final days = [
      {'name': 'Mon', 'day': 1},
      {'name': 'Tue', 'day': 2},
      {'name': 'Wed', 'day': 3},
      {'name': 'Thu', 'day': 4},
      {'name': 'Fri', 'day': 5},
      if (hasSaturday) {'name': 'Sat', 'day': 6},
      if (hasSunday) {'name': 'Sun', 'day': 7},
    ];

    return SizedBox(
      height: 42,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: days.length,
        separatorBuilder: (_, _) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final dayInfo = days[index];
          final dayIndex = dayInfo['day'] as int;
          final isSelected = currentDay == dayIndex;
          final isToday = dayIndex == now.weekday;
          final count = dayCounts[dayIndex] ?? 0;
          final totalHours = weeklyHours[dayIndex] ?? 0.0;
          final hoursFormatted = totalHours > 0
              ? ' (${totalHours.toStringAsFixed(totalHours % 1 == 0 ? 0 : 1)}h)'
              : '';
          final countLabel = count == 0 ? 'Free' : '$count$hoursFormatted';
          final label = '${dayInfo['name']} · $countLabel';

          return ExpressiveInteractivePress(
            onTap: () {
              IrisHaptics.chipSelect();
              onSelectDay(dayIndex);
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: isSelected
                    ? (isM3 ? cs.primary : const Color(0xFF00E5FF))
                    : (isM3
                        ? cs.surfaceContainerHigh
                        : (isDark
                            ? Colors.white.withValues(alpha: 0.08)
                            : Colors.black.withValues(alpha: 0.05))),
                borderRadius: BorderRadius.circular(999),
                border: Border.all(
                  color: isSelected
                      ? (isM3 ? cs.primary : const Color(0xFF00E5FF))
                      : (isToday
                          ? const Color(0xFF10B981).withValues(alpha: isDark ? 0.6 : 0.5)
                          : (isM3
                              ? cs.outlineVariant.withValues(alpha: isDark ? 0.3 : 0.5)
                              : (isDark
                                  ? Colors.white.withValues(alpha: 0.14)
                                  : Colors.black.withValues(alpha: 0.08)))),
                  width: isToday && !isSelected ? 1.5 : 1.0,
                ),
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                          color: (isM3 ? cs.primary : const Color(0xFF00E5FF)).withValues(alpha: 0.30),
                          blurRadius: 10,
                          offset: const Offset(0, 2),
                        ),
                      ]
                    : null,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (isToday) ...[
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: isSelected
                            ? (isM3 ? cs.onPrimary : Colors.black)
                            : const Color(0xFF10B981),
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                  ],
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: isSelected ? FontWeight.w900 : FontWeight.w700,
                      color: isSelected
                          ? (isM3 ? cs.onPrimary : Colors.black87)
                          : (isM3
                              ? cs.onSurfaceVariant
                              : (isDark ? Colors.white.withValues(alpha: 0.85) : const Color(0xFF334155))),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildFacultyTimelineSliver(
    BuildContext context,
    bool isDark,
    bool isM3,
    ColorScheme cs,
  ) {
    final activeDay = overrideDayIndex ?? (schedule.isNotEmpty ? schedule.first.dayIndex : (now.weekday <= 5 ? now.weekday : 1));
    final daysNames = ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    final dayName = activeDay >= 1 && activeDay <= 7 ? daysNames[activeDay] : 'Selected Day';

    if (schedule.isEmpty) {
      return SliverToBoxAdapter(
        child: RepaintBoundary(
          key: ValueKey('faculty_empty_timeline_$activeDay'),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 4),
            child: GlassCard(
              borderRadius: 24,
              padding: const EdgeInsets.all(24),
              enableOverlay: true,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF10B981).withValues(alpha: 0.12),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.event_available_rounded, size: 36, color: Color(0xFF10B981)),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    'No Lectures on $dayName',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 16,
                      color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'You have no scheduled teaching slots on this day. Great time for office hours, research, student consultations, or scheduling makeup classes.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 12,
                      height: 1.4,
                      color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                    ),
                  ),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () {
                            IrisHaptics.chipSelect();
                            pushGlassContainerMorphRoute(
                              context,
                              page: RoomFinderScreen(memory: brain.memory),
                              accentColor: const Color(0xFF00E5FF),
                            );
                          },
                          icon: const Icon(Icons.meeting_room_rounded, size: 14),
                          label: const Text('Find Rooms', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                          style: OutlinedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () {
                            IrisHaptics.chipSelect();
                            pushGlassContainerMorphRoute(
                              context,
                              page: MakeupLectureScheduler(
                                memory: brain.memory,
                                brain: brain,
                                batch: '',
                                teacherName: teacherName,
                                showDock: false,
                                onAddMakeupClass: onAddMakeupClass ?? (_) async {},
                                onRoleChanged: onRoleChanged,
                                onBatchChanged: onBatchChanged,
                              ),
                              accentColor: const Color(0xFF8B5CF6),
                            );
                          },
                          icon: const Icon(Icons.add_rounded, size: 16),
                          label: const Text('Schedule Makeup', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF8B5CF6),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            elevation: 0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    final sortedSchedule = List<ClassSession>.from(schedule)
      ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));

    final currentTime = now.hour + (now.minute / 60.0);
    final bool isToday = activeDay == now.weekday && now.weekday <= 7;

    final List<Widget> items = [];

    for (int index = 0; index < sortedSchedule.length; index++) {
      final session = sortedSchedule[index];
      final isLive = isToday && session.isLive(now);
      final isCompleted = activeDay < now.weekday || (isToday && !isLive && session.safeEndVal <= currentTime);
      final isUpcoming = activeDay > now.weekday || (isToday && !isLive && session.safeStartVal > currentTime);

      final cardContent = Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: isLive
                      ? const Color(0xFF10B981).withValues(alpha: 0.16)
                      : (isUpcoming
                          ? const Color(0xFF8B5CF6).withValues(alpha: 0.14)
                          : (isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.05))),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  '${session.startTime} - ${session.endTime}',
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w800,
                    color: isLive
                        ? const Color(0xFF10B981)
                        : (isUpcoming ? const Color(0xFF8B5CF6) : (isDark ? Colors.white70 : Colors.black54)),
                  ),
                ),
              ),
              if (isLive)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: const Color(0xFF10B981),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: const Text(
                    'LIVE',
                    style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                    ),
                  ),
                )
              else if (isCompleted)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.06),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.check, size: 10, color: isDark ? Colors.white60 : Colors.black54),
                      const SizedBox(width: 4),
                      Text(
                        'DONE',
                        style: TextStyle(
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          color: isDark ? Colors.white60 : Colors.black54,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            session.subject,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w800,
              color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
              decoration: isCompleted ? TextDecoration.lineThrough : null,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              InkWell(
                onTap: () {
                  IrisHaptics.chipSelect();
                  pushGlassContainerMorphRoute(
                    context,
                    page: RoomFinderScreen(
                      memory: brain.memory,
                    ),
                    accentColor: const Color(0xFF00E5FF),
                  );
                },
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFF00E5FF).withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.location_on_rounded, size: 12, color: Color(0xFF00E5FF)),
                      const SizedBox(width: 4),
                      Text(
                        'Room ${session.room}',
                        style: const TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF00E5FF),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 8),
              InkWell(
                onTap: () {
                  IrisHaptics.chipSelect();
                  pushGlassContainerMorphRoute(
                    context,
                    page: DepartmentClassesScreen(
                      memory: brain.memory,
                      brain: brain,
                      currentBatch: session.batchKey.batch,
                      teacherName: teacherName,
                      showBatchShortcut: true,
                      showDock: false,
                      onBatchChanged: onBatchChanged,
                    ),
                    accentColor: const Color(0xFF8B5CF6),
                  );
                },
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFF8B5CF6).withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    session.displayBatch,
                    style: const TextStyle(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF8B5CF6),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      );

      Widget wrappedCard;
      if (isM3) {
        wrappedCard = Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: isDark ? cs.surfaceContainer : cs.surfaceContainerLow,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isLive
                  ? cs.primary.withValues(alpha: 0.5)
                  : cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.5),
              width: 1.0,
            ),
          ),
          child: cardContent,
        );
      } else {
        wrappedCard = Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: GlassCard(
            borderRadius: 20,
            accentColor: isLive ? const Color(0xFF10B981) : const Color(0xFF00E5FF),
            padding: const EdgeInsets.all(16),
            border: Border.all(
              color: (isLive ? const Color(0xFF10B981) : const Color(0xFF00E5FF))
                  .withValues(alpha: isDark ? 0.35 : 0.20),
              width: 1.2,
            ),
            child: cardContent,
          ),
        );
      }

      items.add(
        RepaintBoundary(
          key: ValueKey('faculty_session_${session.id}_$index'),
          child: Opacity(
            opacity: isCompleted ? 0.60 : 1.0,
            child: ExpressiveInteractivePress(
              onTap: () => _showSessionDetailsSheet(context, session, isDark, isM3, cs),
              child: wrappedCard,
            ),
          ),
        ),
      );

      // Check gap between this session and the next session
      if (index < sortedSchedule.length - 1) {
        final nextSession = sortedSchedule[index + 1];
        final gapHours = nextSession.safeStartVal - session.safeEndVal;
        final gapMinutes = (gapHours * 60).round();
        if (gapMinutes >= 15) {
          items.add(
            RepaintBoundary(
              key: ValueKey('faculty_break_$index'),
              child: _buildTimelineBreakIndicator(
                context,
                isDark,
                isM3,
                cs,
                gapMinutes,
                session.room,
                nextSession.room,
              ),
            ),
          );
        }
      }
    }

    return SliverList.list(children: items);
  }

  Widget _buildTimelineBreakIndicator(
    BuildContext context,
    bool isDark,
    bool isM3,
    ColorScheme cs,
    int gapMinutes,
    String prevRoom,
    String nextRoom,
  ) {
    final hasRoomChange = prevRoom.trim().toLowerCase() != nextRoom.trim().toLowerCase();
    final durationText = gapMinutes >= 60
        ? '${gapMinutes ~/ 60}h ${gapMinutes % 60 > 0 ? '${gapMinutes % 60}m' : ''}'
        : '${gapMinutes}m';

    final label = hasRoomChange
        ? 'Transition & Break: $durationText • Room $prevRoom ➔ $nextRoom'
        : 'Free Prep Window: $durationText • Same Room ($prevRoom)';

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: (hasRoomChange ? const Color(0xFFF59E0B) : const Color(0xFF00E5FF))
                .withValues(alpha: isDark ? 0.12 : 0.08),
            borderRadius: BorderRadius.circular(999),
            border: Border.all(
              color: (hasRoomChange ? const Color(0xFFF59E0B) : const Color(0xFF00E5FF))
                  .withValues(alpha: isDark ? 0.28 : 0.18),
              width: 1.0,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                hasRoomChange ? Icons.directions_walk_rounded : Icons.coffee_rounded,
                size: 13,
                color: hasRoomChange ? const Color(0xFFF59E0B) : const Color(0xFF00E5FF),
              ),
              const SizedBox(width: 6),
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: hasRoomChange ? const Color(0xFFF59E0B) : const Color(0xFF00E5FF),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSessionDetailsSheet(
    BuildContext context,
    ClassSession session,
    bool isDark,
    bool isM3,
    ColorScheme cs,
  ) {
    IrisHaptics.chipSelect();
    final live = session.isLive(now);
    final currentTime = now.hour + (now.minute / 60.0);
    final isCompleted = session.safeEndVal <= currentTime;
    final durationHours = (session.safeEndVal - session.safeStartVal).abs();
    final durationFormatted = durationHours >= 1.0
        ? '${durationHours.toStringAsFixed(durationHours % 1 == 0 ? 0 : 1)}h'
        : '${(durationHours * 60).round()}m';

    final themeStyle = ThemeSignals.themeStyle.value;

    BoxDecoration tileDecoration;
    Color tileTitleColor;
    Color tileSubtitleColor;

    switch (themeStyle) {
      case IrisThemeStyle.materialYou:
        tileDecoration = BoxDecoration(
          color: cs.surfaceContainerLow,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: cs.outlineVariant.withValues(alpha: isDark ? 0.25 : 0.4),
            width: 1.0,
          ),
        );
        tileTitleColor = cs.onSurface;
        tileSubtitleColor = cs.onSurfaceVariant;
        break;
      case IrisThemeStyle.notebook:
        tileDecoration = BoxDecoration(
          color: NotebookTokens.cardSurface(isDark),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: NotebookTokens.gridLine(isDark),
            width: 1.5,
          ),
        );
        tileTitleColor = NotebookTokens.inkHeading(isDark);
        tileSubtitleColor = NotebookTokens.inkMuted(isDark);
        break;
      case IrisThemeStyle.line:
        tileDecoration = BoxDecoration(
          color: LineTokens.cardSurface(isDark),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: LineTokens.railLine(isDark),
            width: 1.5,
          ),
        );
        tileTitleColor = LineTokens.inkHeading(isDark);
        tileSubtitleColor = LineTokens.inkMuted(isDark);
        break;
      case IrisThemeStyle.poster:
        tileDecoration = BoxDecoration(
          color: PosterTokens.cardSurface(isDark),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: PosterTokens.inkBorder(isDark),
            width: 2.0,
          ),
          boxShadow: [
            BoxShadow(
              color: PosterTokens.inkBorder(isDark),
              offset: const Offset(2, 2),
              blurRadius: 0,
            ),
          ],
        );
        tileTitleColor = PosterTokens.inkHeading(isDark);
        tileSubtitleColor = PosterTokens.inkBody(isDark);
        break;
      case IrisThemeStyle.almanac:
        tileDecoration = BoxDecoration(
          color: AlmanacTokens.cardSurface(isDark),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: AlmanacTokens.inkRule(isDark),
            width: 1.2,
          ),
        );
        tileTitleColor = AlmanacTokens.inkHeading(isDark);
        tileSubtitleColor = AlmanacTokens.inkRule(isDark);
        break;
      case IrisThemeStyle.editorialAcademic:
        tileDecoration = BoxDecoration(
          color: EditorialTokens.cardSurface(isDark),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: EditorialTokens.cardBorder(isDark),
            width: 1.2,
          ),
        );
        tileTitleColor = EditorialTokens.inkHeading(isDark);
        tileSubtitleColor = EditorialTokens.inkMuted(isDark);
        break;
      case IrisThemeStyle.fluidGlass:
        tileDecoration = BoxDecoration(
          color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.black.withValues(alpha: 0.03),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.06),
          ),
        );
        tileTitleColor = isDark ? Colors.white : Colors.black87;
        tileSubtitleColor = isDark ? Colors.white54 : Colors.black45;
        break;
    }

    IrisModalSheet.show(
      context: context,
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 18),
                  decoration: BoxDecoration(
                    color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.20),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: (live
                              ? const Color(0xFF10B981)
                              : (isM3 ? cs.primary : const Color(0xFF00E5FF)))
                          .withValues(alpha: 0.16),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(
                      Icons.school_rounded,
                      color: live
                          ? const Color(0xFF10B981)
                          : (isM3 ? cs.primary : const Color(0xFF00E5FF)),
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          session.subject,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -0.3,
                            color: tileTitleColor,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          '${session.startTime} - ${session.endTime} ($durationFormatted)',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: tileSubtitleColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: (live
                              ? const Color(0xFF10B981)
                              : (isCompleted
                                  ? (isDark ? Colors.white12 : Colors.black12)
                                  : const Color(0xFF8B5CF6)))
                          .withValues(alpha: 0.18),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      live ? 'LIVE' : (isCompleted ? 'DONE' : 'UPCOMING'),
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        color: live
                            ? const Color(0xFF10B981)
                            : (isCompleted
                                ? (isDark ? Colors.white60 : Colors.black54)
                                : const Color(0xFF8B5CF6)),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              // Room Tile
              InkWell(
                onTap: () {
                  Navigator.of(ctx).pop();
                  pushGlassContainerMorphRoute(
                    context,
                    page: RoomFinderScreen(
                      memory: brain.memory,
                    ),
                    accentColor: const Color(0xFF00E5FF),
                  );
                },
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: tileDecoration,
                  child: Row(
                    children: [
                      const Icon(Icons.meeting_room_rounded, color: Color(0xFF00E5FF), size: 20),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Room ${session.room}',
                              style: TextStyle(
                                fontSize: 13.5,
                                fontWeight: FontWeight.w800,
                                color: tileTitleColor,
                              ),
                            ),
                            Text(
                              'Tap to check vacancy & occupancy schedule',
                              style: TextStyle(
                                fontSize: 11,
                                color: tileSubtitleColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Icon(Icons.arrow_forward_ios_rounded, size: 12, color: Color(0xFF00E5FF)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              // Batch Tile
              InkWell(
                onTap: () {
                  Navigator.of(ctx).pop();
                  pushGlassContainerMorphRoute(
                    context,
                    page: DepartmentClassesScreen(
                      memory: brain.memory,
                      brain: brain,
                      currentBatch: session.batchKey.batch,
                      teacherName: teacherName,
                      showBatchShortcut: true,
                      showDock: false,
                      onBatchChanged: onBatchChanged,
                    ),
                    accentColor: const Color(0xFF8B5CF6),
                  );
                },
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: tileDecoration,
                  child: Row(
                    children: [
                      const Icon(Icons.groups_rounded, color: Color(0xFF8B5CF6), size: 20),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Batch ${session.displayBatch}',
                              style: TextStyle(
                                fontSize: 13.5,
                                fontWeight: FontWeight.w800,
                                color: tileTitleColor,
                              ),
                            ),
                            Text(
                              'Tap to view student batch weekly timetable',
                              style: TextStyle(
                                fontSize: 11,
                                color: tileSubtitleColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Icon(Icons.arrow_forward_ios_rounded, size: 12, color: Color(0xFF8B5CF6)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              // Action Buttons: Attendance & Makeup
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Navigator.of(ctx).pop();
                        pushGlassContainerMorphRoute(
                          context,
                          page: const PortalScreen(
                            url: 'https://faculty.comsats.edu.pk/Home/login?returnUrl=https://faculty.comsats.edu.pk/',
                            title: 'CUOnline Faculty Portal',
                            sessionScope: 'faculty',
                            showBackButton: true,
                          ),
                          accentColor: const Color(0xFFF59E0B),
                        );
                      },
                      icon: const Icon(Icons.how_to_reg_rounded, size: 16),
                      label: const Text(
                        'Attendance',
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
                      ),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFFF59E0B),
                        side: BorderSide(
                          color: const Color(0xFFF59E0B).withValues(alpha: isDark ? 0.6 : 0.4),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () {
                        Navigator.of(ctx).pop();
                        pushGlassContainerMorphRoute(
                          context,
                          page: MakeupLectureScheduler(
                            memory: brain.memory,
                            brain: brain,
                            batch: session.batchKey.batch,
                            teacherName: teacherName,
                            showDock: false,
                            onAddMakeupClass: onAddMakeupClass ?? (_) async {},
                            onRoleChanged: onRoleChanged,
                            onBatchChanged: onBatchChanged,
                          ),
                          accentColor: const Color(0xFF8B5CF6),
                        );
                      },
                      icon: const Icon(Icons.event_repeat_rounded, size: 16),
                      label: const Text(
                        'Plan Makeup',
                        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF8B5CF6),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        elevation: 0,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
