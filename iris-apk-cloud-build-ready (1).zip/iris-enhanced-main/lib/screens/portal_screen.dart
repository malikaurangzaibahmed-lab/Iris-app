import 'dart:io';
import 'dart:convert';
import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:open_filex/open_filex.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/models.dart';
import '../core/tokens.dart';
import '../core/animations.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import '../widgets/smart_widgets.dart';
import '../services/analytics_manager.dart';
import 'package:iris/widgets/iris_components.dart';
import '../core/theme_signals.dart';
import '../core/almanac_theme_tokens.dart';
import '../core/editorial_theme_tokens.dart';
import '../core/notebook_theme_tokens.dart';
import '../core/line_theme_tokens.dart';
import '../core/poster_theme_tokens.dart';
import 'package:google_fonts/google_fonts.dart';
import '../core/sticker_tokens.dart';
import '../core/glass.dart';
import '../core/vital_theme.dart';

/// Portal session metadata persisted across app restarts
import '../models/portal_models.dart';
import '../widgets/portal/portal_widgets.dart';
export '../models/portal_models.dart';
export '../widgets/portal/portal_widgets.dart';
class PortalScreen extends SmartStatefulWidget {
  final String url;
  final String title;
  final bool showBackButton;
  final String sessionScope;

  const PortalScreen({
    required this.url,
    required this.title,
    this.showBackButton = true,
    this.sessionScope = 'global',
    super.key,
  });

  @override
  State<PortalScreen> createState() => _PortalScreenState();
}

class _PortalScreenState extends SmartState<PortalScreen>
    with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  static const String _portalUserAgent =
      'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36';
  static const MethodChannel _androidDownloadChannel = MethodChannel(
    'iris/download',
  );

  late final WebViewController _controller;
  final WebViewCookieManager _cookieManager = WebViewCookieManager();
  bool _isLoading = true;
  bool _canGoBack = false;
  bool _canGoForward = false;
  String _currentUrl = '';
  late PortalSession _currentSession;

  // Smart feature detection
  bool _hasLoginForm = false;
  bool _hasFileUpload = false;
  bool _hasSavedLogin = false;
  int _lastDetectionTime = 0;
  bool _isOffline = false;
  bool _isPullRefreshing = false;
  bool _isHeaderCollapsed = true;
  bool _isEditingAddress = false;
  bool _showAutofillPrompt = false;
  Timer? _connectivityTimer;
  Timer? _loginFocusTimer;
  Timer? _pillRevertTimer;
  String? _pillMessage;
  IconData? _pillIcon;
  Color _pillTone = Colors.white;
  VoidCallback? _pillAction;
  String? _pillActionLabel;
  bool _pillActive = false;
  final ValueNotifier<int> _loadProgressNotifier = ValueNotifier<int>(0);
  String? _lastSnackMessage;
  int _lastSnackAtMs = 0;
  String? _lastDownloadUrl;
  int _lastDownloadAtMs = 0;
  final TextEditingController _addressController = TextEditingController();
  bool? _lastAppliedDark;

  String get _scopeSanitized =>
      widget.sessionScope.toLowerCase().replaceAll(RegExp(r'[^a-z0-9_-]'), '_');

  String get _lastActiveSessionKey =>
      'iris_portal_${_scopeSanitized}_last_active_session';

  String _portalSessionKey(String host) =>
      'iris_portal_${_scopeSanitized}_session_${host.toLowerCase()}';

  String _loginUserKey(String host) =>
      'iris_login_${_scopeSanitized}_${host.toLowerCase()}_u';

  String _loginPassKey(String host) =>
      'iris_login_${_scopeSanitized}_${host.toLowerCase()}_p';

  Future<void> _copyPath(String path) async {
    await Clipboard.setData(ClipboardData(text: path));
    await _showMessage('Path copied: $path');
  }

  Future<void> _openFilePath(String path) async {
    try {
      final file = File(path);
      if (!await file.exists()) {
        await _showMessage('File not found');
        return;
      }

      final result = await OpenFilex.open(path);
      if (result.type != ResultType.done) {
        await _showMessage('Cannot open this file type here. Path copied.');
        await _copyPath(path);
      }
    } catch (_) {
      await _showMessage('Could not open file. Path copied.');
      await _copyPath(path);
    }
  }

  Future<void> _openSystemDownloads() async {
    if (Platform.isAndroid) {
      try {
        await _androidDownloadChannel.invokeMethod('openSystemDownloads');
      } catch (e) {
        await _showMessage('Cannot open system downloads');
      }
    } else {
      await _showMessage('System downloads only available on Android');
    }
  }

  Future<void> _openFolderPath(String path) async {
    try {
      final dir = Directory(path);
      if (!await dir.exists()) {
        await _showMessage('Folder not found');
        return;
      }

      final result = await OpenFilex.open(path);
      if (result.type != ResultType.done) {
        final uri = Uri.directory(path);
        final launched = await launchUrl(
          uri,
          mode: LaunchMode.externalApplication,
        );
        if (!launched) {
          await _showMessage('Cannot open folder directly. Path copied.');
          await _copyPath(path);
        }
      }
    } catch (_) {
      await _showMessage('Could not open folder. Path copied.');
      await _copyPath(path);
    }
  }

  /// Universal canonical sanitizer for modern IIS portals that rewrite legacy Login.aspx to Login/Index
  static String sanitizePortalUrl(String rawUrl) {
    if (rawUrl.isEmpty) return rawUrl;
    if (rawUrl.toLowerCase().contains('login.aspx')) {
      return rawUrl.replaceAll(
        RegExp(r'Login\.aspx', caseSensitive: false),
        'Login/Index',
      );
    }
    return rawUrl;
  }

  Future<void> _checkConnectivity() async {
    final url = _currentUrl.isEmpty ? widget.url : _currentUrl;
    final host = Uri.tryParse(url)?.host;
    if (host == null || host.isEmpty) return;

    bool online = true;
    try {
      final result = await InternetAddress.lookup(
        host,
      ).timeout(const Duration(seconds: 4));
      online = result.isNotEmpty && result.first.rawAddress.isNotEmpty;
    } catch (_) {
      online = false;
    }

    if (!mounted) return;
    if (_isOffline != !online) {
      setState(() => _isOffline = !online);
      if (online) {
        await _showMessage('Back online');
      } else {
        await _showMessage('You appear to be offline');
      }
    }
  }

  Future<void> _saveLastActiveSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _lastActiveSessionKey,
      jsonEncode(_currentSession.toJson()),
    );
  }

  Future<PortalSession?> _loadLastActiveSession() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_lastActiveSessionKey);
    if (raw == null) return null;
    try {
      final session = PortalSession.fromJson(jsonDecode(raw));
      final cleanUrl = sanitizePortalUrl(session.url);
      if (cleanUrl != session.url) {
        final fixedSession = PortalSession(
          host: session.host,
          title: session.title,
          url: cleanUrl,
          createdAt: session.createdAt,
          lastAccessedAt: session.lastAccessedAt,
        );
        await prefs.setString(
          _lastActiveSessionKey,
          jsonEncode(fixedSession.toJson()),
        );
        return fixedSession;
      }
      return session;
    } catch (_) {
      return null;
    }
  }

  Future<void> _refreshPage({bool fromPull = false}) async {
    if (_isPullRefreshing || _isLoading) return;
    if (_isOffline) {
      await _showMessage('You are offline. Retry when internet is back.');
      return;
    }

    if (!mounted) return;
    setState(() => _isPullRefreshing = true);
    await _controller.reload();
    if (fromPull) {
      await _showMessage('Refreshing page...');
    }
    if (mounted) {
      setState(() => _isPullRefreshing = false);
    }
  }

  String get _hostKey {
    final uri = Uri.tryParse(_currentUrl.isEmpty ? widget.url : _currentUrl);
    return (uri?.host.isNotEmpty ?? false) ? uri!.host.toLowerCase() : 'portal';
  }

  int _loginThresholdForHost(String host) {
    if (host.contains('lms') ||
        host.contains('moodle') ||
        host.contains('cms')) {
      return 5;
    }
    if (host.contains('comsats.edu.pk') || host.contains('portal')) {
      return 4;
    }
    if (host.contains('adfs') ||
        host.contains('sso') ||
        host.contains('auth')) {
      return 4;
    }
    return 5;
  }

  Future<void> _detectPageFeatures() async {
    final now = DateTime.now().millisecondsSinceEpoch;
    // Only detect once per 2 seconds to avoid spam
    if (now - _lastDetectionTime < 2000) return;
    _lastDetectionTime = now;

    try {
      final script = '''
(() => {
  const url = window.location.href.toLowerCase();
  const title = (document.title || '').toLowerCase();
  const pwd = document.querySelector('input[type="password"]:not([disabled])');
  const scope = (pwd && pwd.form) ? pwd.form : document;
  
  const scoreField = (element) => {
    if (element === pwd) return -100;
    const type = (element.type || '').toLowerCase();
    if (type === 'hidden' || type === 'password' || type === 'submit' || type === 'button' || type === 'checkbox' || type === 'radio') return -100;
    
    const meta = [element.name, element.id, element.placeholder, element.autocomplete, element.type].filter(Boolean).join(' ').toLowerCase();
    let score = 0;
    if (/email|user|username|login|roll|reg|id|student|account/.test(meta)) score += 5;
    if (/search|query|find|filter/.test(meta)) score -= 5;
    if (/captcha|code|verif|validate|security/i.test(meta)) score -= 20;
    
    // Check visibility
    const style = window.getComputedStyle(element);
    const isVisible = style && style.display !== 'none' && style.visibility !== 'hidden' && element.getClientRects().length > 0;
    if (!isVisible) score -= 10;
    
    return score;
  };

  const candidates = Array.from(scope.querySelectorAll('input, textarea'))
    .sort((a, b) => scoreField(b) - scoreField(a));
  
  const user = (candidates.length > 0 && scoreField(candidates[0]) > 0) ? candidates[0] : null;

  const hasUpload = document.querySelector('input[type="file"]') != null;
  const focusMatchesLogin = (element) => {
    if (!element) return false;
    return element === pwd || element === user;
  };

  const sendFocusState = () => {
    if (!window.IrisPortalChannel) return;
    const active = document.activeElement;
    if (!focusMatchesLogin(active)) return;
    window.IrisPortalChannel.postMessage(JSON.stringify({
      type: 'login_focus',
      focused: true,
    }));
  };
  const active = document.activeElement;
  const loginFocused = !!active && (active === pwd || active === user);

  let score = 0;
  if (pwd) score += 3;
  if (user) score += 2;
  if (/login|signin|sign-in|auth|account|portal/.test(url)) score += 1;
  if (/login|sign in|authentication|portal/.test(title)) score += 1;

  if (pwd && pwd.form) {
    const formMeta = [
      pwd.form.action || '',
      pwd.form.id || '',
      pwd.form.name || '',
      pwd.form.className || ''
    ].join(' ').toLowerCase();

    if (/login|signin|auth|session|account|portal/.test(formMeta)) score += 2;
    if (/upload|assignment|submit|feedback|quiz/.test(formMeta)) score -= 2;
  }

  if (focusMatchesLogin(document.activeElement)) {
    sendFocusState();
  } else {
    document.addEventListener('focusin', sendFocusState, true);
  }

  const hasLogin = score >= 4;
  return JSON.stringify({ hasLogin, hasUpload, loginFocused, score });
})();
''';
      final raw = await _controller.runJavaScriptReturningResult(script);
      final text = _normalizeJsResult(raw);
      final data = jsonDecode(text) as Map<String, dynamic>;
      final score = (data['score'] as num?)?.toInt() ?? 0;
      final host = _hostKey;
      final threshold = _loginThresholdForHost(host);
      // Hysteresis: once we confidently detect login, don't drop immediately.
      final hasLogin =
          score >= threshold || (_hasLoginForm && score >= (threshold - 1));
      final loginFocused = data['loginFocused'] == true;

      if (!mounted) return;
      setState(() {
        _hasLoginForm = hasLogin;
        _hasFileUpload = data['hasUpload'] ?? false;
        if (loginFocused && _hasSavedLogin) {
          _showAutofillPrompt = true;
        } else if (!hasLogin) {
          _showAutofillPrompt = false;
        }
      });

      // Check if we have saved login for this host
      final prefs = await SharedPreferences.getInstance();
      final savedU = prefs.getString(_loginUserKey(_hostKey));
      if (savedU != null) {
        try {
          utf8.decode(base64Decode(savedU));
          if (mounted) {
            setState(() {
              _hasSavedLogin = true;
            });
          }
        } catch (_) {}
      } else if (mounted) {
        setState(() {
          _hasSavedLogin = false;
        });
      }

      // Automatically autofill credentials or registration prefix to streamline login
      if (_hasLoginForm && mounted) {
        if (_hasSavedLogin) {
          await _autofillSavedLogin();
        } else {
          await _autofillSuggestedRegistration();
        }
      }
    } catch (_) {}
  }

  Future<void> _pollLoginFocus() async {
    if (!mounted || !_hasSavedLogin || !_hasLoginForm) return;
    if (!TickerMode.valuesOf(context).enabled) return;
    try {
      final raw = await _controller.runJavaScriptReturningResult('''
(() => {
  const pwd = document.querySelector('input[type="password"]:not([disabled])');
  const scope = (pwd && pwd.form) ? pwd.form : document;
  const user = scope.querySelector(
    'input[type="email"], input[autocomplete="username"], input[name*="user" i], input[id*="user" i], input[name*="login" i], input[id*="login" i], input[name*="roll" i], input[name*="reg" i], input[type="text"]'
  );
  const active = document.activeElement;
  return !!active && (active === pwd || active === user);
})();
''');
      final focused = _normalizeJsResult(raw).toLowerCase() == 'true';
      if (!mounted) return;
      if (focused && !_showAutofillPrompt) {
        _stopLoginFocusWatch();
        setState(() => _showAutofillPrompt = true);
      }
    } catch (_) {}
  }

  void _startLoginFocusWatch() {
    if (!_hasLoginForm || !_hasSavedLogin) return;
    final lower = _currentUrl.toLowerCase();
    if (lower.contains('challenge') ||
        lower.contains('cdn-cgi') ||
        lower.contains('turnstile') ||
        lower.contains('captcha')) {
      return;
    }
    _loginFocusTimer?.cancel();
    _loginFocusTimer = Timer.periodic(const Duration(milliseconds: 1500), (_) {
      unawaited(_pollLoginFocus());
    });
  }

  void _stopLoginFocusWatch() {
    _loginFocusTimer?.cancel();
    _loginFocusTimer = null;
  }

  bool _looksDownloadableUrl(String url) {
    final cleanUrl = url.toLowerCase().split('?').first.split('#').first;

    // Extensions that are ALWAYS downloads:
    final extensions = [
      '.pdf',
      '.doc',
      '.docx',
      '.ppt',
      '.pptx',
      '.xls',
      '.xlsx',
      '.zip',
      '.rar',
      '.7z',
      '.apk',
      '.png',
      '.jpg',
      '.jpeg',
      '.txt',
      '.csv',
    ];
    if (extensions.any((ext) => cleanUrl.endsWith(ext))) {
      return true;
    }

    // Check query params or path triggers, but be careful not to match main pages
    final uri = Uri.tryParse(url);
    if (uri == null) return false;

    final fullLower = url.toLowerCase();
    final hasQuery = uri.hasQuery && uri.query.isNotEmpty;

    // Check known download keywords:
    final keywords = [
      'getfile',
      'getassignment',
      'assignmentfile',
      'resultcard',
      'challan',
      'fee_challan',
      'printchallan',
      'attachment',
    ];
    if (keywords.any((kw) => fullLower.contains(kw))) {
      // Exclude main page routes that contain these keywords but are actually pages.
      // For instance, the main ResultCard page (/Student/ResultCard) or Challan list page (/Student/Challan).
      final path = uri.path.toLowerCase();
      if (!hasQuery) {
        if (path == '/student/resultcard' ||
            path == '/student/challan' ||
            path == '/student/printchallan' ||
            path == '/student/fee_challan' ||
            path.endsWith('/resultcard') ||
            path.endsWith('/challan') ||
            path.endsWith('/printchallan') ||
            path.endsWith('/fee_challan')) {
          return false;
        }
      }
      return true;
    }

    // For 'download', 'export', 'stream', 'generate', 'viewfile':
    // If it's a page (ends with .aspx, .php, .html) but has NO query params, it is likely a webpage, not a download.
    final pageExtensions = ['.aspx', '.php', '.html', '.htm', '.jsp'];
    final isPageExtension = pageExtensions.any((ext) => cleanUrl.endsWith(ext));

    if (fullLower.contains('download') ||
        fullLower.contains('export') ||
        fullLower.contains('stream') ||
        fullLower.contains('generate') ||
        fullLower.contains('viewfile')) {
      if (isPageExtension && !hasQuery) {
        return false;
      }
      // If it ends with '/download' or '/downloads' or '/export' without query, it's probably a page
      final path = uri.path.toLowerCase();
      if (path == '/download' ||
          path == '/downloads' ||
          path == '/export' ||
          path.endsWith('/download') ||
          path.endsWith('/downloads')) {
        return false;
      }
      return true;
    }

    return false;
  }

  Future<void> _handlePrintDocument(String url) async {
    try {
      final uri = Uri.tryParse(url);
      if (uri == null) {
        await _showMessage('Invalid print link');
        return;
      }

      final jsUrl = jsonEncode(uri.toString());
      final rawResult = await _controller.runJavaScriptReturningResult('''
(() => {
  const targetUrl = $jsUrl;
  const normalize = (value) => {
    try {
      const parsed = new URL(value, window.location.href);
      return parsed.origin + parsed.pathname + parsed.search;
    } catch (_) {
      return String(value || '');
    }
  };

  const samePage = normalize(targetUrl) === normalize(window.location.href);
  if (samePage) {
    try {
      window.focus();
      window.print();
      return 'printed-current';
    } catch (_) {
      return 'print-failed';
    }
  }

  try {
    const popup = window.open(targetUrl, '_blank');
    if (popup) {
      setTimeout(() => {
        try {
          popup.focus();
          popup.print();
        } catch (_) {}
      }, 700);
      return 'opened-window';
    }
    return 'popup-blocked';
  } catch (_) {
    return 'open-failed';
  }
})();
''');

      final jsResult = _normalizeJsResult(rawResult).toLowerCase();
      if (jsResult.contains('printed-current') ||
          jsResult.contains('opened-window')) {
        await _showMessage('Print dialog requested');
        return;
      }

      final launched = await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
      );
      if (launched) {
        await _showMessage('Opened in browser for printing');
      } else {
        await _showMessage('Could not open print target');
      }
    } catch (e) {
      await _showMessage('Could not open print dialog');
    }
  }

  String _normalizeJsResult(Object? value) {
    if (value == null) return '';
    final raw = value.toString();
    if (raw.length >= 2 && raw.startsWith('"') && raw.endsWith('"')) {
      return raw.substring(1, raw.length - 1).replaceAll(r'\"', '"');
    }
    return raw;
  }

  String _sessionCookieKeyForHost(String host) =>
      'iris_session_${_scopeSanitized}_${host.toLowerCase()}_cookies';

  // Session persistence method
  Future<void> _savePortalSession() async {
    final prefs = await SharedPreferences.getInstance();
    final sessionKey = _portalSessionKey(_currentSession.host);
    final json = jsonEncode(_currentSession.toJson());
    await prefs.setString(sessionKey, json);
  }

  // Load session metadata
  Future<PortalSession?> _loadPortalSession(String host) async {
    final prefs = await SharedPreferences.getInstance();
    final sessionKey = _portalSessionKey(host);
    final json = prefs.getString(sessionKey);
    if (json == null) return null;
    try {
      final session = PortalSession.fromJson(jsonDecode(json));
      final cleanUrl = sanitizePortalUrl(session.url);
      if (cleanUrl != session.url) {
        final fixed = session.copyWith(url: cleanUrl);
        await prefs.setString(sessionKey, jsonEncode(fixed.toJson()));
        return fixed;
      }
      return session;
    } catch (_) {
      return null;
    }
  }

  // Update session timestamp and cookies validity
  Future<void> _updateSessionMetadata() async {
    String? nextUrl;
    if (_currentUrl.isNotEmpty &&
        !_currentUrl.startsWith('data:') &&
        !_currentUrl.startsWith('blob:') &&
        _currentUrl != 'about:blank' &&
        !_looksDownloadableUrl(_currentUrl)) {
      nextUrl = sanitizePortalUrl(_currentUrl);
    }

    _currentSession = _currentSession.copyWith(
      url: nextUrl,
      lastAccessedAt: DateTime.now().millisecondsSinceEpoch,
      hasValidCookies: true,
    );
    await _savePortalSession();
    await _saveLastActiveSession();
  }

  // Track file download
  Future<void> _trackDownload({
    required String filename,
    required String filePath,
    required String sourceUrl,
    String state = 'completed',
    String backend = 'native',
    String downloadId = '',
  }) async {
    final downloads = [..._currentSession.recentDownloads];
    final normalizedName = filename.trim().toLowerCase();
    final normalizedSource = sourceUrl.trim().toLowerCase();
    downloads.removeWhere((entry) {
      final samePath = filePath.isNotEmpty && entry.filePath == filePath;
      final sameSource =
          normalizedSource.isNotEmpty &&
          entry.sourceUrl.trim().toLowerCase() == normalizedSource;
      final sameNameFallback =
          normalizedName.isNotEmpty &&
          entry.filename.trim().toLowerCase() == normalizedName;
      return samePath ||
          sameSource ||
          (sameNameFallback && entry.state != 'queued');
    });
    downloads.insert(
      0,
      DownloadRecord(
        filename: filename,
        filePath: filePath,
        sourceUrl: sourceUrl,
        savedAt: DateTime.now().millisecondsSinceEpoch,
        state: state,
        backend: backend,
        downloadId: downloadId,
      ),
    );
    _currentSession = _currentSession.copyWith(
      recentDownloads: downloads.take(10).toList(),
    );
    await _savePortalSession();
  }

  Future<void> _removeStaleDownloads() async {
    final current = [..._currentSession.recentDownloads];
    if (current.isEmpty) return;

    final retained = <DownloadRecord>[];
    for (final item in current) {
      if (item.isPending) {
        retained.add(item);
        continue;
      }
      if (item.filePath.isEmpty) {
        retained.add(item);
        continue;
      }
      final exists = await File(item.filePath).exists();
      if (exists) retained.add(item);
    }

    if (retained.length == current.length) return;
    _currentSession = _currentSession.copyWith(recentDownloads: retained);
    await _savePortalSession();
  }

  Future<void> _syncSystemDownloadStates() async {
    if (!Platform.isAndroid) return;
    final current = [..._currentSession.recentDownloads];
    if (current.isEmpty) return;

    bool changed = false;
    final updated = <DownloadRecord>[];

    for (final item in current) {
      if (item.backend != 'system' || item.downloadId.isEmpty) {
        updated.add(item);
        continue;
      }

      final id = int.tryParse(item.downloadId);
      if (id == null) {
        updated.add(item);
        continue;
      }

      try {
        final resp = await _androidDownloadChannel
            .invokeMapMethod<String, dynamic>('querySystemDownload', {
              'downloadId': id,
            });
        if (resp == null) {
          updated.add(item);
          continue;
        }

        final exists = resp['exists'] == true;
        final status = (resp['status']?.toString() ?? '').trim();
        final title = (resp['title']?.toString() ?? '').trim();
        final localUriRaw = (resp['localUri']?.toString() ?? '').trim();

        if (!exists || status.isEmpty) {
          updated.add(item);
          continue;
        }

        var nextPath = item.filePath;
        if (localUriRaw.isNotEmpty) {
          final localUri = Uri.tryParse(localUriRaw);
          if (localUri != null && localUri.scheme == 'file') {
            nextPath = localUri.toFilePath();
          }
        }

        final nextFilename = title.isNotEmpty ? title : item.filename;
        if (status != item.state ||
            nextPath != item.filePath ||
            nextFilename != item.filename) {
          changed = true;
          updated.add(
            DownloadRecord(
              filename: nextFilename,
              filePath: nextPath,
              sourceUrl: item.sourceUrl,
              savedAt: item.savedAt,
              state: status,
              backend: item.backend,
              downloadId: item.downloadId,
            ),
          );
        } else {
          updated.add(item);
        }
      } catch (_) {
        updated.add(item);
      }
    }

    if (!changed) return;
    _currentSession = _currentSession.copyWith(
      recentDownloads: updated.take(10).toList(),
    );
    await _savePortalSession();
  }

  // Track file upload
  Future<void> _trackUpload(String filename) async {
    final uploads = [..._currentSession.recentUploads];
    uploads.removeWhere((f) => f == filename);
    uploads.insert(0, filename);
    _currentSession = _currentSession.copyWith(
      recentUploads: uploads.take(10).toList(),
    );
    await _savePortalSession();
  }

  // Clear session for this portal
  Future<void> _clearCurrentSession() async {
    final prefs = await SharedPreferences.getInstance();
    final sessionKey = _portalSessionKey(_currentSession.host);
    await prefs.remove(sessionKey);
    await prefs.remove(_loginUserKey(_currentSession.host));
    await prefs.remove(_loginPassKey(_currentSession.host));
    final lastRaw = prefs.getString(_lastActiveSessionKey);
    if (lastRaw != null) {
      try {
        final last = PortalSession.fromJson(jsonDecode(lastRaw));
        if (last.host == _currentSession.host) {
          await prefs.remove(_lastActiveSessionKey);
        }
      } catch (_) {}
    }
    if (mounted) await _showMessage('Session and login cleared');
  }

  Future<void> _showDownloadManager() async {
    if (!mounted) return;
    await _syncSystemDownloadStates();
    await _removeStaleDownloads();
    final downloads = _currentSession.recentDownloads;
    final uploads = _currentSession.recentUploads;
    final downloadDir = await _resolveDownloadDirectory();
    if (!mounted) return;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetCtx) => PortalDownloadManagerSheet(
        downloads: downloads,
        uploads: uploads,
        downloadDir: downloadDir,
        isDark: isDark,
        onOpenFilePath: _openFilePath,
        onCopyPath: _copyPath,
        onOpenFolderPath: _openFolderPath,
        onOpenSystemDownloads: _openSystemDownloads,
        onRefresh: () async {
          await _syncSystemDownloadStates();
          await _removeStaleDownloads();
          if (sheetCtx.mounted) {
            Navigator.of(sheetCtx).pop();
          }
          if (mounted) {
            await _showMessage('Download statuses refreshed');
          }
        },
        onCleanMissing: () async {
          await _removeStaleDownloads();
          if (sheetCtx.mounted) {
            Navigator.of(sheetCtx).pop();
          }
          if (mounted) {
            await _showMessage('Removed missing files from history');
          }
        },
        onClearHistory: () async {
          _currentSession = _currentSession.copyWith(
            recentDownloads: const [],
            recentUploads: const [],
          );
          await _savePortalSession();
          if (sheetCtx.mounted) {
            Navigator.of(sheetCtx).pop();
          }
          if (mounted) {
            await _showMessage('Transfer history cleared');
          }
        },
        onRetryDownload: (url) async {
          Navigator.of(context).pop();
          await _downloadFile(url);
        },
      ),
    );
  }

  Future<void> _showClearLoginConfirm() async {
    if (!mounted) return;
    await _showMessage(
      'Clear saved login for $_hostKey?',
      duration: const Duration(seconds: 7),
      action: SnackBarAction(
        label: 'Clear',
        onPressed: () async {
          await _clearSavedLogin();
          if (!mounted) return;
          setState(() {
            _hasSavedLogin = false;
          });
        },
      ),
    );
  }

  Future<void> _showClearSessionConfirm() async {
    if (!mounted) return;
    await _showMessage(
      'Clear this portal session and data?',
      duration: const Duration(seconds: 7),
      action: SnackBarAction(
        label: 'Clear',
        onPressed: () async {
          await _clearCurrentSession();
        },
      ),
    );
  }

  Future<void> _persistSessionCookiesForUrl(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null || uri.host.isEmpty) return;
    try {
      final host = uri.host;
      // Note: webview_flutter 4.x doesn't have a direct getCookies() that sees HttpOnly.
      // We use document.cookie for now as it captures the primary session identifiers.
      final raw = await _controller.runJavaScriptReturningResult(
        'document.cookie',
      );
      final cookieString = _normalizeJsResult(raw).trim();

      if (cookieString.isNotEmpty) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(_sessionCookieKeyForHost(host), cookieString);

        // Also update background service global key if this is student scope
        if (_scopeSanitized == 'student') {
          await prefs.setString(
            'iris_session_student_${host.toLowerCase()}_cookies',
            cookieString,
          );
        }

        debugPrint('🍪 Session cookies persisted for $host');
      }
    } catch (e) {
      debugPrint('⚠️ Cookie persistence failed: $e');
    }
  }

  Future<void> _restoreSessionCookiesForUri(Uri uri) async {
    if (uri.host.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    final cookieHeader = prefs.getString(_sessionCookieKeyForHost(uri.host));
    if (cookieHeader == null || cookieHeader.trim().isEmpty) return;

    for (final part in cookieHeader.split(';')) {
      final entry = part.trim();
      if (entry.isEmpty) continue;
      final equalsAt = entry.indexOf('=');
      if (equalsAt <= 0) continue;

      final name = entry.substring(0, equalsAt).trim();
      final value = entry.substring(equalsAt + 1).trim();
      if (name.isEmpty) continue;

      try {
        await _cookieManager.setCookie(
          WebViewCookie(name: name, value: value, domain: uri.host, path: '/'),
        );
      } catch (_) {
        // Skip malformed/unsupported cookies.
      }
    }
  }

  void _clearTopPillOverlay() {
    _pillRevertTimer?.cancel();
    _pillRevertTimer = null;

    if (!mounted) return;
    setState(() {
      _pillActive = false;
      _pillMessage = null;
      _pillIcon = null;
      _pillAction = null;
      _pillActionLabel = null;
    });
  }

  void _showTopPill({
    required String text,
    required Color tone,
    required IconData icon,
    SnackBarAction? action,
    Duration duration = const Duration(seconds: 3),
  }) {
    if (!mounted) return;
    _pillRevertTimer?.cancel();
    if (!_isHeaderCollapsed) {
      setState(() => _isHeaderCollapsed = true);
    }

    setState(() {
      _pillActive = true;
      _pillMessage = text;
      _pillIcon = icon;
      _pillTone = tone;
      _pillAction = action?.onPressed;
      _pillActionLabel = action?.label;
    });

    final adaptiveHoldMs = (900 + (text.length * 22)).clamp(1200, 3400);
    final holdMs = math
        .min(duration.inMilliseconds, adaptiveHoldMs)
        .clamp(1100, 3400);
    _pillRevertTimer = Timer(Duration(milliseconds: holdMs), () {
      if (!mounted) return;
      _clearTopPillOverlay();
    });
  }

  String _compactPillMessage(String message) {
    final raw = message.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (raw.isEmpty) return 'Updated';

    final lower = raw.toLowerCase();

    if (lower.startsWith('autofilled')) return 'Autofill done';
    if (lower.startsWith('no saved login')) return 'No saved login';
    if (lower.startsWith('saved login removed')) return 'Login removed';
    if (lower.startsWith('download complete:')) {
      final name = raw.substring('download complete:'.length).trim();
      if (name.isEmpty) return 'Download complete';
      final shortName = name.length > 22 ? '${name.substring(0, 19)}...' : name;
      return 'Downloaded: $shortName';
    }
    if (lower.startsWith('downloading')) return 'Downloading file';
    if (lower.contains('download failed')) return 'Download failed';
    if (lower.contains('back online')) return 'Back online';
    if (lower.contains('offline')) return 'Offline';
    if (lower.startsWith('refreshing')) return 'Refreshing';
    if (lower.startsWith('path copied')) return 'Path copied';
    if (lower.contains('print dialog requested')) return 'Print requested';
    if (lower.contains('opened in browser for printing')) {
      return 'Opened in browser';
    }

    if (raw.length <= 44) return raw;
    return '${raw.substring(0, 41)}...';
  }

  Future<void> _showMessage(
    String message, {
    SnackBarAction? action,
    Duration duration = const Duration(seconds: 3),
  }) async {
    if (!mounted) return;
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    if (_lastSnackMessage == message && nowMs - _lastSnackAtMs < 1500) {
      return;
    }
    if (nowMs - _lastSnackAtMs < 220) {
      return;
    }
    _lastSnackMessage = message;
    _lastSnackAtMs = nowMs;

    final compactMessage = _compactPillMessage(message);
    final lower = message.toLowerCase();
    final isError =
        lower.contains('error') ||
        lower.contains('failed') ||
        lower.contains('invalid');
    final isOffline = lower.contains('offline');
    final isDownload = lower.contains('download');
    final isPrint = lower.contains('print');
    final isAutofill =
        lower.contains('autofill') ||
        lower.contains('saved login') ||
        lower.contains('save login');
    final isUpload = lower.contains('upload');
    final isCopy = lower.contains('copied') || lower.contains('copy path');
    final isSuccess =
        lower.contains('saved') ||
        lower.contains('complete') ||
        lower.contains('success') ||
        lower.contains('back online');
    final isHint =
        lower.contains('refresh') ||
        lower.contains('loading') ||
        lower.contains('open') ||
        lower.contains('select');

    Color tone = const Color(0xFF7C8AA5);
    IconData icon = Icons.notifications_none_rounded;
    if (isError) {
      tone = const Color(0xFFEF4444);
      icon = Icons.error_outline_rounded;
    } else if (isOffline) {
      tone = const Color(0xFFF59E0B);
      icon = Icons.cloud_off_rounded;
    } else if (isDownload) {
      tone = const Color(0xFF22D3EE);
      icon = Icons.download_rounded;
    } else if (isPrint) {
      tone = const Color(0xFFA78BFA);
      icon = Icons.print_rounded;
    } else if (isAutofill) {
      tone = const Color(0xFF34D399);
      icon = Icons.vpn_key_rounded;
    } else if (isUpload) {
      tone = const Color(0xFF38BDF8);
      icon = Icons.cloud_upload_rounded;
    } else if (isCopy) {
      tone = const Color(0xFFF472B6);
      icon = Icons.content_copy_rounded;
    } else if (isSuccess) {
      tone = const Color(0xFF10B981);
      icon = Icons.check_circle_outline_rounded;
    } else if (isHint) {
      tone = const Color(0xFFFE7A2C);
      icon = Icons.info_outline_rounded;
    }
    _showTopPill(
      text: compactMessage,
      tone: tone,
      icon: icon,
      action: action,
      duration: duration,
    );
  }

  Future<void> _autofillSavedLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final u = prefs.getString(_loginUserKey(_hostKey));
    final p = prefs.getString(_loginPassKey(_hostKey));
    if (u == null || p == null) {
      await _showMessage('No saved login found for $_hostKey');
      return;
    }

    final username = utf8.decode(base64Decode(u));
    final password = utf8.decode(base64Decode(p));

    final jsUser = jsonEncode(username);
    final jsPass = jsonEncode(password);
    final script =
        '''
(() => {
  const setNativeValue = (element, value) => {
    if (!element) return false;
    element.value = value;
    try {
      const descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value') || 
                         Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element), 'value');
      if (descriptor && descriptor.set) {
        descriptor.set.call(element, value);
      }
    } catch (_) {}
    element.dispatchEvent(new Event('focus', { bubbles: true }));
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  };

  const isVisible = (element) => {
    const style = window.getComputedStyle(element);
    return !!element && style && style.display !== 'none' && style.visibility !== 'hidden' && element.getClientRects().length > 0;
  };

  const isCaptcha = (element) => {
    const meta = [element.id, element.name, element.placeholder, element.className].filter(Boolean).join(" ").toLowerCase();
    return /captcha|code|verif|validate|security/i.test(meta);
  };

  const scoreField = (element) => {
    const meta = [element.name, element.id, element.placeholder, element.autocomplete, element.type].filter(Boolean).join(' ').toLowerCase();
    let score = 0;
    if (/email|user|username|login|roll|reg|id|student|account/.test(meta)) score += 5;
    if (/search|query|find|filter/.test(meta)) score -= 5;
    if (element.type === 'text' || element.type === 'email' || element.type === 'tel' || element.type === 'number') score += 1;
    if (!isVisible(element)) score -= 10;
    if (isCaptcha(element)) score -= 20; // Ensure captcha inputs never match as username
    return score;
  };

  let attempts = 0;
  const tryFill = () => {
    attempts++;
    const pwd = document.querySelector('input[type="password"]');
    const scope = document;
    const candidates = Array.from(scope.querySelectorAll('input, textarea'))
      .filter((element) => element !== pwd)
      .filter((element) => {
        const type = (element.type || '').toLowerCase();
        return type !== 'hidden' && type !== 'password';
      })
      .sort((a, b) => scoreField(b) - scoreField(a));
    const user = candidates[0] || null;

    let filledUser = false;
    let filledPass = false;

    if (user) {
      filledUser = setNativeValue(user, $jsUser);
    }
    if (pwd) {
      filledPass = setNativeValue(pwd, $jsPass);
    }

    if ((filledUser && filledPass) || attempts >= 8) {
      // Find and solve captcha if filled successfully
      const captchaInput = Array.from(document.querySelectorAll('input')).find(input => {
        const type = (input.type || '').toLowerCase();
        if (type !== "text" && type !== "number") return false;
        const meta = [input.id, input.name, input.placeholder, input.className].filter(Boolean).join(" ").toLowerCase();
        return /captcha|code|validate|verif|security/i.test(meta);
      });
      
      if (captchaInput) {
        const solveMath = () => {
          const textElements = Array.from(document.querySelectorAll('label, span, div, p, td, b'));
          for (const el of textElements) {
            const text = el.innerText || '';
            const match = text.match(/(\\d+)\\s*([\\+\\-\\*])\\s*(\\d+)/) || 
                          text.match(/(\\d+)\\s*(plus|minus|times)\\s*(\\d+)/i);
            if (match) {
              const num1 = parseInt(match[1]);
              const op = match[2].toLowerCase();
              const num2 = parseInt(match[3]);
              let ans = null;
              if (op === '+' || op === 'plus') ans = num1 + num2;
              else if (op === '-' || op === 'minus') ans = num1 - num2;
              else if (op === '*' || op === 'times') ans = num1 * num2;
              if (ans !== null) return ans.toString();
            }
          }
          return null;
        };

        const solvedVal = solveMath();
        if (solvedVal) {
          setNativeValue(captchaInput, solvedVal);
        } else {
          setTimeout(() => {
            captchaInput.focus();
            captchaInput.scrollIntoView({ behavior: "smooth", block: "center" });
          }, 300);
        }
      }
    } else {
      setTimeout(tryFill, 250); // Retry after 250ms
    }
  };

  tryFill();
})();
''';
    await _controller.runJavaScript(script);
    await _updateSessionMetadata();
    HapticFeedback.lightImpact();
    if (mounted) {
      setState(() => _showAutofillPrompt = false);
    }
    _showTopPill(
      text: '✓ Credentials autofilled',
      icon: Icons.vpn_key_rounded,
      tone: IrisTokens.brand,
    );
  }

  Future<void> _autofillSuggestedRegistration() async {
    if (widget.sessionScope == 'faculty' ||
        _currentUrl.toLowerCase().contains('faculty.comsats')) {
      return;
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      final rawBatch =
          prefs.getString('current_batch') ??
          prefs.getString('student_batch') ??
          '';
      final savedRoll = prefs.getString('student_roll_no') ?? '';

      String suggestedReg = '';
      final trimmedBatch = rawBatch.trim().toUpperCase();

      // Check if full reg number e.g. FA25-BCS-101 or SP23-BSE-055
      final fullMatch = RegExp(
        r'^((?:FA|SP)\d{2})-([A-Z]{2,6})-(\d{1,4})$',
      ).firstMatch(trimmedBatch);
      if (fullMatch != null) {
        final sess = fullMatch.group(1)!;
        final prog = fullMatch.group(2)!;
        final num = fullMatch.group(3)!.padLeft(3, '0');
        suggestedReg = '$sess-$prog-$num';
      } else if (trimmedBatch.isNotEmpty) {
        final key = BatchKey.parse(trimmedBatch);
        final session = key.intake.isNotEmpty
            ? key.intake.toUpperCase()
            : 'FA25';
        final prog = key.program.isNotEmpty ? key.program.toUpperCase() : 'BCS';

        // Extract 3-digit roll number if typed in keypad or rawBatch
        String rollNum = savedRoll.trim();
        final rawRollMatch = RegExp(r'\d{3}').firstMatch(trimmedBatch);
        if (rollNum.isEmpty && rawRollMatch != null) {
          rollNum = rawRollMatch.group(0)!;
        }

        if (rollNum.isNotEmpty) {
          final paddedRoll = rollNum.padLeft(3, '0');
          suggestedReg = '$session-$prog-$paddedRoll';
        } else {
          suggestedReg = '$session-$prog-';
        }
      }

      if (suggestedReg.isEmpty) return;

      final jsUser = jsonEncode(suggestedReg);
      final script =
          '''
(() => {
  const setNativeValue = (element, value) => {
    if (!element) return false;
    element.value = value;
    try {
      const descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value') || 
                         Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element), 'value');
      if (descriptor && descriptor.set) {
        descriptor.set.call(element, value);
      }
    } catch (_) {}
    element.dispatchEvent(new Event('focus', { bubbles: true }));
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  };

  const isVisible = (element) => {
    const style = window.getComputedStyle(element);
    return !!element && style && style.display !== 'none' && style.visibility !== 'hidden' && element.getClientRects().length > 0;
  };

  const pwd = document.querySelector('input[type="password"]');
  const candidates = Array.from(document.querySelectorAll('input, textarea'))
    .filter((element) => element !== pwd && (element.type || '').toLowerCase() !== 'hidden')
    .filter((element) => isVisible(element));
  const user = candidates[0] || null;

  if (user && !user.value) {
    setNativeValue(user, $jsUser);
  }
})();
''';
      await _controller.runJavaScript(script);
      HapticFeedback.lightImpact();
      if (mounted) {
        setState(() => _showAutofillPrompt = false);
      }
      _showTopPill(
        text: '✓ Student ID filled ($suggestedReg)',
        icon: Icons.badge_rounded,
        tone: IrisTokens.brand,
      );
    } catch (_) {}
  }

  Future<void> _clearSavedLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final host = _hostKey.toLowerCase();
    await prefs.remove(_loginUserKey(_hostKey));
    await prefs.remove(_loginPassKey(_hostKey));
    await prefs.remove('iris_login_student_${host}_u');
    await prefs.remove('iris_login_student_${host}_p');
    await prefs.remove('iris_login_global_${host}_u');
    await prefs.remove('iris_login_global_${host}_p');
    await prefs.remove('iris_login_user_$host');
    await prefs.remove('iris_login_pass_$host');
    if (mounted) {
      setState(() {
        _hasSavedLogin = false;
      });
    }
    await _showMessage('Saved login removed for $_hostKey');
  }

  Future<void> _triggerUploadPicker() async {
    const script = '''
(() => {
  const fileInput = document.querySelector('input[type="file"]');
  if (fileInput) {
    fileInput.click();
    return true;
  }
  return false;
})();
''';
    final raw = await _controller.runJavaScriptReturningResult(script);
    final ok = _normalizeJsResult(raw).toLowerCase().contains('true');
    await _showMessage(
      ok
          ? 'Select your assignment file from picker'
          : 'No upload field found on this page',
    );
  }

  String _sanitizeFileName(String value) {
    final cleaned = value
        .replaceAll(RegExp(r'[\\/:*?"<>|]'), '_')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    return cleaned.isEmpty ? 'download.bin' : cleaned;
  }

  String _extensionForMime(String mime) {
    final normalized = mime.toLowerCase().split(';').first.trim();
    return switch (normalized) {
      'application/pdf' => '.pdf',
      'application/zip' => '.zip',
      'application/x-zip-compressed' => '.zip',
      'application/msword' => '.doc',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document' =>
        '.docx',
      'application/vnd.ms-powerpoint' => '.ppt',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation' =>
        '.pptx',
      'application/vnd.ms-excel' => '.xls',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' =>
        '.xlsx',
      'application/vnd.android.package-archive' => '.apk',
      'image/jpeg' => '.jpg',
      'image/png' => '.png',
      'text/plain' => '.txt',
      _ => '',
    };
  }

  String _ensureFileExtension(String name, String mime) {
    final safe = _sanitizeFileName(name);
    if (RegExp(r'\.[a-zA-Z0-9]{1,6}$').hasMatch(safe)) return safe;
    final ext = _extensionForMime(mime);
    if (ext.isEmpty) return safe;
    return '$safe$ext';
  }

  Future<Directory> _resolveDownloadDirectory() async {
    if (Platform.isAndroid) {
      try {
        final dirs = await getExternalStorageDirectories(
          type: StorageDirectory.downloads,
        );
        if (dirs != null && dirs.isNotEmpty) {
          return dirs.first;
        }
      } catch (_) {}
    }
    try {
      return await getApplicationDocumentsDirectory();
    } catch (_) {
      try {
        return await getTemporaryDirectory();
      } catch (_) {
        return Directory('/storage/emulated/0/Download');
      }
    }
  }

  Future<void> _saveDownloadData(
    String filename,
    String dataUrl, {
    String sourceUrl = '',
  }) async {
    try {
      final parts = dataUrl.split(',');
      if (parts.length < 2) {
        await _showMessage('Download failed: invalid file data');
        return;
      }

      final saveDir = await _resolveDownloadDirectory();
      if (!await saveDir.exists()) {
        await saveDir.create(recursive: true);
      }

      final mime = parts.first
          .toLowerCase()
          .replaceFirst('data:', '')
          .split(';')
          .first
          .trim();
      final safeName = _ensureFileExtension(filename, mime);
      final bytes = base64Decode(parts.last);
      final file = File('${saveDir.path}/$safeName');
      await file.writeAsBytes(bytes, flush: true);

      // Track the download
      await _trackDownload(
        filename: safeName,
        filePath: file.path,
        sourceUrl: sourceUrl,
        state: 'completed',
        backend: 'js',
      );
      if (!mounted) return;
      await _showMessage(
        'Download complete: $safeName',
        duration: const Duration(seconds: 6),
        action: SnackBarAction(
          label: 'Open',
          onPressed: () async {
            await _openFilePath(file.path);
          },
        ),
      );
      unawaited(
        Future<void>.delayed(const Duration(milliseconds: 300), () async {
          if (!mounted) return;
          await _showMessage(
            'Open Download Manager for recent files',
            duration: const Duration(seconds: 5),
            action: SnackBarAction(
              label: 'Manager',
              onPressed: () async => _showDownloadManager(),
            ),
          );
        }),
      );
    } catch (_) {
      await _showMessage('Download failed while saving file');
    } finally {
      if (mounted) {
        setState(() {});
      }
    }
  }

  String _filenameFromResponse({
    required Uri uri,
    required HttpHeaders headers,
  }) {
    final disposition = headers.value('content-disposition') ?? '';
    final utf8Name = RegExp(
      r"filename\*=UTF-8''([^;]+)",
      caseSensitive: false,
    ).firstMatch(disposition)?.group(1);
    final plainName = RegExp(
      r'filename="?([^";]+)"?',
      caseSensitive: false,
    ).firstMatch(disposition)?.group(1);
    final raw =
        utf8Name ??
        plainName ??
        (uri.pathSegments.isNotEmpty ? uri.pathSegments.last : 'download');
    final decoded = Uri.decodeComponent(raw);
    final contentType = headers.contentType?.mimeType ?? '';
    final baseName = decoded.isEmpty ? 'download' : decoded;
    return _ensureFileExtension(baseName, contentType);
  }

  Future<String> _readPortalCookieHeader([String? targetUrl]) async {
    final url = targetUrl ?? (_currentUrl.isEmpty ? widget.url : _currentUrl);
    if (Platform.isAndroid && url.isNotEmpty) {
      try {
        final nativeCookies = await _androidDownloadChannel
            .invokeMethod<String>('getCookiesForUrl', {'url': url});
        if (nativeCookies != null && nativeCookies.trim().isNotEmpty) {
          return nativeCookies.trim();
        }
      } catch (_) {}
    }

    try {
      final raw = await _controller.runJavaScriptReturningResult(
        'document.cookie',
      );
      return _normalizeJsResult(raw).trim();
    } catch (_) {
      return '';
    }
  }

  String _fileNameFromUrl(Uri uri) {
    if (uri.pathSegments.isNotEmpty) {
      final raw = uri.pathSegments.last.trim();
      if (raw.isNotEmpty) {
        return _sanitizeFileName(Uri.decodeComponent(raw));
      }
    }
    return 'download';
  }

  // bool _isSameHost(Uri a, Uri b) {
  //   return a.host == b.host ||
  //       a.host.endsWith('.${b.host}') ||
  //       b.host.endsWith('.${a.host}');
  // }

  Future<void> _downloadFileFast(Uri uri) async {
    final saveDir = await _resolveDownloadDirectory();
    if (!await saveDir.exists()) {
      await saveDir.create(recursive: true);
    }

    final cookieHeader = await _readPortalCookieHeader(uri.toString());
    final currentUri = Uri.tryParse(
      _currentUrl.isEmpty ? widget.url : _currentUrl,
    );
    final sameHost =
        currentUri != null &&
        (uri.host == currentUri.host ||
            uri.host.endsWith('.${currentUri.host}') ||
            currentUri.host.endsWith('.${uri.host}'));
    final referer = sameHost
        ? currentUri.toString()
        : '${uri.scheme}://${uri.host}/';

    // Robust client with SSL bypass for university portals
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 25)
      ..badCertificateCallback = (cert, host, port) => true;

    IOSink? sink;
    File? tempFile;
    try {
      final request = await client
          .getUrl(uri)
          .timeout(const Duration(seconds: 20));
      request.followRedirects = true;
      request.maxRedirects = 8;
      request.headers.set(HttpHeaders.userAgentHeader, _portalUserAgent);
      request.headers.set(HttpHeaders.acceptHeader, '*/*');
      request.headers.set(HttpHeaders.refererHeader, referer);
      request.headers.set('Connection', 'keep-alive');

      if (sameHost && cookieHeader.isNotEmpty) {
        request.headers.set(HttpHeaders.cookieHeader, cookieHeader);
      }

      final response = await request.close().timeout(
        const Duration(seconds: 120),
      );

      // Handle common portal status codes
      if (response.statusCode == 401 || response.statusCode == 403) {
        throw HttpException('Access Denied (${response.statusCode})', uri: uri);
      }
      if (response.statusCode >= 400) {
        throw HttpException('Server Error (${response.statusCode})', uri: uri);
      }

      final safeName = _filenameFromResponse(
        uri: uri,
        headers: response.headers,
      );
      final finalFile = File('${saveDir.path}/$safeName');
      tempFile = File('${saveDir.path}/.$safeName.part');

      if (await tempFile.exists()) {
        try {
          await tempFile.delete();
        } catch (_) {}
      }

      sink = tempFile.openWrite();

      final total = response.contentLength;
      int loaded = 0;
      int lastPercent = -1;

      await for (final chunk in response) {
        sink.add(chunk);
        loaded += chunk.length;
        if (!mounted) continue;
        if (total > 0) {
          final percent = ((loaded / total) * 100).clamp(0, 100).toInt();
          if (percent != lastPercent &&
              (percent == 100 || percent - lastPercent >= 2)) {
            lastPercent = percent;
            setState(() {});
          }
        } else {
          // Indeterminate progress
          if (loaded % (100 * 1024) == 0) {
            // Every 100KB
            setState(() {});
          }
        }
      }

      await sink.flush();
      await sink.close();
      sink = null;

      if (await finalFile.exists()) {
        try {
          await finalFile.delete();
        } catch (_) {}
      }
      await tempFile.rename(finalFile.path);

      await _trackDownload(
        filename: safeName,
        filePath: finalFile.path,
        sourceUrl: uri.toString(),
        state: 'completed',
        backend: 'native',
      );

      if (mounted) {
        setState(() {});
        await _showMessage(
          'Download complete: $safeName',
          duration: const Duration(seconds: 5),
          action: SnackBarAction(
            label: 'Open',
            onPressed: () async => _openFilePath(finalFile.path),
          ),
        );
      }
    } catch (e) {
      try {
        await sink?.flush();
        await sink?.close();
      } catch (_) {}
      if (tempFile != null && await tempFile.exists()) {
        try {
          await tempFile.delete();
        } catch (_) {}
      }
      rethrow;
    }
  }

  /// One-press reliable download flow
  Future<void> _downloadFile(String url) async {
    if (!mounted) return;

    // Normalize and validate URL
    final uri = Uri.tryParse(url.trim());
    if (uri == null || (!uri.hasScheme && !url.startsWith('data:'))) {
      await _showMessage('Invalid download link');
      return;
    }

    // Debounce to prevent multiple triggers
    final now = DateTime.now().millisecondsSinceEpoch;
    if (_lastDownloadUrl == url && (now - _lastDownloadAtMs) < 5000) return;
    _lastDownloadUrl = url;
    _lastDownloadAtMs = now;

    // Handle Data URLs directly
    if (url.startsWith('data:')) {
      await _showMessage('Saving generated file...');
      try {
        final commaIndex = url.indexOf(',');
        if (commaIndex == -1) throw 'Invalid data URL';
        final data = url.substring(commaIndex + 1);
        final filename = 'download_${now % 10000}.bin';
        await _saveDownloadData(filename, data, sourceUrl: 'data:...');
      } catch (e) {
        await _showMessage('Failed to save data URL');
      }
      return;
    }

    setState(() {});
    await _showMessage('Starting download...');

    // Try System Download Manager on Android first
    if (Platform.isAndroid) {
      try {
        final cookieHeader = await _readPortalCookieHeader(uri.toString());
        final currentUri = Uri.tryParse(
          _currentUrl.isEmpty ? widget.url : _currentUrl,
        );
        final sameHost =
            currentUri != null &&
            (uri.host == currentUri.host ||
                uri.host.endsWith('.${currentUri.host}') ||
                currentUri.host.endsWith('.${uri.host}'));
        final referer = sameHost
            ? currentUri.toString()
            : '${uri.scheme}://${uri.host}/';

        final fileName = _fileNameFromUrl(uri);

        final result = await _androidDownloadChannel
            .invokeMapMethod<String, dynamic>('enqueueSystemDownload', {
              'url': uri.toString(),
              'userAgent': _portalUserAgent,
              'referer': referer,
              'cookie': cookieHeader,
              'fileName': fileName,
            });

        if (result != null) {
          final downloadId = result['downloadId']?.toString() ?? '';
          final finalFileName = result['fileName']?.toString() ?? fileName;
          final filePath = result['filePath']?.toString() ?? '';

          await _trackDownload(
            filename: finalFileName,
            filePath: filePath,
            sourceUrl: uri.toString(),
            state: 'running',
            backend: 'system',
            downloadId: downloadId,
          );

          await _showMessage(
            'Download started: $finalFileName. Check system notifications.',
          );

          if (mounted) {
            setState(() {});
          }
          return;
        }
      } catch (e) {
        debugPrint(
          'Android System DownloadManager failed, falling back to native client: $e',
        );
      }
    }

    try {
      // Execute the robust native download
      await _downloadFileFast(uri);
    } catch (e) {
      if (!mounted) return;
      setState(() {});

      final errorMsg = e.toString().contains('HttpException')
          ? e.toString().split(':').last.trim()
          : 'Network error or access denied';

      await _trackDownload(
        filename: _fileNameFromUrl(uri),
        filePath: '',
        sourceUrl: uri.toString(),
        state: 'failed',
        backend: 'native',
        downloadId: '',
      );

      await _showMessage('Download failed: $errorMsg');
    }
  }

  // Handles messages from the injected JS channel
  Future<void> _handleJsMessage(JavaScriptMessage message) async {
    try {
      final data = jsonDecode(message.message);
      final type = data['type']?.toString() ?? '';

      // Ignore scraper logs or deep sync messages on the interactive portal
      if (type == 'log' || type.startsWith('portal_sync')) {
        return;
      }

      if (type == 'login_submit') {
        _autoSaveLogin(
          username: data['username']?.toString() ?? '',
          password: data['password']?.toString() ?? '',
        );
      } else if (type == 'login_focus') {
        if (mounted && _hasSavedLogin && !_showAutofillPrompt) {
          _stopLoginFocusWatch();
          setState(() => _showAutofillPrompt = true);
        }
      } else if (type == 'download') {
        final url = data['url']?.toString() ?? '';
        if (url.isNotEmpty) _downloadFile(url);
      } else if (type == 'download_progress') {
        if (mounted) {
          setState(() {});
        }
      } else if (type == 'download_data') {
        final filename = data['filename']?.toString() ?? 'download';
        final dataUrl = data['data']?.toString() ?? '';
        final sourceUrl = data['sourceUrl']?.toString() ?? '';
        if (dataUrl.isNotEmpty) {
          if (mounted) {}
          _saveDownloadData(filename, dataUrl, sourceUrl: sourceUrl);
        } else if (mounted) {
          setState(() {});
        }
      } else if (type == 'download_error') {
        final sourceUrl =
            data['sourceUrl']?.toString() ?? data['url']?.toString() ?? '';
        if (mounted) {
          setState(() {});

          _showMessage('Download failed: ${data['error'] ?? 'unknown error'}');
        }
        final failedUri = Uri.tryParse(sourceUrl);
        if (failedUri != null) {
          _trackDownload(
            filename: _fileNameFromUrl(failedUri),
            filePath: '',
            sourceUrl: failedUri.toString(),
            state: 'failed',
            backend: 'js',
          );
        }
      } else if (type == 'download_retry') {
        if (mounted) {
          final attempt = (data['attempt'] as num?)?.toInt() ?? 0;
          if (attempt > 0) {
            _showMessage('Retrying download... attempt $attempt');
          }
        }
      }
    } catch (_) {}
  }

  // Automatically saves portal credentials after form submit so background deep sync and future visits succeed seamlessly
  Future<void> _autoSaveLogin({
    required String username,
    required String password,
  }) async {
    final trimmedUser = username.trim();
    final trimmedPass = password.trim();
    if (trimmedUser.isEmpty || trimmedPass.isEmpty) return;

    try {
      final host = _hostKey;
      final hostLower = host.toLowerCase();
      final prefs = await SharedPreferences.getInstance();
      final encUser = base64Encode(utf8.encode(trimmedUser));
      final encPass = base64Encode(utf8.encode(trimmedPass));

      // 1. Save canonical scope key
      await prefs.setString(_loginUserKey(host), encUser);
      await prefs.setString(_loginPassKey(host), encPass);

      // 2. Save fallback keys for HeadlessPortalSync and SessionRefresherService
      await prefs.setString('iris_login_student_${hostLower}_u', encUser);
      await prefs.setString('iris_login_student_${hostLower}_p', encPass);
      await prefs.setString('iris_login_global_${hostLower}_u', encUser);
      await prefs.setString('iris_login_global_${hostLower}_p', encPass);
      await prefs.setString('iris_login_user_$hostLower', encUser);
      await prefs.setString('iris_login_pass_$hostLower', encPass);

      // 3. Update session with saved username
      _currentSession = _currentSession.copyWith(savedUsername: trimmedUser);
      await _savePortalSession();

      HapticFeedback.lightImpact();

      if (mounted) {
        setState(() {
          _hasSavedLogin = true;
          _showAutofillPrompt = false;
        });

        _showTopPill(
          text: '✓ Saved login for $trimmedUser',
          icon: Icons.check_circle_outline_rounded,
          tone: IrisTokens.brand,
        );
      }
      debugPrint(
        '🔑 [PortalScreen] Auto-saved portal credentials for $host ($trimmedUser)',
      );
    } catch (e) {
      debugPrint('❌ [PortalScreen] Error auto-saving portal credentials: $e');
    }
  }

  // Native file picker for WebView file inputs (Android)
  Future<List<String>> _handleFileSelector(FileSelectorParams params) async {
    try {
      final result = await FilePicker.platform.pickFiles(
        allowMultiple: params.mode == FileSelectorMode.openMultiple,
        type: FileType.any,
      );
      if (result == null) return [];
      final paths = result.paths.whereType<String>().toList();
      // Track uploaded files
      for (final path in paths) {
        await _trackUpload(path);
      }
      return paths;
    } catch (_) {
      return [];
    }
  }

  String get addressLabelSafe => _currentUrl.isEmpty ? widget.url : _currentUrl;

  static const String _savePasswordScript = r'''
(() => {
  if (window._irisFormWatcher) return;
  window._irisFormWatcher = true;

  let lastUsername = '';
  let lastPassword = '';
  let lastSentToken = '';

  const scoreField = (element) => {
    if (!element) return -10;
    const meta = [element.name, element.id, element.placeholder, element.autocomplete, element.type].filter(Boolean).join(' ').toLowerCase();
    let score = 0;
    if (/email|user|username|login|roll|reg|id|student|account/.test(meta)) score += 6;
    if (/search|query|filter|searchtext/.test(meta)) score -= 8;
    if (/password/.test(meta)) score -= 10;
    if (element.type === 'text' || element.type === 'email' || element.type === 'tel' || element.type === 'number') score += 2;
    if (element.value && element.value.trim().length > 0) score += 4;
    return score;
  };

  const captureCredentials = () => {
    const pwdFields = Array.from(document.querySelectorAll('input[type="password"]'));
    if (!pwdFields.length) return;
    
    // Select password field that has a value, or the first one
    const pwdField = pwdFields.find(p => p.value && p.value.length > 0) || pwdFields[0];
    if (pwdField && pwdField.value) {
      lastPassword = pwdField.value;
    }
    
    // Look within the same form first for highest accuracy
    const scope = (pwdField && pwdField.form) ? pwdField.form : document;
    const candidates = Array.from(scope.querySelectorAll('input, textarea'))
      .filter((el) => el !== pwdField)
      .filter((el) => {
        const type = (el.type || '').toLowerCase();
        return type !== 'hidden' && type !== 'password' && type !== 'submit' && type !== 'button' && type !== 'reset';
      })
      .sort((a, b) => scoreField(b) - scoreField(a));
      
    const userField = candidates[0];
    if (userField && userField.value) {
      lastUsername = userField.value.trim();
    }
  };

  const sendCredentials = () => {
    captureCredentials();
    if (!lastPassword || !lastUsername) return;
    
    const token = lastUsername + '::' + lastPassword;
    if (token === lastSentToken) return;
    lastSentToken = token;
    
    if (window.IrisPortalChannel) {
      window.IrisPortalChannel.postMessage(JSON.stringify({
        type: 'login_submit',
        username: lastUsername,
        password: lastPassword
      }));
    }
  };

  // 1. Dynamic input & change tracking
  document.addEventListener('input', (e) => {
    if (e.target && e.target.tagName === 'INPUT') {
      captureCredentials();
    }
  }, true);

  document.addEventListener('change', (e) => {
    if (e.target && e.target.tagName === 'INPUT') {
      captureCredentials();
    }
  }, true);

  // 2. Enter key submission (common in portals and hardware/virtual keyboards)
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.keyCode === 13) {
      captureCredentials();
      if (lastUsername && lastPassword) {
        sendCredentials();
      }
    }
  }, true);

  // 3. Form submit event
  document.addEventListener('submit', (e) => {
    captureCredentials();
    sendCredentials();
  }, true);

  // 4. Programmatic HTMLFormElement.prototype.submit interception
  try {
    const origSubmit = HTMLFormElement.prototype.submit;
    HTMLFormElement.prototype.submit = function() {
      try {
        captureCredentials();
        sendCredentials();
      } catch (_) {}
      return origSubmit.apply(this, arguments);
    };
  } catch (_) {}

  // 5. Button clicks on submit/login buttons
  document.addEventListener('click', (e) => {
    const target = e.target;
    if (!target) return;
    
    const tag = (target.tagName || '').toLowerCase();
    const type = (target.type || '').toLowerCase();
    const meta = [target.id, target.name, target.className, target.value, target.innerText]
      .filter(Boolean).join(' ').toLowerCase();
      
    const isSubmitBtn = tag === 'button' || 
                        (tag === 'input' && (type === 'submit' || type === 'button')) ||
                        /login|submit|sign\s*in|log\s*in|enter|continue|proceed|next/i.test(meta);
                        
    if (isSubmitBtn) {
      captureCredentials();
      sendCredentials();
      setTimeout(sendCredentials, 60);
    }
  }, true);

  // 6. Navigation / Unload handlers so credentials are never lost during page change
  window.addEventListener('beforeunload', () => {
    captureCredentials();
    sendCredentials();
  }, true);
  window.addEventListener('pagehide', () => {
    captureCredentials();
    sendCredentials();
  }, true);

  // 7. Initial checks for pre-filled or browser-filled fields
  setTimeout(captureCredentials, 350);
  setTimeout(captureCredentials, 1000);
})();
''';

  // Intercepts download link clicks and routes them to the native handler with browser-context fetch
  static const String _downloadInterceptScript = r'''
(() => {
  if (window._irisDownloadWatcher) return;
  window._irisDownloadWatcher = true;
  
  const isDownloadUrl = (url, anchor) => {
    if (!url) return false;
    const lower = url.toLowerCase();
    if (anchor && anchor.hasAttribute('download')) return true;
    
    // Check extension
    const cleanUrl = lower.split('?')[0].split('#')[0];
    const extensions = ['.pdf', '.doc', '.docx', '.ppt', '.pptx', '.xls', '.xlsx', '.zip', '.rar', '.7z', '.apk', '.png', '.jpg', '.jpeg', '.txt', '.csv'];
    if (extensions.some(ext => cleanUrl.endsWith(ext))) return true;

    // Check page extensions that shouldn't be downloads unless they have query params
    const pageExtensions = ['.aspx', '.php', '.html', '.htm', '.jsp'];
    const isPageExt = pageExtensions.some(ext => cleanUrl.endsWith(ext));
    const hasQuery = lower.includes('?');

    // Keywords that are always downloads
    const keywords = ['getfile', 'getassignment', 'assignmentfile', 'resultcard', 'challan', 'fee_challan', 'printchallan', 'attachment'];
    if (keywords.some(kw => lower.includes(kw))) {
      const path = cleanUrl.replace(/^https?:\/\/[^\/]+/, '');
      if (!hasQuery) {
        if (path === '/student/resultcard' || 
            path === '/student/challan' || 
            path === '/student/printchallan' || 
            path === '/student/fee_challan' ||
            path.endsWith('/resultcard') || 
            path.endsWith('/challan') || 
            path.endsWith('/printchallan') || 
            path.endsWith('/fee_challan')) {
          return false;
        }
      }
      return true;
    }

    if (lower.includes('download') || lower.includes('export') || lower.includes('stream') || lower.includes('generate') || lower.includes('viewfile')) {
      if (isPageExt && !hasQuery) return false;
      const path = cleanUrl.replace(/^https?:\/\/[^\/]+/, '');
      if (path === '/download' || path === '/downloads' || path === '/export' || path.endsWith('/download') || path.endsWith('/downloads')) {
        return false;
      }
      return true;
    }
    return false;
  };

  const fetchAndPassDownload = async (url, suggestedName) => {
    try {
      if (window.IrisPortalChannel) {
        window.IrisPortalChannel.postMessage(JSON.stringify({ type: 'download_retry', attempt: 1 }));
      }
      const response = await fetch(url, { credentials: 'include' });
      if (!response.ok) throw new Error('HTTP ' + response.status);

      const disposition = response.headers.get('content-disposition') || '';
      let filename = suggestedName || '';
      const filenameMatch = disposition.match(/filename\*=UTF-8''([^;]+)|filename="?([^";]+)"?/i);
      if (filenameMatch) {
        filename = decodeURIComponent(filenameMatch[1] || filenameMatch[2] || filename);
      }
      if (!filename) {
        filename = url.split('/').pop().split('?')[0] || 'download.pdf';
      }

      const blob = await response.blob();
      const reader = new FileReader();
      reader.onloadend = () => {
        const dataUrl = reader.result;
        if (window.IrisPortalChannel) {
          window.IrisPortalChannel.postMessage(JSON.stringify({
            type: 'download_data',
            filename: filename,
            data: dataUrl,
            sourceUrl: url
          }));
        }
      };
      reader.readAsDataURL(blob);
    } catch (err) {
      if (window.IrisPortalChannel) {
        window.IrisPortalChannel.postMessage(JSON.stringify({ type: 'download', url: url }));
      }
    }
  };

  document.addEventListener('click', function(e) {
    const a = e.target.closest ? e.target.closest('a[href]') : null;
    if (!a) return;
    
    const href = a.href || '';
    if (href.startsWith('javascript:') || href.startsWith('mailto:') || href.startsWith('tel:')) return;
    
    if (isDownloadUrl(href, a)) {
      if (window.IrisPortalChannel) {
        e.preventDefault();
        e.stopPropagation();
        const suggestedName = a.getAttribute('download') || (a.innerText || '').trim();
        fetchAndPassDownload(href, suggestedName);
      }
    }
  }, true);
})();
''';

  static const String _modernizeFormScript = '''
(() => {
  try {
    const styleId = 'iris-modern-form-style';
    if (!document.getElementById(styleId)) {
      const style = document.createElement('style');
      style.id = styleId;
      style.textContent = `
        input, select, textarea {
          min-height: 42px !important;
          font-size: 16px !important;
          border-radius: 10px !important;
        }
        input:focus, select:focus, textarea:focus, button:focus {
          outline: 2px solid rgba(91,127,255,0.25) !important;
          outline-offset: 1px !important;
        }
        button {
          min-height: 40px !important;
          border-radius: 10px !important;
        }
      `;
      const targetHead = document.head || document.documentElement || document.body;
      if (targetHead) {
        targetHead.appendChild(style);
      }
    }
  } catch (_) {}
})();
''';

  /// Universal Extraction Engine for COMSATS Portal (Mobile Optimized)
  // Shared with HeadlessPortalSync

  Future<void> _updateNavState() async {
    final canBack = await _controller.canGoBack();
    final canForward = await _controller.canGoForward();
    final current = await _controller.currentUrl() ?? widget.url;
    if (!mounted) return;
    setState(() {
      _canGoBack = canBack;
      _canGoForward = canForward;
      _currentUrl = current;
    });
  }

  Future<void> _openAddressBar() async {
    if (!mounted) return;
    setState(() {
      _isEditingAddress = true;
      _addressController.text = addressLabelSafe;
      _addressController.selection = TextSelection(
        baseOffset: 0,
        extentOffset: _addressController.text.length,
      );
    });
  }

  void _cancelAddressEdit() {
    if (!mounted) return;
    setState(() {
      _isEditingAddress = false;
      _addressController.clear();
    });
  }

  Future<void> _submitAddressBar(String rawValue) async {
    final trimmed = rawValue.trim();
    if (trimmed.isEmpty) {
      _cancelAddressEdit();
      return;
    }
    final normalized =
        trimmed.startsWith('http://') || trimmed.startsWith('https://')
        ? trimmed
        : 'https://$trimmed';
    final uri = Uri.tryParse(normalized);
    if (uri == null || !uri.hasScheme) {
      await _showMessage('Invalid address');
      return;
    }

    await _controller.loadRequest(uri);
    await _updateNavState();
    _cancelAddressEdit();
  }

  @override
  void initState() {
    super.initState();
    AnalyticsManager().trackScreenView('portal_$_scopeSanitized');

    _currentUrl = widget.url;

    // Initialize session (will be populated from prefs or created fresh)
    _currentSession = PortalSession(
      host: Uri.tryParse(widget.url)?.host ?? 'portal',
      title: widget.title,
      url: widget.url,
      createdAt: DateTime.now().millisecondsSinceEpoch,
      lastAccessedAt: DateTime.now().millisecondsSinceEpoch,
    );

    final isDark =
        WidgetsBinding.instance.platformDispatcher.platformBrightness ==
        Brightness.dark;
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(isDark ? const Color(0xFF151D2C) : Colors.white)
      ..setUserAgent(_portalUserAgent)
      ..addJavaScriptChannel(
        'IrisPortalChannel',
        onMessageReceived: _handleJsMessage,
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onNavigationRequest: (request) async {
            if (request.url.toLowerCase().contains('login.aspx')) {
              final fixedUrl = sanitizePortalUrl(request.url);
              Future.microtask(
                () => _controller.loadRequest(Uri.parse(fixedUrl)),
              );
              return NavigationDecision.prevent;
            }
            final uri = Uri.tryParse(request.url);
            if (uri != null) {
              await _restoreSessionCookiesForUri(uri);
            }
            if (_looksDownloadableUrl(request.url)) {
              _downloadFile(request.url);
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
          onProgress: (value) {
            if (!mounted) return;
            _loadProgressNotifier.value = value;
            if (value >= 100 && _isLoading) {
              setState(() {
                _isLoading = false;
              });
            }
          },
          onPageStarted: (url) {
            if (!mounted) return;
            _loadProgressNotifier.value = 0;
            _stopLoginFocusWatch();
            if (_looksDownloadableUrl(url)) {
              _downloadFile(url);
              _controller.goBack().catchError((_) {});
              return;
            }
            setState(() {
              _isLoading = true;
              _hasLoginForm = false;
              _hasFileUpload = false;
              _showAutofillPrompt = false;
            });
            _checkConnectivity();
          },
          onPageFinished: (url) async {
            if (!mounted) return;
            if (_looksDownloadableUrl(url)) {
              _downloadFile(url);
              if (await _controller.canGoBack()) {
                await _controller.goBack();
              }
              return;
            }
            _currentUrl = url;

            final lowerUrl = url.toLowerCase();
            final isChallenge =
                lowerUrl.contains('challenge') ||
                lowerUrl.contains('cdn-cgi') ||
                lowerUrl.contains('turnstile') ||
                lowerUrl.contains('captcha');

            if (!isChallenge) {
              try {
                await _controller.runJavaScript(_modernizeFormScript);
                await _controller.runJavaScript(_savePasswordScript);
                await _controller.runJavaScript(_downloadInterceptScript);
              } catch (e) {
                debugPrint('⚠️ [Portal] Script execution caught: $e');
              }

              // Sync cookies aggressively
              try {
                await _persistSessionCookiesForUrl(url);
                await _updateSessionMetadata();
              } catch (_) {}

              if (mounted) {
                setState(() {
                  _isLoading = false;
                });
              }

              try {
                await _updateNavState();
                _startLoginFocusWatch();
                await _checkConnectivity();

                // Detect features after page loads
                await Future.delayed(const Duration(milliseconds: 500));
                await _detectPageFeatures();
              } catch (_) {}
            } else {
              // During Cloudflare challenge: keep page completely untouched by scripts so Turnstile passes
              _stopLoginFocusWatch();
              try {
                await _persistSessionCookiesForUrl(url);
              } catch (_) {}
              if (mounted) {
                setState(() {
                  _isLoading = false;
                });
              }
              await _updateNavState();
            }
          },
          onWebResourceError: (error) async {
            if (!mounted) return;
            final isMain = error.isForMainFrame == true;
            final isAbort = error.description.contains('ERR_ABORTED') || error.errorCode == -1;
            final isCache = error.description.contains('ERR_CACHE_MISS');
            if (isMain && !isAbort && !isCache) {
              setState(() {
                _isOffline = true;
                _isLoading = false;
              });
              await _showMessage('Portal connection timed out');
            }
          },
        ),
      );

    // Enable native file picker & strip WebView bot signature for Cloudflare Turnstile bypass
    if (Platform.isAndroid) {
      final platform = _controller.platform;
      if (platform is AndroidWebViewController) {
        platform.setOnShowFileSelector(_handleFileSelector);
        platform.setMediaPlaybackRequiresUserGesture(false);
        platform.getUserAgent().then((ua) {
          if (ua != null && ua.isNotEmpty) {
            // Strip '; wv' and 'Version/X.X' so Cloudflare recognizes native mobile Chrome
            final cleanUa = ua
                .replaceAll('; wv', '')
                .replaceAll(RegExp(r'Version/\d+\.\d+\s*'), '');
            _controller.setUserAgent(cleanUa);
          }
        });
      }
    }

    final initialUri = Uri.parse(sanitizePortalUrl(widget.url));
    Future.microtask(() async {
      // Restore last active session first, fallback to portal-specific session, then widget URL.
      final lastActive = await _loadLastActiveSession();
      Uri launchUri = initialUri;
      if (lastActive != null) {
        _currentSession = lastActive;
        final cleanUrl = sanitizePortalUrl(lastActive.url);
        final parsed = Uri.tryParse(cleanUrl);
        if (parsed != null) {
          launchUri = parsed;
          _currentUrl = launchUri.toString();
        }
      } else {
        final existingSession = await _loadPortalSession(initialUri.host);
        if (existingSession != null) {
          _currentSession = existingSession;
          if (existingSession.url.isNotEmpty) {
            final cleanUrl = sanitizePortalUrl(existingSession.url);
            final parsed = Uri.tryParse(cleanUrl);
            if (parsed != null) {
              launchUri = parsed;
              _currentUrl = launchUri.toString();
            }
          }
        }
      }

      final sanitizedLaunchUrl = sanitizePortalUrl(launchUri.toString());
      launchUri = Uri.parse(sanitizedLaunchUrl);
      _currentUrl = sanitizedLaunchUrl;

      await _restoreSessionCookiesForUri(launchUri);
      await _controller.loadRequest(launchUri);
      await _checkConnectivity();
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _updateNavState();
    });

    _connectivityTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted && TickerMode.valuesOf(context).enabled) {
        _checkConnectivity();
      }
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    if (_lastAppliedDark != isDark) {
      _lastAppliedDark = isDark;
      _controller.setBackgroundColor(
        isDark ? const Color(0xFF151D2C) : Colors.white,
      );
    }
  }

  @override
  void dispose() {
    _connectivityTimer?.cancel();
    _loginFocusTimer?.cancel();
    _pillRevertTimer?.cancel();
    _addressController.dispose();
    _loadProgressNotifier.dispose();
    super.dispose();
  }

  Widget _buildDynamicIslandLeftStatus(bool isDark, Color accent) {
    if (_pillActive) {
      return Container(
        margin: const EdgeInsets.only(right: 8),
        width: 22,
        height: 22,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _pillTone.withValues(alpha: 0.14),
          border: Border.all(
            color: _pillTone.withValues(alpha: 0.32),
            width: 0.9,
          ),
        ),
        child: Icon(
          _pillIcon ?? Icons.notifications_none_rounded,
          size: 14,
          color: _pillTone,
        ),
      );
    }

    if (_isLoading) {
      return Padding(
        padding: const EdgeInsets.only(right: 8),
        child: IrisComponents.loadingSpinner(
          size: 14,
          strokeWidth: 2.0,
          color: accent,
        ),
      );
    }

    // Default left status when header is collapsed
    Widget child;
    Color containerBg = Colors.transparent;
    Border? border;

    if (_isOffline) {
      child = const Icon(
        Icons.wifi_off_rounded,
        size: 12,
        color: Color(0xFFEF4444),
      );
      containerBg = const Color(0xFFEF4444).withValues(alpha: 0.12);
      border = Border.all(
        color: const Color(0xFFEF4444).withValues(alpha: 0.32),
        width: 0.85,
      );
    } else if (_hasSavedLogin) {
      child = Icon(Icons.vpn_key_rounded, size: 12, color: IrisTokens.success);
      containerBg = IrisTokens.success.withValues(alpha: 0.12);
      border = Border.all(
        color: IrisTokens.success.withValues(alpha: 0.32),
        width: 0.85,
      );
    } else {
      // Clean static status dot
      return Container(
        margin: const EdgeInsets.only(right: 8),
        width: 14,
        height: 14,
        alignment: Alignment.center,
        child: Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: IrisTokens.success,
            boxShadow: [
              BoxShadow(
                color: IrisTokens.success.withValues(alpha: 0.35),
                blurRadius: 4,
                spreadRadius: 1,
              ),
            ],
          ),
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.only(right: 8),
      width: 22,
      height: 22,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: containerBg,
        border: border,
      ),
      child: child,
    );
  }

  Widget _buildDynamicIslandContent({
    required BuildContext context,
    required bool isDark,
    required Color panelText,
    required Color panelMuted,
    required Color accent,
    required String idleTitle,
  }) {
    // 1. Temporary Active Pill (Notification, action, or alert)
    if (_pillActive) {
      return Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _buildDynamicIslandLeftStatus(isDark, accent),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              _pillMessage ?? widget.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.22,
                color: panelText,
                decoration: TextDecoration.none,
              ),
            ),
          ),
          if (_pillAction != null && _pillActionLabel != null) ...[
            const SizedBox(width: 6),
            GestureDetector(
              onTap: () {
                HapticFeedback.lightImpact();
                _pillAction!();
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: _pillTone.withValues(alpha: 0.18),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(
                    color: _pillTone.withValues(alpha: 0.38),
                    width: 0.8,
                  ),
                ),
                child: Text(
                  _pillActionLabel!,
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    color: _pillTone,
                  ),
                ),
              ),
            ),
          ],
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () => _showPortalControlsSheet(
              context: context,
              isDark: isDark,
              panelText: panelText,
              panelMuted: panelMuted,
              accent: accent,
            ),
            child: Icon(
              Icons.tune_rounded,
              size: 16,
              color: panelText.withValues(alpha: 0.75),
            ),
          ),
        ],
      );
    }

    // 2. Login Page with Saved Credentials -> Autofill Action Ready
    if (_hasLoginForm && _hasSavedLogin) {
      final brandColor = ThemeSignals.isMaterialYou
          ? Theme.of(context).colorScheme.primary
          : IrisTokens.brand;
      return Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            margin: const EdgeInsets.only(right: 6),
            width: 22,
            height: 22,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: brandColor.withValues(alpha: 0.14),
              border: Border.all(
                color: brandColor.withValues(alpha: 0.35),
                width: 0.85,
              ),
            ),
            child: Icon(
              Icons.vpn_key_rounded,
              size: 12,
              color: brandColor,
            ),
          ),
          Flexible(
            child: Text(
              (_currentSession.savedUsername?.isNotEmpty == true)
                  ? _currentSession.savedUsername!
                  : 'Saved Login',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.22,
                color: panelText,
                decoration: TextDecoration.none,
              ),
            ),
          ),
          const SizedBox(width: 6),
          GestureDetector(
            onTap: () async {
              HapticFeedback.lightImpact();
              await _autofillSavedLogin();
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: brandColor.withValues(alpha: 0.16),
                borderRadius: BorderRadius.circular(999),
                border: Border.all(
                  color: brandColor.withValues(alpha: 0.42),
                  width: 0.85,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.flash_on_rounded, size: 10, color: brandColor),
                  const SizedBox(width: 3),
                  Text(
                    'AUTOFILL',
                    style: TextStyle(
                      fontSize: 9.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.4,
                      color: brandColor,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () => _showPortalControlsSheet(
              context: context,
              isDark: isDark,
              panelText: panelText,
              panelMuted: panelMuted,
              accent: accent,
            ),
            child: Icon(
              Icons.tune_rounded,
              size: 16,
              color: panelText.withValues(alpha: 0.75),
            ),
          ),
        ],
      );
    }

    // 3. Login Page without Saved Credentials -> Suggest Filling Student ID
    if (_hasLoginForm && !_hasSavedLogin) {
      final brandColor = ThemeSignals.isMaterialYou
          ? Theme.of(context).colorScheme.primary
          : IrisTokens.brand;
      return Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            margin: const EdgeInsets.only(right: 6),
            width: 22,
            height: 22,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: brandColor.withValues(alpha: 0.12),
              border: Border.all(
                color: brandColor.withValues(alpha: 0.30),
                width: 0.85,
              ),
            ),
            child: Icon(
              Icons.badge_rounded,
              size: 12,
              color: brandColor,
            ),
          ),
          Flexible(
            child: Text(
              'Student Portal',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.22,
                color: panelText,
                decoration: TextDecoration.none,
              ),
            ),
          ),
          const SizedBox(width: 6),
          GestureDetector(
            onTap: () async {
              HapticFeedback.lightImpact();
              await _autofillSuggestedRegistration();
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
              decoration: BoxDecoration(
                color: brandColor.withValues(alpha: 0.14),
                borderRadius: BorderRadius.circular(999),
                border: Border.all(
                  color: brandColor.withValues(alpha: 0.35),
                  width: 0.85,
                ),
              ),
              child: Text(
                'FILL ID',
                style: TextStyle(
                  fontSize: 9.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.4,
                  color: brandColor,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () => _showPortalControlsSheet(
              context: context,
              isDark: isDark,
              panelText: panelText,
              panelMuted: panelMuted,
              accent: accent,
            ),
            child: Icon(
              Icons.tune_rounded,
              size: 16,
              color: panelText.withValues(alpha: 0.75),
            ),
          ),
        ],
      );
    }

    // 4. Default Idle Browsing State
    return Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildDynamicIslandLeftStatus(isDark, accent),
        const SizedBox(width: 6),
        Flexible(
          child: Text(
            idleTitle,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.22,
              color: panelText,
              decoration: TextDecoration.none,
            ),
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: () => _showPortalControlsSheet(
            context: context,
            isDark: isDark,
            panelText: panelText,
            panelMuted: panelMuted,
            accent: accent,
          ),
          child: Icon(
            Icons.tune_rounded,
            size: 16,
            color: panelText.withValues(alpha: 0.75),
          ),
        ),
      ],
    );
  }

  Widget _buildAddressBarCard({
    required bool isDark,
    required Color panelText,
    required Color panelMuted,
  }) {
    return PortalAddressBarCard(
      isDark: isDark,
      panelText: panelText,
      panelMuted: panelMuted,
      addressLabelSafe: addressLabelSafe,
      isOffline: _isOffline,
      isEditingAddress: _isEditingAddress,
      addressController: _addressController,
      onOpenAddressBar: _openAddressBar,
      onSubmitAddressBar: _submitAddressBar,
    );
  }

  void _showPortalControlsSheet({
    required BuildContext context,
    required bool isDark,
    required Color panelText,
    required Color panelMuted,
    required Color accent,
  }) {
    _stopLoginFocusWatch();
    IrisModalSheet.show(
      context: context,
      initialState: lgw.GlassSheetState.half,
      settings: IrisGlass.widgetsSettings(
        context,
        blur: 16.0,
        thickness: 16.0,
        ambientStrength: isDark ? 0.65 : 0.72,
        lightAngle: 1.5,
        glassColor: isDark
            ? const Color(0xFF0B1326).withValues(alpha: 0.82)
            : Colors.white.withValues(alpha: 0.88),
      ),
      builder: (sheetContext) => Material(
        color: Colors.transparent,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Center(
                  child: Container(
                    width: 38,
                    height: 4.5,
                    margin: const EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      color: (isDark ? Colors.white : Colors.black)
                          .withValues(alpha: 0.22),
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                ),
                _buildAddressBarCard(
                  isDark: isDark,
                  panelText: panelText,
                  panelMuted: panelMuted,
                ),
                const SizedBox(height: 12),
                _buildBentoLayout(
                  isDark: isDark,
                  panelText: panelText,
                  panelMuted: panelMuted,
                  accent: accent,
                ),
              ],
            ),
          ),
        ),
      ),
    ).then((_) {
      if (mounted) {
        _startLoginFocusWatch();
      }
    });
  }

  Widget _buildBentoLayout({
    required bool isDark,
    required Color panelText,
    required Color panelMuted,
    required Color accent,
  }) {
    return PortalBentoLayout(
      isDark: isDark,
      panelText: panelText,
      panelMuted: panelMuted,
      accent: accent,
      canGoBack: _canGoBack,
      canGoForward: _canGoForward,
      onGoBack: () async {
        await _controller.goBack();
        await _updateNavState();
      },
      onGoForward: () async {
        await _controller.goForward();
        await _updateNavState();
      },
      onRefresh: () async {
        await _refreshPage();
        await _updateNavState();
      },
      onOpenExternal: () async {
        final uri = Uri.tryParse(addressLabelSafe);
        if (uri != null) {
          await launchUrl(uri, mode: LaunchMode.externalApplication);
        }
      },
      showBackButton: widget.showBackButton,
      onExitPortal: () => Navigator.pop(context),
      downloadsCount: _currentSession.recentDownloads.length,
      hasFileUpload: _hasFileUpload,
      onTriggerUpload: _triggerUploadPicker,
      onOpenDownloads: _showDownloadManager,
      hasSavedLogin: _hasSavedLogin,
      hasLoginForm: _hasLoginForm,
      onAutofill: _autofillSavedLogin,
      onPrintDocument: () => _handlePrintDocument(addressLabelSafe),
      onClearLogin: _showClearLoginConfirm,
      onClearSession: _showClearSessionConfirm,
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final media = MediaQuery.of(context);
    final screenSize = media.size;
    final safeBottom = media.padding.bottom;
    final isTablet = screenSize.shortestSide >= 600;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = IrisTokens.brand;
    final edgeInset = isTablet ? 18.0 : 10.0;
    final headerInset = isTablet ? 18.0 : 14.0;
    final maxHeaderWidth = math.min(
      screenSize.width - (headerInset * 2),
      isTablet ? 720.0 : 620.0,
    );
    const idleTitle = 'COMSATS PORTAL';
    final bottomRailBottom = 6.0 + (safeBottom * 0.18);
    final enclosureBottomInset = (isTablet ? 18.0 : 14.0) +
        (widget.showBackButton ? 0.0 : 84.0) +
        safeBottom;
    final headerToggleLabel = _isHeaderCollapsed
        ? 'Expand header controls'
        : 'Collapse header controls';
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorialAcademic;
    final isMaterialYou = ThemeSignals.isMaterialYou;
    final isNotebook = ThemeSignals.isNotebook;
    final isLine = ThemeSignals.isLine;
    final isPoster = ThemeSignals.isPoster;

    final enclosureRadius = (isAlmanac || isPoster)
        ? BorderRadius.zero
        : (isLine
            ? BorderRadius.circular(14)
            : (isNotebook
                ? BorderRadius.circular(16)
                : (isEditorial
                    ? BorderRadius.circular(18)
                    : (isMaterialYou
                        ? BorderRadius.circular(16)
                        : BorderRadius.circular(isTablet ? 24 : 20)))));

    final enclosureStroke = isPoster
        ? PosterTokens.inkBorder(isDark)
        : (isLine
            ? LineTokens.railLine(isDark)
            : (isNotebook
                ? (isDark ? const Color(0xFF2F453B) : const Color(0xFFBDC7BC))
                : (isAlmanac
                    ? AlmanacTokens.inkRule(isDark)
                    : (isEditorial
                        ? EditorialTokens.cardBorder(isDark)
                        : (isMaterialYou
                            ? Theme.of(context).colorScheme.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55)
                            : (isDark ? Colors.white : Colors.black).withValues(alpha: isDark ? 0.16 : 0.08))))));

    final enclosureStrokeWidth = isPoster
        ? 2.2
        : (isLine
            ? 2.0
            : (isNotebook
                ? 1.5
                : (isAlmanac ? 1.5 : (isEditorial ? 1.2 : (isMaterialYou ? 1.0 : 1.25)))));

    final panelBackground = isPoster
        ? PosterTokens.cardSurface(isDark)
        : (isLine
            ? LineTokens.cardSurface(isDark)
            : (isNotebook
                ? NotebookTokens.cardSurface(isDark)
                : (isAlmanac
                    ? AlmanacTokens.canvas(isDark)
                    : (isEditorial
                        ? EditorialTokens.cardSurface(isDark)
                        : (isMaterialYou
                            ? Theme.of(context).colorScheme.surfaceContainerLow
                            : (isDark ? const Color(0xFF151D2C) : Colors.white))))));

    final enclosureShadow = isPoster
        ? PosterTokens.extrudedBlockShadow(isDark, offset: 4.0)
        : (isLine
            ? [
                BoxShadow(
                  color: LineTokens.railLine(isDark).withValues(alpha: 0.16),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ]
            : (isNotebook
                ? [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: isDark ? 0.30 : 0.08),
                      blurRadius: 10,
                      offset: const Offset(0, 3),
                    ),
                  ]
                : (isAlmanac
                    ? <BoxShadow>[]
                    : (isEditorial
                        ? EditorialTokens.cardShadow(isDark, elevation: 4.0)
                        : (isMaterialYou
                            ? [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.06),
                                  blurRadius: 12,
                                  offset: const Offset(0, 4),
                                ),
                              ]
                            : [
                                BoxShadow(
                                  color: Colors.black.withValues(
                                    alpha: isDark ? 0.25 : 0.08,
                                  ),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ])))));

    final panelText = isDark ? Colors.white : const Color(0xFF1E293B);
    final panelMuted = panelText.withValues(alpha: isDark ? 0.78 : 0.72);
    final innerStroke = (isDark ? Colors.white : accent).withValues(
      alpha: isDark ? 0.07 : 0.04,
    );
    final topEdgeHighlight = (isDark ? Colors.white : accent).withValues(
      alpha: isDark ? 0.06 : 0.04,
    );

    // Note: WebView background is updated in didChangeDependencies to avoid surface invalidation during animations

    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.transparent,
      body: Stack(
        fit: StackFit.expand,
        children: [
          ObsidianPulse(isDark: isDark),
          SafeArea(
            child: Stack(
              children: [
                  Positioned.fill(
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(
                        edgeInset,
                        50.0,
                        edgeInset,
                        enclosureBottomInset,
                      ),
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          ClipRRect(
                            borderRadius: enclosureRadius,
                            child: Container(
                              decoration: BoxDecoration(
                                color: panelBackground,
                                borderRadius: enclosureRadius,
                                border: Border.all(
                                  color: enclosureStroke,
                                  width: enclosureStrokeWidth,
                                ),
                                boxShadow: enclosureShadow,
                              ),
                              child: Stack(
                                children: [
                                  Positioned(
                                    top: (isAlmanac || isEditorial || isNotebook || isLine || isPoster) ? 36.0 : 0.0,
                                    left: 0,
                                    right: 0,
                                    bottom: 0,
                                    child: RepaintBoundary(
                                      child: WebViewWidget(
                                        key: const ValueKey<String>('iris_portal_webview_surface'),
                                        controller: _controller,
                                      ),
                                    ),
                                  ),
                                  // Torn paper deckle outline for Material / Comic Scrapbook
                                  if (false && isMaterialYou) ...[
                                    Positioned.fill(
                                      child: IgnorePointer(
                                        child: CustomPaint(
                                          painter: _TornPaperDecklePainter(
                                            isDark: isDark,
                                            strokeColor: StickerTokens.inkOutline(isDark),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                  // Almanac Telegraph Header
                                  if (isAlmanac) ...[
                                    Positioned(
                                      top: 0,
                                      left: 0,
                                      right: 0,
                                      child: Container(
                                        height: 34,
                                        padding: const EdgeInsets.symmetric(horizontal: 14),
                                        decoration: BoxDecoration(
                                          color: AlmanacTokens.cardSurface(isDark),
                                          border: Border(
                                            bottom: BorderSide(
                                              color: AlmanacTokens.inkRule(isDark),
                                              width: 1.0,
                                            ),
                                          ),
                                        ),
                                        child: Row(
                                          children: [
                                            Text(
                                              'THE UNIVERSITY TELEGRAPH ARCHIVE',
                                              style: AlmanacTokens.monoHeader(
                                                isDark,
                                                fontSize: 9.5,
                                                fontWeight: FontWeight.w700,
                                                letterSpacing: 0.8,
                                              ),
                                            ),
                                            const Spacer(),
                                            Text(
                                              'PORTAL TERMINAL',
                                              style: AlmanacTokens.monoHeader(
                                                isDark,
                                                fontSize: 9,
                                                color: AlmanacTokens.accentTerracotta(isDark),
                                                fontWeight: FontWeight.w700,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                  // Editorial Academic Folio Header
                                  if (isEditorial) ...[
                                    Positioned(
                                      top: 0,
                                      left: 0,
                                      right: 0,
                                      child: Container(
                                        height: 36,
                                        padding: const EdgeInsets.symmetric(horizontal: 14),
                                        decoration: BoxDecoration(
                                          color: EditorialTokens.cardSurface(isDark),
                                          border: Border(
                                            bottom: BorderSide(
                                              color: EditorialTokens.cardBorder(isDark),
                                              width: 1.0,
                                            ),
                                          ),
                                        ),
                                        child: Row(
                                          children: [
                                            const Icon(Icons.menu_book_rounded, size: 14, color: Color(0xFFEFA335)),
                                            const SizedBox(width: 8),
                                            Text(
                                              'OXFORD SCHOLARLY ARCHIVE · UNIVERSITY PORTAL',
                                              style: GoogleFonts.plusJakartaSans(
                                                fontSize: 9.5,
                                                fontWeight: FontWeight.w800,
                                                letterSpacing: 0.8,
                                                color: isDark ? const Color(0xFFCBD5E1) : const Color(0xFF1E1B18),
                                              ),
                                            ),
                                            const Spacer(),
                                            Text(
                                              'FOLIO ENTRY',
                                              style: GoogleFonts.spaceMono(
                                                fontSize: 9,
                                                color: const Color(0xFFEFA335),
                                                fontWeight: FontWeight.w700,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                  // Notebook Stationery Header
                                  if (isNotebook) ...[
                                    Positioned(
                                      top: 0,
                                      left: 0,
                                      right: 0,
                                      child: Container(
                                        height: 36,
                                        padding: const EdgeInsets.symmetric(horizontal: 14),
                                        decoration: BoxDecoration(
                                          color: NotebookTokens.canvas(isDark),
                                          border: Border(
                                            bottom: BorderSide(
                                              color: isDark ? const Color(0xFF2F453B) : const Color(0xFFBDC7BC),
                                              width: 1.0,
                                            ),
                                          ),
                                        ),
                                        child: Row(
                                          children: [
                                            Icon(
                                              Icons.edit_note_rounded,
                                              size: 16,
                                              color: NotebookTokens.redDoodle(isDark),
                                            ),
                                            const SizedBox(width: 8),
                                            Text(
                                              'STATIONERY DESK · STUDENT PORTAL',
                                              style: GoogleFonts.spaceMono(
                                                fontSize: 9.5,
                                                fontWeight: FontWeight.w700,
                                                letterSpacing: 0.8,
                                                color: NotebookTokens.inkHeading(isDark),
                                              ),
                                            ),
                                            const Spacer(),
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                              decoration: BoxDecoration(
                                                color: NotebookTokens.stickyYellowLight,
                                                borderRadius: BorderRadius.circular(4),
                                              ),
                                              child: Text(
                                                'DESK NOTE',
                                                style: GoogleFonts.kalam(
                                                  fontSize: 9,
                                                  fontWeight: FontWeight.w700,
                                                  color: Colors.black87,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                  // Line Transit Header
                                  if (isLine) ...[
                                    Positioned(
                                      top: 0,
                                      left: 0,
                                      right: 0,
                                      child: Container(
                                        height: 36,
                                        padding: const EdgeInsets.symmetric(horizontal: 14),
                                        decoration: BoxDecoration(
                                          color: LineTokens.ledBlack,
                                          border: Border(
                                            bottom: BorderSide(
                                              color: LineTokens.railLine(isDark),
                                              width: 1.5,
                                            ),
                                          ),
                                        ),
                                        child: Row(
                                          children: [
                                            Icon(
                                              Icons.subway_rounded,
                                              size: 15,
                                              color: LineTokens.ledAmber,
                                            ),
                                            const SizedBox(width: 8),
                                            Text(
                                              'TRANSIT INTERCHANGE · PORTAL TERMINUS',
                                              style: GoogleFonts.spaceMono(
                                                fontSize: 9.5,
                                                fontWeight: FontWeight.w700,
                                                letterSpacing: 0.8,
                                                color: LineTokens.ledAmber,
                                              ),
                                            ),
                                            const Spacer(),
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                              decoration: BoxDecoration(
                                                color: LineTokens.subwayYellow,
                                                borderRadius: BorderRadius.circular(4),
                                              ),
                                              child: Text(
                                                'TRACK 01',
                                                style: GoogleFonts.archivoBlack(
                                                  fontSize: 8.5,
                                                  fontWeight: FontWeight.w900,
                                                  color: LineTokens.ledBlack,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                  // Poster Swiss Monolith Header
                                  if (isPoster) ...[
                                    Positioned(
                                      top: 0,
                                      left: 0,
                                      right: 0,
                                      child: Container(
                                        height: 36,
                                        padding: const EdgeInsets.symmetric(horizontal: 14),
                                        decoration: BoxDecoration(
                                          color: PosterTokens.cardSurface(isDark),
                                          border: Border(
                                            bottom: BorderSide(
                                              color: PosterTokens.inkBorder(isDark),
                                              width: 2.0,
                                            ),
                                          ),
                                        ),
                                        child: Row(
                                          children: [
                                            const Icon(
                                              Icons.view_quilt_rounded,
                                              size: 16,
                                              color: PosterTokens.orangeHero,
                                            ),
                                            const SizedBox(width: 8),
                                            Text(
                                              'SWISS ARCHITECTURAL PORTAL // 01',
                                              style: GoogleFonts.archivoBlack(
                                                fontSize: 9.5,
                                                fontWeight: FontWeight.w900,
                                                letterSpacing: -0.2,
                                                color: PosterTokens.inkHeading(isDark),
                                              ),
                                            ),
                                            const Spacer(),
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                              decoration: const BoxDecoration(
                                                color: PosterTokens.orangeHero,
                                                borderRadius: BorderRadius.zero,
                                              ),
                                              child: Text(
                                                'SWISS 01',
                                                style: GoogleFonts.archivoBlack(
                                                  fontSize: 8.5,
                                                  fontWeight: FontWeight.w900,
                                                  color: Colors.black,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                  Positioned(
                                    top: (isAlmanac || isEditorial || isNotebook || isLine || isPoster) ? 36.0 : 0.0,
                                    left: 0,
                                    right: 0,
                                    child: ValueListenableBuilder<int>(
                                      valueListenable: _loadProgressNotifier,
                                      builder: (context, progress, _) {
                                        if (!_isLoading || progress >= 100) {
                                          return const SizedBox.shrink();
                                        }
                                        return SizedBox(
                                          height: 2.5,
                                          child: LinearProgressIndicator(
                                            value: progress > 0
                                                ? progress / 100.0
                                                : null,
                                            backgroundColor: Colors.transparent,
                                            color: isAlmanac
                                                ? AlmanacTokens.accentTerracotta(isDark)
                                                : (isEditorial
                                                    ? const Color(0xFFEFA335)
                                                    : (isMaterialYou
                                                        ? (isDark
                                                              ? const Color(0xFF9ECAFF)
                                                              : IrisTokens.brand)
                                                        : accent)),
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          // Spatial 3D Overlays:
                          // 1. Material / Comic Scrapbook: 4 Corner Washi Tape Strips
                          if (false && isMaterialYou) ...[
                            Positioned(
                              top: -8,
                              left: -12,
                              child: _WashiTapeStrip(
                                angle: -0.55,
                                width: 55,
                                height: 22,
                                color: const Color(0xFFFEF08A).withValues(alpha: 0.90),
                              ),
                            ),
                            Positioned(
                              top: -8,
                              right: -12,
                              child: _WashiTapeStrip(
                                angle: 0.48,
                                width: 55,
                                height: 22,
                                color: const Color(0xFFFECDD3).withValues(alpha: 0.90),
                              ),
                            ),
                            Positioned(
                              bottom: -8,
                              left: -12,
                              child: _WashiTapeStrip(
                                angle: 0.42,
                                width: 55,
                                height: 22,
                                color: const Color(0xFFA7F3D0).withValues(alpha: 0.90),
                              ),
                            ),
                            Positioned(
                              bottom: -8,
                              right: -12,
                              child: _WashiTapeStrip(
                                angle: -0.50,
                                width: 55,
                                height: 22,
                                color: const Color(0xFFBFDBFE).withValues(alpha: 0.90),
                              ),
                            ),
                          ],
                          // 2. Editorial Academic: 4 Ornate 3D Brass Corner Brackets + Satin Bookmark
                          if (isEditorial) ...[
                            const Positioned(top: -2, left: -2, child: _AntiquarianBrassCorner(isTop: true, isLeft: true)),
                            const Positioned(top: -2, right: -2, child: _AntiquarianBrassCorner(isTop: true, isLeft: false)),
                            const Positioned(bottom: -2, left: -2, child: _AntiquarianBrassCorner(isTop: false, isLeft: true)),
                            const Positioned(bottom: -2, right: -2, child: _AntiquarianBrassCorner(isTop: false, isLeft: false)),
                            Positioned(
                              top: -12,
                              right: 32,
                              child: _SatinRibbonBookmark(isDark: isDark),
                            ),
                          ],
                          // 3. Almanac: Heavy 3D Industrial Binder Clamp holding broadsheet
                          if (isAlmanac) ...[
                            Positioned(
                              top: -14,
                              left: 0,
                              right: 0,
                              child: Center(child: _BroadsheetBinderClamp(isDark: isDark)),
                            ),
                          ],
                          Positioned.fill(
                                child: IgnorePointer(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: enclosureRadius,
                                      border: Border.all(
                                        color: innerStroke,
                                        width: 0.85,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 0,
                                right: 0,
                                top: 0,
                                child: IgnorePointer(
                                  child: Container(
                                    height: 26,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(
                                          isTablet ? 24 : 20,
                                        ),
                                        topRight: Radius.circular(
                                          isTablet ? 24 : 20,
                                        ),
                                      ),
                                      gradient: LinearGradient(
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                        colors: [
                                          topEdgeHighlight,
                                          Colors.transparent,
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: edgeInset,
                                right: edgeInset,
                                bottom: bottomRailBottom,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [const SizedBox.shrink()],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                  Positioned(
                    left: edgeInset,
                    right: edgeInset,
                    top: 8,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        if (widget.showBackButton) ...[
                          ExpressiveInteractivePress(
                            pressedScale: 0.92,
                            onTap: () {
                              HapticFeedback.lightImpact();
                              Navigator.of(context).maybePop();
                            },
                            child: Container(
                              width: 38,
                              height: 38,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: ThemeSignals.isMaterialYou
                                    ? Theme.of(context).colorScheme.surfaceContainerHigh
                                    : (isDark
                                            ? IrisTokens.surfaceDarkElevated
                                            : Colors.white)
                                        .withValues(alpha: isDark ? 0.75 : 0.88),
                                border: Border.all(
                                  color: ThemeSignals.isMaterialYou
                                      ? Theme.of(context).colorScheme.outlineVariant.withValues(alpha: 0.6)
                                      : (isDark ? Colors.white : Colors.black).withValues(alpha: 0.12),
                                  width: 1.2,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.08),
                                    blurRadius: 10,
                                    offset: const Offset(0, 3),
                                  ),
                                ],
                              ),
                              child: Icon(Icons.arrow_back_rounded, size: 18, color: panelText),
                            ),
                          ),
                          const SizedBox(width: 8),
                        ],
                        Flexible(
                          child: Center(
                            child: ExpressiveInteractivePress(
                              pressedScale: 0.96,
                              onTap: () {
                                _showPortalControlsSheet(
                                  context: context,
                                  isDark: isDark,
                                  panelText: panelText,
                                  panelMuted: panelMuted,
                                  accent: accent,
                                );
                              },
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 280),
                                curve: Curves.easeOutCubic,
                                constraints: BoxConstraints(
                                  minWidth: 150,
                                  maxWidth: maxHeaderWidth - (widget.showBackButton ? 92 : 0),
                                  minHeight: 38,
                                  maxHeight: 42,
                                ),
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                decoration: BoxDecoration(
                                  color: ThemeSignals.isMaterialYou
                                      ? Theme.of(context).colorScheme.surfaceContainerHigh
                                      : (isDark
                                              ? IrisTokens.surfaceDarkElevated
                                              : Colors.white)
                                          .withValues(alpha: isDark ? 0.75 : 0.88),
                                  borderRadius: BorderRadius.circular(999),
                                  border: Border.all(
                                    color: ThemeSignals.isMaterialYou
                                        ? (_pillActive
                                            ? _pillTone.withValues(alpha: 0.5)
                                            : (_hasLoginForm && _hasSavedLogin
                                                ? Theme.of(context).colorScheme.primary.withValues(alpha: 0.5)
                                                : Theme.of(context).colorScheme.outlineVariant.withValues(alpha: 0.6)))
                                        : (_pillActive
                                            ? _pillTone
                                            : (_isOffline
                                                ? const Color(0xFFEF4444)
                                                : (_hasLoginForm && _hasSavedLogin
                                                    ? IrisTokens.success
                                                    : accent)))
                                            .withValues(alpha: 0.25),
                                    width: 1.3,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.08),
                                      blurRadius: 12,
                                      offset: const Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: _buildDynamicIslandContent(
                                  context: context,
                                  isDark: isDark,
                                  panelText: panelText,
                                  panelMuted: panelMuted,
                                  accent: accent,
                                  idleTitle: idleTitle,
                                ),
                              ),
                            ),
                          ),
                        ),
                        if (widget.showBackButton) const SizedBox(width: 46),
                      ],
                    ),
                  ),
                  Positioned.fill(
                    child: IgnorePointer(
                      child: Align(
                        alignment: Alignment.topCenter,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Semantics(
                            label: headerToggleLabel,
                            child: const SizedBox(width: 0, height: 0),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }
}

// ============================================================================
// SPATIAL & 3D HARDWARE DECORATORS FOR PORTAL SCREEN
// ============================================================================

/// Translucent Washi Tape Strip with paper serration and cast shadow
class _WashiTapeStrip extends StatelessWidget {
  final double angle;
  final double width;
  final double height;
  final Color color;

  const _WashiTapeStrip({
    required this.angle,
    required this.width,
    required this.height,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: angle,
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(2),
          border: Border.all(color: Colors.black.withValues(alpha: 0.12), width: 0.8),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.16),
              offset: const Offset(1, 2),
              blurRadius: 3,
            ),
          ],
        ),
      ),
    );
  }
}

/// Jagged Torn Paper Deckle Edge Painter for the WebView perimeter in Comic mode
class _TornPaperDecklePainter extends CustomPainter {
  final bool isDark;
  final Color strokeColor;

  const _TornPaperDecklePainter({
    required this.isDark,
    required this.strokeColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = strokeColor.withValues(alpha: isDark ? 0.40 : 0.25)
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke;

    final path = Path();
    const double step = 8.0;
    final random = math.Random(1337);

    // Top edge jagged
    path.moveTo(0, 0);
    for (double x = 0; x < size.width; x += step) {
      final dy = (random.nextDouble() - 0.5) * 3.5;
      path.lineTo(x, dy);
    }
    // Right edge jagged
    for (double y = 0; y < size.height; y += step) {
      final dx = size.width + (random.nextDouble() - 0.5) * 3.5;
      path.lineTo(dx, y);
    }
    // Bottom edge jagged
    for (double x = size.width; x > 0; x -= step) {
      final dy = size.height + (random.nextDouble() - 0.5) * 3.5;
      path.lineTo(x, dy);
    }
    // Left edge jagged
    for (double y = size.height; y > 0; y -= step) {
      final dx = (random.nextDouble() - 0.5) * 3.5;
      path.lineTo(dx, y);
    }
    path.close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldPainter) => false;
}

/// Ornate 3D Antiquarian Brass Corner Protector with metallic gradient & rivets
class _AntiquarianBrassCorner extends StatelessWidget {
  final bool isTop;
  final bool isLeft;

  const _AntiquarianBrassCorner({
    required this.isTop,
    required this.isLeft,
  });

  @override
  Widget build(BuildContext context) {
    return Transform.scale(
      scaleX: isLeft ? 1 : -1,
      scaleY: isTop ? 1 : -1,
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFFFFE082),
              Color(0xFFD97706),
              Color(0xFF92400E),
              Color(0xFFFDE68A),
            ],
          ),
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(6),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.35),
              offset: const Offset(1, 2),
              blurRadius: 3,
            ),
          ],
        ),
        child: Align(
          alignment: Alignment.topLeft,
          child: Container(
            margin: const EdgeInsets.all(5),
            width: 4.5,
            height: 4.5,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Color(0xFF78350F),
            ),
          ),
        ),
      ),
    );
  }
}

/// 3D Satin Ribbon Bookmark with swallowtail cutout dangling from the top edge
class _SatinRibbonBookmark extends StatelessWidget {
  final bool isDark;

  const _SatinRibbonBookmark({required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 24,
      height: 52,
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.30),
            offset: const Offset(2, 4),
            blurRadius: 6,
          ),
        ],
      ),
      child: CustomPaint(
        painter: _SwallowtailRibbonPainter(),
      ),
    );
  }
}

class _SwallowtailRibbonPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final ribbonPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [
          Color(0xFFB91C1C),
          Color(0xFFDC2626),
          Color(0xFF991B1B),
        ],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width, size.height)
      ..lineTo(size.width / 2, size.height - 10)
      ..lineTo(0, size.height)
      ..close();

    canvas.drawPath(path, ribbonPaint);

    // Golden trim thread along the left edge
    final threadPaint = Paint()
      ..color = const Color(0xFFFDE68A).withValues(alpha: 0.70)
      ..strokeWidth = 1.0;
    canvas.drawLine(const Offset(2.5, 0), Offset(2.5, size.height - 3), threadPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldPainter) => false;
}

/// 3D Industrial Binder Clamp holding broadsheet
class _BroadsheetBinderClamp extends StatelessWidget {
  final bool isDark;

  const _BroadsheetBinderClamp({required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 72,
      height: 22,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: isDark
              ? [const Color(0xFF4B5563), const Color(0xFF1F2937), const Color(0xFF111827)]
              : [const Color(0xFFE2E8F0), const Color(0xFF94A3B8), const Color(0xFF64748B)],
        ),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: Colors.black.withValues(alpha: 0.35), width: 1.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.35),
            offset: const Offset(0, 3),
            blurRadius: 6,
          ),
        ],
      ),
      child: Center(
        child: Container(
          width: 44,
          height: 3,
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF9CA3AF) : Colors.white,
            borderRadius: BorderRadius.circular(1.5),
          ),
        ),
      ),
    );
  }
}
