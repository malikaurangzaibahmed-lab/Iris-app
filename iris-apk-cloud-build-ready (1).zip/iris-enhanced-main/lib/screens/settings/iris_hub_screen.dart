import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/tokens.dart';
import '../../core/models.dart';
import '../../core/app_signals.dart';
import '../../core/omni_brain.dart';
import '../../services/ui_feedback.dart';
import '../../widgets/glass_card.dart';
import '../../core/vital_theme.dart';
import '../../core/animations.dart';
import '../../widgets/effects/glass_container_transform.dart';
import '../../core/theme_signals.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import 'package:iris/widgets/navigation/liquid_glass_sticky_header.dart';
import 'package:iris/screens/settings/profile_settings_screen.dart';
import 'package:iris/screens/settings/appearance_settings_screen.dart';
import 'package:iris/screens/settings/notifications_settings_screen.dart';
import 'package:iris/screens/settings/data_storage_settings_screen.dart';
import 'package:iris/screens/settings/about_iris_screen.dart';
import 'package:iris/screens/settings/feedback_screen.dart';
import 'package:iris/screens/settings/legal_screens.dart';

/// Commercial-grade Phone-like Settings Hub for IRIS.
/// Inspired by Google Pixel Android 15 & iOS modern settings layouts:
/// - Real-time unified settings search
/// - Executive Apple/Google-style Account Profile Banner
/// - Modular grouped inset setting sections routing to dedicated, redesigned sub-screens
/// - Fully responsive across all 7 IRIS design themes
class IrisHubScreen extends StatefulWidget {
  final UniversityMemory memory;
  final ValueChanged<String>? onUserNameChanged;
  final ValueChanged<String>? onRoleChanged;
  final ValueChanged<String>? onBatchChanged;
  final ScrollController? scrollController;
  final VoidCallback? onToggleTheme;
  final String? currentThemeMode;
  final Future<void> Function(String)? onSetThemeMode;
  final VoidCallback? onBackPressed;

  const IrisHubScreen({
    super.key,
    required this.memory,
    this.onUserNameChanged,
    this.onRoleChanged,
    this.onBatchChanged,
    this.scrollController,
    this.onToggleTheme,
    this.currentThemeMode,
    this.onSetThemeMode,
    this.onBackPressed,
  });

  @override
  State<IrisHubScreen> createState() => _IrisHubScreenState();
}

class _IrisHubScreenState extends State<IrisHubScreen> {
  late final ScrollController _scrollController;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  String _userName = 'Student';
  String _batch = '...';
  String _userRole = 'student';

  @override
  void initState() {
    super.initState();
    _scrollController = widget.scrollController ?? ScrollController();
    _loadSettings();
    AppSignals.stateRevision.addListener(_onAppSignalsUpdated);
  }

  void _onAppSignalsUpdated() {
    if (!mounted) return;
    setState(() {
      if (AppSignals.activeRole.value.isNotEmpty) {
        _userRole = AppSignals.activeRole.value;
      }
      if (AppSignals.activeBatch.value.isNotEmpty) {
        _batch = AppSignals.activeBatch.value;
      }
      if (AppSignals.activeUserName.value.isNotEmpty) {
        _userName = AppSignals.activeUserName.value;
      }
    });
  }

  @override
  void dispose() {
    AppSignals.stateRevision.removeListener(_onAppSignalsUpdated);
    _searchController.dispose();
    if (widget.scrollController == null) {
      _scrollController.dispose();
    }
    super.dispose();
  }

  Future<void> _quickSwitchRole(String targetRole) async {
    if (_userRole == targetRole) return;
    IrisHaptics.actionHeavy();
    final brain = OmniBrain(widget.memory);
    String resolvedName = _userName;
    if (targetRole == 'faculty') {
      final prefs = await SharedPreferences.getInstance();
      final teachers = brain.allTeachers();
      final savedTeacher = prefs.getString('faculty_user_name') ?? prefs.getString('faculty_teacher');
      if (savedTeacher != null &&
          savedTeacher.isNotEmpty &&
          savedTeacher != 'Faculty Member' &&
          savedTeacher != 'Student' &&
          (teachers.isEmpty || teachers.contains(savedTeacher))) {
        resolvedName = savedTeacher;
      } else {
        resolvedName = teachers.isNotEmpty ? teachers.first : 'Faculty Member';
      }
    } else {
      final prefs = await SharedPreferences.getInstance();
      final savedStudent = prefs.getString('student_user_name') ?? prefs.getString('student_name');
      resolvedName = (savedStudent != null && savedStudent.isNotEmpty) ? savedStudent : 'Student';
      if ((_batch.isEmpty || _batch == 'UNKNOWN' || _batch == '...') && widget.memory.allBatches.isNotEmpty) {
        final firstBatch = widget.memory.allBatches.first;
        await AppSignals.setBatch(firstBatch);
        widget.onBatchChanged?.call(firstBatch);
      }
    }
    await AppSignals.setRole(targetRole, userName: resolvedName);
    widget.onRoleChanged?.call(targetRole);
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    var rawBatch = prefs.getString('user_batch') ?? 'UNKNOWN';
    if (rawBatch.contains('{') ||
        rawBatch.contains('\n') ||
        rawBatch.contains('courses') ||
        rawBatch.contains('CIIT/') ||
        rawBatch.length > 25) {
      rawBatch = prefs.getString('promoted_from_batch') ??
          (widget.memory.allBatches.isNotEmpty
              ? widget.memory.allBatches.first
              : 'Active Batch');
      if (rawBatch.isNotEmpty) {
        await prefs.setString('user_batch', rawBatch);
        await prefs.setString('student_batch', rawBatch);
      }
    }

    setState(() {
      _userRole = prefs.getString('user_role') ?? 'student';
      if (_userRole == 'faculty') {
        _userName = prefs.getString('faculty_user_name') ?? 'Faculty Member';
      } else {
        _userName =
            prefs.getString('student_user_name')?.trim().isNotEmpty == true
                ? prefs.getString('student_user_name')!.trim()
                : 'Student';
      }
      _batch = rawBatch;
    });
  }

  void _navigateToProfile() async {
    IrisHaptics.actionMedium();
    await pushGlassContainerMorphRoute(
      context,
      page: ProfileSettingsScreen(
          memory: widget.memory,
          userName: _userName,
          userRole: _userRole,
          batch: _batch,
          onUserNameChanged: (newName) {
            setState(() => _userName = newName);
            widget.onUserNameChanged?.call(newName);
          },
          onRoleChanged: (newRole) {
            setState(() => _userRole = newRole);
            widget.onRoleChanged?.call(newRole);
          },
          onBatchChanged: (newBatch) {
            setState(() => _batch = newBatch);
            widget.onBatchChanged?.call(newBatch);
          },
        ),
    );
    _loadSettings();
  }

  void _navigateToAppearance() {
    IrisHaptics.actionMedium();
    pushGlassContainerMorphRoute(
      context,
      page: AppearanceSettingsScreen(
        currentThemeMode: widget.currentThemeMode,
        onSetThemeMode: widget.onSetThemeMode,
      ),
    );
  }

  void _navigateToNotifications() {
    IrisHaptics.actionMedium();
    pushGlassContainerMorphRoute(
      context,
      page: const NotificationsSettingsScreen(),
    );
  }

  void _navigateToDataStorage() {
    IrisHaptics.actionMedium();
    pushGlassContainerMorphRoute(
      context,
      page: DataStorageSettingsScreen(
        memory: widget.memory,
      ),
    );
  }

  void _navigateToFeedback() {
    IrisHaptics.actionMedium();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    pushGlassContainerMorphRoute(
      context,
      page: FeedbackScreen(isDark: isDark),
    );
  }

  void _navigateToAboutIris() {
    IrisHaptics.actionMedium();
    pushGlassContainerMorphRoute(
      context,
      page: const AboutIrisScreen(),
    );
  }

  void _navigateToPrivacy() {
    IrisHaptics.actionMedium();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    pushGlassContainerMorphRoute(
      context,
      page: PrivacyPolicyScreen(isDark: isDark),
    );
  }

  void _navigateToTerms() {
    IrisHaptics.actionMedium();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    pushGlassContainerMorphRoute(
      context,
      page: TermsOfServiceScreen(isDark: isDark),
    );
  }

  List<_SearchItem> _getSearchCatalog() {
    return [
      _SearchItem(
        title: 'Account & Academic Identity',
        subtitle: 'Display name, student/faculty role, active batch',
        category: 'Profile',
        icon: Icons.person_rounded,
        color: VitalTokens.blue,
        onTap: _navigateToProfile,
      ),
      _SearchItem(
        title: 'Appearance & Display Modes',
        subtitle: 'System default, crisp light mode, midnight dark mode',
        category: 'Display',
        icon: Icons.brightness_auto_rounded,
        color: const Color(0xFF6366F1),
        onTap: _navigateToAppearance,
      ),
      _SearchItem(
        title: 'Theme Engine & 7 Design Systems',
        subtitle: 'Material You, Liquid Glass, Almanac, Editorial, Notebook, Line, Poster',
        category: 'Display',
        icon: Icons.palette_rounded,
        color: const Color(0xFF8B5CF6),
        onTap: _navigateToAppearance,
      ),
      _SearchItem(
        title: 'Monet Dynamic Colors & Accent Tokens',
        subtitle: 'Google Pixel wallpaper extraction & custom tinting',
        category: 'Display',
        icon: Icons.color_lens_rounded,
        color: const Color(0xFFEC4899),
        onTap: _navigateToAppearance,
      ),
      _SearchItem(
        title: 'Notifications & Class Tracker',
        subtitle: 'Android persistent status bar lecture tracker',
        category: 'Notifications',
        icon: Icons.notifications_active_rounded,
        color: const Color(0xFFF59E0B),
        onTap: _navigateToNotifications,
      ),
      _SearchItem(
        title: 'Advance Lecture Alarms',
        subtitle: '5m, 10m, or 15m advance warning before scheduled lectures',
        category: 'Notifications',
        icon: Icons.alarm_rounded,
        color: const Color(0xFFF97316),
        onTap: _navigateToNotifications,
      ),
      _SearchItem(
        title: 'Weekend & Vacation Auto-Silencing',
        subtitle: 'Quiet hours during non-academic periods',
        category: 'Notifications',
        icon: Icons.do_not_disturb_on_rounded,
        color: const Color(0xFF10B981),
        onTap: _navigateToNotifications,
      ),
      _SearchItem(
        title: 'Haptic Feedback Physics',
        subtitle: 'Tactile spring response for toggles and navigation',
        category: 'Notifications',
        icon: Icons.vibration_rounded,
        color: const Color(0xFF06B6D4),
        onTap: _navigateToNotifications,
      ),
      _SearchItem(
        title: 'Data, Storage & Edge Sync',
        subtitle: 'Supabase cloud CDN edge synchronization',
        category: 'Storage',
        icon: Icons.cloud_sync_rounded,
        color: const Color(0xFF10B981),
        onTap: _navigateToDataStorage,
      ),
      _SearchItem(
        title: 'Clear Local Timetable Caches',
        subtitle: 'Purge stale timetable drafts and offline memory',
        category: 'Storage',
        icon: Icons.cleaning_services_rounded,
        color: const Color(0xFFEF4444),
        onTap: _navigateToDataStorage,
      ),
      _SearchItem(
        title: 'Portal Credentials & Session Memory',
        subtitle: 'Auto-fill accounts and stored CUOnline credentials',
        category: 'Storage',
        icon: Icons.key_rounded,
        color: const Color(0xFF8B5CF6),
        onTap: _navigateToDataStorage,
      ),
      _SearchItem(
        title: 'Send Feedback & Bug Reports',
        subtitle: 'Report issues directly to the development desk',
        category: 'Support',
        icon: Icons.rate_review_rounded,
        color: const Color(0xFF0284C7),
        onTap: _navigateToFeedback,
      ),
      _SearchItem(
        title: 'About IRIS & System Specifications',
        subtitle: 'Version 1.0.3+4, Shorebird OTA, architecture & hardware',
        category: 'About',
        icon: Icons.phone_android_rounded,
        color: const Color(0xFF8B5CF6),
        onTap: _navigateToAboutIris,
      ),
      _SearchItem(
        title: 'Developer Governance & Lead Architect',
        subtitle: 'Malik Aurangzaib Ahmed • Software engineering portfolio',
        category: 'About',
        icon: Icons.code_rounded,
        color: const Color(0xFF6366F1),
        onTap: _navigateToAboutIris,
      ),
      _SearchItem(
        title: 'Privacy Policy',
        subtitle: 'Local-first architecture and telemetry disclosure',
        category: 'Governance',
        icon: Icons.shield_outlined,
        color: const Color(0xFF64748B),
        onTap: _navigateToPrivacy,
      ),
      _SearchItem(
        title: 'Terms of Service',
        subtitle: 'Autonomous academic companion license and rules',
        category: 'Governance',
        icon: Icons.gavel_rounded,
        color: const Color(0xFF475569),
        onTap: _navigateToTerms,
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          ObsidianPulse(isDark: isDark),
          Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 840),
              child: CustomScrollView(
                controller: _scrollController,
                physics: const ButterScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics(),
                ),
                cacheExtent: 450.0,
                slivers: [
                  // 1. Sleek Sticky Collapsing Header
                  SliverPersistentHeader(
                    pinned: true,
                    delegate: IrisHubLiquidGlassStickyHeaderDelegate(
                      topPadding: MediaQuery.paddingOf(context).top,
                      userRole: _userRole,
                      isDark: isDark,
                      canPop: Navigator.of(context).canPop() || widget.onBackPressed != null,
                      onBack: () {
                        if (widget.onBackPressed != null) {
                          widget.onBackPressed!();
                        } else if (Navigator.canPop(context)) {
                          Navigator.pop(context);
                        }
                      },
                    ),
                  ),

                  // 2. Phone-style Search Bar
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
                      child: _buildSearchBar(context, isDark),
                    ),
                  ),

                  // 3. Search Results or Main Phone Settings Content
                  if (_searchQuery.trim().isNotEmpty)
                    _buildSearchResultsList(context, isDark)
                  else ...[
                    // Executive Apple/Pixel-style Account Banner
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                        child: _buildExecutiveProfileCard(context, isDark),
                      ),
                    ),

                    // Modular Grouped Inset Sections
                    SliverPadding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      sliver: SliverList(
                        delegate: SliverChildListDelegate([
                          _buildSectionLabel(context, 'Display & Preferences'),
                          const SizedBox(height: 10),
                          _buildDisplayGroup(context, isDark),
                          const SizedBox(height: 24),

                          _buildSectionLabel(context, 'Data & Cloud Sync'),
                          const SizedBox(height: 10),
                          _buildDataGroup(context, isDark),
                          const SizedBox(height: 24),

                          _buildSectionLabel(context, 'About & Governance'),
                          const SizedBox(height: 10),
                          _buildAboutGroup(context, isDark),
                          const SizedBox(height: 36),

                          _buildSystemFooter(context, isDark),
                          const SizedBox(height: 120),
                        ]),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Phone-Style In-Page Search Bar
  // ---------------------------------------------------------------------------
  Widget _buildSearchBar(BuildContext context, bool isDark) {
    final isM3 = ThemeSignals.isMaterialYou;
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorial;
    final isNotebook = ThemeSignals.isNotebook;
    final isLine = ThemeSignals.isLine;
    final isPoster = ThemeSignals.isPoster;
    final cs = Theme.of(context).colorScheme;

    if (isEditorial) {
      return Container(
        decoration: BoxDecoration(
          color: EditorialTokens.cardSurface(isDark),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: EditorialTokens.cardBorder(isDark), width: 1.2),
          boxShadow: EditorialTokens.cardShadow(isDark, elevation: 1),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(
          children: [
            Icon(Icons.search_rounded, size: 20, color: EditorialTokens.inkMuted(isDark)),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _searchController,
                onChanged: (val) => setState(() => _searchQuery = val),
                style: EditorialTokens.bodyStyle(isDark, fontSize: 13.5),
                decoration: InputDecoration(
                  hintText: 'Search preferences, topics...',
                  hintStyle: EditorialTokens.monoLabel(isDark, fontSize: 11),
                  border: InputBorder.none,
                ),
              ),
            ),
            if (_searchQuery.isNotEmpty)
              IconButton(
                icon: Icon(Icons.close_rounded, size: 18, color: EditorialTokens.inkHeading(isDark)),
                onPressed: () {
                  _searchController.clear();
                  setState(() => _searchQuery = '');
                },
              ),
          ],
        ),
      );
    }

    if (isAlmanac) {
      return Container(
        decoration: BoxDecoration(
          color: AlmanacTokens.cardSurface(isDark),
          border: Border.all(color: AlmanacTokens.inkRule(isDark), width: 1.2),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(
          children: [
            Icon(Icons.search_rounded, size: 20, color: AlmanacTokens.inkHeading(isDark)),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _searchController,
                onChanged: (val) => setState(() => _searchQuery = val),
                style: AlmanacTokens.monoHeader(isDark, fontSize: 13),
                decoration: InputDecoration(
                  hintText: 'SEARCH SYSTEM SETTINGS...',
                  hintStyle: AlmanacTokens.monoHeader(isDark, fontSize: 11, color: isDark ? Colors.white38 : Colors.black38),
                  border: InputBorder.none,
                ),
              ),
            ),
            if (_searchQuery.isNotEmpty)
              IconButton(
                icon: Icon(Icons.close_rounded, size: 18, color: AlmanacTokens.inkHeading(isDark)),
                onPressed: () {
                  _searchController.clear();
                  setState(() => _searchQuery = '');
                },
              ),
          ],
        ),
      );
    }

    if (isPoster) {
      return Container(
        decoration: BoxDecoration(
          color: PosterTokens.cardSurface(isDark),
          border: Border.all(color: PosterTokens.inkBorder(isDark), width: 2.0),
          boxShadow: PosterTokens.extrudedBlockShadow(isDark, offset: 3),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(
          children: [
            Icon(Icons.search_rounded, size: 20, color: PosterTokens.inkHeading(isDark)),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _searchController,
                onChanged: (val) => setState(() => _searchQuery = val),
                style: PosterTokens.classTitle(isDark).copyWith(fontSize: 13),
                decoration: InputDecoration(
                  hintText: 'SEARCH SETTINGS',
                  hintStyle: TextStyle(fontSize: 11.5, color: isDark ? Colors.white38 : Colors.black38),
                  border: InputBorder.none,
                ),
              ),
            ),
            if (_searchQuery.isNotEmpty)
              IconButton(
                icon: Icon(Icons.close_rounded, size: 18, color: PosterTokens.inkHeading(isDark)),
                onPressed: () {
                  _searchController.clear();
                  setState(() => _searchQuery = '');
                },
              ),
          ],
        ),
      );
    }

    if (isLine) {
      return Container(
        decoration: BoxDecoration(
          color: LineTokens.cardSurface(isDark),
          border: Border.all(color: LineTokens.railLine(isDark), width: 1.5),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(
          children: [
            Icon(Icons.search_rounded, size: 20, color: LineTokens.railLine(isDark)),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _searchController,
                onChanged: (val) => setState(() => _searchQuery = val),
                style: LineTokens.stationMeta(isDark).copyWith(fontSize: 12.5),
                decoration: InputDecoration(
                  hintText: '[SEARCH_SETTINGS]',
                  hintStyle: LineTokens.stationMeta(isDark).copyWith(fontSize: 11, color: isDark ? Colors.white38 : Colors.black38),
                  border: InputBorder.none,
                ),
              ),
            ),
            if (_searchQuery.isNotEmpty)
              IconButton(
                icon: Icon(Icons.close_rounded, size: 18, color: LineTokens.railLine(isDark)),
                onPressed: () {
                  _searchController.clear();
                  setState(() => _searchQuery = '');
                },
              ),
          ],
        ),
      );
    }

    if (isNotebook) {
      return Container(
        decoration: BoxDecoration(
          color: NotebookTokens.cardSurface(isDark),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: NotebookTokens.gridLine(isDark), width: 1.2),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(
          children: [
            Icon(Icons.search_rounded, size: 20, color: NotebookTokens.inkMuted(isDark)),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _searchController,
                onChanged: (val) => setState(() => _searchQuery = val),
                style: NotebookTokens.handwrittenBody(isDark, fontSize: 14),
                decoration: InputDecoration(
                  hintText: 'Search preferences...',
                  hintStyle: NotebookTokens.handwrittenBody(isDark, fontSize: 12, color: isDark ? Colors.white38 : Colors.black38),
                  border: InputBorder.none,
                ),
              ),
            ),
            if (_searchQuery.isNotEmpty)
              IconButton(
                icon: Icon(Icons.close_rounded, size: 18, color: NotebookTokens.inkMuted(isDark)),
                onPressed: () {
                  _searchController.clear();
                  setState(() => _searchQuery = '');
                },
              ),
          ],
        ),
      );
    }

    return GlassCard(
      borderRadius: 22,
      elevation: isM3 ? 1 : 2,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
      child: Row(
        children: [
          Icon(
            Icons.search_rounded,
            size: 21,
            color: isM3 ? cs.primary : VitalTokens.blue,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: TextField(
              controller: _searchController,
              onChanged: (val) => setState(() => _searchQuery = val),
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
              ),
              decoration: InputDecoration(
                hintText: 'Search settings, themes, cache...',
                hintStyle: TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w500,
                  color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white38 : Colors.black38),
                ),
                border: InputBorder.none,
              ),
            ),
          ),
          if (_searchQuery.isNotEmpty)
            GestureDetector(
              onTap: () {
                _searchController.clear();
                setState(() => _searchQuery = '');
              },
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: isDark ? Colors.white12 : Colors.black12,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.close_rounded,
                  size: 16,
                  color: isDark ? Colors.white70 : Colors.black87,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Search Results List
  // ---------------------------------------------------------------------------
  Widget _buildSearchResultsList(BuildContext context, bool isDark) {
    final query = _searchQuery.toLowerCase().trim();
    final results = _getSearchCatalog().where((item) {
      return item.title.toLowerCase().contains(query) ||
          item.subtitle.toLowerCase().contains(query) ||
          item.category.toLowerCase().contains(query);
    }).toList();

    if (results.isEmpty) {
      return SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 48),
          child: Center(
            child: Column(
              children: [
                Icon(
                  Icons.search_off_rounded,
                  size: 48,
                  color: isDark ? Colors.white38 : Colors.black38,
                ),
                const SizedBox(height: 12),
                Text(
                  'No settings match "$_searchQuery"',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: isDark ? Colors.white70 : Colors.black87,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Try checking "themes", "notifications", or "cache"',
                  style: TextStyle(
                    fontSize: 12,
                    color: isDark ? Colors.white38 : Colors.black45,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      sliver: SliverList(
        delegate: SliverChildBuilderDelegate(
          (context, index) {
            final item = results[index];
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: GlassCard(
                borderRadius: 18,
                padding: EdgeInsets.zero,
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  leading: Container(
                    padding: const EdgeInsets.all(9),
                    decoration: BoxDecoration(
                      color: item.color.withValues(alpha: isDark ? 0.22 : 0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(item.icon, color: item.color, size: 20),
                  ),
                  title: Row(
                    children: [
                      Flexible(
                        child: Text(
                          item.title,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: isDark ? Colors.white : const Color(0xFF0F172A),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                        decoration: BoxDecoration(
                          color: item.color.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          item.category.toUpperCase(),
                          style: TextStyle(
                            fontSize: 9.5,
                            fontWeight: FontWeight.w900,
                            color: item.color,
                          ),
                        ),
                      ),
                    ],
                  ),
                  subtitle: Text(
                    item.subtitle,
                    style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w500,
                      color: isDark ? Colors.white60 : Colors.black54,
                    ),
                  ),
                  trailing: const Icon(Icons.chevron_right_rounded, size: 20),
                  onTap: item.onTap,
                ),
              ),
            );
          },
          childCount: results.length,
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Top Executive Profile Hero Card (Phone Settings Style)
  // ---------------------------------------------------------------------------
  Widget _buildExecutiveProfileCard(BuildContext context, bool isDark) {
    final isM3 = ThemeSignals.isMaterialYou;
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorial;
    final isNotebook = ThemeSignals.isNotebook;
    final isLine = ThemeSignals.isLine;
    final isPoster = ThemeSignals.isPoster;
    final cs = Theme.of(context).colorScheme;
    final isFaculty = _userRole == 'faculty';

    final cardContent = Row(
      children: [
        // 1. Phone-style Squircle Avatar with Role Badge
        Stack(
          clipBehavior: Clip.none,
          children: [
            Container(
              width: 58,
              height: 58,
              decoration: BoxDecoration(
                gradient: isM3
                    ? LinearGradient(
                        colors: [cs.primaryContainer, cs.secondaryContainer],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      )
                    : const LinearGradient(
                        colors: [VitalTokens.blue, VitalTokens.purple],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: isM3
                      ? cs.primary.withValues(alpha: isDark ? 0.4 : 0.25)
                      : Colors.white.withValues(alpha: 0.25),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.3 : 0.08),
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  _userName.isNotEmpty ? _userName[0].toUpperCase() : 'U',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    color: isM3 ? cs.onPrimaryContainer : Colors.white,
                  ),
                ),
              ),
            ),
            Positioned(
              right: -2,
              bottom: -2,
              child: Container(
                width: 15,
                height: 15,
                decoration: BoxDecoration(
                  color: const Color(0xFF10B981),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: isM3
                        ? (isDark ? cs.surfaceContainer : Colors.white)
                        : (isDark ? const Color(0xFF0F172A) : Colors.white),
                    width: 2.5,
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(width: 16),

        // 2. User Name, Role & Batch Subtitle
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _userName,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.3,
                  color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                ),
              ),
              const SizedBox(height: 3),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                      color: isFaculty
                          ? VitalTokens.purple.withValues(alpha: 0.15)
                          : VitalTokens.blue.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      isFaculty ? 'FACULTY' : 'STUDENT',
                      style: TextStyle(
                        fontSize: 9.5,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.5,
                        color: isFaculty ? VitalTokens.purple : VitalTokens.blue,
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Flexible(
                    child: Text(
                      isFaculty ? 'COMSATS Dept' : _batch,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 3),
              Text(
                'Tap to configure profile & batch',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  color: isM3 ? cs.primary : VitalTokens.blue,
                ),
              ),
            ],
          ),
        ),

        // 3. Chevron Indicator
        Icon(
          Icons.chevron_right_rounded,
          size: 24,
          color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white38 : Colors.black26),
        ),
      ],
    );

    final quickRoleBar = Padding(
      padding: const EdgeInsets.only(top: 14),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => _quickSwitchRole('student'),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 9),
                decoration: BoxDecoration(
                  color: !isFaculty
                      ? (isM3 ? cs.primaryContainer : VitalTokens.blue.withValues(alpha: isDark ? 0.26 : 0.14))
                      : (isDark ? Colors.white.withValues(alpha: 0.04) : Colors.black.withValues(alpha: 0.04)),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: !isFaculty
                        ? (isM3 ? cs.primary : VitalTokens.blue)
                        : Colors.transparent,
                    width: 1.2,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.school_rounded,
                      size: 15,
                      color: !isFaculty
                          ? (isM3 ? cs.onPrimaryContainer : VitalTokens.blue)
                          : (isDark ? Colors.white54 : Colors.black54),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'Student Mode',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: !isFaculty ? FontWeight.w800 : FontWeight.w600,
                        color: !isFaculty
                            ? (isM3 ? cs.onPrimaryContainer : (isDark ? Colors.white : const Color(0xFF0F172A)))
                            : (isDark ? Colors.white54 : Colors.black54),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => _quickSwitchRole('faculty'),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 9),
                decoration: BoxDecoration(
                  color: isFaculty
                      ? (isM3 ? cs.primaryContainer : VitalTokens.purple.withValues(alpha: isDark ? 0.28 : 0.14))
                      : (isDark ? Colors.white.withValues(alpha: 0.04) : Colors.black.withValues(alpha: 0.04)),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isFaculty
                        ? (isM3 ? cs.primary : VitalTokens.purple)
                        : Colors.transparent,
                    width: 1.2,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.badge_rounded,
                      size: 15,
                      color: isFaculty
                          ? (isM3 ? cs.onPrimaryContainer : VitalTokens.purple)
                          : (isDark ? Colors.white54 : Colors.black54),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'Faculty Mode',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: isFaculty ? FontWeight.w800 : FontWeight.w600,
                        color: isFaculty
                            ? (isM3 ? cs.onPrimaryContainer : (isDark ? Colors.white : const Color(0xFF0F172A)))
                            : (isDark ? Colors.white54 : Colors.black54),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );

    final fullProfileCardBody = Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: _navigateToProfile,
          child: fullProfileCardBody,
        ),
        quickRoleBar,
      ],
    );

    if (isEditorial) {
      return InkWell(
        onTap: _navigateToProfile,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          decoration: BoxDecoration(
            color: EditorialTokens.cardSurface(isDark),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: EditorialTokens.cardBorder(isDark), width: 1.2),
            boxShadow: EditorialTokens.cardShadow(isDark, elevation: 2),
          ),
          padding: const EdgeInsets.all(18),
          child: fullProfileCardBody,
        ),
      );
    }

    if (isAlmanac) {
      return InkWell(
        onTap: _navigateToProfile,
        child: Container(
          decoration: BoxDecoration(
            color: AlmanacTokens.cardSurface(isDark),
            border: Border.all(color: AlmanacTokens.inkRule(isDark), width: 1.2),
          ),
          padding: const EdgeInsets.all(18),
          child: fullProfileCardBody,
        ),
      );
    }

    if (isPoster) {
      return InkWell(
        onTap: _navigateToProfile,
        child: Container(
          decoration: BoxDecoration(
            color: PosterTokens.cardSurface(isDark),
            border: Border.all(color: PosterTokens.inkBorder(isDark), width: 2.0),
            boxShadow: PosterTokens.extrudedBlockShadow(isDark, offset: 3),
          ),
          padding: const EdgeInsets.all(18),
          child: fullProfileCardBody,
        ),
      );
    }

    if (isLine) {
      return InkWell(
        onTap: _navigateToProfile,
        child: Container(
          decoration: BoxDecoration(
            color: LineTokens.cardSurface(isDark),
            border: Border.all(color: LineTokens.railLine(isDark), width: 1.5),
          ),
          padding: const EdgeInsets.all(18),
          child: fullProfileCardBody,
        ),
      );
    }

    if (isNotebook) {
      return InkWell(
        onTap: _navigateToProfile,
        child: Container(
          decoration: BoxDecoration(
            color: NotebookTokens.cardSurface(isDark),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: NotebookTokens.gridLine(isDark), width: 1.2),
          ),
          padding: const EdgeInsets.all(18),
          child: fullProfileCardBody,
        ),
      );
    }

    return ExpressiveInteractivePress(
      onTap: _navigateToProfile,
      pressedScale: 0.97,
      child: GlassCard(
        borderRadius: 24,
        elevation: 2,
        padding: const EdgeInsets.all(18),
        child: fullProfileCardBody,
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Group 1: Display & Preferences (Grouped Inset Card)
  // ---------------------------------------------------------------------------
  Widget _buildDisplayGroup(BuildContext context, bool isDark) {
    return _buildGroupContainer(
      context,
      isDark,
      children: [
        _buildPhoneSettingRow(
          context,
          isDark: isDark,
          title: 'Appearance & Themes',
          subtitle: 'Display modes, all 7 design engines & Monet dynamic palette',
          icon: Icons.palette_rounded,
          gradientColors: const [Color(0xFF6366F1), Color(0xFF8B5CF6)],
          onTap: _navigateToAppearance,
        ),
        _buildGroupDivider(context, isDark),
        _buildPhoneSettingRow(
          context,
          isDark: isDark,
          title: 'Notifications & Alerts',
          subtitle: 'Android persistent tracker, lecture alarms & disturbance rules',
          icon: Icons.notifications_active_rounded,
          gradientColors: const [Color(0xFFF59E0B), Color(0xFFF97316)],
          onTap: _navigateToNotifications,
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // Group 2: Data, Storage & Feedback (Grouped Inset Card)
  // ---------------------------------------------------------------------------
  Widget _buildDataGroup(BuildContext context, bool isDark) {
    return _buildGroupContainer(
      context,
      isDark,
      children: [
        _buildPhoneSettingRow(
          context,
          isDark: isDark,
          title: 'Data, Storage & Edge Sync',
          subtitle: 'Supabase cloud sync, timetable cache & credentials footprint',
          icon: Icons.cloud_sync_rounded,
          gradientColors: const [Color(0xFF10B981), Color(0xFF059669)],
          onTap: _navigateToDataStorage,
        ),
        _buildGroupDivider(context, isDark),
        _buildPhoneSettingRow(
          context,
          isDark: isDark,
          title: 'Send Feedback & Bug Reports',
          subtitle: 'Share feedback or report an issue directly with the dev desk',
          icon: Icons.rate_review_rounded,
          gradientColors: const [Color(0xFF0284C7), Color(0xFF0369A1)],
          onTap: _navigateToFeedback,
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // Group 3: About & Governance (Grouped Inset Card)
  // ---------------------------------------------------------------------------
  Widget _buildAboutGroup(BuildContext context, bool isDark) {
    return _buildGroupContainer(
      context,
      isDark,
      children: [
        _buildPhoneSettingRow(
          context,
          isDark: isDark,
          title: 'About IRIS & System Specs',
          subtitle: 'v1.0.5+6 (Perfected) • Hardware specs, blessings & developer suite',
          icon: Icons.phone_android_rounded,
          gradientColors: const [Color(0xFF8B5CF6), Color(0xFFD946EF)],
          onTap: _navigateToAboutIris,
        ),
        _buildGroupDivider(context, isDark),
        _buildPhoneSettingRow(
          context,
          isDark: isDark,
          title: 'Privacy Policy',
          subtitle: 'Local-first architecture and telemetry disclosure',
          icon: Icons.shield_outlined,
          gradientColors: const [Color(0xFF64748B), Color(0xFF475569)],
          onTap: _navigateToPrivacy,
        ),
        _buildGroupDivider(context, isDark),
        _buildPhoneSettingRow(
          context,
          isDark: isDark,
          title: 'Terms of Service',
          subtitle: 'Academic fair-use & governance rules',
          icon: Icons.gavel_rounded,
          gradientColors: const [Color(0xFF6B7280), Color(0xFF374151)],
          onTap: _navigateToTerms,
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // Reusable Phone Group Container & Dividers
  // ---------------------------------------------------------------------------
  Widget _buildGroupContainer(BuildContext context, bool isDark, {required List<Widget> children}) {
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorial;
    final isPoster = ThemeSignals.isPoster;
    final isLine = ThemeSignals.isLine;
    final isNotebook = ThemeSignals.isNotebook;

    if (isEditorial) {
      return Container(
        decoration: BoxDecoration(
          color: EditorialTokens.cardSurface(isDark),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: EditorialTokens.cardBorder(isDark), width: 1.2),
          boxShadow: EditorialTokens.cardShadow(isDark, elevation: 1),
        ),
        child: Column(children: children),
      );
    }

    if (isAlmanac) {
      return Container(
        decoration: BoxDecoration(
          color: AlmanacTokens.cardSurface(isDark),
          border: Border.all(color: AlmanacTokens.inkRule(isDark), width: 1.2),
        ),
        child: Column(children: children),
      );
    }

    if (isPoster) {
      return Container(
        decoration: BoxDecoration(
          color: PosterTokens.cardSurface(isDark),
          border: Border.all(color: PosterTokens.inkBorder(isDark), width: 2.0),
          boxShadow: PosterTokens.extrudedBlockShadow(isDark, offset: 3),
        ),
        child: Column(children: children),
      );
    }

    if (isLine) {
      return Container(
        decoration: BoxDecoration(
          color: LineTokens.cardSurface(isDark),
          border: Border.all(color: LineTokens.railLine(isDark), width: 1.5),
        ),
        child: Column(children: children),
      );
    }

    if (isNotebook) {
      return Container(
        decoration: BoxDecoration(
          color: NotebookTokens.cardSurface(isDark),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: NotebookTokens.gridLine(isDark), width: 1.2),
        ),
        child: Column(children: children),
      );
    }

    return GlassCard(
      borderRadius: 24,
      elevation: 2,
      padding: EdgeInsets.zero,
      child: Column(children: children),
    );
  }

  Widget _buildGroupDivider(BuildContext context, bool isDark) {
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;
    return Divider(
      height: 1,
      indent: 64,
      endIndent: 16,
      color: isM3
          ? cs.outlineVariant.withValues(alpha: isDark ? 0.25 : 0.45)
          : (isDark ? Colors.white10 : Colors.black12),
    );
  }

  Widget _buildPhoneSettingRow(
    BuildContext context, {
    required bool isDark,
    required String title,
    required String subtitle,
    required IconData icon,
    required List<Color> gradientColors,
    required VoidCallback onTap,
  }) {
    final isM3 = ThemeSignals.isMaterialYou;
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorial;
    final isNotebook = ThemeSignals.isNotebook;
    final isLine = ThemeSignals.isLine;
    final isPoster = ThemeSignals.isPoster;
    final cs = Theme.of(context).colorScheme;

    // Theme-specific leading icon badge widget
    final Widget iconBadge;
    if (isAlmanac) {
      iconBadge = Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: AlmanacTokens.cardSurface(isDark),
          border: Border.all(color: AlmanacTokens.accentTerracotta(isDark), width: 1.2),
        ),
        child: Center(
          child: Icon(icon, color: AlmanacTokens.accentTerracotta(isDark), size: 18),
        ),
      );
    } else if (isEditorial) {
      iconBadge = Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: EditorialTokens.chipSurface(isDark),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: EditorialTokens.cardBorder(isDark), width: 1.0),
        ),
        child: Center(
          child: Icon(icon, color: EditorialTokens.accentUpcoming, size: 18),
        ),
      );
    } else if (isLine) {
      iconBadge = Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: LineTokens.cardSurface(isDark),
          border: Border.all(color: LineTokens.railLine(isDark), width: 1.5),
        ),
        child: Center(
          child: Icon(icon, color: LineTokens.railLine(isDark), size: 18),
        ),
      );
    } else if (isNotebook) {
      iconBadge = Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: NotebookTokens.cardSurface(isDark),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: NotebookTokens.redDoodle(isDark).withValues(alpha: 0.6), width: 1.2),
        ),
        child: Center(
          child: Icon(icon, color: NotebookTokens.redDoodle(isDark), size: 18),
        ),
      );
    } else if (isPoster) {
      iconBadge = Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: PosterTokens.cardSurface(isDark),
          border: Border.all(color: PosterTokens.inkBorder(isDark), width: 2.0),
          boxShadow: PosterTokens.extrudedBlockShadow(isDark, offset: 2),
        ),
        child: Center(
          child: Icon(icon, color: PosterTokens.orangeHero, size: 18),
        ),
      );
    } else if (isM3) {
      iconBadge = Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: cs.primaryContainer,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Center(
          child: Icon(icon, color: cs.onPrimaryContainer, size: 20),
        ),
      );
    } else {
      iconBadge = Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: gradientColors,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: gradientColors.first.withValues(alpha: 0.28),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Center(
          child: Icon(icon, color: Colors.white, size: 20),
        ),
      );
    }

    // Theme-specific Title Typography
    final TextStyle titleStyle;
    if (isAlmanac) {
      titleStyle = AlmanacTokens.serifHeadline(isDark, fontSize: 14.5, fontWeight: FontWeight.w700);
    } else if (isEditorial) {
      titleStyle = EditorialTokens.headingSerif(isDark, fontSize: 14.5, fontWeight: FontWeight.w700);
    } else if (isLine) {
      titleStyle = LineTokens.stationName(isDark).copyWith(fontSize: 14, fontWeight: FontWeight.w800);
    } else if (isNotebook) {
      titleStyle = NotebookTokens.boldScript(isDark, fontSize: 15);
    } else if (isPoster) {
      titleStyle = PosterTokens.classTitle(isDark).copyWith(fontSize: 13.5, fontWeight: FontWeight.w900);
    } else if (isM3) {
      titleStyle = TextStyle(
        fontSize: 14.5,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.2,
        color: cs.onSurface,
      );
    } else {
      titleStyle = TextStyle(
        fontSize: 14.5,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.2,
        color: isDark ? Colors.white : const Color(0xFF0F172A),
      );
    }

    // Theme-specific Subtitle Typography
    final TextStyle subtitleStyle;
    if (isAlmanac) {
      subtitleStyle = AlmanacTokens.monoHeader(isDark, fontSize: 10.5, color: isDark ? Colors.white60 : Colors.black54);
    } else if (isEditorial) {
      subtitleStyle = EditorialTokens.monoLabel(isDark, fontSize: 10.5);
    } else if (isLine) {
      subtitleStyle = LineTokens.stationMeta(isDark).copyWith(fontSize: 10.5);
    } else if (isNotebook) {
      subtitleStyle = NotebookTokens.handwrittenBody(isDark, fontSize: 11);
    } else if (isPoster) {
      subtitleStyle = TextStyle(
        fontSize: 10,
        fontWeight: FontWeight.w700,
        letterSpacing: 0.4,
        color: isDark ? Colors.white60 : Colors.black54,
      );
    } else if (isM3) {
      subtitleStyle = TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w500,
        color: cs.onSurfaceVariant,
      );
    } else {
      subtitleStyle = TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w500,
        color: isDark ? Colors.white60 : Colors.black54,
      );
    }

    // Theme-specific Trailing Chevron
    final Color chevronColor;
    if (isAlmanac) {
      chevronColor = AlmanacTokens.inkMuted(isDark);
    } else if (isEditorial) {
      chevronColor = EditorialTokens.inkMuted(isDark);
    } else if (isLine) {
      chevronColor = LineTokens.railLine(isDark);
    } else if (isNotebook) {
      chevronColor = NotebookTokens.inkMuted(isDark);
    } else if (isPoster) {
      chevronColor = PosterTokens.inkHeading(isDark);
    } else if (isM3) {
      chevronColor = cs.onSurfaceVariant;
    } else {
      chevronColor = isDark ? Colors.white30 : Colors.black26;
    }

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            iconBadge,
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: titleStyle),
                  const SizedBox(height: 2),
                  Text(subtitle, style: subtitleStyle),
                ],
              ),
            ),
            Icon(Icons.chevron_right_rounded, size: 22, color: chevronColor),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Section Headers & System Footer
  // ---------------------------------------------------------------------------
  Widget _buildSectionLabel(BuildContext context, String text) {
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorial;
    final isNotebook = ThemeSignals.isNotebook;
    final isLine = ThemeSignals.isLine;
    final isPoster = ThemeSignals.isPoster;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    if (isAlmanac) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Row(
          children: [
            Text(
              '§ ${text.toUpperCase()}',
              style: AlmanacTokens.monoHeader(
                isDark,
                fontSize: 10.5,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.2,
                color: AlmanacTokens.accentTerracotta(isDark),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Container(
                height: 0.8,
                color: AlmanacTokens.inkRuleSubtle(isDark),
              ),
            ),
          ],
        ),
      );
    }

    if (isEditorial) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Row(
          children: [
            Text(
              text.toUpperCase(),
              style: EditorialTokens.monoLabel(
                isDark,
                fontSize: 10.5,
              ).copyWith(letterSpacing: 1.2, fontWeight: FontWeight.w800),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Container(
                height: 0.8,
                color: EditorialTokens.cardBorder(isDark),
              ),
            ),
          ],
        ),
      );
    }

    if (isLine) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Text(
          '[SECTION // ${text.toUpperCase()}]',
          style: LineTokens.stationMeta(isDark).copyWith(
            fontSize: 10.5,
            fontWeight: FontWeight.w800,
            color: LineTokens.railLine(isDark),
          ),
        ),
      );
    }

    if (isNotebook) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Text(
          '• $text',
          style: NotebookTokens.boldScript(
            isDark,
            fontSize: 14,
          ).copyWith(color: NotebookTokens.redDoodle(isDark)),
        ),
      );
    }

    if (isPoster) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: PosterTokens.orangeHero,
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text(
            text.toUpperCase(),
            style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w900,
              color: Colors.black,
              letterSpacing: 0.8,
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(left: 6),
      child: Text(
        text.toUpperCase(),
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.2,
          color: isM3 ? cs.primary : (isDark ? Colors.white60 : const Color(0xFF475569)),
        ),
      ),
    );
  }

  Widget _buildSystemFooter(BuildContext context, bool isDark) {
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorial;
    final isNotebook = ThemeSignals.isNotebook;
    final isLine = ThemeSignals.isLine;
    final isPoster = ThemeSignals.isPoster;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    if (isAlmanac) {
      return Column(
        children: [
          Container(height: 1.5, color: AlmanacTokens.inkRule(isDark)),
          const SizedBox(height: 3.5),
          Container(height: 0.8, color: AlmanacTokens.inkRule(isDark)),
          const SizedBox(height: 14),
          Text(
            'THE IRIS ALMANAC & GAZETTE',
            style: AlmanacTokens.serifHeadline(
              isDark,
              fontSize: 13.5,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'COMSATS University Islamabad · Autonomous Academic Registry',
            textAlign: TextAlign.center,
            style: AlmanacTokens.monoHeader(
              isDark,
              fontSize: 10,
              letterSpacing: 0.6,
            ),
          ),
        ],
      );
    }

    if (isEditorial) {
      return Column(
        children: [
          Container(height: 1, color: EditorialTokens.cardBorder(isDark)),
          const SizedBox(height: 14),
          Text(
            'THE IRIS ACADEMIC REVIEW',
            style: EditorialTokens.headingSerif(
              isDark,
              fontSize: 13,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'COMSATS University Islamabad • Literary Study Edition',
            textAlign: TextAlign.center,
            style: EditorialTokens.monoLabel(
              isDark,
              fontSize: 10,
            ),
          ),
        ],
      );
    }

    if (isLine) {
      return Column(
        children: [
          Container(height: 2, color: LineTokens.railLine(isDark)),
          const SizedBox(height: 12),
          Text(
            'IRIS METRO TRANSIT // TERMINAL LINE',
            style: LineTokens.stationName(isDark).copyWith(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '[SYSTEM_OK // PLATFORM_ACTIVE]',
            textAlign: TextAlign.center,
            style: LineTokens.stationMeta(isDark).copyWith(fontSize: 10),
          ),
        ],
      );
    }

    if (isNotebook) {
      return Column(
        children: [
          Container(height: 1.5, color: NotebookTokens.gridLine(isDark)),
          const SizedBox(height: 12),
          Text(
            '• IRIS Student Journal & Planner •',
            style: NotebookTokens.boldScript(
              isDark,
              fontSize: 14,
            ).copyWith(color: NotebookTokens.redDoodle(isDark)),
          ),
          const SizedBox(height: 4),
          Text(
            'Handcrafted for COMSATS University Scholars',
            textAlign: TextAlign.center,
            style: NotebookTokens.handwrittenBody(isDark, fontSize: 11),
          ),
        ],
      );
    }

    if (isPoster) {
      return Column(
        children: [
          Container(height: 3, color: PosterTokens.inkBorder(isDark)),
          const SizedBox(height: 12),
          Text(
            'IRIS // SWISS MONOLITH // VER 1.0.3+4',
            style: PosterTokens.classTitle(isDark).copyWith(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'AUTONOMOUS CAMPUS INTELLIGENCE // COMSATS',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.w800, letterSpacing: 0.6),
          ),
        ],
      );
    }

    return Column(
      children: [
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [IrisTokens.brand, IrisTokens.purple],
            ),
            boxShadow: [
              BoxShadow(
                color: IrisTokens.brand.withValues(alpha: 0.25),
                blurRadius: 8,
              ),
            ],
          ),
          child: const Center(
            child: Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 18),
          ),
        ),
        const SizedBox(height: 10),
        Text(
          'IRIS ENHANCED',
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w900,
            letterSpacing: 2.0,
            color: isM3 ? cs.onSurface : (isDark ? Colors.white70 : const Color(0xFF0F172A)),
          ),
        ),
        const SizedBox(height: 2),
        Text(
          'Autonomous Campus Intelligence • COMSATS University Islamabad',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 10.5,
            fontWeight: FontWeight.w500,
            color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white38 : Colors.black45),
          ),
        ),
      ],
    );
  }
}

class _SearchItem {
  final String title;
  final String subtitle;
  final String category;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _SearchItem({
    required this.title,
    required this.subtitle,
    required this.category,
    required this.icon,
    required this.color,
    required this.onTap,
  });
}
