import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/models.dart';
import '../../core/omni_brain.dart';
import '../../core/app_signals.dart';
import '../../core/vital_theme.dart';
import '../../core/theme_signals.dart';
import '../../core/animations.dart';
import '../../services/ui_feedback.dart';
import '../../widgets/glass_card.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';

/// Commercial-grade Phone-like Account & Academic Profile Screen.
/// Seamlessly adapts to all 7 IRIS design styles (Pixel M3 Expressive, Liquid Glass, etc.).
class ProfileSettingsScreen extends StatefulWidget {
  final UniversityMemory memory;
  final String userName;
  final String userRole;
  final String batch;
  final ValueChanged<String>? onUserNameChanged;
  final ValueChanged<String>? onRoleChanged;
  final ValueChanged<String>? onBatchChanged;

  const ProfileSettingsScreen({
    super.key,
    required this.memory,
    required this.userName,
    required this.userRole,
    required this.batch,
    this.onUserNameChanged,
    this.onRoleChanged,
    this.onBatchChanged,
  });

  @override
  State<ProfileSettingsScreen> createState() => _ProfileSettingsScreenState();
}

class _ProfileSettingsScreenState extends State<ProfileSettingsScreen> {
  late String _userName;
  late String _userRole;
  late String _batch;
  String _registrationId = '';

  @override
  void initState() {
    super.initState();
    _userName = AppSignals.activeUserName.value.isNotEmpty
        ? AppSignals.activeUserName.value
        : widget.userName;
    _userRole = AppSignals.activeRole.value.isNotEmpty
        ? AppSignals.activeRole.value
        : widget.userRole;
    _batch = AppSignals.activeBatch.value.isNotEmpty
        ? AppSignals.activeBatch.value
        : widget.batch;
    _loadRegistrationId();
    AppSignals.stateRevision.addListener(_onSignalsChanged);
  }

  @override
  void dispose() {
    AppSignals.stateRevision.removeListener(_onSignalsChanged);
    super.dispose();
  }

  void _onSignalsChanged() {
    if (!mounted) return;
    setState(() {
      if (AppSignals.activeRole.value.isNotEmpty) {
        _userRole = AppSignals.activeRole.value;
      }
      if (AppSignals.activeBatch.value.isNotEmpty) {
        _batch = AppSignals.activeBatch.value;
      }
      if (AppSignals.activeUserName.value.isNotEmpty) {
        _userName = AppSignals.activeUserName.value;
      }
    });
  }

  Future<void> _loadRegistrationId() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        _registrationId = prefs.getString('student_registration_id') ?? '';
      });
    }
  }

  static String _getDegreeTitle(String batch) {
    final upper = batch.toUpperCase();
    if (upper.contains('BCS') || upper.contains('-CS-')) return 'BS Computer Science';
    if (upper.contains('BSE') || upper.contains('-SE-')) return 'BS Software Engineering';
    if (upper.contains('BAI') || upper.contains('-AI-')) return 'BS Artificial Intelligence';
    if (upper.contains('BDS') || upper.contains('-DS-')) return 'BS Data Science';
    if (upper.contains('BCY') || upper.contains('-CY-')) return 'BS Cyber Security';
    if (upper.contains('BEE') || upper.contains('-EE-')) return 'BS Electrical Engineering';
    if (upper.contains('BBA')) return 'Bachelor of Business Admin';
    return 'BS Degree Program';
  }

  void _editUserName() {
    final controller = TextEditingController(text: _userName);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    showDialog(
      context: context,
      builder: (dialogCtx) {
        return AlertDialog(
          backgroundColor: isM3 ? cs.surfaceContainerHigh : (isDark ? const Color(0xFF1E293B) : Colors.white),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: Text(
            'Edit Profile Name',
            style: TextStyle(
              fontWeight: FontWeight.w900,
              fontSize: 18,
              color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Visible on home screen greetings, live notifications, and timetable headers.',
                style: TextStyle(
                  fontSize: 12,
                  color: isDark ? Colors.white60 : Colors.black54,
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: controller,
                autofocus: true,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: isM3 ? cs.onSurface : (isDark ? Colors.white : Colors.black87),
                ),
                decoration: InputDecoration(
                  filled: true,
                  fillColor: isM3 ? cs.surfaceContainer : (isDark ? Colors.black26 : const Color(0xFFF1F5F9)),
                  hintText: 'Enter your full name',
                  prefixIcon: Icon(
                    Icons.person_outline_rounded,
                    color: isM3 ? cs.primary : VitalTokens.blue,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogCtx),
              child: Text(
                'Cancel',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: isDark ? Colors.white60 : Colors.black54,
                ),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: isM3 ? cs.primary : VitalTokens.blue,
                foregroundColor: isM3 ? cs.onPrimary : Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                elevation: 0,
              ),
              onPressed: () async {
                final newName = controller.text.trim();
                if (newName.isNotEmpty) {
                  final prefs = await SharedPreferences.getInstance();
                  await AppSignals.setUserName(newName, role: _userRole);
                  widget.onUserNameChanged?.call(newName);
                  if (mounted) setState(() => _userName = newName);
                  if (dialogCtx.mounted) Navigator.pop(dialogCtx);
                }
              },
              child: const Text('Save Name', style: TextStyle(fontWeight: FontWeight.w800)),
            ),
          ],
        );
      },
    );
  }

  void _editRegistrationId() {
    final controller = TextEditingController(text: _registrationId);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    showDialog(
      context: context,
      builder: (dialogCtx) {
        return AlertDialog(
          backgroundColor: isM3 ? cs.surfaceContainerHigh : (isDark ? const Color(0xFF1E293B) : Colors.white),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: Text(
            'Student Registration ID',
            style: TextStyle(
              fontWeight: FontWeight.w900,
              fontSize: 18,
              color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'E.g. SP22-BCS-042 or CIIT/SP22-BCS-042/SWL. Used for automatic portal login autofill.',
                style: TextStyle(
                  fontSize: 12,
                  color: isDark ? Colors.white60 : Colors.black54,
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: controller,
                autofocus: true,
                textCapitalization: TextCapitalization.characters,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontFamily: 'monospace',
                  color: isM3 ? cs.onSurface : (isDark ? Colors.white : Colors.black87),
                ),
                decoration: InputDecoration(
                  filled: true,
                  fillColor: isM3 ? cs.surfaceContainer : (isDark ? Colors.black26 : const Color(0xFFF1F5F9)),
                  hintText: 'SP22-BCS-042',
                  prefixIcon: Icon(
                    Icons.badge_outlined,
                    color: isM3 ? cs.primary : VitalTokens.blue,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogCtx),
              child: Text(
                'Cancel',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: isDark ? Colors.white60 : Colors.black54,
                ),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: isM3 ? cs.primary : VitalTokens.blue,
                foregroundColor: isM3 ? cs.onPrimary : Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                elevation: 0,
              ),
              onPressed: () async {
                final newId = controller.text.trim().toUpperCase();
                final prefs = await SharedPreferences.getInstance();
                await prefs.setString('student_registration_id', newId);
                if (mounted) setState(() => _registrationId = newId);
                if (dialogCtx.mounted) Navigator.pop(dialogCtx);
              },
              child: const Text('Save ID', style: TextStyle(fontWeight: FontWeight.w800)),
            ),
          ],
        );
      },
    );
  }

  void _switchRole(String newRole) async {
    if (newRole == _userRole) return;
    IrisHaptics.actionHeavy();
    final brain = OmniBrain(widget.memory);
    String? resolvedName;
    if (newRole == 'faculty') {
      final prefs = await SharedPreferences.getInstance();
      final teachers = brain.allTeachers();
      final savedFaculty = prefs.getString('faculty_user_name') ?? prefs.getString('faculty_teacher');
      if (savedFaculty != null &&
          savedFaculty.isNotEmpty &&
          savedFaculty != 'Faculty Member' &&
          savedFaculty != 'Student' &&
          (teachers.isEmpty || teachers.contains(savedFaculty))) {
        resolvedName = savedFaculty;
      } else {
        resolvedName = teachers.isNotEmpty ? teachers.first : 'Faculty Member';
      }
    } else {
      final prefs = await SharedPreferences.getInstance();
      final savedStudent = prefs.getString('student_user_name') ?? prefs.getString('student_name');
      resolvedName = (savedStudent != null && savedStudent.isNotEmpty) ? savedStudent : 'Student';
      if (_batch.isEmpty && widget.memory.allBatches.isNotEmpty) {
        final firstBatch = widget.memory.allBatches.first;
        await AppSignals.setBatch(firstBatch);
        widget.onBatchChanged?.call(firstBatch);
      }
    }
    await AppSignals.setRole(newRole, userName: resolvedName);
    widget.onRoleChanged?.call(newRole);
    if (mounted) {
      setState(() {
        _userRole = newRole;
        if (resolvedName != null && resolvedName.isNotEmpty) {
          _userName = resolvedName;
        }
      });
    }
  }

  void _selectFacultyTeacher() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;
    final allTeachers = OmniBrain(widget.memory).allTeachers();
    String searchQuery = '';

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (sheetCtx) {
        return StatefulBuilder(
          builder: (ctx, setSheetState) {
            final filtered = searchQuery.trim().isEmpty
                ? allTeachers
                : allTeachers
                    .where((t) => t.toLowerCase().contains(searchQuery.trim().toLowerCase()))
                    .toList();
            return Container(
              constraints: BoxConstraints(
                maxHeight: MediaQuery.sizeOf(context).height * 0.78,
              ),
              decoration: BoxDecoration(
                color: isM3
                    ? cs.surfaceContainerHigh
                    : (isDark ? const Color(0xFF0F172A) : Colors.white),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(height: 12),
                  Container(
                    width: 38,
                    height: 4.5,
                    decoration: BoxDecoration(
                      color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 10),
                    child: Row(
                      children: [
                        Icon(
                          Icons.badge_rounded,
                          color: isM3 ? cs.primary : VitalTokens.purple,
                          size: 22,
                        ),
                        const SizedBox(width: 12),
                        Text(
                          'Select Faculty Profile',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                    child: TextField(
                      onChanged: (val) => setSheetState(() => searchQuery = val),
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: isDark ? Colors.white : Colors.black87,
                      ),
                      decoration: InputDecoration(
                        hintText: 'Search faculty instructor name...',
                        prefixIcon: const Icon(Icons.search_rounded, size: 20),
                        filled: true,
                        fillColor: isM3
                            ? cs.surfaceContainer
                            : (isDark ? Colors.white.withValues(alpha: 0.06) : const Color(0xFFF1F5F9)),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  const Divider(height: 1),
                  Flexible(
                    child: ListView.builder(
                      shrinkWrap: true,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      itemCount: filtered.length,
                      itemBuilder: (ctx, i) {
                        final t = filtered[i];
                        final isSelected = t == _userName;
                        return InkWell(
                          borderRadius: BorderRadius.circular(14),
                          onTap: () async {
                            IrisHaptics.selectionClick();
                            await AppSignals.setTeacher(t);
                            widget.onUserNameChanged?.call(t);
                            if (mounted) setState(() => _userName = t);
                            if (sheetCtx.mounted) Navigator.pop(sheetCtx);
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
                            margin: const EdgeInsets.symmetric(vertical: 3),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? (isM3
                                      ? cs.primaryContainer.withValues(alpha: isDark ? 0.35 : 0.6)
                                      : VitalTokens.purple.withValues(alpha: isDark ? 0.22 : 0.12))
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(14),
                              border: isSelected
                                  ? Border.all(color: isM3 ? cs.primary : VitalTokens.purple, width: 1.2)
                                  : null,
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    t,
                                    style: TextStyle(
                                      fontSize: 14.5,
                                      fontWeight: isSelected ? FontWeight.w900 : FontWeight.w600,
                                      color: isSelected
                                          ? (isM3 ? cs.primary : VitalTokens.purple)
                                          : (isDark ? Colors.white : const Color(0xFF1E293B)),
                                    ),
                                  ),
                                ),
                                if (isSelected)
                                  Icon(
                                    Icons.check_circle_rounded,
                                    size: 18,
                                    color: isM3 ? cs.primary : VitalTokens.purple,
                                  ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _selectBatch() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (sheetCtx) {
        return Container(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.sizeOf(context).height * 0.75,
          ),
          decoration: BoxDecoration(
            color: isM3
                ? cs.surfaceContainerHigh
                : (isDark ? const Color(0xFF0F172A) : Colors.white),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: isDark ? 0.5 : 0.15),
                blurRadius: 20,
                offset: const Offset(0, -4),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 12),
              Container(
                width: 38,
                height: 4.5,
                decoration: BoxDecoration(
                  color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
                child: Row(
                  children: [
                    Icon(
                      Icons.layers_rounded,
                      color: isM3 ? cs.primary : VitalTokens.blue,
                      size: 22,
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'Select Academic Batch',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                      ),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  itemCount: widget.memory.allBatches.length,
                  itemBuilder: (ctx, i) {
                    final b = widget.memory.allBatches[i];
                    final isSelected = b == _batch;
                    return InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () async {
                        IrisHaptics.selectionClick();
                        await AppSignals.setBatch(b);
                        widget.onBatchChanged?.call(b);
                        setState(() => _batch = b);
                        if (sheetCtx.mounted) Navigator.pop(sheetCtx);
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
                        margin: const EdgeInsets.symmetric(vertical: 3),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? (isM3
                                  ? cs.primaryContainer.withValues(alpha: isDark ? 0.35 : 0.6)
                                  : VitalTokens.blue.withValues(alpha: isDark ? 0.2 : 0.1))
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(14),
                          border: isSelected
                              ? Border.all(color: isM3 ? cs.primary : VitalTokens.blue, width: 1.2)
                              : null,
                        ),
                        child: Row(
                          children: [
                            Text(
                              b,
                              style: TextStyle(
                                fontSize: 14.5,
                                fontWeight: isSelected ? FontWeight.w900 : FontWeight.w600,
                                color: isSelected
                                    ? (isM3 ? cs.primary : VitalTokens.blue)
                                    : (isDark ? Colors.white : const Color(0xFF1E293B)),
                              ),
                            ),
                            const Spacer(),
                            if (isSelected)
                              Icon(
                                Icons.check_circle_rounded,
                                size: 18,
                                color: isM3 ? cs.primary : VitalTokens.blue,
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorial;
    final isNotebook = ThemeSignals.isNotebook;
    final isLine = ThemeSignals.isLine;
    final isPoster = ThemeSignals.isPoster;
    final cs = Theme.of(context).colorScheme;
    final isFaculty = _userRole == 'faculty';

    final TextStyle appBarTitleStyle;
    if (isAlmanac) {
      appBarTitleStyle = AlmanacTokens.serifHeadline(isDark, fontSize: 18, fontWeight: FontWeight.w800);
    } else if (isEditorial) {
      appBarTitleStyle = EditorialTokens.headingSerif(isDark, fontSize: 18, fontWeight: FontWeight.w900);
    } else if (isNotebook) {
      appBarTitleStyle = NotebookTokens.boldScript(isDark, fontSize: 19);
    } else if (isLine) {
      appBarTitleStyle = LineTokens.stationName(isDark).copyWith(fontSize: 17, fontWeight: FontWeight.w900);
    } else if (isPoster) {
      appBarTitleStyle = PosterTokens.classTitle(isDark).copyWith(fontSize: 17, fontWeight: FontWeight.w900);
    } else if (isM3) {
      appBarTitleStyle = TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: cs.onSurface);
    } else {
      appBarTitleStyle = TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w900,
        color: isDark ? Colors.white : const Color(0xFF0F172A),
      );
    }

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: ExpressiveInteractivePress(
          pressedScale: 0.90,
          onTap: () => Navigator.of(context).pop(),
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: isM3
                  ? cs.surfaceContainer
                  : (isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.06)),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.arrow_back_rounded,
              size: 20,
              color: isDark ? Colors.white : const Color(0xFF0F172A),
            ),
          ),
        ),
        title: Text(
          'Account & Profile',
          style: appBarTitleStyle,
        ),
      ),
      body: Stack(
        children: [
          ObsidianPulse(isDark: isDark),
          SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 720),
                child: ListView(
                  physics: const ButterScrollPhysics(
                    parent: AlwaysScrollableScrollPhysics(),
                  ),
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
                  children: [
                    // 1. Phone-like Avatar Hero Card
                    Center(
                      child: Column(
                        children: [
                          Stack(
                            clipBehavior: Clip.none,
                            children: [
                              Container(
                                width: 88,
                                height: 88,
                                decoration: BoxDecoration(
                                  gradient: isM3
                                      ? LinearGradient(
                                          colors: [cs.primary, cs.secondary],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        )
                                      : const LinearGradient(
                                          colors: [VitalTokens.blue, VitalTokens.purple],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        ),
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: (isM3 ? cs.primary : VitalTokens.blue).withValues(alpha: 0.35),
                                      blurRadius: 18,
                                      offset: const Offset(0, 6),
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: Text(
                                    _userName.isNotEmpty ? _userName[0].toUpperCase() : 'U',
                                    style: const TextStyle(
                                      fontSize: 36,
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                right: 0,
                                bottom: 0,
                                child: ExpressiveInteractivePress(
                                  onTap: _editUserName,
                                  child: Container(
                                    padding: const EdgeInsets.all(7),
                                    decoration: BoxDecoration(
                                      color: isM3 ? cs.primaryContainer : Colors.white,
                                      shape: BoxShape.circle,
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black.withValues(alpha: 0.15),
                                          blurRadius: 6,
                                        ),
                                      ],
                                    ),
                                    child: Icon(
                                      Icons.edit_rounded,
                                      size: 15,
                                      color: isM3 ? cs.onPrimaryContainer : const Color(0xFF0F172A),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 14),
                          Text(
                            _userName,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            isFaculty ? 'COMSATS University Faculty' : _getDegreeTitle(_batch),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 28),

                    // 2. Persona Mode Switcher
                    _buildSectionHeader('Role & Mode Architecture'),
                    const SizedBox(height: 10),
                    GlassCard(
                      borderRadius: 22,
                      elevation: 2,
                      padding: const EdgeInsets.all(6),
                      child: Row(
                        children: [
                          Expanded(
                            child: _buildRoleSegmentPill(
                              label: 'Student Mode',
                              icon: Icons.school_rounded,
                              active: !isFaculty,
                              onTap: () => _switchRole('student'),
                            ),
                          ),
                          Expanded(
                            child: _buildRoleSegmentPill(
                              label: 'Faculty Mode',
                              icon: Icons.badge_rounded,
                              active: isFaculty,
                              onTap: () => _switchRole('faculty'),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // 3. Academic Credentials Group
                    _buildSectionHeader('Academic Credentials'),
                    const SizedBox(height: 10),
                    GlassCard(
                      borderRadius: 22,
                      elevation: 2,
                      padding: EdgeInsets.zero,
                      child: Column(
                        children: [
                          _buildProfileRow(
                            title: 'Display Name',
                            value: _userName,
                            icon: Icons.person_rounded,
                            iconColor: VitalTokens.blue,
                            onTap: _editUserName,
                          ),
                          const Divider(height: 1, indent: 58),
                          if (!isFaculty) ...[
                            _buildProfileRow(
                              title: 'Active Batch',
                              value: _batch.isNotEmpty ? _batch : 'Set Batch',
                              icon: Icons.layers_rounded,
                              iconColor: VitalTokens.purple,
                              onTap: _selectBatch,
                            ),
                            const Divider(height: 1, indent: 58),
                            _buildProfileRow(
                              title: 'Student Registration ID',
                              value: _registrationId.isNotEmpty ? _registrationId : 'Not configured',
                              icon: Icons.pin_rounded,
                              iconColor: const Color(0xFF10B981),
                              onTap: _editRegistrationId,
                            ),
                          ] else ...[
                            _buildProfileRow(
                              title: 'Active Faculty Profile',
                              value: _userName.isNotEmpty ? _userName : 'Select Instructor',
                              icon: Icons.assignment_ind_rounded,
                              iconColor: VitalTokens.purple,
                              onTap: _selectFacultyTeacher,
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // 4. Institution Details
                    _buildSectionHeader('Institutional Registry'),
                    const SizedBox(height: 10),
                    GlassCard(
                      borderRadius: 22,
                      elevation: 2,
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: (isM3 ? cs.primary : VitalTokens.blue).withValues(alpha: 0.12),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: Icon(
                                  Icons.account_balance_rounded,
                                  size: 22,
                                  color: isM3 ? cs.primary : VitalTokens.blue,
                                ),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'COMSATS University Islamabad',
                                      style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w900,
                                        color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      'Sahiwal Campus · Autonomous Local Client',
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String label) {
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorial;
    final isNotebook = ThemeSignals.isNotebook;
    final isLine = ThemeSignals.isLine;
    final isPoster = ThemeSignals.isPoster;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    if (isAlmanac) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Row(
          children: [
            Text(
              '§ ${label.toUpperCase()}',
              style: AlmanacTokens.monoHeader(
                isDark,
                fontSize: 10.5,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.2,
                color: AlmanacTokens.accentTerracotta(isDark),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Container(
                height: 0.8,
                color: AlmanacTokens.inkRuleSubtle(isDark),
              ),
            ),
          ],
        ),
      );
    }

    if (isEditorial) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Row(
          children: [
            Text(
              label.toUpperCase(),
              style: EditorialTokens.monoLabel(
                isDark,
                fontSize: 10.5,
              ).copyWith(letterSpacing: 1.2, fontWeight: FontWeight.w800),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Container(
                height: 0.8,
                color: EditorialTokens.cardBorder(isDark),
              ),
            ),
          ],
        ),
      );
    }

    if (isLine) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Text(
          '[SECTION // ${label.toUpperCase()}]',
          style: LineTokens.stationMeta(isDark).copyWith(
            fontSize: 10.5,
            fontWeight: FontWeight.w800,
            color: LineTokens.railLine(isDark),
          ),
        ),
      );
    }

    if (isNotebook) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Text(
          '• $label',
          style: NotebookTokens.boldScript(
            isDark,
            fontSize: 14,
          ).copyWith(color: NotebookTokens.redDoodle(isDark)),
        ),
      );
    }

    if (isPoster) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: PosterTokens.orangeHero,
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text(
            label.toUpperCase(),
            style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w900,
              color: Colors.black,
              letterSpacing: 0.8,
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(left: 6),
      child: Text(
        label.toUpperCase(),
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.1,
          color: isM3 ? cs.primary : (isDark ? Colors.white60 : const Color(0xFF64748B)),
        ),
      ),
    );
  }

  Widget _buildRoleSegmentPill({
    required String label,
    required IconData icon,
    required bool active,
    required VoidCallback onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    return GestureDetector(
      onTap: () {
        IrisHaptics.selectionClick();
        onTap();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.fastOutSlowIn,
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: active
              ? (isM3 ? cs.surfaceContainerHighest : (isDark ? const Color(0xFF334155) : Colors.white))
              : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          boxShadow: active
              ? [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.08),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 16,
              color: active
                  ? (isM3 ? cs.primary : VitalTokens.blue)
                  : (isDark ? Colors.white54 : Colors.black54),
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: active ? FontWeight.w900 : FontWeight.w600,
                color: active
                    ? (isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)))
                    : (isDark ? Colors.white54 : Colors.black54),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileRow({
    required String title,
    required String value,
    required IconData icon,
    required Color iconColor,
    required VoidCallback onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    return InkWell(
      onTap: () {
        IrisHaptics.actionSoft();
        onTap();
      },
      borderRadius: BorderRadius.circular(20),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: iconColor.withValues(alpha: isDark ? 0.20 : 0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: iconColor, size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w800,
                      color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    value,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.chevron_right_rounded,
              size: 20,
              color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white30 : Colors.black26),
            ),
          ],
        ),
      ),
    );
  }
}
