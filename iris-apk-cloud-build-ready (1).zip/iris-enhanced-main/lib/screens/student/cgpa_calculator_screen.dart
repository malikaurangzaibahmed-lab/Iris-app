import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import '../../core/glass.dart';
import '../../core/tokens.dart';
import '../../widgets/glass_card.dart';
import 'package:iris/widgets/controls/glowing_input_wrapper.dart';
import '../../services/ui_feedback.dart';
import '../../core/vital_theme.dart';
import '../../core/animations.dart';
import '../../core/theme_signals.dart';
import 'package:iris/widgets/controls/iris_liquid_button.dart';
import '../../widgets/iris_components.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';

class CgpaCalculatorScreen extends StatefulWidget {
  const CgpaCalculatorScreen({super.key});

  @override
  State<CgpaCalculatorScreen> createState() => _CgpaCalculatorScreenState();
}

class _CgpaCalculatorScreenState extends State<CgpaCalculatorScreen> {
  final List<CgpaCourseRow> _rows = [
    CgpaCourseRow(),
    CgpaCourseRow(),
    CgpaCourseRow(),
  ];

  final TextEditingController _priorCgpaController = TextEditingController();
  final TextEditingController _priorCreditsController = TextEditingController();

  double _semesterGpa = 0.0;
  double _cumulativeCgpa = 0.0;
  bool _includePriorCgpa = false;

  @override
  void dispose() {
    _priorCgpaController.dispose();
    _priorCreditsController.dispose();
    for (final row in _rows) {
      row.dispose();
    }
    super.dispose();
  }

  void _recalculate() {
    double semQualityPoints = 0;
    double semTotalCredits = 0;

    for (final row in _rows) {
      final credits = double.tryParse(row.creditsController.text) ?? 0;
      if (credits <= 0) continue;
      semQualityPoints += credits * row.gradePoint;
      semTotalCredits += credits;
    }

    final priorCgpa = double.tryParse(_priorCgpaController.text) ?? 0.0;
    final priorCredits = double.tryParse(_priorCreditsController.text) ?? 0.0;

    double cumulativeGpa = 0.0;
    if (_includePriorCgpa && priorCredits > 0) {
      final priorQualityPoints = priorCgpa * priorCredits;
      final totalQualityPoints = priorQualityPoints + semQualityPoints;
      final totalCredits = priorCredits + semTotalCredits;
      cumulativeGpa = totalCredits > 0 ? totalQualityPoints / totalCredits : 0.0;
    } else {
      cumulativeGpa = semTotalCredits > 0 ? semQualityPoints / semTotalCredits : 0.0;
    }

    setState(() {
      _semesterGpa = semTotalCredits > 0 ? semQualityPoints / semTotalCredits : 0.0;
      _cumulativeCgpa = cumulativeGpa;
    });
  }

  void _addRow() {
    setState(() {
      _rows.add(CgpaCourseRow());
    });
    _recalculate();
  }

  void _removeRow(int index) {
    if (_rows.length <= 1) return;
    final row = _rows.removeAt(index);
    row.dispose();
    setState(() {});
    _recalculate();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: irisFrostedAppBar(
        title: 'CGPA Calculator',
        isDark: isDark,
      ),
      body: Stack(
        children: [
          ObsidianPulse(isDark: isDark),
          Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 780),
              child: ListView(
                padding: EdgeInsets.fromLTRB(
                  20,
                  MediaQuery.paddingOf(context).top + kToolbarHeight + 12,
                  20,
                  36,
                ),
            children: [
              GlassCard(
                borderRadius: 22,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: IrisTokens.brandGradient),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: const Icon(Icons.school_rounded, color: Colors.white, size: 24),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Semester GPA Simulator',
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                              color: isDark ? Colors.white : Colors.black,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            'Estimate GPA and keep your degree milestones on track.',
                            style: TextStyle(
                              fontSize: 12.5,
                              height: 1.3,
                              color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.64),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              GlassCard(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Semester GPA',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.6),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              _semesterGpa.toStringAsFixed(2),
                              style: TextStyle(
                                fontSize: 28,
                                fontWeight: FontWeight.w900,
                                letterSpacing: -0.5,
                                color: IrisTokens.brand,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(height: 40, width: 1, color: isDark ? Colors.white10 : Colors.black12),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _includePriorCgpa ? 'Cumulative CGPA' : 'Target CGPA',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.6),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              _includePriorCgpa ? _cumulativeCgpa.toStringAsFixed(2) : _semesterGpa.toStringAsFixed(2),
                              style: TextStyle(
                                fontSize: 28,
                                fontWeight: FontWeight.w900,
                                letterSpacing: -0.5,
                                color: IrisTokens.purple,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),

              // Cumulative CGPA Toggle Card
              GlassCard(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.calculate_rounded, color: IrisTokens.purple, size: 20),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Calculate Overall Cumulative CGPA',
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w800,
                                    color: isDark ? Colors.white : Colors.black87,
                                  ),
                                ),
                                Text(
                                  'Include previous semesters\' CGPA & total credit hours',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.5),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          IrisGlassSwitch(
                            value: _includePriorCgpa,
                            activeColor: IrisTokens.purple,
                            onChanged: (val) {
                              setState(() => _includePriorCgpa = val);
                              _recalculate();
                              IrisHaptics.chipSelect();
                            },
                          ),
                        ],
                      ),
                      if (_includePriorCgpa) ...[
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: IrisTextField(
                                controller: _priorCgpaController,
                                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                onChanged: (_) => _recalculate(),
                                isDark: isDark,
                                label: 'Prior CGPA',
                                hint: 'e.g. 3.45',
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: IrisTextField(
                                controller: _priorCreditsController,
                                keyboardType: TextInputType.number,
                                onChanged: (_) => _recalculate(),
                                isDark: isDark,
                                label: 'Prior Credits',
                                hint: 'e.g. 45',
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Add your courses below',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: (isDark ? Colors.white : Colors.black).withValues(
                    alpha: 0.72,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              ...List.generate(_rows.length, (index) {
                final row = _rows[index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: CgpaRowCard(
                    index: index,
                    row: row,
                    onChanged: _recalculate,
                    onDelete: () => _removeRow(index),
                  ),
                );
              }),
              const SizedBox(height: 6),
              Row(
                children: [
                  Expanded(
                    child: ExpressiveSpringPress(
                      onTap: _addRow,
                      child: IrisLiquidButton(
                        text: 'Add Course',
                        icon: Icons.add_rounded,
                        onTap: _addRow,
                        color: isDark ? Colors.white12 : Colors.black12,
                        isDark: isDark,
                        height: 44,
                        borderSide: BorderSide(
                          color: IrisTokens.brand.withValues(alpha: 0.5),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ExpressiveSpringPress(
                      onTap: _recalculate,
                      child: IrisLiquidButton(
                        text: 'Recalculate',
                        icon: Icons.refresh_rounded,
                        onTap: _recalculate,
                        color: IrisTokens.brand,
                        isDark: isDark,
                        height: 44,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ],
  ),
);
  }
}

class CgpaCourseRow {
  CgpaCourseRow();

  final TextEditingController nameController = TextEditingController();
  final TextEditingController creditsController = TextEditingController();
  String grade = 'A';

  static const Map<String, double> gradePoints = {
    'A': 4.0,
    'A-': 3.67,
    'B+': 3.33,
    'B': 3.00,
    'B-': 2.67,
    'C+': 2.33,
    'C': 2.00,
    'C-': 1.67,
    'D+': 1.33,
    'D': 1.00,
    'F': 0.0,
  };

  double get gradePoint => gradePoints[grade] ?? 0.0;

  List<String> get gradeOptions => gradePoints.keys.toList();

  void dispose() {
    nameController.dispose();
    creditsController.dispose();
  }
}

class CgpaRowCard extends StatelessWidget {
  final int index;
  final CgpaCourseRow row;
  final VoidCallback onChanged;
  final VoidCallback onDelete;

  const CgpaRowCard({
    super.key,
    required this.index,
    required this.row,
    required this.onChanged,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return GlassCard(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  'Course ${index + 1}',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: isDark ? Colors.white : Colors.black,
                  ),
                ),
                const Spacer(),
                IconButton(
                  onPressed: onDelete,
                  icon: Icon(
                    Icons.delete_outline_rounded,
                    color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.6),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            IrisTextField(
              controller: row.nameController,
              isDark: isDark,
              label: 'Course Name (optional)',
              onChanged: (_) => onChanged(),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: IrisTextField(
                    controller: row.creditsController,
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9.]')),
                    ],
                    isDark: isDark,
                    label: 'Credits',
                    onChanged: (_) => onChanged(),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: IrisGlassMenu(
                    autoAdjustToScreen: true,
                    menuPadding: const EdgeInsets.all(16),
                    menuWidth: 190,
                    menuHeight: 280.0,
                    menuBorderRadius: 28.0,
                    itemBorderRadius: 20.0,
                    settings: IrisGlass.widgetsSettings(
                      context,
                      blur: 16.0,
                      ambientStrength: 0.7,
                      lightAngle: 0.15 * math.pi,
                      thickness: 18.0,
                    ),
                    triggerBuilder: (context, toggleMenu) {
                      final isM3 = ThemeSignals.isMaterialYou;
                      final cs = Theme.of(context).colorScheme;
                      final themeStyle = ThemeSignals.themeStyle.value;

                      final pillBg = switch (themeStyle) {
                        IrisThemeStyle.materialYou => isDark ? cs.surfaceContainerHigh : cs.surfaceContainerLow,
                        IrisThemeStyle.notebook => NotebookTokens.cardSurface(isDark),
                        IrisThemeStyle.line => LineTokens.cardSurface(isDark),
                        IrisThemeStyle.poster => isDark ? const Color(0xFF1C1917) : const Color(0xFFF5F5F4),
                        IrisThemeStyle.almanac => AlmanacTokens.canvas(isDark),
                        IrisThemeStyle.editorialAcademic => EditorialTokens.cardSurface(isDark),
                        _ => isDark ? Colors.white.withValues(alpha: 0.06) : Colors.white.withValues(alpha: 0.88),
                      };

                      final pillBorder = switch (themeStyle) {
                        IrisThemeStyle.materialYou => Border.all(
                            color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.6),
                            width: 1.0,
                          ),
                        IrisThemeStyle.notebook => Border.all(
                            color: NotebookTokens.gridLine(isDark),
                            width: 1.0,
                          ),
                        IrisThemeStyle.line => Border.all(
                            color: LineTokens.railLine(isDark),
                            width: 1.2,
                          ),
                        IrisThemeStyle.poster => Border.all(
                            color: PosterTokens.inkBorder(isDark),
                            width: 1.5,
                          ),
                        IrisThemeStyle.almanac => Border.all(
                            color: AlmanacTokens.inkRuleSubtle(isDark),
                            width: 1.0,
                          ),
                        IrisThemeStyle.editorialAcademic => Border.all(
                            color: EditorialTokens.cardBorder(isDark),
                            width: 1.0,
                          ),
                        _ => Border.all(
                            color: isDark ? Colors.white.withValues(alpha: 0.15) : Colors.black.withValues(alpha: 0.08),
                            width: 1.0,
                          ),
                      };

                      final titleColor = switch (themeStyle) {
                        IrisThemeStyle.materialYou => cs.onSurfaceVariant,
                        IrisThemeStyle.notebook => NotebookTokens.inkMuted(isDark),
                        IrisThemeStyle.line => LineTokens.inkMuted(isDark),
                        IrisThemeStyle.poster => PosterTokens.inkMuted(isDark),
                        IrisThemeStyle.almanac => AlmanacTokens.inkMuted(isDark),
                        IrisThemeStyle.editorialAcademic => EditorialTokens.inkMuted(isDark),
                        _ => isDark ? Colors.white70 : Colors.black54,
                      };

                      final valueColor = switch (themeStyle) {
                        IrisThemeStyle.materialYou => cs.onSurface,
                        IrisThemeStyle.notebook => NotebookTokens.inkHeading(isDark),
                        IrisThemeStyle.line => LineTokens.inkHeading(isDark),
                        IrisThemeStyle.poster => PosterTokens.inkHeading(isDark),
                        IrisThemeStyle.almanac => AlmanacTokens.inkHeading(isDark),
                        IrisThemeStyle.editorialAcademic => EditorialTokens.inkHeading(isDark),
                        _ => isDark ? Colors.white : Colors.black87,
                      };

                      return RepaintBoundary(
                        child: ExpressiveSpringPress(
                          onTap: () {
                            IrisHaptics.actionSoft();
                            toggleMenu();
                          },
                          child: Container(
                            height: 56,
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                            decoration: BoxDecoration(
                              border: pillBorder,
                              borderRadius: BorderRadius.circular(isM3 ? 18 : 22),
                              color: pillBg,
                              boxShadow: [
                                if (!isM3 && !isDark && themeStyle == IrisThemeStyle.fluidGlass)
                                  BoxShadow(
                                    color: Colors.black.withValues(alpha: 0.04),
                                    blurRadius: 8,
                                    offset: const Offset(0, 2),
                                  ),
                              ],
                            ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Grade',
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w700,
                                      color: titleColor,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    row.grade,
                                    style: TextStyle(
                                      fontSize: 14.5,
                                      fontWeight: FontWeight.w800,
                                      color: valueColor,
                                    ),
                                  ),
                                ],
                              ),
                              Icon(
                                Icons.keyboard_arrow_down_rounded,
                                color: titleColor,
                              ),
                            ],
                          ),
                        ),
                      ),);
                    },
                    items: row.gradeOptions.map((g) {
                      final isSelected = g == row.grade;
                      return lgw.GlassMenuItem(
                        title: '$g (${CgpaCourseRow.gradePoints[g]})',
                        titleStyle: TextStyle(
                          fontWeight: isSelected ? FontWeight.bold : FontWeight.w600,
                          fontSize: 14,
                          color: isSelected ? IrisTokens.brand : (isDark ? Colors.white.withValues(alpha: 0.9) : Colors.black87),
                        ),
                        isSelected: isSelected,
                        icon: Icon(
                          Icons.grade_rounded,
                          size: 16,
                          color: isSelected ? IrisTokens.brand : (isDark ? Colors.white70 : Colors.black54),
                        ),
                        onTap: () {
                          IrisHaptics.chipSelect();
                          row.grade = g;
                          onChanged();
                        },
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
