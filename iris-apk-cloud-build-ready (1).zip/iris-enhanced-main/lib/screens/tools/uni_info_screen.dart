import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/animations.dart';
import '../../core/vital_theme.dart';
import '../../services/helpdesk_uni_info_service.dart';
import '../../services/room_persistence_service.dart';
import '../../services/ui_feedback.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/iris_components.dart';
import 'resource_hero_card.dart';

class UniInfoScreen extends StatefulWidget {
  final int initialTabIndex;
  const UniInfoScreen({super.key, this.initialTabIndex = 0});

  @override
  State<UniInfoScreen> createState() => _UniInfoScreenState();
}

class _UniInfoScreenState extends State<UniInfoScreen> {
  UniInfoPayload? _payload;
  bool _loading = true;
  List<RoomData> _allRooms = [];
  int _roomCount = 0;
  int _labCount = 0;
  late int _activeTab;
  String _searchQuery = '';
  String _selectedAlumniDept = 'All';
  int? _expandedSocietyIndex = 0;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _activeTab = widget.initialTabIndex.clamp(0, 3);
    _loadData();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    final svc = HelpdeskUniInfoService();
    final data = await svc.fetchUniInfo();

    final roomSvc = RoomPersistenceService();
    final allRooms = await roomSvc.loadAllCampusRoomData();

    int labs = 0;
    int rooms = 0;
    for (final r in allRooms) {
      if (r.type == 'lab' ||
          r.id.toLowerCase().contains('lab') ||
          r.building.toLowerCase().contains('lab') ||
          (r.attendantName?.isNotEmpty ?? false)) {
        labs++;
      } else {
        rooms++;
      }
    }

    if (mounted) {
      setState(() {
        _payload = data;
        _allRooms = allRooms;
        _roomCount = rooms;
        _labCount = labs;
        _loading = false;
      });
    }
  }

  void _copyContact(String label, String text) {
    if (text.isEmpty) return;
    IrisHaptics.actionMedium();
    Clipboard.setData(ClipboardData(text: text));
    showIrisFrostedSnackBar(
      context,
      tint: const Color(0xFF3B82F6),
      content: Text('Copied $label ($text)'),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final onSurface = Theme.of(context).colorScheme.onSurface;
    final topInset = MediaQuery.paddingOf(context).top + kToolbarHeight + 12;
    final q = _searchQuery.trim().toLowerCase();

    final societies = (_payload?.societies ?? const []).where((s) {
      if (q.isEmpty) return true;
      final map = s is Map ? s : const {};
      final name = (map['name'] ?? '').toString().toLowerCase();
      final desc =
          (map['desc'] ?? map['description'] ?? '').toString().toLowerCase();
      return name.contains(q) || desc.contains(q);
    }).toList();

    final rawAlumni = _payload?.alumni ?? const [];
    final alumniDepts = <String>{'All'};
    for (final a in rawAlumni) {
      if (a is Map) {
        final d = (a['department'] ?? '').toString().trim();
        if (d.isNotEmpty) alumniDepts.add(d);
      }
    }

    final allAlumni = rawAlumni.where((a) {
      final map = a is Map ? a : const {};
      if (_selectedAlumniDept != 'All') {
        final dept = (map['department'] ?? '').toString().trim();
        if (dept != _selectedAlumniDept) return false;
      }
      if (q.isEmpty) return true;
      final name = (map['name'] ?? '').toString().toLowerCase();
      final pos = (map['position'] ?? map['role'] ?? map['companyAddress'] ?? '')
          .toString()
          .toLowerCase();
      final dept = (map['department'] ?? '').toString().toLowerCase();
      return name.contains(q) || pos.contains(q) || dept.contains(q);
    }).toList();

    final allBooks = (_payload?.books ?? const []).where((b) {
      if (q.isEmpty) return true;
      final map = b is Map ? b : const {};
      final title = (map['name'] ?? '').toString().toLowerCase();
      final desc =
          (map['desc'] ?? map['author'] ?? '').toString().toLowerCase();
      return title.contains(q) || desc.contains(q);
    }).toList();

    final labRooms = _allRooms.where((r) {
      final isLab = r.id.toLowerCase().contains('lab') ||
          r.building.toLowerCase().contains('lab') ||
          (r.attendantName?.isNotEmpty ?? false);
      if (!isLab) return false;
      if (q.isEmpty) return true;
      return r.id.toLowerCase().contains(q) ||
          r.building.toLowerCase().contains(q) ||
          (r.attendantName?.toLowerCase().contains(q) ?? false);
    }).toList();

    final tabs = [
      (
        icon: Icons.domain_rounded,
        label: 'Facilities',
        count: _roomCount + _labCount,
        color: const Color(0xFF3B82F6),
      ),
      (
        icon: Icons.groups_rounded,
        label: 'Societies',
        count: societies.length,
        color: const Color(0xFF8B5CF6),
      ),
      (
        icon: Icons.school_rounded,
        label: 'Alumni',
        count: allAlumni.length,
        color: const Color(0xFF10B981),
      ),
      (
        icon: Icons.menu_book_rounded,
        label: 'Books',
        count: allBooks.length,
        color: const Color(0xFFF59E0B),
      ),
    ];

    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: irisFrostedAppBar(title: 'Campus Explorer', isDark: isDark),
      body: Stack(
        children: [
          ObsidianPulse(isDark: isDark),
          _loading
              ? Center(child: IrisComponents.loadingSpinner(size: 28))
              : ListView(
                  physics: const ButterScrollPhysics(
                    parent: AlwaysScrollableScrollPhysics(),
                  ),
                  padding: EdgeInsets.fromLTRB(16, topInset, 16, 48),
                  children: [
                    ResourceHeroCard(
                      title: 'COMSATS Sahiwal Explorer',
                      subtitle:
                          '$_roomCount halls • $_labCount labs • ${societies.length} societies • ${allAlumni.length} alumni • ${allBooks.length} books',
                      icon: Icons.explore_rounded,
                      accent: tabs[_activeTab].color,
                      isDark: isDark,
                    ),
                    const SizedBox(height: 14),

                    // Universal Search Bar
                    GlassCard(
                      borderRadius: 20,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 4,
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.search_rounded,
                            size: 20,
                            color: tabs[_activeTab].color,
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: TextField(
                              controller: _searchController,
                              onChanged: (val) =>
                                  setState(() => _searchQuery = val),
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 13.5,
                                color: onSurface,
                              ),
                              decoration: InputDecoration(
                                hintText: _activeTab == 0
                                    ? 'Search labs, blocks, or lab attendants...'
                                    : _activeTab == 1
                                        ? 'Search student societies & cabinets...'
                                        : _activeTab == 2
                                            ? 'Search 145 alumni by name, role, or company...'
                                            : 'Search 346 library books by title or topic...',
                                hintStyle: TextStyle(
                                  fontSize: 12.5,
                                  color: onSurface.withValues(alpha: 0.45),
                                ),
                                border: InputBorder.none,
                                isDense: true,
                              ),
                            ),
                          ),
                          if (_searchQuery.isNotEmpty)
                            IconButton(
                              icon: const Icon(Icons.clear_rounded, size: 18),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(),
                              onPressed: () {
                                _searchController.clear();
                                setState(() => _searchQuery = '');
                              },
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),

                    // 4-Tab Segmented Switcher
                    SizedBox(
                      height: 44,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: tabs.length,
                        separatorBuilder: (_, _) => const SizedBox(width: 8),
                        itemBuilder: (context, idx) {
                          final t = tabs[idx];
                          final selected = _activeTab == idx;
                          return GestureDetector(
                            onTap: () {
                              IrisHaptics.chipSelect();
                              setState(() => _activeTab = idx);
                            },
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 200),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 8,
                              ),
                              decoration: BoxDecoration(
                                color: selected
                                    ? t.color
                                    : onSurface.withValues(alpha: 0.07),
                                borderRadius: BorderRadius.circular(14),
                                boxShadow: selected
                                    ? [
                                        BoxShadow(
                                          color: t.color.withValues(alpha: 0.3),
                                          blurRadius: 10,
                                          offset: const Offset(0, 3),
                                        ),
                                      ]
                                    : null,
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    t.icon,
                                    size: 16,
                                    color: selected ? Colors.white : t.color,
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    '${t.label} (${t.count})',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: selected
                                          ? FontWeight.w800
                                          : FontWeight.w600,
                                      color: selected
                                          ? Colors.white
                                          : onSurface.withValues(alpha: 0.85),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 16),

                    // TAB 0: FACILITIES & LAB ATTENDANTS
                    if (_activeTab == 0) ...[
                      Row(
                        children: [
                          Expanded(
                            child: GlassCard(
                              padding: const EdgeInsets.all(16),
                              accentColor: const Color(0xFF3B82F6),
                              child: Column(
                                children: [
                                  Text(
                                    '$_roomCount',
                                    style: const TextStyle(
                                      fontSize: 24,
                                      fontWeight: FontWeight.w900,
                                      color: Color(0xFF3B82F6),
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    'Lecture Halls',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                      color: onSurface.withValues(alpha: 0.78),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: GlassCard(
                              padding: const EdgeInsets.all(16),
                              accentColor: const Color(0xFF10B981),
                              child: Column(
                                children: [
                                  Text(
                                    '$_labCount',
                                    style: const TextStyle(
                                      fontSize: 24,
                                      fontWeight: FontWeight.w900,
                                      color: Color(0xFF10B981),
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    'Computing & Engg Labs',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                      color: onSurface.withValues(alpha: 0.78),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      Text(
                        'Campus Labs & Attendant Directory (${labRooms.length})',
                        style: TextStyle(
                          fontSize: 15.5,
                          fontWeight: FontWeight.w800,
                          color: onSurface.withValues(alpha: 0.92),
                        ),
                      ),
                      const SizedBox(height: 10),
                      ...labRooms.map((lab) {
                        final attendant = lab.attendantName ?? '';
                        final contact = lab.attendantContact ?? '';
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: GlassCard(
                            borderRadius: 18,
                            padding: const EdgeInsets.all(14),
                            child: Row(
                              children: [
                                Container(
                                  width: 42,
                                  height: 42,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF3B82F6)
                                        .withValues(alpha: 0.15),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: const Icon(
                                    Icons.biotech_rounded,
                                    color: Color(0xFF3B82F6),
                                    size: 20,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        '${lab.id} • ${lab.building.toLowerCase().contains("block") ? lab.building : "${lab.building} Block"}',
                                        style: TextStyle(
                                          fontSize: 13.5,
                                          fontWeight: FontWeight.w800,
                                          color: onSurface,
                                        ),
                                      ),
                                      const SizedBox(height: 2),
                                      Text(
                                        attendant.isNotEmpty
                                            ? 'Attendant: $attendant (${lab.floor})'
                                            : '${lab.floor} • Academic Block ${lab.building}',
                                        style: TextStyle(
                                          fontSize: 11.5,
                                          color: onSurface.withValues(
                                            alpha: 0.65,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                if (contact.isNotEmpty)
                                  IconButton(
                                    onPressed: () =>
                                        _copyContact(lab.id, contact),
                                    icon: const Icon(
                                      Icons.phone_in_talk_rounded,
                                      size: 18,
                                      color: Color(0xFF10B981),
                                    ),
                                    tooltip: 'Copy $contact',
                                  ),
                              ],
                            ),
                          ),
                        );
                      }),
                    ],

                    // TAB 1: STUDENT SOCIETIES & CABINETS
                    if (_activeTab == 1) ...[
                      ...List.generate(societies.length, (idx) {
                        final s = societies[idx];
                        final map = s is Map ? s : const {};
                        final name = (map['name'] ?? 'Society').toString();
                        final desc =
                            (map['desc'] ?? map['description'] ?? '').toString();
                        final members = map['members'] is List
                            ? (map['members'] as List)
                            : const [];
                        final isExpanded = _expandedSocietyIndex == idx;

                        return Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: GlassCard(
                            borderRadius: 22,
                            accentColor: const Color(0xFF8B5CF6),
                            padding: const EdgeInsets.all(16),
                            onTap: () {
                              IrisHaptics.selectionClick();
                              setState(() {
                                _expandedSocietyIndex =
                                    isExpanded ? null : idx;
                              });
                            },
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      width: 44,
                                      height: 44,
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF8B5CF6)
                                            .withValues(alpha: 0.16),
                                        borderRadius: BorderRadius.circular(14),
                                      ),
                                      child: const Icon(
                                        Icons.groups_rounded,
                                        color: Color(0xFF8B5CF6),
                                        size: 22,
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            name,
                                            style: TextStyle(
                                              fontSize: 15,
                                              fontWeight: FontWeight.w800,
                                              color: onSurface,
                                            ),
                                          ),
                                          if (members.isNotEmpty)
                                            Text(
                                              '${members.length} Executive Cabinet Members',
                                              style: const TextStyle(
                                                fontSize: 11,
                                                fontWeight: FontWeight.w700,
                                                color: Color(0xFF8B5CF6),
                                              ),
                                            ),
                                        ],
                                      ),
                                    ),
                                    Icon(
                                      isExpanded
                                          ? Icons.expand_less_rounded
                                          : Icons.expand_more_rounded,
                                      color: const Color(0xFF8B5CF6),
                                    ),
                                  ],
                                ),
                                if (desc.isNotEmpty) ...[
                                  const SizedBox(height: 8),
                                  Text(
                                    desc,
                                    style: TextStyle(
                                      fontSize: 12.5,
                                      height: 1.4,
                                      color: onSurface.withValues(alpha: 0.72),
                                    ),
                                  ),
                                ],
                                if (isExpanded && members.isNotEmpty) ...[
                                  const SizedBox(height: 12),
                                  Divider(
                                    height: 1,
                                    color: onSurface.withValues(alpha: 0.10),
                                  ),
                                  const SizedBox(height: 10),
                                  ...members.map((m) {
                                    final mMap = m is Map ? m : const {};
                                    final mName =
                                        (mMap['name'] ?? '').toString();
                                    final mRole =
                                        (mMap['role'] ?? 'Member').toString();
                                    final mContact =
                                        (mMap['contact'] ?? '').toString();
                                    return Padding(
                                      padding: const EdgeInsets.only(bottom: 8),
                                      child: Row(
                                        children: [
                                          const Icon(
                                            Icons.verified_user_rounded,
                                            size: 15,
                                            color: Color(0xFF8B5CF6),
                                          ),
                                          const SizedBox(width: 8),
                                          Expanded(
                                            child: Text(
                                              '$mName • $mRole',
                                              style: TextStyle(
                                                fontSize: 12,
                                                fontWeight: FontWeight.w700,
                                                color: onSurface,
                                              ),
                                            ),
                                          ),
                                          if (mContact.isNotEmpty)
                                            GestureDetector(
                                              onTap: () => _copyContact(
                                                mName,
                                                mContact,
                                              ),
                                              child: Container(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                      horizontal: 8,
                                                      vertical: 3,
                                                    ),
                                                decoration: BoxDecoration(
                                                  color: const Color(0xFF8B5CF6)
                                                      .withValues(alpha: 0.14),
                                                  borderRadius:
                                                      BorderRadius.circular(8),
                                                ),
                                                child: Text(
                                                  mContact,
                                                  style: const TextStyle(
                                                    fontSize: 10.5,
                                                    fontWeight: FontWeight.w800,
                                                    color: Color(0xFF8B5CF6),
                                                  ),
                                                ),
                                              ),
                                            ),
                                        ],
                                      ),
                                    );
                                  }),
                                ],
                              ],
                            ),
                          ),
                        );
                      }),
                    ],

                    // TAB 2: DISTINGUISHED ALUMNI
                    if (_activeTab == 2) ...[
                      if (alumniDepts.length > 1) ...[
                        SizedBox(
                          height: 34,
                          child: ListView.separated(
                            scrollDirection: Axis.horizontal,
                            itemCount: alumniDepts.length,
                            separatorBuilder: (_, _) =>
                                const SizedBox(width: 8),
                            itemBuilder: (context, idx) {
                              final dept = alumniDepts.elementAt(idx);
                              final selected = _selectedAlumniDept == dept;
                              return GestureDetector(
                                onTap: () {
                                  IrisHaptics.chipSelect();
                                  setState(() => _selectedAlumniDept = dept);
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 12,
                                    vertical: 6,
                                  ),
                                  decoration: BoxDecoration(
                                    color: selected
                                        ? const Color(0xFF10B981)
                                        : onSurface.withValues(alpha: 0.08),
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                  child: Text(
                                    dept,
                                    style: TextStyle(
                                      fontSize: 11.5,
                                      fontWeight: selected
                                          ? FontWeight.w800
                                          : FontWeight.w600,
                                      color: selected
                                          ? Colors.white
                                          : onSurface.withValues(alpha: 0.80),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        const SizedBox(height: 12),
                      ],
                      ...allAlumni.take(60).map((a) {
                        final map = a is Map ? a : const {};
                        final name = (map['name'] ?? 'Alumnus').toString();
                        final position =
                            (map['position'] ?? map['role'] ?? 'Alumnus')
                                .toString();
                        final company =
                            (map['companyAddress'] ?? '').toString();
                        final dept = (map['department'] ?? '').toString();
                        final story = (map['story'] ?? '').toString();

                        return Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: GlassCard(
                            borderRadius: 18,
                            padding: const EdgeInsets.all(14),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(9),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF10B981)
                                            .withValues(alpha: 0.15),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: const Icon(
                                        Icons.school_rounded,
                                        size: 18,
                                        color: Color(0xFF10B981),
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            name,
                                            style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w800,
                                              color: onSurface,
                                            ),
                                          ),
                                          const SizedBox(height: 2),
                                          Text(
                                            company.isNotEmpty
                                                ? '$position • $company'
                                                : position,
                                            style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600,
                                              color: onSurface.withValues(
                                                alpha: 0.68,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    if (dept.isNotEmpty)
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 8,
                                          vertical: 3,
                                        ),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFF10B981)
                                              .withValues(alpha: 0.14),
                                          borderRadius:
                                              BorderRadius.circular(6),
                                        ),
                                        child: Text(
                                          dept,
                                          style: const TextStyle(
                                            fontSize: 10,
                                            fontWeight: FontWeight.w800,
                                            color: Color(0xFF10B981),
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                                if (story.isNotEmpty) ...[
                                  const SizedBox(height: 8),
                                  Text(
                                    story,
                                    maxLines: 3,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontSize: 11.5,
                                      height: 1.35,
                                      color: onSurface.withValues(alpha: 0.62),
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                        );
                      }),
                    ],

                    // TAB 3: LIBRARY BOOK CATALOG (346 BOOKS)
                    if (_activeTab == 3) ...[
                      ...allBooks.take(80).map((b) {
                        final map = b is Map ? b : const {};
                        final title = (map['name'] ?? 'Book').toString();
                        final desc =
                            (map['desc'] ?? map['about'] ?? '').toString();
                        final points = map['points'] is List
                            ? (map['points'] as List)
                                .map((e) => e.toString())
                                .toList()
                            : const <String>[];

                        return Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: GlassCard(
                            borderRadius: 18,
                            padding: const EdgeInsets.all(14),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(9),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFF59E0B)
                                            .withValues(alpha: 0.15),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: const Icon(
                                        Icons.menu_book_rounded,
                                        size: 18,
                                        color: Color(0xFFF59E0B),
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            title,
                                            style: TextStyle(
                                              fontSize: 13.5,
                                              fontWeight: FontWeight.w800,
                                              color: onSurface,
                                            ),
                                          ),
                                          if (desc.isNotEmpty) ...[
                                            const SizedBox(height: 3),
                                            Text(
                                              desc,
                                              style: TextStyle(
                                                fontSize: 12,
                                                height: 1.35,
                                                color: onSurface.withValues(
                                                  alpha: 0.68,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                if (points.isNotEmpty) ...[
                                  const SizedBox(height: 8),
                                  Wrap(
                                    spacing: 6,
                                    runSpacing: 6,
                                    children: points.take(3).map((pt) {
                                      return Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 8,
                                          vertical: 3,
                                        ),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFF59E0B)
                                              .withValues(alpha: 0.10),
                                          borderRadius:
                                              BorderRadius.circular(6),
                                        ),
                                        child: Text(
                                          pt,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                            fontSize: 10.5,
                                            fontWeight: FontWeight.w600,
                                            color: onSurface.withValues(
                                              alpha: 0.78,
                                            ),
                                          ),
                                        ),
                                      );
                                    }).toList(),
                                  ),
                                ],
                              ],
                            ),
                          ),
                        );
                      }),
                    ],
                  ],
                ),
        ],
      ),
    );
  }
}
