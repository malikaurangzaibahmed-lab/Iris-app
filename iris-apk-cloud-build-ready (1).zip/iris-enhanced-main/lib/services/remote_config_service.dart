import 'package:flutter/services.dart' show rootBundle;
// ignore_for_file: constant_identifier_names

import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'timetable_ota_service.dart';
import 'notification_service.dart';
import '../services/ui_feedback.dart';

/// Central Remote Synchronization Engine for IRIS Enhanced.
/// Establishes real-time listeners with Firebase Firestore to toggle academic modes,
/// sync OTA timetable schedules, and notify users about system update APKs.
class RemoteConfigService {
  static const int CURRENT_VERSION_CODE = 6;
  static const String CURRENT_VERSION_NAME = '1.0.5';
  /// Baseline version of the bundled normalized timetable seed
  static const int BUNDLED_TIMETABLE_VERSION = 1795000000000;
  /// Build compile timestamp for IRIS Enhanced (Aug 25, 2026 21:35:00 UTC)
  static const int APP_BUILD_TIMESTAMP_MS = 1787693700000;

  static final ValueNotifier<String> activeTrack =
      ValueNotifier<String>('stable');
  static final ValueNotifier<String> activeAcademicPeriod =
      ValueNotifier<String>('classes');
  static final ValueNotifier<Map<String, dynamic>?> latestApkUpdate =
      ValueNotifier<Map<String, dynamic>?>(null);
  static final ValueNotifier<Map<String, dynamic>?> liveAnnouncement =
      ValueNotifier<Map<String, dynamic>?>(null);
  static final ValueNotifier<List<Map<String, dynamic>>> liveNotices =
      ValueNotifier<List<Map<String, dynamic>>>([]);
  static final ValueNotifier<DateTime?> lastConfigUpdateTime =
      ValueNotifier<DateTime?>(null);
  static final ValueNotifier<DateTime?> lastTimetableUpdateTime =
      ValueNotifier<DateTime?>(null);
  static final ValueNotifier<List<dynamic>> midtermExams =
      ValueNotifier<List<dynamic>>([]);
  static final ValueNotifier<List<dynamic>> finalExams =
      ValueNotifier<List<dynamic>>([]);
  static final ValueNotifier<Map<String, dynamic>?> vacationSchedule =
      ValueNotifier<Map<String, dynamic>?>(null);

  static StreamSubscription<DocumentSnapshot>? _configSubscription;

  /// Comprehensive multi-tier check to determine if an update banner should be displayed
  static bool isUpdateEligibleForBanner(
    Map<String, dynamic> updateData,
    SharedPreferences prefs,
  ) {
    final showUpdate = updateData['show_update_card'] as bool? ?? true;
    if (!showUpdate) return false;

    final vName = updateData['version_name']?.toString() ?? '';
    final apkUrl = updateData['apk_url']?.toString() ??
        updateData['download_url']?.toString() ??
        '';

    // Tier 1: Check if user already downloaded/installed this exact APK URL
    final installedUrl = prefs.getString('installed_apk_url') ?? '';
    if (installedUrl.isNotEmpty && apkUrl.isNotEmpty && installedUrl == apkUrl) {
      return false;
    }

    // Tier 2: Check explicit dismissals (X button)
    final dismissedTag = prefs.getString('dismissed_admin_update_tag') ?? '';
    if (vName.isNotEmpty &&
        (prefs.getBool('dismissed_admin_update_$vName') ?? false)) {
      return false;
    }
    if (apkUrl.isNotEmpty &&
        (prefs.getBool('dismissed_admin_update_$apkUrl') ?? false)) {
      return false;
    }
    if (dismissedTag.isNotEmpty &&
        vName.isNotEmpty &&
        (dismissedTag == vName ||
            dismissedTag.contains(vName) ||
            vName.contains(dismissedTag))) {
      return false;
    }

    // Tier 3: Check release timestamp against current app build timestamp
    final dynamic rawReleasedAt = updateData['released_at'];
    if (rawReleasedAt != null) {
      int? releaseMillis;
      if (rawReleasedAt is Timestamp) {
        releaseMillis = rawReleasedAt.millisecondsSinceEpoch;
      } else if (rawReleasedAt is int) {
        releaseMillis = rawReleasedAt;
      } else if (rawReleasedAt is String) {
        releaseMillis = DateTime.tryParse(rawReleasedAt)?.millisecondsSinceEpoch;
      }
      if (releaseMillis != null && releaseMillis <= APP_BUILD_TIMESTAMP_MS) {
        return false; // Code was compiled after or at release time
      }
    }

    // Tier 4: Version code / Version name comparison
    final rawCode = updateData['version_code'];
    int? remoteCode;
    if (rawCode is int) {
      remoteCode = rawCode;
    } else if (rawCode != null) {
      remoteCode = int.tryParse(rawCode.toString());
    }

    if (remoteCode != null && remoteCode > 0) {
      if (remoteCode <= CURRENT_VERSION_CODE) return false;
    } else if (vName.isNotEmpty) {
      if (_compareSemanticVersions(vName, CURRENT_VERSION_NAME) <= 0) {
        return false;
      }
    }

    return true;
  }

  static int _compareSemanticVersions(String v1, String v2) {
    try {
      final cleanV1 = v1.replaceAll(RegExp(r'[^0-9.]'), '');
      final cleanV2 = v2.replaceAll(RegExp(r'[^0-9.]'), '');
      final parts1 = cleanV1.split('.').map((e) => int.tryParse(e) ?? 0).toList();
      final parts2 = cleanV2.split('.').map((e) => int.tryParse(e) ?? 0).toList();

      for (int i = 0; i < math.max(parts1.length, parts2.length); i++) {
        final p1 = i < parts1.length ? parts1[i] : 0;
        final p2 = i < parts2.length ? parts2[i] : 0;
        if (p1 > p2) return 1;
        if (p1 < p2) return -1;
      }
      return 0;
    } catch (_) {
      return 0;
    }
  }

  /// Dismisses an admin update banner for a specific version/keyword tag or APK URL
  static Future<void> dismissAdminUpdateBanner(
    String versionOrKeyword, [
    String? apkUrl,
  ]) async {
    final prefs = await SharedPreferences.getInstance();
    if (versionOrKeyword.isNotEmpty) {
      await prefs.setBool('dismissed_admin_update_$versionOrKeyword', true);
      await prefs.setString('dismissed_admin_update_tag', versionOrKeyword);
    }
    if (apkUrl != null && apkUrl.isNotEmpty) {
      await prefs.setBool('dismissed_admin_update_$apkUrl', true);
    }
    latestApkUpdate.value = null;
  }

  /// Helper to format raw timestamps/DateTimes safely in a custom, premium aesthetic
  static String formatTimestamp(DateTime? dateTime) {
    if (dateTime == null) return 'Never';
    final localDateTime = dateTime.toLocal();
    final months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    final month = months[localDateTime.month - 1];
    final day = localDateTime.day;
    final hourVal = localDateTime.hour == 0
        ? 12
        : (localDateTime.hour > 12
              ? localDateTime.hour - 12
              : localDateTime.hour);
    final minuteVal = localDateTime.minute.toString().padLeft(2, '0');
    final period = localDateTime.hour >= 12 ? 'PM' : 'AM';
    return '$month $day, $hourVal:$minuteVal $period';
  }

  static List<dynamic>? _bundledMidtermCache;

  /// Loads the verified 879-entry Fall 2026 Midterm Date Sheet seed bundled in assets
  static Future<List<dynamic>> loadBundledMidtermSeed() async {
    if (_bundledMidtermCache != null && _bundledMidtermCache!.isNotEmpty) {
      return _bundledMidtermCache!;
    }
    try {
      final raw = await rootBundle.loadString('assets/helpdesk_backup/midterm_fall2026_seed.json');
      final decoded = jsonDecode(raw);
      if (decoded is List && decoded.isNotEmpty) {
        _bundledMidtermCache = decoded;
        return decoded;
      }
    } catch (e) {
      debugPrint('⚠️ loadBundledMidtermSeed notice: $e');
    }
    return const [];
  }

  /// Validates that an exam list is not corrupted by the legacy 2-row step bug
  /// (which put invigilator/course names into the batch field and skipped 11:00 & 03:00 slots).
  static bool isValidExamPayload(List<dynamic> list) {
    if (list.length < 50) return false;
    int validBatchCount = 0;
    bool has1100Slot = false;
    for (final item in list) {
      if (item is! Map) continue;
      final b = (item['batch'] ?? '').toString().trim().toUpperCase();
      final s = (item['subject'] ?? '').toString().trim().toUpperCase();
      final t = (item['time'] ?? '').toString().trim();
      // If subject is a batch code (e.g. FA26-BCS-A), payload was shifted by legacy 2-row step bug
      if (RegExp(r'^(?:FA|SP)\d{2}-[A-Z]{2,5}').hasMatch(s)) {
        return false;
      }
      if (RegExp(r'(?:FA|SP)\d{2}-[A-Z]{2,5}').hasMatch(b)) {
        validBatchCount++;
      }
      if (t.contains('11:00') || t.contains('1100')) {
        has1100Slot = true;
      }
    }
    final hasCanonicalCohort = list.any((item) =>
        item is Map &&
        (item['batch'] ?? '').toString().trim().toUpperCase() == 'FA24-BMD-B1');
    if (validBatchCount < (list.length * 0.85)) return false;
    if (!has1100Slot || !hasCanonicalCohort) return false;
    return true;
  }

  /// Pre-warms remote config values from SharedPreferences synchronously during app startup before UI mounts
  static Future<void> preWarmLocalCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      activeTrack.value = prefs.getString('app_release_track') ?? 'stable';
      final cachedPeriod = prefs.getString('active_academic_period') ?? 'classes';
      activeAcademicPeriod.value = cachedPeriod;

      final cachedMidterms = prefs.getString('cached_midterm_exams') ?? '';
      bool loadedValidMidterms = false;
      if (cachedMidterms.isNotEmpty) {
        try {
          final decoded = jsonDecode(cachedMidterms);
          if (decoded is List && isValidExamPayload(decoded)) {
            midtermExams.value = decoded;
            loadedValidMidterms = true;
          }
        } catch (_) {}
      }
      if (!loadedValidMidterms) {
        final seed = await loadBundledMidtermSeed();
        if (seed.isNotEmpty) {
          midtermExams.value = seed;
          await prefs.setString('cached_midterm_exams', jsonEncode(seed));
        }
      }

      final cachedFinals = prefs.getString('cached_finals_exams') ?? '';
      if (cachedFinals.isNotEmpty) {
        try {
          final decoded = jsonDecode(cachedFinals);
          if (decoded is List) finalExams.value = decoded;
        } catch (_) {}
      }

      final cachedVacation = prefs.getString('cached_vacation_schedule') ?? '';
      if (cachedVacation.isNotEmpty) {
        try {
          final decoded = jsonDecode(cachedVacation);
          if (decoded is Map) vacationSchedule.value = Map<String, dynamic>.from(decoded);
        } catch (_) {}
      }

      final cachedNotices = prefs.getString('cached_campus_notices') ?? '';
      if (cachedNotices.isNotEmpty) {
        try {
          final decoded = jsonDecode(cachedNotices);
          if (decoded is List) {
            liveNotices.value = decoded
                .whereType<Map>()
                .map((m) => Map<String, dynamic>.from(m))
                .toList();
          }
        } catch (_) {}
      }
    } catch (e) {
      debugPrint('⚠️ preWarmLocalCache error: $e');
    }
  }

  static bool _isListening = false;

  /// Switches active release track between stable and beta
  static Future<void> switchReleaseTrack(BuildContext context, String track) async {
    if (activeTrack.value == track && _isListening) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('app_release_track', track);
    activeTrack.value = track;

    _configSubscription?.cancel();
    _isListening = false;
    if (!context.mounted) return;
    startRemoteListener(context);

    IrisHaptics.actionHeavy();
    if (context.mounted) {
      showIrisFrostedSnackBar(
        context,
        content: Text('Switched to ${track.toUpperCase()} Track (${track == 'beta' ? 'config/beta' : 'config/global'})'),
        tint: track == 'beta' ? const Color(0xFF8B5CF6) : const Color(0xFF10B981),
      );
    }
  }

  /// Start real-time Firestore stream to listen for remote administration config changes
  static void startRemoteListener(BuildContext context) {
    if (_isListening) return;
    _isListening = true;

    // Load cached exams and mode from local storage for offline resiliency
    preWarmLocalCache();

    final docId = activeTrack.value == 'beta' ? 'beta' : 'global';
    debugPrint('📡 IRIS Remote Engine: Connecting Firestore streams (Track: ${activeTrack.value}, Doc: $docId)...');

    _configSubscription?.cancel();
    try {
      _configSubscription = FirebaseFirestore.instance
          .collection('config')
          .doc(docId)
          .snapshots()
          .listen(
          (DocumentSnapshot doc) async {
            if (!doc.exists) {
              debugPrint(
                '⚠️ IRIS Remote Engine: Remote config document ($docId) not found.',
              );
              return;
            }

            final data = doc.data() as Map<String, dynamic>? ?? {};

            // Parse config update time
            final dynamic configUpdateRaw = data['updated_at'];
            if (configUpdateRaw != null) {
              if (configUpdateRaw is Timestamp) {
                lastConfigUpdateTime.value = configUpdateRaw.toDate();
              } else if (configUpdateRaw is DateTime) {
                lastConfigUpdateTime.value = configUpdateRaw;
              } else if (configUpdateRaw is String) {
                lastConfigUpdateTime.value = DateTime.tryParse(configUpdateRaw);
              }
            }

            // 1. Process Academic Period Mode Swapping
            final remotePeriod =
                data['academic_period']?.toString() ?? 'classes';
            final prefs = await SharedPreferences.getInstance();
            await prefs.setString('active_academic_period', remotePeriod);

            if (remotePeriod != activeAcademicPeriod.value) {
              activeAcademicPeriod.value = remotePeriod;
              debugPrint(
                '⚡ IRIS Remote Engine: Academic Period Swapped to: $remotePeriod',
              );
              IrisHaptics.actionHeavy();

              // Instantly update foreground notification and homescreen widget
              try {
                ClassNotificationTaskHandler().onRepeatEvent(DateTime.now());
              } catch (_) {}

              // Notify user about remote academic mode shift
              if (context.mounted) {
                showIrisFrostedSnackBar(
                  context,
                  content: Text(
                    'Academic mode changed to: ${remotePeriod.toUpperCase()}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  tint: _getModeColor(remotePeriod),
                );
              }
            }

            // 2. Process OTA Timetable Upgrades
            final remoteTimetableVersion =
                (data['active_timetable_version'] as num?)?.toInt() ?? 0;
            final remoteTimetableJson =
                data['active_timetable_json']?.toString() ?? '';

            if (remoteTimetableVersion > 0) {
              if (remoteTimetableVersion.toString().length == 10) {
                lastTimetableUpdateTime.value =
                    DateTime.fromMillisecondsSinceEpoch(
                      remoteTimetableVersion * 1000,
                    );
              } else {
                lastTimetableUpdateTime.value =
                    DateTime.fromMillisecondsSinceEpoch(remoteTimetableVersion);
              }
            }

            if (remoteTimetableJson.isNotEmpty) {
              final prefs = await SharedPreferences.getInstance();
              final currentTimetableVersion =
                  prefs.getInt(TimetableOTAService.prefTimetableVersion) ?? 0;

              if (remoteTimetableVersion > currentTimetableVersion) {
                debugPrint(
                  '📥 IRIS Remote Engine: Downloading remote timetable seed upgrade (v$remoteTimetableVersion)...',
                );
                try {
                  // Validate and parse the raw JSON payload directly
                  final decoded = jsonDecode(remoteTimetableJson);
                  int sessionCount = 0;
                  if (decoded is List) {
                    sessionCount = decoded.length;
                  } else if (decoded is Map && decoded['sessions'] is List) {
                    sessionCount = (decoded['sessions'] as List).length;
                  }

                  final oldJson =
                      prefs.getString(
                        TimetableOTAService.prefCachedTimetable,
                      ) ??
                      '';
                  final userBatch = prefs.getString('user_batch') ?? '';
                  if (oldJson.isNotEmpty && userBatch.isNotEmpty) {
                    final diffs = _calculateTimetableDiffs(
                      oldJson,
                      remoteTimetableJson,
                      userBatch,
                    );
                    if (diffs.isNotEmpty) {
                      await prefs.setString(
                        'ota_timetable_changes',
                        jsonEncode(diffs),
                      );
                    }
                  }

                  // Persist locally
                  await prefs.setString(
                    TimetableOTAService.prefCachedTimetable,
                    remoteTimetableJson,
                  );
                  await prefs.setInt(
                    TimetableOTAService.prefTimetableVersion,
                    remoteTimetableVersion,
                  );
                  await prefs.setInt(
                    TimetableOTAService.prefLastCheckTime,
                    remoteTimetableVersion,
                  );

                  debugPrint(
                    '✅ IRIS Remote Engine: Saved timetable OTA data ($sessionCount sessions)',
                  );

                  if (context.mounted) {
                    showIrisFrostedSnackBar(
                      context,
                      content: const Text(
                        '✅ Remote Timetable sync complete! Rebuilding schedule...',
                      ),
                      tint: const Color(0xFF10B981),
                    );
                  }
                } catch (e) {
                  debugPrint('❌ IRIS Remote Engine: Timetable sync failed: $e');
                }
              }
            }

            // 3. Process Remote APK Update Notifications
            final rawUpdate = data['latest_apk_update'];
            Map<String, dynamic>? updateData;
            if (rawUpdate is Map) {
              updateData = Map<String, dynamic>.from(rawUpdate);
            }
            if (updateData != null && isUpdateEligibleForBanner(updateData, prefs)) {
              latestApkUpdate.value = updateData;
            } else {
              latestApkUpdate.value = null;
            }

            // 4. Process Live Broadcast Announcement Banners
            final broadcastEnabled =
                data['broadcast_enabled'] as bool? ?? false;
            final broadcastMsg = data['broadcast_message']?.toString() ?? '';

            if (broadcastEnabled && broadcastMsg.isNotEmpty) {
              liveAnnouncement.value = {
                'message': broadcastMsg,
                'enabled': broadcastEnabled,
                'updated_at': data['updated_at'] ?? Timestamp.now(),
              };
            } else {
              liveAnnouncement.value = null;
            }

            // 4b. Process Multiple Live Campus Notices from Admin Portal
            final rawNotices = data['campus_notices'] ?? data['broadcast_notices'];
            if (rawNotices is List) {
              final parsed = rawNotices
                  .whereType<Map>()
                  .map((m) => Map<String, dynamic>.from(m))
                  .where((m) => m['enabled'] != false)
                  .toList();
              liveNotices.value = parsed;
              SharedPreferences.getInstance().then((p) {
                p.setString('cached_campus_notices', jsonEncode(parsed));
              });
            } else if (data.containsKey('campus_notices') && rawNotices == null) {
              liveNotices.value = [];
              SharedPreferences.getInstance().then((p) {
                p.remove('cached_campus_notices');
              });
            }

            // 5. Process Midterm and Final term Date Sheets (with automatic self-healing for legacy 2-row uploads)
            final midtermJsonRaw =
                data['active_midterm_json']?.toString() ?? '';
            if (midtermJsonRaw.isNotEmpty && midtermJsonRaw != '[]') {
              try {
                final decoded = jsonDecode(midtermJsonRaw);
                if (decoded is List && isValidExamPayload(decoded)) {
                  midtermExams.value = decoded;
                  SharedPreferences.getInstance().then((prefs) {
                    prefs.setString('cached_midterm_exams', midtermJsonRaw);
                  });
                } else {
                  debugPrint('🛠️ IRIS Remote Engine: Detected incomplete/legacy active_midterm_json in cloud. Healing with bundled Fall 2026 Midterm Date Sheet seed!');
                  final seed = await loadBundledMidtermSeed();
                  if (seed.isNotEmpty) {
                    midtermExams.value = seed;
                    SharedPreferences.getInstance().then((prefs) {
                      prefs.setString('cached_midterm_exams', jsonEncode(seed));
                    });
                  } else if (decoded is List) {
                    midtermExams.value = decoded;
                  }
                }
              } catch (e) {
                debugPrint(
                  '❌ IRIS Remote Engine: Failed to parse active_midterm_json: $e',
                );
              }
            } else {
              final seed = await loadBundledMidtermSeed();
              if (seed.isNotEmpty) {
                midtermExams.value = seed;
              } else {
                midtermExams.value = [];
              }
            }

            final finalsJsonRaw = data['active_finals_json']?.toString() ?? '';
            if (finalsJsonRaw.isNotEmpty) {
              try {
                final decoded = jsonDecode(finalsJsonRaw);
                if (decoded is List) {
                  finalExams.value = decoded;
                  SharedPreferences.getInstance().then((prefs) {
                    prefs.setString('cached_finals_exams', finalsJsonRaw);
                  });
                }
              } catch (e) {
                debugPrint(
                  '❌ IRIS Remote Engine: Failed to parse active_finals_json: $e',
                );
              }
            } else {
              finalExams.value = [];
              SharedPreferences.getInstance().then((prefs) {
                prefs.remove('cached_finals_exams');
              });
            }

            // 6. Process Vacation Schedule & Semester Milestones
            final vacationScheduleRaw = data['vacation_schedule'] ??
                (data['semester_schedule'] is Map ? data['semester_schedule'] : null);
            final semesterMilestonesRaw = data['semester_schedule'] is List
                ? data['semester_schedule']
                : (data['semester_milestones'] is List ? data['semester_milestones'] : null);

            if (vacationScheduleRaw is Map) {
              final parsed = Map<String, dynamic>.from(vacationScheduleRaw);
              vacationSchedule.value = parsed;
              SharedPreferences.getInstance().then((prefs) {
                prefs.setString('cached_vacation_schedule', jsonEncode(parsed));
              });
            } else if (semesterMilestonesRaw is List) {
              final now = DateTime.now();
              final defaultTargetSem = now.month >= 8 ? 'Spring ${now.year + 1}' : 'Fall ${now.year}';
              final parsed = {
                'target_semester': data['target_semester']?.toString() ?? defaultTargetSem,
                'resumption_date': data['resumption_date']?.toString() ?? '',
                'milestones': semesterMilestonesRaw,
              };
              vacationSchedule.value = parsed;
              SharedPreferences.getInstance().then((prefs) {
                prefs.setString('cached_vacation_schedule', jsonEncode(parsed));
              });
            }
          },
          onError: (err) {
            debugPrint('⚠️ IRIS Remote Engine Stream Error: $err');
          },
        );
    } catch (e) {
      debugPrint('⚠️ IRIS Remote Engine: Firebase unavailable ($e)');
    }
  }

  static Color _getModeColor(String period) {
    switch (period) {
      case 'classes':
        return const Color(0xFF3A86FF); // Brand blue
      case 'midterms':
        return const Color(0xFFF59E0B); // Amber
      case 'finals':
        return const Color(0xFFF43F5E); // Rose
      case 'sports_week':
        return const Color(0xFF10B981); // Emerald
      case 'ramadan':
        return const Color(0xFF10B981); // Emerald for Ramadan
      case 'vacation':
      case 'break':
        return const Color(0xFFF43F5E); // Rose/Coral for Vacation
      default:
        return const Color(0xFF3A86FF);
    }
  }

  static List<String> _calculateTimetableDiffs(
    String oldJson,
    String newJson,
    String userBatch,
  ) {
    final List<String> diffs = [];
    try {
      final oldDecoded = jsonDecode(oldJson);
      final newDecoded = jsonDecode(newJson);

      List<dynamic> oldList = [];
      if (oldDecoded is List) {
        oldList = oldDecoded;
      } else if (oldDecoded is Map && oldDecoded['sessions'] is List) {
        oldList = oldDecoded['sessions'] as List;
      }

      List<dynamic> newList = [];
      if (newDecoded is List) {
        newList = newDecoded;
      } else if (newDecoded is Map && newDecoded['sessions'] is List) {
        newList = newDecoded['sessions'] as List;
      }

      final targetBatchLower = userBatch.trim().toLowerCase();

      // Helper to match batch
      bool matchesBatch(dynamic item) {
        if (item is! Map) return false;
        final batchVal =
            (item['batch'] ?? item['class_name'] ?? item['section'] ?? '')
                .toString()
                .trim()
                .toLowerCase();
        return batchVal == targetBatchLower;
      }

      final oldSessions = oldList
          .where(matchesBatch)
          .map((item) => Map<String, dynamic>.from(item as Map))
          .toList();
      final newSessions = newList
          .where(matchesBatch)
          .map((item) => Map<String, dynamic>.from(item as Map))
          .toList();

      // Helpers to identify key fields
      String getDay(Map<String, dynamic> item) =>
          (item['day'] ?? item['weekday'] ?? 'Monday').toString();
      String getSubject(Map<String, dynamic> item) =>
          (item['subject'] ?? item['course'] ?? item['title'] ?? 'Unknown')
              .toString();
      String getRoom(Map<String, dynamic> item) =>
          (item['room'] ?? item['location'] ?? 'TBD').toString();
      String getTeacher(Map<String, dynamic> item) =>
          (item['teacher'] ?? item['instructor'] ?? item['staff'] ?? 'Unknown')
              .toString();
      String getTime(Map<String, dynamic> item) {
        if (item['start'] != null) {
          return '${item['start']}-${item['end']}';
        }
        return (item['time'] ?? item['period'] ?? '00:00').toString();
      }

      // Check for room changes or teacher changes or removed classes
      for (final oldItem in oldSessions) {
        final oldDay = getDay(oldItem);
        final oldTime = getTime(oldItem);
        final oldSubj = getSubject(oldItem);

        // Find match in new sessions
        final match = newSessions.firstWhere(
          (newItem) =>
              getDay(newItem).toLowerCase() == oldDay.toLowerCase() &&
              getTime(newItem).toLowerCase() == oldTime.toLowerCase() &&
              getSubject(newItem).toLowerCase() == oldSubj.toLowerCase(),
          orElse: () => <String, dynamic>{},
        );

        if (match.isEmpty) {
          // Class was removed
          diffs.add('Cancelled class: $oldSubj on $oldDay at $oldTime');
        } else {
          final oldRoom = getRoom(oldItem);
          final newRoom = getRoom(match);
          if (oldRoom.toLowerCase() != newRoom.toLowerCase()) {
            diffs.add(
              'Room changed: $oldSubj now in $newRoom (was $oldRoom) on $oldDay at $oldTime',
            );
          }

          final oldTeach = getTeacher(oldItem);
          final newTeach = getTeacher(match);
          if (oldTeach.toLowerCase() != newTeach.toLowerCase()) {
            diffs.add(
              'Instructor changed: $oldSubj now taught by $newTeach on $oldDay',
            );
          }
        }
      }

      // Check for newly added classes
      for (final newItem in newSessions) {
        final newDay = getDay(newItem);
        final newTime = getTime(newItem);
        final newSubj = getSubject(newItem);

        final exists = oldSessions.any(
          (oldItem) =>
              getDay(oldItem).toLowerCase() == newDay.toLowerCase() &&
              getTime(oldItem).toLowerCase() == newTime.toLowerCase() &&
              getSubject(oldItem).toLowerCase() == newSubj.toLowerCase(),
        );

        if (!exists) {
          final newRoom = getRoom(newItem);
          diffs.add(
            'New class added: $newSubj in $newRoom on $newDay at $newTime',
          );
        }
      }
    } catch (e) {
      debugPrint('⚠️ Failed to calculate timetable diffs: $e');
    }
    return diffs;
  }
}
