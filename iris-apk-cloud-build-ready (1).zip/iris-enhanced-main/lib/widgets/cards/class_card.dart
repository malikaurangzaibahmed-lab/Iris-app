import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/models.dart';
import '../../core/animations.dart';
import '../iris_components.dart';
import '../../screens/academics/room_finder_screen.dart';
import '../../screens/faculty/faculty_directory_screen.dart';
import '../effects/glass_container_transform.dart';
import '../../core/sticker_tokens.dart';
import '../../core/theme_signals.dart';
import '../../core/tokens.dart';
import '../../core/vital_theme.dart';
import '../../services/ui_feedback.dart';
import '../glass_card.dart';
import '../controls/tactile_stationery.dart';
import 'package:iris/widgets/cards/vital_card.dart';

class ClassCard extends StatefulWidget {
  final ClassSession session;
  final ClassSession? nextSession;
  final bool isFacultyView;
  final VoidCallback? onRemoveMakeup;

  const ClassCard({
    super.key,
    required this.session,
    this.nextSession,
    this.isFacultyView = false,
    this.onRemoveMakeup,
  });

  static void showSessionQuickSheet(
    BuildContext context,
    ClassSession session, {
    bool isFacultyView = false,
    VoidCallback? onRemoveMakeup,
  }) {
    IrisHaptics.selectionClick();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;
    final now = DateTime.now();
    final isLive = session.isLive(now);
    final cleanSubject = session.subject.replaceAll('[EXAM]', '').trim();
    const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    final dayLabel = (session.dayIndex >= 1 && session.dayIndex <= 7)
        ? dayNames[session.dayIndex - 1]
        : 'Scheduled Day';

    IrisModalSheet.show(
      context: context,
      builder: (sheetCtx) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(22, 14, 22, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 38,
                  height: 4.5,
                  decoration: BoxDecoration(
                    color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: isLive
                          ? const Color(0xFF10B981).withValues(alpha: 0.16)
                          : (isM3 ? cs.primaryContainer : IrisTokens.brand.withValues(alpha: 0.15)),
                      borderRadius: BorderRadius.circular(99),
                    ),
                    child: Text(
                      isLive ? '● LIVE NOW' : dayLabel.toUpperCase(),
                      style: TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.6,
                        color: isLive
                            ? const Color(0xFF10B981)
                            : (isM3 ? cs.onPrimaryContainer : IrisTokens.brand),
                      ),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    '${session.startTime} – ${session.endTime}',
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w800,
                      color: isDark ? Colors.white70 : Colors.black87,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                cleanSubject,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.3,
                  color: isDark ? Colors.white : const Color(0xFF0F172A),
                ),
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.05),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.08),
                  ),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.location_on_rounded, size: 18, color: Color(0xFF38BDF8)),
                        const SizedBox(width: 10),
                        Text(
                          'Room / Venue:',
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                            color: isDark ? Colors.white60 : Colors.black54,
                          ),
                        ),
                        const Spacer(),
                        Text(
                          session.room,
                          style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w900,
                            color: isDark ? Colors.white : Colors.black87,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        const Icon(Icons.person_rounded, size: 18, color: Color(0xFF8B5CF6)),
                        const SizedBox(width: 10),
                        Text(
                          'Instructor:',
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                            color: isDark ? Colors.white60 : Colors.black54,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            session.teacher,
                            textAlign: TextAlign.right,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 13.5,
                              fontWeight: FontWeight.w800,
                              color: isDark ? Colors.white : Colors.black87,
                            ),
                          ),
                        ),
                      ],
                    ),
                    if (session.batchKey.batch.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          const Icon(Icons.groups_rounded, size: 18, color: Color(0xFF10B981)),
                          const SizedBox(width: 10),
                          Text(
                            'Academic Batch:',
                            style: TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w600,
                              color: isDark ? Colors.white60 : Colors.black54,
                            ),
                          ),
                          const Spacer(),
                          Text(
                            session.batchKey.batch,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                              color: isDark ? Colors.white : Colors.black87,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Navigator.of(sheetCtx).pop();
                        pushGlassContainerMorphRoute(
                          context,
                          page: const RoomFinderScreen(),
                          accentColor: const Color(0xFF00E5FF),
                        );
                      },
                      icon: const Icon(Icons.meeting_room_rounded, size: 16),
                      label: const Text(
                        'Room Radar',
                        style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800),
                      ),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                    ),
                  ),
                  if (onRemoveMakeup != null) ...[
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () {
                          Navigator.of(sheetCtx).pop();
                          onRemoveMakeup();
                        },
                        icon: const Icon(Icons.delete_outline_rounded, size: 16),
                        label: const Text(
                          'Remove Makeup',
                          style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: IrisTokens.error,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 13),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          elevation: 0,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  State<ClassCard> createState() => _ClassCardState();
}

class _ClassCardState extends State<ClassCard> {

  @override
  void initState() {
    super.initState();
  }

  Widget _buildVitalProgress(bool isDark) {
    final now = DateTime.now();
    final currentTime = now.hour + (now.minute / 60.0);
    final duration = LectureDuration.getActualDuration(widget.session);
    final actualEndTime = LectureDuration.getActualEndTime(widget.session);
    final progress = ((currentTime - widget.session.safeStartVal) / duration).clamp(0.0, 1.0);
    final minutesLeft = ((actualEndTime - currentTime) * 60).toInt().clamp(0, (duration * 60).toInt());

    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(99),
          child: Container(
            height: 10,
            width: double.infinity,
            decoration: BoxDecoration(
              color: isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.05),
            ),
            child: FractionallySizedBox(
              alignment: Alignment.centerLeft,
              widthFactor: progress,
              child: Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [VitalTokens.green, Color(0xFF2E7D32)],
                  ),
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              '${(progress * 100).toInt()}% COMPLETED',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.5),
                letterSpacing: 0.5,
              ),
            ),
            Text(
              '${minutesLeft}M LEFT',
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w900,
                color: VitalTokens.green,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildM3Progress(ColorScheme cs) {
    final now = DateTime.now();
    final currentTime = now.hour + (now.minute / 60.0);
    final duration = LectureDuration.getActualDuration(widget.session);
    final actualEndTime = LectureDuration.getActualEndTime(widget.session);
    final progress = ((currentTime - widget.session.safeStartVal) / duration).clamp(0.0, 1.0);
    final minutesLeft = ((actualEndTime - currentTime) * 60).toInt().clamp(0, (duration * 60).toInt());

    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(999),
          child: Container(
            height: 8,
            width: double.infinity,
            decoration: BoxDecoration(
              color: cs.onPrimaryContainer.withValues(alpha: 0.15),
            ),
            child: FractionallySizedBox(
              alignment: Alignment.centerLeft,
              widthFactor: progress,
              child: Container(
                decoration: BoxDecoration(
                  color: cs.primary,
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              '${(progress * 100).toInt()}% COMPLETED',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: cs.onPrimaryContainer.withValues(alpha: 0.75),
                letterSpacing: 0.6,
              ),
            ),
            Text(
              '${minutesLeft}M LEFT',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w900,
                color: cs.primary,
                letterSpacing: 0.6,
              ),
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final now = DateTime.now();
    final live = widget.session.isLive(now);
    final currentTime = now.hour + (now.minute / 60.0);
    final isUpcoming =
        !live &&
        widget.session.dayIndex == now.weekday &&
        widget.session.safeStartVal > currentTime &&
        widget.session.safeStartVal - currentTime <= 0.75;
    final isCompleted =
        widget.session.dayIndex == now.weekday &&
        currentTime > LectureDuration.getActualEndTime(widget.session);

    final timeLabel = '${widget.session.startTime} - ${widget.session.endTime}';
    final accentColor = live
        ? IrisTokens.success
        : isUpcoming
        ? IrisTokens.brand
        : IrisTokens.purple;
    final textPrimary = isDark ? Colors.white : IrisTokens.surfaceDark;
    final textSecondary = (isDark ? Colors.white : Colors.black).withValues(
      alpha: 0.68,
    );
    final isMakeup = widget.session.id.startsWith('makeup_') || widget.onRemoveMakeup != null;

    return ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, themeStyle, _) {
        final isM3 = themeStyle == IrisThemeStyle.materialYou;
        final cs = Theme.of(context).colorScheme;

        if (isM3) {
          final cleanSubject = widget.session.subject.replaceAll('[EXAM]', '').trim();
          final isExamSession = widget.session.subject.contains('[EXAM]');
          final Color m3Bg = live
              ? cs.primaryContainer
              : (isUpcoming
                  ? cs.secondaryContainer.withValues(alpha: isDark ? 0.55 : 0.70)
                  : cs.surfaceContainer);

          final Border m3Border = Border.all(
            color: live
                ? cs.primary.withValues(alpha: 0.55)
                : cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55),
            width: live ? 1.5 : 1.0,
          );

          final Color titleColor = live ? cs.onPrimaryContainer : cs.onSurface;
          final Color metaColor = live ? cs.onPrimaryContainer.withValues(alpha: 0.82) : cs.onSurfaceVariant;
          final Color chipBg = live
              ? cs.onPrimaryContainer.withValues(alpha: 0.10)
              : cs.surfaceContainerHighest;

          return RepaintBoundary(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
              child: Opacity(
                opacity: isCompleted ? 0.72 : 1.0,
                child: ExpressiveInteractivePress(
                  pressedScale: 0.985,
                  onTap: () => ClassCard.showSessionQuickSheet(context, widget.session, isFacultyView: widget.isFacultyView, onRemoveMakeup: widget.onRemoveMakeup),
                  child: Container(
                  decoration: BoxDecoration(
                    color: m3Bg,
                    borderRadius: BorderRadius.circular(24),
                    border: m3Border,
                  ),
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Text(
                              cleanSubject,
                              style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w800,
                                height: 1.24,
                                letterSpacing: -0.2,
                                color: titleColor,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          if (isMakeup) ...[
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: cs.errorContainer,
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.event_repeat_rounded, size: 11, color: cs.onErrorContainer),
                                  const SizedBox(width: 4),
                                  Text(
                                    'MAKEUP',
                                    style: TextStyle(
                                      fontSize: 9.5,
                                      fontWeight: FontWeight.w800,
                                      color: cs.onErrorContainer,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            if (widget.onRemoveMakeup != null) ...[
                              const SizedBox(width: 4),
                              IconButton(
                                icon: const Icon(Icons.delete_outline_rounded, size: 18),
                                color: cs.error,
                                tooltip: 'Remove makeup class',
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                                onPressed: () {
                                  IrisHaptics.actionMedium();
                                  widget.onRemoveMakeup!();
                                },
                              ),
                            ],
                          ] else if (live) ...[
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: cs.primary,
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Container(
                                    width: 6,
                                    height: 6,
                                    decoration: BoxDecoration(
                                      color: cs.onPrimary,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                  const SizedBox(width: 5),
                                  Text(
                                    'LIVE',
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w800,
                                      color: cs.onPrimary,
                                      letterSpacing: 0.6,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ] else if (isUpcoming) ...[
                            Builder(
                              builder: (context) {
                                final mins = ((widget.session.safeStartVal - currentTime) * 60).toInt();
                                return Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: cs.tertiaryContainer,
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                  child: Text(
                                    'IN ${mins}M',
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w800,
                                      color: cs.onTertiaryContainer,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                              color: chipBg,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.schedule_rounded,
                                  size: 13,
                                  color: metaColor,
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  timeLabel,
                                  style: TextStyle(
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w600,
                                    color: metaColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                              color: live ? chipBg : cs.secondaryContainer.withValues(alpha: 0.7),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.location_on_outlined,
                                  size: 13,
                                  color: live ? metaColor : cs.onSecondaryContainer,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  isExamSession ? 'Hall ${widget.session.room}' : widget.session.room,
                                  style: TextStyle(
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w700,
                                    color: live ? metaColor : cs.onSecondaryContainer,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              widget.isFacultyView
                                  ? widget.session.batchKey.batch
                                  : (isExamSession
                                      ? 'Invigilator: ${widget.session.teacher}'
                                      : widget.session.teacher),
                              textAlign: TextAlign.right,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: metaColor,
                              ),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ),
                        ],
                      ),
                      if (live) ...[
                        const SizedBox(height: 14),
                        _buildM3Progress(cs),
                      ],
                    ],
                  ),
                ),
                ),
              ),
            ),
          );
        }

        return ValueListenableBuilder<bool>(
          valueListenable: ThemeSignals.useVitalTheme,
          builder: (context, useVital, _) {
            final cleanSubject = widget.session.subject.replaceAll('[EXAM]', '').trim();
            final metaTeacherOrBatch = widget.isFacultyView
                ? widget.session.batchKey.batch
                : (widget.session.subject.contains('[EXAM]')
                    ? 'Invigilator: ${widget.session.teacher}'
                    : widget.session.teacher);
            final metaRoom = widget.session.subject.contains('[EXAM]')
                ? 'Hall: ${widget.session.room}'
                : widget.session.room;

            if (themeStyle == IrisThemeStyle.almanac) {
              final ink = isDark ? const Color(0xFFF4EFE6) : const Color(0xFF14110D);
              final paper = live
                  ? (isDark ? const Color(0xFF282018) : const Color(0xFFEDE4D3))
                  : (isDark ? const Color(0xFF1E1B16) : const Color(0xFFF6F1E7));
              final rule = isDark ? const Color(0xFFD6CEC2) : const Color(0xFF14110D);
              final crimson = isDark ? const Color(0xFFE05A47) : const Color(0xFF9E2A2B);
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                child: Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: paper,
                    border: Border.all(color: live ? crimson : rule, width: live ? 2.0 : 1.2),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            timeLabel.toUpperCase(),
                            style: GoogleFonts.spaceMono(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.0,
                              color: live ? crimson : ink.withValues(alpha: 0.75),
                            ),
                          ),
                          if (live)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              color: crimson,
                              child: Text(
                                'IN SESSION',
                                style: GoogleFonts.spaceMono(
                                  fontSize: 9.5,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white,
                                ),
                              ),
                            )
                          else if (isMakeup)
                            Text(
                              '[MAKEUP]',
                              style: GoogleFonts.spaceMono(
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                                color: crimson,
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        cleanSubject,
                        style: GoogleFonts.playfairDisplay(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          height: 1.2,
                          color: ink,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Divider(height: 1, thickness: 0.8, color: rule.withValues(alpha: 0.35)),
                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'ROOM: $metaRoom',
                            style: GoogleFonts.spaceMono(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: ink,
                            ),
                          ),
                          Flexible(
                            child: Text(
                              metaTeacherOrBatch,
                              style: GoogleFonts.sourceSerif4(
                                fontSize: 12.5,
                                fontStyle: FontStyle.italic,
                                fontWeight: FontWeight.w600,
                                color: ink.withValues(alpha: 0.85),
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            }

            if (themeStyle == IrisThemeStyle.editorialAcademic) {
              final bg = live
                  ? (isDark ? const Color(0xFFF3EFE6) : const Color(0xFF1B2A4A))
                  : (isDark ? const Color(0xFF1A1E26) : const Color(0xFFFFFFFF));
              final fg = live
                  ? (isDark ? const Color(0xFF181613) : const Color(0xFFFDFBF7))
                  : (isDark ? const Color(0xFFF3EFE6) : const Color(0xFF181613));
              final accent = isDark ? const Color(0xFFC25E4C) : const Color(0xFF1B2A4A);
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: bg,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: fg.withValues(alpha: 0.14),
                      width: 1.0,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.05),
                        blurRadius: 14,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            timeLabel,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.8,
                              color: live ? fg.withValues(alpha: 0.85) : accent,
                            ),
                          ),
                          if (live)
                            Text(
                              '• CURRENT LECTURE',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 10,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 1.1,
                                color: fg,
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        cleanSubject,
                        style: GoogleFonts.fraunces(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          height: 1.22,
                          color: fg,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            metaRoom,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w700,
                              color: fg.withValues(alpha: 0.9),
                            ),
                          ),
                          Flexible(
                            child: Text(
                              metaTeacherOrBatch,
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w600,
                                color: fg.withValues(alpha: 0.72),
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            }

            if (themeStyle == IrisThemeStyle.notebook) {
              final paper = live
                  ? (isDark ? const Color(0xFF332D1A) : const Color(0xFFFEF08A))
                  : (isDark ? const Color(0xFF232938) : const Color(0xFFFFFBEB));
              final ink = isDark ? const Color(0xFFE2E8F0) : const Color(0xFF1E293B);
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                child: Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: paper,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: isDark ? const Color(0xFF475569) : const Color(0xFF94A3B8),
                      width: 1.5,
                    ),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x22000000),
                        offset: Offset(3, 4),
                        blurRadius: 0,
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            timeLabel,
                            style: GoogleFonts.spaceMono(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: const Color(0xFFEF4444),
                            ),
                          ),
                          if (live)
                            Text(
                              '★ HAPPENING NOW',
                              style: GoogleFonts.kalam(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: const Color(0xFF16A34A),
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        cleanSubject,
                        style: GoogleFonts.kalam(
                          fontSize: 19,
                          fontWeight: FontWeight.w700,
                          height: 1.2,
                          color: ink,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            '📍 $metaRoom',
                            style: GoogleFonts.patrickHand(
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                              color: ink,
                            ),
                          ),
                          Flexible(
                            child: Text(
                              metaTeacherOrBatch,
                              style: GoogleFonts.patrickHand(
                                fontSize: 14.5,
                                fontWeight: FontWeight.w600,
                                color: ink.withValues(alpha: 0.8),
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            }

            if (themeStyle == IrisThemeStyle.line) {
              final bg = isDark ? const Color(0xFF141C2B) : const Color(0xFFFFFFFF);
              final fg = isDark ? const Color(0xFFF8FAFC) : const Color(0xFF0F172A);
              final lineColor = live
                  ? const Color(0xFF10B981)
                  : (isUpcoming ? const Color(0xFFF59E0B) : const Color(0xFF0284C7));
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                child: Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: bg,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: live ? lineColor : fg.withValues(alpha: 0.16),
                      width: live ? 2.4 : 1.4,
                    ),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        children: [
                          Container(
                            width: 14,
                            height: 14,
                            decoration: BoxDecoration(
                              color: lineColor,
                              shape: BoxShape.circle,
                              border: Border.all(color: bg, width: 2.5),
                            ),
                          ),
                          Container(
                            width: 3,
                            height: 44,
                            color: lineColor.withValues(alpha: 0.45),
                          ),
                        ],
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  timeLabel,
                                  style: GoogleFonts.spaceMono(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: lineColor,
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: lineColor.withValues(alpha: 0.14),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    metaRoom,
                                    style: GoogleFonts.spaceMono(
                                      fontSize: 10.5,
                                      fontWeight: FontWeight.w700,
                                      color: lineColor,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text(
                              cleanSubject,
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 16.5,
                                fontWeight: FontWeight.w800,
                                color: fg,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              metaTeacherOrBatch,
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w600,
                                color: fg.withValues(alpha: 0.68),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }

            if (themeStyle == IrisThemeStyle.poster) {
              final bg = live
                  ? const Color(0xFFFF451A)
                  : (isDark ? const Color(0xFF161616) : const Color(0xFFFFFFFF));
              final fg = live
                  ? Colors.white
                  : (isDark ? Colors.white : Colors.black);
              final borderCol = isDark ? Colors.white : Colors.black;
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                child: Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: bg,
                    border: Border.all(color: borderCol, width: 2.8),
                    boxShadow: [
                      BoxShadow(
                        color: borderCol,
                        offset: const Offset(5, 5),
                        blurRadius: 0,
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            color: live ? Colors.black : const Color(0xFFFF451A),
                            child: Text(
                              timeLabel.toUpperCase(),
                              style: GoogleFonts.spaceMono(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                            ),
                          ),
                          Text(
                            metaRoom.toUpperCase(),
                            style: GoogleFonts.spaceMono(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w700,
                              color: fg,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        cleanSubject.toUpperCase(),
                        style: GoogleFonts.archivoBlack(
                          fontSize: 17,
                          height: 1.15,
                          color: fg,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        metaTeacherOrBatch.toUpperCase(),
                        style: GoogleFonts.spaceMono(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: fg.withValues(alpha: 0.82),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }

            if (useVital && currentStyle != IrisThemeStyle.fluidGlass) {
              final liveBg = isDark ? const Color(0xFF0F3822) : const Color(0xFFE8F5E9);
              final liveText = isDark ? const Color(0xFFA3F0C4) : const Color(0xFF14532D);
              final liveBorder = isDark ? const Color(0xFF166534) : const Color(0xFFA5D6A7);
              final liveChipBg = isDark ? const Color(0xFF15442A) : const Color(0xFFC8E6C9);

              final upcomingBg = isDark ? const Color(0xFF141418) : const Color(0xFFF1F5F9);
              final upcomingText = isDark ? const Color(0xFFE4E4E7) : const Color(0xFF18181B);
              final upcomingBorder = isDark ? const Color(0xFF3F3F46) : const Color(0xFFCBD5E1);
              final upcomingChipBg = isDark ? const Color(0xFF27272A) : const Color(0xFFE2E8F0);

              final cardBg = live
                  ? liveBg
                  : isUpcoming
                      ? upcomingBg
                      : (isDark ? const Color(0xFF0E0E12) : const Color(0xFFFFFFFF));

              final cardBorder = live
                  ? Border.all(color: liveBorder, width: 1.5)
                  : isUpcoming
                      ? Border.all(color: upcomingBorder, width: 1.5)
                      : Border.all(color: isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.06), width: 1.0);

          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
            child: VitalCard(
              animate: false,
              backgroundColor: isCompleted
                  ? cardBg.withValues(alpha: isDark ? 0.65 : 0.75)
                  : cardBg,
                border: cardBorder,
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Top Row: Subject Title + Action / Status Badges
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Text(
                            widget.session.subject,
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                              height: 1.25,
                              color: live
                                  ? liveText
                                  : isUpcoming
                                      ? upcomingText
                                      : textPrimary,
                              decoration: null,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        if (isMakeup) ...[
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: IrisTokens.warning.withValues(alpha: 0.18),
                              borderRadius: BorderRadius.circular(99),
                              border: Border.all(color: IrisTokens.warning.withValues(alpha: 0.4), width: 1),
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.event_repeat_rounded, size: 10, color: IrisTokens.warning),
                                SizedBox(width: 4),
                                Text(
                                  'MAKEUP',
                                  style: TextStyle(
                                    fontSize: 9,
                                    fontWeight: FontWeight.w900,
                                    color: IrisTokens.warning,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          if (widget.onRemoveMakeup != null) ...[
                            const SizedBox(width: 4),
                            IconButton(
                              icon: const Icon(Icons.delete_outline_rounded, size: 18),
                              color: IrisTokens.error,
                              tooltip: 'Remove makeup class',
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                              onPressed: () {
                                IrisHaptics.actionMedium();
                                widget.onRemoveMakeup!();
                              },
                            ),
                          ],
                        ] else if (live) ...[
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: liveChipBg,
                              borderRadius: BorderRadius.circular(99),
                              border: Border.all(color: liveBorder, width: 1),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  width: 7,
                                  height: 7,
                                  decoration: BoxDecoration(
                                    color: liveText,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  'LIVE',
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w900,
                                    color: liveText,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ] else if (isUpcoming) ...[
                          Builder(
                            builder: (context) {
                              final mins = ((widget.session.safeStartVal - currentTime) * 60).toInt();
                              return Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: upcomingChipBg,
                                  borderRadius: BorderRadius.circular(99),
                                  border: Border.all(color: upcomingBorder, width: 1),
                                ),
                                child: Text(
                                  'IN ${mins}M',
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w900,
                                    color: upcomingText,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              );
                            },
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 12),
                    // Bottom Metadata Row: Time Capsule + Room + Teacher
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: live
                                ? liveChipBg
                                : isUpcoming
                                    ? upcomingChipBg
                                    : (isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.05)),
                            borderRadius: BorderRadius.circular(VitalTokens.radiusFull),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.schedule_rounded, size: 12, color: live ? liveText : (isUpcoming ? upcomingText : textSecondary)),
                              const SizedBox(width: 5),
                              Text(
                                timeLabel,
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  color: live ? liveText : (isUpcoming ? upcomingText : textSecondary),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Row(
                          children: [
                            Icon(Icons.location_on_rounded, size: 14, color: (live ? liveText : (isUpcoming ? upcomingText : accentColor)).withValues(alpha: 0.8)),
                            const SizedBox(width: 4),
                            Text(
                              widget.session.room,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                                color: live ? liveText : (isUpcoming ? upcomingText : textPrimary),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(width: 8),
                        Flexible(
                          child: Text(
                            widget.isFacultyView ? widget.session.batchKey.batch : widget.session.teacher,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: live ? liveText.withValues(alpha: 0.85) : (isUpcoming ? upcomingText.withValues(alpha: 0.85) : textSecondary),
                            ),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                        ),
                      ],
                    ),
                    if (live) ...[
                      const SizedBox(height: 20),
                      _buildVitalProgress(isDark),
                    ],
                  ],
                ),
              ),
            );
          }

        // Legacy GlassCard
        return RepaintBoundary(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
            child: GlassCard(
              onTap: () => ClassCard.showSessionQuickSheet(context, widget.session, isFacultyView: widget.isFacultyView, onRemoveMakeup: widget.onRemoveMakeup),
              glow: live,
              shimmer: false,
              enableBlur: true,
              enableShadow: true,
              enableOverlay: true,
              backgroundColor: live
                  ? (isDark ? const Color(0xFF0B3B28).withValues(alpha: 0.78) : const Color(0xFFECFDF5).withValues(alpha: 0.88))
                  : null,
              padding: const EdgeInsets.all(20),
              borderRadius: 32.0,
              elevation: live ? 4 : (isUpcoming ? 3 : 2),
              accentColor: accentColor,
              border: live
                  ? Border.all(
                      color: IrisTokens.success.withValues(alpha: 0.45),
                      width: 1.5,
                    )
                  : isUpcoming
                      ? Border.all(
                          color: isDark ? Colors.white24 : IrisTokens.brand.withValues(alpha: 0.3),
                          width: 1.2,
                        )
                      : Border.all(
                          color: isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.06),
                          width: 1.0,
                        ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                        // Top Row: Subject Title + Status Badges
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Text(
                                widget.session.subject.replaceAll('[EXAM]', '').trim(),
                                style: IrisTextStyles.classSubject(context).copyWith(
                                  fontSize: 17,
                                  height: 1.25,
                                  color: widget.session.subject.contains('[EXAM]')
                                      ? (isDark ? const Color(0xFFFBBF24) : const Color(0xFFD97706))
                                      : (live ? IrisTokens.success : textPrimary),
                                  decoration: null,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            if (widget.session.subject.contains('[EXAM]')) ...[
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFF59E0B).withValues(alpha: 0.18),
                                  borderRadius: BorderRadius.circular(99),
                                  border: Border.all(color: const Color(0xFFF59E0B).withValues(alpha: 0.4), width: 1),
                                ),
                                child: const Text(
                                  '✍️ EXAM PAPER',
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w900,
                                    color: Color(0xFFD97706),
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ),
                            ] else if (isMakeup) ...[
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: IrisTokens.warning.withValues(alpha: 0.18),
                                  borderRadius: BorderRadius.circular(99),
                                  border: Border.all(color: IrisTokens.warning.withValues(alpha: 0.4), width: 1),
                                ),
                                child: const Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(Icons.event_repeat_rounded, size: 10, color: IrisTokens.warning),
                                    SizedBox(width: 4),
                                    Text(
                                      'MAKEUP',
                                      style: TextStyle(
                                        fontSize: 9,
                                        fontWeight: FontWeight.w900,
                                        color: IrisTokens.warning,
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              if (widget.onRemoveMakeup != null) ...[
                                const SizedBox(width: 4),
                                IconButton(
                                  icon: const Icon(Icons.delete_outline_rounded, size: 18),
                                  color: IrisTokens.error,
                                  tooltip: 'Remove makeup class',
                                  padding: EdgeInsets.zero,
                                  constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                                  onPressed: () {
                                    IrisHaptics.actionMedium();
                                    widget.onRemoveMakeup!();
                                  },
                                ),
                              ],
                            ] else if (live) ...[
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                decoration: BoxDecoration(
                                  color: IrisTokens.success.withValues(alpha: 0.15),
                                  borderRadius: BorderRadius.circular(99),
                                  border: Border.all(color: IrisTokens.success.withValues(alpha: 0.3), width: 1),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      width: 6,
                                      height: 6,
                                      decoration: BoxDecoration(
                                        color: IrisTokens.success,
                                        shape: BoxShape.circle,
                                      ),
                                    ),
                                    const SizedBox(width: 5),
                                    Text(
                                      'LIVE',
                                      style: TextStyle(
                                        fontSize: 10,
                                        fontWeight: FontWeight.w900,
                                        color: IrisTokens.success,
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ] else if (isUpcoming) ...[
                              Builder(
                                builder: (context) {
                                  final mins = ((widget.session.safeStartVal - currentTime) * 60).toInt();
                                  return Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                    decoration: BoxDecoration(
                                      color: IrisTokens.brand.withValues(alpha: 0.15),
                                      borderRadius: BorderRadius.circular(99),
                                      border: Border.all(color: IrisTokens.brand.withValues(alpha: 0.3), width: 1),
                                    ),
                                    child: Text(
                                      'IN ${mins}M',
                                      style: TextStyle(
                                        fontSize: 10,
                                        fontWeight: FontWeight.w900,
                                        color: IrisTokens.brand,
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ],
                        ),
                        const SizedBox(height: 14),
                        // Metadata Row: Time Capsule + Room + Teacher
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 5,
                              ),
                              decoration: BoxDecoration(
                                color: live
                                    ? IrisTokens.brand.withValues(alpha: 0.85)
                                    : (isDark ? Colors.white.withValues(alpha: 0.12) : Colors.black.withValues(alpha: 0.08)),
                                borderRadius: BorderRadius.circular(99),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.schedule_rounded, size: 12, color: live ? Colors.white : textSecondary),
                                  const SizedBox(width: 5),
                                  Text(
                                    timeLabel,
                                    style: IrisTextStyles.badgeText(context).copyWith(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w800,
                                      color: live ? Colors.white : textSecondary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),
                            Row(
                              children: [
                                Icon(
                                  widget.session.subject.contains('[EXAM]')
                                      ? Icons.account_balance_rounded
                                      : Icons.location_on_rounded,
                                  size: 15,
                                  color: widget.session.subject.contains('[EXAM]')
                                      ? const Color(0xFFF59E0B)
                                      : (live ? IrisTokens.success : textSecondary.withValues(alpha: 0.6)),
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  widget.session.subject.contains('[EXAM]')
                                      ? 'Hall: ${widget.session.room}'
                                      : widget.session.room,
                                  style: IrisTextStyles.classSessionMeta(context).copyWith(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    color: textPrimary.withValues(alpha: 0.85),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(width: 8),
                            Flexible(
                              child: Text(
                                widget.isFacultyView
                                    ? widget.session.batchKey.batch
                                    : (widget.session.subject.contains('[EXAM]')
                                        ? 'Invigilator: ${widget.session.teacher}'
                                        : widget.session.teacher),
                                style: IrisTextStyles.metaInfo(context).copyWith(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: widget.session.subject.contains('[EXAM]')
                                      ? (isDark ? const Color(0xFFCBD5E1) : const Color(0xFF334155))
                                      : textSecondary.withValues(alpha: 0.7),
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),

                        if (live &&
                            widget.nextSession != null &&
                            widget.nextSession!.dayIndex ==
                                widget.session.dayIndex) ...[
                          const SizedBox(height: 16),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 9,
                            ),
                            decoration: BoxDecoration(
                              color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.04),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.06),
                                width: 0.8,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.keyboard_arrow_right_rounded,
                                  size: 16,
                                  color: textSecondary.withValues(alpha: 0.5),
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  'Next: ${widget.nextSession!.room}',
                                  style: IrisTextStyles.badgeText(context).copyWith(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.2,
                                    color: textSecondary.withValues(alpha: 0.8),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],

                        if (live) ...[
                          const SizedBox(height: 22),
                          Builder(
                            builder: (context) {
                              final currentTime = now.hour + (now.minute / 60.0);
                              final duration = LectureDuration.getActualDuration(widget.session);
                              final actualEndTime = LectureDuration.getActualEndTime(widget.session);
                              final progress = ((currentTime - widget.session.safeStartVal) / duration).clamp(0.0, 1.0);
                              final minutesLeft = ((actualEndTime - currentTime) * 60).toInt().clamp(0, (duration * 60).toInt());

                              return Column(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(99),
                                    child: Container(
                                      height: 8,
                                      width: double.infinity,
                                      decoration: BoxDecoration(
                                        color: isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.05),
                                      ),
                                      child: FractionallySizedBox(
                                        alignment: Alignment.centerLeft,
                                        widthFactor: progress,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            gradient: LinearGradient(
                                              colors: [IrisTokens.success, IrisTokens.successDark],
                                            ),
                                            borderRadius: BorderRadius.circular(99),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        '${(progress * 100).toInt()}% Done',
                                        style: IrisTextStyles.classProgress(context).copyWith(
                                          color: textSecondary.withValues(alpha: 0.6),
                                        ),
                                      ),
                                      Text(
                                        '${minutesLeft}m left',
                                        style: IrisTextStyles.classProgress(context).copyWith(
                                          fontWeight: FontWeight.w800,
                                          color: IrisTokens.success,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              );
                            },
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              );
      },
    );
      },
    );
  }
}

