import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/models.dart';
import '../../core/animations.dart';
import '../../core/theme_signals.dart';
import '../../core/tokens.dart';
import '../../core/sticker_tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../glass_card.dart';

enum ContextualTimelineStatusKind {
  live,
  urgentStarting,
  intervalBreak,
  doneForTodayTomorrowHasClasses,
  doneForTodayMultiDayGap,
  weekendBreak,
  freeDay,
  futureDayPreview,
}

class ContextualTimelineState {
  final ContextualTimelineStatusKind kind;
  final String headline;
  final String subline;
  final String badgeText;
  final ClassSession? targetSession;
  final int daysAhead;
  final int minutesRemaining;
  final int minutesUntil;
  final String room;

  const ContextualTimelineState({
    required this.kind,
    required this.headline,
    required this.subline,
    required this.badgeText,
    this.targetSession,
    this.daysAhead = 0,
    this.minutesRemaining = 0,
    this.minutesUntil = 0,
    this.room = '',
  });

  static const List<String> _weekdayNames = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday',
  ];

  static String weekdayName(int index) {
    if (index < 1 || index > 7) return 'Day';
    return _weekdayNames[index - 1];
  }

  /// Evaluates schedule state across today and upcoming days with high precision
  static ContextualTimelineState resolve({
    required DateTime now,
    required int activeDayIndex,
    required List<ClassSession> todaySessions,
    required ClassSession? currentClass,
    required ClassSession? nextClass,
    required bool isFaculty,
    String? teacherName,
    String? batch,
  }) {
    final double currentTime = now.hour + (now.minute / 60.0);
    final isViewingToday = activeDayIndex == now.weekday;

    // 1. If viewing another day
    if (!isViewingToday) {
      final dayName = weekdayName(activeDayIndex);
      if (todaySessions.isEmpty) {
        return ContextualTimelineState(
          kind: ContextualTimelineStatusKind.freeDay,
          headline: 'NO CLASSES ON ${dayName.toUpperCase()}',
          subline: 'Academic registry is free · Campus library & study halls open',
          badgeText: 'FREE DAY',
        );
      }
      final first = todaySessions.first;
      final partner = isFaculty
          ? (first.isCombinedLecture ? '[COMBINED] ${first.displayBatch}' : first.displayBatch)
          : first.teacher;
      return ContextualTimelineState(
        kind: ContextualTimelineStatusKind.futureDayPreview,
        headline: '${todaySessions.length} ${todaySessions.length == 1 ? "LECTURE" : "LECTURES"} ON ${dayName.toUpperCase()}',
        subline: 'First session at ${first.startTime} in Room ${first.room} ($partner)',
        badgeText: '${first.startTime} START',
        targetSession: first,
        room: first.room,
      );
    }

    // 2. Active Live Lecture
    if (currentClass != null && currentClass.isLive(now)) {
      final double endVal = currentClass.actualEndVal;
      final int minsLeft = ((endVal - currentTime) * 60).clamp(0, 360).round();
      final partner = isFaculty
          ? (currentClass.isCombinedLecture ? '[COMBINED] ${currentClass.displayBatch}' : currentClass.displayBatch)
          : currentClass.teacher;
      return ContextualTimelineState(
        kind: ContextualTimelineStatusKind.live,
        headline: 'NOW IN SESSION · ${currentClass.subject.toUpperCase()}',
        subline: 'Room ${currentClass.room} · $partner',
        badgeText: 'ENDS IN ${minsLeft}M',
        targetSession: currentClass,
        minutesRemaining: minsLeft,
        room: currentClass.room,
      );
    }

    // 3. Next Lecture is later today
    if (nextClass != null && nextClass.dayIndex == now.weekday && nextClass.safeStartVal > currentTime) {
      final double startVal = nextClass.safeStartVal;
      final int minsUntil = ((startVal - currentTime) * 60).clamp(0, 1440).round();
      final partner = isFaculty
          ? (nextClass.isCombinedLecture ? '[COMBINED] ${nextClass.displayBatch}' : nextClass.displayBatch)
          : nextClass.teacher;

      if (minsUntil <= 15) {
        return ContextualTimelineState(
          kind: ContextualTimelineStatusKind.urgentStarting,
          headline: 'STARTING IN ${minsUntil}M · PROCEED TO ROOM ${nextClass.room}',
          subline: '${nextClass.subject} · $partner',
          badgeText: 'IN ${minsUntil}M ⚡',
          targetSession: nextClass,
          minutesUntil: minsUntil,
          room: nextClass.room,
        );
      }

      final int h = minsUntil ~/ 60;
      final int m = minsUntil % 60;
      final intervalStr = h > 0 ? '${h}h ${m}m' : '${m}m';
      return ContextualTimelineState(
        kind: ContextualTimelineStatusKind.intervalBreak,
        headline: 'NEXT LECTURE AT ${nextClass.startTime} (${nextClass.room})',
        subline: '${nextClass.subject} · $partner',
        badgeText: '$intervalStr BREAK',
        targetSession: nextClass,
        minutesUntil: minsUntil,
        room: nextClass.room,
      );
    }

    // 4. Classes for today completed or none left today -> compute upcoming day gap
    if (nextClass != null && nextClass.dayIndex != now.weekday) {
      var daysAhead = (nextClass.dayIndex - now.weekday + 7) % 7;
      if (daysAhead == 0) daysAhead = 7;
      final targetDayName = weekdayName(nextClass.dayIndex);
      final partner = isFaculty
          ? (nextClass.isCombinedLecture ? '[COMBINED] ${nextClass.displayBatch}' : nextClass.displayBatch)
          : nextClass.teacher;

      // Weekend condition
      if (now.weekday == DateTime.friday && daysAhead >= 2) {
        return ContextualTimelineState(
          kind: ContextualTimelineStatusKind.weekendBreak,
          headline: 'WEEKEND BREAK AHEAD 🏖️',
          subline: 'Classes resume Monday at ${nextClass.startTime} in Room ${nextClass.room} ($partner)',
          badgeText: 'WEEKEND BREAK',
          targetSession: nextClass,
          daysAhead: daysAhead,
          room: nextClass.room,
        );
      }

      if (daysAhead == 1) {
        return ContextualTimelineState(
          kind: ContextualTimelineStatusKind.doneForTodayTomorrowHasClasses,
          headline: 'ALL CLASSES DONE FOR TODAY ✨',
          subline: 'Next class tomorrow at ${nextClass.startTime} in Room ${nextClass.room} (${nextClass.subject})',
          badgeText: 'TOMORROW ⚡',
          targetSession: nextClass,
          daysAhead: 1,
          room: nextClass.room,
        );
      }

      return ContextualTimelineState(
        kind: ContextualTimelineStatusKind.doneForTodayMultiDayGap,
        headline: 'DONE FOR TODAY · $targetDayName NEXT',
        subline: 'Next class in $daysAhead days on $targetDayName at ${nextClass.startTime} (${nextClass.room})',
        badgeText: 'IN $daysAhead DAYS',
        targetSession: nextClass,
        daysAhead: daysAhead,
        room: nextClass.room,
      );
    }

    // 5. Today sessions ended with no further classes in week
    if (todaySessions.isNotEmpty && currentTime >= todaySessions.last.actualEndVal) {
      return const ContextualTimelineState(
        kind: ContextualTimelineStatusKind.doneForTodayTomorrowHasClasses,
        headline: 'ALL SESSIONS CONCLUDED FOR THE WEEK 🎉',
        subline: 'Enjoy your evening! Campus facilities & online portals remain available.',
        badgeText: 'ALL DONE',
      );
    }

    // 6. Default Free Day / Weekend
    final isWeekend = now.weekday >= DateTime.saturday;
    if (isWeekend) {
      return const ContextualTimelineState(
        kind: ContextualTimelineStatusKind.weekendBreak,
        headline: 'WEEKEND BREAK 🏖️',
        subline: 'No classes in registry. Recharge and prepare for the coming week.',
        badgeText: 'WEEKEND',
      );
    }

    return const ContextualTimelineState(
      kind: ContextualTimelineStatusKind.freeDay,
      headline: 'ALL CLEAR FOR TODAY ✨',
      subline: 'No scheduled lectures on the timetable. Enjoy your day off!',
      badgeText: 'FREE DAY',
    );
  }
}

/// Dynamic 7-Theme Contextual Timeline Placard for IRIS.
/// Faithfully reproduces each design system's aesthetic down to the micro-interactions.
class ContextualTimelineCard extends StatelessWidget {
  final ContextualTimelineState state;
  final bool isDark;
  final VoidCallback? onTap;

  const ContextualTimelineCard({
    super.key,
    required this.state,
    required this.isDark,
    this.onTap,
  });

  factory ContextualTimelineCard.resolve({
    Key? key,
    required DateTime now,
    required int activeDayIndex,
    required List<ClassSession> todaySessions,
    required ClassSession? currentClass,
    required ClassSession? nextClass,
    required bool isFaculty,
    required bool isDark,
    String? teacherName,
    String? batch,
    VoidCallback? onTap,
  }) {
    final state = ContextualTimelineState.resolve(
      now: now,
      activeDayIndex: activeDayIndex,
      todaySessions: todaySessions,
      currentClass: currentClass,
      nextClass: nextClass,
      isFaculty: isFaculty,
      teacherName: teacherName,
      batch: batch,
    );
    return ContextualTimelineCard(
      key: key,
      state: state,
      isDark: isDark,
      onTap: onTap,
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, style, _) {
        switch (style) {
          case IrisThemeStyle.materialYou:
            return _buildMaterialExpressivePlacard(context);
          case IrisThemeStyle.fluidGlass:
            return _buildLiquidGlassPlacard(context);
          case IrisThemeStyle.almanac:
            return _buildAlmanacPlacard(context);
          case IrisThemeStyle.editorialAcademic:
            return _buildEditorialPlacard(context);
          case IrisThemeStyle.notebook:
            return _buildNotebookPlacard(context);
          case IrisThemeStyle.line:
            return _buildLinePlacard(context);
          case IrisThemeStyle.poster:
            return _buildPosterPlacard(context);
        }
      },
    );
  }

  // ---------------------------------------------------------------------------
  // 1. Material 3 Expressive (Android 15 Google Pixel / Comic Scrapbook)
  // ---------------------------------------------------------------------------
  Widget _buildMaterialExpressivePlacard(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isLive = state.kind == ContextualTimelineStatusKind.live;
    final isUrgent = state.kind == ContextualTimelineStatusKind.urgentStarting;

    final Color badgeBg = isLive
        ? cs.primary
        : (isUrgent ? cs.tertiary : cs.secondaryContainer);
    final Color badgeText = isLive
        ? cs.onPrimary
        : (isUrgent ? cs.onTertiary : cs.onSecondaryContainer);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
      child: ExpressiveInteractivePress(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            color: cs.surfaceContainerLow,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55),
              width: 1.0,
            ),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                    decoration: BoxDecoration(
                      color: badgeBg,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (isLive) ...[
                          Container(
                            width: 6,
                            height: 6,
                            margin: const EdgeInsets.only(right: 5),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: badgeText,
                            ),
                          ),
                        ],
                        Text(
                          state.badgeText,
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            color: badgeText,
                            letterSpacing: 0.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (state.room.isNotEmpty) ...[
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                      decoration: BoxDecoration(
                        color: cs.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        'ROOM ${state.room}',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: cs.onSurfaceVariant,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 10),
              Text(
                state.headline,
                style: TextStyle(
                  fontSize: 14.5,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -0.2,
                  color: cs.onSurface,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                state.subline,
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w500,
                  color: cs.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 2. Liquid Glass (Fluid Glassmorphism & Specular Rim)
  // ---------------------------------------------------------------------------
  Widget _buildLiquidGlassPlacard(BuildContext context) {
    final isLive = state.kind == ContextualTimelineStatusKind.live;
    final isUrgent = state.kind == ContextualTimelineStatusKind.urgentStarting;
    final accent = isLive
        ? const Color(0xFF10B981)
        : (isUrgent ? const Color(0xFFF59E0B) : IrisTokens.brand);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
      child: GlassCard(
        borderRadius: 24,
        padding: EdgeInsets.zero,
        glow: isLive || isUrgent,
        enableOverlay: true,
        accentColor: accent,
        elevation: isLive ? 4 : 2,
        onTap: onTap,
        border: Border.all(
          color: accent.withValues(alpha: isDark ? 0.38 : 0.28),
          width: isLive ? 1.4 : 1.1,
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                    decoration: BoxDecoration(
                      color: isLive
                          ? const Color(0xFF10B981).withValues(alpha: 0.22)
                          : IrisTokens.brand.withValues(alpha: 0.20),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(
                        color: isLive
                            ? const Color(0xFF10B981).withValues(alpha: 0.45)
                            : IrisTokens.brand.withValues(alpha: 0.40),
                        width: 0.85,
                      ),
                    ),
                    child: Text(
                      state.badgeText,
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        color: isLive ? const Color(0xFF10B981) : IrisTokens.brandLight,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ),
                  if (state.room.isNotEmpty) ...[
                    const SizedBox(width: 8),
                    Text(
                      'ROOM ${state.room}',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.65),
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 10),
              Text(
                state.headline,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.2,
                  color: isDark ? Colors.white : const Color(0xFF0F172A),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                state.subline,
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w500,
                  color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.70),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 3. Almanac (Broadsheet Newspaper / Classical Archival)
  // ---------------------------------------------------------------------------
  Widget _buildAlmanacPlacard(BuildContext context) {
    final ruleColor = AlmanacTokens.inkRule(isDark);
    final accent = AlmanacTokens.accentTerracotta(isDark);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 6),
      child: Container(
        decoration: BoxDecoration(
          color: AlmanacTokens.cardSurface(isDark),
          border: Border.all(color: ruleColor, width: 1.2),
        ),
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Text(
                  'ACADEMIC DISPATCH',
                  style: AlmanacTokens.monoHeader(
                    isDark,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.1,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.14),
                    border: Border.all(color: accent, width: 0.8),
                  ),
                  child: Text(
                    state.badgeText,
                    style: AlmanacTokens.monoHeader(
                      isDark,
                      fontSize: 8.5,
                      color: accent,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Container(height: 1.0, color: ruleColor),
            const SizedBox(height: 10),
            Text(
              state.headline,
              style: AlmanacTokens.serifHeadline(
                isDark,
                fontSize: 14.5,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              state.subline,
              style: AlmanacTokens.countdownNarrative(isDark).copyWith(
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 4. Editorial Academic (Oxford Bookplate / Literary Study)
  // ---------------------------------------------------------------------------
  Widget _buildEditorialPlacard(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
      child: Container(
        decoration: BoxDecoration(
          color: EditorialTokens.cardSurface(isDark),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: EditorialTokens.cardBorder(isDark),
            width: 1.2,
          ),
          boxShadow: EditorialTokens.cardShadow(isDark, elevation: 3.0),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: EditorialTokens.accentUpcoming.withValues(alpha: 0.18),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    state.badgeText,
                    style: GoogleFonts.sourceSerif4(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: EditorialTokens.accentUpcoming,
                      letterSpacing: 0.4,
                    ),
                  ),
                ),
                if (state.room.isNotEmpty) ...[
                  const SizedBox(width: 8),
                  Text(
                    'HALL ${state.room}',
                    style: GoogleFonts.sourceSerif4(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: EditorialTokens.inkMuted(isDark),
                    ),
                  ),
                ],
              ],
            ),
            const SizedBox(height: 10),
            Text(
              state.headline,
              style: GoogleFonts.playfairDisplay(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.2,
                color: EditorialTokens.inkHeading(isDark),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              state.subline,
              style: GoogleFonts.sourceSerif4(
                fontSize: 12.5,
                fontWeight: FontWeight.w400,
                fontStyle: FontStyle.italic,
                color: EditorialTokens.inkMuted(isDark),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 5. Notebook (Hand-Drawn Stationery / Pin-Up Sticky Note)
  // ---------------------------------------------------------------------------
  Widget _buildNotebookPlacard(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
            decoration: BoxDecoration(
              color: NotebookTokens.stickyNote(isDark),
              borderRadius: BorderRadius.circular(4),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.09),
                  offset: const Offset(1, 3),
                  blurRadius: 6,
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: NotebookTokens.redDoodle(isDark).withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(
                          color: NotebookTokens.redDoodle(isDark).withValues(alpha: 0.5),
                          width: 1.0,
                        ),
                      ),
                      child: Text(
                        state.badgeText,
                        style: GoogleFonts.kalam(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: NotebookTokens.redDoodle(isDark),
                        ),
                      ),
                    ),
                    if (state.room.isNotEmpty) ...[
                      const SizedBox(width: 8),
                      Text(
                        'room ${state.room}',
                        style: GoogleFonts.caveat(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: NotebookTokens.inkMuted(isDark),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  state.headline.toLowerCase(),
                  style: GoogleFonts.kalam(
                    fontSize: 15.5,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF2C2510),
                    height: 1.15,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  state.subline,
                  style: GoogleFonts.caveat(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF4A3E20),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            top: -10,
            left: 24,
            child: WashiTapeOverhang(
              width: 50,
              height: 18,
              color: NotebookTokens.tapeYellow,
              rotation: -0.03,
            ),
          ),
          Positioned(
            bottom: 0,
            right: 0,
            child: CurledPaperCorner(
              size: 20,
              isDark: isDark,
              paperColor: NotebookTokens.stickyNote(isDark),
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 6. Subway Line (Continuous Metro Rail Transit HUD)
  // ---------------------------------------------------------------------------
  Widget _buildLinePlacard(BuildContext context) {
    final isLive = state.kind == ContextualTimelineStatusKind.live;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
      child: Container(
        decoration: BoxDecoration(
          color: LineTokens.cardSurface(isDark),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: LineTokens.railLine(isDark), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: LineTokens.railLine(isDark).withValues(alpha: 0.12),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: isLive ? LineTokens.subwayGreen : LineTokens.subwayYellow,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    state.badgeText,
                    style: GoogleFonts.spaceMono(
                      fontSize: 9.5,
                      fontWeight: FontWeight.w700,
                      color: Colors.black,
                      letterSpacing: 0.6,
                    ),
                  ),
                ),
                if (state.room.isNotEmpty) ...[
                  const SizedBox(width: 8),
                  Text(
                    'PLATFORM ${state.room}',
                    style: GoogleFonts.spaceMono(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: LineTokens.inkMuted(isDark),
                    ),
                  ),
                ],
              ],
            ),
            const SizedBox(height: 10),
            Text(
              state.headline,
              style: GoogleFonts.spaceMono(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.6,
                color: LineTokens.inkHeading(isDark),
              ),
            ),
            const SizedBox(height: 3),
            Text(
              state.subline,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: LineTokens.inkMuted(isDark),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 7. Swiss Poster (Monolithic Typographic Brutalism)
  // ---------------------------------------------------------------------------
  Widget _buildPosterPlacard(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
      child: Container(
        decoration: BoxDecoration(
          color: PosterTokens.cardSurface(isDark),
          border: Border.all(
            color: PosterTokens.inkBorder(isDark),
            width: 2.2,
          ),
          boxShadow: PosterTokens.extrudedBlockShadow(isDark, offset: 4.0),
        ),
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  color: PosterTokens.orangeHero,
                  child: Text(
                    state.badgeText,
                    style: GoogleFonts.spaceMono(
                      fontSize: 9.5,
                      fontWeight: FontWeight.w900,
                      color: Colors.black,
                      letterSpacing: 0.8,
                    ),
                  ),
                ),
                if (state.room.isNotEmpty) ...[
                  const SizedBox(width: 8),
                  Text(
                    'SECTOR ${state.room}',
                    style: GoogleFonts.spaceMono(
                      fontSize: 10.5,
                      fontWeight: FontWeight.w800,
                      color: PosterTokens.inkHeading(isDark),
                    ),
                  ),
                ],
              ],
            ),
            const SizedBox(height: 10),
            Text(
              state.headline,
              style: PosterTokens.classTitle(isDark).copyWith(
                fontSize: 14.5,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              state.subline,
              style: GoogleFonts.spaceMono(
                fontSize: 11.5,
                fontWeight: FontWeight.w600,
                color: PosterTokens.inkMuted(isDark),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
