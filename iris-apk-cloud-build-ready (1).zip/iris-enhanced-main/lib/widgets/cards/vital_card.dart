import 'package:flutter/material.dart';
import '../../core/vital_theme.dart';
import '../../core/vital_motion.dart';
import '../../core/theme_signals.dart';
import '../../core/sticker_tokens.dart';
import '../../core/animations.dart';
import '../../services/ui_feedback.dart';

class VitalCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final double? borderRadius;
  final VoidCallback? onTap;
  final Color? backgroundColor;
  final Border? border;
  final bool animate;
  final int index;

  const VitalCard({
    required this.child,
    this.padding,
    this.borderRadius,
    this.onTap,
    this.backgroundColor,
    this.border,
    this.animate = true,
    this.index = 0,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, style, _) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final isMinimal = ThemeSignals.useMinimalTheme.value;
        final isMaterialYou = style == IrisThemeStyle.materialYou;

        if (isMaterialYou) {
          final cs = Theme.of(context).colorScheme;
          final effectiveRadius = borderRadius ?? 24.0;
          final outlineColor = cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55);
          final cardColor = backgroundColor ?? cs.surfaceContainer;

          final shape = RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(effectiveRadius),
            side: BorderSide(
              color: outlineColor,
              width: 1.0,
            ),
          );

          Widget m3Card = Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(effectiveRadius),
            ),
            child: Material(
              color: cardColor,
              shape: shape,
              clipBehavior: Clip.antiAlias,
              child: InkWell(
                splashFactory: InkSparkle.splashFactory,
                onTap: onTap != null
                    ? () {
                        IrisHaptics.actionSoft();
                        onTap!();
                      }
                    : null,
                customBorder: shape,
                child: Padding(
                  padding: padding ?? const EdgeInsets.all(VitalTokens.space20),
                  child: child,
                ),
              ),
            ),
          );

          if (onTap != null) {
            m3Card = ExpressiveInteractivePress(
              onTap: onTap,
              pressedScale: 0.96,
              child: m3Card,
            );
          }

          if (!animate) return m3Card;
          return VitalEntrance(index: index, child: m3Card);
        }

        final effectiveRadius = borderRadius ?? VitalTokens.radius24;
        
        final cardBg = backgroundColor ?? (
          isDark ? (isMinimal ? const Color(0xFF0F1218) : const Color(0xFF161618)) : Colors.white
        );

        final cardBorder = border ?? Border.all(
          color: isDark 
              ? (isMinimal ? const Color(0xFF1E2433) : Colors.white.withValues(alpha: 0.08))
              : (isMinimal ? const Color(0xFFE2E8F0) : Colors.black.withValues(alpha: 0.05)),
          width: 1.0,
        );

        final cardShadow = isMinimal
            ? const <BoxShadow>[]
            : [
                BoxShadow(
                  color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.03),
                  blurRadius: 16,
                  spreadRadius: -4,
                  offset: const Offset(0, 6),
                ),
              ];
        
        Widget content = Container(
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(effectiveRadius),
            border: cardBorder,
            boxShadow: cardShadow,
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(effectiveRadius),
            child: Padding(
              padding: padding ?? const EdgeInsets.all(VitalTokens.space20),
              child: child,
            ),
          ),
        );

    if (onTap != null) {
      content = Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(effectiveRadius),
          onTap: () {
            IrisHaptics.actionSoft();
            onTap!();
          },
          child: content,
        ),
      );
    }

        if (!animate) return content;

        return VitalEntrance(
          index: index,
          child: content,
        );
      },
    );
  }
}