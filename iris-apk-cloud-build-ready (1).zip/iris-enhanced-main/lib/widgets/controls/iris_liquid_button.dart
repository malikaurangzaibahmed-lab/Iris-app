import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import '../../services/ui_feedback.dart';
import '../../core/theme_signals.dart';
import '../../core/material_you_theme.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../../core/glass.dart';
import '../../core/animations.dart';

class IrisLiquidButton extends StatelessWidget {
  final String text;
  final IconData? icon;
  final VoidCallback? onTap;
  final bool? isDark;
  final Color? color;
  final double? width;
  final double height;
  final double fontSize;
  final double iconSize;
  final EdgeInsetsGeometry padding;
  final FontWeight fontWeight;
  final BorderSide? borderSide;
  final double? borderRadius;

  const IrisLiquidButton({
    super.key,
    required this.text,
    this.onTap,
    this.icon,
    this.isDark,
    this.color,
    this.width,
    this.height = 44,
    this.fontSize = 16,
    this.iconSize = 20,
    this.padding = const EdgeInsets.symmetric(horizontal: 16.0),
    this.fontWeight = FontWeight.w700,
    this.borderSide,
    this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    final bool isEnabled = onTap != null;
    final bool effectiveDark = isDark ?? (Theme.of(context).brightness == Brightness.dark);
    final brightness = effectiveDark ? Brightness.dark : Brightness.light;
    final isMaterialYou = ThemeSignals.isMaterialYou;
    final isAlmanac = ThemeSignals.isAlmanac;
    final double effectiveRadius = borderRadius ?? (height / 2);

    if (isAlmanac) {
      final btnBg = isEnabled
          ? (color ?? (effectiveDark ? const Color(0xFFEAE6DF) : const Color(0xFF111111)))
          : (effectiveDark ? Colors.white12 : Colors.black12);
      final btnTextColor = isEnabled
          ? (color != null
              ? Colors.white
              : (effectiveDark ? const Color(0xFF111111) : const Color(0xFFFFFFFF)))
          : (effectiveDark ? Colors.white38 : Colors.black38);

      final buttonContent = SizedBox(
        width: width,
        height: height,
        child: Material(
          color: btnBg,
          borderRadius: BorderRadius.zero,
          child: Container(
            decoration: BoxDecoration(
              border: Border.all(
                color: borderSide?.color ?? AlmanacTokens.inkRule(effectiveDark),
                width: borderSide?.width ?? 1.0,
              ),
            ),
            padding: padding,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                if (icon != null) ...[
                  Icon(icon, color: btnTextColor, size: iconSize),
                  const SizedBox(width: 8),
                ],
                Flexible(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      text.toUpperCase(),
                      maxLines: 1,
                      softWrap: false,
                      style: AlmanacTokens.monoHeader(
                        effectiveDark,
                        fontSize: fontSize,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.2,
                        color: btnTextColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );

      if (!isEnabled) return RepaintBoundary(child: buttonContent);
      return RepaintBoundary(
        child: ExpressiveInteractivePress(
          onTap: () {
            IrisHaptics.actionMedium();
            onTap!();
          },
          enable3DTilt: false,
          baseRotation: 0.0,
          pressedScale: 0.96,
          child: buttonContent,
        ),
      );
    }

    if (!ThemeSignals.isFluidGlass) {
      final style = ThemeSignals.themeStyle.value;
      Color btnBg;
      Color btnTextColor;
      BorderRadius btnRadius = BorderRadius.circular(effectiveRadius);
      BoxBorder? btnBorder = borderSide != null ? Border.fromBorderSide(borderSide!) : null;

      if (style == IrisThemeStyle.poster) {
        btnBg = isEnabled ? (color ?? PosterTokens.orangeHero) : (effectiveDark ? Colors.white12 : Colors.black12);
        btnTextColor = isEnabled ? Colors.black : (effectiveDark ? Colors.white38 : Colors.black38);
        btnRadius = BorderRadius.zero;
        btnBorder = Border.all(color: PosterTokens.inkBorder(effectiveDark), width: 2.0);
      } else if (style == IrisThemeStyle.line) {
        btnBg = isEnabled ? (color ?? LineTokens.subwayYellow) : (effectiveDark ? Colors.white12 : Colors.black12);
        btnTextColor = isEnabled ? Colors.black : (effectiveDark ? Colors.white38 : Colors.black38);
        btnRadius = BorderRadius.circular(8);
        btnBorder = Border.all(color: LineTokens.railLine(effectiveDark), width: 1.5);
      } else if (style == IrisThemeStyle.notebook) {
        btnBg = isEnabled ? (color ?? NotebookTokens.redDoodle(effectiveDark)) : (effectiveDark ? Colors.white12 : Colors.black12);
        btnTextColor = isEnabled ? Colors.white : (effectiveDark ? Colors.white38 : Colors.black38);
        btnRadius = BorderRadius.circular(10);
      } else if (style == IrisThemeStyle.editorialAcademic) {
        btnBg = isEnabled ? (color ?? EditorialTokens.accentUpcoming) : (effectiveDark ? Colors.white12 : Colors.black12);
        btnTextColor = isEnabled ? Colors.white : (effectiveDark ? Colors.white38 : Colors.black38);
        btnRadius = BorderRadius.circular(14);
      } else {
        btnBg = isEnabled
            ? (color ?? MaterialYouTokens.primary(brightness))
            : (effectiveDark ? Colors.white12 : Colors.black12);
        btnTextColor = isEnabled
            ? (color != null ? Colors.white : MaterialYouTokens.onPrimary(brightness))
            : (effectiveDark ? Colors.white38 : Colors.black38);
      }

      final buttonContent = SizedBox(
        width: width,
        height: height,
        child: Material(
          color: btnBg,
          borderRadius: btnRadius,
          elevation: isEnabled && isMaterialYou ? 2.0 : 0.0,
          shadowColor: Colors.black.withValues(alpha: effectiveDark ? 0.35 : 0.12),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: btnRadius,
              border: btnBorder,
            ),
            child: Padding(
              padding: padding,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (icon != null) ...[
                    Icon(icon, color: btnTextColor, size: iconSize),
                    const SizedBox(width: 8),
                  ],
                  Flexible(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        text,
                        maxLines: 1,
                        softWrap: false,
                        style: TextStyle(
                          fontSize: fontSize,
                          fontWeight: fontWeight,
                          letterSpacing: 0.1,
                          color: btnTextColor,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );

      if (!isEnabled) return RepaintBoundary(child: buttonContent);
      return RepaintBoundary(
        child: ExpressiveInteractivePress(
          onTap: () {
            IrisHaptics.actionMedium();
            onTap!();
          },
          pressedScale: 0.94,
          child: buttonContent,
        ),
      );
    }

    if (false && isMaterialYou) {
      final btnBg = isEnabled
          ? (color ?? MaterialYouTokens.primary(brightness))
          : (effectiveDark ? Colors.white12 : Colors.black12);
      final btnTextColor = isEnabled
          ? (color != null ? Colors.white : MaterialYouTokens.onPrimary(brightness))
          : (effectiveDark ? Colors.white38 : Colors.black38);

      final buttonContent = SizedBox(
        width: width,
        height: height,
        child: Material(
          color: btnBg,
          borderRadius: BorderRadius.circular(effectiveRadius),
          elevation: isEnabled ? 2.0 : 0.0,
          shadowColor: Colors.black.withValues(alpha: effectiveDark ? 0.35 : 0.12),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(effectiveRadius),
              border: borderSide != null ? Border.fromBorderSide(borderSide!) : null,
            ),
            child: Padding(
              padding: padding,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (icon != null) ...[
                    Icon(icon, color: btnTextColor, size: iconSize),
                    const SizedBox(width: 8),
                  ],
                  Flexible(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        text,
                        maxLines: 1,
                        softWrap: false,
                        style: TextStyle(
                          fontSize: fontSize,
                          fontWeight: fontWeight,
                          letterSpacing: 0.1,
                          color: btnTextColor,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );

      if (!isEnabled) return RepaintBoundary(child: buttonContent);
      return RepaintBoundary(
        child: ExpressiveInteractivePress(
          onTap: () {
            IrisHaptics.actionMedium();
            onTap!();
          },
          pressedScale: 0.94,
          child: buttonContent,
        ),
      );
    }

    final Color? validColor = (color != null && color!.a >= 0.5)
        ? color
        : (color != null ? color!.withValues(alpha: 1.0) : null);
    final textColor = isEnabled
        ? (effectiveDark
            ? (validColor != null
                ? Color.lerp(validColor, Colors.white, 0.62)!
                : Colors.white)
            : (validColor ?? const Color(0xFF0F172A)))
        : (effectiveDark ? Colors.white38 : Colors.black38);

    return ValueListenableBuilder<double>(
      valueListenable: ThemeSignals.glassTransparency,
      builder: (context, transparency, _) {
        final isOpaque = transparency <= 0.08;
        final double btnBlur = isOpaque ? 0.0 : lerpDouble(8.0, 18.0, transparency)!;
        final double btnThickness = isOpaque ? 0.0 : lerpDouble(8.0, 16.0, transparency)!;
        final double btnAmbient = isOpaque ? 0.0 : lerpDouble(0.35, 0.78, transparency)!;

        final Color darkTintBase = validColor != null
            ? Color.alphaBlend(validColor.withValues(alpha: 0.26), const Color(0xFF0F172A))
            : const Color(0xFF0F172A);

        final Color baseGlassColor = effectiveDark
            ? (isOpaque
                ? const Color(0xFF161B26)
                : darkTintBase.withValues(alpha: lerpDouble(0.92, 0.38, transparency)!))
            : (isOpaque
                ? Colors.white
                : Colors.white.withValues(alpha: lerpDouble(0.96, 0.62, transparency)!));

        final side = borderSide ?? (isOpaque
            ? BorderSide(
                color: effectiveDark ? const Color(0xFF2E384D) : const Color(0xFFCBD5E1),
                width: 1.0,
              )
            : (effectiveDark
                ? BorderSide.none
                : BorderSide(
                    color: Colors.black.withValues(alpha: 0.08),
                    width: 1.0,
                  )));

        return RepaintBoundary(
          child: lgw.GlassButton.custom(
            enabled: isEnabled,
            onTap: () {
              if (!isEnabled) return;
              IrisHaptics.actionMedium();
              onTap!();
            },
            width: width,
            height: height,
            useOwnLayer: true, // Forces isolated Two-Blob Metaball tracking
            interactionScale: 0.92, // Deep press squash
            stretch: 0.65, // Very high taffy pull stretch
            anchorStretch: true, // Pin center, stretch towards finger (ColorOS 17 style)
            anchorStretchSettings: const lgw.AnchorStretchSettings(
              intensity: 1.0,
              squashFactor: 0.1, // Only slightly squash the opposite face
              translationDamping: 0.85, // Highly damped translation
              bounciness: 0.05, // Minimal bounce to feel damped and heavy
            ),
            persistPressOnDrag: true, // Consume drag to prevent scrolling while held
            resistance: 0.08, // High resistance for heavy liquid feel
            shape: lgw.LiquidRoundedSuperellipse(
              borderRadius: effectiveRadius,
              side: side,
            ),
            quality: isOpaque ? lgw.GlassQuality.minimal : lgw.GlassQuality.premium,
            settings: IrisGlass.widgetsSettings(
              context,
              blur: btnBlur,
              thickness: btnThickness,
              glassColor: baseGlassColor,
              ambientStrength: btnAmbient,
              lightIntensity: effectiveDark ? 0.85 : 0.95,
              specularSharpness: lgw.GlassSpecularSharpness.sharp,
            ),
            child: Padding(
              padding: padding,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (icon != null) ...[
                    Icon(icon, color: textColor, size: iconSize),
                    const SizedBox(width: 8),
                  ],
                  Flexible(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        text,
                        maxLines: 1,
                        softWrap: false,
                        style: TextStyle(
                          fontSize: fontSize,
                          fontWeight: fontWeight,
                          letterSpacing: 0.5,
                          color: textColor,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}