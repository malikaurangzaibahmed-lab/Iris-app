import 'package:flutter/material.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import '../../core/models.dart';
import '../../core/omni_brain.dart';
import '../../core/theme_signals.dart';
import '../../core/animations.dart';
import '../../services/remote_config_service.dart';
import '../../services/ui_feedback.dart';
import 'package:iris/widgets/effects/glass_container_transform.dart';
import '../../widgets/iris_components.dart';
import 'package:iris/widgets/dashboard/live_class_hub_sheet.dart';
import 'package:iris/screens/academics/department_classes_screen.dart';
import 'package:iris/screens/settings/announcements_screen.dart';

/// Pure, Minimal Material 3 Expressive Home Header.
/// Uses strictly native Material 3 tonal surface containers, clean typography,
/// zero blur shaders, zero sticker/scrapbook gimmicks, and 100% real timetable data.
class MaterialExpressiveHomeHeader extends StatelessWidget {
  final bool isDark;
  final DateTime now;
  final String displayName;
  final String greetingText;
  final String period;
  final TemporalInsight insight;
  final List<ClassSession> schedule;
  final List<ClassSession> filteredSchedule;
  final OmniBrain brain;
  final String batch;
  final UniversityMemory memory;
  final VoidCallback onTriggerBatchSelector;
  final ValueChanged<String>? onBatchChanged;
  final ValueChanged<String>? onRoleChanged;

  const MaterialExpressiveHomeHeader({
    required this.isDark,
    required this.now,
    required this.displayName,
    required this.greetingText,
    required this.period,
    required this.insight,
    required this.schedule,
    required this.filteredSchedule,
    required this.brain,
    required this.batch,
    required this.memory,
    required this.onTriggerBatchSelector,
    this.onBatchChanged,
    this.onRoleChanged,
    super.key,
  });

  static String getDegreeTitle(String batch) {
    final upper = batch.toUpperCase();
    if (upper.contains('BCS') || upper.contains('-CS-')) return 'BS Computer Science';
    if (upper.contains('BSE') || upper.contains('-SE-')) return 'BS Software Engineering';
    if (upper.contains('BAI') || upper.contains('-AI-')) return 'BS Artificial Intelligence';
    if (upper.contains('BDS') || upper.contains('-DS-')) return 'BS Data Science';
    if (upper.contains('BCY') || upper.contains('-CY-')) return 'BS Cyber Security';
    if (upper.contains('BEE') || upper.contains('-EE-')) return 'BS Electrical Engineering';
    if (upper.contains('BBA')) return 'BBA';
    return 'Academic Program';
  }

  static String getInitials(String? name) {
    if (name == null || name.trim().isEmpty) return 'ST';
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.length == 1) {
      if (parts[0].length >= 2) {
        return parts[0].substring(0, 2).toUpperCase();
      }
      return parts[0].toUpperCase();
    }
    final first = parts.first.isNotEmpty
        ? parts.first.substring(0, 1).toUpperCase()
        : '';
    final last = parts.last.isNotEmpty
        ? parts.last.substring(0, 1).toUpperCase()
        : '';
    return '$first$last';
  }

  static String _dayShort(int dayIndex) {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    if (dayIndex >= 1 && dayIndex <= 7) return days[dayIndex - 1];
    return 'Upcoming';
  }

  static String getSmartGreeting(int hour) {
    if (hour >= 5 && hour < 12) return 'Morning';
    if (hour >= 12 && hour < 17) return 'Afternoon';
    if (hour >= 17 && hour < 21) return 'Evening';
    return 'Night';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    final currentClass = brain.getCurrentClass(batch, now);
    final nextClass = brain.getNextClass(batch, now);
    final heroClass = currentClass ?? nextClass ?? (schedule.isNotEmpty ? schedule.first : null);

    final isLive = heroClass != null && heroClass.isLive(now);
    final isToday = heroClass != null && heroClass.dayIndex == now.weekday;
    int minutesUntil = 0;
    if (heroClass != null && !isLive && isToday) {
      final currentHourFraction = now.hour + (now.minute / 60.0);
      final diff = heroClass.safeStartVal - currentHourFraction;
      if (diff > 0) {
        minutesUntil = (diff * 60).round();
      }
    }

    final degreeTitle = getDegreeTitle(batch);
    final studentFirstName = displayName.split(RegExp(r'\s+')).first;
    final smartGreeting = getSmartGreeting(now.hour);

    final String badgeText = isLive
        ? 'LIVE NOW'
        : (heroClass != null
            ? (isToday ? 'UP NEXT' : 'NEXT CLASS')
            : 'TODAY');

    final String statusText = isLive
        ? 'In Session'
        : (minutesUntil > 0 && minutesUntil <= 120
            ? 'In $minutesUntil min'
            : (heroClass != null
                ? (isToday
                    ? heroClass.startTime
                    : '${_dayShort(heroClass.dayIndex)} • ${heroClass.startTime}')
                : 'No Classes'));

    final Color heroCardBg = isLive
        ? cs.primaryContainer
        : cs.surfaceContainerHigh;
    final Color heroCardFg = isLive
        ? cs.onPrimaryContainer
        : cs.onSurface;
    final Color heroCardMuted = isLive
        ? cs.onPrimaryContainer.withValues(alpha: 0.78)
        : cs.onSurfaceVariant;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        // 1. Minimal Material 3 Top Header Bar
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            IrisGlassMenu(
              autoAdjustToScreen: true,
              menuPadding: const EdgeInsets.all(12),
              menuWidth: 220,
              menuBorderRadius: 20.0,
              itemBorderRadius: 14.0,
              triggerBuilder: (menuContext, toggleMenu) {
                return ExpressiveInteractivePress(
                  onTap: toggleMenu,
                  child: Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      color: cs.primaryContainer,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55),
                        width: 1.0,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        getInitials(displayName),
                        style: TextStyle(
                          color: cs.onPrimaryContainer,
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                          letterSpacing: 0.3,
                        ),
                      ),
                    ),
                  ),
                );
              },
              items: [
                lgw.GlassMenuItem(
                  title: 'Student Mode',
                  titleStyle: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 13.5,
                    color: cs.primary,
                  ),
                  isSelected: true,
                  icon: const Icon(Icons.school_rounded, size: 18),
                  onTap: () {},
                ),
                lgw.GlassMenuItem(
                  title: 'Faculty Mode',
                  titleStyle: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 13.5,
                    color: cs.onSurface,
                  ),
                  isSelected: false,
                  icon: const Icon(Icons.badge_rounded, size: 18),
                  onTap: () {
                    onRoleChanged?.call('faculty');
                  },
                ),
                const lgw.GlassMenuDivider(),
                lgw.GlassMenuItem(
                  title: 'Select Batch',
                  titleStyle: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 13.5,
                    color: cs.onSurface,
                  ),
                  icon: const Icon(Icons.layers_rounded, size: 18),
                  onTap: onTriggerBatchSelector,
                ),
                const lgw.GlassMenuDivider(),
                lgw.GlassMenuItem(
                  title: 'Switch to Liquid Glass',
                  titleStyle: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 13.5,
                    color: cs.primary,
                  ),
                  icon: Icon(
                    Icons.water_drop_rounded,
                    size: 18,
                    color: cs.primary,
                  ),
                  onTap: () {
                    ThemeSignals.switchThemeWithMorph(
                      context,
                      style: IrisThemeStyle.fluidGlass,
                    );
                  },
                ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Good $smartGreeting,',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: cs.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 1),
                  Text(
                    studentFirstName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.4,
                      color: cs.onSurface,
                      height: 1.15,
                    ),
                  ),
                ],
              ),
            ),
            if (batch.isNotEmpty) ...[
              const SizedBox(width: 8),
              ExpressiveInteractivePress(
                onTap: onTriggerBatchSelector,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: cs.secondaryContainer,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.school_outlined,
                        size: 15,
                        color: cs.onSecondaryContainer,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        batch,
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w700,
                          color: cs.onSecondaryContainer,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
            const SizedBox(width: 8),
            ExpressiveInteractivePress(
              onTap: () {
                IrisHaptics.actionSoft();
                pushGlassContainerMorphRoute(
                  context,
                  page: const AnnouncementsScreen(),
                  accentColor: cs.primary,
                );
              },
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: cs.surfaceContainerHigh,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55),
                        width: 1.0,
                      ),
                    ),
                    child: Center(
                      child: Icon(
                        Icons.notifications_none_rounded,
                        size: 20,
                        color: cs.onSurfaceVariant,
                      ),
                    ),
                  ),
                  ValueListenableBuilder<List<Map<String, dynamic>>>(
                    valueListenable: RemoteConfigService.liveNotices,
                    builder: (context, notices, _) {
                      return ValueListenableBuilder<Map<String, dynamic>?>(
                        valueListenable: RemoteConfigService.liveAnnouncement,
                        builder: (context, broadcast, _) {
                          final hasNotices = notices.isNotEmpty ||
                              (broadcast != null && broadcast['enabled'] == true);
                          if (!hasNotices) return const SizedBox.shrink();
                          return Positioned(
                            top: 2,
                            right: 2,
                            child: Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: cs.error,
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: cs.surface,
                                  width: 1.5,
                                ),
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
        if (batch.isNotEmpty) ...[
          const SizedBox(height: 10),
          ExpressiveInteractivePress(
            onTap: () {
              IrisHaptics.chipSelect();
              pushGlassContainerMorphRoute(
                context,
                page: DepartmentClassesScreen(
                  memory: memory,
                  brain: brain,
                  currentBatch: batch,
                  showBatchShortcut: true,
                  showBackButton: true,
                  onBatchChanged: onBatchChanged,
                  onRoleChanged: onRoleChanged,
                ),
                accentColor: cs.primary,
              );
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                color: cs.surfaceContainerLow,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.50),
                  width: 1.0,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    '$batch • $degreeTitle',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: cs.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Icon(
                    Icons.chevron_right_rounded,
                    size: 16,
                    color: cs.onSurfaceVariant,
                  ),
                ],
              ),
            ),
          ),
        ],
        const SizedBox(height: 14),

        // 2. Pure Material 3 Expressive Hero Session Card
        ExpressiveInteractivePress(
          onTap: () {
            if (isLive || insight.isUrgent) {
              IrisHaptics.actionSoft();
              IrisModalSheet.show(
                context: context,
                initialState: lgw.GlassSheetState.half,
                builder: (sheetContext) => LiveClassHubSheet(
                  brain: brain,
                  memory: memory,
                  batch: batch,
                  sessions: schedule,
                ),
              );
            } else if (heroClass != null) {
              IrisHaptics.selectionClick();
              pushGlassContainerMorphRoute(
                context,
                page: DepartmentClassesScreen(
                  memory: memory,
                  brain: brain,
                  currentBatch: batch,
                  showBatchShortcut: true,
                  showBackButton: true,
                  onBatchChanged: onBatchChanged,
                  onRoleChanged: onRoleChanged,
                ),
                accentColor: cs.primary,
              );
            }
          },
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: heroCardBg,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color: isLive
                    ? cs.primary.withValues(alpha: 0.45)
                    : cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55),
                width: 1.0,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: isLive
                            ? cs.primary
                            : cs.secondaryContainer,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        badgeText,
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.6,
                          color: isLive
                              ? cs.onPrimary
                              : cs.onSecondaryContainer,
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: isLive
                            ? cs.onPrimaryContainer.withValues(alpha: 0.10)
                            : cs.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (isLive || (minutesUntil > 0 && minutesUntil <= 120)) ...[
                            Container(
                              width: 6,
                              height: 6,
                              decoration: BoxDecoration(
                                color: isLive ? cs.primary : const Color(0xFF10B981),
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 6),
                          ],
                          Text(
                            statusText,
                            style: TextStyle(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w700,
                              color: heroCardFg,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Text(
                  heroClass != null
                      ? heroClass.subject
                      : (insight.headline.isNotEmpty
                          ? insight.headline
                          : 'No Classes Scheduled'),
                  style: TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.3,
                    color: heroCardFg,
                    height: 1.22,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _buildMetaPill(
                      icon: Icons.schedule_rounded,
                      label: heroClass != null
                          ? (isToday
                              ? '${heroClass.startTime} - ${heroClass.endTime}'
                              : '${_dayShort(heroClass.dayIndex)} • ${heroClass.startTime} - ${heroClass.endTime}')
                          : (now.weekday >= 6 ? 'Weekend Break' : 'All Clear Today'),
                      bg: isLive
                          ? cs.onPrimaryContainer.withValues(alpha: 0.10)
                          : cs.surfaceContainerHighest,
                      fg: heroCardMuted,
                    ),
                    if (heroClass != null) ...[
                      _buildMetaPill(
                        icon: Icons.meeting_room_outlined,
                        label: heroClass.subject.toLowerCase().contains('lab')
                            ? 'Lab ${heroClass.room}'
                            : 'Room ${heroClass.room}',
                        bg: isLive
                            ? cs.onPrimaryContainer.withValues(alpha: 0.10)
                            : cs.surfaceContainerHighest,
                        fg: heroCardMuted,
                      ),
                      if (heroClass.teacher.isNotEmpty)
                        _buildMetaPill(
                          icon: Icons.person_outline_rounded,
                          label: heroClass.teacher,
                          bg: isLive
                              ? cs.onPrimaryContainer.withValues(alpha: 0.10)
                              : cs.surfaceContainerHighest,
                          fg: heroCardMuted,
                        ),
                      if (heroClass.isCombinedLecture)
                        _buildMetaPill(
                          icon: Icons.groups_outlined,
                          label: heroClass.displayBatch,
                          bg: cs.tertiaryContainer,
                          fg: cs.onTertiaryContainer,
                        ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMetaPill({
    required IconData icon,
    required String label,
    required Color bg,
    required Color fg,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13.5, color: fg),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              fontSize: 11.5,
              fontWeight: FontWeight.w600,
              color: fg,
            ),
          ),
        ],
      ),
    );
  }
}
