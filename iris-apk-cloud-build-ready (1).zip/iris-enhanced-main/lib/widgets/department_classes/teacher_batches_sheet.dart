import '../../core/theme_signals.dart';
import '../../core/glass.dart';
import 'package:flutter/material.dart';
import '../../core/tokens.dart';
import '../../core/animations.dart';

/// Modal bottom sheet allowing faculty to view and switch between their assigned teaching batches.
class TeacherBatchesSheet extends StatelessWidget {
  final bool isDark;
  final List<String> teacherBatches;
  final String? currentBatchString;
  final ValueChanged<String> onSelectBatch;

  const TeacherBatchesSheet({
    required this.isDark,
    required this.teacherBatches,
    required this.currentBatchString,
    required this.onSelectBatch,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final sheetContent = Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
      decoration: BoxDecoration(
        color: ThemeSignals.isFluidGlass
            ? (isDark ? const Color(0xFF0F172A) : Colors.white).withValues(alpha: isDark ? 0.72 : 0.84)
            : Theme.of(context).colorScheme.surfaceContainerHigh,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 18),
              decoration: BoxDecoration(
                color: (isDark ? Colors.white : Colors.black).withValues(
                  alpha: 0.20,
                ),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          Row(
            children: [
              const Icon(
                Icons.school_rounded,
                color: IrisTokens.brand,
                size: 22,
              ),
              const SizedBox(width: 8),
              Text(
                'Your Teaching Batches',
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w800,
                  color: isDark ? Colors.white : Colors.black87,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'Select a batch to inspect its weekly timetable:',
            style: TextStyle(
              fontSize: 12.5,
              color: isDark ? Colors.white60 : Colors.black54,
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: teacherBatches.map((batch) {
              final isCurrent = currentBatchString == batch;
              return ExpressiveInteractivePress(
                onTap: () {
                  Navigator.of(context).pop();
                  onSelectBatch(batch);
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    color: isCurrent
                        ? IrisTokens.brand
                        : (isDark
                            ? Colors.white.withValues(alpha: 0.08)
                            : Colors.black.withValues(alpha: 0.05)),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isCurrent
                          ? IrisTokens.brand
                          : (isDark ? Colors.white12 : Colors.black12),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.school_rounded,
                        size: 16,
                        color: isCurrent ? Colors.white : IrisTokens.brand,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        batch,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: isCurrent
                              ? FontWeight.w800
                              : FontWeight.w600,
                          color: isCurrent
                              ? Colors.white
                              : (isDark ? Colors.white : Colors.black87),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );

    if (ThemeSignals.isFluidGlass) {
      return ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: GlassSurface(
          settings: IrisGlass.settings(context, blur: 18.0, thickness: 16.0),
          radius: 28,
          child: sheetContent,
        ),
      );
    }
    return sheetContent;
  }
}
