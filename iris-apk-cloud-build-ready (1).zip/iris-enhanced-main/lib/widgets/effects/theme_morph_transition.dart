import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../../core/theme_signals.dart';
import '../../core/laminar_flow.dart';
import '../../services/ui_feedback.dart';
import 'glass_container_transform.dart';

/// Controller and state manager for global theme container morphing.
class ThemeMorphController {
  static ThemeMorphOverlayState? _activeState;

  static void _register(ThemeMorphOverlayState state) {
    _activeState = state;
    ThemeSignals.morphTransitionHandler = morphTo;
  }

  static void _unregister(ThemeMorphOverlayState state) {
    if (_activeState == state) {
      _activeState = null;
      ThemeSignals.morphTransitionHandler = null;
    }
  }

  static bool get isMorphing => _activeState?.isMorphing ?? false;

  static Future<void> morphTo({
    required IrisThemeStyle targetStyle,
    Rect? originRect,
    GlobalKey? originKey,
    BuildContext? context,
  }) async {
    if (_activeState != null && _activeState!.mounted) {
      await _activeState!.startMorph(
        targetStyle: targetStyle,
        originRect: originRect,
        originKey: originKey,
        callerContext: context,
      );
    } else {
      await ThemeSignals.setThemeStyle(targetStyle);
    }
  }
}

/// 120 FPS Zero-Readback ColorOS 17 Theme Wave Transition Overlay.
/// Eliminates the synchronous GPU `boundary.toImage()` stall and expensive
/// `Path.combine` stencil clip, switching themes on Frame 1 with a smooth
/// laminar specular wave ring.
class ThemeMorphOverlay extends StatefulWidget {
  final Widget child;

  static final GlobalKey<ThemeMorphOverlayState> globalKey =
      GlobalKey<ThemeMorphOverlayState>();

  ThemeMorphOverlay({
    Key? key,
    required this.child,
  }) : super(key: key ?? globalKey);

  static Future<void> morph(
    BuildContext context, {
    required IrisThemeStyle targetStyle,
    Rect? originRect,
    GlobalKey? originKey,
  }) {
    return ThemeMorphController.morphTo(
      targetStyle: targetStyle,
      originRect: originRect,
      originKey: originKey,
      context: context,
    );
  }

  @override
  State<ThemeMorphOverlay> createState() => ThemeMorphOverlayState();
}

class ThemeMorphOverlayState extends State<ThemeMorphOverlay>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _morphAnimation;

  bool _isMorphing = false;
  bool get isMorphing => _isMorphing;

  IrisThemeStyle? _toStyle;
  Rect _startRect = Rect.zero;
  Color _monetSeed = ThemeSignals.defaultM3ESeedColor;

  @override
  void initState() {
    super.initState();
    ThemeMorphController._register(this);

    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 280),
    );

    _morphAnimation = CurvedAnimation(
      parent: _animController,
      curve: LaminarCurves.laminarEntrance,
    );

    _animController.addStatusListener((status) {
      if (status == AnimationStatus.completed ||
          status == AnimationStatus.dismissed) {
        if (mounted) {
          setState(() => _isMorphing = false);
        }
      }
    });
  }

  @override
  void dispose() {
    ThemeMorphController._unregister(this);
    _animController.dispose();
    super.dispose();
  }

  Future<void> startMorph({
    required IrisThemeStyle targetStyle,
    Rect? originRect,
    GlobalKey? originKey,
    BuildContext? callerContext,
  }) async {
    if (ThemeSignals.themeStyle.value == targetStyle) {
      return;
    }
    if (_isMorphing) {
      _animController.stop();
    }

    final screenSize = MediaQuery.sizeOf(context);
    final rect = IrisSpatialDepth.resolveOriginBounds(
      screenSize: screenSize,
      initialBounds: originRect,
      originKey: originKey,
      callerContext: callerContext,
      fallbackCardSize: const Size(120, 48),
    );

    _toStyle = targetStyle;
    _startRect = rect;
    _monetSeed = ThemeSignals.m3eSeedColor.value;
    _isMorphing = true;

    IrisHaptics.selectionClick();
    await ThemeSignals.setThemeStyle(targetStyle);

    if (!mounted) return;
    setState(() {});
    await _animController.forward(from: 0.0);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        RepaintBoundary(child: widget.child),
        if (_isMorphing)
          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: _animController,
                builder: (context, _) {
                  return CustomPaint(
                    painter: _ThemeWaveRingPainter(
                      progress: _morphAnimation.value,
                      startRect: _startRect,
                      toStyle: _toStyle ?? IrisThemeStyle.fluidGlass,
                      monetSeed: _monetSeed,
                    ),
                  );
                },
              ),
            ),
          ),
      ],
    );
  }
}

class _ThemeWaveRingPainter extends CustomPainter {
  final double progress;
  final Rect startRect;
  final IrisThemeStyle toStyle;
  final Color monetSeed;

  _ThemeWaveRingPainter({
    required this.progress,
    required this.startRect,
    required this.toStyle,
    required this.monetSeed,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;
    final fadeAlpha = (1.0 - progress).clamp(0.0, 1.0);
    if (fadeAlpha <= 0.01) return;

    final center = startRect.center;
    final maxDist = math.sqrt(size.width * size.width + size.height * size.height);
    final startRadius = math.min(startRect.width, startRect.height) * 0.35;
    final currentRadius = ui.lerpDouble(startRadius, maxDist, progress) ?? maxDist;

    final accent = switch (toStyle) {
      IrisThemeStyle.fluidGlass => const Color(0xFF38BDF8),
      IrisThemeStyle.materialYou => monetSeed,
      IrisThemeStyle.almanac => const Color(0xFFC84B31),
      IrisThemeStyle.editorialAcademic => const Color(0xFFE5A83B),
      IrisThemeStyle.notebook => const Color(0xFFE11D48),
      IrisThemeStyle.line => const Color(0xFF10B981),
      IrisThemeStyle.poster => const Color(0xFFFF451A),
    };

    final rimPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.0 * fadeAlpha
      ..color = accent.withValues(alpha: 0.55 * fadeAlpha);
    canvas.drawCircle(center, currentRadius, rimPaint);
  }

  @override
  bool shouldRepaint(covariant _ThemeWaveRingPainter oldDelegate) {
    return oldDelegate.progress != progress;
  }
}
