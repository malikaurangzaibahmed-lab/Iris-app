import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' hide GlassCard;
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import 'package:material_3_expressive/material_3_expressive.dart';

import '../core/animations.dart';
import '../core/almanac_theme_tokens.dart';
import '../core/editorial_theme_tokens.dart';
import '../core/notebook_theme_tokens.dart';
import '../core/line_theme_tokens.dart';
import '../core/poster_theme_tokens.dart';
import 'package:google_fonts/google_fonts.dart';
import '../core/glass.dart';
import '../core/minimal_theme.dart';
import '../core/theme_signals.dart';
import '../core/tokens.dart';
import '../services/helpdesk_faculty_service.dart';
import '../services/ui_feedback.dart';
import 'controls/iris_expressive_controls.dart';
import 'smart_widgets.dart';
import 'package:iris/widgets/cards/vital_card.dart';

export 'cards/class_card.dart';
export 'navigation/day_switcher.dart';
export 'controls/iris_expressive_controls.dart';

/// Dual-engine adaptive bottom modal sheet.
/// Routes seamlessly between Google Material 3 Expressive bottom sheets
/// and lightweight, high-performance Liquid Glass modal sheets.
class IrisModalSheet {
  static Future<T?> show<T>({
    required BuildContext context,
    required Widget Function(BuildContext) builder,
    lgw.GlassSheetState initialState = lgw.GlassSheetState.half,
    lgw.LiquidGlassSettings? settings,
    bool isScrollControlled = true,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final style = ThemeSignals.themeStyle.value;

    if (style == IrisThemeStyle.almanac) {
      return showModalBottomSheet<T>(
        context: context,
        isScrollControlled: isScrollControlled,
        backgroundColor: Colors.transparent,
        barrierColor: Colors.black.withValues(alpha: isDark ? 0.65 : 0.40),
        elevation: 0,
        builder: (ctx) => RepaintBoundary(
          child: Container(
            decoration: BoxDecoration(
              color: AlmanacTokens.canvas(isDark),
              border: Border(
                top: BorderSide(
                  color: AlmanacTokens.inkRule(isDark),
                  width: 1.5,
                ),
              ),
            ),
            child: SafeArea(
              top: false,
              child: builder(ctx),
            ),
          ),
        ),
      );
    }

    if (style == IrisThemeStyle.poster) {
      return showModalBottomSheet<T>(
        context: context,
        isScrollControlled: isScrollControlled,
        backgroundColor: Colors.transparent,
        barrierColor: Colors.black.withValues(alpha: isDark ? 0.70 : 0.45),
        elevation: 0,
        builder: (ctx) => RepaintBoundary(
          child: Container(
            decoration: BoxDecoration(
              color: PosterTokens.canvas(isDark),
              border: Border.all(
                color: PosterTokens.inkBorder(isDark),
                width: 2.5,
              ),
            ),
            child: SafeArea(
              top: false,
              child: builder(ctx),
            ),
          ),
        ),
      );
    }

    if (style == IrisThemeStyle.line) {
      return showModalBottomSheet<T>(
        context: context,
        isScrollControlled: isScrollControlled,
        backgroundColor: Colors.transparent,
        barrierColor: Colors.black.withValues(alpha: isDark ? 0.65 : 0.40),
        elevation: 0,
        builder: (ctx) => RepaintBoundary(
          child: Container(
            decoration: BoxDecoration(
              color: LineTokens.cardSurface(isDark),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
              border: Border.all(
                color: LineTokens.railLine(isDark),
                width: 1.8,
              ),
            ),
            child: SafeArea(
              top: false,
              child: builder(ctx),
            ),
          ),
        ),
      );
    }

    if (style == IrisThemeStyle.notebook) {
      return showModalBottomSheet<T>(
        context: context,
        isScrollControlled: isScrollControlled,
        backgroundColor: Colors.transparent,
        barrierColor: Colors.black.withValues(alpha: isDark ? 0.60 : 0.35),
        elevation: 0,
        builder: (ctx) => RepaintBoundary(
          child: Container(
            decoration: BoxDecoration(
              color: NotebookTokens.cardSurface(isDark),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              border: Border.all(
                color: NotebookTokens.gridLine(isDark),
                width: 1.5,
              ),
            ),
            child: SafeArea(
              top: false,
              child: builder(ctx),
            ),
          ),
        ),
      );
    }

    if (style == IrisThemeStyle.editorialAcademic) {
      return showModalBottomSheet<T>(
        context: context,
        isScrollControlled: isScrollControlled,
        backgroundColor: Colors.transparent,
        barrierColor: Colors.black.withValues(alpha: isDark ? 0.60 : 0.35),
        elevation: 0,
        builder: (ctx) => RepaintBoundary(
          child: Container(
            decoration: BoxDecoration(
              color: EditorialTokens.cardSurface(isDark),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
              border: Border.all(
                color: EditorialTokens.cardBorder(isDark),
                width: 1.4,
              ),
            ),
            child: SafeArea(
              top: false,
              child: builder(ctx),
            ),
          ),
        ),
      );
    }

    if (style == IrisThemeStyle.materialYou) {
      return showModalBottomSheet<T>(
        context: context,
        isScrollControlled: isScrollControlled,
        backgroundColor: Theme.of(context).colorScheme.surfaceContainerHigh,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        builder: (ctx) => RepaintBoundary(child: builder(ctx)),
      );
    }

    // Liquid Glass Bottom Modal Sheet powered by liquid_glass_widgets 1.14.2 AdaptiveLiquidGlassLayer
    return showModalBottomSheet<T>(
      context: context,
      isScrollControlled: isScrollControlled,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withValues(alpha: isDark ? 0.55 : 0.35),
      elevation: 0,
      builder: (ctx) {
        final effectiveSettings = settings ??
            IrisGlass.widgetsSettings(
              ctx,
              blur: 20.0,
              thickness: 18.0,
              ambientStrength: isDark ? 0.72 : 0.78,
              lightAngle: 1.5,
              glassColor: isDark
                  ? const Color(0xFF0F172A).withValues(alpha: 0.78)
                  : Colors.white.withValues(alpha: 0.85),
            );

        return RepaintBoundary(
          child: Container(
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: isDark ? 0.45 : 0.15),
                  blurRadius: 28,
                  offset: const Offset(0, -6),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
              child: GlassSurface(
                settings: effectiveSettings,
                radius: 28.0,
                applyInLayer: true,
                borderSide: BorderSide(
                  color: (isDark ? Colors.white : Colors.black)
                      .withValues(alpha: isDark ? 0.22 : 0.14),
                  width: 1.2,
                ),
                child: SafeArea(
                  top: false,
                  child: builder(ctx),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
/// Theme-adaptive pull-to-refresh indicator that dynamically configures
/// stroke color, background surface color, stroke width, and displacement
/// relative to the active theme.
class IrisRefreshIndicator extends StatelessWidget {
  final Future<void> Function() onRefresh;
  final Widget child;
  final Color? color;
  final Color? backgroundColor;
  final double displacement;
  final double edgeOffset;

  const IrisRefreshIndicator({
    super.key,
    required this.onRefresh,
    required this.child,
    this.color,
    this.backgroundColor,
    this.displacement = 40.0,
    this.edgeOffset = 0.0,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, themeStyle, _) {
        Color resolvedColor;
        Color resolvedBg;
        double strokeWidth = 2.0;

        switch (themeStyle) {
          case IrisThemeStyle.almanac:
            resolvedColor = color ?? AlmanacTokens.accentTerracotta(isDark);
            resolvedBg = backgroundColor ?? AlmanacTokens.cardSurface(isDark);
            strokeWidth = 2.5;
            break;
          case IrisThemeStyle.editorialAcademic:
            resolvedColor = color ?? (isDark ? const Color(0xFFF59E0B) : const Color(0xFFC2410C));
            resolvedBg = backgroundColor ?? EditorialTokens.cardSurface(isDark);
            strokeWidth = 2.2;
            break;
          case IrisThemeStyle.notebook:
            resolvedColor = color ?? const Color(0xFF2563EB);
            resolvedBg = backgroundColor ?? (isDark ? const Color(0xFF1E222B) : const Color(0xFFFBF9F3));
            strokeWidth = 2.2;
            break;
          case IrisThemeStyle.line:
            resolvedColor = color ?? const Color(0xFF0066CC);
            resolvedBg = backgroundColor ?? (isDark ? const Color(0xFF14171E) : Colors.white);
            strokeWidth = 2.4;
            break;
          case IrisThemeStyle.poster:
            resolvedColor = color ?? (isDark ? Colors.white : Colors.black);
            resolvedBg = backgroundColor ?? (isDark ? const Color(0xFF161616) : Colors.white);
            strokeWidth = 2.8;
            break;
          case IrisThemeStyle.materialYou:
            resolvedColor = color ?? Theme.of(context).colorScheme.primary;
            resolvedBg = backgroundColor ?? Theme.of(context).colorScheme.surfaceContainerHigh;
            strokeWidth = 2.2;
            break;
          case IrisThemeStyle.fluidGlass:
            resolvedColor = color ?? IrisTokens.brand;
            resolvedBg = backgroundColor ?? (isDark ? IrisTokens.surfaceDarkElevated : Colors.white);
            strokeWidth = 2.0;
            break;
        }

        return RefreshIndicator(
          onRefresh: onRefresh,
          color: resolvedColor,
          backgroundColor: resolvedBg,
          displacement: displacement,
          edgeOffset: edgeOffset,
          strokeWidth: strokeWidth,
          child: child,
        );
      },
    );
  }
}

/// ColorOS 17 Aquamorphic 3D Gyroscopic Liquid Glass Loader.
///
/// Renders two counter-rotating 3D perspective orbital rings (`Matrix4` 3D projection)
/// around a pulsing refractive Aquamorphic Glass sphere with a specular caustic highlight
/// and an orbiting liquid droplet satellite.
class IrisThemeLoadingSpinner extends StatefulWidget {
  final Color? color;
  final double size;
  final double strokeWidth;

  const IrisThemeLoadingSpinner({
    super.key,
    this.color,
    this.size = 28,
    this.strokeWidth = 2.2,
  });

  @override
  State<IrisThemeLoadingSpinner> createState() => _IrisThemeLoadingSpinnerState();
}

class _IrisThemeLoadingSpinnerState extends State<IrisThemeLoadingSpinner>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final primaryColor = widget.color ??
        (isDark ? const Color(0xFF38BDF8) : const Color(0xFF0284C7));
    final secondaryColor = isDark
        ? const Color(0xFF818CF8)
        : const Color(0xFF4F46E5);
    final s = widget.size.clamp(16.0, 96.0);

    return RepaintBoundary(
      child: SizedBox(
        width: s,
        height: s,
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, _) {
            final t = _controller.value;
            final angle = t * 2 * math.pi;
            final pulse = 0.88 + 0.14 * math.sin(angle * 2);
            final coreSize = s * 0.44 * pulse;
            final orbitRadius = s * 0.38;
            final satX = math.cos(angle * 2) * orbitRadius;
            final satY = math.sin(angle * 2) * (orbitRadius * 0.52);

            return Stack(
              alignment: Alignment.center,
              children: [
                // 1. Ambient 3D Aquamorphic Glow Halo
                Container(
                  width: s * 0.72,
                  height: s * 0.72,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: primaryColor.withValues(alpha: isDark ? 0.32 : 0.20),
                        blurRadius: s * 0.40,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                ),

                // 2. Outer 3D Gyroscopic Ring (Perspective X/Y + Z spin)
                Transform(
                  alignment: Alignment.center,
                  transform: Matrix4.identity()
                    ..setEntry(3, 2, 0.0028)
                    ..rotateX(0.95 + 0.25 * math.sin(angle))
                    ..rotateY(0.35 * math.cos(angle))
                    ..rotateZ(angle),
                  child: Container(
                    width: s * 0.92,
                    height: s * 0.92,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: primaryColor.withValues(alpha: isDark ? 0.78 : 0.72),
                        width: (widget.strokeWidth * 0.95).clamp(1.4, 3.2),
                      ),
                    ),
                  ),
                ),

                // 3. Inner Counter-Rotating 3D Gyroscopic Ring
                Transform(
                  alignment: Alignment.center,
                  transform: Matrix4.identity()
                    ..setEntry(3, 2, 0.0028)
                    ..rotateY(1.02 + 0.25 * math.cos(angle))
                    ..rotateX(-0.35 * math.sin(angle))
                    ..rotateZ(-angle * 1.3),
                  child: Container(
                    width: s * 0.78,
                    height: s * 0.78,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: secondaryColor.withValues(alpha: isDark ? 0.70 : 0.62),
                        width: (widget.strokeWidth * 0.80).clamp(1.2, 2.8),
                      ),
                    ),
                  ),
                ),

                // 4. Central 3D Refractive Liquid Glass Sphere with Specular Caustic
                Container(
                  width: coreSize,
                  height: coreSize,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      center: const Alignment(-0.35, -0.38),
                      radius: 0.85,
                      colors: [
                        Colors.white.withValues(alpha: 0.95),
                        primaryColor.withValues(alpha: 0.90),
                        secondaryColor.withValues(alpha: 0.92),
                      ],
                      stops: const [0.0, 0.52, 1.0],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: primaryColor.withValues(alpha: 0.45),
                        blurRadius: s * 0.22,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                ),

                // 5. Orbiting 3D Liquid Droplet Satellite
                Transform.translate(
                  offset: Offset(satX, satY),
                  child: Container(
                    width: (s * 0.16).clamp(3.5, 10.0),
                    height: (s * 0.16).clamp(3.5, 10.0),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: primaryColor.withValues(alpha: 0.80),
                          blurRadius: 6,
                          spreadRadius: 0.5,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class IrisComponents {
  /// Build a theme-adaptive RefreshIndicator that dynamically configures
  /// the pull-to-refresh color, background surface color, stroke width, and displacement
  /// relative to the active theme.
  static Widget refreshIndicator({
    required Future<void> Function() onRefresh,
    required Widget child,
    Color? color,
    Color? backgroundColor,
    double displacement = 40.0,
    double edgeOffset = 0.0,
  }) {
    return IrisRefreshIndicator(
      onRefresh: onRefresh,
      color: color,
      backgroundColor: backgroundColor,
      displacement: displacement,
      edgeOffset: edgeOffset,
      child: child,
    );
  }

  /// Build a status badge (LIVE, NEXT, etc.)
  static Widget statusBadge({
    required String label,
    required Color color,
    required bool isDark,
    bool pulse = false,
  }) {
    final widget = ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, themeStyle, _) {
        if (themeStyle == IrisThemeStyle.almanac) {
          return Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 8,
              vertical: 3,
            ),
            decoration: BoxDecoration(
              color: color.withValues(alpha: isDark ? 0.22 : 0.12),
              border: Border.all(
                color: color,
                width: 1.0,
              ),
            ),
            child: Text(
              label.toUpperCase(),
              style: AlmanacTokens.monoHeader(
                isDark,
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: color,
                letterSpacing: 1.0,
              ),
            ),
          );
        }

        if (themeStyle == IrisThemeStyle.editorialAcademic) {
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3.5),
            decoration: BoxDecoration(
              color: color.withValues(alpha: isDark ? 0.22 : 0.12),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: color.withValues(alpha: isDark ? 0.50 : 0.35),
                width: 1.0,
              ),
            ),
            child: Text(
              label.toUpperCase(),
              style: GoogleFonts.plusJakartaSans(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: color,
                letterSpacing: 0.8,
              ),
            ),
          );
        }

        if (themeStyle == IrisThemeStyle.notebook) {
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2.5),
            decoration: BoxDecoration(
              color: color.withValues(alpha: isDark ? 0.25 : 0.15),
              borderRadius: BorderRadius.circular(4),
              border: Border.all(
                color: color,
                width: 1.2,
              ),
            ),
            child: Text(
              label.toUpperCase(),
              style: GoogleFonts.patrickHand(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: color,
                letterSpacing: 0.5,
              ),
            ),
          );
        }

        if (themeStyle == IrisThemeStyle.line) {
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: color.withValues(alpha: isDark ? 0.25 : 0.15),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: color,
                width: 1.2,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 5,
                  height: 5,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: color,
                  ),
                ),
                const SizedBox(width: 4),
                Text(
                  label.toUpperCase(),
                  style: GoogleFonts.inter(
                    fontSize: 9.5,
                    fontWeight: FontWeight.w800,
                    color: color,
                    letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
          );
        }

        if (themeStyle == IrisThemeStyle.poster) {
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
            decoration: BoxDecoration(
              color: color,
              border: Border.all(
                color: isDark ? Colors.white : Colors.black,
                width: 1.5,
              ),
            ),
            child: Text(
              label.toUpperCase(),
              style: GoogleFonts.archivoBlack(
                fontSize: 9.5,
                color: isDark ? Colors.black : Colors.white,
                letterSpacing: 0.5,
              ),
            ),
          );
        }

        if (themeStyle == IrisThemeStyle.materialYou) {
          return Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 4,
            ),
            decoration: BoxDecoration(
              color: color.withValues(alpha: isDark ? 0.20 : 0.12),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: color.withValues(alpha: isDark ? 0.45 : 0.35),
                width: 1.0,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: color,
                  ),
                ),
                const SizedBox(width: 5),
                Text(
                  label.toUpperCase(),
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.8,
                    color: color,
                    height: 1.1,
                  ),
                ),
              ],
            ),
          );
        }

        final useMinimal = ThemeSignals.useMinimalTheme.value;
        return Container(
          padding: const EdgeInsets.symmetric(
            horizontal: IrisTokens.space12,
            vertical: IrisTokens.space8 - 2,
          ),
          decoration: useMinimal
              ? BoxDecoration(
                  color: MinimalTokens.primary,
                  borderRadius: BorderRadius.circular(IrisTokens.radius12),
                )
              : BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [color, color.withValues(alpha: 0.85)],
                  ),
                  borderRadius: BorderRadius.circular(IrisTokens.radius12),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.3),
                    width: 1.2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: color.withValues(alpha: 0.28),
                      blurRadius: 8,
                      spreadRadius: -2,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.8,
              color: Colors.white,
              height: 1.0,
            ),
          ),
        );
      },
    );

    if (pulse) {
      return TweenAnimationBuilder<double>(
        tween: Tween(begin: 0.95, end: 1.05),
        duration: const Duration(milliseconds: 768),
        curve: IrisMotion.standard,
        builder: (context, scale, child) =>
            Transform.scale(scale: scale, child: child),
        onEnd: () {},
        child: widget,
      );
    }

    return widget;
  }

  /// Build a time badge
  static Widget timeBadge({required String time, required bool isDark}) {
    return ValueListenableBuilder<bool>(
      valueListenable: ThemeSignals.useMinimalTheme,
      builder: (context, useMinimal, _) {
        return Container(
          padding: const EdgeInsets.symmetric(
            horizontal: IrisTokens.space12,
            vertical: IrisTokens.space8 - 2,
          ),
          decoration: useMinimal
              ? BoxDecoration(
                  color: isDark ? Colors.white12 : Colors.black12,
                  borderRadius: BorderRadius.circular(IrisTokens.radius12),
                )
              : BoxDecoration(
                  color: isDark
                      ? Colors.white.withValues(alpha: 0.20)
                      : Colors.white.withValues(alpha: 0.92),
                  borderRadius: BorderRadius.circular(IrisTokens.radius12),
                  border: Border.all(
                    color: isDark
                        ? Colors.white.withValues(alpha: 0.24)
                        : Colors.black.withValues(alpha: 0.12),
                    width: 1,
                  ),
                ),
          child: Text(
            time,
            style: TextStyle(
              fontSize: 11,
              letterSpacing: 0.3,
              fontWeight: FontWeight.w700,
              height: 1.0,
              color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.86),
            ),
          ),
        );
      },
    );
  }

  /// Build an icon badge
  static Widget iconBadge({
    required IconData icon,
    required Color color,
    required bool isDark,
    double size = 32,
  }) {
    return Container(
      padding: EdgeInsets.all(size * 0.25),
      decoration: BoxDecoration(
        color: color.withValues(alpha: isDark ? 0.32 : 0.16),
        shape: BoxShape.circle,
        border: Border.all(color: color.withValues(alpha: 0.4), width: 1.2),
      ),
      child: Icon(icon, size: size * 0.65, color: color),
    );
  }

  /// Extracts clean 2-letter monogram initials from a faculty name
  static String extractMonogramInitials(String name) {
    final clean = HelpdeskFacultyService.stripDepartmentPrefix(name).trim();
    final tokens = HelpdeskFacultyService.extractCoreTokens(clean);
    if (tokens.isEmpty) {
      final words = clean.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
      if (words.isEmpty) return 'F';
      if (words.length == 1) return words.first.substring(0, math.min(2, words.first.length)).toUpperCase();
      return '${words.first[0]}${words.last[0]}'.toUpperCase();
    }
    if (tokens.length == 1) {
      final t = tokens.first;
      return t.substring(0, math.min(2, t.length)).toUpperCase();
    }
    return '${tokens.first[0]}${tokens.last[0]}'.toUpperCase();
  }

  /// Curated department gradient for vibrant typographic badges
  static List<Color> departmentGradient(String department, {bool isDark = true}) {
    final d = HelpdeskFacultyService.normalizeDepartment(department);
    switch (d) {
      case 'cs':
        return [const Color(0xFF06B6D4), const Color(0xFF3B82F6)]; // Cyan to Blue
      case 'ms':
        return [const Color(0xFF8B5CF6), const Color(0xFFEC4899)]; // Violet to Pink
      case 'bio':
        return [const Color(0xFF10B981), const Color(0xFF059669)]; // Emerald to Teal
      case 'ee':
      case 'mech':
      case 'civil':
        return [const Color(0xFFF59E0B), const Color(0xFFEA580C)]; // Amber to Orange
      case 'math':
        return [const Color(0xFFF43F5E), const Color(0xFFBE123C)]; // Rose to Crimson
      case 'hum':
        return [const Color(0xFF6366F1), const Color(0xFF4F46E5)]; // Indigo
      default:
        return [const Color(0xFF3B82F6), const Color(0xFF8B5CF6)]; // Blue to Violet
    }
  }

  /// State-of-the-art typographic monogram badge for faculty profiles
  static Widget facultyMonogramBadge({
    required String name,
    String department = '',
    double size = 48,
    bool isDark = true,
  }) {
    final initials = extractMonogramInitials(name);
    final rawHonorific = HelpdeskFacultyService.extractHonorificCategory(name).toUpperCase();
    final honorific = rawHonorific == 'DR'
        ? 'DR'
        : (rawHonorific == 'ENGR' ? 'ENG' : rawHonorific);
    final gradientColors = departmentGradient(department, isDark: isDark);

    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: gradientColors.map((c) => c.withValues(alpha: isDark ? 0.30 : 0.16)).toList(),
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(size * 0.30),
              border: Border.all(
                color: gradientColors.first.withValues(alpha: isDark ? 0.45 : 0.35),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: gradientColors.first.withValues(alpha: isDark ? 0.18 : 0.08),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Center(
              child: Text(
                initials,
                style: TextStyle(
                  fontSize: size * 0.38,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.4,
                  color: isDark ? Colors.white : gradientColors.last,
                ),
              ),
            ),
          ),
          if (honorific.isNotEmpty)
            Positioned(
              right: -2,
              bottom: -2,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 4.0, vertical: 1.0),
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF0F172A) : Colors.white,
                  borderRadius: BorderRadius.circular(5),
                  border: Border.all(
                    color: gradientColors.first.withValues(alpha: 0.6),
                    width: 0.9,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.12),
                      blurRadius: 3,
                      offset: const Offset(0, 1),
                    ),
                  ],
                ),
                child: Text(
                  honorific,
                  style: TextStyle(
                    fontSize: 8.0,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.3,
                    color: gradientColors.first,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  /// Build a faculty avatar with modern typographic monogram fallback
  static Widget facultyAvatar({
    required String? imageUrl,
    required String gender,
    required String name,
    String department = '',
    double radius = 24,
    bool isDark = true,
  }) {
    if (imageUrl == null || imageUrl.trim().isEmpty) {
      return facultyMonogramBadge(
        name: name,
        department: department,
        size: radius * 2,
        isDark: isDark,
      );
    }

    final isFemale = gender.toLowerCase() == 'female';
    final accentColor = isFemale ? IrisTokens.purple : IrisTokens.blue;

    return Container(
      width: radius * 2,
      height: radius * 2,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: accentColor.withValues(alpha: isDark ? 0.2 : 0.1),
        border: Border.all(
          color: accentColor.withValues(alpha: 0.3),
          width: 1.5,
        ),
      ),
      child: ClipOval(
        child: imageUrl.startsWith('assets/')
            ? Image.asset(
                imageUrl,
                fit: BoxFit.cover,
                cacheWidth: 200,
                cacheHeight: 200,
                errorBuilder: (context, error, stackTrace) =>
                    facultyMonogramBadge(name: name, department: department, size: radius * 2, isDark: isDark),
              )
            : Image.network(
                imageUrl,
                fit: BoxFit.cover,
                cacheWidth: (radius * 3).round(),
                cacheHeight: (radius * 3).round(),
                errorBuilder: (context, error, stackTrace) =>
                    facultyMonogramBadge(name: name, department: department, size: radius * 2, isDark: isDark),
                loadingBuilder: (context, child, loadingProgress) {
                  if (loadingProgress == null) return child;
                  return facultyMonogramBadge(name: name, department: department, size: radius * 2, isDark: isDark);
                },
              ),
      ),
    );
  }

  /// Build a loading spinner
  static Widget loadingSpinner({
    Color? color,
    double size = 24,
    double strokeWidth = 2.0,
  }) {
    if (ThemeSignals.isMaterialYou) {
      return M3ELoadingIndicator(
        size: size,
        color: color,
      );
    }
    return IrisThemeLoadingSpinner(
      color: color,
      size: size,
      strokeWidth: strokeWidth,
    );
  }

  /// Build a Quick Action Button for the iOS 18 style grid
  static Widget quickActionButton({
    required String label,
    required IconData icon,
    required Color color,
    required bool isDark,
    required VoidCallback onTap,
  }) {
    return AnimatedButton(
      onPressed: onTap,
      child: ValueListenableBuilder<bool>(
        valueListenable: ThemeSignals.useMinimalTheme,
        builder: (context, useMinimal, _) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  color: useMinimal ? Colors.transparent : (isDark
                      ? Colors.white.withValues(alpha: 0.08)
                      : Colors.white.withValues(alpha: 0.95)),
                  borderRadius: BorderRadius.circular(ThemeSignals.isMaterialYou ? 18 : 24),
                ),
                child: Icon(icon, color: color, size: 26),
              ),
              const SizedBox(height: 8),
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.9),
                  letterSpacing: 0.2,
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  /// Canonical settings tile used across the app
  static Widget settingsTile({
    required BuildContext context,
    required bool isDark,
    required String title,
    required String subtitle,
    required IconData icon,
    required VoidCallback? onTap,
  }) {
    return ValueListenableBuilder<bool>(
      valueListenable: ThemeSignals.useMinimalTheme,
      builder: (context, useMinimal, _) {
        return ListTile(
          onTap: onTap,
          contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
          leading: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: useMinimal ? Colors.transparent : IrisTokens.brand.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: IrisTokens.brand, size: 24),
          ),
          title: Text(title, style: IrisTextStyles.settingTitle(context)),
          subtitle: Text(subtitle, style: IrisTextStyles.settingSubtitle(context)),
          trailing: onTap != null ? Icon(Icons.chevron_right_rounded, color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.2)) : null,
        );
      },
    );
  }

  /// Canonical settings toggle tile used across the app
  static Widget settingsToggle({
    required BuildContext context,
    required bool isDark,
    required String title,
    required String subtitle,
    required IconData icon,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return ValueListenableBuilder<bool>(
      valueListenable: ThemeSignals.useMinimalTheme,
      builder: (context, useMinimal, _) {
        return ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
          leading: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: useMinimal ? Colors.transparent : IrisTokens.brand.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: IrisTokens.brand, size: 24),
          ),
          title: Text(title, style: IrisTextStyles.settingTitle(context)),
          subtitle: Text(subtitle, style: IrisTextStyles.settingSubtitle(context)),
          trailing: IrisGlassSwitch(
            value: value,
            onChanged: (v) {
              IrisHaptics.chipSelect();
              onChanged(v);
            },
            activeColor: IrisTokens.brand,
          ),
        );
      },
    );
  }
}

class RippleEffect extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  final Color? rippleColor;
  final BorderRadius? borderRadius;

  const RippleEffect({
    required this.child,
    this.onTap,
    this.rippleColor,
    this.borderRadius,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        splashColor: rippleColor ?? IrisTokens.brand.withValues(alpha: 0.12),
        highlightColor: Colors.transparent,
        borderRadius: borderRadius ?? BorderRadius.circular(IrisTokens.radius16),
        child: child,
      ),
    );
  }
}

class AnimatedButton extends StatelessWidget {
  final Widget child;
  final VoidCallback? onPressed;
  final Duration duration;

  const AnimatedButton({
    required this.child,
    this.onPressed,
    this.duration = const Duration(milliseconds: 150),
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    if (!ThemeSignals.isFluidGlass) {
      return ExpressiveInteractivePress(
        onTap: () {
          IrisHaptics.actionMedium();
          onPressed?.call();
        },
        pressedScale: 0.94,
        child: child,
      );
    }
    return GlassButton.custom(
      onTap: () {
        onPressed?.call();
      },
      useOwnLayer: true,
      quality: IrisGlass.adaptiveQuality(context),
      style: GlassButtonStyle.transparent,
      stretch: 0.25, // subtle stretch feel
      child: child,
    );
  }
}

class StaggeredListItem extends StatelessWidget {
  final int index;
  final Widget child;
  final Duration? delay;

  const StaggeredListItem({
    required this.index,
    required this.child,
    this.delay,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedListItem(index: index, child: child);
  }
}

class AppBackButton extends StatelessWidget {
  final bool isDark;
  final VoidCallback? onPressed;

  const AppBackButton({required this.isDark, this.onPressed, super.key});

  @override
  Widget build(BuildContext context) {
    final style = ThemeSignals.themeStyle.value;
    if (style == IrisThemeStyle.almanac) {
      final ruleCol = AlmanacTokens.inkRule(isDark);
      return Padding(
        padding: const EdgeInsets.only(left: 12),
        child: Center(
          child: GestureDetector(
            onTap: () {
              IrisHaptics.selectionClick();
              (onPressed ?? () => Navigator.of(context).pop())();
            },
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: AlmanacTokens.cardSurface(isDark),
                border: Border.all(color: ruleCol, width: 1.2),
              ),
              child: Icon(
                Icons.arrow_back_rounded,
                size: 18,
                color: AlmanacTokens.inkHeading(isDark),
              ),
            ),
          ),
        ),
      );
    }
    if (style == IrisThemeStyle.editorialAcademic) {
      return Padding(
        padding: const EdgeInsets.only(left: 12),
        child: Center(
          child: ExpressiveInteractivePress(
            onTap: () {
              IrisHaptics.selectionClick();
              (onPressed ?? () => Navigator.of(context).pop())();
            },
            child: Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: EditorialTokens.chipSurface(isDark),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: EditorialTokens.cardBorder(isDark)),
              ),
              child: Icon(
                Icons.arrow_back_ios_new_rounded,
                size: 16,
                color: EditorialTokens.inkHeading(isDark),
              ),
            ),
          ),
        ),
      );
    }
    if (style == IrisThemeStyle.notebook) {
      return Padding(
        padding: const EdgeInsets.only(left: 12),
        child: Center(
          child: ExpressiveInteractivePress(
            onTap: () {
              IrisHaptics.selectionClick();
              (onPressed ?? () => Navigator.of(context).pop())();
            },
            child: Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: NotebookTokens.stickyNote(isDark),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: NotebookTokens.redDoodle(isDark),
                  width: 1.4,
                ),
              ),
              child: const Icon(
                Icons.arrow_back_rounded,
                size: 18,
                color: Color(0xFF1A1F1C),
              ),
            ),
          ),
        ),
      );
    }
    if (style == IrisThemeStyle.line) {
      return Padding(
        padding: const EdgeInsets.only(left: 12),
        child: Center(
          child: ExpressiveInteractivePress(
            onTap: () {
              IrisHaptics.selectionClick();
              (onPressed ?? () => Navigator.of(context).pop())();
            },
            child: Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: LineTokens.subwayYellow,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.black, width: 2.0),
              ),
              child: const Icon(
                Icons.arrow_back_rounded,
                size: 18,
                color: Colors.black,
              ),
            ),
          ),
        ),
      );
    }
    if (style == IrisThemeStyle.poster) {
      final borderCol = PosterTokens.inkBorder(isDark);
      return Padding(
        padding: const EdgeInsets.only(left: 12),
        child: Center(
          child: ExpressiveInteractivePress(
            onTap: () {
              IrisHaptics.selectionClick();
              (onPressed ?? () => Navigator.of(context).pop())();
            },
            child: Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: PosterTokens.orangeHero,
                border: Border.all(color: Colors.black, width: 2.2),
                boxShadow: [
                  BoxShadow(
                    color: borderCol,
                    offset: const Offset(2, 2),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: const Icon(
                Icons.arrow_back_rounded,
                size: 18,
                color: Colors.black,
              ),
            ),
          ),
        ),
      );
    }
    if (ThemeSignals.isMaterialYou) {
      final cs = Theme.of(context).colorScheme;
      return Padding(
        padding: const EdgeInsets.only(left: 12),
        child: ExpressiveSpringPress(
          onTap: onPressed ?? () => Navigator.of(context).pop(),
          child: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: cs.surfaceContainerHigh,
              shape: BoxShape.circle,
              border: Border.all(
                color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.6),
                width: 1.0,
              ),
            ),
            child: Icon(
              Icons.arrow_back_ios_new_rounded,
              size: 16,
              color: cs.onSurface,
            ),
          ),
        ),
      );
    }
    if (ThemeSignals.isFluidGlass) {
      return Padding(
        padding: const EdgeInsets.only(left: 12),
        child: Center(
          child: GlassButton.custom(
            onTap: () {
              IrisHaptics.actionSoft();
              (onPressed ?? () => Navigator.of(context).pop())();
            },
            width: 38,
            height: 38,
            useOwnLayer: true,
            quality: IrisGlass.adaptiveQuality(context),
            shape: const lgw.LiquidOval(),
            settings: IrisGlass.widgetsSettings(
              context,
              blur: 14.0,
              thickness: 12.0,
              ambientStrength: 0.72,
            ),
            child: Icon(
              Icons.arrow_back_ios_new_rounded,
              size: 16,
              color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.88),
            ),
          ),
        ),
      );
    }
    return Padding(
      padding: const EdgeInsets.only(left: 12),
      child: IconButton(
        onPressed: onPressed ?? () => Navigator.of(context).pop(),
        icon: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.05),
            shape: BoxShape.circle,
            border: Border.all(
              color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.1),
              width: 1,
            ),
          ),
          child: Icon(
            Icons.arrow_back_ios_new_rounded,
            size: 18,
            color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.8),
          ),
        ),
      ),
    );
  }
}

class NavActiveHalo extends StatefulWidget {
  final double size;
  final Color color;

  const NavActiveHalo({required this.size, required this.color, super.key});

  @override
  State<NavActiveHalo> createState() => _NavActiveHaloState();
}

class _NavActiveHaloState extends State<NavActiveHalo>
    with SingleTickerProviderStateMixin {
  late final AnimationController _entranceCtrl;
  late final Animation<double> _entrance;

  @override
  void initState() {
    super.initState();
    _entranceCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _entrance = CurvedAnimation(
      parent: _entranceCtrl,
      curve: IrisMotion.entrance,
    );
    _entranceCtrl.forward();
  }

  @override
  void dispose() {
    _entranceCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _entrance,
      builder: (context, _) {
        final e = _entrance.value;
        return Transform.scale(
          scale: e,
          child: Opacity(
            opacity: e.clamp(0.0, 1.0),
            child: Container(
              width: widget.size,
              height: widget.size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    widget.color.withValues(alpha: 0.16),
                    widget.color.withValues(alpha: 0.05),
                    Colors.transparent,
                  ],
                  stops: const [0.0, 0.72, 1.0],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class BouncyNavButton extends StatefulWidget {
  final IconData icon;
  final String label;
  final bool isDark;
  final bool isSelected;
  final bool enabled;
  final bool showLabelAlways;
  final bool showIndicator;
  final int? indicatorCount;
  final Color? indicatorColor;
  final Color activeColor;
  final bool showSelectionBackground;
  final VoidCallback onTap;
  final GlobalKey? launchIconKey;

  const BouncyNavButton({
    super.key,
    required this.icon,
    required this.label,
    required this.isDark,
    required this.isSelected,
    this.enabled = true,
    this.showLabelAlways = false,
    this.showIndicator = false,
    this.indicatorCount,
    this.indicatorColor,
    required this.activeColor,
    this.showSelectionBackground = true,
    required this.onTap,
    this.launchIconKey,
  });

  @override
  State<BouncyNavButton> createState() => _BouncyNavButtonState();
}

class _BouncyNavButtonState extends State<BouncyNavButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _selectCtrl;
  late final Animation<double> _scaleCurve;
  late final Animation<double> _slideCurve;

  @override
  void initState() {
    super.initState();
    _selectCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 280),
    );
    _scaleCurve = Tween<double>(
      begin: 1.0,
      end: 1.04,
    ).animate(CurvedAnimation(parent: _selectCtrl, curve: IrisMotion.entrance));
    _slideCurve = Tween<double>(
      begin: 0.0,
      end: -0.85,
    ).animate(CurvedAnimation(parent: _selectCtrl, curve: IrisMotion.entrance));
    if (widget.isSelected) _selectCtrl.value = 1.0;
  }

  @override
  void didUpdateWidget(BouncyNavButton oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isSelected && !oldWidget.isSelected) {
      _selectCtrl.forward(from: 0.0);
    } else if (!widget.isSelected && oldWidget.isSelected) {
      _selectCtrl.reverse();
    }
  }

  @override
  void dispose() {
    _selectCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final baseColor = widget.isSelected
        ? widget.activeColor
        : (widget.isDark ? Colors.white38 : Colors.black38);
    final color = widget.enabled
        ? baseColor
        : baseColor.withValues(alpha: widget.isDark ? 0.48 : 0.42);
    final showLabel = widget.isSelected || widget.showLabelAlways;
    final indicatorColor = widget.indicatorColor ?? widget.activeColor;
    final badgeCount = widget.indicatorCount ?? 0;
    final showCountBadge = badgeCount > 0 && !widget.isSelected;
    final badgeText = badgeCount > 9 ? '9+' : '$badgeCount';

    Widget buildIcon(double size, bool veryCompact) {
      return Container(
        key: widget.launchIconKey,
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 192),
              switchInCurve: IrisMotion.entrance,
              switchOutCurve: IrisMotion.standard,
              transitionBuilder: (child, animation) =>
                  ScaleTransition(scale: animation, child: child),
              child: Icon(
                widget.icon,
                key: ValueKey('${widget.icon.codePoint}_${widget.isSelected}'),
                color: color,
                size: size,
              ),
            ),
            if (widget.showIndicator && !widget.isSelected)
              Positioned(
                right: showCountBadge ? -8 : -2,
                top: showCountBadge ? -6 : -1,
                child: showCountBadge
                    ? Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 4,
                          vertical: 1,
                        ),
                        constraints: const BoxConstraints(minWidth: 14),
                        decoration: BoxDecoration(
                          color: indicatorColor,
                          borderRadius: BorderRadius.circular(999),
                          border: Border.all(
                            color: widget.isDark
                                ? IrisTokens.surfaceDarkElevated
                                : Colors.white,
                            width: 1.25,
                          ),
                        ),
                        child: Text(
                          badgeText,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 7,
                            fontWeight: FontWeight.w800,
                            height: 1.0,
                            letterSpacing: 0.1,
                          ),
                        ),
                      )
                    : Container(
                        width: veryCompact ? 7 : 8,
                        height: veryCompact ? 7 : 8,
                        decoration: BoxDecoration(
                          color: indicatorColor,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: widget.isDark
                                ? IrisTokens.surfaceDarkElevated
                                : Colors.white,
                            width: 1.25,
                          ),
                        ),
                      ),
              ),
          ],
        ),
      );
    }

    return RepaintBoundary(
      child: LayoutBuilder(
      builder: (context, constraints) {
        final slotWidth = constraints.maxWidth;
        final veryCompact = slotWidth < 56;
        final compact = slotWidth < 74;
        final roomy = slotWidth > 108;

        return AnimatedBuilder(
          animation: _selectCtrl,
          builder: (context, child) {
            final yOffset = widget.showLabelAlways
                ? (_slideCurve.value * 0.32)
                : _slideCurve.value;
            final scale = widget.showLabelAlways
                ? (1.0 + ((_scaleCurve.value - 1.0) * 0.32))
                : _scaleCurve.value;
            return Transform.translate(
              offset: Offset(0, yOffset),
              child: Transform.scale(scale: scale, child: child),
            );
          },
          child: GestureDetector(
            onTap: () {
              if (widget.enabled) {
                IrisHaptics.selectionClick();
                widget.onTap();
              }
            },
            child: Container(
              padding: EdgeInsets.symmetric(
                horizontal: widget.showLabelAlways
                    ? (veryCompact ? 2 : (compact ? 3 : 6))
                    : (veryCompact ? 3 : (compact ? 4 : (roomy ? 10 : 7))),
                vertical: widget.showLabelAlways
                    ? (veryCompact ? 4 : 5)
                    : (veryCompact ? 4 : (compact ? 5 : 7)),
              ),
              decoration: widget.isSelected && widget.showSelectionBackground
                  ? BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          widget.activeColor.withValues(alpha: 0.28),
                          widget.activeColor.withValues(alpha: 0.12),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(
                        color: widget.activeColor.withValues(alpha: 0.20),
                        width: 1.2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: widget.activeColor.withValues(alpha: 0.18),
                          blurRadius: 12,
                          spreadRadius: -2,
                        ),
                      ],
                    )
                  : null,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  buildIcon(
                    veryCompact ? 18 : (compact ? 20 : (roomy ? 24 : 22)),
                    veryCompact,
                  ),
                  if (showLabel) ...[
                    SizedBox(width: veryCompact ? 4 : (compact ? 6 : 10)),
                    Flexible(
                      child: Text(
                        widget.label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: color,
                          fontSize: veryCompact ? 10 : (compact ? 11 : 13),
                          fontWeight: widget.isSelected
                              ? FontWeight.w900
                              : FontWeight.w700,
                          letterSpacing: widget.isSelected ? 0.3 : 0.1,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    ),);
  }
}

class GlassShimmer extends StatefulWidget {
  const GlassShimmer({super.key});

  @override
  State<GlassShimmer> createState() => _GlassShimmerState();
}

class _GlassShimmerState extends State<GlassShimmer>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _curve;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3456),
    )..repeat();
    _curve = CurvedAnimation(parent: _controller, curve: IrisMotion.standard);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            final shift = (_curve.value * 2) - 1;
            return FractionalTranslation(
              translation: Offset(shift, 0),
              child: child,
            );
          },
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.white.withValues(alpha: 0.0),
                  Colors.white.withValues(alpha: 0.25),
                  Colors.white.withValues(alpha: 0.0),
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class SectionHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final Color statusIndicator;

  const SectionHeader({
    required this.title,
    required this.subtitle,
    required this.statusIndicator,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, themeStyle, _) {
        if (themeStyle == IrisThemeStyle.almanac) {
          final ruleCol = AlmanacTokens.inkRule(isDark);
          final terra = AlmanacTokens.accentTerracotta(isDark);
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: AlmanacTokens.cardSurface(isDark),
                border: Border(
                  top: BorderSide(color: ruleCol, width: 1.5),
                  bottom: BorderSide(color: ruleCol, width: 1.0),
                ),
              ),
              child: Row(
                children: [
                  Container(width: 8, height: 8, color: terra),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title.toUpperCase(),
                          style: AlmanacTokens.monoHeader(isDark, fontSize: 10, color: terra),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          subtitle,
                          style: AlmanacTokens.serifHeadline(isDark, fontSize: 16),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        }
        if (themeStyle == IrisThemeStyle.editorialAcademic) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: EditorialTokens.cardSurface(isDark),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: EditorialTokens.cardBorder(isDark)),
                boxShadow: EditorialTokens.cardShadow(isDark, elevation: 1),
              ),
              child: Row(
                children: [
                  Container(
                    width: 4,
                    height: 32,
                    decoration: BoxDecoration(
                      color: statusIndicator,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title.toUpperCase(),
                          style: EditorialTokens.monoLabel(isDark, fontSize: 10, color: statusIndicator),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          subtitle,
                          style: EditorialTokens.headingSerif(isDark, fontSize: 16),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        }
        if (themeStyle == IrisThemeStyle.notebook) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: NotebookTokens.cardSurface(isDark),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: NotebookTokens.gridLine(isDark), width: 1.2),
              ),
              child: Row(
                children: [
                  Icon(Icons.edit_note_rounded, color: NotebookTokens.redDoodle(isDark), size: 22),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title.toUpperCase(),
                          style: NotebookTokens.monoTimestamp(isDark),
                        ),
                        Text(
                          subtitle,
                          style: NotebookTokens.boldScript(isDark, fontSize: 17),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        }
        if (themeStyle == IrisThemeStyle.line) {
          final rail = LineTokens.railLine(isDark);
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: LineTokens.cardSurface(isDark),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: rail, width: 1.5),
              ),
              child: Row(
                children: [
                  StationStopNode(isDark: isDark, isCurrentPosition: true, size: 18),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title.toUpperCase(), style: LineTokens.lineTag(isDark).copyWith(fontSize: 10)),
                        const SizedBox(height: 2),
                        Text(subtitle, style: LineTokens.stationName(isDark).copyWith(fontSize: 15)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        }
        if (themeStyle == IrisThemeStyle.poster) {
          final borderCol = PosterTokens.inkBorder(isDark);
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: PosterTokens.cardSurface(isDark),
                border: Border.all(color: borderCol, width: 2.2),
                boxShadow: PosterTokens.extrudedBlockShadow(isDark, offset: 3.0),
              ),
              child: Row(
                children: [
                  Container(width: 12, height: 12, color: PosterTokens.orangeHero),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title.toUpperCase(),
                          style: PosterTokens.heroOrangeTag(isDark).copyWith(
                            fontSize: 10,
                            color: PosterTokens.orangeHero,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(subtitle.toUpperCase(), style: PosterTokens.classTitle(isDark).copyWith(fontSize: 14)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        }
        if (themeStyle == IrisThemeStyle.materialYou) {
          final cs = Theme.of(context).colorScheme;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            child: M3ECard(
              variant: M3ECardVariant.filled,
              color: cs.surfaceContainerLow,
              borderRadius: BorderRadius.circular(20),
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
              child: Row(
                children: [
                  Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      color: statusIndicator,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: statusIndicator.withValues(alpha: 0.4),
                          blurRadius: 6,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: statusIndicator.withValues(alpha: isDark ? 0.22 : 0.12),
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Text(
                                title.toUpperCase(),
                                style: TextStyle(
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.8,
                                  fontSize: 9.5,
                                  color: isDark ? Colors.white : cs.primary,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          subtitle,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                            color: cs.onSurface,
                            letterSpacing: -0.2,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        }

        return ValueListenableBuilder<bool>(
          valueListenable: ThemeSignals.useVitalTheme,
          builder: (context, useVital, _) {
            if (useVital && themeStyle != IrisThemeStyle.fluidGlass) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: VitalCard(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  backgroundColor: isDark ? const Color(0xFF161618) : Colors.white,
                  border: Border.all(
                    color: statusIndicator.withValues(alpha: isDark ? 0.35 : 0.25), 
                    width: 1.2,
                  ),
              child: Row(
                children: [
                  Container(
                    width: 14,
                    height: 14,
                    decoration: BoxDecoration(
                      color: statusIndicator,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: statusIndicator.withValues(alpha: 0.3),
                          blurRadius: 10,
                          spreadRadius: -2,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title.toUpperCase(),
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.5,
                            fontSize: 10,
                            color: statusIndicator.withValues(alpha: 0.8),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          subtitle,
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w900,
                            color: isDark ? Colors.white : Colors.black87,
                            letterSpacing: -0.2,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        }

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: GlassSurface(
            settings: IrisGlass.settings(
              context,
              blur: 16.0,
              thickness: 14.0,
              ambientStrength: 0.72,
              glassColor: statusIndicator.withValues(alpha: isDark ? 0.16 : 0.12),
            ),
            radius: IrisTokens.radius24,
            borderSide: BorderSide(
              color: statusIndicator.withValues(alpha: isDark ? 0.36 : 0.26),
              width: 1.2,
            ),
            child: Container(
              padding: const EdgeInsets.all(IrisTokens.space20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  statusIndicator.withValues(
                    alpha: isDark ? 0.26 : 0.18,
                  ),
                  statusIndicator.withValues(
                    alpha: isDark ? 0.14 : 0.10,
                  ),
                ],
              ),
              borderRadius: BorderRadius.circular(IrisTokens.radius24),
              border: Border.all(
                color: statusIndicator.withValues(
                  alpha: isDark ? 0.34 : 0.24,
                ),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: statusIndicator.withValues(alpha: 0.08),
                  offset: const Offset(0, 8),
                  blurRadius: 20,
                  spreadRadius: -14,
                ),
                BoxShadow(
                  color: Colors.black.withValues(alpha: isDark ? 0.14 : 0.05),
                  offset: const Offset(0, 3),
                  blurRadius: 12,
                  spreadRadius: -6,
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 16,
                  height: 16,
                  decoration: BoxDecoration(
                    color: statusIndicator.withValues(alpha: 0.95),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: statusIndicator.withValues(
                          alpha: 0.18,
                        ),
                        blurRadius: 6,
                        spreadRadius: -3,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title.toUpperCase(),
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.8,
                          fontSize: 10,
                          height: 1.4,
                          color: (isDark ? Colors.white : Colors.black)
                              .withValues(alpha: 0.66),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          letterSpacing: -0.2,
                          color: (isDark ? Colors.white : Colors.black)
                              .withValues(alpha: 0.90),
                          height: 1.22,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          ),
        );
      },
    );
      },
    );
  }
}

/// Flagship Material 3 Expressive large header for primary tabs & screens.
/// Features an overline pill badge, bold title, subtitle, and tactile trailing action cluster.
class M3EHeaderLarge extends StatelessWidget {
  final String title;
  final String? subtitle;
  final String? overlineBadge;
  final Color? badgeColor;
  final Color? badgeTextColor;
  final Widget? trailing;
  final IconData? actionIcon;
  final VoidCallback? onAction;
  final String? actionTooltip;

  const M3EHeaderLarge({
    super.key,
    required this.title,
    this.subtitle,
    this.overlineBadge,
    this.badgeColor,
    this.badgeTextColor,
    this.trailing,
    this.actionIcon,
    this.onAction,
    this.actionTooltip,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                if (overlineBadge != null && overlineBadge!.isNotEmpty) ...[
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3.5),
                    decoration: BoxDecoration(
                      color: badgeColor ?? cs.primaryContainer,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      overlineBadge!.toUpperCase(),
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                        color: badgeTextColor ?? cs.onPrimaryContainer,
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                ],
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -0.5,
                    height: 1.15,
                    color: cs.onSurface,
                  ),
                ),
                if (subtitle != null && subtitle!.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(
                    subtitle!,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: cs.onSurfaceVariant,
                      letterSpacing: 0.1,
                    ),
                  ),
                ],
              ],
            ),
          ),
          if (trailing != null)
            trailing!
          else if (actionIcon != null)
            ExpressiveSpringPress(
              onTap: onAction,
              child: Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: cs.surfaceContainerHigh,
                  borderRadius: BorderRadius.circular(21),
                  border: Border.all(
                    color: cs.outlineVariant.withValues(alpha: 0.6),
                    width: 1.0,
                  ),
                ),
                child: Icon(
                  actionIcon,
                  size: 20,
                  color: cs.onSurface,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// Compact Material 3 Expressive header with live connection beacon.
class M3EHeaderMedium extends StatelessWidget {
  final String title;
  final String? subtitle;
  final bool isLive;
  final Widget? trailing;

  const M3EHeaderMedium({
    super.key,
    required this.title,
    this.subtitle,
    this.isLive = false,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              if (isLive) ...[
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: Color(0xFF10B981),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Color(0xFF10B981),
                        blurRadius: 6,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
              ],
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.3,
                      color: cs.onSurface,
                    ),
                  ),
                  if (subtitle != null) ...[
                    const SizedBox(height: 2),
                    Text(
                      subtitle!,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        color: cs.onSurfaceVariant,
                      ),
                    ),
                  ],
                ],
              ),
            ],
          ),
          ?trailing,
        ],
      ),
    );
  }
}

/// Authentic Material 3 Expressive stadium search bar with spring press feedback.
class M3ESearchBar extends StatelessWidget {
  final TextEditingController? controller;
  final String hintText;
  final ValueChanged<String>? onChanged;
  final VoidCallback? onClear;
  final Widget? leading;
  final Widget? trailing;

  const M3ESearchBar({
    super.key,
    this.controller,
    this.hintText = 'Search...',
    this.onChanged,
    this.onClear,
    this.leading,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;

    return RepaintBoundary(
      child: Container(
        height: 48,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: cs.surfaceContainerHigh,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(
          color: cs.outlineVariant.withValues(alpha: 0.6),
          width: 1.0,
        ),
      ),
      child: Row(
        children: [
          leading ?? Icon(Icons.search_rounded, size: 20, color: cs.onSurfaceVariant),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              controller: controller,
              onChanged: onChanged,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: cs.onSurface,
              ),
              decoration: InputDecoration(
                isDense: true,
                border: InputBorder.none,
                hintText: hintText,
                hintStyle: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  color: cs.onSurfaceVariant.withValues(alpha: 0.7),
                ),
              ),
            ),
          ),
          if (trailing != null)
            trailing!
          else if (controller != null && controller!.text.isNotEmpty)
            ExpressiveSpringPress(
              onTap: () {
                controller?.clear();
                onClear?.call();
                onChanged?.call('');
              },
              child: Icon(Icons.close_rounded, size: 18, color: cs.onSurfaceVariant),
            ),
        ],
      ),
    ),);
  }
}
