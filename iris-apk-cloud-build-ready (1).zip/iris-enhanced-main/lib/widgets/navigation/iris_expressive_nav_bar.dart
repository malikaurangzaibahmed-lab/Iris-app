import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import '../../core/glass.dart';
import '../../core/theme_signals.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../../core/laminar_flow.dart';
import '../../services/ui_feedback.dart';

/// A destination item for [IrisExpressiveNavBar].
class ExpressiveNavDestination {
  final IconData icon;
  final IconData activeIcon;
  final String label;

  const ExpressiveNavDestination({
    required this.icon,
    required this.activeIcon,
    required this.label,
  });
}

/// Dynamic multi-theme Navigation Bar for IRIS.
///
/// - **Material 3 Expressive (`materialYou`)**:
///   Pure minimal Material 3 Expressive floating dock with smooth sliding tonal pill
///   (`secondaryContainer`), crisp icon + label typography, and 120 FPS rasterization.
/// - **Liquid Glass (`fluidGlass`)**:
///   OPPO ColorOS 17 Liquid Glass capsule dock powered by `lgw.GlassButton.custom`
///   (`anchorStretch: true`, `persistPressOnDrag: true`, `GlassQuality.premium`) with a
///   translucent refractive Liquid Glass Lens indicator that tracks finger hover/glide
///   in real time, smoothly illuminating and scaling each icon + label by lens proximity
///   and selecting tabs on hover/glide.
class IrisExpressiveNavBar extends StatefulWidget {
  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;
  final bool isFaculty;
  final bool isSearchActive;
  final ValueChanged<bool>? onSearchToggle;
  final TextEditingController? searchController;
  final FocusNode? searchFocusNode;
  final ValueChanged<String>? onSearchChanged;
  final String? searchHint;
  final VoidCallback? onOpenPaletteCustomizer;

  const IrisExpressiveNavBar({
    super.key,
    required this.selectedIndex,
    required this.onDestinationSelected,
    this.isFaculty = false,
    this.isSearchActive = false,
    this.onSearchToggle,
    this.searchController,
    this.searchFocusNode,
    this.onSearchChanged,
    this.searchHint,
    this.onOpenPaletteCustomizer,
  });

  @override
  State<IrisExpressiveNavBar> createState() => _IrisExpressiveNavBarState();
}

class _IrisExpressiveNavBarState extends State<IrisExpressiveNavBar>
    with SingleTickerProviderStateMixin {
  late final AnimationController _slideController;
  late Animation<double> _slideAnimation;
  int _lastIndex = 0;

  // ColorOS 17 Liquid Glass interactive hover & glide-to-select state
  bool _isGlassPointerDown = false;
  bool _isDraggingGlass = false;
  double? _glassHoverSlot;
  int? _glassHoveredIndex;
  Offset? _pointerDownPos;
  Timer? _longPressTimer;

  List<ExpressiveNavDestination> get _destinations {
    return const [
      ExpressiveNavDestination(
        icon: Icons.calendar_month_outlined,
        activeIcon: Icons.calendar_month_rounded,
        label: 'Schedule',
      ),
      ExpressiveNavDestination(
        icon: Icons.language_outlined,
        activeIcon: Icons.language_rounded,
        label: 'Portal',
      ),
      ExpressiveNavDestination(
        icon: Icons.widgets_outlined,
        activeIcon: Icons.widgets_rounded,
        label: 'Tools',
      ),
      ExpressiveNavDestination(
        icon: Icons.tune_outlined,
        activeIcon: Icons.tune_rounded,
        label: 'Settings',
      ),
    ];
  }

  @override
  void initState() {
    super.initState();
    _lastIndex = widget.selectedIndex.clamp(0, 3);
    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 280),
    );
    _slideAnimation = Tween<double>(
      begin: _lastIndex.toDouble(),
      end: _lastIndex.toDouble(),
    ).animate(
      CurvedAnimation(
        parent: _slideController,
        curve: LaminarCurves.laminarEntrance,
      ),
    );
  }

  @override
  void didUpdateWidget(covariant IrisExpressiveNavBar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.selectedIndex != widget.selectedIndex) {
      _lastIndex = oldWidget.selectedIndex.clamp(0, 3);
      final targetIndex = widget.selectedIndex.clamp(0, 3).toDouble();
      final currentPos = _glassHoverSlot ?? _slideAnimation.value;
      _slideAnimation = Tween<double>(
        begin: currentPos,
        end: targetIndex,
      ).animate(
        CurvedAnimation(
          parent: _slideController,
          curve: LaminarCurves.laminarEntrance,
        ),
      );
      _slideController.forward(from: 0.0);
    }
  }

  @override
  void dispose() {
    _longPressTimer?.cancel();
    _slideController.dispose();
    super.dispose();
  }

  void _handleTap(int index) {
    if (widget.selectedIndex != index) {
      IrisHaptics.selectionClick();
      widget.onDestinationSelected(index);
    }
  }

  int _computeSlotIndex(
    Offset localPosition,
    double totalWidth,
    double horizontalPadding,
    int count,
  ) {
    final usableWidth = (totalWidth - horizontalPadding * 2).clamp(1.0, double.infinity);
    final slotWidth = usableWidth / count;
    return ((localPosition.dx - horizontalPadding) / slotWidth)
        .floor()
        .clamp(0, count - 1);
  }

  void _updateGlassHover(
    Offset localPosition,
    double totalWidth,
    double horizontalPadding,
    int count, {
    required bool selectOnHover,
    bool updateContinuousSlot = true,
  }) {
    final usableWidth = (totalWidth - horizontalPadding * 2).clamp(1.0, double.infinity);
    final slotWidth = usableWidth / count;
    final rawSlot = ((localPosition.dx - horizontalPadding) / slotWidth) - 0.5;
    final clampedSlot = rawSlot.clamp(0.0, (count - 1).toDouble());
    final targetIdx = ((localPosition.dx - horizontalPadding) / slotWidth)
        .floor()
        .clamp(0, count - 1);

    final prevIdx = _glassHoveredIndex;
    setState(() {
      if (updateContinuousSlot) {
        _glassHoverSlot = clampedSlot;
      }
      _glassHoveredIndex = targetIdx;
    });

    if (prevIdx != targetIdx) {
      IrisHaptics.selectionClick();
      if (selectOnHover && widget.selectedIndex != targetIdx) {
        widget.onDestinationSelected(targetIdx);
      }
    }
  }

  void _endGlassInteraction() {
    _longPressTimer?.cancel();
    if (!_isGlassPointerDown && _glassHoverSlot == null && _glassHoveredIndex == null) return;
    final bool wasDragging = _isDraggingGlass || _glassHoverSlot != null;
    final settledIdx = (_glassHoveredIndex ?? widget.selectedIndex).clamp(0, _destinations.length - 1);
    final startPos = _glassHoverSlot ?? _slideAnimation.value;
    setState(() {
      _isGlassPointerDown = false;
      _isDraggingGlass = false;
      _glassHoverSlot = null;
      _glassHoveredIndex = null;
      _pointerDownPos = null;
    });
    if (widget.selectedIndex != settledIdx) {
      IrisHaptics.selectionClick();
      widget.onDestinationSelected(settledIdx);
    } else if (wasDragging) {
      _slideAnimation = Tween<double>(
        begin: startPos,
        end: settledIdx.toDouble(),
      ).animate(
        CurvedAnimation(
          parent: _slideController,
          curve: LaminarCurves.laminarEntrance,
        ),
      );
      _slideController.forward(from: 0.0);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final screenWidth = MediaQuery.sizeOf(context).width;
    final bottomPadding = MediaQuery.viewPaddingOf(context).bottom;

    return RepaintBoundary(
      child: ValueListenableBuilder<IrisThemeStyle>(
        valueListenable: ThemeSignals.themeStyle,
        builder: (context, themeStyle, _) {
          final isM3 = themeStyle == IrisThemeStyle.materialYou;

          return AnimatedSwitcher(
            duration: const Duration(milliseconds: 240),
            switchInCurve: LaminarCurves.laminarEntrance,
            switchOutCurve: LaminarCurves.laminarExit,
            child: isM3
                ? KeyedSubtree(
                    key: const ValueKey('navbar_theme_m3e'),
                    child: _buildMaterialExpressiveNavBar(
                      context,
                      cs,
                      isDark,
                      bottomPadding,
                    ),
                  )
                : KeyedSubtree(
                    key: ValueKey('navbar_theme_${themeStyle.name}'),
                    child: _buildLiquidGlassNavBar(
                      context,
                      cs,
                      isDark,
                      bottomPadding,
                      screenWidth,
                      themeStyle: themeStyle,
                    ),
                  ),
          );
        },
      ),
    );
  }

  // =========================================================================
  // 1. MATERIAL 3 EXPRESSIVE NAVBAR (Pure Minimal Android 15 Style)
  // =========================================================================

  Widget _buildMaterialExpressiveNavBar(
    BuildContext context,
    ColorScheme cs,
    bool isDark,
    double bottomPadding,
  ) {
    final destinations = _destinations;
    final canSearch = widget.selectedIndex == 0 || widget.selectedIndex == 2;

    return Padding(
      padding: EdgeInsets.fromLTRB(
        16,
        0,
        16,
        bottomPadding > 0 ? bottomPadding + 6 : 14,
      ),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 240),
        curve: LaminarCurves.laminarEntrance,
        height: 68,
        decoration: BoxDecoration(
          color: cs.surfaceContainer,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(
            color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55),
            width: 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.28 : 0.06),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 220),
            switchInCurve: LaminarCurves.laminarEntrance,
            switchOutCurve: LaminarCurves.laminarExit,
            child: widget.isSearchActive
                ? KeyedSubtree(
                    key: const ValueKey('m3_search_bar'),
                    child: _buildM3ActiveSearchBar(cs, isDark),
                  )
                : KeyedSubtree(
                    key: const ValueKey('m3_navigation_row'),
                    child: _buildM3NavigationRow(
                      cs,
                      isDark,
                      destinations,
                      canSearch,
                    ),
                  ),
          ),
        ),
      ),
    );
  }

  Widget _buildM3NavigationRow(
    ColorScheme cs,
    bool isDark,
    List<ExpressiveNavDestination> destinations,
    bool canSearch,
  ) {
    return MediaQuery.withClampedTextScaling(
      maxScaleFactor: 1.12,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final slotWidth = constraints.maxWidth / destinations.length;

          return Stack(
            alignment: Alignment.centerLeft,
            children: [
              // Smooth sliding Material 3 tonal pill
              AnimatedBuilder(
                animation: _slideController,
                builder: (context, _) {
                  final pos = _slideAnimation.value;
                  final progress = _slideController.value;
                  final stretch = math.sin(progress * math.pi) * 10.0;
                  final pillWidth = 58.0 + stretch;
                  final left = (pos * slotWidth) + ((slotWidth - pillWidth) / 2);

                  return Positioned(
                    left: left.clamp(4.0, constraints.maxWidth - pillWidth - 4.0),
                    top: 9,
                    width: pillWidth,
                    height: 30,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        color: cs.secondaryContainer,
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                  );
                },
              ),
              Row(
                children: List.generate(destinations.length, (index) {
                  final dest = destinations[index];
                  final isSelected = widget.selectedIndex == index;

                  return Expanded(
                    child: InkWell(
                      onTap: () => _handleTap(index),
                      onLongPress: () {
                        if (index == 0 || index == 2) {
                          IrisHaptics.actionSoft();
                          widget.onSearchToggle?.call(true);
                        } else if (index == 3) {
                          IrisHaptics.actionSoft();
                          widget.onOpenPaletteCustomizer?.call();
                        }
                      },
                      borderRadius: BorderRadius.circular(22),
                      splashColor: cs.primary.withValues(alpha: 0.08),
                      highlightColor: cs.primary.withValues(alpha: 0.04),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            width: 60,
                            height: 30,
                            child: Center(
                              child: Icon(
                                isSelected ? dest.activeIcon : dest.icon,
                                size: 21,
                                color: isSelected
                                    ? cs.onSecondaryContainer
                                    : cs.onSurfaceVariant,
                              ),
                            ),
                          ),
                          const SizedBox(height: 3),
                          AnimatedDefaultTextStyle(
                            duration: const Duration(milliseconds: 180),
                            style: TextStyle(
                              fontSize: 11.5,
                              fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                              color: isSelected ? cs.onSurface : cs.onSurfaceVariant,
                              letterSpacing: 0.1,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            child: Text(dest.label),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildM3ActiveSearchBar(ColorScheme cs, bool isDark) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: cs.primaryContainer,
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.search_rounded,
              color: cs.onPrimaryContainer,
              size: 20,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: widget.searchController,
              focusNode: widget.searchFocusNode,
              autofocus: true,
              style: TextStyle(
                color: cs.onSurface,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
              decoration: InputDecoration(
                hintText: widget.searchHint ?? 'Search...',
                hintStyle: TextStyle(
                  color: cs.onSurfaceVariant.withValues(alpha: 0.65),
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 8),
              ),
              onChanged: widget.onSearchChanged,
            ),
          ),
          if (widget.searchController != null &&
              widget.searchController!.text.isNotEmpty)
            IconButton(
              icon: Icon(Icons.clear_rounded, size: 18, color: cs.onSurfaceVariant),
              visualDensity: VisualDensity.compact,
              constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
              onPressed: () {
                IrisHaptics.actionSoft();
                widget.searchController?.clear();
                widget.onSearchChanged?.call('');
                setState(() {});
              },
            ),
          IconButton.filledTonal(
            icon: const Icon(Icons.close_rounded, size: 18),
            style: IconButton.styleFrom(
              backgroundColor: cs.surfaceContainerHighest,
              foregroundColor: cs.onSurfaceVariant,
              visualDensity: VisualDensity.compact,
            ),
            onPressed: () {
              IrisHaptics.actionSoft();
              widget.onSearchToggle?.call(false);
            },
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // 2. COLOROS 17 LIQUID GLASS NAVBAR (Refractive GlassButton.custom + Lens)
  // =========================================================================

  Widget _buildLiquidGlassNavBar(
    BuildContext context,
    ColorScheme cs,
    bool isDark,
    double bottomPadding,
    double screenWidth, {
    IrisThemeStyle themeStyle = IrisThemeStyle.fluidGlass,
  }) {
    final double dockWidth = widget.isSearchActive
        ? (screenWidth - 28.0).clamp(280.0, 520.0)
        : math.min(screenWidth - 28.0, 352.0);
    const double dockHeight = 68.0;
    const double dockRadius = 34.0;

    return Align(
      alignment: Alignment.bottomCenter,
      child: Padding(
        padding: EdgeInsets.only(
          bottom: bottomPadding > 0 ? bottomPadding + 6 : 14,
        ),
        child: ValueListenableBuilder<double>(
          valueListenable: ThemeSignals.glassTransparency,
          builder: (context, transparency, _) {
            final isOpaque = transparency <= 0.08;
            final double navBlur = themeStyle == IrisThemeStyle.fluidGlass
                ? (isOpaque ? 0.0 : lerpDouble(8.0, 22.0, transparency)!)
                : 0.0;

            Color dockColor;
            Border dockBorder;
            List<BoxShadow> dockShadow;

            switch (themeStyle) {
              case IrisThemeStyle.notebook:
                dockColor = NotebookTokens.navBarBackground(isDark);
                dockBorder = Border.all(
                  color: NotebookTokens.navBarBorder(isDark),
                  width: 1.6,
                );
                dockShadow = [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ];
                break;
              case IrisThemeStyle.line:
                dockColor = LineTokens.navBarBackground(isDark);
                dockBorder = Border.all(
                  color: LineTokens.railLine(isDark),
                  width: 2.0,
                );
                dockShadow = [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ];
                break;
              case IrisThemeStyle.poster:
                dockColor = PosterTokens.navBarBackground(isDark);
                dockBorder = Border.all(
                  color: PosterTokens.inkBorder(isDark),
                  width: 2.4,
                );
                dockShadow = [
                  BoxShadow(
                    color: PosterTokens.inkBorder(isDark),
                    offset: const Offset(2, 3),
                    blurRadius: 0,
                  ),
                ];
                break;
              case IrisThemeStyle.almanac:
                dockColor = AlmanacTokens.navBarBackground(isDark);
                dockBorder = Border.all(
                  color: AlmanacTokens.inkRule(isDark),
                  width: 1.4,
                );
                dockShadow = [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ];
                break;
              case IrisThemeStyle.editorialAcademic:
                dockColor = EditorialTokens.cardSurface(isDark);
                dockBorder = Border.all(
                  color: EditorialTokens.cardBorder(isDark),
                  width: 1.4,
                );
                dockShadow = [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ];
                break;
              case IrisThemeStyle.fluidGlass:
              case IrisThemeStyle.materialYou:
                dockColor = isDark
                    ? (isOpaque
                        ? const Color(0xFF10192D)
                        : const Color(0xFF0A1224).withValues(
                            alpha: lerpDouble(0.94, 0.56, transparency)!,
                          ))
                    : (isOpaque
                        ? const Color(0xFFFCFDFF)
                        : const Color(0xFFFDFEFF).withValues(
                            alpha: lerpDouble(0.97, 0.85, transparency)!,
                          ));
                dockBorder = Border.all(
                  color: isOpaque
                      ? (isDark ? const Color(0xFF2E384D) : const Color(0xFFCBD5E1))
                      : (isDark
                          ? Colors.white.withValues(alpha: 0.18)
                          : const Color(0xFF94A3B8).withValues(alpha: 0.45)),
                  width: 1.15,
                );
                dockShadow = [
                  BoxShadow(
                    color: isDark
                        ? Colors.black.withValues(alpha: 0.44)
                        : const Color(0xFF0F172A).withValues(alpha: 0.10),
                    blurRadius: 26,
                    spreadRadius: isDark ? 0 : 0.5,
                    offset: const Offset(0, 9),
                  ),
                ];
                break;
            }

            final innerSwitcher = AnimatedSwitcher(
              duration: const Duration(milliseconds: 240),
              switchInCurve: LaminarCurves.laminarEntrance,
              switchOutCurve: LaminarCurves.laminarExit,
              child: widget.isSearchActive
                  ? KeyedSubtree(
                      key: const ValueKey('glass_search_active'),
                      child: _buildGlassActiveSearchBar(isDark),
                    )
                  : KeyedSubtree(
                      key: const ValueKey('glass_tabs_active'),
                      child: _buildGlassTabsRow(
                        isDark,
                        dockWidth,
                        dockHeight: dockHeight,
                        themeStyle: themeStyle,
                      ),
                    ),
            );

            if (themeStyle == IrisThemeStyle.fluidGlass) {
              // Deep refractive smoked-crystal shader & ColorOS 17 stretch calibration
              final double btnBlur = isOpaque ? 0.0 : lerpDouble(8.0, 18.0, transparency)!;
              final double btnThickness = isOpaque ? 0.0 : lerpDouble(10.0, 16.0, transparency)!;
              final double btnAmbient = isOpaque ? 0.0 : lerpDouble(0.40, 0.78, transparency)!;
              final BorderSide glassSide = isOpaque
                  ? BorderSide(
                      color: isDark ? const Color(0xFF2E384D) : const Color(0xFFCBD5E1),
                      width: 1.0,
                    )
                  : (isDark
                      ? BorderSide.none
                      : BorderSide(
                          color: Colors.black.withValues(alpha: 0.08),
                          width: 1.0,
                        ));

              if (widget.isSearchActive) {
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 260),
                  curve: LaminarCurves.laminarEntrance,
                  width: dockWidth,
                  height: dockHeight,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(dockRadius),
                    boxShadow: dockShadow,
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(dockRadius),
                    child: GlassSurface(
                      settings: IrisGlass.widgetsSettings(
                        context,
                        blur: btnBlur,
                        thickness: btnThickness,
                        ambientStrength: btnAmbient,
                        lightIntensity: isDark ? 0.85 : 0.95,
                        glassColor: dockColor,
                        specularSharpness: lgw.GlassSpecularSharpness.sharp,
                      ),
                      radius: dockRadius,
                      applyInLayer: true,
                      quality: isOpaque ? lgw.GlassQuality.minimal : lgw.GlassQuality.premium,
                      borderSide: glassSide,
                      child: innerSwitcher,
                    ),
                  ),
                );
              }

              return AnimatedBuilder(
                animation: _slideController,
                builder: (context, child) {
                  final activeSlot = (_glassHoverSlot ?? _slideAnimation.value)
                      .clamp(0.0, (_destinations.length - 1).toDouble());
                  final centerSlot = (_destinations.length - 1) / 2.0;
                  final normalizedX = centerSlot > 0
                      ? ((activeSlot - centerSlot) / centerSlot).clamp(-1.0, 1.0)
                      : 0.0;
                  final isInteracting = _isGlassPointerDown || _glassHoverSlot != null;
                  final tiltY = normalizedX * (isInteracting ? 0.075 : 0.032);
                  final tiltX = isInteracting ? -0.035 : -0.012;

                  return Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.identity()
                      ..setEntry(3, 2, 0.0016)
                      ..rotateY(tiltY)
                      ..rotateX(tiltX),
                    child: child,
                  );
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 260),
                  curve: LaminarCurves.laminarEntrance,
                  width: dockWidth,
                  height: dockHeight,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(dockRadius),
                    boxShadow: dockShadow,
                  ),
                  child: RepaintBoundary(
                    child: lgw.GlassButton.custom(
                    enabled: true,
                    onTap: () {},
                    width: dockWidth,
                    height: dockHeight,
                    useOwnLayer: true,
                    interactionScale: 0.94,
                    stretch: 0.58,
                    anchorStretch: true,
                    anchorStretchSettings: const lgw.AnchorStretchSettings(
                      intensity: 1.0,
                      squashFactor: 0.1,
                      translationDamping: 0.85,
                      bounciness: 0.05,
                    ),
                    persistPressOnDrag: true,
                    resistance: 0.08,
                    shape: lgw.LiquidRoundedSuperellipse(
                      borderRadius: dockRadius,
                      side: glassSide,
                    ),
                    quality: isOpaque ? lgw.GlassQuality.minimal : lgw.GlassQuality.premium,
                    settings: IrisGlass.widgetsSettings(
                      context,
                      blur: btnBlur,
                      thickness: btnThickness,
                      glassColor: dockColor,
                      ambientStrength: btnAmbient,
                      lightIntensity: isDark ? 0.85 : 0.95,
                      specularSharpness: lgw.GlassSpecularSharpness.sharp,
                    ),
                      child: innerSwitcher,
                    ),
                  ),
                ),
              );
            }

            return AnimatedContainer(
              duration: const Duration(milliseconds: 260),
              curve: LaminarCurves.laminarEntrance,
              width: dockWidth,
              height: dockHeight,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(dockRadius),
                child: Container(
                  decoration: BoxDecoration(
                    color: dockColor,
                    borderRadius: BorderRadius.circular(dockRadius),
                    border: dockBorder,
                    boxShadow: dockShadow,
                  ),
                  child: innerSwitcher,
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildGlassTabsRow(
    bool isDark,
    double dockWidth, {
    double dockHeight = 64.0,
    IrisThemeStyle themeStyle = IrisThemeStyle.fluidGlass,
  }) {
    final destinations = _destinations;
    const double horizontalPadding = 6.0;

    Color thumbColor;
    Border? thumbBorder;
    List<BoxShadow> thumbShadow;
    Color activeIconColor;
    Color inactiveIconColor;

    switch (themeStyle) {
      case IrisThemeStyle.notebook:
        thumbColor = NotebookTokens.navActivePill(isDark);
        thumbBorder = Border.all(
          color: NotebookTokens.marginRule(isDark),
          width: 1.2,
        );
        thumbShadow = [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.12),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ];
        activeIconColor = NotebookTokens.navActiveText(isDark);
        inactiveIconColor = NotebookTokens.navInactiveText(isDark);
        break;
      case IrisThemeStyle.line:
        thumbColor = LineTokens.navActivePill(isDark);
        thumbBorder = null;
        thumbShadow = [
          BoxShadow(
            color: LineTokens.railLine(isDark).withValues(alpha: 0.35),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ];
        activeIconColor = LineTokens.navActiveText(isDark);
        inactiveIconColor = LineTokens.navInactiveText(isDark);
        break;
      case IrisThemeStyle.poster:
        thumbColor = PosterTokens.navActiveBlock(isDark);
        thumbBorder = Border.all(
          color: PosterTokens.inkBorder(isDark),
          width: 1.8,
        );
        thumbShadow = [
          BoxShadow(
            color: PosterTokens.inkBorder(isDark),
            offset: const Offset(1.5, 2),
            blurRadius: 0,
          ),
        ];
        activeIconColor = PosterTokens.navActiveText(isDark);
        inactiveIconColor = PosterTokens.navInactiveText(isDark);
        break;
      case IrisThemeStyle.almanac:
        thumbColor = AlmanacTokens.navActivePill(isDark);
        thumbBorder = Border.all(
          color: AlmanacTokens.inkRule(isDark),
          width: 1.0,
        );
        thumbShadow = [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.30 : 0.10),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ];
        activeIconColor = AlmanacTokens.navActiveText(isDark);
        inactiveIconColor = AlmanacTokens.navInactiveText(isDark);
        break;
      case IrisThemeStyle.editorialAcademic:
        thumbColor = isDark ? const Color(0xFF6366F1) : const Color(0xFF4F46E5);
        thumbBorder = null;
        thumbShadow = [
          BoxShadow(
            color: const Color(0xFF6366F1).withValues(alpha: 0.35),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ];
        activeIconColor = Colors.white;
        inactiveIconColor = EditorialTokens.inkMuted(isDark);
        break;
      case IrisThemeStyle.fluidGlass:
      case IrisThemeStyle.materialYou:
        thumbColor = isDark
            ? Colors.white.withValues(alpha: 0.16)
            : Colors.white.withValues(alpha: 0.85);
        thumbBorder = Border.all(
          color: isDark
              ? Colors.white.withValues(alpha: 0.38)
              : Colors.white.withValues(alpha: 0.96),
          width: 1.2,
        );
        thumbShadow = [
          BoxShadow(
            color: (isDark ? const Color(0xFF38BDF8) : const Color(0xFF0284C7))
                .withValues(alpha: isDark ? 0.22 : 0.14),
            blurRadius: 14,
            offset: const Offset(0, 2),
          ),
        ];
        activeIconColor = isDark ? Colors.white : const Color(0xFF0369A1);
        inactiveIconColor = isDark
            ? Colors.white.withValues(alpha: 0.64)
            : const Color(0xFF334155).withValues(alpha: 0.86);
        break;
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final double totalWidth = constraints.maxWidth;
        final double actualAvailableWidth = totalWidth - (horizontalPadding * 2);
        final double slotWidth = actualAvailableWidth / destinations.length;
        final bool isFluidGlass = themeStyle == IrisThemeStyle.fluidGlass;

        final Widget tabStack = AnimatedBuilder(
          animation: _slideController,
          builder: (context, _) {
            final bool isInteracting =
                isFluidGlass && (_isGlassPointerDown || _glassHoverSlot != null);
            final double currentPos = isInteracting && _glassHoverSlot != null
                ? _glassHoverSlot!
                : _slideAnimation.value;
            final double progress = _slideController.value;

            final double basePillWidth = (slotWidth - 4.0).clamp(56.0, 84.0);
            final double transitStretch =
                math.sin(progress * math.pi) * (isFluidGlass ? 12.0 : 8.0);
            final double lensExpand = isInteracting ? 6.0 : 0.0;
            final double currentThumbWidth = basePillWidth + transitStretch + lensExpand;
            final double currentThumbHeight = isInteracting ? 54.0 : 50.0;
            final double thumbLeft = (horizontalPadding +
                    (currentPos * slotWidth) +
                    ((slotWidth - currentThumbWidth) / 2))
                .clamp(horizontalPadding, totalWidth - horizontalPadding - currentThumbWidth);

            return Stack(
              alignment: Alignment.centerLeft,
              children: [
                // 1. ColorOS 17 Refractive Liquid Glass Lens Indicator Pill
                Positioned(
                  left: thumbLeft,
                  top: (dockHeight - currentThumbHeight) / 2,
                  width: currentThumbWidth,
                  height: currentThumbHeight,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      color: isFluidGlass ? null : thumbColor,
                      gradient: isFluidGlass
                          ? LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: isDark
                                  ? [
                                      Colors.white.withValues(
                                        alpha: isInteracting ? 0.30 : 0.20,
                                      ),
                                      const Color(0xFF38BDF8).withValues(
                                        alpha: isInteracting ? 0.22 : 0.12,
                                      ),
                                    ]
                                  : [
                                      Colors.white.withValues(
                                        alpha: isInteracting ? 0.96 : 0.88,
                                      ),
                                      const Color(0xFFE0F2FE).withValues(
                                        alpha: isInteracting ? 0.90 : 0.78,
                                      ),
                                    ],
                            )
                          : null,
                      borderRadius: BorderRadius.circular(currentThumbHeight / 2),
                      border: isFluidGlass && isInteracting
                          ? Border.all(
                              color: isDark
                                  ? const Color(0xFF7DD3FC).withValues(alpha: 0.78)
                                  : Colors.white,
                              width: 1.4,
                            )
                          : thumbBorder,
                      boxShadow: isFluidGlass && isInteracting
                          ? [
                              BoxShadow(
                                color: const Color(0xFF38BDF8).withValues(
                                  alpha: isDark ? 0.38 : 0.24,
                                ),
                                blurRadius: 18,
                                spreadRadius: 0.5,
                                offset: const Offset(0, 2),
                              ),
                            ]
                          : thumbShadow,
                    ),
                  ),
                ),

                // 2. Destination Tabs with Continuous Lens-Proximity Highlight & Stable Icon+Label Layout
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: horizontalPadding,
                  ),
                  child: Row(
                    children: List.generate(destinations.length, (index) {
                      final dest = destinations[index];
                      final double dist = (index - currentPos).abs();
                      final double proximity = (1.0 - dist).clamp(0.0, 1.0);
                      final bool isFocused = proximity > 0.52;
                      final Color blendedColor =
                          Color.lerp(inactiveIconColor, activeIconColor, proximity)!;
                      final double scale = 1.0 + (0.09 * proximity) + (isInteracting && isFocused ? 0.04 : 0.0);

                      // 3D Per-Tab Personality Transform (Schedule, Portal, Tools, Settings)
                      final double pWave = math.sin(progress * math.pi);
                      final double rotY = switch (index) {
                        0 => proximity * 0.22 * math.sin(proximity * math.pi),
                        1 => proximity * 0.28 * (isInteracting ? 1.0 : pWave),
                        2 => -proximity * 0.22 * math.sin(proximity * math.pi),
                        _ => proximity * 0.25 * pWave,
                      };
                      final double rotX = switch (index) {
                        0 => -0.18 * proximity,
                        1 => 0.14 * proximity * pWave,
                        2 => -0.16 * proximity,
                        _ => -0.14 * proximity,
                      };
                      final double rotZ = index == 3
                          ? (proximity * 0.35 * pWave)
                          : (index == 2 ? (proximity * 0.12 * pWave) : 0.0);
                      final double liftY = -2.8 * proximity;

                      final Color tabAccent = switch (index) {
                        0 => isDark ? const Color(0xFF38BDF8) : const Color(0xFF0284C7),
                        1 => isDark ? const Color(0xFF818CF8) : const Color(0xFF4F46E5),
                        2 => isDark ? const Color(0xFF2DD4BF) : const Color(0xFF0D9488),
                        _ => isDark ? const Color(0xFFC084FC) : const Color(0xFF7C3AED),
                      };

                      final Widget tabContent = Center(
                        child: Transform.translate(
                          offset: Offset(0, liftY),
                          child: Transform.scale(
                            scale: scale,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Stack(
                                  alignment: Alignment.center,
                                  clipBehavior: Clip.none,
                                  children: [
                                    // 3D Aquamorphic Pedestal Disc behind focused icon
                                    if (proximity > 0.12)
                                      Container(
                                        width: 30 * proximity.clamp(0.5, 1.0),
                                        height: 24 * proximity.clamp(0.5, 1.0),
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(10),
                                          gradient: RadialGradient(
                                            colors: [
                                              tabAccent.withValues(
                                                alpha: (isDark ? 0.34 : 0.20) * proximity,
                                              ),
                                              Colors.transparent,
                                            ],
                                          ),
                                        ),
                                      ),
                                    // 3D Perspective Icon with Specular Depth Shadow
                                    Transform(
                                      alignment: Alignment.center,
                                      transform: Matrix4.identity()
                                        ..setEntry(3, 2, 0.0032)
                                        ..rotateX(rotX)
                                        ..rotateY(rotY)
                                        ..rotateZ(rotZ),
                                      child: Icon(
                                        isFocused ? dest.activeIcon : dest.icon,
                                        size: isFocused ? 21.5 : 19.5,
                                        color: isFocused
                                            ? (isDark ? Colors.white : tabAccent)
                                            : blendedColor,
                                        shadows: isFocused
                                            ? [
                                                Shadow(
                                                  color: tabAccent.withValues(
                                                    alpha: isDark ? 0.65 : 0.35,
                                                  ),
                                                  blurRadius: 10,
                                                  offset: const Offset(0, 3),
                                                ),
                                              ]
                                            : null,
                                      ),
                                    ),
                                    // Floating 3D Specular Personality Orb Badge
                                    if (isFocused)
                                      Positioned(
                                        top: -2,
                                        right: -5,
                                        child: Container(
                                          width: 5.0,
                                          height: 5.0,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: isDark ? Colors.white : tabAccent,
                                            boxShadow: [
                                              BoxShadow(
                                                color: tabAccent.withValues(alpha: 0.75),
                                                blurRadius: 5,
                                                spreadRadius: 0.5,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                                const SizedBox(height: 3.0),
                                Text(
                                  dest.label,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: 10.2,
                                    fontWeight: isFocused ? FontWeight.w800 : FontWeight.w600,
                                    letterSpacing: 0.15,
                                    height: 1.0,
                                    color: isFocused
                                        ? (isDark ? Colors.white : const Color(0xFF0F172A))
                                        : blendedColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );

                      return Expanded(
                        child: SizedBox(
                          height: dockHeight,
                          child: isFluidGlass
                              ? tabContent
                              : GestureDetector(
                                  behavior: HitTestBehavior.opaque,
                                  onTap: () => _handleTap(index),
                                  onLongPress: () {
                                    if (index == 0 || index == 2) {
                                      IrisHaptics.actionSoft();
                                      widget.onSearchToggle?.call(true);
                                    } else if (index == 3) {
                                      IrisHaptics.actionSoft();
                                      widget.onOpenPaletteCustomizer?.call();
                                    }
                                  },
                                  child: tabContent,
                                ),
                        ),
                      );
                    }),
                  ),
                ),
              ],
            );
          },
        );

        if (!isFluidGlass) {
          return tabStack;
        }

        // ColorOS 17 Continuous Hover & Glide-to-Select Listener for Liquid Glass Navbar
        return MouseRegion(
          onHover: (event) {
            if (!_isGlassPointerDown) {
              _updateGlassHover(
                event.localPosition,
                totalWidth,
                horizontalPadding,
                destinations.length,
                selectOnHover: true,
                updateContinuousSlot: true,
              );
            }
          },
          onExit: (_) {
            if (!_isGlassPointerDown) {
              _endGlassInteraction();
            }
          },
          child: Listener(
            behavior: HitTestBehavior.translucent,
            onPointerDown: (event) {
              _pointerDownPos = event.localPosition;
              final pressedIdx = _computeSlotIndex(
                event.localPosition,
                totalWidth,
                horizontalPadding,
                destinations.length,
              );
              setState(() {
                _isGlassPointerDown = true;
                _isDraggingGlass = false;
                _glassHoveredIndex = pressedIdx;
              });
              // On pointer down, trigger smooth spring slide toward pressedIdx without
              // teleporting _glassHoverSlot, so taps animate smoothly across tabs!
              if (widget.selectedIndex != pressedIdx) {
                IrisHaptics.selectionClick();
                widget.onDestinationSelected(pressedIdx);
              }
              _longPressTimer?.cancel();
              _longPressTimer = Timer(const Duration(milliseconds: 460), () {
                if (!mounted || !_isGlassPointerDown) return;
                if (pressedIdx == 0 || pressedIdx == 2) {
                  IrisHaptics.actionSoft();
                  _endGlassInteraction();
                  widget.onSearchToggle?.call(true);
                } else if (pressedIdx == 3) {
                  IrisHaptics.actionSoft();
                  _endGlassInteraction();
                  widget.onOpenPaletteCustomizer?.call();
                }
              });
            },
            onPointerMove: (event) {
              final dist = _pointerDownPos != null
                  ? (event.localPosition - _pointerDownPos!).distance
                  : 0.0;
              if (dist > 10.0) {
                _longPressTimer?.cancel();
              }
              if (dist > 6.0 || _isDraggingGlass) {
                _isDraggingGlass = true;
                _updateGlassHover(
                  event.localPosition,
                  totalWidth,
                  horizontalPadding,
                  destinations.length,
                  selectOnHover: true,
                  updateContinuousSlot: true,
                );
              }
            },
            onPointerUp: (_) => _endGlassInteraction(),
            onPointerCancel: (_) => _endGlassInteraction(),
            child: tabStack,
          ),
        );
      },
    );
  }

  Widget _buildGlassActiveSearchBar(bool isDark) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: isDark
                  ? Colors.white.withValues(alpha: 0.15)
                  : Colors.black.withValues(alpha: 0.08),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.search_rounded,
              color: isDark ? Colors.white : Colors.black87,
              size: 20,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: widget.searchController,
              focusNode: widget.searchFocusNode,
              autofocus: true,
              style: TextStyle(
                color: isDark ? Colors.white : Colors.black,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
              decoration: InputDecoration(
                hintText: widget.searchHint ?? 'Search...',
                hintStyle: TextStyle(
                  color: isDark ? Colors.white54 : Colors.black45,
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 8),
              ),
              onChanged: widget.onSearchChanged,
            ),
          ),
          if (widget.searchController != null &&
              widget.searchController!.text.isNotEmpty)
            IconButton(
              icon: Icon(
                Icons.clear_rounded,
                size: 18,
                color: isDark ? Colors.white70 : Colors.black54,
              ),
              visualDensity: VisualDensity.compact,
              constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
              padding: EdgeInsets.zero,
              onPressed: () {
                IrisHaptics.actionSoft();
                widget.searchController?.clear();
                widget.onSearchChanged?.call('');
                setState(() {});
              },
            ),
          IconButton.filledTonal(
            icon: const Icon(Icons.close_rounded, size: 18),
            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
            padding: EdgeInsets.zero,
            style: IconButton.styleFrom(
              backgroundColor: isDark
                  ? Colors.white.withValues(alpha: 0.12)
                  : Colors.black.withValues(alpha: 0.08),
              foregroundColor: isDark ? Colors.white : Colors.black87,
              visualDensity: VisualDensity.compact,
            ),
            onPressed: () {
              IrisHaptics.actionSoft();
              widget.onSearchToggle?.call(false);
            },
          ),
        ],
      ),
    );
  }
}

/// Animated tab stack that smoothly transitions between navigation tabs with
/// ColorOS 17 laminar parallel motion (shared-axis slide + scale + fade)
/// while strictly preserving state (WebViews, scroll offsets, form fields).
class IrisExpressiveTabStack extends StatefulWidget {
  final int index;
  final int slideDirection;
  final List<Widget> children;

  const IrisExpressiveTabStack({
    super.key,
    required this.index,
    this.slideDirection = 1,
    required this.children,
  });

  @override
  State<IrisExpressiveTabStack> createState() => _IrisExpressiveTabStackState();
}

class _IrisExpressiveTabStackState extends State<IrisExpressiveTabStack>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _animation;
  late Animation<Offset> _inSlideAnimation;
  late Animation<double> _inFadeAnimation;
  late Animation<double> _inScaleAnimation;
  late Animation<Offset> _outSlideAnimation;
  late Animation<double> _outFadeAnimation;
  late Animation<double> _outScaleAnimation;

  int _lastIndex = 0;
  int _direction = 1;

  @override
  void initState() {
    super.initState();
    _lastIndex = widget.index;
    _direction = widget.slideDirection;
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );
    _animation = CurvedAnimation(
      parent: _controller,
      curve: LaminarCurves.laminarEntrance,
    );
    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        if (mounted) setState(() {});
      }
    });
    _updateAnimations();
    _controller.value = 1.0;
  }

  void _updateAnimations() {
    _inSlideAnimation = Tween<Offset>(
      begin: Offset(0.032 * _direction, 0.0),
      end: Offset.zero,
    ).animate(_animation);
    _inFadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(_animation);
    _inScaleAnimation = Tween<double>(
      begin: 0.982,
      end: 1.0,
    ).animate(_animation);

    _outSlideAnimation = Tween<Offset>(
      begin: Offset.zero,
      end: Offset(-0.022 * _direction, 0.0),
    ).animate(_animation);
    _outFadeAnimation = Tween<double>(
      begin: 1.0,
      end: 0.0,
    ).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.58, curve: Curves.easeOut),
      ),
    );
    _outScaleAnimation = Tween<double>(
      begin: 1.0,
      end: 0.985,
    ).animate(_animation);
  }

  @override
  void didUpdateWidget(covariant IrisExpressiveTabStack oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.index != oldWidget.index) {
      _lastIndex = oldWidget.index;
      _direction = widget.slideDirection;
      _updateAnimations();
      _controller.forward(from: 0.0);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isAnimating = _controller.isAnimating;

    return Stack(
      fit: StackFit.expand,
      children: List.generate(widget.children.length, (i) {
        final isCurrent = i == widget.index;
        final isLast = i == _lastIndex && isAnimating;

        if (!isCurrent && !isLast) {
          return Offstage(
            offstage: true,
            child: TickerMode(
              enabled: false,
              child: RepaintBoundary(child: widget.children[i]),
            ),
          );
        }

        if (isLast) {
          return IgnorePointer(
            child: SlideTransition(
              position: _outSlideAnimation,
              child: ScaleTransition(
                scale: _outScaleAnimation,
                child: FadeTransition(
                  opacity: _outFadeAnimation,
                  child: TickerMode(
                    enabled: false,
                    child: RepaintBoundary(child: widget.children[i]),
                  ),
                ),
              ),
            ),
          );
        }

        if (!isAnimating) {
          return TickerMode(
            enabled: true,
            child: RepaintBoundary(child: widget.children[i]),
          );
        }

        return SlideTransition(
          position: _inSlideAnimation,
          child: ScaleTransition(
            scale: _inScaleAnimation,
            child: FadeTransition(
              opacity: _inFadeAnimation,
              child: TickerMode(
                enabled: true,
                child: RepaintBoundary(child: widget.children[i]),
              ),
            ),
          ),
        );
      }),
    );
  }
}
