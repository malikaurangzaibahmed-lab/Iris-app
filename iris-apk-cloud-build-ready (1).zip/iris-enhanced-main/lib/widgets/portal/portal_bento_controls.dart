import 'package:flutter/material.dart';

import '../../core/animations.dart';
import '../../core/sticker_tokens.dart';
import '../../core/theme_signals.dart';
import '../../core/tokens.dart';
import 'package:iris/widgets/controls/iris_liquid_button.dart';

class PortalBentoCard extends StatelessWidget {
  final bool isDark;
  final Widget child;
  final Color? borderTint;
  final double? width;
  final double? height;

  const PortalBentoCard({
    required this.isDark,
    required this.child,
    this.borderTint,
    this.width,
    this.height,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final isM3 = ThemeSignals.isMaterialYou;
    final screenW = MediaQuery.sizeOf(context).width;
    final isCompact = screenW < 400;

    if (isM3) {
      final cs = Theme.of(context).colorScheme;
      return Container(
        width: width,
        height: height,
        padding: EdgeInsets.symmetric(
          horizontal: isCompact ? 12 : 16,
          vertical: 14,
        ),
        decoration: BoxDecoration(
          color: cs.surfaceContainer,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55),
            width: 1.0,
          ),
        ),
        child: child,
      );
    }

    final borderColor = borderTint != null
        ? borderTint!.withValues(alpha: isDark ? 0.24 : 0.40)
        : (isDark ? Colors.white : IrisTokens.brand).withValues(alpha: 0.15);
    final cardBg = isDark
        ? Colors.white.withValues(alpha: 0.05)
        : Colors.white.withValues(alpha: 0.55);

    return Container(
      width: width,
      height: height,
      padding: EdgeInsets.symmetric(
        horizontal: isCompact ? 12 : 16,
        vertical: 14,
      ),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderColor, width: 1.0),
      ),
      child: child,
    );
  }
}

class PortalBentoActionBtn extends StatelessWidget {
  final bool isDark;
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool primary;

  const PortalBentoActionBtn({
    required this.isDark,
    required this.icon,
    required this.label,
    required this.onTap,
    this.primary = false,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final accent = IrisTokens.brand;
    final btnColor = primary
        ? accent
        : (isDark ? Colors.white : const Color(0xFF0F172A));

    return ExpressiveSpringPress(
      onTap: onTap,
      child: IrisLiquidButton(
        text: label,
        icon: icon,
        onTap: onTap,
        color: btnColor,
        isDark: isDark,
        height: 38,
        fontSize: 10.5,
        iconSize: 13,
        fontWeight: FontWeight.w800,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        borderSide: BorderSide(
          color: primary
              ? accent
              : (isDark ? Colors.white : Colors.black).withValues(alpha: 0.12),
          width: 0.8,
        ),
      ),
    );
  }
}

class PortalBentoNavCircle extends StatelessWidget {
  final bool isDark;
  final IconData icon;
  final String tooltip;
  final bool enabled;
  final VoidCallback onTap;

  const PortalBentoNavCircle({
    required this.isDark,
    required this.icon,
    required this.tooltip,
    required this.enabled,
    required this.onTap,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final baseColor = isDark ? Colors.white : Colors.black;
    final iconColor = enabled
        ? (isDark ? Colors.white : IrisTokens.surfaceDarkElevated)
        : baseColor.withValues(alpha: 0.28);
    final circleBg = enabled
        ? baseColor.withValues(alpha: 0.08)
        : Colors.transparent;

    return Tooltip(
      message: tooltip,
      child: ExpressiveSpringPress(
        enabled: enabled,
        onTap: enabled ? onTap : null,
        child: Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: circleBg,
            border: Border.all(
              color: baseColor.withValues(alpha: enabled ? 0.12 : 0.05),
              width: 0.9,
            ),
          ),
          child: Center(child: Icon(icon, size: 17, color: iconColor)),
        ),
      ),
    );
  }
}
