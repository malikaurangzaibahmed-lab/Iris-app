import 'sports_gala_view.dart';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/editorial_theme_tokens.dart';
import '../../core/models.dart';
import '../../core/omni_brain.dart';
import '../../services/remote_config_service.dart';
import '../../services/ui_feedback.dart';
import '../iris_components.dart';
import 'package:iris/widgets/effects/glass_container_transform.dart';
import 'package:iris/screens/settings/announcements_screen.dart';

/// Pixel-perfect Cozy Editorial Academic Timetable View.
/// Faithfully reproduces Light.png and Dark.png down to the exact castle canopy,
/// perforated ticket stub hero pass, 7-day strip, perforated lecture cards,
/// and live campus intelligence synchronization.
class EditorialScheduleView extends StatelessWidget {
  final OmniBrain brain;
  final String batch;
  final int activeDayIndex;
  final ValueChanged<int> onDaySelected;
  final VoidCallback onRefresh;
  final VoidCallback onOpenBatchSelector;
  final List<String> pendingChanges;
  final VoidCallback? onDismissChanges;
  final String? userName;
  final VoidCallback? onToggleTheme;
  final bool isFaculty;
  final String? teacherName;

  const EditorialScheduleView({
    super.key,
    required this.brain,
    required this.batch,
    required this.activeDayIndex,
    required this.onDaySelected,
    required this.onRefresh,
    required this.onOpenBatchSelector,
    this.pendingChanges = const [],
    this.onDismissChanges,
    this.userName,
    this.onToggleTheme,
    this.isFaculty = false,
    this.teacherName,
  });

  static const List<String> _weekdaysShort = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
  static const List<String> _monthsShort = [
    'JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN',
    'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final now = DateTime.now();
    final currentWeekday = now.weekday; // 1 = Mon, 7 = Sun

    // Calculate dates for the 7-day strip (Sunday first: index 0 = Sun, 1 = Mon, ... 6 = Sat)
    final sundayOffset = now.weekday % 7;
    final sundayDate = now.subtract(Duration(days: sundayOffset));

    final activeDateOffset = activeDayIndex == 7 ? 0 : activeDayIndex;
    final activeDate = sundayDate.add(Duration(days: activeDateOffset));

    final String activeIdentity = isFaculty ? (teacherName ?? batch) : batch;

    // Real schedule sessions for the selected day
    final List<ClassSession> sessions = isFaculty
        ? brain.getMergedDayScheduleForTeacher(activeIdentity, activeDayIndex)
        : brain.getMergedDaySchedule(batch, activeDayIndex);

    // Compute real current/next class and countdown
    final double currentTime = now.hour + (now.minute / 60.0);
    final ClassSession? currentClass = isFaculty
        ? brain.getCurrentClassForTeacher(activeIdentity, now)
        : brain.getCurrentClass(batch, now);
    final ClassSession? nextClass = isFaculty
        ? brain.getNextClassForTeacher(activeIdentity, now)
        : brain.getNextClass(batch, now);

    final String countdownDisplay;
    final String handwrittenNote;
    final String topMetaHeadline;
    final String heroSubject;
    final String heroDetails;

    if (activeDayIndex == currentWeekday) {
      if (currentClass != null && currentClass.isLive(now)) {
        final double endVal = currentClass.actualEndVal;
        final int minutesLeft = ((endVal - currentTime) * 60).clamp(0, 300).round();
        final int hours = minutesLeft ~/ 60;
        final int mins = minutesLeft % 60;
        final partner = isFaculty ? currentClass.displayBatch : currentClass.teacher;
        countdownDisplay = hours > 0 ? '${hours}h ${mins}m' : '${mins}m';
        handwrittenNote = 'lecture in session!';
        topMetaHeadline = 'NOW HAPPENING · LIVE LECTURE';
        heroSubject = currentClass.subject;
        heroDetails = '${currentClass.startTime} – ${currentClass.endTime} · Room ${currentClass.room} · $partner';
      } else if (nextClass != null && nextClass.dayIndex == now.weekday && nextClass.safeStartVal > currentTime) {
        final double startVal = nextClass.safeStartVal;
        final int minutesLeft = ((startVal - currentTime) * 60).clamp(0, 1440).round();
        final int hours = minutesLeft ~/ 60;
        final int mins = minutesLeft % 60;
        final partner = isFaculty ? nextClass.displayBatch : nextClass.teacher;
        countdownDisplay = hours > 0 ? '${hours}h ${mins}m' : '${mins}m';
        if (minutesLeft <= 5) {
          handwrittenNote = 'hurry, lecture starting!';
          topMetaHeadline = 'NEXT UP · STARTING SOON';
        } else if (sessions.any((s) => s.actualEndVal <= currentTime)) {
          handwrittenNote = 'free. grab chai!';
          topMetaHeadline = 'NEXT UP · INTERVAL BREAK';
        } else if (now.hour < 9) {
          handwrittenNote = 'free. grab chai!';
          topMetaHeadline = 'NEXT UP · EARLY MORNING';
        } else {
          handwrittenNote = 'free. grab chai!';
          topMetaHeadline = 'NEXT UP · UPCOMING';
        }
        heroSubject = nextClass.subject;
        heroDetails = '${nextClass.startTime} – ${nextClass.endTime} · Room ${nextClass.room} · $partner';
      } else if (nextClass != null && nextClass.dayIndex != now.weekday) {
        var daysAhead = (nextClass.dayIndex - now.weekday + 7) % 7;
        if (daysAhead == 0) daysAhead = 7;
        final totalMins = ((24.0 - currentTime) * 60 +
                (daysAhead - 1) * 24 * 60 +
                nextClass.safeStartVal * 60)
            .round();
        final hoursUntil = totalMins ~/ 60;
        final dayTarget = daysAhead == 1
            ? 'Tomorrow'
            : _weekdaysShort[(nextClass.dayIndex - 1).clamp(0, 6)];
        final partner = isFaculty ? nextClass.displayBatch : nextClass.teacher;
        countdownDisplay = hoursUntil >= 24 ? '${daysAhead}d ${hoursUntil % 24}h' : '${hoursUntil}h';
        handwrittenNote = now.hour >= 21 ? 'rest well tonight!' : 'day classes done!';
        topMetaHeadline = 'NEXT UP · ${dayTarget.toUpperCase()}';
        heroSubject = nextClass.subject;
        heroDetails = '$dayTarget at ${nextClass.startTime} · Room ${nextClass.room} · $partner';
      } else if (sessions.isNotEmpty && currentTime >= sessions.last.actualEndVal) {
        countdownDisplay = 'All clear';
        handwrittenNote = now.hour >= 21 ? 'free. sleep first!' : 'classes complete!';
        topMetaHeadline = now.hour >= 21 ? 'SCHEDULE · NIGHT' : 'DAY COMPLETE';
        heroSubject = 'All Classes Done For Today';
        heroDetails = 'Campus Library & Portals Available';
      } else if (sessions.isEmpty) {
        countdownDisplay = 'All clear';
        handwrittenNote = 'enjoy your free day!';
        topMetaHeadline = 'SCHEDULE · DAY OFF';
        heroSubject = 'No Classes Scheduled';
        heroDetails = 'Campus Library & Labs Open';
      } else {
        final firstSession = sessions.first;
        final partner = isFaculty ? firstSession.displayBatch : firstSession.teacher;
        countdownDisplay = firstSession.startTime;
        handwrittenNote = 'free. prepare notes!';
        topMetaHeadline = 'NEXT UP · TODAY';
        heroSubject = firstSession.subject;
        heroDetails = '${firstSession.startTime} – ${firstSession.endTime} · Room ${firstSession.room} · $partner';
      }
    } else {
      if (sessions.isEmpty) {
        countdownDisplay = 'Free day';
        handwrittenNote = 'no classes scheduled';
        topMetaHeadline = 'SCHEDULE · DAY OFF';
        heroSubject = 'No Classes Scheduled';
        heroDetails = 'Academic Registry Free';
      } else {
        final firstSession = sessions.first;
        final partner = isFaculty ? firstSession.displayBatch : firstSession.teacher;
        countdownDisplay = firstSession.startTime;
        handwrittenNote = 'first session';
        topMetaHeadline = 'SCHEDULE · PREVIEW';
        heroSubject = firstSession.subject;
        heroDetails = '${firstSession.startTime} – ${firstSession.endTime} · Room ${firstSession.room} · $partner';
      }
    }

    final String dayName = _weekdaysShort[(activeDate.weekday - 1).clamp(0, 6)];
    final String syncTimeStr =
        'SYNCED ${_monthsShort[(now.month - 1).clamp(0, 11)]} ${now.day}, ${now.hour % 12 == 0 ? 12 : now.hour % 12}:${now.minute.toString().padLeft(2, '0')} ${now.hour >= 12 ? 'PM' : 'AM'}';

    return Container(
      color: EditorialTokens.canvas(isDark),
      child: IrisRefreshIndicator(
        onRefresh: () async => onRefresh(),
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(
            parent: BouncingScrollPhysics(),
          ),
          padding: EdgeInsets.zero,
          children: [
            // 1. Atmosphere Castle Canopy Header
            _buildCastleCanopy(context, isDark, now),

            // Main Body Content
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 110),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // 2. Hero Ticket Stub Pass
                  _buildHeroTicketStub(
                    context: context,
                    isDark: isDark,
                    topMetaHeadline: topMetaHeadline,
                    batch: activeIdentity,
                    heroSubject: heroSubject,
                    heroDetails: heroDetails,
                    countdownDisplay: countdownDisplay,
                    handwrittenNote: handwrittenNote,
                    onOpenBatchSelector: onOpenBatchSelector,
                  ),

                  const SizedBox(height: 18),

                  // 3. 7-Day Strip Carousel (Sunday first)
                  _buildSevenDayStrip(
                    isDark: isDark,
                    sundayDate: sundayDate,
                    activeDayIndex: activeDayIndex,
                    onDaySelected: onDaySelected,
                  ),

                  const SizedBox(height: 14),

                  // 4. Meta & Sync Status Row
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: Wrap(
                      alignment: WrapAlignment.spaceBetween,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      spacing: 8,
                      runSpacing: 4,
                      children: [
                        Text(
                          '$dayName · ${activeDayIndex == currentWeekday ? 'TODAY' : 'PREVIEW'}',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.8,
                            color: isDark ? const Color(0xFF8E9BAE) : const Color(0xFF64748B),
                          ),
                        ),
                        Text(
                          syncTimeStr,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 10.5,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.6,
                            color: const Color(0xFF10B981),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 14),

                  // Emergency Announcement Bulletin
                  ValueListenableBuilder<Map<String, dynamic>?>(
                    valueListenable: RemoteConfigService.liveAnnouncement,
                    builder: (context, notice, _) {
                      if (notice == null || notice.isEmpty) return const SizedBox.shrink();
                      final message = (notice['message'] ?? notice['title'] ?? '').toString();
                      if (message.isEmpty) return const SizedBox.shrink();
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 14),
                        child: _buildEmergencyBulletin(isDark, message),
                      );
                    },
                  ),

                  // Timetable Revision Diffs
                  if (pendingChanges.isNotEmpty) ...[
                    _buildTimetableDiffBanner(isDark),
                    const SizedBox(height: 14),
                  ],

                  // Academic Period Mode Banner (Sports Week / Ramadan)
                  ValueListenableBuilder<String>(
                    valueListenable: RemoteConfigService.activeAcademicPeriod,
                    builder: (context, activePeriod, _) {
                      if (activePeriod == 'sports_week') {
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 14),
                          child: StudentsWeekInfoCard(isFaculty: isFaculty),
                        );
                      }
                      if (activePeriod == 'ramadan') {
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 14),
                          child: _buildEmergencyBulletin(
                            isDark,
                            'Ramadan Timings Active · 1-Hour Compressed Lectures (08:30 AM – 01:30 PM)',
                          ),
                        );
                      }
                      return const SizedBox.shrink();
                    },
                  ),

                  // 5. Timeline with "NOW" indicator and Class Passes
                  _buildTimelineAndPasses(
                    context: context,
                    isDark: isDark,
                    now: now,
                    sessions: sessions,
                    currentTime: currentTime,
                    countdownDisplay: countdownDisplay,
                    handwrittenNote: handwrittenNote,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- 1. ATMOSPHERE CASTLE CANOPY HEADER ---
  Widget _buildCastleCanopy(BuildContext context, bool isDark, DateTime now) {
    final topPadding = MediaQuery.viewPaddingOf(context).top;
    final isMorning = now.hour < 12;
    final isNight = now.hour >= 20 || now.hour < 6;
    final greetingTime = isNight ? 'GOOD NIGHT' : (isMorning ? 'GOOD MORNING' : 'GOOD AFTERNOON');
    final displayName = (userName != null && userName!.trim().isNotEmpty) ? userName!.trim() : (isFaculty && teacherName != null && teacherName!.trim().isNotEmpty ? teacherName!.trim() : 'Scholar');

    return SizedBox(
      height: 220 + topPadding,
      child: Stack(
        children: [
          // Background Sky & Castle Silhouette Painter
          Positioned.fill(
            child: CustomPaint(
              painter: _CastleSilhouettePainter(
                isDark: isDark,
                isNight: isNight,
              ),
            ),
          ),

          // Header Bar: Avatar, Greeting, and Action Buttons
          Positioned(
            top: topPadding + 10,
            left: 20,
            right: 20,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Initials Avatar Circle
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isDark ? const Color(0xFFF5EFE0) : const Color(0xFF1E1B38),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.18),
                        blurRadius: 8,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      displayName.length >= 2 ? displayName.substring(0, 2).toUpperCase() : 'MA',
                      style: GoogleFonts.fraunces(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: isDark ? const Color(0xFF1E1B18) : Colors.white,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 14),

                // Greeting & Name
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        greetingTime,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.2,
                          color: isDark ? const Color(0xFF8E9BAE) : const Color(0xFF5A4D41),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        displayName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.fraunces(
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -0.5,
                          color: isDark ? Colors.white : const Color(0xFF1E1B18),
                        ),
                      ),
                    ],
                  ),
                ),

                // Right Action Buttons: Notification Bell & Theme Toggle
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _buildCircleActionButton(
                      icon: Icons.notifications_none_rounded,
                      isDark: isDark,
                      onTap: () {
                        IrisHaptics.actionMedium();
                        pushGlassContainerMorphRoute(
                          context,
                          page: const AnnouncementsScreen(),
                          accentColor: const Color(0xFFD97706),
                        );
                      },
                    ),
                    const SizedBox(width: 8),
                    _buildCircleActionButton(
                      icon: isDark ? Icons.light_mode_outlined : Icons.nightlight_round,
                      isDark: isDark,
                      onTap: onToggleTheme,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCircleActionButton({
    required IconData icon,
    required bool isDark,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: isDark
              ? const Color(0xFF1A1C2C).withValues(alpha: 0.85)
              : Colors.white.withValues(alpha: 0.75),
          border: Border.all(
            color: isDark ? const Color(0xFF283042) : const Color(0xFFE8E2D6),
            width: 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.06),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Center(
          child: Icon(
            icon,
            size: 20,
            color: isDark ? Colors.white : const Color(0xFF1E1B18),
          ),
        ),
      ),
    );
  }

  // --- 2. HERO TICKET STUB PASS ---
  Widget _buildHeroTicketStub({
    required BuildContext context,
    required bool isDark,
    required String topMetaHeadline,
    required String batch,
    required String heroSubject,
    required String heroDetails,
    required String countdownDisplay,
    required String handwrittenNote,
    required VoidCallback onOpenBatchSelector,
  }) {
    final Color ticketBg = isDark ? const Color(0xFFF5EFE0) : const Color(0xFF1E1B38);
    final Color textColor = isDark ? const Color(0xFF1E1B18) : Colors.white;
    final Color mutedTextColor = isDark ? const Color(0xFF6B6358) : const Color(0xFFB0B7C6);
    final Color amberAccent = isDark ? const Color(0xFFD97706) : const Color(0xFFF59E0B);

    return Stack(
      clipBehavior: Clip.none,
      children: [
        // 3D Secondary Paper Slip peeking from behind at an angle
        Positioned.fill(
          child: Transform.rotate(
            angle: -0.022,
            child: Transform.translate(
              offset: const Offset(3, 6),
              child: ClipPath(
                clipper: const _TicketStubClipper(notchRadius: 13, notchYOffset: 142),
                child: Container(
                  decoration: BoxDecoration(
                    color: (isDark ? const Color(0xFF161928) : const Color(0xFFEADBCE))
                        .withValues(alpha: 0.90),
                    border: Border.all(
                      color: (isDark ? const Color(0xFF283042) : const Color(0xFFD6C8B8)),
                      width: 1.0,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),

        // Main Hero Ticket Stub Pass
        Container(
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: isDark ? 0.40 : 0.18),
                blurRadius: 18,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: ClipPath(
            clipper: const _TicketStubClipper(notchRadius: 13, notchYOffset: 142),
            child: Container(
              color: ticketBg,
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Top Meta: Status Headline & Embossed 3D Golden Foil Batch Pill
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          topMetaHeadline,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 10.5,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.0,
                            color: amberAccent,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: () {
                          IrisHaptics.selectionClick();
                          onOpenBatchSelector();
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4.5),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Color(0xFFFFDF73),
                                Color(0xFFD97706),
                                Color(0xFFB45309),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.25),
                                offset: const Offset(0, 2),
                                blurRadius: 4,
                              ),
                            ],
                          ),
                          child: Text(
                            batch,
                            style: GoogleFonts.spaceMono(
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              color: const Color(0xFF1E1B18),
                              letterSpacing: 0.6,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),

              const SizedBox(height: 12),

              // Subject Headline
              Text(
                heroSubject,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.fraunces(
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.4,
                  height: 1.15,
                  color: textColor,
                ),
              ),

              const SizedBox(height: 6),

              // Room & Teacher Details
              Text(
                heroDetails,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w600,
                  color: mutedTextColor,
                ),
              ),

              const SizedBox(height: 18),

              // Horizontal Dashed Perforation Line
              CustomPaint(
                painter: _DashedHorizontalRulePainter(
                  color: (isDark ? Colors.black : Colors.white).withValues(alpha: 0.20),
                ),
                child: const SizedBox(height: 14),
              ),

              const SizedBox(height: 4),

              // Bottom Row: Giant Countdown & Handwritten Note
              Wrap(
                alignment: WrapAlignment.spaceBetween,
                crossAxisAlignment: WrapCrossAlignment.end,
                spacing: 8,
                runSpacing: 4,
                children: [
                  Text(
                    countdownDisplay,
                    style: GoogleFonts.fraunces(
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -0.8,
                      color: textColor,
                    ),
                  ),
                  Text(
                    handwrittenNote,
                    style: GoogleFonts.caveat(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: amberAccent,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ),
  ],
);
  }

  // --- 3. 7-DAY STRIP CAROUSEL (Sunday first) ---
  Widget _buildSevenDayStrip({
    required bool isDark,
    required DateTime sundayDate,
    required int activeDayIndex,
    required ValueChanged<int> onDaySelected,
  }) {
    final Color stripBg = isDark ? const Color(0xFF1E2235) : Colors.white;
    final Color activePillColor = isDark ? const Color(0xFFF59E0B) : const Color(0xFFEFA335);

    // Days list: Sunday (0) to Saturday (6)
    final days = [
      (label: 'SUN', dayIdx: 7),
      (label: 'MON', dayIdx: 1),
      (label: 'TUE', dayIdx: 2),
      (label: 'WED', dayIdx: 3),
      (label: 'THU', dayIdx: 4),
      (label: 'FRI', dayIdx: 5),
      (label: 'SAT', dayIdx: 6),
    ];

    return Container(
      decoration: BoxDecoration(
        color: stripBg,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: isDark ? const Color(0xFF283042) : const Color(0xFFE8E2D6),
          width: 1.0,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.05),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
      child: Row(
        children: List.generate(days.length, (i) {
          final day = days[i];
          final date = sundayDate.add(Duration(days: i));
          final isSelected = (day.dayIdx == activeDayIndex);

          return Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () {
                IrisHaptics.selectionClick();
                onDaySelected(day.dayIdx);
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOutCubic,
                decoration: BoxDecoration(
                  color: isSelected ? activePillColor : Colors.transparent,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: isSelected
                      ? [
                          BoxShadow(
                            color: isDark ? const Color(0xFF78350F) : const Color(0xFFB45309),
                            offset: const Offset(0, 3.5),
                            blurRadius: 0,
                          ),
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.20),
                            offset: const Offset(0, 5),
                            blurRadius: 6,
                          ),
                        ]
                      : null,
                ),
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      day.label,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        color: isSelected
                            ? const Color(0xFF1E1B18)
                            : (isDark ? const Color(0xFF8E9BAE) : const Color(0xFF64748B)),
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      date.day.toString(),
                      style: GoogleFonts.fraunces(
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                        color: isSelected
                            ? const Color(0xFF1E1B18)
                            : (isDark ? Colors.white : const Color(0xFF1E1B18)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  // --- 4. TIMELINE & PERFORATED LECTURE PASSES ---
  Widget _buildTimelineAndPasses({
    required BuildContext context,
    required bool isDark,
    required DateTime now,
    required List<ClassSession> sessions,
    required double currentTime,
    required String countdownDisplay,
    required String handwrittenNote,
  }) {
    final nowTimeStr =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // "NOW" Timestamp Node & Handwritten Note
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(
            children: [
              Container(
                width: 14,
                height: 14,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: const Color(0xFFE5A83B),
                    width: 3.0,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                'NOW · $nowTimeStr',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.6,
                  color: isDark ? const Color(0xFFCBD5E1) : const Color(0xFF334155),
                ),
              ),
            ],
          ),
        ),

        // Handwritten Interval Note
        Padding(
          padding: const EdgeInsets.only(left: 24, bottom: 12),
          child: Text(
            '$countdownDisplay $handwrittenNote',
            style: GoogleFonts.caveat(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: isDark ? const Color(0xFFFBBF24) : const Color(0xFFD97706),
            ),
          ),
        ),

        // Lecture Passes List
        if (sessions.isEmpty)
          Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF181D2B) : Colors.white,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: isDark ? const Color(0xFF283042) : const Color(0xFFE8E2D6),
              ),
            ),
            child: Center(
              child: Text(
                'No classes scheduled for this day.',
                style: GoogleFonts.fraunces(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: isDark ? const Color(0xFF8E9BAE) : const Color(0xFF64748B),
                ),
              ),
            ),
          )
        else
          ...sessions.map((session) {
            final isLive = session.isLive(now);
            final isLab = session.room.toLowerCase().contains('lab') || session.subject.toLowerCase().contains('lab');
            final Color accentColor = isLive
                ? const Color(0xFF10B981)
                : (isLab ? const Color(0xFFF43F5E) : const Color(0xFFF59E0B));

            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: _buildPerforatedClassPass(
                context: context,
                session: session,
                isDark: isDark,
                accentColor: accentColor,
                isLive: isLive,
              ),
            );
          }),
      ],
    );
  }

  // --- PERFORATED TICKET CLASS PASS ---
  Widget _buildPerforatedClassPass({
    required BuildContext context,
    required ClassSession session,
    required bool isDark,
    required Color accentColor,
    required bool isLive,
  }) {
    final Color cardBg = isDark ? const Color(0xFF181D2B) : Colors.white;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => ClassCard.showSessionQuickSheet(context, session, isFacultyView: isFaculty),
      child: Container(
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.05),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Container(
          color: cardBg,
          child: IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Left Vertical Color Stripe
                Container(
                  width: 5,
                  decoration: BoxDecoration(
                    color: accentColor,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(16),
                      bottomLeft: Radius.circular(16),
                    ),
                  ),
                ),

                // Time Column
                Container(
                  width: 80,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        session.startTime,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w800,
                          color: isDark ? Colors.white : const Color(0xFF1E1B18),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        session.endTime,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: isDark ? const Color(0xFF8E9BAE) : const Color(0xFF64748B),
                        ),
                      ),
                    ],
                  ),
                ),

                // Vertical Perforation Divider with Circular Notches
                CustomPaint(
                  painter: _VerticalNotchDividerPainter(
                    isDark: isDark,
                    canvasColor: EditorialTokens.canvas(isDark),
                    dividerColor: isDark ? const Color(0xFF283042) : const Color(0xFFE8E2D6),
                  ),
                  child: const SizedBox(width: 16),
                ),

                // Subject & Room Info
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(6, 14, 14, 14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          session.subject,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            letterSpacing: -0.2,
                            color: isDark ? Colors.white : const Color(0xFF1E1B18),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Text(
                              session.room,
                              style: GoogleFonts.spaceMono(
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: accentColor,
                              ),
                            ),
                            Flexible(
                              child: Text(
                                ' · ${isFaculty ? session.displayBatch : session.teacher}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w600,
                                  color: isDark ? const Color(0xFF8E9BAE) : const Color(0xFF64748B),
                                ),
                              ),
                            ),
                            if (isFaculty && session.isCombinedLecture) ...[
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                                decoration: BoxDecoration(
                                  color: accentColor.withValues(alpha: 0.15),
                                  borderRadius: BorderRadius.circular(4),
                                  border: Border.all(
                                    color: accentColor.withValues(alpha: 0.35),
                                    width: 0.8,
                                  ),
                                ),
                                child: Text(
                                  'COMBINED',
                                  style: GoogleFonts.spaceMono(
                                    fontSize: 9,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.5,
                                    color: accentColor,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ),
    );
  }

  // --- EMERGENCY BULLETIN & DIFF BANNERS ---
  Widget _buildEmergencyBulletin(bool isDark, String notice) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFFDC2626).withValues(alpha: isDark ? 0.20 : 0.10),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFFDC2626).withValues(alpha: 0.6),
          width: 1.0,
        ),
      ),
      child: Row(
        children: [
          const Icon(Icons.campaign_rounded, color: Color(0xFFDC2626), size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              notice,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: isDark ? Colors.white : const Color(0xFF1E1B18),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTimetableDiffBanner(bool isDark) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF3B82F6).withValues(alpha: isDark ? 0.20 : 0.10),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFF3B82F6).withValues(alpha: 0.6),
        ),
      ),
      child: Row(
        children: [
          const Icon(Icons.update_rounded, color: Color(0xFF3B82F6), size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              '${pendingChanges.length} timetable changes detected.',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: isDark ? Colors.white : const Color(0xFF1E1B18),
              ),
            ),
          ),
          if (onDismissChanges != null)
            GestureDetector(
              onTap: onDismissChanges,
              child: const Icon(Icons.close_rounded, size: 16),
            ),
        ],
      ),
    );
  }
}

// ============================================================================
// CUSTOM PAINTERS & CLIPPERS FOR THE EDITORIAL DESIGN LANGUAGE
// ============================================================================

/// Custom clipper for the Hero Ticket Stub, carving semi-circular notches
/// on the left and right borders.
class _TicketStubClipper extends CustomClipper<Path> {
  final double notchRadius;
  final double notchYOffset;

  const _TicketStubClipper({
    required this.notchRadius,
    required this.notchYOffset,
  });

  @override
  Path getClip(Size size) {
    const double radius = 24.0;
    final path = Path();

    // Top-left corner
    path.moveTo(0, radius);
    path.quadraticBezierTo(0, 0, radius, 0);

    // Top edge & Top-right corner
    path.lineTo(size.width - radius, 0);
    path.quadraticBezierTo(size.width, 0, size.width, radius);

    // Right edge down to notch
    path.lineTo(size.width, notchYOffset - notchRadius);
    // Right notch (inward semi-circle)
    path.arcToPoint(
      Offset(size.width, notchYOffset + notchRadius),
      radius: Radius.circular(notchRadius),
      clockwise: false,
    );
    // Right edge down to bottom-right corner
    path.lineTo(size.width, size.height - radius);
    path.quadraticBezierTo(size.width, size.height, size.width - radius, size.height);

    // Bottom edge & Bottom-left corner
    path.lineTo(radius, size.height);
    path.quadraticBezierTo(0, size.height, 0, size.height - radius);

    // Left edge up to notch
    path.lineTo(0, notchYOffset + notchRadius);
    // Left notch (inward semi-circle)
    path.arcToPoint(
      Offset(0, notchYOffset - notchRadius),
      radius: Radius.circular(notchRadius),
      clockwise: false,
    );
    // Left edge back to top
    path.lineTo(0, radius);

    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}

/// Painter for horizontal dashed perforation line across ticket stub
class _DashedHorizontalRulePainter extends CustomPainter {
  final Color color;

  const _DashedHorizontalRulePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke;

    const double dashWidth = 5.0;
    const double dashSpace = 4.0;
    double startX = 0.0;
    final y = size.height / 2;

    while (startX < size.width) {
      canvas.drawLine(
        Offset(startX, y),
        Offset(math.min(startX + dashWidth, size.width), y),
        paint,
      );
      startX += dashWidth + dashSpace;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldPainter) => false;
}

/// Painter for vertical perforated notch divider on class passes
class _VerticalNotchDividerPainter extends CustomPainter {
  final bool isDark;
  final Color canvasColor;
  final Color dividerColor;

  const _VerticalNotchDividerPainter({
    required this.isDark,
    required this.canvasColor,
    required this.dividerColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final notchPaint = Paint()
      ..color = canvasColor
      ..style = PaintingStyle.fill;

    const double notchRadius = 6.0;
    final centerX = size.width / 2;

    // Top cutout notch
    canvas.drawCircle(Offset(centerX, 0), notchRadius, notchPaint);

    // Bottom cutout notch
    canvas.drawCircle(Offset(centerX, size.height), notchRadius, notchPaint);

    // Dashed vertical line
    final dashPaint = Paint()
      ..color = dividerColor
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;

    const double dashHeight = 4.0;
    const double dashSpace = 3.5;
    double startY = notchRadius + 2.0;

    while (startY < size.height - notchRadius - 2.0) {
      canvas.drawLine(
        Offset(centerX, startY),
        Offset(centerX, math.min(startY + dashHeight, size.height - notchRadius - 2.0)),
        dashPaint,
      );
      startY += dashHeight + dashSpace;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldPainter) => false;
}

/// Painter for the Castle Canopy Silhouette & Warm Sky Atmosphere
class _CastleSilhouettePainter extends CustomPainter {
  final bool isDark;
  final bool isNight;

  const _CastleSilhouettePainter({
    required this.isDark,
    required this.isNight,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;

    // 1. Sky Gradient Fill
    final skyPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: isDark
            ? [
                const Color(0xFF0F101A),
                const Color(0xFF161828),
                const Color(0xFF1E2138),
              ]
            : [
                const Color(0xFFF9D6A0),
                const Color(0xFFFBE4BA),
                const Color(0xFFFAF7F2),
              ],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), skyPaint);

    // 2. Stars (in dark/night mode) or Sun (in day mode)
    if (isDark || isNight) {
      final starPaint = Paint()..color = Colors.white.withValues(alpha: 0.65);
      final random = math.Random(42);
      for (int i = 0; i < 24; i++) {
        final x = random.nextDouble() * size.width;
        final y = random.nextDouble() * (size.height * 0.65);
        final r = random.nextDouble() * 1.5 + 0.6;
        canvas.drawCircle(Offset(x, y), r, starPaint);
      }

      // Crescent Moon
      final moonPaint = Paint()..color = const Color(0xFFFEF3C7);
      canvas.drawCircle(Offset(size.width * 0.68, size.height * 0.28), 16, moonPaint);
      final shadowPaint = Paint()..color = const Color(0xFF161828);
      canvas.drawCircle(Offset(size.width * 0.65, size.height * 0.25), 14, shadowPaint);
    } else {
      // Soft layered sun
      final sunPaint1 = Paint()..color = const Color(0xFFFEF08A).withValues(alpha: 0.35);
      final sunPaint2 = Paint()..color = const Color(0xFFFEF08A).withValues(alpha: 0.65);
      canvas.drawCircle(Offset(size.width * 0.68, size.height * 0.30), 44, sunPaint1);
      canvas.drawCircle(Offset(size.width * 0.68, size.height * 0.30), 24, sunPaint2);
    }

    // 3. Castle Silhouette
    final castlePaint = Paint()
      ..color = isDark ? const Color(0xFF121422) : const Color(0xFF4A384C)
      ..style = PaintingStyle.fill;

    final castlePath = Path();
    final baseY = size.height;
    castlePath.moveTo(size.width * 0.32, baseY);

    // Main wall
    castlePath.lineTo(size.width * 0.32, baseY - 80);
    // Battlements
    for (int i = 0; i < 6; i++) {
      final start = size.width * (0.32 + i * 0.08);
      castlePath.lineTo(start, baseY - 80);
      castlePath.lineTo(start, baseY - 94);
      castlePath.lineTo(start + size.width * 0.04, baseY - 94);
      castlePath.lineTo(start + size.width * 0.04, baseY - 80);
    }
    // High tower
    castlePath.lineTo(size.width * 0.80, baseY - 80);
    castlePath.lineTo(size.width * 0.80, baseY - 130);
    castlePath.lineTo(size.width * 0.84, baseY - 160); // Spire
    castlePath.lineTo(size.width * 0.88, baseY - 130);
    castlePath.lineTo(size.width * 0.88, baseY);

    castlePath.close();
    canvas.drawPath(castlePath, castlePaint);

    // 4. Glowing Castle Windows
    final windowPaint = Paint()..color = const Color(0xFFFDE047);
    final List<Offset> windows = [
      Offset(size.width * 0.45, baseY - 50),
      Offset(size.width * 0.58, baseY - 45),
      Offset(size.width * 0.70, baseY - 55),
      Offset(size.width * 0.83, baseY - 90),
      Offset(size.width * 0.85, baseY - 110),
    ];
    for (final win in windows) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: win, width: 4.5, height: 7),
          const Radius.circular(1.5),
        ),
        windowPaint,
      );
    }

    // 5. Slanted Street Lamp
    final lampPolePaint = Paint()
      ..color = const Color(0xFF854D0E)
      ..strokeWidth = 3.5
      ..style = PaintingStyle.stroke;
    canvas.drawLine(
      Offset(size.width * 0.10, baseY),
      Offset(size.width * 0.28, baseY - 90),
      lampPolePaint,
    );
    // Lamp Shade
    final lampHeadPaint = Paint()..color = const Color(0xFFCA8A04);
    final lampHeadPath = Path()
      ..moveTo(size.width * 0.24, baseY - 88)
      ..lineTo(size.width * 0.34, baseY - 102)
      ..lineTo(size.width * 0.38, baseY - 92)
      ..lineTo(size.width * 0.28, baseY - 80)
      ..close();
    canvas.drawPath(lampHeadPath, lampHeadPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldPainter) => false;
}
