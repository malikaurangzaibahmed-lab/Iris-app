import 'sports_gala_view.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iris/core/line_theme_tokens.dart';
import 'package:iris/core/models.dart';
import 'package:iris/core/omni_brain.dart';
import 'package:iris/services/remote_config_service.dart';
import 'package:iris/services/ui_feedback.dart';
import 'package:iris/widgets/iris_components.dart';
import 'package:iris/widgets/effects/glass_container_transform.dart';
import 'package:iris/screens/settings/announcements_screen.dart';

/// Authentic Urban Metro Transit Line Schedule View
/// (Modeled with 100% pixel fidelity after Line · Light.png & Line · Dark.png).
/// Breaks completely free from rectangular cards, transforming the schedule into
/// a continuous 3D elevated subway rail line with station stops and LED signs.
class LineScheduleView extends StatelessWidget {
  final OmniBrain brain;
  final String batch;
  final int activeDayIndex; // 1=Mon ... 7=Sun
  final ValueChanged<int> onDaySelected;
  final Future<void> Function() onRefresh;
  final VoidCallback onOpenBatchSelector;
  final ScrollController? scrollController;
  final List<String> pendingChanges;
  final VoidCallback? onDismissChanges;
  final String? userName;
  final bool isFaculty;
  final String? teacherName;

  static const List<String> _months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];
  static const List<String> _weekdays = [
    'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'
  ];

  const LineScheduleView({
    super.key,
    required this.brain,
    required this.batch,
    required this.activeDayIndex,
    required this.onDaySelected,
    required this.onRefresh,
    required this.onOpenBatchSelector,
    this.scrollController,
    this.pendingChanges = const [],
    this.onDismissChanges,
    this.userName,
    this.isFaculty = false,
    this.teacherName,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final topPadding = MediaQuery.paddingOf(context).top;
    final now = DateTime.now();
    final todayWeekday = now.weekday; // 1=Mon ... 7=Sun
    final isViewingToday = activeDayIndex == todayWeekday;

    final currentClass = isViewingToday
        ? (isFaculty && teacherName != null
            ? brain.getCurrentClassForTeacher(teacherName!, now)
            : brain.getCurrentClass(batch, now))
        : null;
    final nextClass = isViewingToday
        ? (isFaculty && teacherName != null
            ? brain.getNextClassForTeacher(teacherName!, now)
            : brain.getNextClass(batch, now))
        : null;
    final rawSessions = isFaculty && teacherName != null
        ? brain.getMergedDayScheduleForTeacher(teacherName!, activeDayIndex)
        : brain.getMergedDaySchedule(batch, activeDayIndex);
    final sortedSessions = List<ClassSession>.from(rawSessions)
      ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));

    final isLive = currentClass != null;
    final railColor = LineTokens.railLine(isDark);

    return Container(
      color: LineTokens.canvas(isDark),
      child: IrisRefreshIndicator(
        onRefresh: onRefresh,
        color: railColor,
        backgroundColor: LineTokens.cardSurface(isDark),
        child: CustomScrollView(
          controller: scrollController,
          physics: const AlwaysScrollableScrollPhysics(
            parent: BouncingScrollPhysics(),
          ),
          slivers: [
            // 1. Line Transit Header & Departure LED Clock
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(20, topPadding + 14, 20, 12),
                child: _buildLineHeader(context, isDark, isViewingToday, now),
              ),
            ),

            // 2. 7-Day Transit Day Switcher Tiles
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                child: _build7DayTiles(context, isDark, now),
              ),
            ),

            // 2B. Sports Week Service Advisory
            ValueListenableBuilder<String>(
              valueListenable: RemoteConfigService.activeAcademicPeriod,
              builder: (context, activePeriod, _) {
                if (activePeriod == 'sports_week') {
                  return SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 18),
                      child: StudentsWeekInfoCard(isFaculty: isFaculty),
                    ),
                  );
                }
                return const SliverToBoxAdapter(child: SizedBox.shrink());
              },
            ),

            // 3. The Continuous Transit Rail Section
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: _buildSubwayTrackSection(
                  context,
                  isDark: isDark,
                  sortedSessions: sortedSessions,
                  currentClass: currentClass,
                  nextClass: nextClass,
                  isLive: isLive,
                  isViewingToday: isViewingToday,
                  now: now,
                ),
              ),
            ),

            const SliverToBoxAdapter(
              child: SizedBox(height: 120),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 1. Line Transit Header
  // ---------------------------------------------------------------------------
  Widget _buildLineHeader(BuildContext context, bool isDark, bool isViewingToday, DateTime now) {
    final activeDate = _getDateForSelectedDay(now);
    final dayCode = _weekdays[activeDate.weekday - 1].toUpperCase();
    final dayNum = activeDate.day.toString().padLeft(2, '0');

    final allBatches = brain.memory.allBatches;
    final batchCode = isFaculty
        ? (teacherName?.trim().isNotEmpty == true ? teacherName!.trim() : 'FACULTY')
        : (batch.trim().isNotEmpty
            ? batch.trim()
            : (allBatches.isNotEmpty ? allBatches.first : 'COMSATS'));
    final nowH24 = now.hour.toString().padLeft(2, '0');
    final nowM = now.minute.toString().padLeft(2, '0');
    final nowTimeStr = '$nowH24:$nowM';

    return Wrap(
      alignment: WrapAlignment.spaceBetween,
      crossAxisAlignment: WrapCrossAlignment.start,
      spacing: 12,
      runSpacing: 10,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            GestureDetector(
              onTap: () {
                IrisHaptics.actionSoft();
                onOpenBatchSelector();
              },
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'LINE $batchCode',
                    style: LineTokens.lineTag(isDark),
                  ),
                  const SizedBox(width: 4),
                  Icon(
                    Icons.arrow_drop_down_rounded,
                    size: 16,
                    color: LineTokens.inkMuted(isDark),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 4),
            Text(
              '$dayCode $dayNum',
              style: LineTokens.heroMonDate(isDark),
            ),
          ],
        ),

        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Terminal Bulletin Trigger
            GestureDetector(
              onTap: () {
                IrisHaptics.actionMedium();
                pushGlassContainerMorphRoute(
                  context,
                  page: const AnnouncementsScreen(),
                  accentColor: LineTokens.subwayYellow,
                );
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF1E232B) : const Color(0xFFE4DFD3),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: LineTokens.railLine(isDark),
                    width: 1.2,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.campaign_rounded,
                      size: 15,
                      color: LineTokens.railLine(isDark),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      'BULLETIN',
                      style: GoogleFonts.spaceMono(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.8,
                        color: LineTokens.inkHeading(isDark),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),

            // Glowing Yellow LED Departure Clock Pill
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: LineTokens.ledAmber,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: LineTokens.ledAmber.withValues(alpha: 0.35),
                    offset: const Offset(0, 3),
                    blurRadius: 8,
                  ),
                ],
              ),
              child: Text(
                'NOW $nowTimeStr',
                style: GoogleFonts.archivoBlack(
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.5,
                  color: LineTokens.ledBlack,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // 2. 7-Day Transit Day Switcher Tiles
  // ---------------------------------------------------------------------------
  Widget _build7DayTiles(BuildContext context, bool isDark, DateTime now) {
    const daysInitials = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    final weekStart = now.subtract(Duration(days: now.weekday % 7));
    final currentSelectedStripIndex = activeDayIndex % 7;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: List.generate(7, (index) {
        final dayDate = weekStart.add(Duration(days: index));
        final isSelected = currentSelectedStripIndex == index;

        return Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2.5),
            child: GestureDetector(
              onTap: () {
                IrisHaptics.selectionClick();
                final targetDay = index == 0 ? 7 : index;
                onDaySelected(targetDay);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: isSelected
                      ? LineTokens.subwayYellow
                      : (isDark ? const Color(0xFF181C22) : const Color(0xFFE8E4DA)),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: isSelected
                        ? LineTokens.subwayYellow
                        : (isDark ? const Color(0xFF28303C) : const Color(0xFFD6D1C4)),
                    width: 1.2,
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      daysInitials[index],
                      style: GoogleFonts.spaceMono(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: isSelected
                            ? LineTokens.ledBlack
                            : LineTokens.inkMuted(isDark),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${dayDate.day}',
                      style: GoogleFonts.archivoBlack(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        color: isSelected
                            ? LineTokens.ledBlack
                            : LineTokens.inkHeading(isDark),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }),
    );
  }

  // ---------------------------------------------------------------------------
  // 3. Continuous Subway Rail Line Track Section
  // ---------------------------------------------------------------------------
  Widget _buildSubwayTrackSection(
    BuildContext context, {
    required bool isDark,
    required List<ClassSession> sortedSessions,
    required ClassSession? currentClass,
    required ClassSession? nextClass,
    required bool isLive,
    required bool isViewingToday,
    required DateTime now,
  }) {
    const railX = 22.0;
    final double currentTime = now.hour + (now.minute / 60.0);
    final List<Widget> stationWidgets = [];

    if (!isViewingToday) {
      stationWidgets.add(
        _buildYouAreHereStation(
          context,
          isDark: isDark,
          railX: railX,
          beaconTitle: 'TIMETABLE OVERVIEW',
          hudText: sortedSessions.isNotEmpty
              ? '${sortedSessions.length} RUNS SCHEDULED'
              : 'NO RUNS SCHEDULED',
          subText: sortedSessions.isNotEmpty
              ? 'First departure at ${sortedSessions.first.startTime} (${sortedSessions.first.room}).'
              : 'Academic registry line is inactive.',
        ),
      );
      stationWidgets.add(const SizedBox(height: 36));

      if (sortedSessions.isEmpty) {
        stationWidgets.add(_buildEmptyLineNotice(railX, isDark));
      } else {
        for (final session in sortedSessions) {
          stationWidgets.add(
            Padding(
              padding: const EdgeInsets.only(bottom: 38),
              child: _buildClassStationStop(
                context,
                isDark: isDark,
                railX: railX,
                session: session,
                isLive: false,
              ),
            ),
          );
        }
      }

      stationWidgets.add(
        _buildEndOfLineStation(
          isDark: isDark,
          railX: railX,
          lastSession: sortedSessions.isNotEmpty ? sortedSessions.last : null,
        ),
      );
    } else {
      if (sortedSessions.isEmpty) {
        final String hud;
        final String sub;
        if (nextClass != null) {
          var daysAhead = (nextClass.dayIndex - now.weekday + 7) % 7;
          if (daysAhead == 0) daysAhead = 7;
          final dayTarget = daysAhead == 1
              ? 'Tomorrow'
              : _weekdays[(nextClass.dayIndex - 1).clamp(0, 6)].toUpperCase();
          final totalMins = ((24.0 - currentTime) * 60 +
                  (daysAhead - 1) * 24 * 60 +
                  nextClass.safeStartVal * 60)
              .round();
          final h = totalMins ~/ 60;
          hud = h >= 24 ? 'IN ${daysAhead}D ${h % 24}H' : 'IN ${h}H';
          sub = 'Next departure $dayTarget at ${nextClass.startTime} (${nextClass.room} · ${nextClass.subject}).';
        } else {
          hud = 'ALL CLEAR';
          sub = 'No runs scheduled on timetable.';
        }

        stationWidgets.add(
          _buildYouAreHereStation(
            context,
            isDark: isDark,
            railX: railX,
            beaconTitle: 'YOU ARE HERE · DEPOT',
            hudText: hud,
            subText: sub,
          ),
        );
        stationWidgets.add(const SizedBox(height: 36));
        stationWidgets.add(_buildEmptyLineNotice(railX, isDark));
        stationWidgets.add(
          _buildEndOfLineStation(
            isDark: isDark,
            railX: railX,
            lastSession: null,
          ),
        );
      } else {
        final bool beforeFirstClass = currentTime < sortedSessions.first.safeStartVal;
        final bool afterLastClass = currentTime >= sortedSessions.last.actualEndVal;

        if (beforeFirstClass) {
          final diff = sortedSessions.first.safeStartVal - currentTime;
          final totalMins = (diff * 60).round();
          final h = totalMins ~/ 60;
          final m = totalMins % 60;
          final timeStr = h > 0 ? '${h}h ${m}m' : '${m}m';

          stationWidgets.add(
            _buildYouAreHereStation(
              context,
              isDark: isDark,
              railX: railX,
              beaconTitle: 'YOU ARE HERE · ORIGIN DEPOT',
              hudText: '$timeStr TO FIRST RUN',
              subText: 'Boarding begins soon. First run at ${sortedSessions.first.startTime} (${sortedSessions.first.room}).',
            ),
          );
          stationWidgets.add(const SizedBox(height: 36));

          for (final session in sortedSessions) {
            stationWidgets.add(
              Padding(
                padding: const EdgeInsets.only(bottom: 38),
                child: _buildClassStationStop(
                  context,
                  isDark: isDark,
                  railX: railX,
                  session: session,
                  isLive: false,
                ),
              ),
            );
          }

          stationWidgets.add(
            _buildEndOfLineStation(
              isDark: isDark,
              railX: railX,
              lastSession: sortedSessions.last,
            ),
          );
        } else if (afterLastClass) {
          for (final session in sortedSessions) {
            stationWidgets.add(
              Padding(
                padding: const EdgeInsets.only(bottom: 38),
                child: _buildClassStationStop(
                  context,
                  isDark: isDark,
                  railX: railX,
                  session: session,
                  isLive: false,
                  isCompleted: true,
                ),
              ),
            );
          }

          final String hud;
          final String sub;
          if (nextClass != null && nextClass.dayIndex != now.weekday) {
            var daysAhead = (nextClass.dayIndex - now.weekday + 7) % 7;
            if (daysAhead == 0) daysAhead = 7;
            final dayTarget = daysAhead == 1
                ? 'Tomorrow'
                : _weekdays[(nextClass.dayIndex - 1).clamp(0, 6)].toUpperCase();
            final totalMins = ((24.0 - currentTime) * 60 +
                    (daysAhead - 1) * 24 * 60 +
                    nextClass.safeStartVal * 60)
                .round();
            final h = totalMins ~/ 60;
            hud = h >= 24 ? 'NEXT DEPARTURE ${daysAhead}D' : 'NEXT IN ${h}H';
            sub = 'Service completed for today. Next departure $dayTarget at ${nextClass.startTime} (${nextClass.room} · ${nextClass.subject}).';
          } else {
            hud = 'ALL RUNS COMPLETED';
            sub = 'Service completed for today. Night depot maintenance active.';
          }

          stationWidgets.add(
            _buildYouAreHereStation(
              context,
              isDark: isDark,
              railX: railX,
              beaconTitle: 'YOU ARE HERE · TERMINUS REACHED',
              hudText: hud,
              subText: sub,
            ),
          );
        } else {
          int transitBreakAfterIndex = -1;
          for (int i = 0; i < sortedSessions.length - 1; i++) {
            if (currentTime >= sortedSessions[i].actualEndVal && currentTime < sortedSessions[i + 1].safeStartVal) {
              transitBreakAfterIndex = i;
              break;
            }
          }

          for (int i = 0; i < sortedSessions.length; i++) {
            final session = sortedSessions[i];
            final isSessionLive = isLive && currentClass?.id == session.id;
            final isCompleted = currentTime >= session.actualEndVal;

            if (isSessionLive) {
              final minsLeft = ((session.actualEndVal - currentTime) * 60).clamp(0, 300).round();
              final partner = isFaculty ? session.displayBatch : session.teacher;
              stationWidgets.add(
                _buildYouAreHereStation(
                  context,
                  isDark: isDark,
                  railX: railX,
                  beaconTitle: 'YOU ARE HERE · NOW AT PLATFORM',
                  hudText: 'IN SESSION · ${minsLeft}m LEFT',
                  subText: '${session.subject} in Room ${session.room} with $partner until ${session.endTime}.',
                ),
              );
              stationWidgets.add(const SizedBox(height: 24));
            }

            stationWidgets.add(
              Padding(
                padding: const EdgeInsets.only(bottom: 38),
                child: _buildClassStationStop(
                  context,
                  isDark: isDark,
                  railX: railX,
                  session: session,
                  isLive: isSessionLive,
                  isCompleted: isCompleted,
                ),
              ),
            );

            if (i == transitBreakAfterIndex) {
              final nextSession = sortedSessions[i + 1];
              final minsLeft = ((nextSession.safeStartVal - currentTime) * 60).clamp(0, 300).round();
              stationWidgets.add(
                _buildYouAreHereStation(
                  context,
                  isDark: isDark,
                  railX: railX,
                  beaconTitle: 'YOU ARE HERE · TRANSIT EN ROUTE',
                  hudText: '${minsLeft}m INTERVAL BREAK',
                  subText: 'Next stop Room ${nextSession.room} for ${nextSession.subject} at ${nextSession.startTime}.',
                ),
              );
              stationWidgets.add(const SizedBox(height: 36));
            }
          }

          stationWidgets.add(
            _buildEndOfLineStation(
              isDark: isDark,
              railX: railX,
              lastSession: sortedSessions.last,
            ),
          );
        }
      }
    }

    return Stack(
      clipBehavior: Clip.none,
      children: [
        // 1. Continuous Vertical Elevated Rail Track
        Positioned.fill(
          child: CustomPaint(
            painter: SubwayRailTrackPainter(
              isDark: isDark,
              railX: railX,
              topOffset: 12.0,
              bottomOffset: 48.0,
            ),
          ),
        ),

        // 2. Station Stops
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: stationWidgets,
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // "YOU ARE HERE" Station Node
  // ---------------------------------------------------------------------------
  Widget _buildYouAreHereStation(
    BuildContext context, {
    required bool isDark,
    required double railX,
    required String beaconTitle,
    required String hudText,
    required String subText,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Circular Station Stop Ring centered on rail line
        SizedBox(
          width: railX * 2,
          child: Center(
            child: StationStopNode(
              isCurrentPosition: true,
              isDark: isDark,
              size: 24,
            ),
          ),
        ),

        const SizedBox(width: 14),

        // Station Info Content
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                beaconTitle,
                style: GoogleFonts.spaceMono(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.0,
                  color: LineTokens.inkHeading(isDark),
                ),
              ),
              const SizedBox(height: 8),

              // Dashed HUD Box
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color: LineTokens.inkHeading(isDark).withValues(alpha: 0.6),
                    width: 1.5,
                  ),
                ),
                child: Text(
                  hudText,
                  style: GoogleFonts.archivoBlack(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.8,
                    color: LineTokens.inkHeading(isDark),
                  ),
                ),
              ),
              const SizedBox(height: 6),

              Text(
                subText,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 13,
                  fontStyle: FontStyle.italic,
                  color: LineTokens.inkMuted(isDark),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // Class Station Stop Node
  // ---------------------------------------------------------------------------
  Widget _buildClassStationStop(
    BuildContext context, {
    required bool isDark,
    required double railX,
    required ClassSession session,
    required bool isLive,
    bool isCompleted = false,
  }) {
    final durationMins = ((session.actualEndVal - session.safeStartVal) * 60).round();
    final durationStr = '${durationMins ~/ 60}h ${durationMins % 60}m';
    final opacity = isCompleted ? 0.5 : 1.0;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => ClassCard.showSessionQuickSheet(context, session, isFacultyView: isFaculty),
      child: Opacity(
      opacity: opacity,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Circular Station Stop Ring centered on rail
          SizedBox(
            width: railX * 2,
            child: Center(
              child: StationStopNode(
                isCurrentPosition: isLive,
                isDark: isDark,
                size: 20,
              ),
            ),
          ),

          const SizedBox(width: 14),

          // Station Class Content
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Departure Time in Red / Yellow Grotesque
                Text(
                  session.startTime,
                  style: LineTokens.departureTime(isDark),
                ),
                const SizedBox(height: 2),

                // Station Name in Heavy Grotesque Uppercase
                Text(
                  session.subject.toUpperCase(),
                  style: LineTokens.stationName(isDark),
                ),
                const SizedBox(height: 8),

                // Platform Pill & Instructor
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                      decoration: BoxDecoration(
                        color: LineTokens.subwayYellow,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        session.room,
                        style: GoogleFonts.archivoBlack(
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                          color: LineTokens.ledBlack,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        '${isFaculty ? (session.displayBatch.isNotEmpty ? session.displayBatch : "Class") : session.teacher} · $durationStr',
                        overflow: TextOverflow.ellipsis,
                        style: LineTokens.stationMeta(isDark),
                      ),
                    ),
                    if (isFaculty && session.isCombinedLecture) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: LineTokens.subwayYellow.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(color: LineTokens.subwayYellow, width: 1.0),
                        ),
                        child: Text(
                          'COMBINED',
                          style: GoogleFonts.spaceMono(
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            color: isDark ? Colors.white : Colors.black,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    ),
    );
  }

  // ---------------------------------------------------------------------------
  // End of Line Station
  // ---------------------------------------------------------------------------
  Widget _buildEndOfLineStation({
    required bool isDark,
    required double railX,
    required ClassSession? lastSession,
  }) {
    final endTimeStr = lastSession != null ? ' · ${lastSession.endTime}' : '';

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Railroad Bumper Bar
        SizedBox(
          width: railX * 2,
          child: Center(
            child: Container(
              width: 18,
              height: 6,
              decoration: BoxDecoration(
                color: isDark ? Colors.white : const Color(0xFF0F1419),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
        ),

        const SizedBox(width: 14),

        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'END OF LINE$endTimeStr',
                style: GoogleFonts.archivoBlack(
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.6,
                  color: LineTokens.inkHeading(isDark),
                ),
              ),
              const SizedBox(height: 4),
              ValueListenableBuilder<DateTime?>(
                valueListenable: RemoteConfigService.lastTimetableUpdateTime,
                builder: (context, lastSync, _) {
                  final syncTime = lastSync ?? RemoteConfigService.lastConfigUpdateTime.value ?? DateTime.now();
                  final h12 = syncTime.hour % 12 == 0 ? 12 : syncTime.hour % 12;
                  final ampm = syncTime.hour >= 12 ? 'PM' : 'AM';
                  final mPad = syncTime.minute.toString().padLeft(2, '0');
                  final monthStr = _months[syncTime.month - 1];
                  return Text(
                    'Timetable synced $monthStr ${syncTime.day}, $h12:$mPad $ampm',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 12,
                      color: LineTokens.inkMuted(isDark),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyLineNotice(double railX, bool isDark) {
    return Row(
      children: [
        SizedBox(width: railX * 2),
        const SizedBox(width: 14),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 24),
            child: Text(
              'NO ACTIVE RUNS SCHEDULED ON THIS TRACK.',
              style: GoogleFonts.spaceMono(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: LineTokens.inkMuted(isDark),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------
  DateTime _getDateForSelectedDay(DateTime now) {
    final currentDay = now.weekday;
    final diff = activeDayIndex - currentDay;
    return now.add(Duration(days: diff));
  }
}
