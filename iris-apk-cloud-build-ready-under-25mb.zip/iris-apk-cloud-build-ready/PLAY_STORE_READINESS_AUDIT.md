# IRIS Enhanced — Google Play Store Readiness & Policy Compliance Audit

**Generated Date**: October 8, 2026  
**Target Platform**: Android (Google Play Console)  
**Target SDK**: Android 14 / 15 (API 34–35)  
**App Version**: `1.0.3+4`

---

## Executive Summary

This document provides a comprehensive, rigorous, and unvarnished audit of **IRIS Enhanced** regarding its readiness for publication on the **Google Play Store**. 

While the app features state-of-the-art Material 3 Expressive motion physics, real-time timetable algorithms, and rich campus features, **it currently contains critical policy blockers, forbidden permissions, and build configurations that will trigger immediate rejection or account suspension by Google Play Review bots if submitted as-is.**

---

## 1. Critical Policy Blockers (Immediate Rejections)

| # | Issue / Code Reference | Policy Clause | Impact | Required Remediation |
|---|---|---|---|---|
| **1.1** | `android.permission.REQUEST_INSTALL_PACKAGES`<br>`android/app/src/main/AndroidManifest.xml` (Line 14)<br>`RemoteConfigService` (`apk_url`) | **Device and Network Abuse & Malicious Behavior** | **Immediate Rejection / Potential App Suspension** | Remove permission from manifest. Replace in-app APK installer with a redirect to the Google Play Store URL. |
| **1.2** | `android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`<br>`android/app/src/main/AndroidManifest.xml` (Line 10) | **Battery Saver & Background Execution Policy** | **Rejection during Permission Declaration** | Remove permission. Battery optimization exemption is only permitted for emergency or critical VoIP apps. |
| **1.3** | Dual Exact Alarm Declarations:<br>`SCHEDULE_EXACT_ALARM`<br>`USE_EXACT_ALARM`<br>`AndroidManifest.xml` (Lines 12–13) | **Exact Alarm Policy (Android 13/14+)** | **Manifest Validation Failure** | Remove `USE_EXACT_ALARM`. Keep only `SCHEDULE_EXACT_ALARM` with declared timetable notification justification. |
| **1.4** | `FOREGROUND_SERVICE_DATA_SYNC`<br>`AndroidManifest.xml` (Line 7)<br>`flutter_foreground_task` | **Foreground Service Policy (Android 14+ / API 34)** | **Rejection unless justified by video proof** | Submit a video demonstrating the user-facing live class countdown notification, or rely on inexact background jobs. |
| **1.5** | University Crest / Logo Assets<br>`assets/comsats_logo.png`<br>`assets/comsats_logo.jpg` | **Impersonation & Intellectual Property Policy** | **Automated Trademark Suspension** | Remove university logo from app icon and store screenshots. Include explicit "Unofficial companion" disclaimer. |

---

### Detailed Policy Breakdown

### 1.1 In-App APK Updates (`REQUEST_INSTALL_PACKAGES`)
- **What is in the code**:
  In `AndroidManifest.xml`:
  ```xml
  <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />
  ```
  In `RemoteConfigService.dart`:
  ```dart
  final apkUrl = updateData['apk_url']?.toString() ?? ...
  ```
- **Why Google rejects this**:
  Google Play prohibits apps distributed via the Play Store from updating themselves, downloading external APK files, or asking the user to install third-party packages. Only file managers and alternative app stores qualify for this permission.
- **The Fix**:
  1. Remove `REQUEST_INSTALL_PACKAGES` from `AndroidManifest.xml`.
  2. In `RemoteConfigService`, replace APK download triggers with `url_launcher`:
     ```dart
     launchUrl(Uri.parse('market://details?id=com.iris.app'), mode: LaunchMode.externalApplication);
     ```

---

### 1.2 Battery Optimization Bypass (`REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`)
- **What is in the code**:
  ```xml
  <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
  ```
- **Why Google rejects this**:
  Prompting users to whitelist an application from Android's battery manager is strictly monitored. Unless your app's core function is device telemetry or medical monitoring, Google Play will reject the declaration form.
- **The Fix**:
  Delete line 10 from `android/app/src/main/AndroidManifest.xml`.

---

### 1.3 Exact Alarm Conflicts (`USE_EXACT_ALARM` vs `SCHEDULE_EXACT_ALARM`)
- **What is in the code**:
  ```xml
  <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
  <uses-permission android:name="android.permission.USE_EXACT_ALARM" />
  ```
- **Why Google rejects this**:
  `USE_EXACT_ALARM` is granted **only** to dedicated alarm clock apps, stopwatch/timer apps, or calendar apps whose primary utility is setting alarms. Timetable and education apps must use `SCHEDULE_EXACT_ALARM` and provide a user toggle.
- **The Fix**:
  Remove `<uses-permission android:name="android.permission.USE_EXACT_ALARM" />`.

---

### 1.4 Intellectual Property & Impersonation (COMSATS Branding)
- **What is in the code**:
  The repository contains `assets/comsats_logo.png`, `assets/comsats_logo.jpg`, and references to "COMSATS Student Portal" and "COMSATS Faculty Portal".
- **Why Google rejects this**:
  Google uses automated visual scrapers to match logos against university databases. If an app uses an official university crest or trademark without an **Advance Notice / Letter of Authorization (LoA)** signed by the university registrar, it is suspended for impersonation.
- **The Fix**:
  1. Ensure the store app icon uses only the custom geometric **IRIS** logo (`assets/iris_logo.PNG`).
  2. In your Google Play Store short and full descriptions, append this disclaimer:
     > *"Disclaimer: IRIS is an independent student and faculty utility created to view academic timetables and rooms. IRIS is not affiliated with, endorsed by, sponsored by, or officially associated with COMSATS University Islamabad."*

---

## 2. Technical Build & Packaging Requirements

### 2.1 Release Signing with Debug Key (Critical Blocker)
In `android/app/build.gradle.kts`:
```kotlin
buildTypes {
    release {
        signingConfig = signingConfigs.getByName("debug") // <-- REJECTED BY PLAY STORE
        proguardFiles(
            getDefaultProguardFile("proguard-android-optimize.txt"),
            "proguard-rules.pro"
        )
    }
}
```
**Google Play Console will not allow you to upload an App Bundle signed with a debug certificate.**

#### How to Fix:
1. Generate an official upload keystore using `keytool`:
   ```powershell
   keytool -genkey -v -keystore android/upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
   ```
2. Create `android/key.properties`:
   ```properties
   storePassword=YOUR_STORE_PASSWORD
   keyPassword=YOUR_KEY_PASSWORD
   keyAlias=upload
   storeFile=upload-keystore.jks
   ```
3. Update `android/app/build.gradle.kts` to load `key.properties` for the release build type.

---

### 2.2 Android App Bundle (.aab) Requirement
Google Play has completely deprecated `.apk` uploads for new apps. You must generate an `.aab`:
```powershell
flutter build appbundle --release
```
The output file is located at:
`build/app/outputs/bundle/release/app-release.aab`

---

### 2.3 Package Name Collision Check (`com.iris.app`)
In `android/app/build.gradle.kts`:
```kotlin
applicationId = "com.iris.app"
```
Because `com.iris.app` is generic, another developer may have registered it on Google Play Console.
- If Play Console says: *"Package name already in use by another application"*, rename the application ID to a unique namespace such as:
  `com.nexsync.iris` or `com.irisenhanced.app`
- Update:
  1. `applicationId` in `android/app/build.gradle.kts`
  2. `package_name` in `android/app/google-services.json` (or download a fresh JSON from Firebase)

---

## 3. Google Play Console Mandatory Checklist

### 3.1 20-Tester Closed Testing Requirement (Personal Accounts)
> [!IMPORTANT]
> Since November 13, 2023, Google requires all new personal developer accounts to run a **Closed Testing Track with at least 20 opted-in testers for 14 continuous days** before Google enables the button to apply for Production access.

- **Requirement**: You must create a Closed Testing track in Play Console, upload your `.aab`, and invite at least 20 Google accounts.
- **Rule**: All 20 testers must remain opted in for 14 days without opting out.

---

### 3.2 Publicly Hosted Privacy Policy URL
Google Play Console requires a public URL entered under **App Content $\rightarrow$ Privacy Policy**.
- IRIS already has the complete policy text written inside [`lib/screens/legal_screens.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/legal_screens.dart).
- **Action Required**: Host this exact markdown text on a public GitHub Pages repository (e.g. `https://yourusername.github.io/iris-privacy-policy/`) or a free static host.

---

### 3.3 Data Safety Declaration Questionnaire
When filling out the **Data Safety** section on Play Console, declare:
1. **Analytics**: Disclose that `firebase_analytics` collects app interactions and crash diagnostics.
2. **Device / Other IDs**: Disclose device identifiers used for FCM notifications (`firebase_messaging`).
3. **Data Sharing**: Declare that data is **NOT shared with third parties** for advertising purposes.
4. **Data Deletion**: State that users can wipe all local cached timetables and preferences directly via the in-app "Reset System Data" button in Settings / Iris Hub.

---

### 3.4 Reviewer App Access Mode
Google Play reviewers must be able to test the application.
- In **App Content $\rightarrow$ App Access**, select:
  *"All or some functionality is restricted"*
- Provide instructions:
  > *"The timetable schedule, room locator, and tools can be explored immediately without logging in by selecting any batch (e.g., BCS-1A) on the initial setup wizard. The 'Student Portal' tab embeds an external university web portal."*

---

## 4. Action Checklist Prior to Play Store Upload

```markdown
- [ ] 1. Remove REQUEST_INSTALL_PACKAGES from AndroidManifest.xml
- [ ] 2. Remove REQUEST_IGNORE_BATTERY_OPTIMIZATIONS from AndroidManifest.xml
- [ ] 3. Remove USE_EXACT_ALARM from AndroidManifest.xml (keep SCHEDULE_EXACT_ALARM)
- [ ] 4. Replace in-app APK updater in RemoteConfigService with Play Store redirect
- [ ] 5. Generate android/upload-keystore.jks and android/key.properties
- [ ] 6. Update android/app/build.gradle.kts to use release signing config
- [ ] 7. Host Privacy Policy on GitHub Pages and obtain live URL
- [ ] 8. Verify package name uniqueness on Play Console (switch to com.nexsync.iris if needed)
- [ ] 9. Compile release App Bundle: flutter build appbundle --release
- [ ] 10. Upload .aab to Closed Testing track and recruit 20 testers for 14 days
- [ ] 11. Complete Data Safety questionnaire on Play Console
- [ ] 12. Submit Foreground Service declaration video for live status notification
```
