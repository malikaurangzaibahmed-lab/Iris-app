# 🌌 IRIS Enhanced — Next-Generation Campus Intelligence Suite

> **The Ultimate Autonomous Academic Companion & Campus Cockpit**  
> *Engineered with Flutter 3.29, Firebase Cloud Firestore, Liquid Glass UI Engine, Native Android Glance Widgets, and Real-Time Over-The-Air (OTA) Delivery.*

---

## 🌟 Highlights & Key Innovations

- 📱 **5 Dynamic Academic Modes**: Automatic real-time transitions between **Regular Classes**, **Sports Gala Week**, **Ramadan Compressed Timings**, **Examination Periods (Midterms & Finals)**, and **Vacation Recess**.
- 🎨 **Dual UI Design Engine**: Material 3 Expressive (Google Pixel style) with Monet container tokens, compact useful headers, spring physics, and shared-axis transitions, alongside the Liquid Glass Neomorphic Engine with harmonic Lissajous mesh shaders.
- ⚡ **Real-Time Cloud Synchronization**: Sub-100ms timetable and announcement streaming via Firebase Firestore WebSockets.
- 🏢 **Room Finder & Study Space Intelligence**: Circular vacancy gauge with real-time occupancy indices and AI-calculated study scores.
- 👥 **215+ Faculty Directory**: Searchable instructor roster with live teaching availability (*"Done for today · 3 classes completed"*), office locations, and 1-tap Email/Call integration.
- 📄 **Document Workspace Studio**: Native `.docx` exporter with pre-scaffolded academic templates and official COMSATS Cover Page generator.
- 📊 **CGPA Calculator & Simulator**: Dynamic semester and cumulative GPA projection engine.
- 🚀 **Zero-Glitch Two-Tier OTA Engine**: Instant Shorebird Dart patches + in-app APK background downloader with 5-tier intelligent banner suppression.
- 📦 **Native Android Home Widgets**: Glance widget suite featuring responsive DP breakpoints, live lecture progress bars, and vacation countdowns.

---

## 🏗️ System Architecture

```mermaid
graph TD
    subgraph Cloud Infrastructure
        A[Firebase Firestore] -->|WebSocket Snapshot Stream| B[Flutter Mobile Client]
        C[Firebase Hosting: iris-138ef.web.app] -->|Management Web UI| D[Web Admin Portal]
        D -->|Publishes Config & Timetables| A
        E[GitHub Releases API] -->|Direct Split APK Assets| B
        F[Shorebird Cloud] -->|Silent OTA Dart Patches| B
    end

    subgraph Mobile Core Engine
        B --> G[RemoteConfigService]
        G --> H[5 Dynamic Academic Modes]
        H --> I[Regular Classes Mode]
        H --> J[Sports Gala Break Mode]
        H --> K[Ramadan Timings Mode]
        H --> L[Examination Mode]
        H --> M[Vacation Recess Mode]
        B --> N[Dual UI Engine: M3 Expressive / Liquid Glass]
        B --> O[Native Android Glance Widgets]
        B --> P[Offline SharedPreferences & Asset Fallback]
    end
```

---

## 📚 Comprehensive Documentation Suite

| Document | Purpose & Scope |
| :--- | :--- |
| 📖 [System Architecture & Mechanics Guide](docs/ARCHITECTURE_AND_MECHANICS.md) | Full technical architecture, system overview, dynamic mode mechanics, and directory structure. |
| 🎨 [Frontend System & UI Engine Guide](docs/FRONTEND_SYSTEM_GUIDE.md) | Dual UI Engine (Material 3 Expressive & Liquid Glass), navigation, animations, and Glance widgets. |
| ⚡ [Backend, Cloud Sync & Data Pipelines](docs/BACKEND_AND_CLOUD_SYNC.md) | Firestore schema, Web Admin Portal engine, CUI Helpdesk scrapers, and Excel Quad parser. |
| 🛰️ [CUI Helpdesk Upstream Dossier](docs/CUI_HELPDESK_UPSTREAM_DOSSIER.md) | Reverse-engineered metadata, project IDs, admin session state, and Supabase endpoints. |
| 🧪 [Beta & Staging Multi-Channel Guide](docs/BETA_CHANNEL_GUIDE.md) | Beta testing workflows, in-app channel switcher, and Firestore staged channel rules. |
| 🚀 [Update Delivery & Release Operations](docs/UPDATE_AND_RELEASE_OPERATIONS.md) | Two-tier deployment manual, multi-tier update banner suppression, and release checklists. |

---

## 🛠️ Quick Start & Developer Setup

### Prerequisites
- **Flutter SDK**: `^3.22.0` (Dart 3.4+)
- **Android SDK**: API Level 34 (Android 14) / Min SDK 21 (Android 5.0)
- **Python**: 3.10+ (for tools and data pipeline scripts)

### Installation & Run
```bash
# 1. Clone repository
git clone https://github.com/malikaurangzaibahmed-lab/iris-enhanced.git
cd iris-enhanced

# 2. Install dependencies
flutter pub get

# 3. Analyze codebase (0 issues)
flutter analyze

# 4. Launch app in debug/profile mode
flutter run
```

### Production Release Build (Split APKs ~33 MB)
```bash
flutter build apk --split-per-abi --release
```
*Primary Binary Output*: `build/app/outputs/flutter-apk/app-arm64-v8a-release.apk`

---

## 🌐 Web Admin Portal

The Web Admin Portal is deployed live at **[https://iris-138ef.web.app](https://iris-138ef.web.app)**:
- **Timetable Publishing**: Ingests department Excel/JSON schedules and syncs to student devices instantly.
- **Exam Date Sheets**: Publishes midterm/final date sheets with 2-hall allocations.
- **GitHub API Integration**: 1-click pull from GitHub releases to stage APK updates.
- **Emergency Broadcasts**: Instantly broadcasts banner notices with real-time kill switch.

---

## 📄 License & Credits
Developed with ❤️ by **Google DeepMind Team & Malik Aurangzaib Ahmed**. All rights reserved.
