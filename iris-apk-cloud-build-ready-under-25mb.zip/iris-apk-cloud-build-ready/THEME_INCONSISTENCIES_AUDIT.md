# IRIS Comprehensive Theme & Architectural Inconsistency Audit

> **Scope**: Multi-dimensional audit across all 7 design themes, 5 campus academic periods, dual user roles (Student vs. Faculty), and appearance modes (Dark vs. Light).

---

## Executive Summary

This report documents all architectural, logical, contextual, temporal-intelligence, and visual inconsistencies identified in the IRIS Enhanced codebase.

### Evaluated Dimensions
1. **Themes (7)**:
   - `materialYou` (Google Pixel Monet / Material 3 Expressive)
   - `fluidGlass` (Liquid Glass / iOS Vital Obsidian)
   - `almanac` (Classical Broadsheet Newspaper & Scotch Roman)
   - `editorialAcademic` (Oxford Literary Academic & Fraunces Serif)
   - `notebook` (Tactile Graph Paper, Washi Tape & Highlighters)
   - `line` (Metro Subway Transit & Archivo Wayfinding)
   - `poster` (Swiss Brutalism, Monolithic Monospace & International Orange)
2. **Academic Modes (5)**:
   - `classes` (Regular semester lectures & labs)
   - `sports_week` (Annual Sports Gala & Cultural Olympiad)
   - `ramadan` (Compressed 60-minute holy month slots)
   - `midterms` / `finals` (Examination periods)
   - `vacation` / `break` (Semester recess)
3. **Roles (2)**:
   - `student`
   - `faculty`
4. **Appearance Modes (2)**:
   - `light`
   - `dark`

---

## 1. Logical & State Inconsistencies

### 1.1 `MaterialApp` Root ThemeData Fallback Blindspot
- **File**: [`lib/app.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/app.dart#L508-L531)
- **Code Context**:
  ```dart
  theme: isM3
      ? MaterialYouTheme.light(themeModeService.paletteKey.value)
      : buildVitalTheme(brightness: Brightness.light),
  darkTheme: isM3
      ? MaterialYouTheme.dark(themeModeService.paletteKey.value)
      : buildVitalTheme(brightness: Brightness.dark),
  ```
- **Problem**: When any of the 5 newer themes (`almanac`, `editorialAcademic`, `notebook`, `line`, `poster`) is active, `isM3` is `false`. The root `MaterialApp` is supplied with `buildVitalTheme(...)`.
- **Root Cause**: The 5 custom themes do not inject a specialized `ThemeData` to the root application.
- **Impact**: All framework-level standard widgets (`showDialog`, `showDatePicker`, `showTimePicker`, `PopupMenuButton`, `TextField` cursor/selection handles, text selection magnification toolbars, scroll bounce overscroll glows, and default `SnackBar` surfaces) render with iOS Liquid Glass styles (`#007AFF` blue accents, `Inter` typography, and glass surfaces), clashing with the active artistic theme.

### 1.2 Container Morph Transition Painter Degradation
- **File**: [`lib/widgets/effects/theme_morph_transition.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/effects/theme_morph_transition.dart#L310-L316)
- **Code Context**:
  ```dart
  if (toStyle == IrisThemeStyle.fluidGlass) {
    _paintLiquidGlassMorph(canvas, currentRect, currentRadius, center);
  } else if (toStyle == IrisThemeStyle.editorialAcademic) {
    _paintEditorialAcademicMorph(canvas, currentRect, currentRadius, size);
  } else {
    _paintMaterialExpressiveMorph(canvas, currentRect, currentRadius, size);
  }
  ```
- **Problem**: In `_ThemeContainerMorphPainter.paint`, explicit painting routines exist only for `fluidGlass` and `editorialAcademic`.
- **Root Cause**: The default `else` branch falls into `_paintMaterialExpressiveMorph(...)`.
- **Impact**: When switching to `almanac`, `notebook`, `line`, or `poster`, the transition paints a Google Pixel Material You Monet squircle ripple with Monet seed tints rather than a theme-appropriate geometric wave (e.g., graph paper reveal for Notebook, subway track line for Line, Swiss drop-block for Poster).

### 1.3 Modals, Sheets, and Dialogs Binary Fallback
- **Files**:
  - [`lib/widgets/controls/batch_selector.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/controls/batch_selector.dart#L301-L320) & [L461-L520](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/controls/batch_selector.dart#L461-L520)
  - [`lib/screens/settings/iris_hub_screen.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/settings/iris_hub_screen.dart#L175-L186)
- **Code Context**:
  ```dart
  final isAlmanac = ThemeSignals.isAlmanac;
  return AlertDialog(
    backgroundColor: isAlmanac
        ? AlmanacTokens.cardSurface(isDark)
        : (isM3
            ? cs.surfaceContainerHigh
            : (isDark ? const Color(0xFF1E293B) : Colors.white)),
  ...
  ```
- **Problem**: [BatchSelectorSheet](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/controls/batch_selector.dart#L301) and [IrisHubScreen](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/settings/iris_hub_screen.dart#L175) only inspect `isAlmanac` and `isM3`.
- **Root Cause**: All other themes (`editorialAcademic`, `notebook`, `line`, `poster`) fall through to a Liquid Glass blurred backdrop (`sigma: 18.0`) with rounded cyan/blue pill buttons or generic dark slate containers (`0xFF1E293B`).
- **Impact**: Opening the batch selector or name editor in Notebook, Line, or Poster completely breaks visual immersion.

### 1.4 Secondary Academic Screens Theme Ignorance
- **Files**:
  - [`lib/screens/academics/department_classes_screen.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/academics/department_classes_screen.dart#L433-L474)
  - [`lib/screens/faculty/faculty_directory_screen.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/faculty/faculty_directory_screen.dart#L420-L450)
  - [`lib/screens/student/repeater_course_planner_screen.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/student/repeater_course_planner_screen.dart)
  - [`lib/screens/tools/document_workspace_screen.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/tools/document_workspace_screen.dart)
- **Problem**: These screens only evaluate `ThemeSignals.isMaterialYou`.
- **Root Cause**: If `isM3` is false, they default unconditionally to [AcademicsLiquidGlassStickyHeaderDelegate](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/academics/department_classes_screen.dart#L480) and [GlassCard](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/glass_card.dart).
- **Impact**: When navigating from Tools or Dashboard in Almanac, Notebook, Line, or Poster, sub-screens revert entirely to Liquid Glass cards and headers.

---

## 2. Intelligence & OmniBrain Inconsistencies

### 2.1 Sports Gala Event Duty Hallucination
- **File**: [`lib/core/omni_brain.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/core/omni_brain.dart#L1408-L1440) & [L1059-L1108](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/core/omni_brain.dart#L1059-L1108)
- **Code Context**:
  ```dart
  final headlineText = isExam
      ? 'Invigilating Now'
      : (period == 'sports_week' ? 'Gala Event Duty' : 'Teaching Now');
  return TemporalInsight(
    headline: headlineText,
    subline: '${current.subject} · $roomPrefix${current.room}',
    timeInfo: timeLeft, ...
  );
  ```
- **Problem**: During `sports_week`, when classes are suspended campus-wide, [OmniBrain](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/core/omni_brain.dart) relabels active lectures as `'Gala Event Duty'` (faculty) or `'Gala Event Live'` (student), but pulls metadata directly from regular academic sessions (e.g., *"Gala Event Duty: Algorithms · CS-01"*).
- **Root Cause**: If `current == null`, [OmniBrain](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/core/omni_brain.dart#L1423) calculates "Break: Algorithms at 10:00" and countdowns to the next regular lecture, contradicting campus suspension.
- **Impact**: The executive status pill announces non-existent duties and breaks for classes that are not taking place.

### 2.2 Ramadan Slot Compression Truncation for Labs & Evening Classes
- **File**: [`lib/core/models.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/core/models.dart#L869-L910)
- **Code Context**:
  ```dart
  if (s.startTime.contains('08:30') || s.startTime.contains('8:30')) {
    newStart = '08:30 AM';
    newEnd = '09:30 AM';
  } else if (s.startTime.contains('10:00')) {
    newStart = '09:30 AM';
    newEnd = '10:30 AM';
  ...
  ```
- **Problem**: `_toRamadanSessions` applies fixed 60-minute duration replacement based on prefix matching `startTime`.
- **Root Cause**:
  1. A 3-hour laboratory starting at `08:30 AM` is converted to `08:30 AM - 09:30 AM` (1 hour), truncating 2 hours.
  2. Classes starting after `03:00 PM` (e.g. `04:30 PM` evening lectures) match no condition and retain uncompressed times, while morning classes shift forward, creating timetable overlap.
- **Impact**: Timetable collision detection flags false positive conflicts; students in afternoon/evening slots see incorrect countdowns.

### 2.3 Exam Room Aggregation Discrepancy
- **File**: [`lib/core/omni_brain.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/core/omni_brain.dart#L1291-L1323)
- **Problem**: When a batch is split across multiple exam halls (e.g., `CS-01, CS-02`), `buildExamTemporalInsight` extracts only the first room entry or prints raw unsanitized strings (`Venue: CS-01, CS-02, EE-04`), while [ExamScheduleView](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/schedule_views/exam_schedule_view.dart) parses them into individual venue badges.

---

## 3. Contextual & Academic Mode Inconsistencies

### 3.1 Theme Suppression in Exam & Vacation Modes
- **Files**:
  - [`lib/screens/dashboard_screen.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/dashboard_screen.dart#L1768-L2015)
  - [`lib/screens/faculty/faculty_schedule_view.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/faculty/faculty_schedule_view.dart#L127-L205)
- **Problem**: `if (isExamPeriod)` and `if (isVacation)` are evaluated **before** `ThemeSignals`.
- **Root Cause**: The schedule views for Almanac, Notebook, Line, and Poster are completely bypassed. The dashboard renders [ExamStickyHeaderDelegate](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/schedule_views/exam_sticky_header.dart) and [VacationStickyHeaderDelegate](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/schedule_views/vacation_sticky_header.dart) in Liquid Glass or M3.
- **Impact**: The user's active theme is overridden on Tab 0, but the bottom navigation bar remains styled to the custom theme, creating an inconsistent hybrid layout.

### 3.2 Sports Gala Class Suspension Bypass in Custom Themes
- **File**: [`lib/screens/dashboard_screen.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/dashboard_screen.dart#L2146-L2249)
- **Problem**: In `sports_week`, the dashboard routes directly to [AlmanacScheduleView](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/schedule_views/almanac_schedule_view.dart), [NotebookScheduleView](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/schedule_views/notebook_schedule_view.dart), [LineScheduleView](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/schedule_views/line_schedule_view.dart), etc.
- **Root Cause**: None of these 5 schedule views check `RemoteConfigService.activeAcademicPeriod`.
- **Impact**:
  1. Students in these themes see normal regular class cards and active countdown timers during Sports Week.
  2. [StudentsWeekInfoCard](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/schedule_views/sports_gala_view.dart#L6) (which explains that lectures are suspended) is **completely orphaned** and never rendered in [dashboard_screen.dart](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/dashboard_screen.dart).

### 3.3 Hardcoded Fall 2026 Resumption Fallbacks
- **Files**:
  - [`lib/screens/faculty/faculty_schedule_view.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/faculty/faculty_schedule_view.dart#L129-L130)
  - [`lib/widgets/faculty/faculty_mode_views.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/faculty/faculty_mode_views.dart#L30)
  - [`lib/widgets/schedule_views/vacation_schedule_view.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/schedule_views/vacation_schedule_view.dart#L138-L224)
- **Problem**: When remote config dates are uninitialized or empty, the app defaults to `'2026-09-01'` and `'Fall 2026'`.
- **Impact**: In future academic cycles (2027+), unseeded configurations display expired 2026 countdowns and dates.

---

## 4. Role Inconsistencies (Student vs. Faculty)

### 4.1 Faculty Dashboard Schedule View Hierarchy
- **File**: [`lib/screens/faculty/faculty_dashboard_screen.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/faculty/faculty_dashboard_screen.dart#L724-L751)
- **Problem**: [FacultyDashboardScreen](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/faculty/faculty_dashboard_screen.dart) Tab 0 mounts [FacultyScheduleView](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/faculty/faculty_schedule_view.dart) unconditionally.
- **Root Cause**: Even though [AlmanacScheduleView](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/schedule_views/almanac_schedule_view.dart), [EditorialScheduleView](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/schedule_views/editorial_schedule_view.dart), [NotebookScheduleView](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/schedule_views/notebook_schedule_view.dart), [LineScheduleView](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/schedule_views/line_schedule_view.dart), and [PosterScheduleView](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/schedule_views/poster_schedule_view.dart) support `isFaculty: true`, the root container in [FacultyDashboardScreen](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/faculty/faculty_dashboard_screen.dart) delegates internal branching to [FacultyScheduleView](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/faculty/faculty_schedule_view.dart#L269-L333), which creates an extra layout/widget pass compared to [Dashboard](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/dashboard_screen.dart).

### 4.2 Faculty Schedule Top Popup Menu Limited to Two Themes
- **File**: [`lib/screens/faculty/faculty_schedule_view.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/faculty/faculty_schedule_view.dart#L797-L815) & [L1483](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/faculty/faculty_schedule_view.dart#L1483)
- **Problem**: The top header popup menu in [FacultyScheduleView](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/faculty/faculty_schedule_view.dart) only offers options to toggle between "Liquid Glass" and "Material 3 Expressive".
- **Impact**: Faculty members using the top menu are unable to switch to Almanac, Editorial, Notebook, Line, or Poster without opening Settings / Iris Hub.

### 4.3 Route Morphing in Faculty Tools Screen
- **File**: [`lib/screens/faculty/faculty_tools_screen.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/faculty/faculty_tools_screen.dart)
- **Problem**: [FacultyToolsScreen](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/screens/faculty/faculty_tools_screen.dart) uses `pushGlassContainerMorphRoute` regardless of the selected theme, triggering glass container morphs in all non-glass themes.

---

## 5. UI & Dark / Light Appearance Inconsistencies

### 5.1 WCAG AA Contrast Deficiency in Editorial Dark Mode
- **File**: [`lib/core/editorial_theme_tokens.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/core/editorial_theme_tokens.dart#L44)
- **Problem**: `EditorialTokens.accentNotice` (`#6366F1`, Royal Indigo) against `canvasSurface(true)` (`#141926`) produces a contrast ratio of **4.07:1**.
- **Impact**: Fails WCAG AA (4.5:1 required for body text and indicators under 18pt), impairing readability in Midnight mode.

### 5.2 Scaffold Background Leakage Across Themes
- **File**: [`lib/core/vital_theme.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/core/vital_theme.dart#L74-L85)
- **Problem**: Root scaffold background is set to `VitalTokens.offWhite` (`#F6F7FB`) in light mode and `VitalTokens.obsidian` (`#0A0A0C`) in dark mode.
- **Mismatch**:
  - **Almanac Light**: Canvas is broadsheet parchment `#EFECE6`.
  - **Notebook Light**: Canvas is graph paper cream `#FBF9F3`.
  - **Line Light**: Canvas is metro ticket beige `#F3EFE6`.
  - **Poster Light**: Canvas is concrete ivory `#EBE8E1`.
  - **Editorial Light**: Canvas is book paper `#FAF7F2`.
- **Impact**: During page transitions or in secondary dialogs/drawers that don't paint a full custom background, the underlying `#F6F7FB` surface flashes visibly.

### 5.3 SmartPillOverlay Hardcoded Themes
- **File**: [`lib/widgets/navigation/smart_pill_overlay.dart`](file:///d:/Iris%20Working%20backup/MOST%20RECENT/IRIS/lib/widgets/navigation/smart_pill_overlay.dart#L264-L408)
- **Problem**: Global banner overlay only accounts for `isMaterialYou`.
- **Impact**: In Almanac, Editorial, Notebook, Line, and Poster, broadcast announcements render as a Liquid Glass frosted capsule with `#141923` or `#FFFFFF` fill and a blur filter, visually conflicting with the active theme.

---

## 6. Summary Matrix Across All 7 Themes

| Theme / Dimension | Root ThemeData | Bottom Nav Bar | Dialogs & Sheets | Sports Week Handling | Exam Mode Theme Preservation | Dark/Light Contrast |
|---|---|---|---|---|---|---|
| **Material 3 Expressive** | ✅ Dedicated | ✅ 4 Tabs | ✅ M3 Squircles | ⚠️ Classes shown (Orphan card) | ⚠️ Standardized layout | ✅ High |
| **Liquid Glass** | ✅ Dedicated | ✅ 4 Tabs | ✅ Glass Morph | ⚠️ Classes shown (Orphan card) | ⚠️ Standardized layout | ✅ High |
| **Almanac** | ❌ Vital fallback | ✅ 4 Tabs | ⚠️ Partial (Batch only) | ❌ Shows regular classes | ❌ Reverts to Glass/M3 | ✅ High |
| **Editorial Academic** | ❌ Vital fallback | ✅ 4 Tabs | ❌ Falls back to Glass | ❌ Shows regular classes | ❌ Reverts to Glass/M3 | ⚠️ Indigo fails AA in Dark |
| **Notebook** | ❌ Vital fallback | ✅ 4 Tabs | ❌ Falls back to Glass | ❌ Shows regular classes | ❌ Reverts to Glass/M3 | ✅ High |
| **Line** | ❌ Vital fallback | ✅ 4 Tabs | ❌ Falls back to Glass | ❌ Shows regular classes | ❌ Reverts to Glass/M3 | ✅ High |
| **Poster** | ❌ Vital fallback | ✅ 4 Tabs | ❌ Falls back to Glass | ❌ Shows regular classes | ❌ Reverts to Glass/M3 | ✅ High |
