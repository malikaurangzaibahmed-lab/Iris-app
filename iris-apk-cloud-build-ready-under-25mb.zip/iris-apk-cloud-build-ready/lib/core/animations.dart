import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:material_3_expressive/material_3_expressive.dart';
import 'theme_signals.dart';
import '../widgets/effects/glass_container_transform.dart';
import 'glass.dart';
import 'material_you_theme.dart';
import 'almanac_theme_tokens.dart';
import 'editorial_theme_tokens.dart';
import 'notebook_theme_tokens.dart';
import 'line_theme_tokens.dart';
import 'poster_theme_tokens.dart';
import 'laminar_flow.dart';
import '../services/ui_feedback.dart';

class IrisMotion {
  static const Duration fast = Duration(milliseconds: 240);
  static const Duration normal = Duration(milliseconds: 380);
  static const Duration medium = Duration(milliseconds: 540);
  static const Duration slow = Duration(milliseconds: 800);

  // Global performance toggles for low-jank rendering on large widget trees.
  static const bool reduceMotion = false;
  static const bool reduceBlur = false; // Enabled full blur for Liquid Glass

  // Hyper-fluid 144Hz optimized curves
  static const Curve entrance = Cubic(0.0, 0.0, 0.05, 1.0); // Ultra-fast start, long tail
  static const Curve standard = Cubic(0.2, 0.0, 0.0, 1.0);
  static const Curve emphasized = Cubic(0.15, 0.0, 0.0, 1.0);
  static const Curve bouncy = Cubic(0.175, 0.885, 0.32, 1.275);
  static const Curve fluid = Cubic(0.4, 0.0, 0.2, 1.0);
  static const Curve spring = Cubic(0.175, 0.885, 0.32, 1.15); // Tighter physical snap

  // OPPO ColorOS 17 Living Flow & Laminar Motion Curves
  static const Curve laminarEntrance = LaminarCurves.laminarEntrance;
  static const Curve fluidDecelerate = LaminarCurves.fluidDecelerate;
  static const Curve parallelMotion = LaminarCurves.parallelMotion;
  static const Curve viscoelasticBounce = LaminarCurves.viscoelasticBounce;

  // Material 3 Expressive motion tokens & physics
  static const Curve expressiveStandard = M3EMotion.standard;
  static const Curve expressiveEmphasized = M3EMotion.emphasized;
  static const Curve expressiveEmphasizedDecelerate = M3EMotion.emphasizedDecelerate;
  static const Curve expressiveSpring = M3ESpringCurve(stiffness: 380, damping: 0.55);
  static const Duration expressiveShort = M3EMotion.short4;
  static const Duration expressiveMedium = M3EMotion.medium2;
  static const Duration expressiveLong = M3EMotion.long2;
  static const M3ESpring spatialFast = M3EMotion.spatialFast;
  static const M3ESpring spatialDefault = M3EMotion.spatialDefault;
  static const M3ESpring expressiveSpatialFast = M3EMotion.expressiveSpatialFast;
  static const M3ESpring expressiveSpatialPress = M3EMotion.expressiveSpatialPress;
}

/// A physics-driven spring press wrapper powering authentic Material 3 Expressive interactions.
class ExpressiveSpringPress extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final double pressedScale;
  final bool enabled;

  const ExpressiveSpringPress({
    super.key,
    required this.child,
    this.onTap,
    this.onLongPress,
    this.pressedScale = 0.95,
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    return M3ETappable(
      onTap: onTap,
      onLongPress: onLongPress,
      pressedScale: pressedScale,
      spring: M3EMotion.expressiveSpatialPress,
      enabled: enabled,
      child: child,
    );
  }
}

/// Advanced button press and hold wrapper providing authentic Material 3 Expressive tactile feedback:
/// - Smooth scale compression on touch down with damped spring physics
/// - Dynamic harmonic breathing tension oscillation when held
/// - Tactile haptic ticks on contact, tension threshold, and release
class ExpressiveInteractivePress extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final double pressedScale;
  final bool enableHaptics;
  final bool enable3DTilt;
  final double maxTiltAngle;
  final double baseRotation;

  const ExpressiveInteractivePress({
    super.key,
    required this.child,
    this.onTap,
    this.onLongPress,
    this.pressedScale = 0.94,
    this.enableHaptics = true,
    this.enable3DTilt = false,
    this.maxTiltAngle = 0.065,
    this.baseRotation = 0.0,
  });

  @override
  State<ExpressiveInteractivePress> createState() => _ExpressiveInteractivePressState();
}

class _ExpressiveInteractivePressState extends State<ExpressiveInteractivePress>
    with TickerProviderStateMixin {
  late final AnimationController _pressController;
  late final Animation<double> _scaleAnimation;
  late final AnimationController _tensionController;
  late final Animation<double> _tensionAnimation;
  Timer? _holdTimer;
  bool _isHolding = false;
  bool _isPressed = false;
  double _tiltX = 0.0;
  double _tiltY = 0.0;

  @override
  void initState() {
    super.initState();
    _pressController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 130),
      reverseDuration: const Duration(milliseconds: 220),
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: widget.pressedScale,
    ).animate(CurvedAnimation(
      parent: _pressController,
      curve: Curves.easeOutCubic,
      reverseCurve: Curves.easeOutBack,
    ));

    _tensionController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _tensionAnimation = Tween<double>(
      begin: 0.0,
      end: 0.025,
    ).animate(CurvedAnimation(
      parent: _tensionController,
      curve: Curves.easeInOutSine,
    ));
  }

  @override
  void dispose() {
    _holdTimer?.cancel();
    _pressController.dispose();
    _tensionController.dispose();
    super.dispose();
  }

  void _handleTapDown(TapDownDetails details) {
    _isPressed = true;
    if (widget.enableHaptics) IrisHaptics.actionSoft();

    if (widget.enable3DTilt) {
      final box = context.findRenderObject() as RenderBox?;
      if (box != null && box.hasSize) {
        final w = box.size.width;
        final h = box.size.height;
        if (w > 0 && h > 0) {
          final nx = ((details.localPosition.dx - (w / 2)) / (w / 2)).clamp(-1.0, 1.0);
          final ny = ((details.localPosition.dy - (h / 2)) / (h / 2)).clamp(-1.0, 1.0);
          _tiltX = -ny * widget.maxTiltAngle;
          _tiltY = nx * widget.maxTiltAngle;
        }
      }
    }

    _pressController.forward();

    _holdTimer?.cancel();
    _holdTimer = Timer(const Duration(milliseconds: 170), () {
      if (mounted && _isPressed) {
        setState(() => _isHolding = true);
        _tensionController.repeat(reverse: true);
        if (widget.enableHaptics) IrisHaptics.selectionClick();
      }
    });
  }

  void _handleTapUp(TapUpDetails _) {
    _resetPressState();
    widget.onTap?.call();
  }

  void _handleTapCancel() {
    _resetPressState();
  }

  void _handleLongPress() {
    if (widget.enableHaptics) IrisHaptics.actionHeavy();
    widget.onLongPress?.call();
  }

  void _resetPressState() {
    _isPressed = false;
    _holdTimer?.cancel();
    if (_isHolding) {
      _tensionController.stop();
      _tensionController.reset();
      setState(() => _isHolding = false);
    }
    _pressController.reverse();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: _handleTapDown,
      onTapUp: _handleTapUp,
      onTapCancel: _handleTapCancel,
      onLongPress: widget.onLongPress != null ? _handleLongPress : null,
      behavior: HitTestBehavior.opaque,
      child: AnimatedBuilder(
        animation: Listenable.merge([_pressController, _tensionController]),
        builder: (context, child) {
          final scale = (_scaleAnimation.value - (_isHolding ? _tensionAnimation.value : 0.0)).clamp(0.85, 1.05);
          // OPPO ColorOS 17 volume-conserving fluid deformation:
          // Transversal stretch compensates for longitudinal compression (Poisson fluid ratio)
          final compression = (1.0 - scale).clamp(0.0, 0.15);
          final scaleX = (scale * (1.0 + compression * 0.35)).clamp(0.85, 1.06);
          final scaleY = scale;
          final pressProgress = _pressController.value;

          final matrix = Matrix4.identity()
            ..setEntry(3, 2, 0.0014); // 3D Perspective Depth

          if (widget.baseRotation != 0.0) {
            matrix.rotateZ(widget.baseRotation);
          }

          if (widget.enable3DTilt && pressProgress > 0.0) {
            matrix.rotateX(_tiltX * pressProgress);
            matrix.rotateY(_tiltY * pressProgress);
          }

          matrix.scaleByDouble(scaleX, scaleY, 1.0, 1.0);

          return Transform(
            alignment: Alignment.center,
            transform: matrix,
            child: child,
          );
        },
        child: RepaintBoundary(child: widget.child),
      ),
    );
  }
}

/// Authentic Material 3 Expressive Extended & Morphing Floating Action Button.
/// Features:
/// - Smooth squircle-to-extended pill morphing with spring physics
/// - Google InkSparkle ripple feedback on tap
/// - Interactive press compression & elevation drop on touch
/// - Seed-reactive Monet elevation glow
class IrisExpressiveFAB extends StatefulWidget {
  final IconData icon;
  final String? label;
  final VoidCallback? onPressed;
  final VoidCallback? onLongPress;
  final bool isExtended;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final String? tooltip;

  const IrisExpressiveFAB({
    super.key,
    required this.icon,
    this.label,
    required this.onPressed,
    this.onLongPress,
    this.isExtended = true,
    this.backgroundColor,
    this.foregroundColor,
    this.tooltip,
  });

  @override
  State<IrisExpressiveFAB> createState() => _IrisExpressiveFABState();
}

class _IrisExpressiveFABState extends State<IrisExpressiveFAB> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = widget.backgroundColor ?? cs.primaryContainer;
    final fg = widget.foregroundColor ?? cs.onPrimaryContainer;
    final hasLabel = widget.isExtended && widget.label != null && widget.label!.isNotEmpty;

    return Semantics(
      button: true,
      label: widget.tooltip ?? widget.label,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOutBack,
        scale: _isPressed ? 0.93 : 1.0,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 280),
          curve: Curves.easeOutCubic,
          height: 56,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(hasLabel ? 20 : 18),
            boxShadow: [
              BoxShadow(
                color: bg.withValues(alpha: isDark ? 0.40 : 0.28),
                blurRadius: _isPressed ? 4 : 14,
                spreadRadius: _isPressed ? -2 : 0,
                offset: Offset(0, _isPressed ? 2 : 5),
              ),
            ],
          ),
          child: Material(
            color: bg,
            borderRadius: BorderRadius.circular(hasLabel ? 20 : 18),
            clipBehavior: Clip.antiAlias,
            child: InkWell(
              splashFactory: InkSparkle.splashFactory,
              onTapDown: (_) {
                IrisHaptics.actionMedium();
                setState(() => _isPressed = true);
              },
              onTapUp: (_) {
                setState(() => _isPressed = false);
                widget.onPressed?.call();
              },
              onTapCancel: () => setState(() => _isPressed = false),
              onLongPress: widget.onLongPress != null ? () {
                IrisHaptics.actionHeavy();
                widget.onLongPress!();
              } : null,
              child: AnimatedPadding(
                duration: const Duration(milliseconds: 260),
                curve: Curves.easeOutCubic,
                padding: EdgeInsets.symmetric(
                  horizontal: hasLabel ? 20 : 16,
                  vertical: 12,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AnimatedRotation(
                      turns: _isPressed ? 0.05 : 0.0,
                      duration: const Duration(milliseconds: 180),
                      curve: Curves.easeOutBack,
                      child: Icon(widget.icon, color: fg, size: 24),
                    ),
                    if (hasLabel) ...[
                      const SizedBox(width: 10),
                      AnimatedDefaultTextStyle(
                        duration: const Duration(milliseconds: 200),
                        style: TextStyle(
                          color: fg,
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.2,
                        ),
                        child: Text(widget.label!),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// A premium route transition that morphs origin container bounds into full screen with modern OS container morphing physics.
Future<T?> pushIconLaunchRoute<T>(
  BuildContext context, {
  required Widget page,
  GlobalKey? originKey,
  bool lightweight = false,
  Duration? transitionDuration,
  Duration? reverseTransitionDuration,
}) {
  return pushGlassContainerMorphRoute<T>(
    context,
    page: page,
    originKey: originKey,
    duration: transitionDuration ?? const Duration(milliseconds: 420),
    reverseDuration: reverseTransitionDuration ?? const Duration(milliseconds: 340),
  );
}
/// A custom scroll physics providing authentic OPPO ColorOS 17 hydrodynamic viscosity
/// and non-linear boundary resistance across all IRIS scroll views.
class ButterScrollPhysics extends LaminarScrollPhysics {
  const ButterScrollPhysics({super.parent, super.viscosity = 1.0});

  @override
  ButterScrollPhysics applyTo(ScrollPhysics? ancestor) {
    return ButterScrollPhysics(
      parent: buildParent(ancestor),
      viscosity: viscosity,
    );
  }
}

/// Premium frosted / M3 input decoration for tool sub-screens.
InputDecoration irisFrostedInputDecoration({
  String? label,
  required bool isDark,
  IconData? prefixIcon,
  String? hint,
}) {
  final brightness = isDark ? Brightness.dark : Brightness.light;
  if (ThemeSignals.isMaterialYou) {
    final fill = MaterialYouTokens.surfaceContainerHighest(brightness);
    final outline = MaterialYouTokens.outlineVariant(brightness);
    final brand = MaterialYouTokens.primary(brightness);
    final labelColor = isDark ? const Color(0xFFC4C6D0) : const Color(0xFF44474E);

    return InputDecoration(
      labelText: label,
      hintText: hint,
      isDense: true,
      filled: true,
      fillColor: fill,
      prefixIcon: prefixIcon != null
          ? Icon(prefixIcon, size: 20, color: labelColor)
          : null,
      labelStyle: TextStyle(
        fontSize: 13,
        fontWeight: FontWeight.w600,
        color: labelColor,
      ),
      hintStyle: TextStyle(
        fontSize: 13,
        fontWeight: FontWeight.w500,
        color: labelColor.withValues(alpha: 0.6),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(MaterialYouTokens.radiusMedium),
        borderSide: BorderSide(color: outline, width: 1),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(MaterialYouTokens.radiusMedium),
        borderSide: BorderSide(color: outline, width: 1),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(MaterialYouTokens.radiusMedium),
        borderSide: BorderSide(color: brand, width: 2),
      ),
    );
  }

  final fillColor = isDark
      ? Colors.white.withValues(alpha: 0.08)
      : Colors.black.withValues(alpha: 0.04);
  final borderColor = isDark
      ? Colors.white.withValues(alpha: 0.14)
      : Colors.black.withValues(alpha: 0.10);
  final focusColor = isDark
      ? Colors.white.withValues(alpha: 0.24)
      : const Color(0xFF6366F1).withValues(alpha: 0.32);
  final labelColor = isDark
      ? Colors.white.withValues(alpha: 0.62)
      : Colors.black.withValues(alpha: 0.55);

  return InputDecoration(
    labelText: label,
    hintText: hint,
    isDense: true,
    filled: true,
    fillColor: fillColor,
    prefixIcon: prefixIcon != null
        ? Icon(prefixIcon, size: 18, color: labelColor)
        : null,
    labelStyle: TextStyle(
      fontSize: 13,
      fontWeight: FontWeight.w600,
      color: labelColor,
    ),
    hintStyle: TextStyle(
      fontSize: 13,
      fontWeight: FontWeight.w500,
      color: labelColor.withValues(alpha: 0.5),
    ),
    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(color: borderColor, width: 1),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(color: borderColor, width: 1),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(color: focusColor, width: 1.5),
    ),
  );
}

/// Premium frosted / M3 AppBar for tool sub-screens.
PreferredSizeWidget irisFrostedAppBar({
  required String title,
  required bool isDark,
  List<Widget>? actions,
  Widget? leading,
  bool centerTitle = true,
}) {
  return PreferredSize(
    preferredSize: const Size.fromHeight(kToolbarHeight),
    child: ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, themeStyle, _) {
        final isM3 = themeStyle == IrisThemeStyle.materialYou;
        if (isM3) {
          return M3EAppBar.top(
            titleText: title,
            centerTitle: centerTitle,
            actions: actions,
            leading: leading,
            density: M3EAppBarDensity.regular,
            shapeFamily: M3EAppBarShapeFamily.square,
          );
        }

        if (themeStyle == IrisThemeStyle.almanac) {
          final ruleColor = AlmanacTokens.inkRule(isDark);
          return Container(
            decoration: BoxDecoration(
              color: AlmanacTokens.canvas(isDark).withValues(alpha: 0.96),
              border: Border(
                bottom: BorderSide(color: ruleColor, width: 1.5),
              ),
            ),
            child: AppBar(
              title: Text(
                title.toUpperCase(),
                style: AlmanacTokens.serifHeadline(
                  isDark,
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.6,
                ),
              ),
              centerTitle: centerTitle,
              backgroundColor: Colors.transparent,
              elevation: 0,
              scrolledUnderElevation: 0,
              leading: leading,
              actions: actions,
              iconTheme: IconThemeData(color: AlmanacTokens.inkHeading(isDark)),
            ),
          );
        }

        if (themeStyle == IrisThemeStyle.editorialAcademic) {
          return Container(
            decoration: BoxDecoration(
              color: EditorialTokens.cardSurface(isDark).withValues(alpha: 0.96),
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(22)),
              border: Border(
                bottom: BorderSide(color: EditorialTokens.cardBorder(isDark), width: 1.2),
              ),
              boxShadow: EditorialTokens.cardShadow(isDark, elevation: 1.5),
            ),
            child: AppBar(
              title: Text(
                title,
                style: EditorialTokens.headingSerif(
                  isDark,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
              centerTitle: centerTitle,
              backgroundColor: Colors.transparent,
              elevation: 0,
              scrolledUnderElevation: 0,
              leading: leading,
              actions: actions,
              iconTheme: IconThemeData(color: EditorialTokens.inkHeading(isDark)),
            ),
          );
        }

        if (themeStyle == IrisThemeStyle.notebook) {
          return Container(
            decoration: BoxDecoration(
              color: NotebookTokens.cardSurface(isDark).withValues(alpha: 0.96),
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(14)),
              border: Border(
                bottom: BorderSide(color: NotebookTokens.marginRule(isDark), width: 1.6),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.06),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: AppBar(
              title: HighlighterSwash(
                color: NotebookTokens.stickyNote(isDark),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Text(
                    title,
                    style: NotebookTokens.boldScript(isDark, fontSize: 20),
                  ),
                ),
              ),
              centerTitle: centerTitle,
              backgroundColor: Colors.transparent,
              elevation: 0,
              scrolledUnderElevation: 0,
              leading: leading,
              actions: actions,
              iconTheme: IconThemeData(color: NotebookTokens.inkHeading(isDark)),
            ),
          );
        }

        if (themeStyle == IrisThemeStyle.line) {
          final railColor = LineTokens.railLine(isDark);
          return Container(
            decoration: BoxDecoration(
              color: LineTokens.cardSurface(isDark),
              border: Border(
                bottom: BorderSide(color: railColor, width: 3.5),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: AppBar(
              title: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      color: railColor,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      title.toUpperCase(),
                      overflow: TextOverflow.ellipsis,
                      style: LineTokens.stationName(isDark).copyWith(fontSize: 16.5),
                    ),
                  ),
                ],
              ),
              centerTitle: centerTitle,
              backgroundColor: Colors.transparent,
              elevation: 0,
              scrolledUnderElevation: 0,
              leading: leading,
              actions: actions,
              iconTheme: IconThemeData(color: LineTokens.inkHeading(isDark)),
            ),
          );
        }

        if (themeStyle == IrisThemeStyle.poster) {
          final borderCol = PosterTokens.inkBorder(isDark);
          return Container(
            decoration: BoxDecoration(
              color: PosterTokens.cardSurface(isDark),
              border: Border(
                bottom: BorderSide(color: borderCol, width: 2.8),
              ),
              boxShadow: [
                BoxShadow(
                  color: borderCol,
                  offset: const Offset(0, 3),
                  blurRadius: 0,
                ),
              ],
            ),
            child: AppBar(
              title: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: PosterTokens.orangeHero,
                  border: Border.all(color: Colors.black, width: 1.8),
                ),
                child: Text(
                  title.toUpperCase(),
                  style: PosterTokens.classTitle(false).copyWith(
                    fontSize: 14,
                    color: Colors.black,
                    letterSpacing: 0.6,
                  ),
                ),
              ),
              centerTitle: centerTitle,
              backgroundColor: Colors.transparent,
              elevation: 0,
              scrolledUnderElevation: 0,
              leading: leading,
              actions: actions,
              iconTheme: IconThemeData(color: PosterTokens.inkHeading(isDark)),
            ),
          );
        }

        return ValueListenableBuilder<double>(
          valueListenable: ThemeSignals.glassTransparency,
          builder: (context, transparency, _) {
            final isFluidGlass = themeStyle == IrisThemeStyle.fluidGlass;
            final isOpaque = !isFluidGlass || transparency <= 0.08;
            final double appBarBlur = isOpaque ? 0.0 : lerpDouble(6.0, 22.0, transparency)!;
            final Color bgColor = isDark 
                ? const Color(0xFF0A0A0C).withValues(
                    alpha: isOpaque ? 0.98 : lerpDouble(0.98, 0.40, transparency)!,
                  )
                : Colors.white.withValues(
                    alpha: isOpaque ? 0.98 : lerpDouble(0.98, 0.58, transparency)!,
                  );

            final bottomRadius = const Radius.circular(22.0);
            return Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.vertical(bottom: bottomRadius),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.08),
                    blurRadius: 14,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.vertical(bottom: bottomRadius),
                child: IrisGlass.backdropFilter(
                  sigmaX: appBarBlur,
                  sigmaY: appBarBlur,
                  child: Container(
                    decoration: BoxDecoration(
                      color: bgColor,
                      border: Border(
                        bottom: BorderSide(
                          color: isDark
                              ? Colors.white.withValues(alpha: isOpaque ? 0.12 : 0.18)
                              : Colors.black.withValues(alpha: isOpaque ? 0.08 : 0.10),
                          width: 1.2,
                        ),
                      ),
                    ),
                    child: AppBar(
                      title: Text(
                        title,
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -0.3,
                          color: isDark ? Colors.white : Colors.black,
                        ),
                      ),
                      centerTitle: centerTitle,
                      backgroundColor: Colors.transparent,
                      elevation: 0,
                      scrolledUnderElevation: 0,
                      leading: leading,
                      actions: actions,
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    ),
  );
}

/// A smooth slide-and-fade entrance animation.
class MotionSlideFade extends StatelessWidget {
  final Widget child;
  final Offset beginOffset;
  final Duration duration;
  final Curve curve;

  const MotionSlideFade({
    required this.child,
    required this.beginOffset,
    this.duration = IrisMotion.medium,
    this.curve = IrisMotion.entrance,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    if (IrisMotion.reduceMotion) return child;
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: duration,
      curve: curve,
      builder: (context, value, _) => Transform.translate(
        offset: Offset(
          beginOffset.dx * (1 - value),
          beginOffset.dy * (1 - value),
        ),
        child: Opacity(
          opacity: value,
          child: RepaintBoundary(child: child),
        ),
      ),
    );
  }
}

/// A smooth scale-and-fade entrance animation.
class MotionScaleFade extends StatelessWidget {
  final Widget child;
  final double beginScale;
  final Duration duration;
  final Curve curve;

  const MotionScaleFade({
    required this.child,
    this.beginScale = 0.9,
    this.duration = IrisMotion.medium,
    this.curve = IrisMotion.bouncy,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    if (IrisMotion.reduceMotion) return child;
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: duration,
      curve: curve,
      builder: (context, value, _) => Transform.scale(
        scale: beginScale + ((1 - beginScale) * value),
        child: Opacity(
          opacity: value,
          child: RepaintBoundary(child: child),
        ),
      ),
    );
  }
}

/// Authentic Google Pixel / Material 3 Expressive shared-axis Z zoom-fade page route.
/// Provides 60-120 FPS fluid spring zoom-fade transitions across all sub-screens.
class IrisExpressivePageRoute<T> extends PageRouteBuilder<T> {
  final WidgetBuilder builder;

  IrisExpressivePageRoute({
    required this.builder,
    super.settings,
  }) : super(
          pageBuilder: (context, animation, secondaryAnimation) => builder(context),
          transitionDuration: const Duration(milliseconds: 320),
          reverseTransitionDuration: const Duration(milliseconds: 260),
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            final primaryCurve = CurvedAnimation(
              parent: animation,
              curve: LaminarCurves.laminarEntrance,
              reverseCurve: LaminarCurves.fluidDecelerate,
            );
            final inScale = Tween<double>(begin: 0.945, end: 1.0).animate(primaryCurve);
            final inFade = Tween<double>(begin: 0.0, end: 1.0).animate(primaryCurve);
            final inSlide = Tween<Offset>(
              begin: const Offset(0.0, 0.035),
              end: Offset.zero,
            ).animate(primaryCurve);

            final secondaryCurve = CurvedAnimation(
              parent: secondaryAnimation,
              curve: LaminarCurves.parallelMotion,
              reverseCurve: LaminarCurves.fluidDecelerate,
            );
            final outScale = Tween<double>(begin: 1.0, end: 0.965).animate(secondaryCurve);
            final outFade = Tween<double>(begin: 1.0, end: 0.86).animate(secondaryCurve);

            return RepaintBoundary(
              child: ScaleTransition(
                scale: outScale,
                child: FadeTransition(
                  opacity: outFade,
                  child: SlideTransition(
                    position: inSlide,
                    child: ScaleTransition(
                      scale: inScale,
                      child: FadeTransition(
                        opacity: inFade,
                        child: child,
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        );
}

/// Authentic 3D Paper Curl & Turning Page Route for the Notebook theme.
/// Renders a dynamic 3D perspective rotation around the notebook's left spiral spine
/// paired with an authentic paper curl gradient shadow.
class NotebookPageCurlRoute<T> extends PageRouteBuilder<T> {
  final WidgetBuilder builder;

  NotebookPageCurlRoute({
    required this.builder,
    super.settings,
  }) : super(
          pageBuilder: (context, animation, secondaryAnimation) => builder(context),
          transitionDuration: const Duration(milliseconds: 380),
          reverseTransitionDuration: const Duration(milliseconds: 320),
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            final curved = CurvedAnimation(
              parent: animation,
              curve: Curves.easeOutCubic,
              reverseCurve: Curves.easeInCubic,
            );

            return AnimatedBuilder(
              animation: curved,
              builder: (context, _) {
                final progress = curved.value;
                final angle = (1.0 - progress) * (math.pi / 2.3);
                final matrix = Matrix4.identity()
                  ..setEntry(3, 2, 0.0012)
                  ..rotateY(-angle);

                return Transform(
                  transform: matrix,
                  alignment: Alignment.centerLeft,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      child,
                      if (progress < 0.99)
                        IgnorePointer(
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                                stops: const [0.0, 0.20, 1.0],
                                colors: [
                                  Colors.black.withValues(
                                    alpha: (1.0 - progress) * 0.25,
                                  ),
                                  Colors.black.withValues(
                                    alpha: (1.0 - progress) * 0.06,
                                  ),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                );
              },
            );
          },
        );
}

/// Ultra-crisp Subway Rapid Rail Transit Slide Page Route for the Line theme.
/// Simulates high-speed metro train cars sweeping horizontally across station platforms.
class LineRapidRailRoute<T> extends PageRouteBuilder<T> {
  final WidgetBuilder builder;

  LineRapidRailRoute({
    required this.builder,
    super.settings,
  }) : super(
          pageBuilder: (context, animation, secondaryAnimation) => builder(context),
          transitionDuration: const Duration(milliseconds: 240),
          reverseTransitionDuration: const Duration(milliseconds: 200),
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            final primaryCurve = CurvedAnimation(
              parent: animation,
              curve: const Cubic(0.05, 0.9, 0.1, 1.0),
              reverseCurve: Curves.easeInCubic,
            );
            final inSlide = Tween<Offset>(
              begin: const Offset(1.0, 0.0),
              end: Offset.zero,
            ).animate(primaryCurve);

            final secondaryCurve = CurvedAnimation(
              parent: secondaryAnimation,
              curve: Curves.fastOutSlowIn,
            );
            final outSlide = Tween<Offset>(
              begin: Offset.zero,
              end: const Offset(-0.25, 0.0),
            ).animate(secondaryCurve);

            return SlideTransition(
              position: outSlide,
              child: SlideTransition(
                position: inSlide,
                child: child,
              ),
            );
          },
        );
}

/// Stark Swiss Geometric Snap & Brutalist Punch Page Route for the Poster theme.
/// Mechanical zero-overshoot slide with instantaneous snap and punchy presence.
class PosterSwissSnapRoute<T> extends PageRouteBuilder<T> {
  final WidgetBuilder builder;

  PosterSwissSnapRoute({
    required this.builder,
    super.settings,
  }) : super(
          pageBuilder: (context, animation, secondaryAnimation) => builder(context),
          transitionDuration: const Duration(milliseconds: 170),
          reverseTransitionDuration: const Duration(milliseconds: 140),
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            final snapCurve = CurvedAnimation(
              parent: animation,
              curve: Curves.easeOutExpo,
              reverseCurve: Curves.easeInExpo,
            );
            final inSlide = Tween<Offset>(
              begin: const Offset(0.0, 0.06),
              end: Offset.zero,
            ).animate(snapCurve);
            final inFade = Tween<double>(begin: 0.0, end: 1.0).animate(snapCurve);

            return SlideTransition(
              position: inSlide,
              child: FadeTransition(
                opacity: inFade,
                child: child,
              ),
            );
          },
        );
}

/// Broadsheet Newspaper Fold & Ink Dissolve Page Route for the Almanac theme.
/// Simulates unfolding a morning archival university gazette along a vertical axis.
class AlmanacBroadsheetFoldRoute<T> extends PageRouteBuilder<T> {
  final WidgetBuilder builder;

  AlmanacBroadsheetFoldRoute({
    required this.builder,
    super.settings,
  }) : super(
          pageBuilder: (context, animation, secondaryAnimation) => builder(context),
          transitionDuration: const Duration(milliseconds: 360),
          reverseTransitionDuration: const Duration(milliseconds: 300),
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            final unfoldCurve = CurvedAnimation(
              parent: animation,
              curve: Curves.easeOutCubic,
              reverseCurve: Curves.easeInCubic,
            );
            final inFade = Tween<double>(begin: 0.0, end: 1.0).animate(unfoldCurve);

            return AnimatedBuilder(
              animation: unfoldCurve,
              builder: (context, _) {
                final angle = (1.0 - unfoldCurve.value) * 0.14;
                final matrix = Matrix4.identity()
                  ..setEntry(3, 2, 0.001)
                  ..rotateX(angle);

                return Transform(
                  transform: matrix,
                  alignment: Alignment.topCenter,
                  child: FadeTransition(
                    opacity: inFade,
                    child: child,
                  ),
                );
              },
            );
          },
        );
}

/// Oxford Scholarly Elevation Glide Page Route for the Editorial Academic theme.
/// Refined stately vertical slide with open-tracking academic crossfade.
class EditorialElevationRoute<T> extends PageRouteBuilder<T> {
  final WidgetBuilder builder;

  EditorialElevationRoute({
    required this.builder,
    super.settings,
  }) : super(
          pageBuilder: (context, animation, secondaryAnimation) => builder(context),
          transitionDuration: const Duration(milliseconds: 320),
          reverseTransitionDuration: const Duration(milliseconds: 260),
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            final glideCurve = CurvedAnimation(
              parent: animation,
              curve: Curves.easeOutCubic,
              reverseCurve: Curves.easeInCubic,
            );
            final inSlide = Tween<Offset>(
              begin: const Offset(0.0, 0.045),
              end: Offset.zero,
            ).animate(glideCurve);
            final inFade = Tween<double>(begin: 0.0, end: 1.0).animate(glideCurve);

            return SlideTransition(
              position: inSlide,
              child: FadeTransition(
                opacity: inFade,
                child: child,
              ),
            );
          },
        );
}

/// Adaptive page route helper that dynamically selects the authentic physical
/// transition relative to the currently active theme:
/// - **Notebook**: 3D Page Turn / Paper Curl around the spiral spine
/// - **Line**: Subway Rapid Rail Transit Slide along the horizontal track
/// - **Poster**: Swiss Geometric Snap & Brutalist Punch
/// - **Almanac**: Broadsheet Newspaper Fold & Ink Dissolve
/// - **Editorial**: Oxford Scholarly Elevation Glide
/// - **Material 3 / Fluid Glass**: Google Pixel shared-axis Z zoom-fade
Route<T> irisPageRoute<T>({
  required WidgetBuilder builder,
  RouteSettings? settings,
}) {
  final style = ThemeSignals.themeStyle.value;
  switch (style) {
    case IrisThemeStyle.notebook:
      return NotebookPageCurlRoute<T>(builder: builder, settings: settings);
    case IrisThemeStyle.line:
      return LineRapidRailRoute<T>(builder: builder, settings: settings);
    case IrisThemeStyle.poster:
      return PosterSwissSnapRoute<T>(builder: builder, settings: settings);
    case IrisThemeStyle.almanac:
      return AlmanacBroadsheetFoldRoute<T>(builder: builder, settings: settings);
    case IrisThemeStyle.editorialAcademic:
      return EditorialElevationRoute<T>(builder: builder, settings: settings);
    case IrisThemeStyle.materialYou:
    case IrisThemeStyle.fluidGlass:
      return IrisExpressivePageRoute<T>(builder: builder, settings: settings);
  }
}


