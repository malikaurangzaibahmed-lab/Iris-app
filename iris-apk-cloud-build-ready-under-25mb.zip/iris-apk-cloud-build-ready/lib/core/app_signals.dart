import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// App-wide reactive state bus for instantaneous, zero-restart updates across
/// roles ('student' / 'faculty'), active batch, student/faculty display names,
/// and custom repeater schedules.
class AppSignals {
  static final ValueNotifier<String?> roleNotifier = ValueNotifier(null);
  static final ValueNotifier<String> activeRole = ValueNotifier('student');
  static final ValueNotifier<String> activeBatch = ValueNotifier('');
  static final ValueNotifier<String> activeUserName = ValueNotifier('');
  static final ValueNotifier<int> stateRevision = ValueNotifier(0);

  static Future<void> syncFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final role = prefs.getString('user_role') ?? prefs.getString('active_role') ?? 'student';
    final batch = prefs.getString('user_batch') ??
        prefs.getString('student_batch') ??
        prefs.getString('selected_batch') ??
        '';
    final name = role == 'faculty'
        ? (prefs.getString('faculty_user_name') ?? prefs.getString('faculty_teacher') ?? 'Faculty Member')
        : (prefs.getString('student_user_name') ?? prefs.getString('student_name') ?? 'Student');
    activeRole.value = role;
    if (batch.isNotEmpty) activeBatch.value = batch;
    if (name.isNotEmpty) activeUserName.value = name;
    stateRevision.value++;
  }

  static Future<void> setRole(String role, {String? userName}) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_role', role);
    await prefs.setString('active_role', role);
    if (userName != null && userName.trim().isNotEmpty) {
      if (role == 'faculty') {
        await prefs.setString('faculty_user_name', userName.trim());
        await prefs.setString('faculty_teacher', userName.trim());
      } else {
        await prefs.setString('student_user_name', userName.trim());
        await prefs.setString('student_name', userName.trim());
      }
      activeUserName.value = userName.trim();
    } else {
      final savedName = role == 'faculty'
          ? (prefs.getString('faculty_user_name') ?? prefs.getString('faculty_teacher') ?? '')
          : (prefs.getString('student_user_name') ?? prefs.getString('student_name') ?? '');
      if (savedName.isNotEmpty) {
        activeUserName.value = savedName;
      }
    }
    activeRole.value = role;
    roleNotifier.value = role;
    stateRevision.value++;
  }

  static Future<void> setBatch(String batch) async {
    final trimmed = batch.trim();
    if (trimmed.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_batch', trimmed);
    await prefs.setString('student_batch', trimmed);
    await prefs.setString('selected_batch', trimmed);
    activeBatch.value = trimmed;
    stateRevision.value++;
  }

  static Future<void> setUserName(String name, {String? role}) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    final effectiveRole = role ?? activeRole.value;
    if (effectiveRole == 'faculty') {
      await prefs.setString('faculty_user_name', trimmed);
      await prefs.setString('faculty_teacher', trimmed);
    } else {
      await prefs.setString('student_user_name', trimmed);
      await prefs.setString('student_name', trimmed);
    }
    activeUserName.value = trimmed;
    stateRevision.value++;
  }
}
