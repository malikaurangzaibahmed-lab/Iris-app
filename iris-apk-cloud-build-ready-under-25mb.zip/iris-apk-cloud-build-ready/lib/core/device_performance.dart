/// Intelligent Device Performance Detector for IRIS.
/// Unthrottled performance mode for full 60-120 FPS high-capacity rendering.
class DevicePerformance {
  static String? _deviceSummary;

  static String get deviceSummary => _deviceSummary ?? 'Standard Device';

  /// Full capacity performance mode: never artificially throttle device graphics.
  /// IRIS runs at full unthrottled capability (60-120 FPS).
  static Future<bool> isLowEndDevice() async {
    return false;
  }

  /// Synchronous fallback helper: always unthrottled full capacity.
  static bool isLowEndSync() {
    return false;
  }
}
