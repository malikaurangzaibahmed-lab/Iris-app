import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Design tokens for the Cozy Editorial Academic aesthetic (Day & Midnight modes).
/// Provides unified colors, typography scales, squircle geometry, and elevation shadows
/// ready for direct mockup ingestion across all IRIS screens.
class EditorialTokens {
  // --- Canvas & Scaffold Backgrounds ---
  static Color canvas(bool isDark) =>
      isDark ? const Color(0xFF0E111B) : const Color(0xFFFAF7F2);

  static Color canvasSurface(bool isDark) =>
      isDark ? const Color(0xFF141926) : const Color(0xFFF3EFE6);

  // --- Hero Inverted Focal Card ---
  /// In light mode: deep midnight navy focal card.
  /// In dark mode: inverted warm ivory-biscuit parchment card.
  static Color heroCard(bool isDark) =>
      isDark ? const Color(0xFFFDF8F0) : const Color(0xFF1E2235);

  static Color heroCardText(bool isDark) =>
      isDark ? const Color(0xFF1E1B18) : Colors.white;

  static Color heroCardMutedText(bool isDark) =>
      isDark ? const Color(0xFF6B6358) : const Color(0xFFB0B7C6);

  static Color heroCardBadge(bool isDark) =>
      isDark ? const Color(0xFFF0E7D8) : const Color(0xFF2C324B);

  // --- Timetable & Bento Cards ---
  static Color cardSurface(bool isDark) =>
      isDark ? const Color(0xFF181D2B) : Colors.white;

  static Color cardBorder(bool isDark) =>
      isDark ? const Color(0xFF283042) : const Color(0xFFE8E2D6);

  static Color chipSurface(bool isDark) =>
      isDark ? const Color(0xFF22293C) : const Color(0xFFF0EBE1);

  // --- Accent Status Stripes & Badges ---
  static const Color accentLive = Color(0xFF10B981);       // Emerald Green
  static const Color accentLab = Color(0xFFE06D53);        // Terracotta / Coral
  static const Color accentUpcoming = Color(0xFFE5A83B);   // Honey Amber Gold
  static const Color accentNotice = Color(0xFF6366F1);     // Royal Indigo

  // --- Typography Colors ---
  static Color inkHeading(bool isDark) =>
      isDark ? Colors.white : const Color(0xFF1E1B18);

  static Color inkBody(bool isDark) =>
      isDark ? const Color(0xFFCBD5E1) : const Color(0xFF4A453E);

  static Color inkMuted(bool isDark) =>
      isDark ? const Color(0xFF8E9BAE) : const Color(0xFF7E766D);

  // --- Typography Scales (Literary Serif + Geometric Sans) ---
  static TextStyle headingSerif(
    bool isDark, {
    double fontSize = 22,
    FontWeight fontWeight = FontWeight.w900,
    double letterSpacing = -0.4,
    double? height,
  }) {
    return GoogleFonts.fraunces(
      fontSize: fontSize,
      fontWeight: fontWeight,
      letterSpacing: letterSpacing,
      height: height,
      color: inkHeading(isDark),
    );
  }

  static TextStyle bodySans(
    bool isDark, {
    double fontSize = 13,
    FontWeight fontWeight = FontWeight.w600,
    Color? color,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color ?? inkBody(isDark),
    );
  }

  static TextStyle bodyStyle(
    bool isDark, {
    double fontSize = 13,
    FontWeight fontWeight = FontWeight.w600,
    Color? color,
  }) =>
      bodySans(isDark, fontSize: fontSize, fontWeight: fontWeight, color: color);

  static TextStyle monoLabel(
    bool isDark, {
    double fontSize = 11,
    FontWeight fontWeight = FontWeight.w700,
    Color? color,
  }) {
    return GoogleFonts.jetBrainsMono(
      fontSize: fontSize,
      fontWeight: fontWeight,
      letterSpacing: 0.8,
      color: color ?? inkMuted(isDark),
    );
  }

  static TextStyle handwrittenScript(
    bool isDark, {
    double fontSize = 15,
    FontWeight fontWeight = FontWeight.w600,
    Color? color,
  }) {
    return GoogleFonts.caveat(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color ?? (isDark ? const Color(0xFFFBBF24) : const Color(0xFFD97706)),
    );
  }

  // --- Shadows & Elevations (Clean, non-gimmicky outer drop shadows) ---
  static List<BoxShadow> cardShadow(bool isDark, {double elevation = 2.0}) {
    return [
      BoxShadow(
        color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.06),
        offset: Offset(0, elevation * 1.2),
        blurRadius: elevation * 3.5,
        spreadRadius: 0,
      ),
    ];
  }

  static List<BoxShadow> heroShadow(bool isDark) {
    return [
      BoxShadow(
        color: isDark
            ? Colors.black.withValues(alpha: 0.45)
            : const Color(0xFF1E2235).withValues(alpha: 0.16),
        offset: const Offset(0, 6),
        blurRadius: 18,
        spreadRadius: 0,
      ),
    ];
  }
}
