import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import 'tokens.dart';
import 'theme_signals.dart';
import 'material_you_theme.dart';

export 'package:liquid_glass_widgets/liquid_glass_widgets.dart'
    show
        LiquidGlassSettings,
        LiquidRoundedSuperellipse,
        GlassQuality,
        GlassBodyMode,
        GlassSpecularSharpness,
        GlassSheetState;

class IrisGlass {
  static final ValueNotifier<bool> isFastScrolling = ValueNotifier<bool>(false);

  static bool reduceEffects(BuildContext context) {
    return ThemeSignals.useMinimalTheme.value ||
        !ThemeSignals.isFluidGlass ||
        ThemeSignals.glassTransparency.value <= 0.08;
  }

  /// Dynamically resolves the optimal [lgw.GlassQuality] tier for `liquid_glass_widgets` 1.14.2:
  /// - [lgw.GlassQuality.minimal]: Zero fragment shader cost during fast scrolling, Eco mode, or Opaque Glass.
  /// - [lgw.GlassQuality.premium]: Reserved strictly for static non-scrolling navigation bars.
  /// - [lgw.GlassQuality.standard]: Single-pass shader that renders reliably inside ListViews & CustomScrollViews.
  static lgw.GlassQuality adaptiveQuality(
    BuildContext context, {
    bool isStaticHero = false,
  }) {
    if (!ThemeSignals.isFluidGlass ||
        ThemeSignals.useMinimalTheme.value ||
        ThemeSignals.glassTransparency.value <= 0.08) {
      return lgw.GlassQuality.minimal;
    }
    return lgw.GlassQuality.premium;
  }

  /// High-performance zero-sigma backdrop filter helper:
  /// When sigma is 0.0 (e.g. non-glass themes, Opaque Glass, or Eco mode), directly returns [child]
  /// without allocating an expensive GPU compositing layer or offscreen texture.
  static Widget backdropFilter({
    required double sigmaX,
    required double sigmaY,
    required Widget child,
  }) {
    if (!ThemeSignals.isFluidGlass || (sigmaX <= 0.001 && sigmaY <= 0.001)) {
      return child;
    }
    return BackdropFilter(
      filter: ui.ImageFilter.blur(sigmaX: sigmaX, sigmaY: sigmaY),
      child: child,
    );
  }

  static double adaptiveBlur(
    BuildContext context,
    double base, {
    double min = 8.0,
  }) {
    if (ThemeSignals.useMinimalTheme.value || !ThemeSignals.isFluidGlass) {
      return 0.0;
    }
    final transparency = ThemeSignals.glassTransparency.value;
    if (transparency <= 0.08) {
      return 0.0;
    }
    if (isFastScrolling.value) {
      return math.min(base, min);
    }
    if (transparency <= 0.5) {
      final t = (transparency - 0.08) / (0.5 - 0.08);
      return ui.lerpDouble(8.0, base, t.clamp(0.0, 1.0))!;
    } else {
      final t = (transparency - 0.5) / 0.5;
      return ui.lerpDouble(base, base * 1.30, t.clamp(0.0, 1.0))!;
    }
  }

  static double adaptiveAmbient(BuildContext context, double base) {
    if (ThemeSignals.useMinimalTheme.value || !ThemeSignals.isFluidGlass) {
      return 0.0;
    }
    final transparency = ThemeSignals.glassTransparency.value;
    if (transparency <= 0.08) return 0.0;
    if (transparency <= 0.5) {
      final t = (transparency - 0.08) / (0.5 - 0.08);
      return ui.lerpDouble(0.35, base, t.clamp(0.0, 1.0))!;
    } else {
      final t = (transparency - 0.5) / 0.5;
      return ui.lerpDouble(
        base,
        math.min(1.0, base * 1.25),
        t.clamp(0.0, 1.0),
      )!;
    }
  }

  static double adaptiveThickness(
    BuildContext context,
    double base, {
    double min = 12.0,
  }) {
    if (ThemeSignals.useMinimalTheme.value || !ThemeSignals.isFluidGlass) {
      return 0.0;
    }
    final transparency = ThemeSignals.glassTransparency.value;
    if (transparency <= 0.08) return 0.0;
    if (transparency <= 0.5) {
      final t = (transparency - 0.08) / (0.5 - 0.08);
      return ui.lerpDouble(min, base, t.clamp(0.0, 1.0))!;
    } else {
      final t = (transparency - 0.5) / 0.5;
      return ui.lerpDouble(base, base * 1.30, t.clamp(0.0, 1.0))!;
    }
  }

  static Color adaptiveGlassColor(
    BuildContext context, {
    Color? dark,
    Color? light,
    double darkAlpha = 0.0,
    double lightAlpha = 0.0,
  }) {
    final isMinimal = ThemeSignals.useMinimalTheme.value;
    final isMaterialYou = ThemeSignals.isMaterialYou;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    if (isMaterialYou) {
      return MaterialYouTokens.surfaceContainer(
        isDark ? Brightness.dark : Brightness.light,
      );
    }

    if (isMinimal) {
      return isDark
          ? (dark ?? IrisTokens.surfaceDarkElevated)
          : (light ?? Colors.white);
    }

    // Elevated frosted slate in Dark Mode so cards have unmistakable physical body over #08080C
    final base = isDark
        ? (dark ?? const Color(0xFF1E293B))
        : (light ?? Colors.white);

    final transparency = ThemeSignals.glassTransparency.value;
    final defaultTargetAlpha = isDark ? 0.62 : 0.78;
    final effectiveTargetAlpha = (darkAlpha > 0.0 || lightAlpha > 0.0)
        ? (isDark ? darkAlpha : lightAlpha)
        : defaultTargetAlpha;

    final alpha =
        ui.lerpDouble(0.96, effectiveTargetAlpha, transparency)!.clamp(0.38, 0.98);
    return base.withValues(alpha: alpha);
  }

  static lgw.LiquidGlassSettings settings(
    BuildContext context, {
    double blur = 18.0,
    double ambientStrength = 0.82,
    double lightAngle = 1.35,
    double thickness = 18.0,
    Color? glassColor,
    double minBlur = 10.0,
    double minThickness = 12.0,
    double? lightIntensity,
    double refractiveIndex = 1.22,
    double chromaticAberration = 0.015,
    double saturation = 1.18,
    lgw.GlassSpecularSharpness specularSharpness =
        lgw.GlassSpecularSharpness.medium,
    lgw.GlassBodyMode? bodyMode,
  }) {
    final isMinimal = ThemeSignals.useMinimalTheme.value;
    final isMaterialYou = ThemeSignals.isMaterialYou;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final transparency = ThemeSignals.glassTransparency.value;

    Color effectiveColor;
    if (isMaterialYou) {
      effectiveColor = glassColor != null && glassColor.a >= 0.85
          ? glassColor
          : MaterialYouTokens.surfaceContainer(
              isDark ? Brightness.dark : Brightness.light,
            );
    } else if (isMinimal) {
      if (glassColor != null && glassColor.a >= 0.85) {
        effectiveColor = glassColor;
      } else {
        effectiveColor = isDark ? IrisTokens.surfaceDarkElevated : Colors.white;
      }
    } else {
      if (glassColor != null && glassColor != Colors.transparent) {
        // Ensure dark-mode glass colors are never pitch-black (#0C101A) or invisible (<0.42 alpha)
        final isTooDarkForDarkCanvas =
            isDark && glassColor.r < 0.12 && glassColor.g < 0.14 && glassColor.b < 0.20;
        final baseTint = isTooDarkForDarkCanvas
            ? Color.alphaBlend(
                Colors.white.withValues(alpha: 0.10),
                const Color(0xFF1E293B),
              )
            : glassColor;
        final floorAlpha = isDark ? 0.52 : 0.72;
        final targetAlpha = math.max(glassColor.a, floorAlpha);
        final resolvedA =
            ui.lerpDouble(0.96, targetAlpha, transparency)!.clamp(floorAlpha, 0.98);
        effectiveColor = baseTint.withValues(alpha: resolvedA);
      } else {
        final base = isDark
            ? Color.alphaBlend(
                Colors.white.withValues(alpha: 0.10),
                const Color(0xFF1E293B),
              )
            : Colors.white;
        final targetA = isDark ? 0.60 : 0.78;
        final resolvedA =
            ui.lerpDouble(0.96, targetA, transparency)!.clamp(0.50, 0.98);
        effectiveColor = base.withValues(alpha: resolvedA);
      }
    }

    final resolvedBlur = adaptiveBlur(context, blur, min: minBlur);
    final resolvedThickness =
        adaptiveThickness(context, thickness, min: minThickness);
    final resolvedAmbient = adaptiveAmbient(context, ambientStrength);
    final resolvedBodyMode = bodyMode ?? lgw.GlassBodyMode.adaptive;

    return lgw.LiquidGlassSettings(
      blur: resolvedBlur,
      ambientStrength: resolvedAmbient,
      lightAngle: lightAngle,
      glassColor: effectiveColor,
      thickness: resolvedThickness,
      lightIntensity: lightIntensity ?? (isDark ? 1.15 : 1.05),
      refractiveIndex: refractiveIndex,
      chromaticAberration: resolvedBlur > 0 ? chromaticAberration : 0.0,
      saturation: resolvedBlur > 0 ? saturation : 1.0,
      specularSharpness: specularSharpness,
      bodyMode: resolvedBodyMode,
    );
  }

  static lgw.LiquidGlassSettings widgetsSettings(
    BuildContext context, {
    double blur = 18.0,
    double ambientStrength = 0.82,
    double lightAngle = 1.35,
    double thickness = 18.0,
    Color? glassColor,
    double minBlur = 10.0,
    double minThickness = 12.0,
    double? lightIntensity,
    double refractiveIndex = 1.22,
    double chromaticAberration = 0.015,
    double saturation = 1.18,
    lgw.GlassSpecularSharpness specularSharpness =
        lgw.GlassSpecularSharpness.medium,
    lgw.GlassBodyMode? bodyMode,
  }) {
    return settings(
      context,
      blur: blur,
      ambientStrength: ambientStrength,
      lightAngle: lightAngle,
      thickness: thickness,
      glassColor: glassColor,
      minBlur: minBlur,
      minThickness: minThickness,
      lightIntensity: lightIntensity,
      refractiveIndex: refractiveIndex,
      chromaticAberration: chromaticAberration,
      saturation: saturation,
      specularSharpness: specularSharpness,
      bodyMode: bodyMode,
    );
  }

  static lgw.LiquidRoundedSuperellipse shape(
    double radius, {
    BorderSide side = BorderSide.none,
  }) {
    return lgw.LiquidRoundedSuperellipse(
      borderRadius: math.max(0.0, radius),
      side: side,
    );
  }
}
