/// Core API constants and endpoints for the CUI Helpdesk Backend
class HelpdeskApiConstants {
  // ---------------------------------------------------------------------------
  // Supabase Storage - Static JSON Data
  // ---------------------------------------------------------------------------
  static const String supabaseProjectUrl = 'https://pkhphvsrfdiqyzzmjykb.supabase.co';
  static const String supabaseStorageUrl = '$supabaseProjectUrl/storage/v1';
  static const String supabaseBucketUrl = '$supabaseStorageUrl/object/public';
  
  /// Supabase Storage Bucket Names
  static const String timetableBucket = 'timetable.json';
  static const String timetableFileName = 'timetable.json';
  static const String examScheduleBucket = 'exam_schedule.json';
  static const String examScheduleFileName = 'exam_schedule.json';

  /// Live Timetable JSON blob
  static const String timetableUrl = '$supabaseBucketUrl/$timetableBucket/$timetableFileName';
  
  /// Exam Schedule JSON blob
  static const String examScheduleUrl = '$supabaseBucketUrl/$examScheduleBucket/$examScheduleFileName';

  /// Supabase Storage Upload / Management REST Endpoint
  static const String timetableUploadUrl = '$supabaseStorageUrl/object/$timetableBucket/$timetableFileName';


  // ---------------------------------------------------------------------------
  // Render Custom Backend - Dynamic Operations
  // ---------------------------------------------------------------------------
  static const String renderBaseUrl = 'https://cui-helpdesk-backend.onrender.com/api';

  static const String facultyInfo = '$renderBaseUrl/faculty?limit=1000';
  static const String notices = '$renderBaseUrl/notices?limit=50';
  static const String societies = '$renderBaseUrl/societies?limit=1000';
  static const String events = '$renderBaseUrl/events?limit=1000';
  static const String lostAndFound = '$renderBaseUrl/lostfound';
  static const String timetableStatus = '$renderBaseUrl/admin/timetable/status';
  static const String alumniData = '$renderBaseUrl/alumni/all';
  static const String checkUpdate = '$renderBaseUrl/updates/check-update';


  // ---------------------------------------------------------------------------
  // Cloudinary Image Hosting
  // ---------------------------------------------------------------------------
  static const String cloudinaryBaseUrl = 'https://res.cloudinary.com/dbjdnztkq/image/upload/';
}
