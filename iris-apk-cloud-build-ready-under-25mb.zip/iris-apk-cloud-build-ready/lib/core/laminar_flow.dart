import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/physics.dart';
import 'package:flutter/scheduler.dart';

/// ============================================================================
/// 🌊 IRIS LAMINAR FLOW ENGINE (ColorOS 17 Living Flow Architecture)
/// ============================================================================
///
/// Inspired by OPPO ColorOS 17's Laminar Flow & Luminous Rendering Engine:
/// 1. Parallel Animation Tracks: Animations never block, snap, or stutter when
///    interrupted. Instantaneous spatial position (x₀) and velocity (v₀) are
///    seamlessly inherited into subsequent spring simulations (C¹ continuity).
/// 2. Hydrodynamic Viscosity Curves: Damped non-linear phase-space trajectories
///    modeled after laminar fluid streamlines without turbulent jitter.
/// 3. Laminar Task Interleaving: Cooperatively yields long-running campus computations
///    to the event loop so the 120 FPS VSYNC frame budget (8.33ms) is preserved.
/// ============================================================================

/// ColorOS 17 Living Flow motion curves & duration tokens.
class LaminarCurves {
  /// Ultra-fast initial laminar acceleration with smooth asymptotic settle.
  /// Mimics viscous fluid rushing into an open channel and reaching laminar equilibrium.
  static const Curve laminarEntrance = Cubic(0.05, 0.90, 0.10, 1.0);

  /// Smooth fluid deceleration curve for natural gesture release.
  static const Curve fluidDecelerate = Cubic(0.12, 0.95, 0.18, 1.0);

  /// ColorOS 17 parallel transition curve for layered element choreography.
  static const Curve parallelMotion = Cubic(0.20, 0.0, 0.0, 1.0);

  /// Viscoelastic rebound curve: slight organic overshoot with high damping.
  static const Curve viscoelasticBounce = Cubic(0.175, 0.885, 0.32, 1.15);

  /// Standard ColorOS 17 motion durations.
  static const Duration durationFast = Duration(milliseconds: 220);
  static const Duration durationFluid = Duration(milliseconds: 360);
  static const Duration durationParallel = Duration(milliseconds: 480);
  static const Duration durationExtended = Duration(milliseconds: 620);
}

/// Spring parameters matching OPPO ColorOS 17 fluid dynamics.
class LaminarSpringConfig {
  final double mass;
  final double stiffness;
  final double damping;

  const LaminarSpringConfig({
    this.mass = 1.0,
    this.stiffness = 320.0,
    this.damping = 26.0,
  });

  /// Snappy fluid spring for small UI micro-interactions (chips, toggles, pills).
  static const LaminarSpringConfig responsive = LaminarSpringConfig(
    mass: 0.8,
    stiffness: 420.0,
    damping: 30.0,
  );

  /// Balanced fluid spring for cards, container transforms, and modal sheets.
  static const LaminarSpringConfig standard = LaminarSpringConfig(
    mass: 1.0,
    stiffness: 300.0,
    damping: 24.0,
  );

  /// Viscous liquid spring for large Fluid Cloud expansions and page zooms.
  static const LaminarSpringConfig viscous = LaminarSpringConfig(
    mass: 1.2,
    stiffness: 240.0,
    damping: 22.0,
  );

  SpringDescription toSpringDescription() {
    return SpringDescription(
      mass: mass,
      stiffness: stiffness,
      damping: damping,
    );
  }
}

/// ============================================================================
/// 🚀 PARALLEL ANIMATION CONTROLLER (Velocity-Preserving Interruption)
/// ============================================================================
///
/// In standard Flutter, interrupting an in-flight animation leads to abrupt snaps
/// or jerky resets. [LaminarParallelController] continuously tracks instantaneous
/// position and velocity, ensuring that interrupting gestures or state transitions
/// maintain flawless C¹ velocity continuity.
class LaminarParallelController extends ChangeNotifier implements ValueListenable<double> {
  final TickerProvider vsync;
  final LaminarSpringConfig springConfig;

  Ticker? _ticker;
  SpringSimulation? _simulation;

  double _value;
  double _velocity = 0.0;
  double _targetValue;

  LaminarParallelController({
    required this.vsync,
    double initialValue = 0.0,
    this.springConfig = LaminarSpringConfig.standard,
  })  : _value = initialValue,
        _targetValue = initialValue;

  @override
  double get value => _value;
  double get velocity => _velocity;
  double get targetValue => _targetValue;
  bool get isAnimating => _ticker != null && _ticker!.isActive;

  /// Seamlessly animate to [newTarget].
  /// If an animation is already in flight, its instantaneous velocity (v₀) and
  /// position (x₀) are preserved and passed to the new spring simulation.
  void animateTo(double newTarget, {double? initialVelocity}) {
    if (_value == newTarget && (_velocity.abs() < 0.01)) {
      return;
    }

    _targetValue = newTarget;
    final effectiveVelocity = initialVelocity ?? _velocity;

    _simulation = SpringSimulation(
      springConfig.toSpringDescription(),
      _value,
      _targetValue,
      effectiveVelocity,
    );

    _ticker ??= vsync.createTicker(_handleTick);
    if (!_ticker!.isActive) {
      _ticker!.start();
    }
  }

  /// Instantly jump to a value, terminating any active simulation.
  void jumpTo(double newValue) {
    _simulation = null;
    _ticker?.stop();
    _value = newValue;
    _targetValue = newValue;
    _velocity = 0.0;
    notifyListeners();
  }

  void _handleTick(Duration elapsed) {
    if (_simulation == null) {
      _ticker?.stop();
      return;
    }

    final elapsedSeconds = elapsed.inMicroseconds / 1e6;
    _value = _simulation!.x(elapsedSeconds);
    _velocity = _simulation!.dx(elapsedSeconds);

    if (_simulation!.isDone(elapsedSeconds)) {
      _value = _targetValue;
      _velocity = 0.0;
      _simulation = null;
      _ticker?.stop();
    }

    notifyListeners();
  }

  @override
  void dispose() {
    _ticker?.dispose();
    super.dispose();
  }
}

/// ============================================================================
/// ⚡ LAMINAR SCROLL PHYSICS (Hydrodynamic Viscosity)
/// ============================================================================
///
/// Fluid scroll physics with velocity-dependent viscous resistance and
/// authentic ColorOS 17 elastic overscroll rebound.
class LaminarScrollPhysics extends BouncingScrollPhysics {
  final double viscosity;

  const LaminarScrollPhysics({
    super.parent,
    this.viscosity = 1.0,
  });

  @override
  LaminarScrollPhysics applyTo(ScrollPhysics? ancestor) {
    return LaminarScrollPhysics(
      parent: buildParent(ancestor),
      viscosity: viscosity,
    );
  }

  @override
  SpringDescription get spring => SpringDescription(
        mass: 0.85 * viscosity,
        stiffness: 220.0 / viscosity,
        damping: 24.0 * math.sqrt(viscosity),
      );

  @override
  double frictionFactor(double overscrollFraction) {
    // Non-linear fluid boundary resistance (logarithmic deceleration)
    return 0.48 * math.pow(1.0 - overscrollFraction.clamp(0.0, 1.0), 1.8).toDouble();
  }

  @override
  double get minFlingVelocity => 40.0;

  @override
  double get maxFlingVelocity => 9000.0;
}

/// ============================================================================
/// 🧠 LAMINAR WORK SCHEDULER (ColorOS 17 Adaptive Workload Interleaving)
/// ============================================================================
///
/// Cooperatively yields heavy campus computation (timetable lookups, room radar,
/// schedule indexing) into microtask time slices, ensuring that the 120 FPS
/// frame deadline (8.33ms) is never starved by background data processing.
class LaminarWorkScheduler {
  /// Executes a list of tasks cooperatively in micro-slices.
  /// If the current slice exceeds [maxSliceDurationMs] (default 4ms), it yields
  /// to the engine VSYNC loop before resuming.
  static Future<List<R>> interleave<T, R>({
    required List<T> items,
    required R Function(T item) processor,
    int maxSliceDurationMs = 4,
  }) async {
    final results = <R>[];
    final stopwatch = Stopwatch()..start();

    for (int i = 0; i < items.length; i++) {
      results.add(processor(items[i]));

      if (stopwatch.elapsedMilliseconds >= maxSliceDurationMs && i < items.length - 1) {
        // Yield to let the Flutter engine render the current frame at 120 FPS
        await SchedulerBinding.instance.endOfFrame;
        stopwatch.reset();
      }
    }

    return results;
  }
}
