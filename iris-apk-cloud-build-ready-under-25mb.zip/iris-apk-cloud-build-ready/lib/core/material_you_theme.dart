import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:google_fonts/google_fonts.dart';
import 'theme_signals.dart';

/// Predefined curated Material 3 Expressive Tonal Palettes
class M3EPalettePreset {
  final String id;
  final String name;
  final String description;
  final Color seedColor;
  final IconData icon;

  const M3EPalettePreset({
    required this.id,
    required this.name,
    required this.description,
    required this.seedColor,
    required this.icon,
  });
}

class M3EPalettes {
  static const List<M3EPalettePreset> presets = [
    M3EPalettePreset(
      id: 'monet_blue',
      name: 'Iris Monet',
      description: 'Dynamic Android 15 Sky & Cobalt',
      seedColor: Color(0xFF0061A4),
      icon: Icons.water_drop_rounded,
    ),
    M3EPalettePreset(
      id: 'amethyst_violet',
      name: 'Amethyst Violet',
      description: 'Expressive Royal Lavender & Orchid',
      seedColor: Color(0xFF6750A4),
      icon: Icons.auto_awesome_rounded,
    ),
    M3EPalettePreset(
      id: 'verdant_emerald',
      name: 'Verdant Emerald',
      description: 'Botanical Forest Mint & Sage',
      seedColor: Color(0xFF006C4C),
      icon: Icons.eco_rounded,
    ),
    M3EPalettePreset(
      id: 'solar_amber',
      name: 'Solar Amber',
      description: 'Warm Ochre, Honey & Sunlight',
      seedColor: Color(0xFF8C5000),
      icon: Icons.wb_sunny_rounded,
    ),
    M3EPalettePreset(
      id: 'sakura_blush',
      name: 'Sakura Blush',
      description: 'Crimson Rose, Peony & Petal',
      seedColor: Color(0xFF984061),
      icon: Icons.local_florist_rounded,
    ),
    M3EPalettePreset(
      id: 'oceanic_teal',
      name: 'Oceanic Teal',
      description: 'Deep Pacific Cyan & Marine Reef',
      seedColor: Color(0xFF006876),
      icon: Icons.waves_rounded,
    ),
    M3EPalettePreset(
      id: 'terracotta_rust',
      name: 'Terracotta Rust',
      description: 'Warm Desert Canyon Clay & Earth',
      seedColor: Color(0xFF9C4323),
      icon: Icons.terrain_rounded,
    ),
    M3EPalettePreset(
      id: 'cyber_neon',
      name: 'Cyber Citron',
      description: 'High-Energy Electric Lime & Mint',
      seedColor: Color(0xFF4C662B),
      icon: Icons.bolt_rounded,
    ),
    M3EPalettePreset(
      id: 'midnight_slate',
      name: 'Midnight Slate',
      description: 'Deep Obsidian Twilight & Indigo',
      seedColor: Color(0xFF2C3E50),
      icon: Icons.nightlight_round,
    ),
    M3EPalettePreset(
      id: 'crimson_ruby',
      name: 'Crimson Ruby',
      description: 'Rich Scarlet, Berry & Garnet',
      seedColor: Color(0xFFB3261E),
      icon: Icons.favorite_rounded,
    ),
  ];
}

/// Material You (Material 3) Tonal System & Theme Definitions for IRIS.
/// Implements authentic Android 14/15 Monet-style surface containers,
/// tonal palettes, squircle geometry, and locked 120 FPS flat rasterization.
class MaterialYouTokens {
  // Light Palette
  static const Color primaryLight = Color(0xFF0061A4);
  static const Color onPrimaryLight = Color(0xFFFFFFFF);
  static const Color primaryContainerLight = Color(0xFFD1E4FF);
  static const Color onPrimaryContainerLight = Color(0xFF001D36);

  static const Color secondaryLight = Color(0xFF535F70);
  static const Color onSecondaryLight = Color(0xFFFFFFFF);
  static const Color secondaryContainerLight = Color(0xFFD7E3F7);
  static const Color onSecondaryContainerLight = Color(0xFF101C2B);

  static const Color tertiaryLight = Color(0xFF6B5778);
  static const Color onTertiaryLight = Color(0xFFFFFFFF);
  static const Color tertiaryContainerLight = Color(0xFFF2DAFF);
  static const Color onTertiaryContainerLight = Color(0xFF251432);

  static const Color surfaceLight = Color(0xFFF8F9FF);
  static const Color surfaceDimLight = Color(0xFFD8DAE0);
  static const Color surfaceBrightLight = Color(0xFFF8F9FF);
  static const Color surfaceContainerLowestLight = Color(0xFFFFFFFF);
  static const Color surfaceContainerLowLight = Color(0xFFF2F3F9);
  static const Color surfaceContainerLight = Color(0xFFECEDF4);
  static const Color surfaceContainerHighLight = Color(0xFFE6E8EE);
  static const Color surfaceContainerHighestLight = Color(0xFFE0E2E8);

  static const Color onSurfaceLight = Color(0xFF191C20);
  static const Color onSurfaceVariantLight = Color(0xFF43474E);
  static const Color outlineLight = Color(0xFF73777F);
  static const Color outlineVariantLight = Color(0xFFC3C7D0);

  // Dark Palette
  static const Color primaryDark = Color(0xFF9ECAFF);
  static const Color onPrimaryDark = Color(0xFF003258);
  static const Color primaryContainerDark = Color(0xFF00497D);
  static const Color onPrimaryContainerDark = Color(0xFFD1E4FF);

  static const Color secondaryDark = Color(0xFFBBC7DB);
  static const Color onSecondaryDark = Color(0xFF253140);
  static const Color secondaryContainerDark = Color(0xFF3B4858);
  static const Color onSecondaryContainerDark = Color(0xFFD7E3F7);

  static const Color tertiaryDark = Color(0xFFD6BEE4);
  static const Color onTertiaryDark = Color(0xFF3B2947);
  static const Color tertiaryContainerDark = Color(0xFF533F5F);
  static const Color onTertiaryContainerDark = Color(0xFFF2DAFF);

  static const Color surfaceDark = Color(0xFF111318);
  static const Color surfaceDimDark = Color(0xFF111318);
  static const Color surfaceBrightDark = Color(0xFF37393E);
  static const Color surfaceContainerLowestDark = Color(0xFF0B0E13);
  static const Color surfaceContainerLowDark = Color(0xFF191C20);
  static const Color surfaceContainerDark = Color(0xFF1D2024);
  static const Color surfaceContainerHighDark = Color(0xFF272A2F);
  static const Color surfaceContainerHighestDark = Color(0xFF32353A);

  static const Color onSurfaceDark = Color(0xFFE1E2E8);
  static const Color onSurfaceVariantDark = Color(0xFFC3C7D0);
  static const Color outlineDark = Color(0xFF8D9199);
  static const Color outlineVariantDark = Color(0xFF43474E);

  // Radii Tokens
  static const double cardRadius = 24.0;
  static const double innerRadius = 16.0;
  static const double radiusMedium = 16.0;
  static const double pillRadius = 999.0;
  static const double sheetRadius = 28.0;

  // Elevation Tokens
  static const double elevation0 = 0.0;
  static const double elevation1 = 1.0;
  static const double elevation2 = 3.0;
  static const double elevation3 = 6.0;

  // Brightness-aware helpers (dynamically powered by active M3E ColorScheme)
  static ColorScheme _scheme(Brightness b) =>
      b == Brightness.dark ? MaterialYouTheme.getDarkColorScheme() : MaterialYouTheme.getLightColorScheme();

  static Color primary(Brightness b) => _scheme(b).primary;
  static Color onPrimary(Brightness b) => _scheme(b).onPrimary;
  static Color secondary(Brightness b) => _scheme(b).secondary;
  static Color secondaryContainer(Brightness b) => _scheme(b).secondaryContainer;
  static Color onSecondaryContainer(Brightness b) => _scheme(b).onSecondaryContainer;
  static Color surface(Brightness b) => _scheme(b).surface;
  static Color onSurface(Brightness b) => _scheme(b).onSurface;
  static Color surfaceContainerLowest(Brightness b) => _scheme(b).surfaceContainerLowest;
  static Color surfaceContainerLow(Brightness b) => _scheme(b).surfaceContainerLow;
  static Color surfaceContainer(Brightness b) => _scheme(b).surfaceContainer;
  static Color surfaceContainerHigh(Brightness b) => _scheme(b).surfaceContainerHigh;
  static Color surfaceContainerHighest(Brightness b) => _scheme(b).surfaceContainerHighest;
  static Color outline(Brightness b) => _scheme(b).outline;
  static Color outlineVariant(Brightness b) => _scheme(b).outlineVariant;
  static Color onSurfaceVariant(Brightness b) => _scheme(b).onSurfaceVariant;
}

/// Helper to build Material You color schemes and themes
class MaterialYouTheme {
  /// Dynamically generated light ColorScheme from the active or given seed color.
  static ColorScheme getLightColorScheme([Color? seedColor]) {
    final seed = seedColor ?? ThemeSignals.m3eSeedColor.value;
    return ColorScheme.fromSeed(
      seedColor: seed,
      brightness: Brightness.light,
    );
  }

  /// Dynamically generated dark ColorScheme from the active or given seed color.
  static ColorScheme getDarkColorScheme([Color? seedColor]) {
    final seed = seedColor ?? ThemeSignals.m3eSeedColor.value;
    return ColorScheme.fromSeed(
      seedColor: seed,
      brightness: Brightness.dark,
    );
  }

  /// Fallback static references for legacy callers.
  static ColorScheme get lightColorScheme => getLightColorScheme();
  static ColorScheme get darkColorScheme => getDarkColorScheme();

  static Color surfaceContainer(BuildContext context) {
    return Theme.of(context).colorScheme.surfaceContainer;
  }

  static Color surfaceContainerHigh(BuildContext context) {
    return Theme.of(context).colorScheme.surfaceContainerHigh;
  }

  static Color surfaceContainerLow(BuildContext context) {
    return Theme.of(context).colorScheme.surfaceContainerLow;
  }

  static Color surfaceContainerHighest(BuildContext context) {
    return Theme.of(context).colorScheme.surfaceContainerHighest;
  }

  static Color borderStroke(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Theme.of(context).colorScheme.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.6);
  }

  static TextTheme buildExpressiveTextTheme(ColorScheme colorScheme) {
    return GoogleFonts.robotoFlexTextTheme(
      TextTheme(
        displayLarge: TextStyle(
        fontSize: 57,
        fontWeight: FontWeight.w900,
        letterSpacing: -0.25,
        color: colorScheme.onSurface,
        height: 1.12,
      ),
      displayMedium: TextStyle(
        fontSize: 45,
        fontWeight: FontWeight.w800,
        letterSpacing: 0,
        color: colorScheme.onSurface,
        height: 1.16,
      ),
      displaySmall: TextStyle(
        fontSize: 36,
        fontWeight: FontWeight.w800,
        letterSpacing: 0,
        color: colorScheme.onSurface,
        height: 1.22,
      ),
      headlineLarge: TextStyle(
        fontSize: 32,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.2,
        color: colorScheme.onSurface,
        height: 1.25,
      ),
      headlineMedium: TextStyle(
        fontSize: 28,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.15,
        color: colorScheme.onSurface,
        height: 1.29,
      ),
      headlineSmall: TextStyle(
        fontSize: 24,
        fontWeight: FontWeight.w700,
        letterSpacing: 0,
        color: colorScheme.onSurface,
        height: 1.33,
      ),
      titleLarge: TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.w700,
        letterSpacing: 0,
        color: colorScheme.onSurface,
        height: 1.27,
      ),
      titleMedium: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
        letterSpacing: 0.15,
        color: colorScheme.onSurface,
        height: 1.5,
      ),
      titleSmall: TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w700,
        letterSpacing: 0.1,
        color: colorScheme.onSurface,
        height: 1.43,
      ),
      labelLarge: TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w800,
        letterSpacing: 0.1,
        color: colorScheme.onSurface,
        height: 1.43,
      ),
      labelMedium: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w700,
        letterSpacing: 0.5,
        color: colorScheme.onSurfaceVariant,
        height: 1.33,
      ),
      labelSmall: TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w800,
        letterSpacing: 0.5,
        color: colorScheme.onSurfaceVariant,
        height: 1.45,
      ),
      bodyLarge: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w400,
        letterSpacing: 0.15,
        color: colorScheme.onSurface,
        height: 1.5,
      ),
      bodyMedium: TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w400,
        letterSpacing: 0.25,
        color: colorScheme.onSurfaceVariant,
        height: 1.43,
      ),
      bodySmall: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w400,
        letterSpacing: 0.4,
        color: colorScheme.onSurfaceVariant,
        height: 1.33,
      ),
    ));
  }

  static ThemeData buildTheme({
    required Brightness brightness,
    Color? seedColor,
  }) {
    final isDark = brightness == Brightness.dark;
    final seed = seedColor ?? ThemeSignals.m3eSeedColor.value;
    final colorScheme = ColorScheme.fromSeed(
      seedColor: seed,
      brightness: brightness,
    );
    final background = colorScheme.surface;

    return ThemeData(
      useMaterial3: true,
      fontFamily: GoogleFonts.robotoFlex().fontFamily,
      brightness: brightness,
      scaffoldBackgroundColor: background,
      colorScheme: colorScheme,
      textTheme: buildExpressiveTextTheme(colorScheme),
      cardTheme: CardThemeData(
        color: colorScheme.surfaceContainer,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24.0),
          side: BorderSide(
            color: colorScheme.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.6),
            width: 1.0,
          ),
        ),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: background,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w800,
          color: colorScheme.onSurface,
        ),
        iconTheme: IconThemeData(color: colorScheme.onSurface),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: colorScheme.surfaceContainer,
        indicatorColor: colorScheme.secondaryContainer,
        indicatorShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        height: 74,
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: colorScheme.onSurface,
            );
          }
          return TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: colorScheme.onSurfaceVariant,
          );
        }),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return IconThemeData(color: colorScheme.onSecondaryContainer, size: 26);
          }
          return IconThemeData(color: colorScheme.onSurfaceVariant, size: 24);
        }),
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: colorScheme.primaryContainer,
        foregroundColor: colorScheme.onPrimaryContainer,
        elevation: 3.0,
        highlightElevation: 4.0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
      menuTheme: MenuThemeData(
        style: MenuStyle(
          backgroundColor: WidgetStatePropertyAll(
            colorScheme.surfaceContainerHigh,
          ),
          surfaceTintColor: const WidgetStatePropertyAll(Colors.transparent),
          elevation: const WidgetStatePropertyAll(8.0),
          shadowColor: WidgetStatePropertyAll(Colors.black.withValues(alpha: isDark ? 0.45 : 0.15)),
          shape: WidgetStatePropertyAll(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24.0),
              side: BorderSide(
                color: colorScheme.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.6),
                width: 1.0,
              ),
            ),
          ),
          padding: const WidgetStatePropertyAll(EdgeInsets.symmetric(vertical: 8.0, horizontal: 6.0)),
        ),
      ),
      menuButtonTheme: MenuButtonThemeData(
        style: MenuItemButton.styleFrom(
          foregroundColor: colorScheme.onSurface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
        ),
      ),
      dropdownMenuTheme: DropdownMenuThemeData(
        menuStyle: MenuStyle(
          backgroundColor: WidgetStatePropertyAll(colorScheme.surfaceContainerHigh),
          surfaceTintColor: const WidgetStatePropertyAll(Colors.transparent),
          elevation: const WidgetStatePropertyAll(6.0),
          shadowColor: WidgetStatePropertyAll(Colors.black.withValues(alpha: isDark ? 0.35 : 0.12)),
          shape: WidgetStatePropertyAll(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20.0),
              side: BorderSide(
                color: colorScheme.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.6),
                width: 1.0,
              ),
            ),
          ),
          padding: const WidgetStatePropertyAll(EdgeInsets.symmetric(vertical: 6.0, horizontal: 4.0)),
        ),
      ),
      popupMenuTheme: PopupMenuThemeData(
        color: colorScheme.surfaceContainerHigh,
        surfaceTintColor: Colors.transparent,
        elevation: 6.0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24.0),
          side: BorderSide(
            color: colorScheme.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.6),
            width: 1.0,
          ),
        ),
        textStyle: TextStyle(
          color: colorScheme.onSurface,
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: colorScheme.surfaceContainerHigh,
        surfaceTintColor: Colors.transparent,
        elevation: 3.0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
        titleTextStyle: TextStyle(
          fontSize: 22,
          fontWeight: FontWeight.w700,
          color: colorScheme.onSurface,
        ),
        contentTextStyle: TextStyle(
          fontSize: 14,
          color: colorScheme.onSurfaceVariant,
        ),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: colorScheme.surfaceContainerLow,
        surfaceTintColor: Colors.transparent,
        elevation: 1.0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        dragHandleColor: colorScheme.outline,
        showDragHandle: true,
      ),
      chipTheme: ChipThemeData(
        backgroundColor: colorScheme.surfaceContainerLow,
        selectedColor: colorScheme.secondaryContainer,
        side: BorderSide(
          color: colorScheme.outlineVariant.withValues(alpha: 0.5),
          width: 1.0,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
        labelStyle: TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          color: colorScheme.onSurface,
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          shape: const StadiumBorder(),
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          elevation: 1,
          shadowColor: colorScheme.shadow,
          shape: const StadiumBorder(),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          backgroundColor: colorScheme.surfaceContainerLow,
          foregroundColor: colorScheme.primary,
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          shape: const StadiumBorder(),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          side: BorderSide(
            color: colorScheme.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.6),
            width: 1.0,
          ),
          foregroundColor: colorScheme.primary,
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          shape: const StadiumBorder(),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          foregroundColor: colorScheme.primary,
        ),
      ),
      segmentedButtonTheme: SegmentedButtonThemeData(
        style: SegmentedButton.styleFrom(
          selectedBackgroundColor: colorScheme.secondaryContainer,
          selectedForegroundColor: colorScheme.onSecondaryContainer,
          backgroundColor: colorScheme.surfaceContainer,
          foregroundColor: colorScheme.onSurface,
          shape: const StadiumBorder(),
          side: BorderSide(
            color: colorScheme.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.6),
            width: 1.0,
          ),
        ),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return colorScheme.onPrimary;
          }
          return colorScheme.outline;
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return colorScheme.primary;
          }
          return colorScheme.surfaceContainerHighest;
        }),
        trackOutlineColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return Colors.transparent;
          }
          return colorScheme.outline;
        }),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: isDark ? const Color(0xFFE2E2E6) : const Color(0xFF2E3036),
        contentTextStyle: TextStyle(
          color: isDark ? const Color(0xFF1B1B1F) : const Color(0xFFF1F0F4),
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        elevation: 4.0,
      ),
      searchBarTheme: SearchBarThemeData(
        elevation: const WidgetStatePropertyAll(0),
        backgroundColor: WidgetStatePropertyAll(
          colorScheme.surfaceContainerHigh,
        ),
        shape: const WidgetStatePropertyAll(StadiumBorder()),
        hintStyle: WidgetStatePropertyAll(
          TextStyle(color: colorScheme.onSurfaceVariant, fontSize: 15),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(24),
          borderSide: BorderSide(
            color: colorScheme.outlineVariant,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(24),
          borderSide: BorderSide(
            color: colorScheme.outlineVariant,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(24),
          borderSide: BorderSide(
            color: colorScheme.primary,
            width: 2.0,
          ),
        ),
      ),
      splashFactory: InkSparkle.splashFactory,
      iconTheme: IconThemeData(
        color: colorScheme.onSurface,
        size: 24.0,
      ),
      dividerTheme: DividerThemeData(
        color: colorScheme.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.6),
        thickness: 1.0,
        space: 1.0,
      ),
      listTileTheme: ListTileThemeData(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        tileColor: Colors.transparent,
        selectedTileColor: colorScheme.secondaryContainer.withValues(alpha: 0.5),
        selectedColor: colorScheme.onSecondaryContainer,
        iconColor: colorScheme.onSurfaceVariant,
        textColor: colorScheme.onSurface,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      ),
      tabBarTheme: TabBarThemeData(
        indicatorColor: colorScheme.primary,
        indicatorSize: TabBarIndicatorSize.tab,
        labelColor: colorScheme.primary,
        unselectedLabelColor: colorScheme.onSurfaceVariant,
        labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
        unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14),
        dividerColor: Colors.transparent,
      ),
      badgeTheme: BadgeThemeData(
        backgroundColor: colorScheme.error,
        textColor: colorScheme.onError,
        textStyle: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800),
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: colorScheme.primary,
        linearTrackColor: colorScheme.surfaceContainerHighest,
        circularTrackColor: colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(8),
      ),
      tooltipTheme: TooltipThemeData(
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFFE2E2E6) : const Color(0xFF2E3036),
          borderRadius: BorderRadius.circular(8),
        ),
        textStyle: TextStyle(
          color: isDark ? const Color(0xFF1B1B1F) : const Color(0xFFF1F0F4),
          fontSize: 12,
          fontWeight: FontWeight.w500,
        ),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      ),
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          TargetPlatform.android: ZoomPageTransitionsBuilder(),
          TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
        },
      ),
    );
  }
}
