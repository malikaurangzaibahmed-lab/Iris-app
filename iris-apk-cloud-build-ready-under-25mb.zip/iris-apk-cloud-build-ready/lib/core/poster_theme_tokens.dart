import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Design tokens, brutalist 3D extruded drop-block shadows, and monolithic typography
/// for the Poster / Swiss Brutalism Theme.
/// Tuned for crisp legibility, balanced letter-spacing, and zero text clipping across all screen sizes.
class PosterTokens {
  // --- Canvas & Surfaces ---
  static Color canvas(bool isDark) =>
      isDark ? const Color(0xFF0A0C0E) : const Color(0xFFEBE8E1);

  static Color cardSurface(bool isDark) =>
      isDark ? const Color(0xFF14181E) : Colors.white;

  // --- Signature International Orange Hero Accent ---
  static const Color orangeHero = Color(0xFFFF451A);

  // --- High-Contrast Borders & Rules ---
  static Color inkBorder(bool isDark) =>
      isDark ? const Color(0xFFF4F6F8) : const Color(0xFF000000);

  static Color inkBorderSubtle(bool isDark) =>
      isDark ? const Color(0xFF384252) : const Color(0xFF9E9B95);

  // --- Typography Inks ---
  static Color inkHeading(bool isDark) =>
      isDark ? const Color(0xFFFFFFFF) : const Color(0xFF000000);

  static Color inkBody(bool isDark) =>
      isDark ? const Color(0xFFE2E8F0) : const Color(0xFF111111);

  static Color inkMuted(bool isDark) =>
      isDark ? const Color(0xFF94A3B8) : const Color(0xFF4B5563);

  // --- Bottom Navigation Colors ---
  static Color navBarBackground(bool isDark) =>
      isDark ? const Color(0xFF0A0C0E) : const Color(0xFFEBE8E1);

  static Color navActiveBlock(bool isDark) => orangeHero;

  static Color navActiveText(bool isDark) => Colors.black;

  static Color navInactiveText(bool isDark) =>
      isDark ? const Color(0xFFE5E7EB) : const Color(0xFF000000);

  // --- Monolithic Swiss Typography (Balanced & Legible) ---
  static TextStyle heroMonolithicClock(bool isDark) {
    return GoogleFonts.archivoBlack(
      fontSize: 68,
      fontWeight: FontWeight.w900,
      letterSpacing: -2.2,
      height: 0.96,
      color: Colors.black,
    );
  }

  static TextStyle heroOrangeTag(bool isDark) {
    return GoogleFonts.spaceMono(
      fontSize: 11.5,
      fontWeight: FontWeight.w700,
      letterSpacing: 1.0,
      height: 1.25,
      color: Colors.black,
    );
  }

  static TextStyle heroOrangeTitle(bool isDark) {
    return GoogleFonts.archivoBlack(
      fontSize: 20,
      fontWeight: FontWeight.w900,
      letterSpacing: -0.4,
      height: 1.15,
      color: Colors.black,
    );
  }

  static TextStyle classIndexNumber(bool isDark) {
    return GoogleFonts.archivoBlack(
      fontSize: 38,
      fontWeight: FontWeight.w900,
      letterSpacing: -1.2,
      height: 1.0,
      color: inkHeading(isDark),
    );
  }

  static TextStyle classTitle(bool isDark) {
    return GoogleFonts.archivoBlack(
      fontSize: 16,
      fontWeight: FontWeight.w900,
      letterSpacing: -0.2,
      height: 1.22,
      color: inkHeading(isDark),
    );
  }

  // --- Brutalist 3D Extruded Block Shadow ---
  static List<BoxShadow> extrudedBlockShadow(
    bool isDark, {
    double offset = 4.0,
    Color? color,
  }) {
    return [
      BoxShadow(
        offset: Offset(offset, offset),
        color: color ?? (isDark ? Colors.black : const Color(0xFF000000)),
        blurRadius: 0,
        spreadRadius: 0,
      ),
    ];
  }
}
