import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';
import 'format_guard.dart';

/// Represents a specific course taught in a particular student batch.
class CourseOffering {
  final String courseName;
  final String batch;
  final String teacher;
  final String room;
  final List<ClassSession> sessions;

  const CourseOffering({
    required this.courseName,
    required this.batch,
    required this.teacher,
    required this.room,
    required this.sessions,
  });

  /// Human-readable time slots summary (e.g. "Mon 08:30-10:00 (C-1), Wed 10:00-11:30 (C-2)")
  String get timeSlotsSummary {
    if (sessions.isEmpty) return 'No scheduled slots';
    final parts = sessions.map((s) {
      final dayName = _shortDay(s.dayIndex);
      final roomStr = s.room.isNotEmpty ? ' (${s.room})' : '';
      return '$dayName ${s.startTime}-${s.endTime}$roomStr';
    }).toList();
    return parts.join(' · ');
  }

  static String _shortDay(int dayIndex) {
    switch (dayIndex) {
      case 1:
        return 'Mon';
      case 2:
        return 'Tue';
      case 3:
        return 'Wed';
      case 4:
        return 'Thu';
      case 5:
        return 'Fri';
      case 6:
        return 'Sat';
      case 7:
        return 'Sun';
      default:
        return 'Day $dayIndex';
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'courseName': courseName,
      'batch': batch,
      'teacher': teacher,
      'room': room,
      'sessionIds': sessions.map((s) => s.id).toList(),
    };
  }
}

/// Represents an exact time clash between two course sessions.
class ScheduleClash {
  final String courseA;
  final String batchA;
  final ClassSession sessionA;
  final String courseB;
  final String batchB;
  final ClassSession sessionB;
  final int dayIndex;

  const ScheduleClash({
    required this.courseA,
    required this.batchA,
    required this.sessionA,
    required this.courseB,
    required this.batchB,
    required this.sessionB,
    required this.dayIndex,
  });

  String get dayName {
    switch (dayIndex) {
      case 1:
        return 'Monday';
      case 2:
        return 'Tuesday';
      case 3:
        return 'Wednesday';
      case 4:
        return 'Thursday';
      case 5:
        return 'Friday';
      case 6:
        return 'Saturday';
      case 7:
        return 'Sunday';
      default:
        return 'Day $dayIndex';
    }
  }

  String get description {
    return '$courseA ($batchA) clashes with $courseB ($batchB) on $dayName (${sessionA.startTime} - ${sessionA.endTime})';
  }
}

/// Represents a real course offering taught in a university section with clash analysis against a student's regular timetable.
class AnalyzedOffering {
  final CourseOffering offering;
  final bool hasClash;
  final List<ScheduleClash> clashes;

  const AnalyzedOffering({
    required this.offering,
    required this.hasClash,
    this.clashes = const [],
  });

  bool get isClashFree => !hasClash;

  String get clashSummary {
    if (clashes.isEmpty) return 'Conflict-free';
    final first = clashes.first;
    return 'Clashes with ${first.courseB} on ${first.dayName}';
  }
}

/// Persistent storage manager for repeater / custom timetables.
class RepeaterScheduleStorage {
  static const String _keyIsRepeater = 'iris_is_repeater_student';
  static const String _keyBaseBatch = 'iris_repeater_base_batch';
  static const String _keySelectedCourses = 'iris_repeater_courses';
  static const String _keySelectedOfferings = 'iris_repeater_offerings';
  static const String _keyCustomSessions = 'iris_repeater_sessions_cache';

  static Future<bool> isRepeaterActive() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getBool(_keyIsRepeater) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<String?> getBaseBatch() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_keyBaseBatch);
    } catch (_) {
      return null;
    }
  }

  static Future<void> setBaseBatch(String batch) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyBaseBatch, batch);
    } catch (_) {}
  }

  static Future<List<String>> getSelectedCourses() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getStringList(_keySelectedCourses) ?? [];
    } catch (_) {
      return [];
    }
  }

  static Future<int> getCustomCourseCount() async {
    final courses = await getSelectedCourses();
    return courses.length;
  }

  static Future<Map<String, String>> getSelectedOfferingsMap() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_keySelectedOfferings);
      if (raw == null || raw.isEmpty) return {};
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      return decoded.map((k, v) => MapEntry(k, v.toString()));
    } catch (_) {
      return {};
    }
  }

  static Future<void> saveRepeaterSchedule({
    String? baseBatch,
    required List<String> courses,
    required Map<String, CourseOffering> offerings,
    required List<ClassSession> sessions,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyIsRepeater, true);
    if (baseBatch != null && baseBatch.isNotEmpty) {
      await prefs.setString(_keyBaseBatch, baseBatch);
    }
    await prefs.setStringList(_keySelectedCourses, courses);

    final offeringMap = offerings.map((k, v) => MapEntry(k, v.batch));
    await prefs.setString(_keySelectedOfferings, jsonEncode(offeringMap));

    // Serialize custom sessions
    final sessionsJson = sessions.map((s) {
      return {
        'id': s.id,
        'batch': s.batchKey.batch,
        'dayIndex': s.dayIndex,
        'startTime': s.startTime,
        'endTime': s.endTime,
        'subject': s.subject,
        'teacher': s.teacher,
        'room': s.room,
        'isBreak': s.isBreak,
      };
    }).toList();
    await prefs.setString(_keyCustomSessions, jsonEncode(sessionsJson));
  }

  static Future<void> clearRepeaterSchedule() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyIsRepeater);
    await prefs.remove(_keyBaseBatch);
    await prefs.remove(_keySelectedCourses);
    await prefs.remove(_keySelectedOfferings);
    await prefs.remove(_keyCustomSessions);
  }

  static Future<List<ClassSession>> loadSavedSessions(UniversityMemory memory) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_keyCustomSessions);
      if (raw == null || raw.isEmpty) return [];

      final list = jsonDecode(raw) as List<dynamic>;
      final result = <ClassSession>[];

      for (final item in list) {
        if (item is Map) {
          final m = Map<String, dynamic>.from(item);
          final batchStr = (m['batch'] ?? '').toString();
          final key = BatchKey.parse(batchStr);
          result.add(
            ClassSession(
              id: (m['id'] ?? '').toString(),
              batchKey: key,
              dayIndex: (m['dayIndex'] as num?)?.toInt() ?? 1,
              startTime: (m['startTime'] ?? '').toString(),
              endTime: (m['endTime'] ?? '').toString(),
              subject: (m['subject'] ?? '').toString(),
              teacher: (m['teacher'] ?? '').toString(),
              room: (m['room'] ?? '').toString(),
              isBreak: m['isBreak'] == true,
            ),
          );
        }
      }
      return result;
    } catch (e) {
      debugPrint('Error loading saved repeater sessions: $e');
      return [];
    }
  }
}

/// The core intelligence engine for repeater course analysis and clash solving.
class RepeaterPlannerEngine {
  /// Cleans and canonicalizes course subject names for clean grouping.
  static String normalizeCourseName(String rawSubject) {
    if (rawSubject.trim().isEmpty) return '';
    var cleaned = rawSubject
        .replaceAll(RegExp(r'\s*\((lab|1\s*hr|2\s*hr|theory)\)', caseSensitive: false), '')
        .replaceAll(RegExp(r'\s*-\s*(lab|theory)', caseSensitive: false), '')
        .trim();
    // Normalize casing
    return FormatGuard.sanitizeSubject(cleaned);
  }

  static List<String>? _cachedUniqueCourses;
  static final Map<String, Map<String, CourseOffering>> _cachedBatchCourses = {};
  static final Map<String, List<CourseOffering>> _cachedCourseOfferings = {};
  static final Map<String, List<ClassSession>> _cachedBatchSessions = {};
  static final Map<String, List<AnalyzedOffering>> _cachedAnalyzedOfferings = {};

  static void clearCaches() {
    _cachedUniqueCourses = null;
    _cachedBatchCourses.clear();
    _cachedCourseOfferings.clear();
    _cachedBatchSessions.clear();
    _cachedAnalyzedOfferings.clear();
  }

  /// Retrieves all scheduled classes for the given base batch (instant cached lookup).
  static List<ClassSession> getBaseBatchSessions(
    UniversityMemory memory,
    String batch,
  ) {
    final cleanB = batch.trim().toUpperCase();
    final cached = _cachedBatchSessions[cleanB];
    if (cached != null) return cached;

    final sessions = memory.sessions
        .where((s) => !s.isBreak && s.batchKey.batch.trim().toUpperCase() == cleanB)
        .toList();
    _cachedBatchSessions[cleanB] = sessions;
    return sessions;
  }

  /// Analyzes where a repeat/improvement course is being taught across the university,
  /// who is teaching it, which room, which batch, and evaluates real-time clashes against the student's normal batch courses.
  static List<AnalyzedOffering> analyzeOfferingsForCourse({
    required UniversityMemory memory,
    required String courseName,
    required String baseBatch,
  }) {
    final cleanBatch = baseBatch.trim().toUpperCase();
    final cleanCourse = normalizeCourseName(courseName).toLowerCase();
    final cacheKey = '$cleanBatch|$cleanCourse';
    final cached = _cachedAnalyzedOfferings[cacheKey];
    if (cached != null) return cached;

    // 1. Get base batch sessions and group by dayIndex for microsecond clash lookups
    final baseSessions = getBaseBatchSessions(memory, baseBatch);
    final baseByDay = <int, List<ClassSession>>{};
    for (final s in baseSessions) {
      baseByDay.putIfAbsent(s.dayIndex, () => []).add(s);
    }

    // 2. Find all existing sections offering this course
    final offerings = getOfferingsForCourse(memory, courseName);
    final result = <AnalyzedOffering>[];

    for (final off in offerings) {
      final clashes = <ScheduleClash>[];
      for (final sOff in off.sessions) {
        final dayBase = baseByDay[sOff.dayIndex] ?? const [];
        for (final sBase in dayBase) {
          // If the base course is the exact same course being replaced, don't flag as clash
          if (normalizeCourseName(sBase.subject).toLowerCase() == cleanCourse) {
            continue;
          }
          if (sessionsOverlap(sOff, sBase)) {
            clashes.add(
              ScheduleClash(
                courseA: off.courseName,
                batchA: off.batch,
                sessionA: sOff,
                courseB: sBase.subject,
                batchB: baseBatch,
                sessionB: sBase,
                dayIndex: sOff.dayIndex,
              ),
            );
          }
        }
      }

      result.add(
        AnalyzedOffering(
          offering: off,
          hasClash: clashes.isNotEmpty,
          clashes: clashes,
        ),
      );
    }

    // Sort: Clash-free first, then section/batch name
    result.sort((a, b) {
      if (a.hasClash != b.hasClash) {
        return a.hasClash ? 1 : -1;
      }
      return a.offering.batch.compareTo(b.offering.batch);
    });

    _cachedAnalyzedOfferings[cacheKey] = result;
    return result;
  }

  /// Asynchronously analyzes offerings with thread safety, ensuring zero UI jank
  static Future<List<AnalyzedOffering>> analyzeOfferingsAsync({
    required UniversityMemory memory,
    required String courseName,
    required String baseBatch,
  }) async {
    final cleanBatch = baseBatch.trim().toUpperCase();
    final cleanCourse = normalizeCourseName(courseName).toLowerCase();
    final cacheKey = '$cleanBatch|$cleanCourse';
    final cached = _cachedAnalyzedOfferings[cacheKey];
    if (cached != null) return cached;

    // Fast indexed analytical computation
    return analyzeOfferingsForCourse(
      memory: memory,
      courseName: courseName,
      baseBatch: baseBatch,
    );
  }

  /// Combines student's normal base batch sessions with selected repeater offerings
  static List<ClassSession> buildCombinedSchedule({
    required UniversityMemory memory,
    required String baseBatch,
    required List<String> repeatCourses,
    required Map<String, CourseOffering> selectedOfferings,
  }) {
    final baseSessions = getBaseBatchSessions(memory, baseBatch);
    final repeatNormSet = repeatCourses
        .map((c) => normalizeCourseName(c).toLowerCase())
        .toSet();

    final combined = <ClassSession>[];
    // Keep all normal courses except any that are being repeated with a chosen section
    for (final s in baseSessions) {
      final norm = normalizeCourseName(s.subject).toLowerCase();
      if (!repeatNormSet.contains(norm)) {
        combined.add(s);
      }
    }

    // Add all sessions of the selected repeater offerings
    for (final off in selectedOfferings.values) {
      combined.addAll(off.sessions);
    }

    // Sort chronologically
    combined.sort((a, b) {
      final d = a.dayIndex.compareTo(b.dayIndex);
      if (d != 0) return d;
      return a.safeStartVal.compareTo(b.safeStartVal);
    });

    return combined;
  }

  /// Extracts all distinct course names offered across the university timetable.
  static List<String> extractUniqueCourses(UniversityMemory memory) {
    if (_cachedUniqueCourses != null) return _cachedUniqueCourses!;
    final courseCounts = <String, int>{};
    for (final s in memory.sessions) {
      if (s.isBreak) continue;
      final name = normalizeCourseName(s.subject);
      if (name.length < 3) continue;
      courseCounts[name] = (courseCounts[name] ?? 0) + 1;
    }

    final courses = courseCounts.keys.toList();
    courses.sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    _cachedUniqueCourses = courses;
    return courses;
  }

  /// Extracts all courses taught for a specific batch, returning a map of courseName -> CourseOffering.
  static Map<String, CourseOffering> getCoursesForBatch(
    UniversityMemory memory,
    String batch,
  ) {
    final cleanB = batch.trim().toUpperCase();
    final cached = _cachedBatchCourses[cleanB];
    if (cached != null) return cached;

    final batchSessions = memory.sessions
        .where((s) => !s.isBreak && s.batchKey.batch.toUpperCase().trim() == cleanB)
        .toList();

    final courseSessions = <String, List<ClassSession>>{};
    for (final s in batchSessions) {
      final name = normalizeCourseName(s.subject);
      if (name.length < 3) continue;
      courseSessions.putIfAbsent(name, () => []).add(s);
    }

    final result = <String, CourseOffering>{};
    for (final entry in courseSessions.entries) {
      final cName = entry.key;
      final sessList = entry.value;

      String primaryTeacher = '';
      String primaryRoom = '';
      for (final s in sessList) {
        if (s.teacher.isNotEmpty && primaryTeacher.isEmpty && s.teacher.toLowerCase() != 'unknown') {
          primaryTeacher = FormatGuard.formatTeacherName(s.teacher);
        }
        if (s.room.isNotEmpty && primaryRoom.isEmpty) {
          primaryRoom = s.room;
        }
      }
      if (primaryTeacher.isEmpty) primaryTeacher = 'Staff Instructor';
      if (primaryRoom.isEmpty) primaryRoom = 'TBA';

      result[cName] = CourseOffering(
        courseName: cName,
        batch: batch,
        teacher: primaryTeacher,
        room: primaryRoom,
        sessions: sessList..sort((a, b) {
          final d = a.dayIndex.compareTo(b.dayIndex);
          if (d != 0) return d;
          return a.safeStartVal.compareTo(b.safeStartVal);
        }),
      );
    }
    _cachedBatchCourses[cleanB] = result;
    return result;
  }

  /// Finds all batch offerings for a given course name.
  static List<CourseOffering> getOfferingsForCourse(
    UniversityMemory memory,
    String targetCourseName,
  ) {
    final cleanTarget = normalizeCourseName(targetCourseName).toLowerCase();
    final cached = _cachedCourseOfferings[cleanTarget];
    if (cached != null) return cached;

    final batchSessionsMap = <String, List<ClassSession>>{};

    for (final s in memory.sessions) {
      if (s.isBreak) continue;
      final cleanSub = normalizeCourseName(s.subject).toLowerCase();
      if (cleanSub == cleanTarget ||
          cleanSub.contains(cleanTarget) ||
          cleanTarget.contains(cleanSub)) {
        final b = s.batchKey.batch.trim();
        if (b.isEmpty) continue;
        batchSessionsMap.putIfAbsent(b, () => []).add(s);
      }
    }

    final offerings = <CourseOffering>[];
    for (final entry in batchSessionsMap.entries) {
      final b = entry.key;
      final sessList = entry.value;

      // Deduce primary instructor and room
      String primaryTeacher = '';
      String primaryRoom = '';
      for (final s in sessList) {
        if (s.teacher.isNotEmpty && primaryTeacher.isEmpty && s.teacher.toLowerCase() != 'unknown') {
          primaryTeacher = FormatGuard.formatTeacherName(s.teacher);
        }
        if (s.room.isNotEmpty && primaryRoom.isEmpty) {
          primaryRoom = s.room;
        }
      }
      if (primaryTeacher.isEmpty) primaryTeacher = 'Staff Instructor';
      if (primaryRoom.isEmpty) primaryRoom = 'TBA';

      offerings.add(
        CourseOffering(
          courseName: targetCourseName,
          batch: b,
          teacher: primaryTeacher,
          room: primaryRoom,
          sessions: sessList..sort((a, b) {
            final dayCmp = a.dayIndex.compareTo(b.dayIndex);
            if (dayCmp != 0) return dayCmp;
            return a.safeStartVal.compareTo(b.safeStartVal);
          }),
        ),
      );
    }

    offerings.sort((a, b) => a.batch.compareTo(b.batch));
    _cachedCourseOfferings[cleanTarget] = offerings;
    return offerings;
  }

  /// Detects all time overlaps/clashes between the selected course offerings.
  static List<ScheduleClash> detectClashes(List<CourseOffering> chosenOfferings) {
    final clashes = <ScheduleClash>[];
    if (chosenOfferings.length < 2) return clashes;

    for (int i = 0; i < chosenOfferings.length; i++) {
      for (int j = i + 1; j < chosenOfferings.length; j++) {
        final offA = chosenOfferings[i];
        final offB = chosenOfferings[j];

        for (final sA in offA.sessions) {
          for (final sB in offB.sessions) {
            if (sessionsOverlap(sA, sB)) {
              clashes.add(
                ScheduleClash(
                  courseA: offA.courseName,
                  batchA: offA.batch,
                  sessionA: sA,
                  courseB: offB.courseName,
                  batchB: offB.batch,
                  sessionB: sB,
                  dayIndex: sA.dayIndex,
                ),
              );
            }
          }
        }
      }
    }

    return clashes;
  }

  /// Checks if two class sessions overlap in time on the same day.
  static bool sessionsOverlap(ClassSession a, ClassSession b) {
    if (a.dayIndex != b.dayIndex) return false;
    // Two intervals [startA, endA) and [startB, endB) overlap iff startA < endB && startB < endA
    final startA = a.safeStartVal;
    final endA = a.actualEndVal;
    final startB = b.safeStartVal;
    final endB = b.actualEndVal;
    return startA < endB && startB < endA;
  }
}

