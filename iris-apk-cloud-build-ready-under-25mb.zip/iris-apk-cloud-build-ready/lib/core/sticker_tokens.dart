import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Design tokens for the Material 3 Expressive "Cozy Comic / Sticker Scrapbook" style.
///
/// Combines tactile papercraft aesthetics, pastel color-coding, crisp ink outlines,
/// and zero-blur hardware-accelerated cardboard drop shadows with 60-120 FPS performance.
class StickerTokens {
  // ---------------------------------------------------------------------------
  // 1. Pastel Container Palettes (Light Mode)
  // ---------------------------------------------------------------------------
  static const Color creamButter = Color(0xFFFFF8E7);
  static const Color lavenderPastel = Color(0xFFEDE9FE);
  static const Color skyBreeze = Color(0xFFE0F2FE);
  static const Color apricotPeach = Color(0xFFFFEDD5);
  static const Color blushRose = Color(0xFFFFE4E6);
  static const Color mintPastel = Color(0xFFDCFCE7);
  static const Color lemonYellow = Color(0xFFFEF9C3);
  static const Color slateTorn = Color(0xFF1E293B);

  // ---------------------------------------------------------------------------
  // 2. Blueprint / Midnight Chalkboard Palettes (Dark Mode)
  // ---------------------------------------------------------------------------
  static const Color darkCanvas = Color(0xFF0F1117);
  static const Color darkSurface = Color(0xFF181B22);
  static const Color darkCreamButter = Color(0xFF2A2318);
  static const Color darkLavender = Color(0xFF241C30);
  static const Color darkSky = Color(0xFF162434);
  static const Color darkApricot = Color(0xFF2E1E16);
  static const Color darkBlush = Color(0xFF2E1720);
  static const Color darkMint = Color(0xFF142C20);
  static const Color darkLemon = Color(0xFF292614);

  // Surface Defaults
  static const Color surfaceLight = creamButter;
  static const Color darkCardSurface = darkSurface;
  static Color cardSurface(bool isDark) => isDark ? darkCardSurface : surfaceLight;

  // ---------------------------------------------------------------------------
  // 3. Stroke & Outline Tokens
  // ---------------------------------------------------------------------------
  static const double strokeWidth = 1.85;
  static const double cardRadius = 24.0;
  static const double pillRadius = 999.0;

  static const Color inkOutlineLight = Color(0xFF2C221A);
  static const Color chalkOutlineDark = Color(0xFF475266);

  static Color inkOutline(bool isDark) =>
      isDark ? chalkOutlineDark : inkOutlineLight;

  // ---------------------------------------------------------------------------
  // 4. Physical Cardboard Drop Shadows (0 Blur = Locked 120 FPS on GPU)
  // ---------------------------------------------------------------------------
  static List<BoxShadow> stickerShadow(bool isDark, {double offset = 3.0, Color? customColor}) {
    final shadowColor = customColor ??
        (isDark ? const Color(0x99000000) : const Color(0x3B2C221A));
    return [
      // 1. Tactile ambient depth blur shadow (physical paper lift off page)
      BoxShadow(
        color: shadowColor.withValues(alpha: isDark ? 0.35 : 0.16),
        offset: Offset(0.8, offset + 1.2),
        blurRadius: 3.5,
      ),
      // 2. Crisp cardboard contact cast shadow
      BoxShadow(
        color: shadowColor,
        offset: Offset(1.5, offset),
        blurRadius: 0.0,
      ),
    ];
  }

  // ---------------------------------------------------------------------------
  // 5. Dynamic Container Color Resolvers
  // ---------------------------------------------------------------------------
  static Color containerColor({
    required bool isDark,
    required Color lightColor,
    required Color darkColor,
  }) => isDark ? darkColor : lightColor;

  static Color butter(bool isDark) => containerColor(
        isDark: isDark,
        lightColor: creamButter,
        darkColor: darkCreamButter,
      );

  static Color lavender(bool isDark) => containerColor(
        isDark: isDark,
        lightColor: lavenderPastel,
        darkColor: darkLavender,
      );

  static Color sky(bool isDark) => containerColor(
        isDark: isDark,
        lightColor: skyBreeze,
        darkColor: darkSky,
      );

  static Color peach(bool isDark) => containerColor(
        isDark: isDark,
        lightColor: apricotPeach,
        darkColor: darkApricot,
      );

  static Color rose(bool isDark) => containerColor(
        isDark: isDark,
        lightColor: blushRose,
        darkColor: darkBlush,
      );

  static Color mint(bool isDark) => containerColor(
        isDark: isDark,
        lightColor: mintPastel,
        darkColor: darkMint,
      );

  static Color yellow(bool isDark) => containerColor(
        isDark: isDark,
        lightColor: lemonYellow,
        darkColor: darkLemon,
      );

  // ---------------------------------------------------------------------------
  // 6. Expressive Typography Styles
  // ---------------------------------------------------------------------------
  static TextStyle displayTitle({
    required bool isDark,
    double fontSize = 26.0,
    FontWeight fontWeight = FontWeight.w900,
  }) {
    return GoogleFonts.poppins(
      fontSize: fontSize,
      fontWeight: fontWeight,
      letterSpacing: -0.4,
      color: isDark ? const Color(0xFFF1F5F9) : const Color(0xFF2C221A),
      height: 1.18,
    );
  }

  static TextStyle bodyText({
    required bool isDark,
    double fontSize = 13.0,
    FontWeight fontWeight = FontWeight.w600,
    Color? color,
  }) {
    return GoogleFonts.poppins(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color ?? (isDark ? const Color(0xFFCBD5E1) : const Color(0xFF473A30)),
      height: 1.35,
    );
  }

  /// Hand-sketched annotation typography (script / doodle style)
  static TextStyle scriptAnnotation({
    required bool isDark,
    double fontSize = 13.0,
    FontWeight fontWeight = FontWeight.w700,
    Color? color,
  }) {
    return GoogleFonts.caveat(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color ?? (isDark ? const Color(0xFFFCD34D) : const Color(0xFF2C221A)),
      letterSpacing: 0.2,
    );
  }
}
