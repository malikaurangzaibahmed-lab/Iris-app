import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'tokens.dart';
import 'theme_signals.dart';
import 'almanac_theme_tokens.dart';
import 'editorial_theme_tokens.dart';
import 'notebook_theme_tokens.dart';
import 'line_theme_tokens.dart';
import 'poster_theme_tokens.dart';
import 'material_you_theme.dart';
import 'minimal_theme.dart';
import 'vital_theme.dart';

class IrisTheme {
  static final Map<String, ThemeData> _themeCache = {};
  static bool _fontsPrewarmed = false;

  /// Prewarms all 7 theme Google Fonts at startup so switching themes never
  /// triggers Flash-of-Unstyled-Text (FOUT) or layout jitter.
  static void prewarmFonts() {
    if (_fontsPrewarmed) return;
    _fontsPrewarmed = true;
    try {
      GoogleFonts.inter();
      GoogleFonts.plusJakartaSans();
      GoogleFonts.playfairDisplay();
      GoogleFonts.sourceSerif4();
      GoogleFonts.spaceMono();
      GoogleFonts.fraunces();
      GoogleFonts.kalam();
      GoogleFonts.patrickHand();
      GoogleFonts.archivoBlack();
    } catch (_) {}
  }

  /// Builds an authentic, signature ThemeData for any of the 7 IRIS themes!
  /// Cached by (style, brightness, seedColor, useMinimal, useVital) for 0ms lookup.
  static ThemeData buildForStyle({
    required IrisThemeStyle style,
    required Brightness brightness,
    Color seedColor = const Color(0xFF0061A4),
    bool useMinimal = false,
    bool useVital = false,
  }) {
    final cacheKey = '${style.name}_${brightness.name}_${seedColor.toARGB32()}_${useMinimal}_$useVital';
    final cached = _themeCache[cacheKey];
    if (cached != null) return cached;

    final built = _buildForStyleUncached(
      style: style,
      brightness: brightness,
      seedColor: seedColor,
      useMinimal: useMinimal,
      useVital: useVital,
    );
    _themeCache[cacheKey] = built;
    return built;
  }

  static ThemeData _buildForStyleUncached({
    required IrisThemeStyle style,
    required Brightness brightness,
    Color seedColor = const Color(0xFF0061A4),
    bool useMinimal = false,
    bool useVital = false,
  }) {
    final isDark = brightness == Brightness.dark;

    switch (style) {
      case IrisThemeStyle.materialYou:
        return MaterialYouTheme.buildTheme(
          brightness: brightness,
          seedColor: seedColor,
        );

      case IrisThemeStyle.almanac:
        final canvas = AlmanacTokens.canvas(isDark);
        final surface = AlmanacTokens.cardSurface(isDark);
        final primary = AlmanacTokens.accentTerracotta(isDark);
        final inkHeading = AlmanacTokens.inkHeading(isDark);
        final inkBody = AlmanacTokens.inkBody(isDark);
        final inkRule = AlmanacTokens.inkRule(isDark);
        final baseText = ThemeData(brightness: brightness).textTheme;
        return ThemeData(
          useMaterial3: true,
          brightness: brightness,
          scaffoldBackgroundColor: canvas,
          colorScheme: ColorScheme.fromSeed(
            seedColor: primary,
            brightness: brightness,
            primary: primary,
            onPrimary: Colors.white,
            secondary: const Color(0xFF4A6B5B),
            surface: surface,
            onSurface: inkHeading,
            onSurfaceVariant: AlmanacTokens.inkMuted(isDark),
            outline: inkRule,
            outlineVariant: AlmanacTokens.inkRuleSubtle(isDark),
          ),
          fontFamily: GoogleFonts.playfairDisplay().fontFamily,
          textTheme: GoogleFonts.playfairDisplayTextTheme(baseText).apply(
            bodyColor: inkBody,
            displayColor: inkHeading,
          ),
          dividerTheme: DividerThemeData(color: inkRule, thickness: 1.0),
          cardTheme: CardThemeData(
            elevation: 0,
            color: surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.zero,
              side: BorderSide(color: inkRule, width: 1.0),
            ),
          ),
          appBarTheme: AppBarTheme(
            elevation: 0,
            scrolledUnderElevation: 0,
            backgroundColor: canvas,
            foregroundColor: inkHeading,
            titleTextStyle: AlmanacTokens.serifHeadline(isDark, fontSize: 19),
          ),
        );

      case IrisThemeStyle.editorialAcademic:
        final canvas = EditorialTokens.canvas(isDark);
        final surface = EditorialTokens.cardSurface(isDark);
        final primary = EditorialTokens.accentUpcoming;
        final inkHeading = EditorialTokens.inkHeading(isDark);
        final inkBody = EditorialTokens.inkBody(isDark);
        final border = EditorialTokens.cardBorder(isDark);
        final baseText = ThemeData(brightness: brightness).textTheme;
        return ThemeData(
          useMaterial3: true,
          brightness: brightness,
          scaffoldBackgroundColor: canvas,
          colorScheme: ColorScheme.fromSeed(
            seedColor: primary,
            brightness: brightness,
            primary: primary,
            onPrimary: const Color(0xFF1E1B18),
            secondary: EditorialTokens.accentLab,
            tertiary: EditorialTokens.accentLive,
            surface: surface,
            onSurface: inkHeading,
            onSurfaceVariant: EditorialTokens.inkMuted(isDark),
            outline: border,
            outlineVariant: border.withValues(alpha: 0.65),
          ),
          fontFamily: GoogleFonts.plusJakartaSans().fontFamily,
          textTheme: GoogleFonts.plusJakartaSansTextTheme(baseText).apply(
            bodyColor: inkBody,
            displayColor: inkHeading,
          ),
          dividerTheme: DividerThemeData(color: border, thickness: 1.0),
          cardTheme: CardThemeData(
            elevation: 0,
            color: surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(22),
              side: BorderSide(color: border, width: 1.0),
            ),
          ),
          appBarTheme: AppBarTheme(
            elevation: 0,
            scrolledUnderElevation: 0,
            backgroundColor: canvas,
            foregroundColor: inkHeading,
            titleTextStyle: EditorialTokens.headingSerif(isDark, fontSize: 19),
          ),
        );

      case IrisThemeStyle.notebook:
        final canvas = NotebookTokens.canvas(isDark);
        final surface = NotebookTokens.cardSurface(isDark);
        final primary = NotebookTokens.redDoodle(isDark);
        final inkHeading = NotebookTokens.inkHeading(isDark);
        final inkBody = NotebookTokens.inkBody(isDark);
        final gridBorder = NotebookTokens.gridLine(isDark);
        final baseText = ThemeData(brightness: brightness).textTheme;
        return ThemeData(
          useMaterial3: true,
          brightness: brightness,
          scaffoldBackgroundColor: canvas,
          colorScheme: ColorScheme.fromSeed(
            seedColor: primary,
            brightness: brightness,
            primary: primary,
            onPrimary: Colors.white,
            secondary: const Color(0xFF2563EB),
            tertiary: NotebookTokens.stickyNote(isDark),
            surface: surface,
            onSurface: inkHeading,
            onSurfaceVariant: NotebookTokens.inkMuted(isDark),
            outline: gridBorder,
            outlineVariant: gridBorder,
          ),
          fontFamily: GoogleFonts.patrickHand().fontFamily,
          textTheme: GoogleFonts.patrickHandTextTheme(baseText).apply(
            bodyColor: inkBody,
            displayColor: inkHeading,
          ),
          dividerTheme: DividerThemeData(color: gridBorder, thickness: 1.0),
          cardTheme: CardThemeData(
            elevation: 0,
            color: surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
              side: BorderSide(color: gridBorder, width: 1.1),
            ),
          ),
          appBarTheme: AppBarTheme(
            elevation: 0,
            scrolledUnderElevation: 0,
            backgroundColor: canvas,
            foregroundColor: inkHeading,
            titleTextStyle: NotebookTokens.boldScript(isDark, fontSize: 20),
          ),
        );

      case IrisThemeStyle.line:
        final canvas = LineTokens.canvas(isDark);
        final surface = LineTokens.cardSurface(isDark);
        final primary = LineTokens.railLine(isDark);
        final inkHeading = LineTokens.inkHeading(isDark);
        final inkBody = LineTokens.inkBody(isDark);
        final baseText = ThemeData(brightness: brightness).textTheme;
        return ThemeData(
          useMaterial3: true,
          brightness: brightness,
          scaffoldBackgroundColor: canvas,
          colorScheme: ColorScheme.fromSeed(
            seedColor: primary,
            brightness: brightness,
            primary: primary,
            onPrimary: isDark ? Colors.black : Colors.white,
            secondary: LineTokens.subwayCobalt,
            tertiary: LineTokens.subwayGreen,
            surface: surface,
            onSurface: inkHeading,
            onSurfaceVariant: LineTokens.inkMuted(isDark),
            outline: primary,
            outlineVariant: isDark ? const Color(0xFF28303C) : const Color(0xFFD6D1C4),
          ),
          fontFamily: GoogleFonts.plusJakartaSans().fontFamily,
          textTheme: GoogleFonts.plusJakartaSansTextTheme(baseText).apply(
            bodyColor: inkBody,
            displayColor: inkHeading,
          ),
          dividerTheme: DividerThemeData(color: primary.withValues(alpha: 0.35), thickness: 1.2),
          cardTheme: CardThemeData(
            elevation: 0,
            color: surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: primary, width: 1.4),
            ),
          ),
          appBarTheme: AppBarTheme(
            elevation: 0,
            scrolledUnderElevation: 0,
            backgroundColor: canvas,
            foregroundColor: inkHeading,
            titleTextStyle: LineTokens.stationName(isDark).copyWith(fontSize: 18),
          ),
        );

      case IrisThemeStyle.poster:
        final canvas = PosterTokens.canvas(isDark);
        final surface = PosterTokens.cardSurface(isDark);
        const primary = PosterTokens.orangeHero;
        final inkHeading = PosterTokens.inkHeading(isDark);
        final inkBody = PosterTokens.inkBody(isDark);
        final inkBorder = PosterTokens.inkBorder(isDark);
        final baseText = ThemeData(brightness: brightness).textTheme;
        return ThemeData(
          useMaterial3: true,
          brightness: brightness,
          scaffoldBackgroundColor: canvas,
          colorScheme: ColorScheme.fromSeed(
            seedColor: primary,
            brightness: brightness,
            primary: primary,
            onPrimary: Colors.black,
            secondary: inkHeading,
            surface: surface,
            onSurface: inkHeading,
            onSurfaceVariant: PosterTokens.inkMuted(isDark),
            outline: inkBorder,
            outlineVariant: PosterTokens.inkBorderSubtle(isDark),
          ),
          fontFamily: GoogleFonts.plusJakartaSans().fontFamily,
          textTheme: GoogleFonts.plusJakartaSansTextTheme(baseText).copyWith(
            displayLarge: GoogleFonts.archivoBlack(fontSize: 44, height: 1.0, letterSpacing: -1.5, color: inkHeading),
            displayMedium: GoogleFonts.archivoBlack(fontSize: 34, height: 1.05, letterSpacing: -1.0, color: inkHeading),
            displaySmall: GoogleFonts.archivoBlack(fontSize: 26, height: 1.1, letterSpacing: -0.6, color: inkHeading),
            headlineLarge: GoogleFonts.archivoBlack(fontSize: 22, height: 1.15, letterSpacing: -0.4, color: inkHeading),
            headlineMedium: GoogleFonts.archivoBlack(fontSize: 18, height: 1.18, letterSpacing: -0.3, color: inkHeading),
            headlineSmall: GoogleFonts.archivoBlack(fontSize: 16, height: 1.2, letterSpacing: -0.2, color: inkHeading),
            titleLarge: GoogleFonts.archivoBlack(fontSize: 16, height: 1.22, letterSpacing: -0.2, color: inkHeading),
            titleMedium: GoogleFonts.plusJakartaSans(fontSize: 15, fontWeight: FontWeight.w800, height: 1.3, color: inkHeading),
            titleSmall: GoogleFonts.spaceMono(fontSize: 12.5, fontWeight: FontWeight.w700, height: 1.3, color: inkHeading),
            bodyLarge: GoogleFonts.plusJakartaSans(fontSize: 14.5, fontWeight: FontWeight.w600, height: 1.4, color: inkBody),
            bodyMedium: GoogleFonts.plusJakartaSans(fontSize: 13.5, fontWeight: FontWeight.w600, height: 1.4, color: inkBody),
            bodySmall: GoogleFonts.spaceMono(fontSize: 11.5, fontWeight: FontWeight.w600, height: 1.35, color: PosterTokens.inkMuted(isDark)),
            labelLarge: GoogleFonts.spaceMono(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.6, color: inkHeading),
            labelMedium: GoogleFonts.spaceMono(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 0.5, color: inkBody),
            labelSmall: GoogleFonts.spaceMono(fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 0.6, color: PosterTokens.inkMuted(isDark)),
          ),
          dividerTheme: DividerThemeData(color: inkBorder, thickness: 2.0),
          cardTheme: CardThemeData(
            elevation: 0,
            color: surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.zero,
              side: BorderSide(color: inkBorder, width: 2.2),
            ),
          ),
          appBarTheme: AppBarTheme(
            elevation: 0,
            scrolledUnderElevation: 0,
            backgroundColor: canvas,
            foregroundColor: inkHeading,
            titleTextStyle: PosterTokens.classTitle(isDark).copyWith(fontSize: 18),
          ),
        );

      case IrisThemeStyle.fluidGlass:
        if (useMinimal) {
          return buildMinimalTheme(brightness: brightness);
        }
        if (useVital) {
          return buildVitalTheme(brightness: brightness);
        }
        return _base(brightness);
    }
  }

  static ThemeData _base(Brightness brightness) {
    final isDark = brightness == Brightness.dark;
    final primaryColor = IrisTokens.brand;
    final baseTextTheme = ThemeData(brightness: brightness).textTheme;

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryColor,
        brightness: brightness,
        surface: isDark ? IrisTokens.surfaceDark : IrisTokens.surfaceLight,
      ),
      scaffoldBackgroundColor: isDark ? IrisTokens.surfaceDark : IrisTokens.surfaceLight,
      fontFamily: IrisTokens.fontFamily,
      textTheme: GoogleFonts.interTextTheme(baseTextTheme),
      pageTransitionsTheme: IrisTokens.pageTransitions,
      visualDensity: VisualDensity.adaptivePlatformDensity,
      cardTheme: CardThemeData(
        elevation: 0,
        shape: const ContinuousRectangleBorder(
          borderRadius: IrisTokens.cardRadius,
        ),
        color: isDark ? IrisTokens.surfaceDarkElevated : IrisTokens.surfaceLightElevated,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          elevation: 0,
          backgroundColor: primaryColor,
          foregroundColor: Colors.white,
          minimumSize: const Size(88, 48),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          textStyle: const TextStyle(
            fontWeight: FontWeight.w600,
            letterSpacing: 0.2,
          ),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          elevation: 0,
          backgroundColor: primaryColor,
          foregroundColor: Colors.white,
          minimumSize: const Size(88, 48),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(88, 48),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
        ),
      ),
      appBarTheme: AppBarTheme(
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        backgroundColor: Colors.transparent,
        foregroundColor: isDark ? Colors.white : Colors.black,
        titleTextStyle: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.5,
          color: isDark ? Colors.white : Colors.black,
        ),
      ),
    );
  }

  static ThemeData light() => _base(Brightness.light);
  static ThemeData dark() => _base(Brightness.dark);
}
