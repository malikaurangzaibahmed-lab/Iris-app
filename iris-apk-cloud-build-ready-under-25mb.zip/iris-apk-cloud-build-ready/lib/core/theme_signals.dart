import 'package:flutter/material.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import 'package:shared_preferences/shared_preferences.dart';

import 'glass.dart';
import 'tokens.dart';
import 'material_you_theme.dart';
import 'editorial_theme_tokens.dart';
import 'almanac_theme_tokens.dart';
import 'notebook_theme_tokens.dart';
import 'line_theme_tokens.dart';
import 'poster_theme_tokens.dart';
import 'package:iris/widgets/cards/vital_card.dart';

/// Supported visual styles in IRIS:
/// - [fluidGlass]: Signature liquid glass, optical refraction, specular reflections, and ambient auroras.
/// - [materialYou]: Android 14/15 Material 3 Monet design system with solid tonal surface containers, 120 FPS flat rasterization, and zero blurs.
/// - [almanac]: Theme 4 classical newspaper broadside with double horizontal hairline rules, Scotch Roman typography, and 3-column timetable.
enum IrisThemeStyle {
  fluidGlass,
  materialYou,
  almanac,
  editorialAcademic,
  notebook,
  line,
  poster,
}

/// Discrete operational glass presets for liquid theme.
enum IrisGlassLevel {
  opaque(0.0, 'Opaque Glass', 'Solid surface, zero blur & maximum contrast'),
  medium(0.5, 'Medium Glass', 'Balanced frosted refraction & clean readability'),
  maximum(1.0, 'Maximum Glass', 'Translucent luminous glass & deep refraction');

  final double value;
  final String label;
  final String description;

  const IrisGlassLevel(this.value, this.label, this.description);

  static IrisGlassLevel fromValue(double v) {
    if (v <= 0.25) return IrisGlassLevel.opaque;
    if (v >= 0.75) return IrisGlassLevel.maximum;
    return IrisGlassLevel.medium;
  }
}

/// Global signals used to toggle visual languages and themes at runtime.
class ThemeSignals {
  /// Active visual theme style. Default to Material You (M3 Expressive) for ultra-fluid startup.
  static final ValueNotifier<IrisThemeStyle> themeStyle =
      ValueNotifier<IrisThemeStyle>(IrisThemeStyle.materialYou);

  static bool get isMaterialYou => themeStyle.value == IrisThemeStyle.materialYou;
  static bool get isFluidGlass => themeStyle.value == IrisThemeStyle.fluidGlass;
  static bool get isAlmanac => themeStyle.value == IrisThemeStyle.almanac;
  static bool get isEditorialAcademic => themeStyle.value == IrisThemeStyle.editorialAcademic;
  static bool get isEditorial => isEditorialAcademic;
  static bool get isNotebook => themeStyle.value == IrisThemeStyle.notebook;
  static bool get isLine => themeStyle.value == IrisThemeStyle.line;
  static bool get isPoster => themeStyle.value == IrisThemeStyle.poster;

  /// Legacy flags maintained for backward compatibility.
  /// [useVitalTheme] defaults to false so [IrisThemeStyle.fluidGlass] renders genuine
  /// refractive Liquid Glass surfaces rather than opaque VitalCard containers.
  static final ValueNotifier<bool> useMinimalTheme = ValueNotifier<bool>(false);
  static final ValueNotifier<bool> useVitalTheme = ValueNotifier<bool>(false);

  /// Default Material Expressive Seed Color (Iris Monet Blue).
  static const Color defaultM3ESeedColor = Color(0xFF0061A4);

  /// Active Material Expressive Seed Color signal.
  static final ValueNotifier<Color> m3eSeedColor =
      ValueNotifier<Color>(defaultM3ESeedColor);

  /// Change and persist active seed color for Material Expressive theme.
  static Future<void> setSeedColor(Color color) async {
    m3eSeedColor.value = color;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('app_m3e_seed_color', color.toARGB32());
    } catch (_) {}
  }

  /// Global glass transparency modifier for liquid themes (0.0 to 1.0)
  static final ValueNotifier<double> glassTransparency = ValueNotifier<double>(1.0);

  /// Change and persist glass transparency.
  static Future<void> setGlassTransparency(double value) async {
    final clamped = value.clamp(0.0, 1.0);
    glassTransparency.value = clamped;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble('app_glass_transparency', clamped);
    } catch (_) {}
  }

  /// Change glass level using discrete presets (Opaque, Medium, Maximum).
  static Future<void> setGlassLevel(IrisGlassLevel level) async {
    await setGlassTransparency(level.value);
  }

  /// Current active glass level.
  static IrisGlassLevel get activeGlassLevel =>
      IrisGlassLevel.fromValue(glassTransparency.value);

  /// Change and persist active theme style.
  static Future<void> setThemeStyle(IrisThemeStyle style) async {
    if (themeStyle.value == style) return;
    themeStyle.value = style;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('app_theme_style', style.name);
    } catch (_) {}
  }

  /// Callback handler wired to global ThemeMorphController.
  static Future<void> Function({
    required IrisThemeStyle targetStyle,
    Rect? originRect,
    GlobalKey? originKey,
    BuildContext? context,
  })? morphTransitionHandler;

  /// Switch theme style with the authentic dual-theme container morphing animation.
  static Future<void> switchThemeWithMorph(
    BuildContext? context, {
    required IrisThemeStyle style,
    Rect? originRect,
    GlobalKey? originKey,
  }) async {
    if (morphTransitionHandler != null) {
      await morphTransitionHandler!(
        targetStyle: style,
        originRect: originRect,
        originKey: originKey,
        context: context,
      );
    } else {
      await setThemeStyle(style);
    }
  }

  /// Cycle through all 7 IRIS themes with optional container morph.
  static Future<void> toggleThemeStyle({
    BuildContext? context,
    Rect? originRect,
    GlobalKey? originKey,
  }) async {
    final IrisThemeStyle next;
    switch (themeStyle.value) {
      case IrisThemeStyle.materialYou:
        next = IrisThemeStyle.almanac;
        break;
      case IrisThemeStyle.almanac:
        next = IrisThemeStyle.editorialAcademic;
        break;
      case IrisThemeStyle.editorialAcademic:
        next = IrisThemeStyle.notebook;
        break;
      case IrisThemeStyle.notebook:
        next = IrisThemeStyle.line;
        break;
      case IrisThemeStyle.line:
        next = IrisThemeStyle.poster;
        break;
      case IrisThemeStyle.poster:
        next = IrisThemeStyle.fluidGlass;
        break;
      case IrisThemeStyle.fluidGlass:
        next = IrisThemeStyle.materialYou;
        break;
    }
    if (morphTransitionHandler != null) {
      await morphTransitionHandler!(
        targetStyle: next,
        originRect: originRect,
        originKey: originKey,
        context: context,
      );
    } else {
      await setThemeStyle(next);
    }
  }

  /// Initialize theme style and seed color from local storage.
  static Future<void> loadSavedThemeStyle() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString('app_theme_style');
      if (saved == IrisThemeStyle.materialYou.name) {
        themeStyle.value = IrisThemeStyle.materialYou;
      } else if (saved == IrisThemeStyle.almanac.name) {
        themeStyle.value = IrisThemeStyle.almanac;
      } else if (saved == IrisThemeStyle.editorialAcademic.name) {
        themeStyle.value = IrisThemeStyle.editorialAcademic;
      } else if (saved == IrisThemeStyle.notebook.name) {
        themeStyle.value = IrisThemeStyle.notebook;
      } else if (saved == IrisThemeStyle.line.name) {
        themeStyle.value = IrisThemeStyle.line;
      } else if (saved == IrisThemeStyle.poster.name) {
        themeStyle.value = IrisThemeStyle.poster;
      } else if (saved == IrisThemeStyle.fluidGlass.name) {
        themeStyle.value = IrisThemeStyle.fluidGlass;
      } else {
        themeStyle.value = IrisThemeStyle.materialYou;
      }

      final savedSeed = prefs.getInt('app_m3e_seed_color');
      if (savedSeed != null) {
        m3eSeedColor.value = Color(savedSeed);
      }

      final savedTransparency = prefs.getDouble('app_glass_transparency');
      if (savedTransparency != null) {
        glassTransparency.value = savedTransparency;
      }
    } catch (_) {}
  }
}

/// A polymorphic surface that renders authentic aesthetics for all 7 IRIS themes:
/// 1. Material You: Flat tonal M3 surface container with zero blur (120 FPS).
/// 2. Almanac: Newsprint surface with clean broadside hairline rules and zero blur.
/// 3. Editorial Academic: Warm parchment surface with subtle border and drop shadow.
/// 4. Notebook: Graph-paper stationery card with subtle ink rule.
/// 5. Line: Subway transit card with crisp rail outline.
/// 6. Poster: Monolithic Swiss brutalist block with hard 3D shadow.
/// 7. Fluid Glass: Genuine `liquid_glass_widgets` 1.14.2 `AdaptiveLiquidGlassLayer` with
///    superellipse geometry, specular rim reflections, and adaptive quality scaling.
class GlassSurface extends StatelessWidget {
  final lgw.LiquidGlassSettings settings;
  final double radius;
  final Widget child;
  final bool applyInLayer;
  final lgw.GlassQuality? quality;
  final BorderSide? borderSide;

  const GlassSurface({
    super.key,
    required this.settings,
    required this.radius,
    required this.child,
    this.applyInLayer = true,
    this.quality,
    this.borderSide,
  });

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, currentStyle, _) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final isCustomColor =
            settings.glassColor != Colors.transparent && settings.glassColor.a > 0;

        if (currentStyle == IrisThemeStyle.materialYou) {
          return Container(
            decoration: BoxDecoration(
              color: isCustomColor
                  ? settings.glassColor
                  : MaterialYouTheme.surfaceContainer(context),
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(
                color: MaterialYouTheme.borderStroke(context),
                width: 1.0,
              ),
            ),
            child: child,
          );
        }

        if (currentStyle == IrisThemeStyle.almanac) {
          return Container(
            decoration: BoxDecoration(
              color: isCustomColor
                  ? settings.glassColor
                  : AlmanacTokens.cardSurface(isDark),
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(
                color: AlmanacTokens.inkRuleSubtle(isDark),
                width: 1.0,
              ),
            ),
            child: child,
          );
        }

        if (currentStyle == IrisThemeStyle.editorialAcademic) {
          return Container(
            decoration: BoxDecoration(
              color: isCustomColor
                  ? settings.glassColor
                  : EditorialTokens.cardSurface(isDark),
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(
                color: EditorialTokens.cardBorder(isDark),
                width: 1.0,
              ),
              boxShadow: EditorialTokens.cardShadow(isDark),
            ),
            child: child,
          );
        }

        if (currentStyle == IrisThemeStyle.notebook) {
          return Container(
            decoration: BoxDecoration(
              color: isCustomColor
                  ? settings.glassColor
                  : NotebookTokens.cardSurface(isDark),
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(
                color: isDark ? const Color(0xFF2F453B) : const Color(0xFFE5E0D6),
                width: 1.0,
              ),
            ),
            child: child,
          );
        }

        if (currentStyle == IrisThemeStyle.line) {
          return Container(
            decoration: BoxDecoration(
              color: isCustomColor
                  ? settings.glassColor
                  : LineTokens.cardSurface(isDark),
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(
                color: LineTokens.railLine(isDark),
                width: 1.4,
              ),
            ),
            child: child,
          );
        }

        if (currentStyle == IrisThemeStyle.poster) {
          return Container(
            decoration: BoxDecoration(
              color: isCustomColor
                  ? settings.glassColor
                  : PosterTokens.cardSurface(isDark),
              border: Border.all(
                color: PosterTokens.inkBorder(isDark),
                width: 2.2,
              ),
              boxShadow: PosterTokens.extrudedBlockShadow(isDark, offset: 3.0),
            ),
            child: child,
          );
        }

        // Fluid Glass (IrisThemeStyle.fluidGlass) powered by liquid_glass_widgets 1.14.2
        return ValueListenableBuilder<double>(
          valueListenable: ThemeSignals.glassTransparency,
          builder: (context, transparency, _) {
            return ValueListenableBuilder<bool>(
              valueListenable: ThemeSignals.useMinimalTheme,
              builder: (context, useMinimal, _) {
                final isOpaque = transparency <= 0.08;
                if (useMinimal || isOpaque) {
                  return Container(
                    decoration: BoxDecoration(
                      color: isCustomColor
                          ? settings.glassColor.withValues(alpha: 0.98)
                          : (isDark
                              ? IrisTokens.surfaceDarkElevated
                              : Colors.white),
                      borderRadius: BorderRadius.circular(radius),
                      border: Border.all(
                        color: borderSide?.color ??
                            (isDark
                                ? const Color(0xFF1E2433)
                                : const Color(0xFFE2E8F0)),
                        width: borderSide?.width ?? 1.0,
                      ),
                    ),
                    child: child,
                  );
                }

                final resolvedQuality = quality ?? lgw.GlassQuality.premium;

                final effectiveSide = borderSide ??
                    BorderSide(
                      color: isDark
                          ? Colors.white.withValues(
                              alpha: 0.24 + (0.10 * transparency),
                            )
                          : Colors.white.withValues(
                              alpha: 0.84 + (0.14 * transparency),
                            ),
                      width: 1.2,
                    );

                // Luminous physical frosted glass body so cards never look transparent or flat
                final basePlatterColor = isCustomColor
                    ? settings.glassColor
                    : (isDark
                          ? const Color(0xFF1E293B).withValues(alpha: 0.66)
                          : Colors.white.withValues(alpha: 0.82));

                final frostedPlatter = DecoratedBox(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(radius),
                    color: basePlatterColor,
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: isDark
                          ? [
                              Colors.white.withValues(alpha: 0.14),
                              Colors.white.withValues(alpha: 0.05),
                              Colors.black.withValues(alpha: 0.12),
                            ]
                          : [
                              Colors.white.withValues(alpha: 0.92),
                              Colors.white.withValues(alpha: 0.76),
                              const Color(0xFFF1F5F9).withValues(alpha: 0.82),
                            ],
                      stops: const [0.0, 0.48, 1.0],
                    ),
                    border: Border.fromBorderSide(effectiveSide),
                  ),
                  child: child,
                );

                return ClipRRect(
                  borderRadius: BorderRadius.circular(radius),
                  child: lgw.AdaptiveLiquidGlassLayer(
                    settings: settings,
                    quality: resolvedQuality,
                    shape: IrisGlass.shape(radius, side: effectiveSide),
                    blendAmount: 0.0,
                    child: frostedPlatter,
                  ),
                );
              },
            );
          },
        );
      },
    );
  }
}
