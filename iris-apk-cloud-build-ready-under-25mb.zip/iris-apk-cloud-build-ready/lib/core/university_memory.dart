import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'models.dart';
import '../services/timetable_storage.dart';
import '../services/remote_config_service.dart';

/// Intelligent Memory Loader for IRIS.
/// - Automatically discovers and pulls the latest timetable and academic modes on first-time setup and app boot.
/// - Performs seamless offline caching with zero-friction fallback.
/// - Features Smart Batch Migration: automatically promotes returning students to their new active semester (e.g., FA25-BCS-2-C -> FA25-BCS-3-C) without data loss or layout breakage.
class UniversityMemoryLoader {
  static Future<UniversityMemory> loadFromAssets() async {
    String raw = '';
    bool loadedFromCache = false;
    int currentTimetableVersion = 0;
    
    try {
      final prefs = await SharedPreferences.getInstance();
      
      // 1. Cache Reset on App Upgrade: clear old cached timetable when build version bumps
      final lastRunVersion = prefs.getInt('last_run_version_code') ?? 0;
      const currentVersion = RemoteConfigService.CURRENT_VERSION_CODE;
      if (lastRunVersion != currentVersion) {
        debugPrint('ℹ️ App upgraded from build $lastRunVersion to $currentVersion. Resetting timetable cache.');
        await prefs.remove('ota_cached_timetable');
        await prefs.remove('ota_timetable_version');
        await prefs.setInt('last_run_version_code', currentVersion);
      }

      currentTimetableVersion = prefs.getInt('ota_timetable_version') ?? 0;
      final cachedTimetable = prefs.getString('ota_cached_timetable');

      // 2. High-speed Instant Load: Check local OTA cache first without network stalls
      if (cachedTimetable != null && cachedTimetable.isNotEmpty) {
        if (currentTimetableVersion > RemoteConfigService.BUNDLED_TIMETABLE_VERSION) {
          debugPrint('✅ Loading cached timetable from local OTA storage');
          raw = cachedTimetable;
          loadedFromCache = true;
        } else {
          debugPrint('📚 Local OTA cache older than or equal to bundled baseline (v${RemoteConfigService.BUNDLED_TIMETABLE_VERSION}). Using clean bundled asset.');
          await prefs.remove('ota_cached_timetable');
          await prefs.remove('ota_timetable_version');
        }
      }

      // 3. Unblocked Background Sync: query remote config asynchronously without stalling startup
      unawaited(_syncRemoteTimetableInBackground(prefs, currentTimetableVersion));
    } catch (e) {
      debugPrint('⚠️ Error checking cached timetable: $e');
    }
    
    List<dynamic> data = [];
    if (loadedFromCache) {
      try {
        data = await compute(_decodeTimetableJson, raw);
      } catch (e) {
        debugPrint('⚠️ Error parsing cached timetable: $e - falling back to assets');
        loadedFromCache = false;
      }
    }
    
    // 3. Fallback to bundled asset if no cache or parse failed
    if (!loadedFromCache || data.isEmpty) {
      debugPrint('📚 Loading timetable from assets');
      try {
        raw = await rootBundle.loadString('assets/timetable_seed.json');
        data = await compute(_decodeTimetableJson, raw);
      } catch (e) {
        debugPrint('❌ Critical error loading timetable assets: $e');
      }
    }
    
    var sessions = data
      .whereType<Map<String, dynamic>>()
      .map((item) => ClassSession.fromJson(item))
      .where((s) => !s.isBreak)
      .toList();

    // 4. Smart Auto-Promotion & Self-Healing Batch Sanitization
    try {
      final prefs = await SharedPreferences.getInstance();
      var userBatch = prefs.getString('user_batch')?.trim() ?? '';
      
      // Self-Healing: Check if userBatch is corrupted with JSON, html, scrap text, or CIIT/ prefix
      final isCorrupted = userBatch.contains('{') ||
          userBatch.contains('\n') ||
          userBatch.contains('courses') ||
          userBatch.contains('CIIT/') ||
          userBatch.length > 25;

      if (isCorrupted && sessions.isNotEmpty) {
        debugPrint('🛠️ Corrupted batch detected in storage: "$userBatch". Running self-healing repair...');
        final studentId = prefs.getString('student_id') ?? prefs.getString('student_registration_no') ?? '';
        final candidateStr = '$userBatch $studentId';
        final match = RegExp(r'(FA|SP)\d{2}-[A-Za-z0-9]+', caseSensitive: false).firstMatch(candidateStr);
        String? repaired;
        if (match != null) {
          final prefix = match.group(0)!.toUpperCase();
          for (final s in sessions) {
            if (s.batchKey.batch.toUpperCase().startsWith(prefix)) {
              repaired = s.batchKey.batch;
              break;
            }
          }
        }
        repaired ??= sessions.firstWhere((s) => s.batchKey.program == 'BCS', orElse: () => sessions.first).batchKey.batch;
        userBatch = repaired;
        await prefs.setString('user_batch', userBatch);
        await prefs.setString('student_batch', userBatch);
        await prefs.setString('selected_batch', userBatch);
        debugPrint('✅ Repaired student batch to: "$userBatch"');
      }

      if (userBatch.isNotEmpty && sessions.isNotEmpty) {
        final hasExactBatch = sessions.any(
          (s) => s.batchKey.batch.toUpperCase() == userBatch.toUpperCase(),
        );

        if (!hasExactBatch) {
          final oldKey = BatchKey.parse(userBatch);
          debugPrint('🔍 Student batch "$userBatch" not found in new timetable. Resolving promotion for ${oldKey.intake}-${oldKey.program}-${oldKey.section}...');

          // 1. Match exact intake + program + section (e.g. FA25 + BCS + C -> FA25-BCS-3-C)
          ClassSession? promotedMatch;
          for (final s in sessions) {
            if (s.batchKey.intake.toUpperCase() == oldKey.intake.toUpperCase() &&
                s.batchKey.program.toUpperCase() == oldKey.program.toUpperCase() &&
                s.batchKey.section.toUpperCase() == oldKey.section.toUpperCase()) {
              promotedMatch = s;
              break;
            }
          }

          // 2. If exact section isn't found, find any section of the same intake + program
          if (promotedMatch == null) {
            for (final s in sessions) {
              if (s.batchKey.intake.toUpperCase() == oldKey.intake.toUpperCase() &&
                  s.batchKey.program.toUpperCase() == oldKey.program.toUpperCase()) {
                promotedMatch = s;
                break;
              }
            }
          }

          // 3. Fallback: find any matching program
          if (promotedMatch == null && oldKey.program.isNotEmpty) {
            for (final s in sessions) {
              if (s.batchKey.program.toUpperCase() == oldKey.program.toUpperCase()) {
                promotedMatch = s;
                break;
              }
            }
          }

          if (promotedMatch != null) {
            final newBatch = promotedMatch.batchKey.batch;
            debugPrint('🎓 Smart Batch Migration: Successfully auto-promoted student from $userBatch to $newBatch!');
            await prefs.setString('user_batch', newBatch);
            await prefs.setString('student_batch', newBatch);
            await prefs.setString('selected_batch', newBatch);
            await prefs.setString('promoted_from_batch', userBatch);
          }
        }
      }
    } catch (e) {
      debugPrint('⚠️ Error in smart batch migration: $e');
    }

    // 5. Emergency asset fallback ONLY if sessions list is completely empty
    if (sessions.isEmpty) {
      debugPrint('⚠️ Sessions list is empty - loading emergency asset seed');
      try {
        raw = await rootBundle.loadString('assets/timetable_seed.json');
        data = await compute(_decodeTimetableJson, raw);
        sessions = data
          .whereType<Map<String, dynamic>>()
          .map((item) => ClassSession.fromJson(item))
          .where((s) => !s.isBreak)
          .toList();
      } catch (e) {
        debugPrint('❌ Emergency fallback error: $e');
      }
    }

    final merged = await TimetableStorage.mergeOverrides(sessions);
    return UniversityMemory(merged);
  }

  static Future<void> _syncRemoteTimetableInBackground(
    SharedPreferences prefs,
    int currentTimetableVersion,
  ) async {
    try {
      final doc = await FirebaseFirestore.instance
          .collection('config')
          .doc('global')
          .get()
          .timeout(const Duration(milliseconds: 4000));

      if (doc.exists) {
        final data = doc.data() ?? {};
        final remoteTimetableJson = data['active_timetable_json']?.toString() ?? '';
        final remoteTimetableVersion = (data['active_timetable_version'] as num?)?.toInt() ?? 0;

        // Sync remote active academic mode if present
        final remotePeriod =
            (data['academic_period'] ?? data['active_academic_period'])
                ?.toString();
        if (remotePeriod != null && remotePeriod.isNotEmpty) {
          await prefs.setString('active_academic_period', remotePeriod);
          await prefs.setString('cached_academic_period', remotePeriod);
          RemoteConfigService.activeAcademicPeriod.value = remotePeriod;
        }

        if (remoteTimetableJson.isNotEmpty && remoteTimetableJson != '[]') {
          final baselineVersion = currentTimetableVersion > RemoteConfigService.BUNDLED_TIMETABLE_VERSION
              ? currentTimetableVersion
              : RemoteConfigService.BUNDLED_TIMETABLE_VERSION;
          if (remoteTimetableVersion > baselineVersion) {
            debugPrint('🚀 Smart Sync: Found fresh timetable seed (v$remoteTimetableVersion) in background!');
            await prefs.setString('ota_cached_timetable', remoteTimetableJson);
            await prefs.setInt('ota_timetable_version', remoteTimetableVersion);
          }
        }
      }
    } catch (e) {
      debugPrint('ℹ️ Background remote timetable check: $e');
    }
  }
}

List<Map<String, dynamic>> _decodeTimetableJson(String raw) {
  final decoded = jsonDecode(raw);
  final list = <Map<String, dynamic>>[];
  if (decoded is List) {
    for (final item in decoded) {
      if (item is Map) {
        list.add(Map<String, dynamic>.from(item));
      }
    }
  } else if (decoded is Map && decoded['sessions'] is List) {
    for (final item in decoded['sessions']) {
      if (item is Map) {
        list.add(Map<String, dynamic>.from(item));
      }
    }
  }
  return list;
}
