import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tz;

import 'app.dart';
import 'core/theme_signals.dart';
import 'services/analytics_manager.dart';
import 'services/app_config.dart';
import 'services/memory_manager.dart';
import 'services/remote_config_service.dart';
import 'services/ui_feedback.dart';

export 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  ErrorHandler.setupErrorHandling();
  ImageCacheManager.optimizeImageCache();

  String initialThemeMode = 'system';
  bool initialUseMinimal = false;
  bool initialUseVital = false;

  // High-performance parallel initialization: run independent startup services concurrently
  try {
    await Future.wait([
      (() async {
        try {
          await Firebase.initializeApp();
        } catch (e) {
          debugPrint('Firebase init fallback: $e');
        }
      })(),
      (() async {
        try {
          await AppConfig().initialize();
          await RemoteConfigService.preWarmLocalCache();
        } catch (e) {
          debugPrint('AppConfig init error: $e');
        }
      })(),
      (() async {
        try {
          tz.initializeTimeZones();
        } catch (e) {
          debugPrint('Timezone init error: $e');
        }
      })(),
      (() async {
        try {
          await LiquidGlassWidgets.initialize(enablePerformanceMonitor: false);
        } catch (e) {
          debugPrint('LiquidGlassWidgets init error: $e');
        }
      })(),
      (() async {
        try {
          await IrisHaptics.init();
        } catch (e) {
          debugPrint('UI feedback init error: $e');
        }
      })(),
      (() async {
        try {
          final prefs = await SharedPreferences.getInstance();
          initialThemeMode = prefs.getString('theme_mode') ?? 'system';
          initialUseMinimal = prefs.getBool('use_minimal_ui') ?? false;
          initialUseVital = prefs.getBool('use_vital_theme') ?? false;
          ThemeSignals.useMinimalTheme.value = initialUseMinimal;
          ThemeSignals.useVitalTheme.value = initialUseVital;
          await ThemeSignals.loadSavedThemeStyle();
        } catch (e) {
          debugPrint('Prefs boot prewarm error: $e');
        }
      })(),
    ]);
  } catch (e) {
    debugPrint('Parallel boot error: $e');
  }

  // Defer background task binding slightly so UI boots with instant 120 FPS frame delivery
  FlutterForegroundTask.init(
    androidNotificationOptions: AndroidNotificationOptions(
      channelId: 'persistent_class_foreground_v2',
      channelName: 'IRIS Class Tracker',
      channelDescription: 'Shows your current and upcoming classes',
      channelImportance: NotificationChannelImportance.LOW,
      priority: NotificationPriority.LOW,
      enableVibration: false,
      playSound: false,
      showWhen: false,
      onlyAlertOnce: true,
    ),
    iosNotificationOptions: const IOSNotificationOptions(
      showNotification: false,
    ),
    foregroundTaskOptions: ForegroundTaskOptions(
      eventAction: ForegroundTaskEventAction.repeat(30000),
      autoRunOnBoot: true,
      autoRunOnMyPackageReplaced: true,
      allowWakeLock: true,
      allowWifiLock: true,
    ),
  );

  runApp(
    ErrorBoundary(
      child: LiquidGlassWidgets.wrap(
        brightnessResolver: Theme.maybeBrightnessOf,
        adaptiveQuality: false,
        child: IrisApp(
          initialThemeMode: initialThemeMode,
          initialUseMinimal: initialUseMinimal,
          initialUseVital: initialUseVital,
        ),
      ),
    ),
  );
}

