import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';

class StudioBlock {
  final String id;
  String type; // 'text', 'bullet', 'formula', 'note'
  TextEditingController controller;

  StudioBlock({
    required this.id,
    required this.type,
    required String initialContent,
  }) : controller = TextEditingController(text: initialContent);
}

class DraggableStudioImage {
  final String id;
  final PlatformFile file;
  Offset offset;
  double width;
  double height;

  DraggableStudioImage({
    required this.id,
    required this.file,
    this.offset = const Offset(20, 160),
    this.width = 180,
    this.height = 140,
  });
}
