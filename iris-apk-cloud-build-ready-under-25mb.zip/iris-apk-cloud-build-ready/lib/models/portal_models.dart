class DownloadRecord {
  final String filename;
  final String filePath;
  final String sourceUrl;
  final int savedAt;
  final String state;
  final String backend;
  final String downloadId;

  const DownloadRecord({
    required this.filename,
    required this.filePath,
    this.sourceUrl = '',
    required this.savedAt,
    this.state = 'completed',
    this.backend = 'native',
    this.downloadId = '',
  });

  factory DownloadRecord.fromJson(dynamic json) {
    if (json is String) {
      final fallbackName = json.split(RegExp(r'[\\/]')).last;
      return DownloadRecord(
        filename: fallbackName,
        filePath: json,
        sourceUrl: '',
        savedAt: DateTime.now().millisecondsSinceEpoch,
        state: 'completed',
        backend: 'legacy',
        downloadId: '',
      );
    }

    final data = (json is Map)
        ? Map<String, dynamic>.from(json)
        : <String, dynamic>{};
    final filePath = data['filePath']?.toString() ?? '';
    final filename =
        data['filename']?.toString() ?? filePath.split(RegExp(r'[\\/]')).last;
    return DownloadRecord(
      filename: filename.isEmpty ? 'download.bin' : filename,
      filePath: filePath,
      sourceUrl: data['sourceUrl']?.toString() ?? '',
      savedAt:
          (data['savedAt'] as num?)?.toInt() ??
          DateTime.now().millisecondsSinceEpoch,
      state: data['state']?.toString().isNotEmpty == true
          ? data['state'].toString()
          : 'completed',
      backend: data['backend']?.toString().isNotEmpty == true
          ? data['backend'].toString()
          : 'native',
      downloadId: data['downloadId']?.toString() ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
    'filename': filename,
    'filePath': filePath,
    'sourceUrl': sourceUrl,
    'savedAt': savedAt,
    'state': state,
    'backend': backend,
    'downloadId': downloadId,
  };

  String get displaySource {
    final uri = Uri.tryParse(sourceUrl);
    if (uri == null || uri.host.isEmpty) return 'Saved file';
    return uri.host;
  }

  String get prettySavedAt {
    final now = DateTime.now().millisecondsSinceEpoch;
    final diff = now - savedAt;
    if (diff < 60000) return 'Just now';
    final minutes = diff ~/ 60000;
    if (minutes < 60) return '$minutes min${minutes > 1 ? 's' : ''} ago';
    final hours = diff ~/ 3600000;
    if (hours < 24) return '$hours hour${hours > 1 ? 's' : ''} ago';
    final days = diff ~/ 86400000;
    return '$days day${days > 1 ? 's' : ''} ago';
  }

  bool get isPending =>
      state == 'queued' || state == 'running' || state == 'paused';

  String get statusLabel {
    if (state == 'queued') return 'Queued';
    if (state == 'running') return 'Downloading';
    if (state == 'paused') return 'Paused';
    if (state == 'failed') return 'Failed';
    return 'Saved';
  }
}

/// Represents a student task (Assignment or Quiz) from the portal
class PortalTask {
  final String type; // Assignment, Quiz, etc.
  final String title;
  final String subject;
  final String dueDate;
  final String startDate;
  final int scrapedAt;
  final bool isCompleted;
  final bool isActionable;
  final String status;
  final String? courseId;
  final DateTime? _dueDateTime;

  static final RegExp _spaceRegex = RegExp(r'\s+');
  static final RegExp _dateSepRegex = RegExp(r'[/\-]');

  const PortalTask({
    required this.type,
    required this.title,
    required this.subject,
    required this.dueDate,
    this.startDate = "",
    required this.scrapedAt,
    this.isCompleted = false,
    this.isActionable = false,
    this.status = "",
    this.courseId,
    DateTime? dueDateTime,
  }) : _dueDateTime = dueDateTime;

  factory PortalTask.fromJson(dynamic json) {
    final data = (json is Map)
        ? Map<String, dynamic>.from(json)
        : <String, dynamic>{};
    final rawDue = data['dueDate']?.toString() ?? '';
    return PortalTask(
      type: data['type']?.toString() ?? 'Task',
      title: data['title']?.toString() ?? '',
      subject: data['subject']?.toString() ?? 'Unknown Subject',
      dueDate: rawDue,
      startDate: data['startDate']?.toString() ?? '',
      scrapedAt:
          (data['scrapedAt'] as num?)?.toInt() ??
          DateTime.now().millisecondsSinceEpoch,
      isCompleted: data['isCompleted'] == true,
      isActionable: data['isActionable'] == true,
      status: data['status']?.toString() ?? "",
      courseId: data['courseId']?.toString(),
      dueDateTime: _parseDueDate(rawDue),
    );
  }

  Map<String, dynamic> toJson() => {
    'type': type,
    'title': title,
    'subject': subject,
    'dueDate': dueDate,
    'startDate': startDate,
    'scrapedAt': scrapedAt,
    'isCompleted': isCompleted,
    'isActionable': isActionable,
    'status': status,
    'courseId': courseId,
  };

  DateTime? get dueDateTime => _dueDateTime ?? _parseDueDate(dueDate);

  static DateTime? _parseDueDate(String raw) {
    final trimmed = raw.trim();
    if (trimmed.isEmpty) return null;

    final isoDate = DateTime.tryParse(trimmed);
    if (isoDate != null) return isoDate;

    try {
      // Handles portal formats like "9/21/2026 12:31:00 PM" or "21/09/2026 12:31:00 PM"
      final parts = trimmed.split(_spaceRegex);
      if (parts.isEmpty) return null;

      final dateParts = parts[0].split(_dateSepRegex);
      if (dateParts.length < 3) return null;

      int p1 = int.parse(dateParts[0]);
      int p2 = int.parse(dateParts[1]);
      final yearText = dateParts[2];
      int year = int.parse(yearText.length == 2 ? '20$yearText' : yearText);

      int month = p1;
      int day = p2;
      if (p1 > 12) {
        day = p1;
        month = p2;
      }

      int hour = 23;
      int minute = 59;

      if (parts.length >= 2) {
        final timeSegs = parts[1].split(':');
        if (timeSegs.isNotEmpty) {
          hour = int.tryParse(timeSegs[0]) ?? hour;
          if (timeSegs.length > 1) {
            minute = int.tryParse(timeSegs[1]) ?? minute;
          }
        }
        if (parts.length >= 3) {
          final ampm = parts[2].toUpperCase();
          if (ampm == 'PM' && hour < 12) {
            hour += 12;
          } else if (ampm == 'AM' && hour == 12) {
            hour = 0;
          }
        }
      }

      return DateTime(year, month, day, hour, minute);
    } catch (_) {
      return null;
    }
  }

  static const List<String> _months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];

  static const List<String> _weekdays = [
    'Mon',
    'Tue',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun',
  ];

  String get formattedDueDate {
    final dt = dueDateTime;
    if (dt == null) return dueDate;
    final weekdayStr = _weekdays[dt.weekday - 1];
    final monthStr = _months[dt.month - 1];
    return '$weekdayStr, $monthStr ${dt.day}';
  }

  String get formattedDueTime {
    final dt = dueDateTime;
    if (dt == null) return '11:59 PM';
    final int h = dt.hour;
    final int m = dt.minute;
    final String ampm = h >= 12 ? 'PM' : 'AM';
    final int displayH = h == 0 ? 12 : (h > 12 ? h - 12 : h);
    final String displayM = m.toString().padLeft(2, '0');
    return '$displayH:$displayM $ampm';
  }

  String get formattedDueSummary {
    final dt = dueDateTime;
    if (dt == null) return dueDate;
    return '$formattedDueDate • $formattedDueTime';
  }

  bool get isUrgent {
    final diff = daysRemaining;
    return diff >= 0 && diff <= 2;
  }

  int get daysRemaining {
    final dt = dueDateTime;
    if (dt == null) return 999;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final target = DateTime(dt.year, dt.month, dt.day);
    return target.difference(today).inDays;
  }

  PortalTask copyWith({bool? isCompleted, bool? isActionable, String? status}) {
    return PortalTask(
      type: type,
      title: title,
      subject: subject,
      dueDate: dueDate,
      startDate: startDate,
      scrapedAt: scrapedAt,
      isCompleted: isCompleted ?? this.isCompleted,
      isActionable: isActionable ?? this.isActionable,
      status: status ?? this.status,
      courseId: courseId,
      dueDateTime: _dueDateTime,
    );
  }
}

class PortalSession {
  final String host;
  final String title;
  final String url;
  final String? savedUsername;
  final int createdAt;
  final int lastAccessedAt;
  final bool hasValidCookies;
  final List<DownloadRecord> recentDownloads;
  final List<String> recentUploads;

  PortalSession({
    required this.host,
    required this.title,
    required this.url,
    this.savedUsername,
    required this.createdAt,
    required this.lastAccessedAt,
    this.hasValidCookies = false,
    this.recentDownloads = const [],
    this.recentUploads = const [],
    this.tasks = const [],
    this.lastSyncAt,
  });

  final List<PortalTask> tasks;
  final int? lastSyncAt;

  factory PortalSession.fromJson(Map<String, dynamic> json) {
    return PortalSession(
      host: json['host'] ?? 'unknown',
      title: json['title'] ?? 'Portal',
      url: json['url'] ?? '',
      savedUsername: json['savedUsername'],
      createdAt: json['createdAt'] ?? DateTime.now().millisecondsSinceEpoch,
      lastAccessedAt:
          json['lastAccessedAt'] ?? DateTime.now().millisecondsSinceEpoch,
      hasValidCookies: json['hasValidCookies'] ?? false,
      recentDownloads: (json['recentDownloads'] as List<dynamic>? ?? const [])
          .map(DownloadRecord.fromJson)
          .toList(),
      recentUploads: List<String>.from(json['recentUploads'] ?? []),
      tasks: (json['tasks'] as List<dynamic>? ?? const [])
          .map(PortalTask.fromJson)
          .toList(),
      lastSyncAt: json['lastSyncAt'],
    );
  }

  Map<String, dynamic> toJson() => {
    'host': host,
    'title': title,
    'url': url,
    'savedUsername': savedUsername,
    'createdAt': createdAt,
    'lastAccessedAt': lastAccessedAt,
    'hasValidCookies': hasValidCookies,
    'recentDownloads': recentDownloads.map((d) => d.toJson()).toList(),
    'recentUploads': recentUploads,
    'tasks': tasks.map((t) => t.toJson()).toList(),
    'lastSyncAt': lastSyncAt,
  };

  String get prettyLastAccessed {
    final now = DateTime.now().millisecondsSinceEpoch;
    final diff = now - lastAccessedAt;
    final days = diff ~/ (24 * 60 * 60 * 1000);
    if (days > 0) return '$days day${days > 1 ? 's' : ''} ago';
    final hours = diff ~/ (60 * 60 * 1000);
    if (hours > 0) return '$hours hour${hours > 1 ? 's' : ''} ago';
    return 'Just now';
  }

  PortalSession copyWith({
    String? title,
    String? url,
    String? savedUsername,
    int? lastAccessedAt,
    bool? hasValidCookies,
    List<DownloadRecord>? recentDownloads,
    List<String>? recentUploads,
    List<PortalTask>? tasks,
    int? lastSyncAt,
  }) {
    return PortalSession(
      host: host,
      title: title ?? this.title,
      url: url ?? this.url,
      savedUsername: savedUsername ?? this.savedUsername,
      createdAt: createdAt,
      lastAccessedAt: lastAccessedAt ?? this.lastAccessedAt,
      hasValidCookies: hasValidCookies ?? this.hasValidCookies,
      recentDownloads: recentDownloads ?? this.recentDownloads,
      recentUploads: recentUploads ?? this.recentUploads,
      tasks: tasks ?? this.tasks,
      lastSyncAt: lastSyncAt ?? this.lastSyncAt,
    );
  }
}

