import 'package:flutter/material.dart';
import 'package:iris/widgets/schedule_views/exam_schedule_view.dart';
import '../../services/ui_feedback.dart';
import '../../core/vital_theme.dart';
import '../../core/animations.dart';
import '../../widgets/iris_components.dart';

class ExamGridDashboard extends StatelessWidget {
  final String period;
  final String batch;
  final VoidCallback onToggleTheme;

  const ExamGridDashboard({
    required this.period,
    required this.batch,
    required this.onToggleTheme,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: irisFrostedAppBar(
        title: period == 'midterms' ? 'Midterm Examinations' : 'Final Examinations',
        isDark: isDark,
        leading: AppBackButton(isDark: isDark),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          ObsidianPulse(isDark: isDark),
          SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 860),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 8),

                  // Embedded High-Performance Exam Schedule View
                  ExamScheduleView(
                    period: period,
                    batch: batch,
                    showHeroBanner: true,
                    onToggleTheme: onToggleTheme,
                  ),

                  const SizedBox(height: 48),
                ],
              ),
            ),
          ),
        ),
      ),
        ],
      ),
    );
  }
}
