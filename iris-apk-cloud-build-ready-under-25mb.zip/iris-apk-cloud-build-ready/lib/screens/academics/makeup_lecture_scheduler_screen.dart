import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import '../../core/tokens.dart';
import '../../core/models.dart';
import '../../core/omni_brain.dart';
import '../../core/glass.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/iris_components.dart';
import 'package:iris/widgets/navigation/dashboard_dock.dart';
import '../../core/animations.dart';
import '../../services/ui_feedback.dart';
import '../../core/vital_theme.dart'; // For ObsidianPulse
import '../../core/theme_signals.dart';
import 'package:iris/widgets/controls/iris_liquid_button.dart';
import '../../widgets/makeup/makeup_widgets.dart';
import '../../services/helpdesk_faculty_service.dart';
import '../../services/remote_config_service.dart';
import '../tools_screen.dart';
import 'package:iris/screens/faculty/teacher_locator_screen.dart';
import '../portal_screen.dart';
import 'package:iris/screens/settings/about_screen.dart';
import 'package:iris/screens/academics/department_classes_screen.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';

class MakeupLectureScheduler extends StatefulWidget {
  final UniversityMemory memory;
  final OmniBrain brain;
  final String batch;
  final Future<void> Function(ClassSession session) onAddMakeupClass;
  final Future<void> Function(ClassSession session)? onRemoveMakeupClass;
  final ValueChanged<String>? onRoleChanged;
  final ValueChanged<String>? onBatchChanged;
  final bool showDock;
  final bool showBackButton;
  final String? teacherName;

  const MakeupLectureScheduler({
    required this.memory,
    required this.brain,
    required this.batch,
    required this.onAddMakeupClass,
    this.onRemoveMakeupClass,
    this.onRoleChanged,
    this.onBatchChanged,
    this.showDock = false,
    this.showBackButton = true,
    this.teacherName,
    super.key,
  });

  @override
  State<MakeupLectureScheduler> createState() => _MakeupLectureSchedulerState();
}

class _MakeupLectureSchedulerState extends State<MakeupLectureScheduler> {
  late TextEditingController _teacherController;
  String? _selectedTeacher;
  String? _selectedSuggestionKey;
  bool _autoSelectedTeacher = false;
  List<MakeupSlotSuggestion> _suggestions = [];
  List<MakeupSlotSuggestion> _filteredSuggestions = [];
  List<String> _filteredTeachers = [];
  bool _isLoading = false;
  final List<String> _allTeachers = [];
  late String _activeBatch;
  List<String> _teacherBatches = [];
  bool get _isFacultyMode => widget.teacherName != null && widget.teacherName!.trim().isNotEmpty;

  // Smart filters
  int? _filterDayIndex;
  double _minDuration = 0.5;
  int _minRooms = 0;
  String _sortBy = 'earliest'; // 'earliest', 'duration', 'rooms'
  final ScrollController _scrollController = ScrollController();

  void _onPeriodChanged() {
    if (!mounted) return;
    if (_selectedTeacher != null && _selectedTeacher!.isNotEmpty) {
      _findMakeupSlots();
    } else {
      setState(() {});
    }
  }

  @override
  void initState() {
    super.initState();
    RemoteConfigService.activeAcademicPeriod.addListener(_onPeriodChanged);
    _teacherController = TextEditingController();
    // Get all teachers from memory
    final teachers = <String>{};
    for (final session in widget.memory.sessions) {
      teachers.add(session.teacher);
    }
    _allTeachers.addAll(teachers.toList()..sort());
    _filteredTeachers = List.from(_allTeachers);

    if (_isFacultyMode) {
      final tName = widget.teacherName!.trim();
      _selectedTeacher = tName;
      _teacherController.text = tName;

      // Extract all distinct batches taught by this teacher
      final teacherSessions = widget.memory.sessions
          .where((s) => HelpdeskFacultyService.isNameMatch(s.teacher, tName))
          .toList();
      _teacherBatches = teacherSessions
          .map((s) => s.batchKey.batch.trim())
          .where((b) => b.isNotEmpty)
          .toSet()
          .toList()
        ..sort();

      if (widget.batch.isNotEmpty && _teacherBatches.contains(widget.batch)) {
        _activeBatch = widget.batch;
      } else if (_teacherBatches.isNotEmpty) {
        _activeBatch = _teacherBatches.first;
      } else {
        _activeBatch = widget.batch;
      }

      WidgetsBinding.instance.addPostFrameCallback((_) {
        Future.delayed(const Duration(milliseconds: 260), () {
          if (mounted) _findMakeupSlots();
        });
      });
    } else {
      _activeBatch = widget.batch;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        // Wait for route transition to complete before heavy slot discovery.
        Future.delayed(const Duration(milliseconds: 260), () {
          if (mounted) _autoSelectSmartTeacher();
        });
      });
    }
  }

  @override
  void dispose() {
    RemoteConfigService.activeAcademicPeriod.removeListener(_onPeriodChanged);
    _teacherController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _updateTeacherSuggestions(String query) {
    if (query.trim().isEmpty) {
      setState(() => _filteredTeachers = List.from(_allTeachers));
      return;
    }
    final q = query.toLowerCase().trim();
    final qTokens = HelpdeskFacultyService.extractCoreTokens(q);
    final matches = _allTeachers.where((t) {
      final tLower = t.toLowerCase();
      if (tLower.contains(q)) return true;
      if (HelpdeskFacultyService.isNameMatch(t, q, threshold: 0.65)) {
        return true;
      }
      final tTokens = HelpdeskFacultyService.extractCoreTokens(t);
      if (qTokens.isNotEmpty && qTokens.every((qt) => tTokens.contains(qt))) {
        return true;
      }
      return false;
    }).toList();
    setState(() => _filteredTeachers = matches);
  }

  void _selectTeacher(String teacher) {
    setState(() {
      _selectedTeacher = teacher;
      _selectedSuggestionKey = null;
      _autoSelectedTeacher = false;
      _teacherController.text = teacher;
      _filteredTeachers = [];
    });
    IrisHaptics.chipSelect();
    _findMakeupSlots();
  }

  List<ClassSession> get _activeBatchSessions =>
      widget.brain.scheduleFor(_activeBatch);

  String? _pickSmartTeacherForBatch() {
    final now = DateTime.now();
    final nowVal = now.hour + (now.minute / 60.0);
    final batchSessions = _activeBatchSessions
        .where(
          (s) => !s.id.startsWith('makeup_'),
        )
        .toList();
    if (batchSessions.isEmpty) return null;

    final today = batchSessions
        .where((s) => s.dayIndex == now.weekday)
        .toList();
    today.sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));

    final live = today
        .where((s) => s.safeStartVal <= nowVal && nowVal < s.safeEndVal)
        .toList();
    if (live.isNotEmpty) return live.first.teacher;

    final upcoming = today.where((s) => s.safeStartVal > nowVal).toList();
    if (upcoming.isNotEmpty) return upcoming.first.teacher;

    final frequency = <String, int>{};
    for (final session in batchSessions) {
      final key = session.teacher.trim();
      if (key.isEmpty) continue;
      frequency.update(key, (count) => count + 1, ifAbsent: () => 1);
    }
    if (frequency.isEmpty) return null;
    return frequency.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
  }

  void _autoSelectSmartTeacher() {
    if (_selectedTeacher != null || _isLoading || _allTeachers.isEmpty) return;

    final smartTeacher = _pickSmartTeacherForBatch();
    if (smartTeacher == null || !_allTeachers.contains(smartTeacher)) return;

    setState(() {
      _selectedTeacher = smartTeacher;
      _teacherController.text = smartTeacher;
      _selectedSuggestionKey = null;
      _filteredTeachers = [];
      _autoSelectedTeacher = true;
    });

    _findMakeupSlots();
  }

  String _timeFromDecimal(double value) {
    final rawHour = value.floor().clamp(0, 23);
    final minute = ((value - value.floor()) * 60).round().clamp(0, 59);
    final period = rawHour >= 12 ? 'PM' : 'AM';
    final hour = rawHour == 0 ? 12 : (rawHour > 12 ? rawHour - 12 : rawHour);
    return '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')} $period';
  }

  String _slotKey(MakeupSlotSuggestion suggestion) {
    final teacherKey = (_selectedTeacher ?? '').trim().toLowerCase();
    return '${suggestion.dayIndex}_${suggestion.startTime.toStringAsFixed(3)}_${suggestion.endTime.toStringAsFixed(3)}_$teacherKey';
  }

  bool _sameTimeSlot(ClassSession session, MakeupSlotSuggestion suggestion) {
    return session.dayIndex == suggestion.dayIndex &&
        (session.safeStartVal - suggestion.startTime).abs() < 0.05 &&
        (session.safeEndVal - suggestion.endTime).abs() < 0.05;
  }

  ClassSession? _existingMakeupSessionForSuggestion(
    MakeupSlotSuggestion suggestion,
  ) {
    final teacher = _selectedTeacher?.trim().toLowerCase();
    if (teacher == null || teacher.isEmpty) return null;

    for (final session in _activeBatchSessions) {
      if (!session.id.startsWith('makeup_')) continue;
      if (session.teacher.trim().toLowerCase() != teacher) continue;
      if (_sameTimeSlot(session, suggestion)) return session;
    }
    return null;
  }

  bool _sessionsOverlapWithSuggestion(
    ClassSession session,
    MakeupSlotSuggestion suggestion,
  ) {
    if (session.dayIndex != suggestion.dayIndex) return false;
    return session.safeStartVal < (suggestion.endTime - 0.03) &&
        suggestion.startTime < (session.safeEndVal - 0.03);
  }

  ClassSession? _regularConflictForSuggestion(MakeupSlotSuggestion suggestion) {
    for (final session in _activeBatchSessions) {
      if (session.id.startsWith('makeup_')) continue;
      if (_sessionsOverlapWithSuggestion(session, suggestion)) return session;
    }
    return null;
  }

  List<ClassSession> _overlappingMakeupsForSuggestion(
    MakeupSlotSuggestion suggestion,
  ) {
    final teacher = _selectedTeacher?.trim().toLowerCase();
    return _activeBatchSessions.where((session) {
      if (!session.id.startsWith('makeup_')) return false;
      if (!_sessionsOverlapWithSuggestion(session, suggestion)) return false;
      if (teacher != null &&
          teacher.isNotEmpty &&
          session.teacher.trim().toLowerCase() == teacher &&
          _sameTimeSlot(session, suggestion)) {
        return false;
      }
      return true;
    }).toList();
  }

  String _inferMakeupSubject(String teacher) {
    final teacherKey = teacher.trim().toLowerCase();
    final frequency = <String, int>{};
    for (final session in _activeBatchSessions) {
      if (session.id.startsWith('makeup_')) continue;
      if (session.teacher.trim().toLowerCase() != teacherKey) continue;
      final subject = session.subject.trim();
      if (subject.isEmpty) continue;
      frequency.update(subject, (count) => count + 1, ifAbsent: () => 1);
    }
    if (frequency.isEmpty) return 'Makeup Class';
    return frequency.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
  }

  String _pickBestRoom(MakeupSlotSuggestion suggestion, String teacher) {
    final available = suggestion.availableRooms;
    if (available == null || available.isEmpty) {
      return 'TBD';
    }

    final teacherKey = teacher.trim().toLowerCase();
    final roomFrequency = <String, int>{};
    for (final session in widget.memory.sessions) {
      if (session.batchKey.batch != _activeBatch) continue;
      if (session.teacher.trim().toLowerCase() != teacherKey) continue;
      final room = session.room.trim();
      if (room.isEmpty) continue;
      roomFrequency.update(room, (count) => count + 1, ifAbsent: () => 1);
    }

    final rankedRooms = available.toList();
    rankedRooms.sort((a, b) {
      final aScore = roomFrequency[a] ?? 0;
      final bScore = roomFrequency[b] ?? 0;
      return bScore.compareTo(aScore);
    });

    return rankedRooms.first;
  }

  ClassSession _buildMakeupSession(MakeupSlotSuggestion suggestion) {
    final teacher = _selectedTeacher ?? 'Unknown Teacher';
    final inferredSubject = _inferMakeupSubject(teacher);
    final start = _timeFromDecimal(suggestion.startTime);
    final end = _timeFromDecimal(suggestion.endTime);
    final room = _pickBestRoom(suggestion, teacher);
    final teacherSlug = teacher
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
        .replaceAll(RegExp(r'_+'), '_')
        .replaceAll(RegExp(r'^_|_$'), '');
    final slotSlug =
        '${suggestion.dayIndex}_${(suggestion.startTime * 100).round()}_${(suggestion.endTime * 100).round()}';

    return ClassSession(
      id: 'makeup_${_activeBatch}_${teacherSlug}_$slotSlug',
      batchKey: BatchKey.parse(_activeBatch),
      dayIndex: suggestion.dayIndex,
      startTime: start,
      endTime: end,
      subject: inferredSubject,
      teacher: teacher,
      room: room,
    );
  }

  Future<void> _handleSuggestionAction(MakeupSlotSuggestion suggestion) async {
    if (_selectedTeacher == null || _selectedTeacher!.isEmpty) return;

    final existing = _existingMakeupSessionForSuggestion(suggestion);
    final regularConflict = _regularConflictForSuggestion(suggestion);

    if (existing == null && regularConflict != null) {
      showIrisFrostedSnackBar(
        context,
        dedupeKey: 'makeup_slot_conflict_${regularConflict.id}',
        content: Text(
          'Cannot add: conflicts with ${regularConflict.subject} (${regularConflict.startTime}-${regularConflict.endTime}).',
        ),
      );
      return;
    }

    if (existing != null) {
      if (widget.onRemoveMakeupClass != null) {
        await widget.onRemoveMakeupClass!(existing);
      }
    } else {
      final session = _buildMakeupSession(suggestion);
      await widget.onAddMakeupClass(session);
    }

    if (!mounted) return;
    setState(() {});
  }

  void _findMakeupSlots() {
    if (_selectedTeacher == null || _selectedTeacher!.isEmpty) {
      showIrisFrostedSnackBar(
        context,
        dedupeKey: 'makeup_select_teacher_first',
        content: const Text('Please select a teacher'),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    // Yield one frame so loading state can paint before heavy computation starts.
    Future.delayed(Duration.zero, () {
      if (!mounted) return;

      final computed = widget.brain.findMakeupSlots(
        _activeBatch,
        _selectedTeacher!,
      );
      setState(() {
        _suggestions = computed;
        _applyFiltersAndSort();
      });

      Future.delayed(const Duration(milliseconds: 180), () {
        if (mounted) {
          setState(() => _isLoading = false);

          if (_filteredSuggestions.isEmpty) {
            showIrisFrostedSnackBar(
              context,
              dedupeKey: _suggestions.isEmpty
                  ? 'makeup_slots_none_common'
                  : 'makeup_slots_none_filtered',
              content: Text(
                _suggestions.isEmpty
                    ? 'No common free slots found'
                    : 'No slots match your filters. Try adjusting them.',
              ),
            );
          }
        }
      });
    });
  }

  Future<void> _openTeacherFromMakeup() async {
    if (!mounted) return;
    await pushIconLaunchRoute(
      context,
      lightweight: true,
      transitionDuration: const Duration(milliseconds: 304),
      reverseTransitionDuration: const Duration(milliseconds: 240),
      page: TeacherLocatorScreen(
        brain: widget.brain,
        onRoleChanged: widget.onRoleChanged,
        onBatchChanged: widget.onBatchChanged,
        memory: widget.memory,
        currentBatch: _activeBatch,
      ),
    );
  }

  Future<void> _openPortalFromMakeup() async {
    if (!mounted) return;
    await pushIconLaunchRoute(
      context,
      lightweight: true,
      transitionDuration: const Duration(milliseconds: 304),
      reverseTransitionDuration: const Duration(milliseconds: 240),
      page: const PortalScreen(
        url: 'https://swl-sis.comsats.edu.pk/',
        title: 'COMSATS Student Portal',
        sessionScope: 'student',
      ),
    );
  }

  Future<void> _openClassesFromMakeup() async {
    if (!mounted) return;
    await pushIconLaunchRoute(
      context,
      lightweight: true,
      transitionDuration: const Duration(milliseconds: 304),
      reverseTransitionDuration: const Duration(milliseconds: 240),
      page: DepartmentClassesScreen(
        memory: widget.memory,
        currentBatch: _activeBatch,
        teacherName: widget.teacherName,
        brain: widget.brain,
        showBatchShortcut: true,
        onRoleChanged: widget.onRoleChanged,
        onBatchChanged: widget.onBatchChanged,
        onAddMakeupClass: widget.onAddMakeupClass,
        onRemoveMakeupClass: widget.onRemoveMakeupClass,
      ),
    );
  }

  Future<void> _openToolsFromMakeup() async {
    if (!mounted) return;
    await pushIconLaunchRoute(
      context,
      lightweight: true,
      transitionDuration: const Duration(milliseconds: 304),
      reverseTransitionDuration: const Duration(milliseconds: 240),
      page: ToolsScreen(
        memory: widget.memory,
        batch: _activeBatch,
        brain: widget.brain,
        onRoleChanged: widget.onRoleChanged,
        onBatchChanged: widget.onBatchChanged,
        onAddMakeupClass: widget.onAddMakeupClass,
        onRemoveMakeupClass: widget.onRemoveMakeupClass,
      ),
    );
  }

  Future<void> _openAboutFromMakeup() async {
    if (!mounted) return;
    await pushIconLaunchRoute(
      context,
      lightweight: true,
      transitionDuration: const Duration(milliseconds: 304),
      reverseTransitionDuration: const Duration(milliseconds: 240),
      page: AboutScreen(
        memory: widget.memory,
        onRoleChanged: widget.onRoleChanged,
        onBatchChanged: widget.onBatchChanged,
      ),
    );
  }

  void _applyFiltersAndSort() {
    var filtered = List<MakeupSlotSuggestion>.from(_suggestions);

    // Strictly exclude slots that conflict with regular classes and cannot be arranged
    filtered = filtered.where((s) {
      final conflict = _regularConflictForSuggestion(s);
      final isAdded = _existingMakeupSessionForSuggestion(s) != null;
      if (conflict != null && !isAdded) return false;
      return true;
    }).toList();

    // Apply filters
    if (_filterDayIndex != null) {
      filtered = filtered.where((s) => s.dayIndex == _filterDayIndex).toList();
    }
    if (_minDuration > 0.5) {
      filtered = filtered
          .where((s) => s.durationHours >= _minDuration)
          .toList();
    }
    if (_minRooms > 0) {
      filtered = filtered
          .where(
            (s) =>
                s.availableRooms != null &&
                s.availableRooms!.length >= _minRooms,
          )
          .toList();
    }

    // Apply sorting
    switch (_sortBy) {
      case 'earliest':
        filtered.sort((a, b) {
          final dayCompare = a.dayIndex.compareTo(b.dayIndex);
          if (dayCompare != 0) return dayCompare;
          return a.startTime.compareTo(b.startTime);
        });
        break;
      case 'duration':
        filtered.sort((a, b) => b.durationHours.compareTo(a.durationHours));
        break;
      case 'rooms':
        filtered.sort((a, b) {
          final aRooms = a.availableRooms?.length ?? 0;
          final bRooms = b.availableRooms?.length ?? 0;
          return bRooms.compareTo(aRooms);
        });
        break;
    }

    _filteredSuggestions = filtered;
  }

  void _resetFilters() {
    setState(() {
      _filterDayIndex = null;
      _minDuration = 0.5;
      _minRooms = 0;
      _sortBy = 'earliest';
      _applyFiltersAndSort();
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;
    const purple = IrisTokens.purple;
    const purpleLight = IrisTokens.purpleLight;
    const amber = Color(0xFFF59E0B);

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: irisFrostedAppBar(
        title: 'Makeup Scheduler',
        isDark: isDark,
        leading: widget.showBackButton ? AppBackButton(isDark: isDark) : null,
      ),
      body: Stack(
        children: [
          // Neural aura background
          ObsidianPulse(isDark: isDark),
          SafeArea(
            child: Align(
              alignment: Alignment.topCenter,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 860),
                child: SingleChildScrollView(
                  controller: _scrollController,
                  physics: const ButterScrollPhysics(
                    parent: AlwaysScrollableScrollPhysics(),
                  ),
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 108),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 12),
                  // Header
                  GlassCard(
                    borderRadius: 24,
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [purple, purpleLight, purpleLight],
                            ),
                            borderRadius: BorderRadius.circular(18),
                            boxShadow: [
                              BoxShadow(
                                color: purple.withValues(alpha: 0.35),
                                blurRadius: 16,
                                offset: const Offset(0, 6),
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.schedule_rounded,
                            color: Colors.white,
                            size: 28,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ShaderMask(
                                shaderCallback: (bounds) =>
                                    const LinearGradient(
                                      colors: [purple, purpleLight],
                                    ).createShader(bounds),
                                child: const Text(
                                  'Schedule Makeup',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 24,
                                    letterSpacing: -0.3,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Find free slots with your teacher',
                                style: TextStyle(
                                  fontSize: 13,
                                  letterSpacing: 0.1,
                                  color:
                                      (isDark ? Colors.white : Colors.black)
                                          .withValues(alpha: 0.55),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 22),

                  // Search card
                  Builder(
                    builder: (context) {
                      final searchCardContent = _isFacultyMode
                          ? Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      width: 42,
                                      height: 42,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        gradient: const LinearGradient(
                                          colors: [
                                            IrisTokens.purple,
                                            IrisTokens.brand,
                                          ],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                            color: IrisTokens.brand.withValues(alpha: 0.3),
                                            blurRadius: 8,
                                            offset: const Offset(0, 2),
                                          ),
                                        ],
                                      ),
                                      child: Center(
                                        child: Text(
                                          widget.teacherName!.isNotEmpty
                                              ? widget.teacherName![0].toUpperCase()
                                              : 'F',
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 17,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            widget.teacherName!,
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w700,
                                              color: isDark ? Colors.white : Colors.black,
                                              letterSpacing: -0.2,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          const SizedBox(height: 2),
                                          Text(
                                            'Faculty Mode • Schedule Makeup Lecture',
                                            style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w500,
                                              color: (isDark ? Colors.white : Colors.black)
                                                  .withValues(alpha: 0.55),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: IrisTokens.purple.withValues(alpha: isDark ? 0.2 : 0.1),
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(
                                          color: IrisTokens.purple.withValues(alpha: 0.35),
                                        ),
                                      ),
                                      child: const Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(Icons.lock_rounded, size: 12, color: IrisTokens.purple),
                                          SizedBox(width: 4),
                                          Text(
                                            'Active',
                                            style: TextStyle(
                                              fontSize: 11,
                                              fontWeight: FontWeight.w700,
                                              color: IrisTokens.purple,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 16),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.school_rounded,
                                      size: 15,
                                      color: purple.withValues(alpha: 0.85),
                                    ),
                                    const SizedBox(width: 6),
                                    Text(
                                      'Target Batch (${_teacherBatches.length} taught)',
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w700,
                                        color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.75),
                                        letterSpacing: 0.3,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 10),
                                if (_teacherBatches.isNotEmpty)
                                  Wrap(
                                    spacing: 8,
                                    runSpacing: 8,
                                    children: _teacherBatches.map((batch) {
                                      final isSelected = _activeBatch == batch;
                                      return ExpressiveInteractivePress(
                                        onTap: () {
                                          IrisHaptics.selectionClick();
                                          if (_activeBatch != batch) {
                                            setState(() {
                                              _activeBatch = batch;
                                              _selectedSuggestionKey = null;
                                            });
                                            _findMakeupSlots();
                                          }
                                        },
                                        child: AnimatedContainer(
                                          duration: IrisMotion.fast,
                                          curve: IrisMotion.standard,
                                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                                          decoration: BoxDecoration(
                                            color: isSelected
                                                ? IrisTokens.brand
                                                : (isDark
                                                    ? Colors.white.withValues(alpha: 0.08)
                                                    : Colors.black.withValues(alpha: 0.05)),
                                            borderRadius: BorderRadius.circular(12),
                                            border: Border.all(
                                              color: isSelected
                                                  ? IrisTokens.brand
                                                  : (isDark
                                                      ? Colors.white.withValues(alpha: 0.12)
                                                      : Colors.black.withValues(alpha: 0.08)),
                                              width: isSelected ? 1.5 : 1.0,
                                            ),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(
                                                Icons.groups_rounded,
                                                size: 14,
                                                color: isSelected
                                                    ? Colors.white
                                                    : (isDark ? Colors.white70 : Colors.black87),
                                              ),
                                              const SizedBox(width: 6),
                                              Text(
                                                batch,
                                                style: TextStyle(
                                                  fontSize: 13,
                                                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                                                  color: isSelected
                                                      ? Colors.white
                                                      : (isDark ? Colors.white : Colors.black),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    }).toList(),
                                  )
                                else
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    decoration: BoxDecoration(
                                      color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.black.withValues(alpha: 0.03),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Text(
                                      'Active batch: $_activeBatch',
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w600,
                                        color: isDark ? Colors.white70 : Colors.black87,
                                      ),
                                    ),
                                  ),
                              ],
                            )
                          : Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.person_rounded,
                                  size: 16,
                                  color: purple.withValues(alpha: 0.8),
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  'Teacher',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    color:
                                        (isDark ? Colors.white : Colors.black)
                                            .withValues(alpha: 0.7),
                                    letterSpacing: 0.4,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            // Search field
                            AnimatedContainer(
                              duration: IrisMotion.fast,
                              curve: IrisMotion.standard,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: isDark
                                      ? [
                                          Colors.black.withValues(alpha: 0.50),
                                          Colors.black.withValues(alpha: 0.45),
                                        ]
                                      : [
                                          Colors.white.withValues(alpha: 0.85),
                                          Colors.white.withValues(alpha: 0.80),
                                        ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                borderRadius: BorderRadius.circular(
                                  IrisTokens.radius20,
                                ),
                                border: Border.all(
                                  color: isDark
                                      ? Colors.white.withValues(alpha: 0.18)
                                      : IrisTokens.brand.withValues(
                                          alpha: 0.10,
                                        ),
                                  width: 1.5,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: IrisTokens.brand.withValues(
                                      alpha: isDark ? 0.08 : 0.06,
                                    ),
                                    blurRadius: 16,
                                    offset: const Offset(0, 4),
                                    spreadRadius: -2,
                                  ),
                                  BoxShadow(
                                    color: Colors.black.withValues(
                                      alpha: isDark ? 0.25 : 0.04,
                                    ),
                                    blurRadius: 8,
                                    offset: const Offset(0, 2),
                                    spreadRadius: -1,
                                  ),
                                ],
                              ),
                              child: TextField(
                                controller: _teacherController,
                                onChanged: (value) {
                                  _updateTeacherSuggestions(value);
                                  setState(() {});
                                },
                                textInputAction: TextInputAction.search,
                                enabled: !_isLoading,
                                style: const TextStyle(
                                  fontSize: 17,
                                  fontWeight: FontWeight.w500,
                                  letterSpacing: 0.1,
                                ),
                                decoration: InputDecoration(
                                  hintText: 'Search by name...',
                                  enabledBorder: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintStyle: TextStyle(
                                    color:
                                        (isDark ? Colors.white : Colors.black)
                                            .withValues(alpha: 0.40),
                                    fontWeight: FontWeight.w400,
                                    letterSpacing: 0.1,
                                  ),
                                  prefixIcon: const Icon(
                                    Icons.person_search_rounded,
                                    color: IrisTokens.brand,
                                    size: 24,
                                  ),
                                  suffixIcon:
                                      _selectedTeacher != null ||
                                          _teacherController.text.isNotEmpty
                                      ? IconButton(
                                          icon: Icon(
                                            Icons.clear_rounded,
                                            color:
                                                (isDark
                                                        ? Colors.white
                                                        : Colors.black)
                                                    .withValues(alpha: 0.45),
                                            size: 22,
                                          ),
                                          splashRadius: 22,
                                          onPressed: () {
                                            IrisHaptics.actionSoft();
                                            _teacherController.clear();
                                            setState(() {
                                              _selectedTeacher = null;
                                              _selectedSuggestionKey = null;
                                              _autoSelectedTeacher = false;
                                              _filteredTeachers = List.from(
                                                _allTeachers,
                                              );
                                              _suggestions = [];
                                              _filteredSuggestions = [];
                                            });
                                          },
                                        )
                                      : null,
                                  border: InputBorder.none,
                                  contentPadding: const EdgeInsets.symmetric(
                                    horizontal: IrisTokens.space20,
                                    vertical: IrisTokens.space20,
                                  ),
                                ),
                              ),
                            ),
                            // Filtered suggestions dropdown
                            if (_filteredTeachers.isNotEmpty &&
                                _teacherController.text.isNotEmpty)
                              Column(
                                children: [
                                  const SizedBox(height: 8),
                                  Container(
                                    decoration: BoxDecoration(
                                      color: isDark
                                          ? Colors.black.withValues(alpha: 0.4)
                                          : Colors.white.withValues(alpha: 0.6),
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(
                                        color: isDark
                                            ? Colors.white.withValues(
                                                alpha: 0.10,
                                              )
                                            : Colors.black.withValues(
                                                alpha: 0.06,
                                              ),
                                      ),
                                    ),
                                    constraints: const BoxConstraints(
                                      maxHeight: 220,
                                    ),
                                    child: ListView.builder(
                                      shrinkWrap: true,
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 4,
                                      ),
                                      itemCount: _filteredTeachers.length,
                                      itemBuilder: (context, index) {
                                        final teacher =
                                            _filteredTeachers[index];
                                        final isSelected =
                                            _selectedTeacher == teacher;
                                        return InkWell(
                                          onTap: () => _selectTeacher(teacher),
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 14,
                                              vertical: 12,
                                            ),
                                            decoration: BoxDecoration(
                                              color: isSelected
                                                  ? purple.withValues(
                                                      alpha: isDark
                                                          ? 0.16
                                                          : 0.10,
                                                    )
                                                  : Colors.transparent,
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            child: Row(
                                              children: [
                                                Icon(
                                                  isSelected
                                                      ? Icons
                                                            .check_circle_rounded
                                                      : Icons.person_rounded,
                                                  size: 16,
                                                  color: isSelected
                                                      ? purple
                                                      : (isDark
                                                                ? Colors.white
                                                                : Colors.black)
                                                            .withValues(
                                                              alpha: 0.5,
                                                            ),
                                                ),
                                                const SizedBox(width: 10),
                                                Expanded(
                                                  child: Text(
                                                    teacher,
                                                    style: TextStyle(
                                                      fontSize: 14,
                                                      fontWeight: isSelected
                                                          ? FontWeight.w700
                                                          : FontWeight.w500,
                                                      color: isDark
                                                          ? Colors.white
                                                          : Colors.black,
                                                    ),
                                                    maxLines: 1,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            if (_selectedTeacher != null) ...[
                              const SizedBox(height: 10),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 8,
                                ),
                                decoration: BoxDecoration(
                                  color: purple.withValues(
                                    alpha: isDark ? 0.18 : 0.12,
                                  ),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: purple.withValues(alpha: 0.35),
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    const Icon(
                                      Icons.verified_rounded,
                                      size: 16,
                                      color: IrisTokens.purple,
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        _selectedTeacher!,
                                        style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w700,
                                          color: isDark
                                              ? Colors.white
                                              : Colors.black,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 8,
                                        vertical: 4,
                                      ),
                                      decoration: BoxDecoration(
                                        color: Colors.white.withValues(
                                          alpha: isDark ? 0.08 : 0.7,
                                        ),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Text(
                                        _autoSelectedTeacher
                                            ? 'Smart Pick'
                                            : 'Selected',
                                        style: TextStyle(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w700,
                                          color: isDark
                                              ? Colors.white70
                                              : Colors.black54,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ],
                        );

                      final themeStyle = ThemeSignals.themeStyle.value;
                      if (themeStyle != IrisThemeStyle.fluidGlass && !isM3) {
                        return GlassCard(
                          borderRadius: 24,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 24,
                            vertical: 24,
                          ),
                          child: searchCardContent,
                        );
                      }

                      return isM3
                          ? Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 24,
                            vertical: 24,
                          ),
                          decoration: BoxDecoration(
                            color: isDark
                                ? cs.surfaceContainerLow
                                : cs.surfaceContainer,
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(
                              color: cs.outlineVariant.withValues(
                                alpha: isDark ? 0.35 : 0.5,
                              ),
                              width: 1.0,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(
                                  alpha: isDark ? 0.16 : 0.04,
                                ),
                                blurRadius: 10,
                                offset: const Offset(0, 3),
                              ),
                            ],
                          ),
                          child: searchCardContent,
                        )
                      : ClipRRect(
                          borderRadius: BorderRadius.circular(24),
                          child: GlassSurface(
                            settings: IrisGlass.settings(
                              context,
                              blur: 24,
                              ambientStrength: 0.5,
                              lightAngle: 1.5,
                              thickness: 16,
                              glassColor: isDark
                                  ? Colors.white.withValues(alpha: 0.05)
                                  : Colors.white.withValues(alpha: 0.4),
                            ),
                            radius: 24,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 24,
                                vertical: 24,
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(24),
                                border: Border.all(
                                  color: isDark
                                      ? Colors.white.withValues(alpha: 0.1)
                                      : Colors.white.withValues(alpha: 0.8),
                                  width: 1.2,
                                ),
                              ),
                              child: searchCardContent,
                            ),
                          ),
                        );
                    },
                  ),
                  const SizedBox(height: 20),

                  // Find Slots Button
                  SizedBox(
                    width: double.infinity,
                    child: IrisLiquidButton(
                      text: _isLoading ? 'Searching...' : 'Find Available Slots',
                      icon: _isLoading ? Icons.hourglass_top_rounded : Icons.search_rounded,
                      onTap: _isLoading || _selectedTeacher == null ? null : _findMakeupSlots,
                      color: purple,
                      isDark: isDark,
                      height: 54,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Results with Filters and Sort
                  if (_suggestions.isNotEmpty) ...[
                    // Statistics Summary
                    MakeupStatsCard(
                      isDark: isDark,
                      isM3: isM3,
                      cs: cs,
                      slotCount: _filteredSuggestions.length,
                      totalHours: _filteredSuggestions.fold<double>(
                        0,
                        (sum, s) => sum + s.durationHours,
                      ),
                      withRoomsCount: _filteredSuggestions
                          .where(
                            (s) => (s.availableRooms?.isNotEmpty ?? false),
                          )
                          .length,
                    ),
                    const SizedBox(height: 16),

                    // Filter & Sort Controls
                    Builder(
                      builder: (context) {
                        final filterSortContent = Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.tune_rounded,
                                size: 16,
                                color: purple.withValues(alpha: 0.9),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                'Filters & Sorting',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.5,
                                  color: (isDark ? Colors.white : Colors.black)
                                      .withValues(alpha: 0.7),
                                ),
                              ),
                              const Spacer(),
                              GestureDetector(
                                onTap: _resetFilters,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 6,
                                  ),
                                  decoration: BoxDecoration(
                                    color: amber.withValues(alpha: 0.14),
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                      color: amber.withValues(alpha: 0.3),
                                    ),
                                  ),
                                  child: Text(
                                    'Reset',
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w700,
                                      color: amber,
                                      letterSpacing: 0.3,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          // Day Segmented Bar (Mon - Fri)
                          IrisSegmentedControl(
                            selectedIndex: _filterDayIndex == null
                                ? 0
                                : _filterDayIndex!.clamp(1, 5),
                            onSegmentSelected: (index) {
                              IrisHaptics.chipSelect();
                              setState(() {
                                _filterDayIndex = index == 0 ? null : index;
                                _applyFiltersAndSort();
                              });
                            },
                            segments: const [
                              'All',
                              'Mon',
                              'Tue',
                              'Wed',
                              'Thu',
                              'Fri',
                            ],
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              // Day Filter
                              Expanded(
                                child: IrisGlassMenu(
                                  autoAdjustToScreen: true,
                                  menuPadding: const EdgeInsets.all(16),
                                  menuWidth: 175,
                                  menuHeight: 330.0,
                                  menuBorderRadius: 28.0,
                                  itemBorderRadius: 20.0,
                                  menuAlignment:
                                      lgw.GlassMenuAlignment.bottomCenter,
                                  settings: IrisGlass.widgetsSettings(
                                    context,
                                    blur: 16.0,
                                    ambientStrength: 0.7,
                                    lightAngle: 0.15 * math.pi,
                                    thickness: 18.0,
                                  ),
                                  triggerBuilder: (context, toggleMenu) {
                                    return _buildFilterChip(
                                      icon: Icons.calendar_today_rounded,
                                      label: _filterDayIndex == null
                                          ? 'All Days'
                                          : [
                                              'Mon',
                                              'Tue',
                                              'Wed',
                                              'Thu',
                                              'Fri',
                                              'Sat',
                                              'Sun',
                                            ][_filterDayIndex! - 1],
                                      onTap: () {
                                        IrisHaptics.actionSoft();
                                        toggleMenu();
                                      },
                                      isDark: isDark,
                                    );
                                  },
                                  items: [
                                    lgw.GlassMenuItem(
                                      title: 'All Days',
                                      titleStyle: TextStyle(
                                        fontWeight: _filterDayIndex == null
                                            ? FontWeight.bold
                                            : FontWeight.w600,
                                        fontSize: 14,
                                        color: _filterDayIndex == null
                                            ? IrisTokens.brand
                                            : (isDark
                                                  ? Colors.white.withValues(
                                                      alpha: 0.9,
                                                    )
                                                  : Colors.black87),
                                      ),
                                      isSelected: _filterDayIndex == null,
                                      icon: Icon(
                                        Icons.calendar_month_rounded,
                                        size: 16,
                                        color: _filterDayIndex == null
                                            ? IrisTokens.brand
                                            : (isDark
                                                  ? Colors.white70
                                                  : Colors.black54),
                                      ),
                                      onTap: () {
                                        IrisHaptics.chipSelect();
                                        setState(() {
                                          _filterDayIndex = null;
                                          _applyFiltersAndSort();
                                        });
                                      },
                                    ),
                                    ...List.generate(7, (i) {
                                      final days = [
                                        'Monday',
                                        'Tuesday',
                                        'Wednesday',
                                        'Thursday',
                                        'Friday',
                                        'Saturday',
                                        'Sunday',
                                      ];
                                      final isSelected =
                                          _filterDayIndex == i + 1;
                                      return lgw.GlassMenuItem(
                                        title: days[i],
                                        titleStyle: TextStyle(
                                          fontWeight: isSelected
                                              ? FontWeight.bold
                                              : FontWeight.w600,
                                          fontSize: 14,
                                          color: isSelected
                                              ? IrisTokens.brand
                                              : (isDark
                                                    ? Colors.white.withValues(
                                                        alpha: 0.9,
                                                      )
                                                    : Colors.black87),
                                        ),
                                        isSelected: isSelected,
                                        icon: Icon(
                                          Icons.calendar_today_rounded,
                                          size: 16,
                                          color: isSelected
                                              ? IrisTokens.brand
                                              : (isDark
                                                    ? Colors.white70
                                                    : Colors.black54),
                                        ),
                                        onTap: () {
                                          IrisHaptics.chipSelect();
                                          setState(() {
                                            _filterDayIndex = i + 1;
                                            _applyFiltersAndSort();
                                          });
                                        },
                                      );
                                    }),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              // Sort
                              Expanded(
                                child: IrisGlassMenu(
                                  autoAdjustToScreen: true,
                                  menuPadding: const EdgeInsets.all(16),
                                  menuWidth: 195,
                                  menuHeight: 165.0,
                                  menuBorderRadius: 28.0,
                                  itemBorderRadius: 20.0,
                                  menuAlignment:
                                      lgw.GlassMenuAlignment.bottomCenter,
                                  settings: IrisGlass.widgetsSettings(
                                    context,
                                    blur: 16.0,
                                    ambientStrength: 0.7,
                                    lightAngle: 0.15 * math.pi,
                                    thickness: 18.0,
                                  ),
                                  triggerBuilder: (context, toggleMenu) {
                                    return _buildFilterChip(
                                      icon: Icons.sort_rounded,
                                      label: _sortBy == 'earliest'
                                          ? 'Earliest'
                                          : _sortBy == 'duration'
                                          ? 'Longest'
                                          : 'Most Rooms',
                                      onTap: () {
                                        IrisHaptics.actionSoft();
                                        toggleMenu();
                                      },
                                      isDark: isDark,
                                    );
                                  },
                                  items: [
                                    lgw.GlassMenuItem(
                                      title: 'Earliest First',
                                      titleStyle: TextStyle(
                                        fontWeight: _sortBy == 'earliest'
                                            ? FontWeight.bold
                                            : FontWeight.w600,
                                        fontSize: 14,
                                        color: _sortBy == 'earliest'
                                            ? IrisTokens.brand
                                            : (isDark
                                                  ? Colors.white.withValues(
                                                      alpha: 0.9,
                                                    )
                                                  : Colors.black87),
                                      ),
                                      isSelected: _sortBy == 'earliest',
                                      icon: Icon(
                                        Icons.access_time_rounded,
                                        size: 16,
                                        color: _sortBy == 'earliest'
                                            ? IrisTokens.brand
                                            : (isDark
                                                  ? Colors.white70
                                                  : Colors.black54),
                                      ),
                                      onTap: () {
                                        IrisHaptics.chipSelect();
                                        setState(() {
                                          _sortBy = 'earliest';
                                          _applyFiltersAndSort();
                                        });
                                      },
                                    ),
                                    lgw.GlassMenuItem(
                                      title: 'Longest Duration',
                                      titleStyle: TextStyle(
                                        fontWeight: _sortBy == 'duration'
                                            ? FontWeight.bold
                                            : FontWeight.w600,
                                        fontSize: 14,
                                        color: _sortBy == 'duration'
                                            ? IrisTokens.brand
                                            : (isDark
                                                  ? Colors.white.withValues(
                                                      alpha: 0.9,
                                                    )
                                                  : Colors.black87),
                                      ),
                                      isSelected: _sortBy == 'duration',
                                      icon: Icon(
                                        Icons.hourglass_bottom_rounded,
                                        size: 16,
                                        color: _sortBy == 'duration'
                                            ? IrisTokens.brand
                                            : (isDark
                                                  ? Colors.white70
                                                  : Colors.black54),
                                      ),
                                      onTap: () {
                                        IrisHaptics.chipSelect();
                                        setState(() {
                                          _sortBy = 'duration';
                                          _applyFiltersAndSort();
                                        });
                                      },
                                    ),
                                    lgw.GlassMenuItem(
                                      title: 'Most Rooms Available',
                                      titleStyle: TextStyle(
                                        fontWeight: _sortBy == 'rooms'
                                            ? FontWeight.bold
                                            : FontWeight.w600,
                                        fontSize: 14,
                                        color: _sortBy == 'rooms'
                                            ? IrisTokens.brand
                                            : (isDark
                                                  ? Colors.white.withValues(
                                                      alpha: 0.9,
                                                    )
                                                  : Colors.black87),
                                      ),
                                      isSelected: _sortBy == 'rooms',
                                      icon: Icon(
                                        Icons.meeting_room_rounded,
                                        size: 16,
                                        color: _sortBy == 'rooms'
                                            ? IrisTokens.brand
                                            : (isDark
                                                  ? Colors.white70
                                                  : Colors.black54),
                                      ),
                                      onTap: () {
                                        IrisHaptics.chipSelect();
                                        setState(() {
                                          _sortBy = 'rooms';
                                          _applyFiltersAndSort();
                                        });
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      );

                      return isM3
                          ? Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: isDark
                                  ? cs.surfaceContainerLow
                                  : cs.surfaceContainer,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: cs.outlineVariant.withValues(
                                  alpha: isDark ? 0.35 : 0.5,
                                ),
                                width: 1.0,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(
                                    alpha: isDark ? 0.16 : 0.04,
                                  ),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: filterSortContent,
                          )
                        : GlassCard(
                            enableOverlay: false,
                            enableShadow: false,
                            child: filterSortContent,
                          );
                      },
                    ),
                    const SizedBox(height: 16),

                    // Slots Header
                    Row(
                      children: [
                        Container(
                          width: 4,
                          height: 20,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [purple, purpleLight],
                            ),
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          'Available Slots',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: isDark ? Colors.white : Colors.black,
                            letterSpacing: 0.4,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '(${_filteredSuggestions.length})',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: (isDark ? Colors.white : Colors.black)
                                .withValues(alpha: 0.55),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),

                    // Slots List
                    ListView.separated(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _filteredSuggestions.length,
                      separatorBuilder: (_, index2) =>
                          const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        final suggestion = _filteredSuggestions[index];
                        return _buildMakeupSlotCard(suggestion, isDark);
                      },
                    ),
                    const SizedBox(height: 20),
                  ] else if (!_isLoading && _selectedTeacher != null) ...[
                    GlassCard(
                      borderRadius: 24,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 24,
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.info_rounded, color: amber, size: 20),
                          const SizedBox(width: 12),
                          const Expanded(
                            child: Text(
                              'No common free slots found. Try another teacher.',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
      if (widget.showDock)
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: SafeArea(
            top: false,
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 580),
                child: DashboardDock(
                  scrollController: _scrollController,
                  selectedIndex: 5,
                  onTeacher: _openTeacherFromMakeup,
                  onPortal: _openPortalFromMakeup,
                  onClasses: _openClassesFromMakeup,
                  onTools: _openToolsFromMakeup,
                  onMakeup: () {},
                  onAbout: _openAboutFromMakeup,
                ),
              ),
            ),
          ),
        ),
        ],
      ),
    );
  }

  Widget _buildMakeupSlotCard(MakeupSlotSuggestion suggestion, bool isDark) {
    final slotKey = _slotKey(suggestion);
    return MakeupSlotCard(
      suggestion: suggestion,
      isSelected: _selectedSuggestionKey == slotKey,
      isAdded: _existingMakeupSessionForSuggestion(suggestion) != null,
      regularConflict: _regularConflictForSuggestion(suggestion),
      overlappingMakeups: _overlappingMakeupsForSuggestion(suggestion),
      isDark: isDark,
      isM3: ThemeSignals.isMaterialYou,
      hasTeacher: _selectedTeacher != null,
      onTap: () => setState(() => _selectedSuggestionKey = slotKey),
      onAction: () => _handleSuggestionAction(suggestion),
    );
  }

  Widget _buildFilterChip({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required bool isDark,
  }) {
    final cs = Theme.of(context).colorScheme;
    final themeStyle = ThemeSignals.themeStyle.value;

    final pillBg = switch (themeStyle) {
      IrisThemeStyle.materialYou => isDark ? cs.surfaceContainerHigh : cs.surfaceContainerLow,
      IrisThemeStyle.notebook => NotebookTokens.cardSurface(isDark),
      IrisThemeStyle.line => LineTokens.cardSurface(isDark),
      IrisThemeStyle.poster => isDark ? const Color(0xFF1C1917) : const Color(0xFFF5F5F4),
      IrisThemeStyle.almanac => AlmanacTokens.canvas(isDark),
      IrisThemeStyle.editorialAcademic => EditorialTokens.cardSurface(isDark),
      _ => isDark
          ? IrisTokens.brand.withValues(alpha: 0.16)
          : Colors.white.withValues(alpha: 0.88),
    };

    final pillBorder = switch (themeStyle) {
      IrisThemeStyle.materialYou => Border.all(
          color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.6),
          width: 1.0,
        ),
      IrisThemeStyle.notebook => Border.all(
          color: NotebookTokens.gridLine(isDark),
          width: 1.0,
        ),
      IrisThemeStyle.line => Border.all(
          color: LineTokens.railLine(isDark),
          width: 1.2,
        ),
      IrisThemeStyle.poster => Border.all(
          color: PosterTokens.inkBorder(isDark),
          width: 1.5,
        ),
      IrisThemeStyle.almanac => Border.all(
          color: AlmanacTokens.inkRuleSubtle(isDark),
          width: 1.0,
        ),
      IrisThemeStyle.editorialAcademic => Border.all(
          color: EditorialTokens.cardBorder(isDark),
          width: 1.0,
        ),
      _ => Border.all(
          color: isDark
              ? IrisTokens.brand.withValues(alpha: 0.35)
              : IrisTokens.brand.withValues(alpha: 0.28),
          width: 1.0,
        ),
    };

    final textColor = switch (themeStyle) {
      IrisThemeStyle.materialYou => cs.onSurface,
      IrisThemeStyle.notebook => NotebookTokens.inkHeading(isDark),
      IrisThemeStyle.line => LineTokens.inkHeading(isDark),
      IrisThemeStyle.poster => PosterTokens.inkHeading(isDark),
      IrisThemeStyle.almanac => AlmanacTokens.inkHeading(isDark),
      IrisThemeStyle.editorialAcademic => EditorialTokens.inkHeading(isDark),
      _ => isDark ? Colors.white : Colors.black87,
    };

    return RepaintBoundary(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: pillBg,
            borderRadius: BorderRadius.circular(22),
            border: pillBorder,
            boxShadow: [
              if (!isDark && themeStyle == IrisThemeStyle.fluidGlass)
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.04),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 16, color: IrisTokens.brand),
              const SizedBox(width: 8),
              Flexible(
                child: Text(
                  label,
                  style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    color: textColor,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
