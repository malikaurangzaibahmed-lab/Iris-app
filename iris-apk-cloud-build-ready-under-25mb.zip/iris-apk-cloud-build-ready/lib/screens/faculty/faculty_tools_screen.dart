import 'package:flutter/material.dart';
import '../../core/glass.dart';
import '../../core/theme_signals.dart';
import '../../core/animations.dart';
import '../../core/models.dart';
import '../../core/omni_brain.dart';
import '../../services/ui_feedback.dart';
import '../../services/analytics_manager.dart';
import '../../services/helpdesk_faculty_service.dart';
import '../../services/remote_config_service.dart';
import '../../widgets/glass_card.dart';
import 'package:iris/widgets/effects/glass_container_transform.dart';
import 'package:iris/widgets/navigation/liquid_glass_sticky_header.dart';
import 'package:iris/screens/academics/room_finder_screen.dart';
import 'package:iris/screens/faculty/faculty_directory_screen.dart';
import 'package:iris/screens/academics/makeup_lecture_scheduler_screen.dart';
import 'package:iris/screens/academics/department_classes_screen.dart';
import 'package:iris/screens/tools/semester_schedule_screen.dart';
import 'package:iris/screens/tools/transport_schedule_screen.dart';
import 'package:iris/screens/tools/library_schedule_screen.dart';
import 'package:iris/screens/tools/uni_info_screen.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';

class FacultyToolItem {
  final String id;
  final String title;
  final String subtitle;
  final String description;
  final IconData icon;
  final Color accentColor;
  final String category;
  final String? badge;

  const FacultyToolItem({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.icon,
    required this.accentColor,
    required this.category,
    this.badge,
  });
}

class FacultyToolsScreen extends StatefulWidget {
  final OmniBrain brain;
  final UniversityMemory memory;
  final String teacherName;
  final FacultyProfile? profile;
  final ValueChanged<String>? onRoleChanged;
  final ValueChanged<String>? onBatchChanged;
  final ValueChanged<String>? onTeacherChanged;
  final Future<void> Function(ClassSession session)? onAddMakeupClass;
  final Future<void> Function(ClassSession session)? onRemoveMakeupClass;
  final ScrollController? scrollController;
  final String initialSearchQuery;

  const FacultyToolsScreen({
    super.key,
    required this.brain,
    required this.memory,
    required this.teacherName,
    this.profile,
    this.onRoleChanged,
    this.onBatchChanged,
    this.onTeacherChanged,
    this.onAddMakeupClass,
    this.onRemoveMakeupClass,
    this.scrollController,
    this.initialSearchQuery = '',
  });

  @override
  State<FacultyToolsScreen> createState() => _FacultyToolsScreenState();
}

class _FacultyToolsScreenState extends State<FacultyToolsScreen> {
  late final TextEditingController _searchController;
  late final FocusNode _searchFocusNode;
  String _searchQuery = '';
  String _activeCategory = 'All';

  static const List<String> _categories = [
    'All',
    'Scheduling',
    'Campus & Rooms',
  ];

  List<FacultyToolItem> get _tools {
    final period = RemoteConfigService.activeAcademicPeriod.value;
    final isExam = period == 'midterms' || period == 'finals';
    final isRamadan = period == 'ramadan';
    final isGala = period == 'sports_week';
    final examLabel = period == 'midterms' ? 'Midterms' : 'Finals';
    return _baseTools.map((t) {
      if (t.id == 'department_classes') {
        return FacultyToolItem(
          id: t.id,
          title: isExam
              ? 'Department Exam & Batch Matrix'
              : (isRamadan
                  ? 'Ramadan Batch Timetables'
                  : (isGala ? 'Sports Week Batch Classes' : t.title)),
          subtitle: isExam
              ? 'Browse $examLabel datesheets & student batches'
              : (isRamadan ? '1-hour compressed Ramadan schedules' : t.subtitle),
          description: t.description,
          icon: t.icon,
          accentColor: t.accentColor,
          category: t.category,
          badge: isExam ? '$examLabel Matrix' : (isRamadan ? 'Ramadan' : t.badge),
        );
      }
      if (t.id == 'room_finder') {
        return FacultyToolItem(
          id: t.id,
          title: isExam ? 'Exam Hall & Empty Room Radar' : t.title,
          subtitle: isExam ? 'Live $examLabel hall occupancy & vacant rooms' : t.subtitle,
          description: t.description,
          icon: t.icon,
          accentColor: t.accentColor,
          category: t.category,
          badge: isExam ? '$examLabel Halls' : t.badge,
        );
      }
      if (t.id == 'faculty_directory') {
        return FacultyToolItem(
          id: t.id,
          title: isExam ? 'Faculty & Invigilation Roster' : t.title,
          subtitle: isExam ? 'Colleague $examLabel supervision & cabin directory' : t.subtitle,
          description: t.description,
          icon: t.icon,
          accentColor: t.accentColor,
          category: t.category,
          badge: isExam ? 'Exam Roster' : t.badge,
        );
      }
      return t;
    }).toList();
  }

  static const List<FacultyToolItem> _baseTools = [
    FacultyToolItem(
      id: 'makeup_planner',
      title: 'Makeup Lecture Planner',
      subtitle: 'Mutual free slot & room discovery',
      description: 'Cross-reference student batch timetables, locate empty lecture halls, and book makeup classes seamlessly.',
      icon: Icons.event_repeat_rounded,
      accentColor: Color(0xFF8B5CF6),
      category: 'Scheduling',
      badge: 'Smart AI',
    ),
    FacultyToolItem(
      id: 'department_classes',
      title: 'Department Batch Timetables',
      subtitle: 'Browse all student class schedules',
      description: 'Lookup any program or semester timetable across Computer Science, Software Engineering, EE, and Management.',
      icon: Icons.school_rounded,
      accentColor: Color(0xFF38BDF8),
      category: 'Scheduling',
    ),
    FacultyToolItem(
      id: 'room_finder',
      title: 'Empty Room & Lab Finder',
      subtitle: 'Real-time campus room vacancy',
      description: 'Instantly discover vacant classrooms, computing labs, and study spaces across campus right now.',
      icon: Icons.meeting_room_rounded,
      accentColor: Color(0xFF00E5FF),
      category: 'Campus & Rooms',
      badge: 'Live',
    ),
    FacultyToolItem(
      id: 'faculty_directory',
      title: 'Faculty Directory & Locator',
      subtitle: 'Office cabins, contacts & timetables',
      description: 'Search fellow faculty members, cabin numbers, official extensions, and view their weekly lecture timetables.',
      icon: Icons.person_search_rounded,
      accentColor: Color(0xFF10B981),
      category: 'Campus & Rooms',
    ),
    FacultyToolItem(
      id: 'semester_schedule',
      title: 'Academic Calendar & Roadmap',
      subtitle: 'Milestones, exams & deadlines',
      description: 'Track official semester milestones, examination windows, holidays, and academic deadlines.',
      icon: Icons.calendar_month_rounded,
      accentColor: Color(0xFF84CC16),
      category: 'Scheduling',
    ),
    FacultyToolItem(
      id: 'transport_schedule',
      title: 'Campus Transit Network',
      subtitle: '7 bus routes, stops & staff contacts',
      description: 'Interactive route timelines, stop departure times, and direct driver/conductor contact numbers.',
      icon: Icons.directions_bus_rounded,
      accentColor: Color(0xFF06B6D4),
      category: 'Campus & Rooms',
    ),
    FacultyToolItem(
      id: 'library_schedule',
      title: 'Central Library & Study Hub',
      subtitle: 'Live status, reading zones & 346 books',
      description: 'Check live library operating status, prayer breaks, study halls, and browse the 346-book catalog.',
      icon: Icons.local_library_rounded,
      accentColor: Color(0xFF6366F1),
      category: 'Campus & Rooms',
    ),
    FacultyToolItem(
      id: 'uni_info',
      title: 'Campus Explorer & Directory',
      subtitle: 'Labs, 6 societies, 145 alumni & catalog',
      description: 'Explore lab attendant contacts, student society executive cabinets, distinguished alumni, and library books.',
      icon: Icons.explore_rounded,
      accentColor: Color(0xFFF59E0B),
      category: 'Campus & Rooms',
    ),
  ];

  void _onPeriodChanged() {
    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    AnalyticsManager().trackScreenView('faculty_tools_hub');
    _searchQuery = widget.initialSearchQuery;
    _searchController = TextEditingController(text: widget.initialSearchQuery);
    _searchFocusNode = FocusNode();
    RemoteConfigService.activeAcademicPeriod.addListener(_onPeriodChanged);
  }

  @override
  void dispose() {
    RemoteConfigService.activeAcademicPeriod.removeListener(_onPeriodChanged);
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  List<FacultyToolItem> get _filteredTools {
    final query = _searchQuery.trim().toLowerCase();
    return _tools.where((tool) {
      if (_activeCategory != 'All' && tool.category != _activeCategory) {
        return false;
      }
      if (query.isEmpty) return true;
      return tool.title.toLowerCase().contains(query) ||
          tool.subtitle.toLowerCase().contains(query) ||
          tool.description.toLowerCase().contains(query);
    }).toList();
  }

  void _handleToolTap(FacultyToolItem tool, {GlobalKey? originKey}) {
    IrisHaptics.actionMedium();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final teacherSessions = widget.brain.scheduleForTeacher(widget.teacherName);
    final taughtBatches = teacherSessions
        .map((s) => s.batchKey.batch.trim())
        .where((b) => b.isNotEmpty)
        .toSet()
        .toList()
      ..sort();
    final firstBatch = taughtBatches.isNotEmpty
        ? taughtBatches.first
        : (widget.profile?.department.isNotEmpty == true
            ? widget.profile!.department
            : 'BCS-1A');

    final originIcon = Container(
      width: 56,
      height: 56,
      decoration: BoxDecoration(
        color: tool.accentColor.withValues(alpha: isDark ? 0.28 : 0.16),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: tool.accentColor.withValues(alpha: isDark ? 0.45 : 0.30),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: tool.accentColor.withValues(alpha: isDark ? 0.32 : 0.18),
            blurRadius: 18,
            spreadRadius: 1,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Center(
        child: Icon(tool.icon, color: tool.accentColor, size: 28),
      ),
    );

    switch (tool.id) {
      case 'makeup_planner':
        pushGlassContainerMorphRoute(
          context,
          originKey: originKey,
          originIcon: originIcon,
          page: MakeupLectureScheduler(
            memory: widget.memory,
            brain: widget.brain,
            batch: firstBatch,
            teacherName: widget.teacherName,
            onAddMakeupClass: widget.onAddMakeupClass ?? (_) async {},
            onRemoveMakeupClass: widget.onRemoveMakeupClass,
            onRoleChanged: widget.onRoleChanged,
            onBatchChanged: widget.onBatchChanged,
            showDock: false,
          ),
          accentColor: tool.accentColor,
        );
        break;
      case 'room_finder':
        pushGlassContainerMorphRoute(
          context,
          originKey: originKey,
          originIcon: originIcon,
          page: RoomFinderScreen(memory: widget.memory),
          accentColor: tool.accentColor,
        );
        break;
      case 'faculty_directory':
        pushGlassContainerMorphRoute(
          context,
          originKey: originKey,
          originIcon: originIcon,
          page: FacultyDirectoryScreen(
            brain: widget.brain,
            onTeacherSelected: null,
            isSelectionMode: false,
            onRoleChanged: widget.onRoleChanged,
            onBatchChanged: widget.onBatchChanged,
            memory: widget.memory,
          ),
          accentColor: tool.accentColor,
        );
        break;
      case 'department_classes':
        final teacherSessions = widget.brain.scheduleForTeacher(widget.teacherName);
        final firstBatch = teacherSessions.isNotEmpty
            ? teacherSessions.first.batchKey.batch
            : '';
        pushGlassContainerMorphRoute(
          context,
          originKey: originKey,
          originIcon: originIcon,
          page: DepartmentClassesScreen(
            memory: widget.memory,
            currentBatch: firstBatch,
            teacherName: widget.teacherName,
            brain: widget.brain,
            showBatchShortcut: true,
            onBatchChanged: widget.onBatchChanged,
            onRoleChanged: widget.onRoleChanged,
            showDock: false,
          ),
          accentColor: tool.accentColor,
        );
        break;
      case 'semester_schedule':
        pushGlassContainerMorphRoute(
          context,
          originKey: originKey,
          originIcon: originIcon,
          page: SemesterScheduleScreen(batch: firstBatch),
          accentColor: tool.accentColor,
        );
        break;
      case 'transport_schedule':
        pushGlassContainerMorphRoute(
          context,
          originKey: originKey,
          originIcon: originIcon,
          page: const TransportScheduleScreen(),
          accentColor: tool.accentColor,
        );
        break;
      case 'library_schedule':
        pushGlassContainerMorphRoute(
          context,
          originKey: originKey,
          originIcon: originIcon,
          page: const LibraryScheduleScreen(),
          accentColor: tool.accentColor,
        );
        break;
      case 'uni_info':
        pushGlassContainerMorphRoute(
          context,
          originKey: originKey,
          originIcon: originIcon,
          page: const UniInfoScreen(),
          accentColor: tool.accentColor,
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;
    final filtered = _filteredTools;

    if (ThemeSignals.isAlmanac) {
      return _buildAlmanacClassifiedsView(context, isDark: isDark, filtered: filtered);
    }
    if (ThemeSignals.isEditorialAcademic) {
      return _buildEditorialClassifiedsView(context, isDark: isDark, filtered: filtered);
    }
    if (ThemeSignals.isNotebook) {
      return _buildNotebookClassifiedsView(context, isDark: isDark, filtered: filtered);
    }
    if (ThemeSignals.isLine) {
      return _buildLineClassifiedsView(context, isDark: isDark, filtered: filtered);
    }
    if (ThemeSignals.isPoster) {
      return _buildPosterClassifiedsView(context, isDark: isDark, filtered: filtered);
    }

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 840),
          child: NotificationListener<ScrollNotification>(
            onNotification: (notification) {
              if (notification is ScrollUpdateNotification) {
                final delta = notification.scrollDelta?.abs() ?? 0.0;
                final fast = delta > 16.0;
                if (IrisGlass.isFastScrolling.value != fast) {
                  IrisGlass.isFastScrolling.value = fast;
                }
              } else if (notification is ScrollEndNotification) {
                if (IrisGlass.isFastScrolling.value) {
                  IrisGlass.isFastScrolling.value = false;
                }
              }
              return false;
            },
            child: CustomScrollView(
              controller: widget.scrollController,
              physics: const ButterScrollPhysics(
                parent: AlwaysScrollableScrollPhysics(),
              ),
              cacheExtent: 450.0,
            slivers: [
              if (isM3) ...[
                // Top Safe Area Spacer
                const SliverToBoxAdapter(child: SizedBox(height: 52)),

                // Header Title Block
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                'Faculty Tools',
                                style: TextStyle(
                                  fontSize: 26,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: -0.6,
                                  color: cs.onSurface,
                                  height: 1.15,
                                ),
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                color: const Color(0xFF8B5CF6).withValues(alpha: 0.16),
                                borderRadius: BorderRadius.circular(999),
                                border: Border.all(
                                  color: const Color(0xFF8B5CF6).withValues(alpha: 0.35),
                                  width: 1.0,
                                ),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.auto_awesome_rounded, size: 12, color: Color(0xFF8B5CF6)),
                                  SizedBox(width: 5),
                                  Text(
                                    'Academic Suite',
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w800,
                                      color: Color(0xFF8B5CF6),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Classroom workflows, room intelligence & scheduling',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: cs.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ] else ...[
                SliverPersistentHeader(
                  pinned: true,
                  delegate: FacultyToolsLiquidGlassStickyHeaderDelegate(
                    topPadding: MediaQuery.paddingOf(context).top,
                    teacherName: widget.teacherName,
                    isDark: isDark,
                  ),
                ),
                const SliverToBoxAdapter(child: SizedBox(height: 8)),
              ],

              // Search Bar
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 14),
                  child: _buildSearchBar(isDark, isM3, cs),
                ),
              ),

              // Category Filter Chips
              SliverToBoxAdapter(
                child: SizedBox(
                  height: 38,
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    scrollDirection: Axis.horizontal,
                    itemCount: _categories.length,
                    separatorBuilder: (_, _) => const SizedBox(width: 8),
                    itemBuilder: (context, index) {
                      final cat = _categories[index];
                      final isSelected = _activeCategory == cat;
                      return ExpressiveInteractivePress(
                        onTap: () {
                          IrisHaptics.chipSelect();
                          setState(() {
                            _activeCategory = cat;
                          });
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? (isM3 ? cs.primary : const Color(0xFF8B5CF6))
                                : (isM3
                                    ? cs.surfaceContainerHigh
                                    : (isDark
                                        ? Colors.white.withValues(alpha: 0.08)
                                        : Colors.black.withValues(alpha: 0.05))),
                            borderRadius: BorderRadius.circular(999),
                            border: Border.all(
                              color: isSelected
                                  ? (isM3 ? cs.primary : const Color(0xFF8B5CF6))
                                  : (isM3
                                      ? cs.outlineVariant.withValues(alpha: isDark ? 0.3 : 0.5)
                                      : (isDark
                                          ? Colors.white.withValues(alpha: 0.12)
                                          : Colors.black.withValues(alpha: 0.08))),
                              width: 1.0,
                            ),
                          ),
                          child: Center(
                            child: Text(
                              cat,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                                color: isSelected
                                    ? (isM3 ? cs.onPrimary : Colors.white)
                                    : (isM3
                                        ? cs.onSurfaceVariant
                                        : (isDark
                                            ? Colors.white.withValues(alpha: 0.85)
                                            : const Color(0xFF334155))),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),

              const SliverToBoxAdapter(child: SizedBox(height: 16)),

              // Tool Cards Grid / List
              filtered.isEmpty
                  ? SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.all(40),
                        child: Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.search_off_rounded,
                                size: 48,
                                color: isDark ? Colors.white30 : Colors.black26,
                              ),
                              const SizedBox(height: 12),
                              Text(
                                'No matching faculty tools found',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                  color: isDark ? Colors.white70 : Colors.black54,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    )
                  : SliverPadding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 110),
                      sliver: SliverList(
                        delegate: SliverChildBuilderDelegate(
                          (context, index) {
                            final tool = filtered[index];
                            return RepaintBoundary(
                              key: ValueKey('faculty_tool_${tool.id}'),
                              child: Padding(
                                padding: const EdgeInsets.only(bottom: 12),
                                child: _buildToolCard(tool, isDark, isM3, cs),
                              ),
                            );
                          },
                          childCount: filtered.length,
                        ),
                      ),
                    ),
            ],
          ),
        ),
      ),
    ),
  );
  }

  Widget _buildSearchBar(bool isDark, bool isM3, ColorScheme cs) {
    if (isM3) {
      return Container(
        height: 48,
        decoration: BoxDecoration(
          color: cs.surfaceContainerHigh,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: cs.outlineVariant.withValues(alpha: isDark ? 0.3 : 0.5),
            width: 1.0,
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(
          children: [
            Icon(Icons.search_rounded, size: 20, color: cs.onSurfaceVariant),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _searchController,
                focusNode: _searchFocusNode,
                onChanged: (val) => setState(() => _searchQuery = val),
                style: TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w600,
                  color: cs.onSurface,
                ),
                decoration: InputDecoration(
                  hintText: 'Search tools & actions...',
                  hintStyle: TextStyle(
                    fontSize: 13.5,
                    color: cs.onSurfaceVariant.withValues(alpha: 0.65),
                  ),
                  border: InputBorder.none,
                  isDense: true,
                ),
              ),
            ),
            if (_searchQuery.isNotEmpty)
              IconButton(
                icon: const Icon(Icons.close_rounded, size: 18),
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
                onPressed: () {
                  _searchController.clear();
                  setState(() => _searchQuery = '');
                },
              ),
          ],
        ),
      );
    }

    return GlassCard(
      borderRadius: 24,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      child: Row(
        children: [
          Icon(Icons.search_rounded, size: 20, color: isDark ? Colors.white70 : Colors.black54),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              controller: _searchController,
              focusNode: _searchFocusNode,
              onChanged: (val) => setState(() => _searchQuery = val),
              style: TextStyle(
                fontSize: 13.5,
                fontWeight: FontWeight.w600,
                color: isDark ? Colors.white : Colors.black87,
              ),
              decoration: InputDecoration(
                hintText: 'Search tools & actions...',
                hintStyle: TextStyle(
                  fontSize: 13.5,
                  color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.40),
                ),
                border: InputBorder.none,
                isDense: true,
              ),
            ),
          ),
          if (_searchQuery.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.close_rounded, size: 18),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
              onPressed: () {
                _searchController.clear();
                setState(() => _searchQuery = '');
              },
            ),
        ],
      ),
    );
  }

  Widget _buildToolCard(
    FacultyToolItem tool,
    bool isDark,
    bool isM3,
    ColorScheme cs,
  ) {
    final cardKey = GlobalKey();

    final cardContent = Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(
            color: tool.accentColor.withValues(alpha: isDark ? 0.20 : 0.14),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: tool.accentColor.withValues(alpha: isDark ? 0.45 : 0.35),
              width: 1.0,
            ),
          ),
          child: Icon(tool.icon, color: tool.accentColor, size: 22),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      tool.title,
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.2,
                        color: isM3
                            ? cs.onSurface
                            : (isDark ? Colors.white : const Color(0xFF0F172A)),
                      ),
                    ),
                  ),
                  if (tool.badge != null) ...[
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: tool.accentColor.withValues(alpha: 0.16),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        tool.badge!,
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          color: tool.accentColor,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 3),
              Text(
                tool.subtitle,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: isM3
                      ? cs.primary
                      : (isDark ? tool.accentColor : const Color(0xFF475569)),
                ),
              ),
              const SizedBox(height: 5),
              Text(
                tool.description,
                style: TextStyle(
                  fontSize: 11.5,
                  fontWeight: FontWeight.w500,
                  height: 1.35,
                  color: isM3
                      ? cs.onSurfaceVariant.withValues(alpha: 0.85)
                      : (isDark
                          ? Colors.white.withValues(alpha: 0.65)
                          : const Color(0xFF64748B)),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Icon(
          Icons.arrow_forward_ios_rounded,
          size: 14,
          color: isM3
              ? cs.onSurfaceVariant.withValues(alpha: 0.4)
              : (isDark ? Colors.white24 : Colors.black26),
        ),
      ],
    );

    if (isM3) {
      return ExpressiveInteractivePress(
        onTap: () => _handleToolTap(tool, originKey: cardKey),
        child: Container(
          key: cardKey,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: isDark ? cs.surfaceContainer : cs.surfaceContainerLow,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.5),
              width: 1.0,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: isDark ? 0.20 : 0.05),
                blurRadius: 10,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: cardContent,
        ),
      );
    }

    return ExpressiveInteractivePress(
      onTap: () => _handleToolTap(tool, originKey: cardKey),
      child: GlassCard(
        key: cardKey,
        borderRadius: 22,
        accentColor: tool.accentColor,
        padding: const EdgeInsets.all(16),
        child: cardContent,
      ),
    );
  }

  // ===========================================================================
  // 1. ALMANAC BROADSIDE CLASSIFIEDS VIEW
  // ===========================================================================
  Widget _buildAlmanacClassifiedsView(
    BuildContext context, {
    required bool isDark,
    required List<FacultyToolItem> filtered,
  }) {
    final topPadding = MediaQuery.paddingOf(context).top;
    return Container(
      color: AlmanacTokens.canvas(isDark),
      child: CustomScrollView(
        controller: widget.scrollController,
        physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, topPadding + 14, 20, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('THE COMSATS ALMANAC', style: AlmanacTokens.serifHeadline(isDark, fontSize: 22)),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AlmanacTokens.accentTerracotta(isDark).withValues(alpha: isDark ? 0.25 : 0.15),
                          border: Border.all(color: AlmanacTokens.accentTerracotta(isDark), width: 1.0),
                        ),
                        child: Text(
                          'FACULTY DIRECTORY',
                          style: GoogleFonts.spaceMono(
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            color: AlmanacTokens.accentTerracotta(isDark),
                            letterSpacing: 0.8,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Official academic operations, classroom scheduling & directory services',
                    style: GoogleFonts.spaceMono(
                      fontSize: 11,
                      color: AlmanacTokens.inkMuted(isDark),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Column(
                    children: [
                      Container(height: 1.2, color: AlmanacTokens.inkRule(isDark)),
                      const SizedBox(height: 2),
                      Container(height: 1.2, color: AlmanacTokens.inkRule(isDark)),
                    ],
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final tool = filtered[index];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: ExpressiveInteractivePress(
                      onTap: () => _handleToolTap(tool),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AlmanacTokens.cardSurface(isDark),
                          border: Border.all(color: AlmanacTokens.inkRule(isDark), width: 1.2),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                color: tool.accentColor.withValues(alpha: isDark ? 0.2 : 0.12),
                                border: Border.all(color: tool.accentColor.withValues(alpha: 0.6), width: 1.0),
                              ),
                              child: Icon(tool.icon, color: tool.accentColor, size: 22),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Text(
                                          tool.title.toUpperCase(),
                                          style: GoogleFonts.spaceMono(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w700,
                                            color: AlmanacTokens.inkHeading(isDark),
                                          ),
                                        ),
                                      ),
                                      if (tool.badge != null)
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                          decoration: BoxDecoration(
                                            color: tool.accentColor.withValues(alpha: 0.15),
                                            border: Border.all(color: tool.accentColor, width: 0.8),
                                          ),
                                          child: Text(
                                            tool.badge!,
                                            style: GoogleFonts.spaceMono(
                                              fontSize: 9,
                                              fontWeight: FontWeight.w700,
                                              color: tool.accentColor,
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    tool.subtitle,
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: AlmanacTokens.accentTerracotta(isDark),
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    tool.description,
                                    style: TextStyle(
                                      fontSize: 12,
                                      height: 1.35,
                                      color: AlmanacTokens.inkMuted(isDark),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
                childCount: filtered.length,
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 120)),
        ],
      ),
    );
  }

  // ===========================================================================
  // 2. EDITORIAL ACADEMIC GAZETTE VIEW
  // ===========================================================================
  Widget _buildEditorialClassifiedsView(
    BuildContext context, {
    required bool isDark,
    required List<FacultyToolItem> filtered,
  }) {
    final topPadding = MediaQuery.paddingOf(context).top;
    return Container(
      color: EditorialTokens.canvas(isDark),
      child: CustomScrollView(
        controller: widget.scrollController,
        physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, topPadding + 14, 20, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'FACULTY COMPENDIUM',
                        style: GoogleFonts.playfairDisplay(
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.4,
                          color: EditorialTokens.inkHeading(isDark),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: EditorialTokens.accentUpcoming.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(color: EditorialTokens.accentUpcoming, width: 1.0),
                        ),
                        child: Text(
                          'COMSATS REGISTRY',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            color: EditorialTokens.accentUpcoming,
                            letterSpacing: 0.8,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Official academic registry & pedagogical utilities catalogue',
                    style: TextStyle(
                      fontSize: 12.5,
                      fontStyle: FontStyle.italic,
                      color: EditorialTokens.inkMuted(isDark),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Divider(color: EditorialTokens.cardBorder(isDark), thickness: 1.2),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final tool = filtered[index];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: ExpressiveInteractivePress(
                      onTap: () => _handleToolTap(tool),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: EditorialTokens.cardSurface(isDark),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: EditorialTokens.cardBorder(isDark), width: 1.2),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: isDark ? 0.3 : 0.05),
                              blurRadius: 6,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                color: tool.accentColor.withValues(alpha: isDark ? 0.22 : 0.14),
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(color: tool.accentColor.withValues(alpha: 0.5)),
                              ),
                              child: Icon(tool.icon, color: tool.accentColor, size: 22),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    tool.title,
                                    style: GoogleFonts.playfairDisplay(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700,
                                      color: EditorialTokens.inkHeading(isDark),
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    tool.subtitle,
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: EditorialTokens.accentUpcoming,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    tool.description,
                                    style: TextStyle(
                                      fontSize: 12,
                                      height: 1.35,
                                      color: EditorialTokens.inkMuted(isDark),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
                childCount: filtered.length,
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 120)),
        ],
      ),
    );
  }

  // ===========================================================================
  // 3. NOTEBOOK CORKBOARD PIN-UP VIEW
  // ===========================================================================
  Widget _buildNotebookClassifiedsView(
    BuildContext context, {
    required bool isDark,
    required List<FacultyToolItem> filtered,
  }) {
    final topPadding = MediaQuery.paddingOf(context).top;
    return Container(
      color: NotebookTokens.canvas(isDark),
      child: CustomScrollView(
        controller: widget.scrollController,
        physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, topPadding + 14, 20, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Faculty Study Board 📌',
                        style: GoogleFonts.kalam(
                          fontSize: 22,
                          fontWeight: FontWeight.w700,
                          color: NotebookTokens.inkHeading(isDark),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: NotebookTokens.redDoodle(isDark).withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(color: NotebookTokens.redDoodle(isDark), width: 1.0),
                        ),
                        child: Text(
                          'DESK MEMOS',
                          style: GoogleFonts.kalam(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: NotebookTokens.redDoodle(isDark),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Notes, empty labs & mutual free scheduling tools',
                    style: GoogleFonts.kalam(
                      fontSize: 13,
                      color: NotebookTokens.inkMuted(isDark),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Divider(color: NotebookTokens.gridLine(isDark), thickness: 1.5),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final tool = filtered[index];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: ExpressiveInteractivePress(
                      onTap: () => _handleToolTap(tool),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: NotebookTokens.cardSurface(isDark),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: NotebookTokens.gridLine(isDark), width: 1.5),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
                              blurRadius: 6,
                              offset: const Offset(2, 3),
                            ),
                          ],
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 42,
                              height: 42,
                              decoration: BoxDecoration(
                                color: tool.accentColor.withValues(alpha: isDark ? 0.25 : 0.16),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: tool.accentColor.withValues(alpha: 0.5)),
                              ),
                              child: Icon(tool.icon, color: tool.accentColor, size: 22),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    tool.title,
                                    style: GoogleFonts.kalam(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700,
                                      color: NotebookTokens.inkHeading(isDark),
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    tool.subtitle,
                                    style: GoogleFonts.kalam(
                                      fontSize: 12.5,
                                      color: NotebookTokens.redDoodle(isDark),
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    tool.description,
                                    style: TextStyle(
                                      fontSize: 12,
                                      height: 1.35,
                                      color: NotebookTokens.inkMuted(isDark),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
                childCount: filtered.length,
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 120)),
        ],
      ),
    );
  }

  // ===========================================================================
  // 4. SUBWAY LINE TRANSIT DIRECTORY VIEW
  // ===========================================================================
  Widget _buildLineClassifiedsView(
    BuildContext context, {
    required bool isDark,
    required List<FacultyToolItem> filtered,
  }) {
    final topPadding = MediaQuery.paddingOf(context).top;
    return Container(
      color: LineTokens.canvas(isDark),
      child: CustomScrollView(
        controller: widget.scrollController,
        physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, topPadding + 14, 20, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('METRO INTERCHANGE', style: LineTokens.heroMonDate(isDark)),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: LineTokens.subwayYellow,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          'PLATFORM TOOLS',
                          style: GoogleFonts.archivoBlack(
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            color: LineTokens.ledBlack,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Campus transit, faculty scheduling & timetable routing stations',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 12,
                      color: LineTokens.inkMuted(isDark),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Divider(color: LineTokens.railLine(isDark), thickness: 2.0),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final tool = filtered[index];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: ExpressiveInteractivePress(
                      onTap: () => _handleToolTap(tool),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: LineTokens.cardSurface(isDark),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: LineTokens.railLine(isDark), width: 1.5),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                color: tool.accentColor.withValues(alpha: isDark ? 0.25 : 0.16),
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(color: tool.accentColor.withValues(alpha: 0.6)),
                              ),
                              child: Icon(tool.icon, color: tool.accentColor, size: 22),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    tool.title.toUpperCase(),
                                    style: LineTokens.stationName(isDark),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    tool.subtitle,
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                      color: LineTokens.subwayGreen,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    tool.description,
                                    style: TextStyle(
                                      fontSize: 12,
                                      height: 1.35,
                                      color: LineTokens.inkMuted(isDark),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
                childCount: filtered.length,
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 120)),
        ],
      ),
    );
  }

  // ===========================================================================
  // 5. SWISS POSTER BRUTALIST DIRECTORY VIEW
  // ===========================================================================
  Widget _buildPosterClassifiedsView(
    BuildContext context, {
    required bool isDark,
    required List<FacultyToolItem> filtered,
  }) {
    final topPadding = MediaQuery.paddingOf(context).top;
    final borderColor = PosterTokens.inkBorder(isDark);
    return Container(
      color: PosterTokens.canvas(isDark),
      child: CustomScrollView(
        controller: widget.scrollController,
        physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, topPadding + 14, 20, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'FACULTY SUITE //',
                        style: GoogleFonts.archivoBlack(
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.8,
                          color: PosterTokens.inkHeading(isDark),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: PosterTokens.orangeHero,
                          border: Border.all(color: borderColor, width: 2.0),
                          boxShadow: [
                            BoxShadow(
                              offset: const Offset(2, 2),
                              color: borderColor,
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: Text(
                          '2026 EDITION',
                          style: GoogleFonts.archivoBlack(
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Campus infrastructure, room telemetry & timetable coordination',
                    style: GoogleFonts.spaceMono(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w600,
                      color: PosterTokens.inkMuted(isDark),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Container(height: 2.5, color: borderColor),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final tool = filtered[index];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: ExpressiveInteractivePress(
                      onTap: () => _handleToolTap(tool),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: isDark ? const Color(0xFF161C24) : Colors.white,
                          border: Border.all(color: borderColor, width: 2.2),
                          boxShadow: PosterTokens.extrudedBlockShadow(isDark, offset: 4.0),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                color: tool.accentColor.withValues(alpha: isDark ? 0.3 : 0.2),
                                border: Border.all(color: borderColor, width: 1.8),
                              ),
                              child: Icon(tool.icon, color: tool.accentColor, size: 24),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    tool.title.toUpperCase(),
                                    style: PosterTokens.classTitle(isDark),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    tool.subtitle,
                                    style: GoogleFonts.spaceMono(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                      color: PosterTokens.orangeHero,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    tool.description,
                                    style: GoogleFonts.plusJakartaSans(
                                      fontSize: 12,
                                      height: 1.35,
                                      color: PosterTokens.inkMuted(isDark),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
                childCount: filtered.length,
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 120)),
        ],
      ),
    );
  }
}
