import '../../core/glass.dart';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/tokens.dart';
import '../../core/vital_theme.dart';
import '../../core/models.dart';
import '../../core/app_signals.dart';
import '../../widgets/effects/glass_container_transform.dart';
import '../../core/theme_signals.dart';
import 'package:iris/widgets/controls/glowing_input_wrapper.dart';
import '../../services/ui_feedback.dart';
import '../../services/helpdesk_faculty_service.dart';
import '../../widgets/glass_card.dart';
import '../../services/notification_service.dart';
import 'package:iris/widgets/controls/iris_liquid_button.dart';
import '../../widgets/iris_components.dart';
import '../../widgets/setup/setup_widgets.dart';
import '../../core/animations.dart';
import '../../core/repeater_planner_engine.dart';
import 'package:iris/screens/student/repeater_course_planner_screen.dart';
import 'package:iris/screens/settings/theme_selector_screen.dart';

typedef OnboardingCompleteCallback =
    Function(String role, String name, String value);

/// Ultra-Fluid Onboarding Setup Wizard & Faculty Selector for IRIS.
class OnboardingWizard extends StatefulWidget {
  final UniversityMemory memory;
  final OnboardingCompleteCallback onComplete;
  final ValueChanged<String>? onSetThemeMode;
  final String? currentThemeMode;

  const OnboardingWizard({
    super.key,
    required this.memory,
    required this.onComplete,
    this.onSetThemeMode,
    this.currentThemeMode,
  });

  @override
  State<OnboardingWizard> createState() => _OnboardingWizardState();
}

class _OnboardingWizardState extends State<OnboardingWizard>
    with TickerProviderStateMixin {
  late final AnimationController _controller;
  late final AnimationController _welcomeController;
  late final Animation<double> _welcomeAnimation;
  bool _isWelcoming = false;
  String _welcomeName = '';
  String _welcomeBatchOrRole = '';

  // Wizard steps:
  // 0: Role Selection (Student / Faculty)
  // 1: Profile Selection (Student Batch / Faculty Directory Profile)
  // 2: Visual Experience & System Preferences (First-time Theme Selection)
  // 3: Neural Sync Loader
  int _currentStep = 0;

  String? _role; // 'student' or 'faculty'
  String? _selectedRoleMorph;
  final GlobalKey _studentCardKey = GlobalKey();
  final GlobalKey _facultyCardKey = GlobalKey();

  String _name = '';
  String? _program;
  String? _intake;
  String? _section;
  String _rollNo = '';

  // Faculty selections & live helpdesk list
  String? _selectedTeacher;
  String _teacherSearchQuery = '';
  final TextEditingController _teacherSearchController =
      TextEditingController();
  List<FacultyProfile> _facultyList = [];
  bool _loadingFaculty = false;

  // Theme & System Preference Toggles (First-Time Setup)
  IrisThemeStyle _selectedThemeStyle = IrisThemeStyle.materialYou;
  Color _selectedSeedColor = const Color(0xFF0061A4);
  String _selectedThemeMode = 'system';
  bool _notifClassAlerts = true;
  bool _useEcoMode = false;

  // Repeater / Custom Course Selection state
  bool _hasCustomRepeaterSchedule = false;
  int _customRepeaterCourseCount = 0;

  @override
  void initState() {
    super.initState();
    _selectedThemeStyle = ThemeSignals.themeStyle.value;
    _selectedSeedColor = ThemeSignals.m3eSeedColor.value;
    _selectedThemeMode = widget.currentThemeMode ?? 'system';
    _useEcoMode = ThemeSignals.useMinimalTheme.value;
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    );

    // Smooth, fluid true container morphing controller
    _welcomeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 650),
    );
    _welcomeAnimation = CurvedAnimation(
      parent: _welcomeController,
      curve: const Cubic(0.12, 0.9, 0.18, 1.0),
    );

    _fetchLiveFacultyProfiles();
    _checkRepeaterStatus();
  }

  Future<void> _checkRepeaterStatus() async {
    final active = await RepeaterScheduleStorage.isRepeaterActive();
    final count = await RepeaterScheduleStorage.getCustomCourseCount();
    if (mounted) {
      setState(() {
        _hasCustomRepeaterSchedule = active;
        _customRepeaterCourseCount = count;
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _welcomeController.dispose();
    _teacherSearchController.dispose();
    super.dispose();
  }

  Future<void> _fetchLiveFacultyProfiles() async {
    final timetableTeachers = widget.memory.allTeachers();
    if (timetableTeachers.isNotEmpty) {
      final instant = HelpdeskFacultyService.buildPureTimetableProfiles(
        timetableTeachers: timetableTeachers,
      )..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
      if (instant.isNotEmpty && mounted) {
        setState(() {
          _facultyList = instant;
          _loadingFaculty = false;
        });
      }
    } else {
      setState(() => _loadingFaculty = true);
    }
    try {
      final service = HelpdeskFacultyService();
      final payload = await service.fetchLiveFirstWithFallbackPayload();
      if (mounted) {
        final merged = timetableTeachers.isNotEmpty
            ? HelpdeskFacultyService.buildPureTimetableProfiles(
                timetableTeachers: timetableTeachers,
                enrichmentProfiles: payload.items,
              )
            : List<FacultyProfile>.from(payload.items);
        merged.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
        setState(() {
          if (merged.isNotEmpty) _facultyList = merged;
          _loadingFaculty = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loadingFaculty = false);
    }
  }

  void _nextStep() {
    if (_currentStep < 2) {
      IrisHaptics.actionMedium();
      setState(() => _currentStep++);
    }
  }

  void _prevStep() {
    if (_currentStep > 0) {
      IrisHaptics.actionMedium();
      setState(() {
        _currentStep--;
        if (_currentStep == 0) {
          _role = null;
          _selectedRoleMorph = null;
        }
      });
    }
  }

  void _showFacultyConfirmationDialog(FacultyProfile profile) {
    IrisHaptics.selectionClick();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF0F172A) : Colors.white,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
            border: Border.all(
              color: IrisTokens.blue.withValues(alpha: 0.3),
              width: 1.5,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 20),
              CircleAvatar(
                radius: 36,
                backgroundColor: IrisTokens.blue.withValues(alpha: 0.2),
                child: Text(
                  profile.name.isNotEmpty ? profile.name[0].toUpperCase() : 'F',
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    color: IrisTokens.blue,
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                profile.name,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  color: isDark ? Colors.white : Colors.black,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                '${profile.department} • ${profile.location}',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: (isDark ? Colors.white : Colors.black).withValues(
                    alpha: 0.6,
                  ),
                ),
              ),
              const SizedBox(height: 24),

              SizedBox(
                width: double.infinity,
                child: IrisLiquidButton(
                  text: 'CONFIRM PROFILE & CONTINUE',
                  icon: Icons.check_circle_rounded,
                  onTap: () {
                    Navigator.pop(context);
                    setState(() {
                      _selectedTeacher = profile.name;
                    });
                    _nextStep(); // Proceed directly to Notification Preferences Step!
                  },
                  color: IrisTokens.blue,
                  height: 52,
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  String _resolveSelectedBatchKey() {
    if (_program == null || _section == null) return '';
    final progUpper = _program!.toUpperCase().trim();
    final intakeUpper = _intake?.toUpperCase().trim();
    final secUpper = _section!.toUpperCase().trim();

    // 1. Exact match with program, intake, and section (prioritize active or highest semester)
    String? bestMatch;
    int bestSemester = -1;
    final targetSem = intakeUpper != null
        ? BatchKey.calculateSemester(intakeUpper)
        : 0;

    for (final batch in widget.memory.allBatches) {
      final key = BatchKey.parse(batch);
      if (key.program.toUpperCase().trim() == progUpper &&
          (intakeUpper == null ||
              key.intake.toUpperCase().trim() == intakeUpper) &&
          key.section.toUpperCase().trim() == secUpper) {
        if (targetSem > 0 && key.semester == targetSem) {
          return batch; // Perfect active semester match
        }
        if (key.semester > bestSemester) {
          bestSemester = key.semester;
          bestMatch = batch;
        }
      }
    }
    if (bestMatch != null) return bestMatch;

    // 2. Program + section match (handles cohort batches like BBA-B21, BME-01)
    for (final batch in widget.memory.allBatches) {
      final key = BatchKey.parse(batch);
      if (key.program.toUpperCase().trim() == progUpper &&
          key.section.toUpperCase().trim() == secUpper) {
        return batch;
      }
    }

    if (intakeUpper != null) {
      final sem = BatchKey.calculateSemester(intakeUpper);
      return '$intakeUpper-$progUpper-$sem-$secUpper';
    }
    return '$progUpper-$secUpper';
  }

  Future<void> _finishSetupAndWelcome() async {
    IrisHaptics.actionHeavy();
    final prefs = await SharedPreferences.getInstance();

    if (_role == 'faculty') {
      final teacherName = _selectedTeacher ?? 'Faculty Member';
      await prefs.setString('user_role', 'faculty');
      await prefs.setString('active_role', 'faculty');
      await prefs.setString('faculty_user_name', teacherName);
      await prefs.setString('faculty_teacher', teacherName);
      await prefs.setString('student_name', teacherName);
    } else {
      final batchKey = _resolveSelectedBatchKey();
      final studentName = _name.trim().isNotEmpty ? _name.trim() : 'Student';
      await prefs.setString('user_role', 'student');
      await prefs.setString('active_role', 'student');
      await prefs.setString('student_name', studentName);
      await prefs.setString('student_user_name', studentName);
      await prefs.setString('user_name', studentName);
      await prefs.setString('name', studentName);
      await prefs.setString('student_batch', batchKey);
      await prefs.setString('selected_batch', batchKey);
      await prefs.setString('user_batch', batchKey);
      await prefs.setString('student_roll_no', _rollNo);
      await prefs.setString('student_registration_id', _rollNo);
    }

    await prefs.setBool('notif_class_alerts', _notifClassAlerts);
    await prefs.setBool('notifications_enabled', _notifClassAlerts);
    await prefs.setBool('persistent_notification_enabled', _notifClassAlerts);
    await prefs.setBool('lecture_reminders_enabled', _notifClassAlerts);
    await prefs.setBool('class_alerts_enabled', _notifClassAlerts);
    await prefs.setBool('class_reminders', _notifClassAlerts);
    await prefs.setBool('is_first_time', false);
    await prefs.setBool('setup_completed', true);
    await prefs.setBool('use_minimal_ui', _useEcoMode);
    ThemeSignals.useMinimalTheme.value = _useEcoMode;

    await ThemeSignals.setThemeStyle(_selectedThemeStyle);
    if (_selectedThemeStyle == IrisThemeStyle.materialYou) {
      await ThemeSignals.setSeedColor(_selectedSeedColor);
    }
    await prefs.setString('theme_mode', _selectedThemeMode);
    widget.onSetThemeMode?.call(_selectedThemeMode);

    await NotificationSyncService.instance.setPersistentTrackerEnabled(_notifClassAlerts);
    await NotificationSyncService.instance.setLectureRemindersEnabled(_notifClassAlerts);

    final targetRole = _role == 'faculty' ? 'faculty' : 'student';
    final targetName = _role == 'faculty'
        ? (_selectedTeacher ?? 'Faculty Member')
        : (_name.trim().isNotEmpty ? _name.trim() : 'Student');
    final targetValue = _role == 'faculty'
        ? (_selectedTeacher ?? 'Faculty Member')
        : _resolveSelectedBatchKey();

    await AppSignals.setRole(targetRole, userName: targetName);
    if (targetRole == 'student' && targetValue.isNotEmpty) {
      await AppSignals.setBatch(targetValue);
    }

    if (mounted) {
      setState(() {
        _isWelcoming = true;
        _welcomeName = targetName;
        _welcomeBatchOrRole = _role == 'faculty'
            ? 'FACULTY PORTAL'
            : 'BATCH $targetValue';
      });
      _welcomeController.forward(from: 0.0);
    }

    // Smooth, fluid container morphing before entering campus workspace
    await Future.delayed(const Duration(milliseconds: 900));

    if (mounted) {
      widget.onComplete(targetRole, targetName, targetValue);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        fit: StackFit.expand,
        children: [
          ObsidianPulse(isDark: isDark),
          SafeArea(
            child: Align(
              alignment: Alignment.topCenter,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 680),
                child: Column(
                  children: [
                    // Top Progress Bar
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 12,
                      ),
                      child: Row(
                        children: List.generate(3, (index) {
                          final isActive = index <= _currentStep;
                          return Expanded(
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 300),
                              height: 4,
                              margin: const EdgeInsets.symmetric(horizontal: 3),
                              decoration: BoxDecoration(
                                color: isActive
                                    ? (_role == 'faculty'
                                          ? IrisTokens.blue
                                          : IrisTokens.brand)
                                    : (isDark
                                          ? Colors.white12
                                          : Colors.black12),
                                borderRadius: BorderRadius.circular(2),
                              ),
                            ),
                          );
                        }),
                      ),
                    ),

                    Expanded(
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 320),
                        child: _buildStepContent(isDark),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // True Container Morphing Welcoming Overlay
          if (_isWelcoming)
            _buildWelcomingContainerMorph(isDark, cs),
        ],
      ),
    );
  }

  Widget _buildStepContent(bool isDark) {
    switch (_currentStep) {
      case 0:
        return _buildStep0RoleSelection(isDark);
      case 1:
        return _buildStep1ProfileSetup(isDark);
      case 2:
      default:
        return _buildStep2NotificationPreferences(isDark);
    }
  }

  // STEP 0: CREATIVE & AMAZING ROLE SELECTION (COMPACT & ZERO-SCROLL)
  Widget _buildStep0RoleSelection(bool isDark) {
    final cs = Theme.of(context).colorScheme;
    final isM3 = ThemeSignals.isMaterialYou;

    return SingleChildScrollView(
      key: const ValueKey(0),
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Step status tag
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3.5),
            decoration: BoxDecoration(
              color: isM3
                  ? cs.primaryContainer.withValues(alpha: isDark ? 0.35 : 0.6)
                  : IrisTokens.brand.withValues(alpha: isDark ? 0.2 : 0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: isM3
                    ? cs.primary.withValues(alpha: 0.25)
                    : IrisTokens.brand.withValues(alpha: 0.3),
                width: 0.8,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.auto_awesome_rounded,
                  size: 11,
                  color: isM3 ? cs.primary : IrisTokens.brand,
                ),
                const SizedBox(width: 4),
                Text(
                  'IDENTITY · STEP 1',
                  style: TextStyle(
                    fontSize: 9.5,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.8,
                    color: isM3 ? cs.primary : IrisTokens.brand,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 6),

          // Expressive Headline
          Text(
            'Who are you?',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.5,
              color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
            ),
          ),
          const SizedBox(height: 2),
          Text(
            'Choose your portal to personalize your schedule & cockpit.',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              height: 1.25,
              color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
            ),
          ),
          const SizedBox(height: 12),

          // 1. STUDENT HERO BENTO CARD
          _buildCreativeRoleCard(
            key: _studentCardKey,
            roleId: 'student',
            title: 'Student Portal',
            badge: 'STUDENT COCKPIT',
            tagline: 'Timetables, clash radar & room finder',
            icon: Icons.school_rounded,
            accentColor: IrisTokens.brand,
            gradientColors: [const Color(0xFF10B981), const Color(0xFF06B6D4)],
            previewTitle: 'Automata & Formal Languages',
            previewRoom: 'Room 4-12 • CS-6A',
            chips: const ['Timetable', 'Room Radar', 'Clashes'],
            buttonLabel: 'CONTINUE AS STUDENT',
            isDark: isDark,
            isM3: isM3,
            cs: cs,
          ),
          const SizedBox(height: 10),

          // 2. FACULTY HERO BENTO CARD
          _buildCreativeRoleCard(
            key: _facultyCardKey,
            roleId: 'faculty',
            title: 'Faculty Portal',
            badge: 'FACULTY & STAFF',
            tagline: 'Teaching rosters, staff directory & makeups',
            icon: Icons.badge_rounded,
            accentColor: IrisTokens.blue,
            gradientColors: [const Color(0xFF3B82F6), const Color(0xFF8B5CF6)],
            previewTitle: 'Advanced Algorithms',
            previewRoom: 'Room C-03 • CS Dept',
            chips: const ['Roster', 'Staff Directory', 'Makeups'],
            buttonLabel: 'CONTINUE AS FACULTY',
            isDark: isDark,
            isM3: isM3,
            cs: cs,
          ),
          const SizedBox(height: 10),

          // Reassurance Footer Pill
          Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
              decoration: BoxDecoration(
                color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.04),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.06),
                  width: 0.8,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.swap_horiz_rounded,
                    size: 13,
                    color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white54 : Colors.black45),
                  ),
                  const SizedBox(width: 5),
                  Text(
                    'You can switch roles anytime in Settings',
                    style: TextStyle(
                      fontSize: 10.5,
                      fontWeight: FontWeight.w600,
                      color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCreativeRoleCard({
    required GlobalKey key,
    required String roleId,
    required String title,
    required String badge,
    required String tagline,
    required IconData icon,
    required Color accentColor,
    required List<Color> gradientColors,
    required String previewTitle,
    required String previewRoom,
    required List<String> chips,
    required String buttonLabel,
    required bool isDark,
    required bool isM3,
    required ColorScheme cs,
  }) {
    return CreativeRoleCard(
      cardKey: key,
      roleId: roleId,
      title: title,
      badge: badge,
      tagline: tagline,
      icon: icon,
      accentColor: accentColor,
      gradientColors: gradientColors,
      previewTitle: previewTitle,
      previewRoom: previewRoom,
      chips: chips,
      buttonLabel: buttonLabel,
      isDark: isDark,
      isM3: isM3,
      cs: cs,
      isSelected: _selectedRoleMorph == roleId,
      onTap: () {
        IrisHaptics.actionMedium();
        setState(() => _selectedRoleMorph = roleId);
        _role = roleId;
        Future.delayed(const Duration(milliseconds: 240), () {
          if (mounted) {
            setState(() => _selectedRoleMorph = null);
            _nextStep();
          }
        });
      },
    );
  }

  // STEP 1: PROFILE SETUP
  Widget _buildStep1ProfileSetup(bool isDark) {
    return Padding(
      key: const ValueKey(1),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              IconButton(
                onPressed: _prevStep,
                icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
              ),
              const SizedBox(width: 8),
              Text(
                _role == 'faculty' ? 'Faculty Directory' : 'Select Your Batch',
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.only(left: 44),
            child: Text(
              _role == 'faculty'
                  ? 'Tap your faculty profile card to confirm & proceed'
                  : 'Select program, active semester, section & roll number',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: (isDark ? Colors.white : Colors.black).withValues(
                  alpha: 0.6,
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: _role == 'faculty'
                ? _buildFacultyDirectoryListWidget(isDark)
                : _buildStudentSelectorWidget(isDark),
          ),
        ],
      ),
    );
  }

  Widget _buildFacultyDirectoryListWidget(bool isDark) {
    final qLower = _teacherSearchQuery.toLowerCase();
    final qTokens = HelpdeskFacultyService.extractCoreTokens(
      _teacherSearchQuery,
    );

    final matched = _facultyList.where((f) {
      if (qLower.isEmpty) return true;
      if (f.name.toLowerCase().contains(qLower) ||
          f.department.toLowerCase().contains(qLower) ||
          f.location.toLowerCase().contains(qLower)) {
        return true;
      }
      if (HelpdeskFacultyService.isNameMatch(
        f.name,
        _teacherSearchQuery,
        threshold: 0.65,
      )) {
        return true;
      }
      final fTokens = HelpdeskFacultyService.extractCoreTokens(
        '${f.name} ${f.department}',
      );
      if (qTokens.isNotEmpty && qTokens.every((qt) => fTokens.contains(qt))) {
        return true;
      }
      return false;
    }).toList();

    return Column(
      children: [
        // Clean Search Field
        IrisTextField(
          controller: _teacherSearchController,
          isDark: isDark,
          hint: 'Search faculty by name, department...',
          prefixIcon: Icons.search_rounded,
          onChanged: (val) => setState(() => _teacherSearchQuery = val.trim()),
        ),
        const SizedBox(height: 12),

        Expanded(
          child: _loadingFaculty
              ? const Center(
                  child: CircularProgressIndicator(color: IrisTokens.blue),
                )
              : matched.isEmpty
              ? Center(
                  child: Text(
                    'No matching faculty profiles found',
                    style: TextStyle(
                      color: (isDark ? Colors.white : Colors.black).withValues(
                        alpha: 0.4,
                      ),
                    ),
                  ),
                )
              : ListView.builder(
                  physics: const BouncingScrollPhysics(),
                  itemCount: matched.length,
                  itemBuilder: (context, index) {
                    final item = matched[index];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: InkWell(
                        onTap: () => _showFacultyConfirmationDialog(item),
                        borderRadius: BorderRadius.circular(16),
                        child: GlassCard(
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            children: [
                              CircleAvatar(
                                radius: 20,
                                backgroundColor: IrisTokens.blue.withValues(
                                  alpha: 0.2,
                                ),
                                child: Text(
                                  item.name.isNotEmpty
                                      ? item.name[0].toUpperCase()
                                      : 'F',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    color: isDark ? Colors.white : Colors.black,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      item.name,
                                      style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w800,
                                        color: isDark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                    ),
                                    Text(
                                      '${item.department} • ${item.location}',
                                      style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w500,
                                        color:
                                            (isDark
                                                    ? Colors.white
                                                    : Colors.black)
                                                .withValues(alpha: 0.6),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const Icon(
                                Icons.arrow_forward_ios_rounded,
                                size: 14,
                                color: IrisTokens.blue,
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildStudentSelectorWidget(bool isDark) {
    final programs = widget.memory
        .programs()
        .where((p) => !RegExp(r'^(FA|SP)\d{2}$').hasMatch(p))
        .toList();
    final intakes = _program == null
        ? <String>[]
        : widget.memory.intakes(_program!);
    final sections = (_program != null && _intake != null)
        ? widget.memory.sectionsForIntake(_program!, _intake!)
        : (_program != null
              ? widget.memory.sectionsForIntake(_program!, '')
              : <String>[]);

    final isReady =
        _name.trim().isNotEmpty &&
        _program != null &&
        _intake != null &&
        _section != null;

    return Column(
      children: [
        Expanded(
          child: ListView(
            physics: ScrollConfiguration.of(context).getScrollPhysics(context),
            cacheExtent: 350.0,
            children: [
              // 1. YOUR FULL NAME INPUT AT THE VERY TOP
              SetupStudentNameInputField(
                name: _name,
                onChanged: (newName) {
                  setState(() => _name = newName);
                },
              ),
              const SizedBox(height: 16),

              // 2. PROGRAM GLASS MENU SELECTOR
              SetupGlassMenuDropdownSelector(
                label: 'PROGRAM',
                selectedValue: _program,
                items: programs,
                icon: Icons.school_rounded,
                onSelected: (value) => setState(() {
                  _program = value;
                  _intake = null;
                  _section = null;
                }),
              ),
              const SizedBox(height: 16),

              // 3. INTAKE / BATCH GLASS MENU SELECTOR
              SetupGlassMenuDropdownSelector(
                label: 'BATCH / INTAKE',
                selectedValue: _intake,
                items: intakes,
                itemLabelBuilder: (item) {
                  final sem = BatchKey.calculateSemester(item);
                  return '$item · Semester $sem';
                },
                icon: Icons.calendar_month_rounded,
                placeholder: _program == null
                    ? 'Select program first'
                    : 'No batches found',
                onSelected: (value) => setState(() {
                  _intake = value;
                  _section = null;
                }),
              ),
              const SizedBox(height: 16),

              // 4. SECTION GLASS MENU SELECTOR
              SetupGlassMenuDropdownSelector(
                label: 'SECTION',
                selectedValue: _section,
                items: sections,
                icon: Icons.group_rounded,
                placeholder: _intake == null
                    ? 'Select batch first'
                    : 'No sections found',
                onSelected: (value) => setState(() => _section = value),
              ),
              const SizedBox(height: 16),

              // 5. ROLL NUMBER (OPTIONAL)
              SetupRollNumberInputField(
                rollNo: _rollNo,
                onChanged: (newRoll) {
                  setState(() => _rollNo = newRoll);
                },
              ),

              // 6. REPEATER & CUSTOM COURSE SELECTION (OPTIONAL)
              _buildRepeaterCustomizerCard(isDark),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: IrisLiquidButton(
            text: 'CONTINUE TO PREFERENCES',
            icon: Icons.arrow_forward_rounded,
            onTap: isReady ? _nextStep : null,
            color: IrisTokens.brand,
            height: 52,
            fontSize: 13,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }

  Widget _buildRepeaterCustomizerCard(bool isDark) {
    final isBaseBatchSelected =
        _program != null && _intake != null && _section != null;
    const accentColor = Color(0xFF8B5CF6);
    const emeraldColor = Color(0xFF10B981);
    const roseColor = Color(0xFFF43F5E);

    return Container(
      margin: const EdgeInsets.only(top: 16),
      decoration: BoxDecoration(
        color: isDark
            ? (_hasCustomRepeaterSchedule
                ? accentColor.withValues(alpha: 0.12)
                : Colors.white.withValues(alpha: 0.04))
            : (_hasCustomRepeaterSchedule
                ? accentColor.withValues(alpha: 0.08)
                : Colors.black.withValues(alpha: 0.03)),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: _hasCustomRepeaterSchedule
              ? accentColor.withValues(alpha: 0.5)
              : (isDark
                  ? Colors.white.withValues(alpha: 0.1)
                  : Colors.black.withValues(alpha: 0.08)),
          width: _hasCustomRepeaterSchedule ? 1.5 : 1.0,
        ),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: accentColor.withValues(
                    alpha: isDark ? 0.22 : 0.14,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Icon(
                    _hasCustomRepeaterSchedule
                        ? Icons.check_circle_rounded
                        : Icons.alt_route_rounded,
                    color: _hasCustomRepeaterSchedule
                        ? emeraldColor
                        : accentColor,
                    size: 20,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          _hasCustomRepeaterSchedule
                              ? 'Custom Schedule Active'
                              : 'Repeaters & Extra Courses',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            letterSpacing: -0.2,
                            color: isDark ? Colors.white : Colors.black87,
                          ),
                        ),
                        if (_hasCustomRepeaterSchedule) ...[
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 1.5,
                            ),
                            decoration: BoxDecoration(
                              color: emeraldColor.withValues(alpha: 0.18),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const Text(
                              'CUSTOMIZED',
                              style: TextStyle(
                                fontSize: 9.5,
                                fontWeight: FontWeight.w900,
                                color: emeraldColor,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      _hasCustomRepeaterSchedule
                          ? '$_customRepeaterCourseCount course(s) customized with clash checks.'
                          : (isBaseBatchSelected
                              ? 'Add courses from other batches, drop subjects, or swap sections.'
                              : 'Select your program and batch above to customize.'),
                      style: TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w500,
                        color: (isDark ? Colors.white : Colors.black)
                            .withValues(alpha: 0.6),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: isBaseBatchSelected
                      ? () async {
                          IrisHaptics.actionMedium();
                          final batchKey = _resolveSelectedBatchKey();
                          await pushGlassContainerMorphRoute(
                            context,
                            page: RepeaterCoursePlannerScreen(
                              memory: widget.memory,
                              initialBatch: batchKey,
                              isModalMode: true,
                            ),
                          );
                          await _checkRepeaterStatus();
                        }
                      : null,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: accentColor,
                    side: BorderSide(
                      color: isBaseBatchSelected
                          ? accentColor.withValues(alpha: 0.6)
                          : (isDark ? Colors.white12 : Colors.black12),
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                  ),
                  icon: Icon(
                    _hasCustomRepeaterSchedule
                        ? Icons.edit_note_rounded
                        : Icons.bolt_rounded,
                    size: 16,
                  ),
                  label: Text(
                    _hasCustomRepeaterSchedule
                        ? 'Edit Courses & Clashes'
                        : 'Customize Courses (Optional)',
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
              if (_hasCustomRepeaterSchedule) ...[
                const SizedBox(width: 8),
                TextButton(
                  onPressed: () async {
                    IrisHaptics.actionMedium();
                    await RepeaterScheduleStorage.clearRepeaterSchedule();
                    await _checkRepeaterStatus();
                  },
                  style: TextButton.styleFrom(
                    foregroundColor: roseColor,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 10,
                    ),
                  ),
                  child: const Text(
                    'Reset',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  // STEP 2: VISUAL EXPERIENCE & THEME SELECTION
  Widget _buildStep2NotificationPreferences(bool isDark) {
    final accentColor = _role == 'faculty' ? IrisTokens.blue : IrisTokens.brand;

    return Column(
      key: const ValueKey(2),
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Navigation Header
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
          child: Row(
            children: [
              IconButton(
                onPressed: _prevStep,
                icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Visual Experience',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.5,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Choose your design language and personalize campus display',
                      style: TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w500,
                        color: (isDark ? Colors.white70 : Colors.black54),
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 6),

        // Embed Ground-Redesigned Interactive Theme Selector View
        Expanded(
          child: IrisThemeSelectorView(
            isEmbedded: true,
            initialStyle: _selectedThemeStyle,
            initialSeedColor: _selectedSeedColor,
            initialThemeMode: _selectedThemeMode,
            onThemeStyleChanged: (style) {
              setState(() => _selectedThemeStyle = style);
            },
            onSeedColorChanged: (color) {
              setState(() => _selectedSeedColor = color);
            },
            onThemeModeChanged: (mode) {
              setState(() => _selectedThemeMode = mode);
              widget.onSetThemeMode?.call(mode);
            },
            bottomChild: _buildSmartAlertsCard(isDark, accentColor),
            confirmButtonText: 'CONFIRM & ENTER IRIS',
            onConfirm: _finishSetupAndWelcome,
          ),
        ),
      ],
    );
  }

  Widget _buildSmartAlertsCard(bool isDark, Color accentColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'SMART ALERTS',
          style: TextStyle(
            fontSize: 10.5,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.0,
            color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.55),
          ),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 11,
          ),
          decoration: BoxDecoration(
            color: isDark
                ? const Color(0xFF1E293B).withValues(alpha: 0.5)
                : Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: (isDark ? Colors.white : Colors.black).withValues(
                alpha: 0.08,
              ),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: isDark ? 0.2 : 0.04),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: accentColor.withValues(
                    alpha: isDark ? 0.20 : 0.12,
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  Icons.notifications_active_rounded,
                  color: accentColor,
                  size: 18,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Live Class Reminders',
                      style: TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w800,
                        color: isDark ? Colors.white : Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Notified 10 mins before each class starts',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        color: (isDark ? Colors.white : Colors.black)
                            .withValues(alpha: 0.55),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              IrisGlassSwitch(
                value: _notifClassAlerts,
                onChanged: (val) {
                  IrisHaptics.selectionClick();
                  setState(() => _notifClassAlerts = val);
                },
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }

  Widget _buildWelcomingContainerMorph(bool isDark, ColorScheme cs) {
    final isM3 = _selectedThemeStyle == IrisThemeStyle.materialYou;
    final accent = isM3 ? _selectedSeedColor : const Color(0xFF00F2FE);

    return AnimatedBuilder(
      animation: _welcomeAnimation,
      builder: (context, child) {
        final t = _welcomeAnimation.value;
        final size = MediaQuery.sizeOf(context);

        // Fluid, smooth container morph:
        // Expands smoothly from center bounds into full screen
        final startCenter = Offset(size.width / 2, size.height * 0.46);
        final initialRect = Rect.fromCenter(
          center: startCenter,
          width: math.min(300.0, size.width - 32),
          height: 280.0,
        );
        final targetRect = Offset.zero & size;
        final currentRect = Rect.lerp(initialRect, targetRect, t)!;
        final currentRadius = ui.lerpDouble(36.0, 0.0, t)!;

        // Container background color matches destination app theme
        final containerBg = isM3
            ? Color.lerp(
                isDark ? const Color(0xFF1E2128) : const Color(0xFFF1F4F9),
                isDark ? const Color(0xFF0E1217) : const Color(0xFFFBFDFF),
                t,
              )!
            : Color.lerp(
                const Color(0xFF0F172A),
                isDark ? const Color(0xFF030712) : const Color(0xFFF8FAFC),
                t,
              )!;

        // Content phase opacities
        final emblemOpacity = ((t - 0.10) / 0.35).clamp(0.0, 1.0);
        final titleOpacity = ((t - 0.25) / 0.35).clamp(0.0, 1.0);
        final badgeOpacity = ((t - 0.40) / 0.35).clamp(0.0, 1.0);
        final footerOpacity = ((t - 0.55) / 0.35).clamp(0.0, 1.0);

        return Stack(
          children: [
            // Dark scrim behind the expanding container during early morph
            Positioned.fill(
              child: Container(
                color: Colors.black.withValues(
                  alpha: (0.75 * t).clamp(0.0, 0.75),
                ),
              ),
            ),

            Positioned(
              left: currentRect.left,
              top: currentRect.top,
              width: currentRect.width,
              height: currentRect.height,
              child: Material(
                color: Colors.transparent,
                child: Container(
                  decoration: BoxDecoration(
                    color: containerBg,
                    borderRadius: BorderRadius.circular(currentRadius),
                    border: t < 0.95
                        ? Border.all(
                            color: accent.withValues(
                              alpha: (1.0 - t * 0.9).clamp(0.0, 1.0),
                            ),
                            width: ui.lerpDouble(2.5, 0.0, t)!,
                          )
                        : null,
                    boxShadow: t < 0.95
                        ? [
                            BoxShadow(
                              color: accent.withValues(
                                alpha: (0.45 * (1.0 - t)).clamp(0.0, 0.45),
                              ),
                              blurRadius: 32 * (1.0 - t * 0.8),
                              offset: const Offset(0, 8),
                            ),
                          ]
                        : null,
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Stack(
                    children: [
                      // If Liquid Glass, render soft aurora blobs in the welcoming canvas
                      if (_selectedThemeStyle == IrisThemeStyle.fluidGlass)
                        Positioned.fill(
                          child: RepaintBoundary(
                            child: CustomPaint(
                              painter: LiquidGlassCardBlobPainter(
                                animation: _controller,
                              ),
                            ),
                          ),
                        ),
                      if (_selectedThemeStyle == IrisThemeStyle.fluidGlass)
                        Positioned.fill(
                          child: IrisGlass.backdropFilter(
                            sigmaX: IrisGlass.adaptiveBlur(context, 20.0),
                            sigmaY: IrisGlass.adaptiveBlur(context, 20.0),
                            child: Container(
                              color: (isDark ? Colors.black : Colors.white)
                                  .withValues(alpha: isDark ? 0.65 : 0.80),
                            ),
                          ),
                        ),

                      // Welcoming Animated Content
                      SafeArea(
                        child: Center(
                          child: SingleChildScrollView(
                            physics: const NeverScrollableScrollPhysics(),
                            padding: const EdgeInsets.symmetric(horizontal: 32),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                // 1. EMBLEM / AVATAR
                                Opacity(
                                  opacity: emblemOpacity,
                                  child: Transform.scale(
                                    scale: 0.75 + (emblemOpacity * 0.25),
                                    child: Container(
                                      width: 88,
                                      height: 88,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        gradient: LinearGradient(
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                          colors: [
                                            accent,
                                            isM3
                                                ? accent.withValues(alpha: 0.7)
                                                : const Color(0xFF8B5CF6),
                                          ],
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                            color: accent.withValues(
                                              alpha: 0.45,
                                            ),
                                            blurRadius: 28,
                                            offset: const Offset(0, 8),
                                          ),
                                        ],
                                      ),
                                      child: Center(
                                        child: Icon(
                                          _role == 'faculty'
                                              ? Icons.badge_rounded
                                              : Icons.school_rounded,
                                          size: 42,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),

                                const SizedBox(height: 28),

                                // 2. WELCOMING HEADLINE
                                Opacity(
                                  opacity: titleOpacity,
                                  child: Transform.translate(
                                    offset: Offset(
                                      0,
                                      16 * (1.0 - titleOpacity),
                                    ),
                                    child: Column(
                                      children: [
                                        Text(
                                          'WELCOME TO IRIS',
                                          style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w800,
                                            letterSpacing: 2.2,
                                            color: accent,
                                          ),
                                        ),
                                        const SizedBox(height: 8),
                                        Text(
                                          _welcomeName.isNotEmpty
                                              ? _welcomeName
                                              : (_role == 'faculty'
                                                  ? 'Faculty'
                                                  : 'Student'),
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            fontSize: 30,
                                            fontWeight: FontWeight.w900,
                                            letterSpacing: -0.6,
                                            color: isDark
                                                ? Colors.white
                                                : const Color(0xFF0F172A),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),

                                const SizedBox(height: 16),

                                // 3. STATUS BADGE & THEME BADGE
                                Opacity(
                                  opacity: badgeOpacity,
                                  child: Transform.translate(
                                    offset: Offset(
                                      0,
                                      14 * (1.0 - badgeOpacity),
                                    ),
                                    child: Column(
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 16,
                                            vertical: 7,
                                          ),
                                          decoration: BoxDecoration(
                                            color: accent.withValues(
                                              alpha: isDark ? 0.18 : 0.12,
                                            ),
                                            borderRadius: BorderRadius.circular(
                                              20,
                                            ),
                                            border: Border.all(
                                              color: accent.withValues(
                                                alpha: 0.35,
                                              ),
                                              width: 1.0,
                                            ),
                                          ),
                                          child: Text(
                                            _welcomeBatchOrRole,
                                            style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w800,
                                              letterSpacing: 1.2,
                                              color: accent,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(height: 10),
                                        Text(
                                          isM3
                                              ? 'Material 3 Expressive • Active'
                                              : 'Fluid Glass Aurora • Active',
                                          style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                            color: (isDark
                                                    ? Colors.white
                                                    : Colors.black87)
                                                .withValues(alpha: 0.55),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),

                                const SizedBox(height: 36),

                                // 4. FOOTER PREPARING / OPENING BADGE
                                Opacity(
                                  opacity: footerOpacity,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 18,
                                      vertical: 10,
                                    ),
                                    decoration: BoxDecoration(
                                      color: (isDark
                                              ? Colors.white
                                              : Colors.black)
                                          .withValues(alpha: 0.06),
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        SizedBox(
                                          width: 14,
                                          height: 14,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                            color: accent,
                                          ),
                                        ),
                                        const SizedBox(width: 10),
                                        Text(
                                          'Opening your campus workspace...',
                                          style: TextStyle(
                                            fontSize: 12.5,
                                            fontWeight: FontWeight.w700,
                                            color: (isDark
                                                    ? Colors.white
                                                    : Colors.black87)
                                                .withValues(alpha: 0.75),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
