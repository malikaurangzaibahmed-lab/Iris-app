// ==========================================
// 📱 CORE & APPLICATION SHELL
// ==========================================
export 'app_root.dart';
export 'dashboard_screen.dart';
export 'portal_screen.dart';
export 'tools_screen.dart';

// ==========================================
// 🎓 ACADEMICS & TIMETABLES
// ==========================================
export 'academics/department_classes_screen.dart';
export 'academics/exam_grid_dashboard_screen.dart';
export 'academics/makeup_lecture_scheduler_screen.dart';
export 'academics/room_finder_screen.dart';

// ==========================================
// 🧑‍🎓 STUDENT UTILITIES
// ==========================================
export 'student/students_week_screen.dart';
export 'student/cgpa_calculator_screen.dart';
export 'student/repeater_course_planner_screen.dart';

// ==========================================
// 👨‍🏫 FACULTY & LOCATOR
// ==========================================
export 'faculty/faculty_directory_screen.dart';
export 'faculty/faculty_dashboard_screen.dart';
export 'faculty/teacher_locator_screen.dart';
export 'faculty/faculty_detail_screen.dart';
export 'faculty/faculty_schedule_view.dart';
export 'faculty/faculty_tools_screen.dart';

// ==========================================
// 🛠️ TOOLS & WORKSPACES
// ==========================================
export 'tools/document_workspace_screen.dart';
export 'tools/semester_schedule_screen.dart';
export 'tools/library_schedule_screen.dart';
export 'tools/transport_schedule_screen.dart';
export 'tools/uni_info_screen.dart';

// ==========================================
// ⚙️ SETTINGS, HUB & SYSTEM
// ==========================================
export 'settings/iris_hub_screen.dart';
export 'settings/profile_settings_screen.dart';
export 'settings/appearance_settings_screen.dart';
export 'settings/notifications_settings_screen.dart';
export 'settings/data_storage_settings_screen.dart';
export 'settings/about_iris_screen.dart';
export 'settings/theme_selector_screen.dart';
export 'settings/announcements_screen.dart';
export 'settings/about_screen.dart';
export 'settings/feedback_screen.dart';
export 'settings/legal_screens.dart';
export 'settings/tutorial_screen.dart';

// ==========================================
// 🚀 ONBOARDING & SETUP
// ==========================================
export 'onboarding/onboarding_wizard_screen.dart';
