import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/tokens.dart';
import '../../core/vital_theme.dart';
import '../../core/theme_signals.dart';
import '../../core/animations.dart';
import '../../widgets/effects/glass_container_transform.dart';
import '../../services/ui_feedback.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/iris_components.dart';
import '../../widgets/cards/developer_card.dart';
import '../../screens/settings/legal_screens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';

/// Phone-like "About Phone / System Info" Sub-Screen for IRIS.
/// Displays software specifications, OTA versioning, developer governance, and licenses.
class AboutIrisScreen extends StatefulWidget {
  const AboutIrisScreen({super.key});

  @override
  State<AboutIrisScreen> createState() => _AboutIrisScreenState();
}

class _AboutIrisScreenState extends State<AboutIrisScreen> {
  bool _daroodReminder = true;

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        _daroodReminder = prefs.getBool('darood_pak_reminder_enabled') ?? true;
      });
    }
  }

  Future<void> _toggleDaroodReminder(bool val) async {
    IrisHaptics.selectionClick();
    setState(() => _daroodReminder = val);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('darood_pak_reminder_enabled', val);
  }

  void _openPrivacy() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    pushGlassContainerMorphRoute(
      context,
      page: PrivacyPolicyScreen(isDark: isDark),
    );
  }

  void _openTerms() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    pushGlassContainerMorphRoute(
      context,
      page: TermsOfServiceScreen(isDark: isDark),
    );
  }

  void _contactEngineering() async {
    try {
      final uri = Uri.parse('mailto:malikaurangzaibahmed@gmail.com?subject=IRIS%20Engineering%20Inquiry');
      await launchUrl(uri, mode: LaunchMode.externalApplication);
      IrisHaptics.actionSoft();
    } catch (_) {
      if (mounted) {
        showIrisFrostedSnackBar(
          context,
          content: const Text('Contact: malikaurangzaibahmed@gmail.com'),
          tint: VitalTokens.error,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorial;
    final isNotebook = ThemeSignals.isNotebook;
    final isLine = ThemeSignals.isLine;
    final isPoster = ThemeSignals.isPoster;
    final cs = Theme.of(context).colorScheme;

    final TextStyle appBarTitleStyle;
    if (isAlmanac) {
      appBarTitleStyle = AlmanacTokens.serifHeadline(isDark, fontSize: 18, fontWeight: FontWeight.w800);
    } else if (isEditorial) {
      appBarTitleStyle = EditorialTokens.headingSerif(isDark, fontSize: 18, fontWeight: FontWeight.w900);
    } else if (isNotebook) {
      appBarTitleStyle = NotebookTokens.boldScript(isDark, fontSize: 19);
    } else if (isLine) {
      appBarTitleStyle = LineTokens.stationName(isDark).copyWith(fontSize: 17, fontWeight: FontWeight.w900);
    } else if (isPoster) {
      appBarTitleStyle = PosterTokens.classTitle(isDark).copyWith(fontSize: 17, fontWeight: FontWeight.w900);
    } else if (isM3) {
      appBarTitleStyle = TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: cs.onSurface);
    } else {
      appBarTitleStyle = TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w900,
        color: isDark ? Colors.white : const Color(0xFF0F172A),
      );
    }

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: ExpressiveInteractivePress(
          pressedScale: 0.90,
          onTap: () => Navigator.of(context).pop(),
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: isM3
                  ? cs.surfaceContainer
                  : (isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.06)),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.arrow_back_rounded,
              size: 20,
              color: isDark ? Colors.white : const Color(0xFF0F172A),
            ),
          ),
        ),
        title: Text(
          'About IRIS',
          style: appBarTitleStyle,
        ),
      ),
      body: Stack(
        children: [
          ObsidianPulse(isDark: isDark),
          SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 720),
                child: ListView(
                  physics: const ButterScrollPhysics(
                    parent: AlwaysScrollableScrollPhysics(),
                  ),
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
                  children: [
                    // 1. Phone-like System Spec Hero Card
                    GlassCard(
                      borderRadius: 24,
                      elevation: 2,
                      padding: const EdgeInsets.all(22),
                      child: Column(
                        children: [
                          Container(
                            width: 64,
                            height: 64,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: const LinearGradient(
                                colors: [IrisTokens.brand, IrisTokens.purple],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: IrisTokens.brand.withValues(alpha: 0.35),
                                  blurRadius: 16,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: const Center(
                              child: Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 30),
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            'IRIS ENHANCED',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5,
                              color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            'Release Version 1.0.3+4 · Stable Channel',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: const Color(0xFF10B981).withValues(alpha: 0.16),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.verified_rounded, color: Color(0xFF10B981), size: 14),
                                SizedBox(width: 5),
                                Text(
                                  'SHOREBIRD OTA READY',
                                  style: TextStyle(
                                    fontSize: 9.5,
                                    fontWeight: FontWeight.w900,
                                    color: Color(0xFF10B981),
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // 2. Hardware & Architecture Specifications
                    _buildSectionHeader('System & Architecture Specifications'),
                    const SizedBox(height: 10),
                    GlassCard(
                      borderRadius: 22,
                      elevation: 2,
                      padding: EdgeInsets.zero,
                      child: Column(
                        children: [
                          _buildSpecRow(
                            label: 'Campus Entity',
                            value: 'COMSATS University Islamabad',
                            icon: Icons.account_balance_rounded,
                            iconColor: VitalTokens.blue,
                          ),
                          const Divider(height: 1, indent: 58),
                          _buildSpecRow(
                            label: 'Graphic Framework',
                            value: 'Flutter 3.x Engine · Impeller Vulkan',
                            icon: Icons.layers_rounded,
                            iconColor: VitalTokens.purple,
                          ),
                          const Divider(height: 1, indent: 58),
                          _buildSpecRow(
                            label: 'Edge Network Cloud',
                            value: 'Supabase Edge CDN + Firestore',
                            icon: Icons.cloud_done_rounded,
                            iconColor: const Color(0xFF10B981),
                          ),
                          const Divider(height: 1, indent: 58),
                          _buildSpecRow(
                            label: 'Security & Privacy',
                            value: 'Zero Remote Tracking · Local Keyring',
                            icon: Icons.shield_rounded,
                            iconColor: Colors.teal,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // 3. Cultural & Spiritual Settings
                    _buildSectionHeader('Spiritual & Cultural Preferences'),
                    const SizedBox(height: 10),
                    GlassCard(
                      borderRadius: 22,
                      elevation: 2,
                      padding: const EdgeInsets.all(18),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: const Color(0xFF059669).withValues(alpha: isDark ? 0.20 : 0.12),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: const Icon(Icons.star_rounded, color: Color(0xFF059669), size: 22),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Darood e Pak Boot Blessing',
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w900,
                                    color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  'Gentle remembrance dialog on app launch',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          IrisGlassSwitch(
                            value: _daroodReminder,
                            onChanged: _toggleDaroodReminder,
                            activeColor: const Color(0xFF059669),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // 4. Developer Suite
                    _buildSectionHeader('Developer & Creator Governance'),
                    const SizedBox(height: 10),
                    DeveloperCard(isDark: isDark),
                    const SizedBox(height: 24),

                    // 5. Legal & Compliance
                    _buildSectionHeader('Legal & Compliance'),
                    const SizedBox(height: 10),
                    GlassCard(
                      borderRadius: 22,
                      elevation: 2,
                      padding: EdgeInsets.zero,
                      child: Column(
                        children: [
                          _buildActionRow(
                            title: 'Privacy Policy',
                            subtitle: 'Strict localized data custody standards',
                            icon: Icons.privacy_tip_rounded,
                            iconColor: const Color(0xFF8B5CF6),
                            onTap: _openPrivacy,
                          ),
                          const Divider(height: 1, indent: 58),
                          _buildActionRow(
                            title: 'Terms of Service',
                            subtitle: 'Academic fair-use & governance guidelines',
                            icon: Icons.gavel_rounded,
                            iconColor: const Color(0xFF6366F1),
                            onTap: _openTerms,
                          ),
                          const Divider(height: 1, indent: 58),
                          _buildActionRow(
                            title: 'Contact Engineering Support',
                            subtitle: 'Direct email channel to developer maintainers',
                            icon: Icons.mail_outline_rounded,
                            iconColor: VitalTokens.blue,
                            onTap: _contactEngineering,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String label) {
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorial;
    final isNotebook = ThemeSignals.isNotebook;
    final isLine = ThemeSignals.isLine;
    final isPoster = ThemeSignals.isPoster;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    if (isAlmanac) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Row(
          children: [
            Text(
              '§ ${label.toUpperCase()}',
              style: AlmanacTokens.monoHeader(
                isDark,
                fontSize: 10.5,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.2,
                color: AlmanacTokens.accentTerracotta(isDark),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Container(
                height: 0.8,
                color: AlmanacTokens.inkRuleSubtle(isDark),
              ),
            ),
          ],
        ),
      );
    }

    if (isEditorial) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Row(
          children: [
            Text(
              label.toUpperCase(),
              style: EditorialTokens.monoLabel(
                isDark,
                fontSize: 10.5,
              ).copyWith(letterSpacing: 1.2, fontWeight: FontWeight.w800),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Container(
                height: 0.8,
                color: EditorialTokens.cardBorder(isDark),
              ),
            ),
          ],
        ),
      );
    }

    if (isLine) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Text(
          '[SECTION // ${label.toUpperCase()}]',
          style: LineTokens.stationMeta(isDark).copyWith(
            fontSize: 10.5,
            fontWeight: FontWeight.w800,
            color: LineTokens.railLine(isDark),
          ),
        ),
      );
    }

    if (isNotebook) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Text(
          '• $label',
          style: NotebookTokens.boldScript(
            isDark,
            fontSize: 14,
          ).copyWith(color: NotebookTokens.redDoodle(isDark)),
        ),
      );
    }

    if (isPoster) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: PosterTokens.orangeHero,
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text(
            label.toUpperCase(),
            style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w900,
              color: Colors.black,
              letterSpacing: 0.8,
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(left: 6),
      child: Text(
        label.toUpperCase(),
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.1,
          color: isM3 ? cs.primary : (isDark ? Colors.white60 : const Color(0xFF64748B)),
        ),
      ),
    );
  }

  Widget _buildSpecRow({
    required String label,
    required String value,
    required IconData icon,
    required Color iconColor,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: isDark ? 0.20 : 0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: iconColor, size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                  ),
                ),
                const SizedBox(height: 1),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 11,
                    color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionRow({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color iconColor,
    required VoidCallback onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    return InkWell(
      onTap: () {
        IrisHaptics.actionSoft();
        onTap();
      },
      borderRadius: BorderRadius.circular(20),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: iconColor.withValues(alpha: isDark ? 0.20 : 0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: iconColor, size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w800,
                      color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 10.5,
                      color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.chevron_right_rounded,
              size: 20,
              color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white30 : Colors.black26),
            ),
          ],
        ),
      ),
    );
  }
}
