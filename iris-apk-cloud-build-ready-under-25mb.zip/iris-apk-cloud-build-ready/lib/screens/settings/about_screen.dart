import 'package:iris/screens/settings/iris_hub_screen.dart';

export 'iris_hub_screen.dart';

/// [AboutScreen] has been unified into [IrisHubScreen].
/// This typedef guarantees 100% backward-compatibility across all callers, routes, and imports.
typedef AboutScreen = IrisHubScreen;
