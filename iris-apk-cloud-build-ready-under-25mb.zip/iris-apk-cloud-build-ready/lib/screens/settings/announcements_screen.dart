import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/theme_signals.dart';
import '../../core/vital_theme.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/animations.dart';
import '../../services/remote_config_service.dart';
import '../../services/ui_feedback.dart';
import '../../services/analytics_manager.dart';
import '../../widgets/iris_components.dart';

/// Campus Announcements & Official Notices Screen.
/// Synchronized live with Firebase Cloud Firestore (config/global) & Admin Portal.
/// Supports authentic Material 3 Expressive and Liquid Glass design systems.
class AnnouncementsScreen extends StatefulWidget {
  const AnnouncementsScreen({super.key});

  @override
  State<AnnouncementsScreen> createState() => _AnnouncementsScreenState();
}

class _AnnouncementsScreenState extends State<AnnouncementsScreen>
    with SingleTickerProviderStateMixin {
  late final TextEditingController _searchController;
  late final FocusNode _searchFocusNode;
  late final AnimationController _pulseController;

  String _searchQuery = '';
  String _selectedCategory = 'All';
  bool _isRefreshing = false;

  static const List<String> _categories = [
    'All',
    'General',
    'Examinations',
    'Fee & Accounts',
    'Events & Sports',
    'Transport',
    'Hostel',
    'Urgent',
    'Advising',
  ];

  @override
  void initState() {
    super.initState();
    AnalyticsManager().trackScreenView('campus_announcements_screen');
    _searchController = TextEditingController();
    _searchFocusNode = FocusNode();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );
    if (!ThemeSignals.useMinimalTheme.value) {
      _pulseController.repeat(reverse: true);
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _handleRefresh() async {
    IrisHaptics.refreshStart();
    setState(() => _isRefreshing = true);
    try {
      RemoteConfigService.startRemoteListener(context);
      await Future.delayed(const Duration(milliseconds: 400));
      IrisHaptics.refreshSuccess();
    } catch (_) {
      IrisHaptics.actionSoft();
    } finally {
      if (mounted) {
        setState(() => _isRefreshing = false);
      }
    }
  }

  DateTime? _parseNoticeDate(dynamic raw) {
    if (raw == null) return null;
    if (raw is Timestamp) return raw.toDate();
    if (raw is DateTime) return raw;
    if (raw is int) return DateTime.fromMillisecondsSinceEpoch(raw);
    if (raw is String) return DateTime.tryParse(raw);
    return null;
  }

  String _formatRelativeTime(DateTime? dt) {
    if (dt == null) return 'Recently';
    final now = DateTime.now();
    final diff = now.difference(dt);

    if (diff.inSeconds < 60) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays == 1) return 'Yesterday';
    if (diff.inDays < 7) return '${diff.inDays}d ago';

    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return '${months[dt.month - 1]} ${dt.day}, ${dt.year}';
  }

  Color _getCategoryColor(String category) {
    switch (category.toLowerCase().trim()) {
      case 'urgent':
      case 'emergency':
        return const Color(0xFFEF4444); // Red
      case 'examinations':
      case 'exams':
      case 'datesheet':
        return const Color(0xFFF59E0B); // Amber
      case 'fee & accounts':
      case 'accounts':
      case 'fee':
        return const Color(0xFF10B981); // Emerald
      case 'transport':
      case 'bus':
        return const Color(0xFF06B6D4); // Cyan
      case 'events & sports':
      case 'events':
      case 'sports':
        return const Color(0xFF8B5CF6); // Purple
      case 'hostel':
        return const Color(0xFF3B82F6); // Blue
      case 'advising':
      case 'academics':
        return const Color(0xFF6366F1); // Indigo
      default:
        return const Color(0xFF0D9488); // Teal
    }
  }

  IconData _getCategoryIcon(String category) {
    switch (category.toLowerCase().trim()) {
      case 'urgent':
      case 'emergency':
        return Icons.warning_amber_rounded;
      case 'examinations':
      case 'exams':
      case 'datesheet':
        return Icons.assignment_turned_in_rounded;
      case 'fee & accounts':
      case 'accounts':
      case 'fee':
        return Icons.account_balance_wallet_rounded;
      case 'transport':
      case 'bus':
        return Icons.directions_bus_rounded;
      case 'events & sports':
      case 'events':
      case 'sports':
        return Icons.emoji_events_rounded;
      case 'hostel':
        return Icons.hotel_rounded;
      case 'advising':
      case 'academics':
        return Icons.psychology_rounded;
      default:
        return Icons.campaign_rounded;
    }
  }

  void _copyToClipboard(String text, String title) {
    Clipboard.setData(ClipboardData(text: text));
    IrisHaptics.actionMedium();
    showIrisFrostedSnackBar(
      context,
      content: Text('$title copied to clipboard.'),
    );
  }

  void _showNoticeDetailModal(
    BuildContext context,
    Map<String, dynamic> notice,
    bool isDark,
    bool isM3,
    ColorScheme cs,
  ) {
    final title = notice['title']?.toString() ?? 'Announcement';
    final detail = notice['detail']?.toString() ??
        notice['message']?.toString() ??
        notice['body']?.toString() ??
        '';
    final author = notice['author']?.toString() ??
        notice['createdBy']?.toString() ??
        'Campus Administration';
    final category = notice['category']?.toString() ?? 'General';
    final date = _parseNoticeDate(notice['created_at'] ?? notice['createdAt']);
    final timeStr = _formatRelativeTime(date);
    final catColor = _getCategoryColor(category);
    final catIcon = _getCategoryIcon(category);

    IrisHaptics.selectionClick();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return Container(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.sizeOf(ctx).height * 0.82,
          ),
          decoration: BoxDecoration(
            color: isM3
                ? (isDark ? cs.surfaceContainer : cs.surfaceContainerLow)
                : (isDark
                    ? const Color(0xFF1E293B)
                    : Colors.white),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
            border: Border.all(
              color: isM3
                  ? cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.45)
                  : (isDark ? Colors.white24 : Colors.black12),
              width: 1.0,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Drag Handle
              Center(
                child: Container(
                  margin: const EdgeInsets.only(top: 12, bottom: 8),
                  width: 40,
                  height: 4.5,
                  decoration: BoxDecoration(
                    color: cs.onSurfaceVariant.withValues(alpha: 0.30),
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
              // Modal Header
              Padding(
                padding: const EdgeInsets.fromLTRB(22, 10, 22, 14),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: catColor.withValues(alpha: 0.16),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(catIcon, size: 14, color: catColor),
                          const SizedBox(width: 5),
                          Text(
                            category.toUpperCase(),
                            style: TextStyle(
                              fontSize: 10.5,
                              fontWeight: FontWeight.w900,
                              color: catColor,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    Text(
                      timeStr,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: cs.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton(
                      icon: const Icon(Icons.close_rounded, size: 20),
                      onPressed: () => Navigator.of(ctx).pop(),
                      visualDensity: VisualDensity.compact,
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              // Body Content (Scrollable)
              Flexible(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(22, 16, 22, 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SelectableText(
                        title,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -0.4,
                          color: cs.onSurface,
                          height: 1.25,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(
                            Icons.verified_user_rounded,
                            size: 14,
                            color: catColor,
                          ),
                          const SizedBox(width: 5),
                          Expanded(
                            child: Text(
                              'Issued by $author',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: cs.onSurfaceVariant,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: isM3
                              ? (isDark
                                  ? cs.surfaceContainerHigh
                                  : cs.surfaceContainerHighest.withValues(alpha: 0.4))
                              : (isDark
                                  ? Colors.white.withValues(alpha: 0.05)
                                  : Colors.black.withValues(alpha: 0.03)),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: cs.outlineVariant.withValues(
                              alpha: isDark ? 0.25 : 0.35,
                            ),
                          ),
                        ),
                        child: SelectableText(
                          detail,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            height: 1.6,
                            color: cs.onSurface.withValues(alpha: 0.95),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      // Copy & Actions Row
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: () {
                                _copyToClipboard(
                                  '$title\n\n$detail\n\nIssued by: $author',
                                  'Notice',
                                );
                              },
                              icon: const Icon(Icons.copy_rounded, size: 16),
                              label: const Text(
                                'Copy Details',
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13,
                                ),
                              ),
                              style: OutlinedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () => Navigator.of(ctx).pop(),
                              icon: const Icon(Icons.check_rounded, size: 16),
                              label: const Text(
                                'Done',
                                style: TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 13,
                                ),
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: catColor,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                elevation: 0,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildThemedBackground(IrisThemeStyle style, bool isDark, ColorScheme cs) {
    switch (style) {
      case IrisThemeStyle.notebook:
        return Positioned.fill(
          child: CustomPaint(
            painter: NotebookGraphPaperPainter(
              isDark: isDark,
              gridSize: 22.0,
              marginX: 42.0,
            ),
          ),
        );
      case IrisThemeStyle.line:
        return Stack(
          children: [
            Positioned.fill(child: Container(color: LineTokens.canvas(isDark))),
            Positioned(top: 0, left: 0, right: 0, child: Container(height: 4, color: LineTokens.railLine(isDark))),
          ],
        );
      case IrisThemeStyle.poster:
        return Positioned.fill(child: Container(color: PosterTokens.canvas(isDark)));
      case IrisThemeStyle.almanac:
        return Positioned.fill(child: Container(color: AlmanacTokens.canvas(isDark)));
      case IrisThemeStyle.editorialAcademic:
        return Positioned.fill(child: Container(color: EditorialTokens.canvas(isDark)));
      case IrisThemeStyle.materialYou:
        return Positioned.fill(child: Container(color: cs.surface));
      case IrisThemeStyle.fluidGlass:
        return RepaintBoundary(child: ObsidianPulse(isDark: isDark));
    }
  }

  Widget _buildThemedAppBar(IrisThemeStyle style, bool isDark, ColorScheme cs) {
    switch (style) {
      case IrisThemeStyle.notebook:
        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.of(context).maybePop(),
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: NotebookTokens.cardSurface(isDark),
                    shape: BoxShape.circle,
                    border: Border.all(color: NotebookTokens.inkMuted(isDark).withValues(alpha: 0.3), width: 1.5),
                  ),
                  child: Icon(Icons.arrow_back_rounded, color: NotebookTokens.inkHeading(isDark), size: 20),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Student Noticeboard', style: GoogleFonts.kalam(fontSize: 22, fontWeight: FontWeight.w700, color: NotebookTokens.inkHeading(isDark))),
                    Text('Campus alerts & pinned notes', style: GoogleFonts.kalam(fontSize: 12, color: NotebookTokens.inkMuted(isDark))),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: NotebookTokens.tapeYellow,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.push_pin_rounded, size: 12, color: NotebookTokens.redDoodle(isDark)),
                    const SizedBox(width: 4),
                    Text('PINNED', style: GoogleFonts.kalam(fontSize: 10, fontWeight: FontWeight.w800, color: const Color(0xFF1A1F1C))),
                  ],
                ),
              ),
            ],
          ),
        );

      case IrisThemeStyle.line:
        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.of(context).maybePop(),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: LineTokens.cardSurface(isDark),
                    border: Border.all(color: LineTokens.railLine(isDark), width: 1.5),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Icon(Icons.arrow_back_rounded, color: LineTokens.inkHeading(isDark), size: 18),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('TRANSIT BULLETIN', style: GoogleFonts.archivoBlack(fontSize: 18, color: LineTokens.inkHeading(isDark))),
                    Text('SYSTEM BROADCAST LOG // S-01', style: GoogleFonts.spaceMono(fontSize: 10, fontWeight: FontWeight.bold, color: LineTokens.railLine(isDark))),
                  ],
                ),
              ),
              Container(
                width: 10,
                height: 10,
                decoration: const BoxDecoration(
                  color: LineTokens.subwayYellow,
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ),
        );

      case IrisThemeStyle.poster:
        return Container(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          decoration: BoxDecoration(
            border: Border(bottom: BorderSide(color: PosterTokens.inkBorder(isDark), width: 2.5)),
          ),
          child: Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.of(context).maybePop(),
                child: Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: PosterTokens.cardSurface(isDark),
                    border: Border.all(color: PosterTokens.inkBorder(isDark), width: 2.5),
                  ),
                  child: Icon(Icons.arrow_back_rounded, color: PosterTokens.inkHeading(isDark), size: 20),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('CAMPUS DISPATCH', style: GoogleFonts.archivoBlack(fontSize: 20, letterSpacing: -0.8, color: PosterTokens.inkHeading(isDark))),
                    Text('SWISS BULLETINS // ALL CATEGORIES', style: GoogleFonts.spaceMono(fontSize: 10, fontWeight: FontWeight.w700, color: PosterTokens.orangeHero)),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: PosterTokens.orangeHero,
                  border: Border.all(color: PosterTokens.inkBorder(isDark), width: 2.0),
                ),
                child: Text('LIVE FEED', style: GoogleFonts.spaceMono(fontSize: 10, fontWeight: FontWeight.w900, color: Colors.black)),
              ),
            ],
          ),
        );

      case IrisThemeStyle.almanac:
        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
          child: Column(
            children: [
              Container(height: 2, color: AlmanacTokens.inkRule(isDark)),
              const SizedBox(height: 2),
              Container(height: 0.8, color: AlmanacTokens.inkRule(isDark)),
              const SizedBox(height: 6),
              Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.of(context).maybePop(),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(border: Border.all(color: AlmanacTokens.inkRule(isDark), width: 1), shape: BoxShape.circle),
                      child: Icon(Icons.arrow_back_rounded, color: AlmanacTokens.inkHeading(isDark), size: 18),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      children: [
                        Text('THE IRIS GAZETTE · OFFICIAL CHRONICLE', style: GoogleFonts.playfairDisplay(fontSize: 12, letterSpacing: 1.5, fontWeight: FontWeight.w900, color: AlmanacTokens.accentTerracotta(isDark))),
                        Text('University Decrees & Notices', style: GoogleFonts.playfairDisplay(fontSize: 20, fontStyle: FontStyle.italic, fontWeight: FontWeight.w700, color: AlmanacTokens.inkHeading(isDark))),
                      ],
                    ),
                  ),
                  const SizedBox(width: 36),
                ],
              ),
              const SizedBox(height: 6),
              Container(height: 0.8, color: AlmanacTokens.inkRule(isDark)),
              const SizedBox(height: 2),
              Container(height: 2, color: AlmanacTokens.inkRule(isDark)),
            ],
          ),
        );

      case IrisThemeStyle.editorialAcademic:
        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.of(context).maybePop(),
                child: Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: EditorialTokens.cardSurface(isDark),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: EditorialTokens.cardBorder(isDark), width: 1.2),
                  ),
                  child: Icon(Icons.arrow_back_rounded, color: EditorialTokens.inkHeading(isDark), size: 20),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Campus Gazette', style: GoogleFonts.newsreader(fontSize: 22, fontWeight: FontWeight.w800, color: EditorialTokens.inkHeading(isDark))),
                    Text('ARCHIVUM ACADEMICUM · ANNOUNCEMENTS', style: GoogleFonts.spaceMono(fontSize: 10, letterSpacing: 1.0, color: EditorialTokens.accentUpcoming, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ],
          ),
        );

      case IrisThemeStyle.materialYou:
      case IrisThemeStyle.fluidGlass:
        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: Row(
            children: [
              ExpressiveInteractivePress(
                onTap: () {
                  IrisHaptics.actionSoft();
                  Navigator.of(context).maybePop();
                },
                child: Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: style == IrisThemeStyle.materialYou ? cs.surfaceContainerHigh : (isDark ? Colors.white.withValues(alpha: 0.10) : Colors.white),
                    shape: BoxShape.circle,
                    border: Border.all(color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.50), width: 1.0),
                  ),
                  child: Center(child: Icon(Icons.arrow_back_rounded, size: 20, color: cs.onSurface)),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Campus Noticeboard', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: -0.4, color: cs.onSurface)),
                    const SizedBox(height: 2),
                    Text('Administrative broadcasts & student notices', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: cs.onSurfaceVariant), maxLines: 1, overflow: TextOverflow.ellipsis),
                  ],
                ),
              ),
              ExpressiveInteractivePress(
                onTap: _handleRefresh,
                child: Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: style == IrisThemeStyle.materialYou ? cs.surfaceContainerHigh : (isDark ? Colors.white.withValues(alpha: 0.10) : Colors.white),
                    shape: BoxShape.circle,
                    border: Border.all(color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.50), width: 1.0),
                  ),
                  child: Center(
                    child: _isRefreshing
                        ? SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: cs.primary))
                        : Icon(Icons.sync_rounded, size: 20, color: cs.onSurfaceVariant),
                  ),
                ),
              ),
            ],
          ),
        );
    }
  }

  Widget _buildThemedEmergencyCard(IrisThemeStyle style, bool isDark, ColorScheme cs, String broadcastMsg, String timeStr) {
    if (style == IrisThemeStyle.poster) {
      return Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: PosterTokens.orangeHero,
          border: Border.all(color: PosterTokens.inkBorder(isDark), width: 2.5),
          boxShadow: [
            BoxShadow(color: PosterTokens.inkBorder(isDark), offset: const Offset(4, 4), blurRadius: 0),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('CRITICAL EMERGENCY BROADCAST // $timeStr'.toUpperCase(), style: GoogleFonts.spaceMono(fontSize: 11, fontWeight: FontWeight.w900, color: Colors.black)),
            const SizedBox(height: 8),
            Text(broadcastMsg, style: GoogleFonts.archivoBlack(fontSize: 14, color: Colors.black)),
          ],
        ),
      );
    }

    if (style == IrisThemeStyle.notebook) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFFFDE8E8),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: NotebookTokens.redDoodle(isDark), width: 1.5),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.warning_amber_rounded, size: 16, color: NotebookTokens.redDoodle(isDark)),
                const SizedBox(width: 6),
                Text('EMERGENCY BROADCAST', style: GoogleFonts.kalam(fontSize: 12, fontWeight: FontWeight.w700, color: NotebookTokens.redDoodle(isDark))),
              ],
            ),
            const SizedBox(height: 6),
            Text(broadcastMsg, style: GoogleFonts.plusJakartaSans(fontSize: 13, fontWeight: FontWeight.w600, color: const Color(0xFF7F1D1D))),
          ],
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF3F0B13) : const Color(0xFFFEF2F2),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFEF4444).withValues(alpha: isDark ? 0.55 : 0.40), width: 1.4),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(width: 8, height: 8, decoration: const BoxDecoration(color: Color(0xFFEF4444), shape: BoxShape.circle)),
              const SizedBox(width: 8),
              const Text('OFFICIAL EMERGENCY BROADCAST', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 0.8, color: Color(0xFFEF4444))),
              const Spacer(),
              Text(timeStr, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: isDark ? Colors.white60 : const Color(0xFF991B1B))),
            ],
          ),
          const SizedBox(height: 10),
          SelectableText(broadcastMsg, style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700, height: 1.4, color: isDark ? Colors.white : const Color(0xFF7F1D1D))),
        ],
      ),
    );
  }

  Widget _buildThemedSearchBar(IrisThemeStyle style, bool isDark, ColorScheme cs) {
    if (style == IrisThemeStyle.notebook) {
      return Container(
        decoration: BoxDecoration(
          color: NotebookTokens.cardSurface(isDark),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: NotebookTokens.inkMuted(isDark).withValues(alpha: 0.3), width: 1.2),
        ),
        child: TextField(
          controller: _searchController,
          focusNode: _searchFocusNode,
          onChanged: (val) => setState(() => _searchQuery = val.trim()),
          style: GoogleFonts.plusJakartaSans(fontSize: 13.5, color: NotebookTokens.inkHeading(isDark)),
          decoration: InputDecoration(
            hintText: 'Search pinned notices & alerts...',
            hintStyle: GoogleFonts.kalam(fontSize: 13, color: NotebookTokens.inkMuted(isDark)),
            prefixIcon: Icon(Icons.search_rounded, size: 20, color: NotebookTokens.inkMuted(isDark)),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          ),
        ),
      );
    }

    if (style == IrisThemeStyle.line) {
      return Container(
        decoration: BoxDecoration(
          color: LineTokens.cardSurface(isDark),
          border: Border.all(color: LineTokens.railLine(isDark).withValues(alpha: 0.4), width: 1.5),
          borderRadius: BorderRadius.circular(6),
        ),
        child: TextField(
          controller: _searchController,
          focusNode: _searchFocusNode,
          onChanged: (val) => setState(() => _searchQuery = val.trim()),
          style: GoogleFonts.inter(fontSize: 13.5, color: LineTokens.inkHeading(isDark)),
          decoration: InputDecoration(
            hintText: 'FILTER TRANSIT DISPATCH...',
            hintStyle: GoogleFonts.spaceMono(fontSize: 11, color: LineTokens.inkMuted(isDark)),
            prefixIcon: Icon(Icons.search_rounded, size: 18, color: LineTokens.railLine(isDark)),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          ),
        ),
      );
    }

    if (style == IrisThemeStyle.poster) {
      return Container(
        decoration: BoxDecoration(
          color: PosterTokens.cardSurface(isDark),
          border: Border.all(color: PosterTokens.inkBorder(isDark), width: 2.0),
        ),
        child: TextField(
          controller: _searchController,
          focusNode: _searchFocusNode,
          onChanged: (val) => setState(() => _searchQuery = val.trim()),
          style: GoogleFonts.inter(fontSize: 13.5, fontWeight: FontWeight.w600, color: PosterTokens.inkHeading(isDark)),
          decoration: InputDecoration(
            hintText: 'SEARCH MANIFESTO...',
            hintStyle: GoogleFonts.spaceMono(fontSize: 11, fontWeight: FontWeight.bold, color: PosterTokens.inkBorder(isDark).withValues(alpha: 0.5)),
            prefixIcon: Icon(Icons.search_rounded, size: 20, color: PosterTokens.orangeHero),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          ),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        color: style == IrisThemeStyle.materialYou ? cs.surfaceContainer : (isDark ? Colors.white.withValues(alpha: 0.08) : Colors.white),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.50), width: 1.0),
      ),
      child: TextField(
        controller: _searchController,
        focusNode: _searchFocusNode,
        onChanged: (val) => setState(() => _searchQuery = val.trim()),
        style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: cs.onSurface),
        decoration: InputDecoration(
          hintText: 'Search announcements, exams, fees...',
          hintStyle: TextStyle(fontSize: 13.5, color: cs.onSurfaceVariant.withValues(alpha: 0.7)),
          prefixIcon: Icon(Icons.search_rounded, size: 20, color: cs.onSurfaceVariant),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        ),
      ),
    );
  }

  Widget _buildThemedChip(IrisThemeStyle style, bool isDark, ColorScheme cs, String cat, bool isSelected) {
    final catColor = cat == 'All' ? cs.primary : _getCategoryColor(cat);

    if (style == IrisThemeStyle.notebook) {
      return GestureDetector(
        onTap: () {
          IrisHaptics.chipSelect();
          setState(() => _selectedCategory = cat);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: isSelected ? NotebookTokens.stickyNote(isDark) : NotebookTokens.cardSurface(isDark),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: isSelected ? NotebookTokens.redDoodle(isDark) : NotebookTokens.inkMuted(isDark).withValues(alpha: 0.3), width: 1.2),
          ),
          child: Text(
            cat,
            style: GoogleFonts.kalam(
              fontSize: 12,
              fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
              color: isSelected ? const Color(0xFF1A1F1C) : NotebookTokens.inkBody(isDark),
            ),
          ),
        ),
      );
    }

    if (style == IrisThemeStyle.line) {
      return GestureDetector(
        onTap: () {
          IrisHaptics.chipSelect();
          setState(() => _selectedCategory = cat);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: isSelected ? LineTokens.subwayYellow : LineTokens.cardSurface(isDark),
            border: Border.all(color: isSelected ? LineTokens.subwayYellow : LineTokens.inkMuted(isDark).withValues(alpha: 0.3), width: 1.2),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Text(
            cat.toUpperCase(),
            style: GoogleFonts.spaceMono(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: isSelected ? Colors.black : LineTokens.inkHeading(isDark),
            ),
          ),
        ),
      );
    }

    if (style == IrisThemeStyle.poster) {
      return GestureDetector(
        onTap: () {
          IrisHaptics.chipSelect();
          setState(() => _selectedCategory = cat);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: isSelected ? PosterTokens.orangeHero : PosterTokens.cardSurface(isDark),
            border: Border.all(color: PosterTokens.inkBorder(isDark), width: 2.0),
          ),
          child: Text(
            cat.toUpperCase(),
            style: GoogleFonts.spaceMono(
              fontSize: 11,
              fontWeight: FontWeight.w900,
              color: isSelected ? Colors.black : PosterTokens.inkHeading(isDark),
            ),
          ),
        ),
      );
    }

    return GestureDetector(
      onTap: () {
        IrisHaptics.chipSelect();
        setState(() => _selectedCategory = cat);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? catColor : (style == IrisThemeStyle.materialYou ? (isDark ? cs.surfaceContainer : cs.surfaceContainerHigh) : (isDark ? Colors.white.withValues(alpha: 0.08) : Colors.white)),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: isSelected ? catColor : cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.50)),
        ),
        child: Text(
          cat,
          style: TextStyle(
            fontSize: 12,
            fontWeight: isSelected ? FontWeight.w900 : FontWeight.w700,
            color: isSelected ? Colors.white : cs.onSurfaceVariant,
          ),
        ),
      ),
    );
  }

  Widget _buildThemedNoticeCard(IrisThemeStyle style, bool isDark, ColorScheme cs, Map<String, dynamic> notice) {
    final title = notice['title']?.toString() ?? 'Campus Notice';
    final detail = notice['detail'] ?? notice['message'] ?? notice['body'] ?? '';
    final author = notice['author']?.toString() ?? notice['createdBy']?.toString() ?? 'Campus Administration';
    final category = notice['category']?.toString() ?? 'General';
    final date = _parseNoticeDate(notice['created_at'] ?? notice['createdAt']);
    final timeStr = _formatRelativeTime(date);
    final catColor = _getCategoryColor(category);
    final catIcon = _getCategoryIcon(category);

    if (style == IrisThemeStyle.notebook) {
      return Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: NotebookTokens.cardSurface(isDark),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: NotebookTokens.inkMuted(isDark).withValues(alpha: 0.25), width: 1.5),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(catIcon, size: 14, color: NotebookTokens.redDoodle(isDark)),
                const SizedBox(width: 6),
                Text(category.toUpperCase(), style: GoogleFonts.kalam(fontSize: 11, fontWeight: FontWeight.w700, color: NotebookTokens.redDoodle(isDark))),
                const Spacer(),
                Text(timeStr, style: GoogleFonts.kalam(fontSize: 11, color: NotebookTokens.inkMuted(isDark))),
              ],
            ),
            const SizedBox(height: 8),
            Text(title, style: GoogleFonts.kalam(fontSize: 16, fontWeight: FontWeight.w700, color: NotebookTokens.inkHeading(isDark))),
            const SizedBox(height: 6),
            Text(detail.toString(), style: GoogleFonts.plusJakartaSans(fontSize: 13, height: 1.5, color: NotebookTokens.inkBody(isDark)), maxLines: 3, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 12),
            Text('Issued by: $author', style: GoogleFonts.kalam(fontSize: 11, color: NotebookTokens.inkMuted(isDark))),
          ],
        ),
      );
    }

    if (style == IrisThemeStyle.line) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: LineTokens.cardSurface(isDark),
          border: Border.all(color: LineTokens.railLine(isDark).withValues(alpha: 0.4), width: 1.5),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: LineTokens.railLine(isDark), borderRadius: BorderRadius.circular(4)),
                  child: Text(category.toUpperCase(), style: GoogleFonts.spaceMono(fontSize: 9, fontWeight: FontWeight.w900, color: Colors.black)),
                ),
                const Spacer(),
                Text(timeStr, style: GoogleFonts.spaceMono(fontSize: 10, color: LineTokens.inkMuted(isDark))),
              ],
            ),
            const SizedBox(height: 10),
            Text(title, style: GoogleFonts.spaceGrotesk(fontSize: 15, fontWeight: FontWeight.w800, color: LineTokens.inkHeading(isDark))),
            const SizedBox(height: 6),
            Text(detail.toString(), style: GoogleFonts.inter(fontSize: 13, height: 1.5, color: LineTokens.inkBody(isDark)), maxLines: 3, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 10),
            Text('DISPATCH AUTHOR: $author', style: GoogleFonts.spaceMono(fontSize: 10, color: LineTokens.railLine(isDark))),
          ],
        ),
      );
    }

    if (style == IrisThemeStyle.poster) {
      return Container(
        decoration: BoxDecoration(
          color: PosterTokens.cardSurface(isDark),
          border: Border.all(color: PosterTokens.inkBorder(isDark), width: 2.5),
          boxShadow: [
            BoxShadow(color: PosterTokens.inkBorder(isDark), offset: const Offset(5, 5), blurRadius: 0),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              color: catColor,
              child: Row(
                children: [
                  Text(category.toUpperCase(), style: GoogleFonts.archivoBlack(fontSize: 11, color: Colors.black)),
                  const Spacer(),
                  Text(timeStr.toUpperCase(), style: GoogleFonts.spaceMono(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.black)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title.toUpperCase(), style: GoogleFonts.archivoBlack(fontSize: 16, letterSpacing: -0.4, color: PosterTokens.inkHeading(isDark))),
                  const SizedBox(height: 8),
                  Text(detail.toString(), style: GoogleFonts.inter(fontSize: 13, fontWeight: FontWeight.w600, height: 1.5, color: PosterTokens.inkBody(isDark)), maxLines: 3, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 12),
                  Text('ISSUED: $author'.toUpperCase(), style: GoogleFonts.spaceMono(fontSize: 10, fontWeight: FontWeight.w700, color: PosterTokens.orangeHero)),
                ],
              ),
            ),
          ],
        ),
      );
    }

    if (style == IrisThemeStyle.almanac) {
      return Container(
        decoration: BoxDecoration(
          color: AlmanacTokens.cardSurface(isDark),
          border: Border.all(color: AlmanacTokens.inkRule(isDark).withValues(alpha: 0.35), width: 1.5),
        ),
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text('ORDINANCE · ${category.toUpperCase()}', style: GoogleFonts.spaceMono(fontSize: 10, fontWeight: FontWeight.w700, color: AlmanacTokens.accentTerracotta(isDark))),
                const Spacer(),
                Text(timeStr, style: GoogleFonts.playfairDisplay(fontSize: 11, fontStyle: FontStyle.italic, color: AlmanacTokens.inkMuted(isDark))),
              ],
            ),
            const SizedBox(height: 8),
            Text(title, style: GoogleFonts.playfairDisplay(fontSize: 17, fontWeight: FontWeight.w700, fontStyle: FontStyle.italic, color: AlmanacTokens.inkHeading(isDark))),
            const SizedBox(height: 6),
            Text(detail.toString(), style: GoogleFonts.newsreader(fontSize: 14, height: 1.6, color: AlmanacTokens.inkBody(isDark)), maxLines: 3, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 10),
            Text('By Order of $author', style: GoogleFonts.playfairDisplay(fontSize: 11, fontStyle: FontStyle.italic, color: AlmanacTokens.inkMuted(isDark))),
          ],
        ),
      );
    }

    if (style == IrisThemeStyle.editorialAcademic) {
      return Container(
        decoration: BoxDecoration(
          color: EditorialTokens.cardSurface(isDark),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: EditorialTokens.cardBorder(isDark), width: 1.2),
          boxShadow: [
            BoxShadow(color: Colors.black.withValues(alpha: isDark ? 0.3 : 0.05), blurRadius: 12, offset: const Offset(0, 4)),
          ],
        ),
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text('§ $category'.toUpperCase(), style: GoogleFonts.spaceMono(fontSize: 10, fontWeight: FontWeight.w700, color: EditorialTokens.accentUpcoming)),
                const Spacer(),
                Text(timeStr, style: GoogleFonts.plusJakartaSans(fontSize: 11, color: EditorialTokens.inkMuted(isDark))),
              ],
            ),
            const SizedBox(height: 8),
            Text(title, style: GoogleFonts.newsreader(fontSize: 17, fontWeight: FontWeight.w800, color: EditorialTokens.inkHeading(isDark))),
            const SizedBox(height: 6),
            Text(detail.toString(), style: GoogleFonts.plusJakartaSans(fontSize: 13, height: 1.55, color: EditorialTokens.inkBody(isDark)), maxLines: 3, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 10),
            Text('Dean / $author', style: GoogleFonts.plusJakartaSans(fontSize: 11, fontWeight: FontWeight.w600, color: EditorialTokens.accentUpcoming)),
          ],
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: style == IrisThemeStyle.materialYou ? (isDark ? cs.surfaceContainer : cs.surfaceContainerLow) : (isDark ? Colors.white.withValues(alpha: 0.08) : Colors.white),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: style == IrisThemeStyle.materialYou ? cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.50) : (isDark ? Colors.white.withValues(alpha: 0.12) : Colors.black.withValues(alpha: 0.06)), width: 1.0),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                decoration: BoxDecoration(color: catColor.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(8)),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(catIcon, size: 13, color: catColor),
                    const SizedBox(width: 4),
                    Text(category.toUpperCase(), style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 0.3, color: catColor)),
                  ],
                ),
              ),
              const Spacer(),
              Text(timeStr, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: cs.onSurfaceVariant)),
            ],
          ),
          const SizedBox(height: 12),
          Text(title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, letterSpacing: -0.3, color: cs.onSurface, height: 1.25)),
          const SizedBox(height: 6),
          Text(detail.toString(), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: cs.onSurfaceVariant, height: 1.45), maxLines: 3, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 14),
          Row(
            children: [
              Icon(Icons.verified_user_rounded, size: 13, color: catColor),
              const SizedBox(width: 4),
              Expanded(child: Text(author, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: cs.onSurfaceVariant), maxLines: 1, overflow: TextOverflow.ellipsis)),
              Text('Read More', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: catColor)),
              const SizedBox(width: 3),
              Icon(Icons.arrow_forward_ios_rounded, size: 10, color: catColor),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cs = Theme.of(context).colorScheme;

    return ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, style, _) {
        final isM3 = style == IrisThemeStyle.materialYou;

        return Scaffold(
          backgroundColor: Colors.transparent,
          body: Stack(
            fit: StackFit.expand,
            children: [
              _buildThemedBackground(style, isDark, cs),
              SafeArea(
                child: IrisRefreshIndicator(
                  onRefresh: _handleRefresh,
                  child: CustomScrollView(
                    physics: const AlwaysScrollableScrollPhysics(
                      parent: BouncingScrollPhysics(),
                    ),
                    slivers: [
                      // 1. App Bar Sliver
                      SliverToBoxAdapter(
                        child: _buildThemedAppBar(style, isDark, cs),
                      ),

                      // 2. Live Announcement / Emergency Broadcast Card
                      ValueListenableBuilder<Map<String, dynamic>?>(
                        valueListenable: RemoteConfigService.liveAnnouncement,
                        builder: (context, broadcast, _) {
                          final isBroadcastEnabled =
                              broadcast?['enabled'] == true;
                          final broadcastMsg =
                              broadcast?['message']?.toString() ?? '';

                          if (!isBroadcastEnabled || broadcastMsg.trim().isEmpty) {
                            return const SliverToBoxAdapter(
                              child: SizedBox.shrink(),
                            );
                          }

                          final date = _parseNoticeDate(broadcast!['updated_at']);
                          final timeStr = _formatRelativeTime(date);

                          return SliverToBoxAdapter(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                              child: _buildThemedEmergencyCard(
                                style,
                                isDark,
                                cs,
                                broadcastMsg,
                                timeStr,
                              ),
                            ),
                          );
                        },
                      ),

                      // 3. Search Bar
                      SliverToBoxAdapter(
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                          child: _buildThemedSearchBar(style, isDark, cs),
                        ),
                      ),

                      // 4. Category Filter Chips
                      SliverToBoxAdapter(
                        child: Padding(
                          padding: const EdgeInsets.only(top: 14, bottom: 4),
                          child: SizedBox(
                            height: 38,
                            child: ListView.separated(
                              scrollDirection: Axis.horizontal,
                              physics: const BouncingScrollPhysics(),
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              itemCount: _categories.length,
                              separatorBuilder: (_, _) => const SizedBox(width: 8),
                              itemBuilder: (context, index) {
                                final cat = _categories[index];
                                final isSelected = _selectedCategory == cat;
                                return _buildThemedChip(
                                  style,
                                  isDark,
                                  cs,
                                  cat,
                                  isSelected,
                                );
                              },
                            ),
                          ),
                        ),
                      ),

                  // 5. Notices List Stream from RemoteConfigService.liveNotices
                  ValueListenableBuilder<List<Map<String, dynamic>>>(
                    valueListenable: RemoteConfigService.liveNotices,
                    builder: (context, rawNotices, _) {
                      // Filter notices by category & search query
                      final filtered = rawNotices.where((notice) {
                        final isEnabled = notice['enabled'] != false;
                        if (!isEnabled) return false;

                        final title = (notice['title'] ?? '').toString().toLowerCase();
                        final detail = (notice['detail'] ??
                                notice['message'] ??
                                notice['body'] ??
                                '')
                            .toString()
                            .toLowerCase();
                        final author = (notice['author'] ??
                                notice['createdBy'] ??
                                '')
                            .toString()
                            .toLowerCase();
                        final category = (notice['category'] ?? 'General')
                            .toString();

                        // Category filter
                        if (_selectedCategory != 'All') {
                          if (category.toLowerCase() !=
                              _selectedCategory.toLowerCase()) {
                            return false;
                          }
                        }

                        // Search query filter
                        if (_searchQuery.isNotEmpty) {
                          final q = _searchQuery.toLowerCase();
                          if (!title.contains(q) &&
                              !detail.contains(q) &&
                              !author.contains(q)) {
                            return false;
                          }
                        }

                        // Filter out dummy/test items
                        if (title.trim() == '.' ||
                            title.trim().isEmpty ||
                            title == 'dummy' ||
                            title == 'test') {
                          return false;
                        }

                        return true;
                      }).toList();

                      if (filtered.isEmpty) {
                        return SliverFillRemaining(
                          hasScrollBody: false,
                          child: Center(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 36,
                                vertical: 40,
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Container(
                                    width: 72,
                                    height: 72,
                                    decoration: BoxDecoration(
                                      color: cs.primary.withValues(alpha: 0.12),
                                      shape: BoxShape.circle,
                                    ),
                                    child: Center(
                                      child: Icon(
                                        Icons.notifications_off_rounded,
                                        size: 36,
                                        color: cs.primary,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 18),
                                  Text(
                                    _searchQuery.isNotEmpty
                                        ? 'No Notices Found'
                                        : 'All Quiet on Campus',
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w900,
                                      color: cs.onSurface,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    _searchQuery.isNotEmpty
                                        ? 'No announcements match "$_searchQuery". Try different keywords or clear the search.'
                                        : 'No active notices found in "$_selectedCategory". When campus administration broadcasts an announcement, it appears here live.',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 13,
                                      color: cs.onSurfaceVariant,
                                      height: 1.45,
                                    ),
                                  ),
                                  if (_searchQuery.isNotEmpty ||
                                      _selectedCategory != 'All') ...[
                                    const SizedBox(height: 16),
                                    TextButton.icon(
                                      onPressed: () {
                                        _searchController.clear();
                                        setState(() {
                                          _searchQuery = '';
                                          _selectedCategory = 'All';
                                        });
                                      },
                                      icon: const Icon(Icons.refresh_rounded, size: 16),
                                      label: const Text(
                                        'Reset Filters',
                                        style: TextStyle(fontWeight: FontWeight.w800),
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        );
                      }

                      return SliverPadding(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 80),
                        sliver: SliverList(
                          delegate: SliverChildBuilderDelegate(
                            (context, index) {
                              final notice = filtered[index];
                              final cardChild = _buildThemedNoticeCard(
                                style,
                                isDark,
                                cs,
                                notice,
                              );

                              return Padding(
                                padding: const EdgeInsets.only(bottom: 12),
                                child: ExpressiveInteractivePress(
                                  onTap: () {
                                    _showNoticeDetailModal(
                                      context,
                                      notice,
                                      isDark,
                                      isM3,
                                      cs,
                                    );
                                  },
                                  child: cardChild,
                                ),
                              );
                            },
                            childCount: filtered.length,
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
      },
    );
  }
}
