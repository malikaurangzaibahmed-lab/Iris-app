import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/theme_signals.dart';
import '../../core/animations.dart';
import '../../core/vital_theme.dart';
import '../../services/ui_feedback.dart';
import '../../widgets/iris_components.dart';
import 'theme_selector_screen.dart';

/// Unified, Non-Duplicated Appearance & Visual Experience Studio.
/// Provides a single authoritative 7-Theme Live Interactive Preview Stage,
/// Design Engine Selector, and contextual customization controls (showing
/// Glass Refraction controls ONLY when Liquid Glass is active, and Monet
/// Accent Palettes ONLY when Material 3 is active).
class AppearanceSettingsScreen extends StatefulWidget {
  final String? currentThemeMode;
  final Future<void> Function(String)? onSetThemeMode;

  const AppearanceSettingsScreen({
    super.key,
    this.currentThemeMode,
    this.onSetThemeMode,
  });

  @override
  State<AppearanceSettingsScreen> createState() => _AppearanceSettingsScreenState();
}

class _AppearanceSettingsScreenState extends State<AppearanceSettingsScreen> {
  late String _currentMode;

  @override
  void initState() {
    super.initState();
    _currentMode = widget.currentThemeMode ?? 'system';
    _loadStoredThemeMode();
  }

  Future<void> _loadStoredThemeMode() async {
    final prefs = await SharedPreferences.getInstance();
    final stored = prefs.getString('theme_mode') ?? prefs.getString('app_theme_mode');
    if (stored != null && mounted) {
      setState(() => _currentMode = stored);
    }
  }

  Future<void> _setMode(String mode) async {
    IrisHaptics.chipSelect();
    setState(() => _currentMode = mode);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('theme_mode', mode);
    await prefs.setString('app_theme_mode', mode);
    await widget.onSetThemeMode?.call(mode);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, _, _) {
        return Scaffold(
          extendBodyBehindAppBar: true,
          backgroundColor: Colors.transparent,
          appBar: irisFrostedAppBar(
            title: 'Appearance & Themes',
            isDark: isDark,
            leading: AppBackButton(isDark: isDark),
          ),
          body: Stack(
            fit: StackFit.expand,
            children: [
              ObsidianPulse(isDark: isDark),
              SafeArea(
                child: IrisThemeSelectorView(
                  isEmbedded: false,
                  initialThemeMode: _currentMode,
                  onThemeModeChanged: _setMode,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
