import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../core/models.dart';
import '../../core/vital_theme.dart';
import '../../core/theme_signals.dart';
import '../../core/animations.dart';
import '../../services/ui_feedback.dart';
import '../../services/timetable_ota_service.dart';
import '../../services/notification_service.dart';
import '../../widgets/glass_card.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';

/// Phone-like Data, Storage & Cache Sub-Screen.
/// Offers full visibility into edge-cloud synchronization, cache metrics, and portal storage.
class DataStorageSettingsScreen extends StatefulWidget {
  final UniversityMemory memory;

  const DataStorageSettingsScreen({
    super.key,
    required this.memory,
  });

  @override
  State<DataStorageSettingsScreen> createState() => _DataStorageSettingsScreenState();
}

class _DataStorageSettingsScreenState extends State<DataStorageSettingsScreen> {
  bool _isSyncing = false;
  int _savedLoginsCount = 0;
  int _downloadHistoryCount = 0;

  @override
  void initState() {
    super.initState();
    _loadStorageTelemetry();
  }

  Future<void> _loadStorageTelemetry() async {
    final prefs = await SharedPreferences.getInstance();
    int logins = 0;
    int downloads = 0;

    for (final key in prefs.getKeys()) {
      if (key.startsWith('iris_login_')) logins++;
      if (key.startsWith('iris_download_')) downloads++;
    }

    if (mounted) {
      setState(() {
        _savedLoginsCount = logins;
        _downloadHistoryCount = downloads;
      });
    }
  }

  Future<void> _syncTimetableNow() async {
    if (_isSyncing) return;
    IrisHaptics.actionMedium();
    setState(() => _isSyncing = true);

    try {
      final result = await TimetableOTAService.forceRefresh();
      await NotificationSyncService.instance.syncClassRemindersFromPrefs();

      if (mounted) {
        setState(() => _isSyncing = false);
        IrisHaptics.actionHeavy();
        final String message = switch (result) {
          1 => 'New timetable update synced from cloud edge!',
          0 => 'Timetable is already up to date with cloud edge.',
          _ => 'Edge cloud synchronization complete (offline ready).',
        };
        showIrisFrostedSnackBar(
          context,
          content: Row(
            children: [
              const Icon(Icons.check_circle_rounded, color: Colors.white, size: 20),
              const SizedBox(width: 12),
              Expanded(child: Text(message)),
            ],
          ),
          tint: const Color(0xFF10B981),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isSyncing = false);
        showIrisFrostedSnackBar(
          context,
          content: Text('Sync notice: $e'),
          tint: VitalTokens.error,
        );
      }
    }
  }

  Future<void> _clearLocalCaches() async {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogCtx) {
        return AlertDialog(
          backgroundColor: isM3 ? cs.surfaceContainerHigh : (isDark ? const Color(0xFF1E293B) : Colors.white),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: const Text('Clear Local Storage & Caches?'),
          content: const Text(
            'This will clear cached timetable drafts, temporary files, and downloaded preview states. Your saved batch and preferences will be preserved.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogCtx, false),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: VitalTokens.error,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: () => Navigator.pop(dialogCtx, true),
              child: const Text('Clear Cache'),
            ),
          ],
        );
      },
    );

    if (confirmed == true && mounted) {
      IrisHaptics.actionHeavy();
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('helpdesk_faculty_cache_v2');
      await prefs.remove('helpdesk_has_doc_draft');
      await prefs.remove('cached_timetable_diffs');
      await prefs.remove('ota_cached_timetable');
      await prefs.remove('ota_last_check_time');
      await prefs.remove('cached_vacation_schedule');
      await prefs.remove('cached_midterm_exams');
      await prefs.remove('cached_finals_exams');

      if (mounted) {
        showIrisFrostedSnackBar(
          context,
          content: const Text('Local caches cleared successfully'),
          tint: const Color(0xFF10B981),
        );
      }
    }
  }

  Future<void> _clearSavedPortalCredentials() async {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogCtx) {
        return AlertDialog(
          backgroundColor: isM3 ? cs.surfaceContainerHigh : (isDark ? const Color(0xFF1E293B) : Colors.white),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: const Text('Clear Saved Portal Logins?'),
          content: const Text(
            'This will remove all auto-saved roll numbers, student passwords, and portal session tokens stored on this device.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogCtx, false),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: VitalTokens.error,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: () => Navigator.pop(dialogCtx, true),
              child: const Text('Clear Logins'),
            ),
          ],
        );
      },
    );

    if (confirmed == true && mounted) {
      IrisHaptics.actionHeavy();
      final prefs = await SharedPreferences.getInstance();
      final keysToRemove = prefs
          .getKeys()
          .where((k) => k.startsWith('iris_login_') || k.startsWith('iris_portal_'))
          .toList();
      for (final k in keysToRemove) {
        await prefs.remove(k);
      }
      try {
        final cookieManager = WebViewCookieManager();
        await cookieManager.clearCookies();
      } catch (_) {}
      await _loadStorageTelemetry();

      if (mounted) {
        showIrisFrostedSnackBar(
          context,
          content: const Text('Saved portal logins & cookies removed'),
          tint: const Color(0xFF10B981),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorial;
    final isNotebook = ThemeSignals.isNotebook;
    final isLine = ThemeSignals.isLine;
    final isPoster = ThemeSignals.isPoster;
    final cs = Theme.of(context).colorScheme;
    final activeSessionsCount = widget.memory.sessions.length;
    final batchesCount = widget.memory.allBatches.length;

    final TextStyle appBarTitleStyle;
    if (isAlmanac) {
      appBarTitleStyle = AlmanacTokens.serifHeadline(isDark, fontSize: 18, fontWeight: FontWeight.w800);
    } else if (isEditorial) {
      appBarTitleStyle = EditorialTokens.headingSerif(isDark, fontSize: 18, fontWeight: FontWeight.w900);
    } else if (isNotebook) {
      appBarTitleStyle = NotebookTokens.boldScript(isDark, fontSize: 19);
    } else if (isLine) {
      appBarTitleStyle = LineTokens.stationName(isDark).copyWith(fontSize: 17, fontWeight: FontWeight.w900);
    } else if (isPoster) {
      appBarTitleStyle = PosterTokens.classTitle(isDark).copyWith(fontSize: 17, fontWeight: FontWeight.w900);
    } else if (isM3) {
      appBarTitleStyle = TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: cs.onSurface);
    } else {
      appBarTitleStyle = TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w900,
        color: isDark ? Colors.white : const Color(0xFF0F172A),
      );
    }

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: ExpressiveInteractivePress(
          pressedScale: 0.90,
          onTap: () => Navigator.of(context).pop(),
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: isM3
                  ? cs.surfaceContainer
                  : (isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.06)),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.arrow_back_rounded,
              size: 20,
              color: isDark ? Colors.white : const Color(0xFF0F172A),
            ),
          ),
        ),
        title: Text(
          'Data, Storage & Sync',
          style: appBarTitleStyle,
        ),
      ),
      body: Stack(
        children: [
          ObsidianPulse(isDark: isDark),
          SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 720),
                child: ListView(
                  physics: const ButterScrollPhysics(
                    parent: AlwaysScrollableScrollPhysics(),
                  ),
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
                  children: [
                    // 1. Cloud Sync Status Card
                    _buildSectionHeader('Cloud & Edge Synchronization'),
                    const SizedBox(height: 10),
                    GlassCard(
                      borderRadius: 22,
                      elevation: 2,
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF10B981).withValues(alpha: isDark ? 0.20 : 0.12),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: const Icon(Icons.cloud_done_rounded, color: Color(0xFF10B981), size: 22),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Supabase Edge Cache',
                                      style: TextStyle(
                                        fontSize: 14.5,
                                        fontWeight: FontWeight.w900,
                                        color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      'Low-latency CDN mirrors timetables to protect university servers',
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF10B981).withValues(alpha: 0.18),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: const Text(
                                  'CONNECTED',
                                  style: TextStyle(
                                    fontSize: 9,
                                    fontWeight: FontWeight.w900,
                                    color: Color(0xFF10B981),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: isM3 ? cs.primary : VitalTokens.blue,
                                foregroundColor: isM3 ? cs.onPrimary : Colors.white,
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                                elevation: 0,
                              ),
                              onPressed: _isSyncing ? null : _syncTimetableNow,
                              icon: _isSyncing
                                  ? const SizedBox(
                                      width: 16,
                                      height: 16,
                                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                    )
                                  : const Icon(Icons.sync_rounded, size: 18),
                              label: Text(
                                _isSyncing ? 'Synchronizing...' : 'Sync Timetable Now',
                                style: const TextStyle(fontWeight: FontWeight.w800),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // 2. Local Storage Footprint
                    _buildSectionHeader('Device Storage Footprint'),
                    const SizedBox(height: 10),
                    GlassCard(
                      borderRadius: 22,
                      elevation: 2,
                      padding: EdgeInsets.zero,
                      child: Column(
                        children: [
                          _buildTelemetryRow(
                            title: 'Active Lecture Sessions',
                            value: '$activeSessionsCount cached slots',
                            icon: Icons.schedule_rounded,
                            iconColor: VitalTokens.blue,
                          ),
                          const Divider(height: 1, indent: 58),
                          _buildTelemetryRow(
                            title: 'Registered Academic Batches',
                            value: '$batchesCount degree cohorts',
                            icon: Icons.school_rounded,
                            iconColor: VitalTokens.purple,
                          ),
                          const Divider(height: 1, indent: 58),
                          _buildTelemetryRow(
                            title: 'Saved Portal Logins',
                            value: '$_savedLoginsCount secure credentials',
                            icon: Icons.key_rounded,
                            iconColor: const Color(0xFFF59E0B),
                          ),
                          const Divider(height: 1, indent: 58),
                          _buildTelemetryRow(
                            title: 'Portal Transfer History',
                            value: '$_downloadHistoryCount tracked files',
                            icon: Icons.folder_zip_rounded,
                            iconColor: const Color(0xFF10B981),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // 3. Maintenance & Storage Actions
                    _buildSectionHeader('Storage Maintenance'),
                    const SizedBox(height: 10),
                    GlassCard(
                      borderRadius: 22,
                      elevation: 2,
                      padding: EdgeInsets.zero,
                      child: Column(
                        children: [
                          _buildActionTile(
                            title: 'Clear Application Caches',
                            subtitle: 'Removes cached drafts and temporary timetable diffs',
                            icon: Icons.cleaning_services_rounded,
                            iconColor: Colors.amber,
                            onTap: _clearLocalCaches,
                          ),
                          const Divider(height: 1, indent: 58),
                          _buildActionTile(
                            title: 'Clear Saved Portal Logins',
                            subtitle: 'Erases all saved roll numbers and auto-fill keys',
                            icon: Icons.no_accounts_rounded,
                            iconColor: VitalTokens.error,
                            onTap: _clearSavedPortalCredentials,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String label) {
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorial;
    final isNotebook = ThemeSignals.isNotebook;
    final isLine = ThemeSignals.isLine;
    final isPoster = ThemeSignals.isPoster;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    if (isAlmanac) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Row(
          children: [
            Text(
              '§ ${label.toUpperCase()}',
              style: AlmanacTokens.monoHeader(
                isDark,
                fontSize: 10.5,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.2,
                color: AlmanacTokens.accentTerracotta(isDark),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Container(
                height: 0.8,
                color: AlmanacTokens.inkRuleSubtle(isDark),
              ),
            ),
          ],
        ),
      );
    }

    if (isEditorial) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Row(
          children: [
            Text(
              label.toUpperCase(),
              style: EditorialTokens.monoLabel(
                isDark,
                fontSize: 10.5,
              ).copyWith(letterSpacing: 1.2, fontWeight: FontWeight.w800),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Container(
                height: 0.8,
                color: EditorialTokens.cardBorder(isDark),
              ),
            ),
          ],
        ),
      );
    }

    if (isLine) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Text(
          '[SECTION // ${label.toUpperCase()}]',
          style: LineTokens.stationMeta(isDark).copyWith(
            fontSize: 10.5,
            fontWeight: FontWeight.w800,
            color: LineTokens.railLine(isDark),
          ),
        ),
      );
    }

    if (isNotebook) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Text(
          '• $label',
          style: NotebookTokens.boldScript(
            isDark,
            fontSize: 14,
          ).copyWith(color: NotebookTokens.redDoodle(isDark)),
        ),
      );
    }

    if (isPoster) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: PosterTokens.orangeHero,
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text(
            label.toUpperCase(),
            style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w900,
              color: Colors.black,
              letterSpacing: 0.8,
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(left: 6),
      child: Text(
        label.toUpperCase(),
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.1,
          color: isM3 ? cs.primary : (isDark ? Colors.white60 : const Color(0xFF64748B)),
        ),
      ),
    );
  }

  Widget _buildTelemetryRow({
    required String title,
    required String value,
    required IconData icon,
    required Color iconColor,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: isDark ? 0.20 : 0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: iconColor, size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              title,
              style: TextStyle(
                fontSize: 13.5,
                fontWeight: FontWeight.w800,
                color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
              ),
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 11.5,
              fontWeight: FontWeight.w600,
              color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionTile({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color iconColor,
    required VoidCallback onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    return InkWell(
      onTap: () {
        IrisHaptics.actionSoft();
        onTap();
      },
      borderRadius: BorderRadius.circular(20),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: iconColor.withValues(alpha: isDark ? 0.20 : 0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: iconColor, size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w800,
                      color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 10.5,
                      color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.chevron_right_rounded,
              size: 20,
              color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white30 : Colors.black26),
            ),
          ],
        ),
      ),
    );
  }
}
