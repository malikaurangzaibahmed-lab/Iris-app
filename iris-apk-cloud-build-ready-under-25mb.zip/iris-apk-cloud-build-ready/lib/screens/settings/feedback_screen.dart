import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/tokens.dart';
import '../../core/theme_signals.dart';
import '../../core/vital_theme.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../services/ui_feedback.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/iris_components.dart';
import 'package:iris/widgets/controls/iris_liquid_button.dart';
import '../../core/animations.dart';

/// Ultra-Streamlined In-App User Feedback Transceiver for IRIS Mobile Client.
/// Pre-fills user profile details, role, batch, roll number, and hardware telemetry.
class FeedbackScreen extends StatefulWidget {
  final VoidCallback? onBackPressed;
  final bool? isDark;

  const FeedbackScreen({
    super.key,
    this.onBackPressed,
    this.isDark,
  });

  @override
  State<FeedbackScreen> createState() => _FeedbackScreenState();
}

class _FeedbackScreenState extends State<FeedbackScreen> {
  final _commentController = TextEditingController();

  String _userRole = 'Student';
  String _userName = 'IRIS Student';
  String _userBatch = 'SP26-BCS-1-A';
  String _rollNumber = 'SP26-BCS-001';
  String _deviceSpecs = 'Detecting device telemetry...';
  String _category = 'General Feedback';
  int _selectedRating = 5;
  bool _isSubmitting = false;

  static const List<String> _categories = [
    'General Feedback',
    'Bug Report',
    'Feature Request',
    'Timetable Issue',
    'UI & Theme',
  ];

  @override
  void initState() {
    super.initState();
    _autoPrefillAllTelemetryData();
  }

  void _autoPrefillAllTelemetryData() async {
    final prefs = await SharedPreferences.getInstance();

    // Auto-detect role
    final savedRole = (prefs.getString('active_role') ?? prefs.getString('user_role') ?? prefs.getString('role') ?? '').toLowerCase();
    String detectedRole = 'Student';
    if (savedRole.contains('faculty') || savedRole.contains('teacher') || savedRole.contains('instructor') || savedRole.contains('prof')) {
      detectedRole = 'Faculty';
    }

    String name = 'IRIS Mobile User';
    String batch = 'SP26-BCS-1-A';
    String roll = 'SP26-BCS-001';

    if (detectedRole == 'Faculty') {
      name = prefs.getString('faculty_user_name') ??
             prefs.getString('faculty_teacher') ??
             prefs.getString('student_name') ??
             prefs.getString('user_name') ??
             prefs.getString('name') ??
             'Faculty Member';

      batch = prefs.getString('faculty_department') ??
              prefs.getString('department') ??
              prefs.getString('faculty_dept') ??
              'COMSATS Faculty';

      roll = prefs.getString('faculty_id') ??
             prefs.getString('employee_id') ??
             prefs.getString('faculty_emp_id') ??
             'FACULTY-ID';
    } else {
      name = prefs.getString('student_user_name')?.trim().isNotEmpty == true
          ? prefs.getString('student_user_name')!.trim()
          : (prefs.getString('student_name') ??
             prefs.getString('user_name') ??
             prefs.getString('name') ??
             'IRIS Student');

      batch = prefs.getString('student_batch') ??
                    prefs.getString('current_batch') ??
                    prefs.getString('user_batch') ??
                    prefs.getString('selected_batch') ??
                    'SP26-BCS-1-A';

      roll = prefs.getString('student_roll_no') ??
                    prefs.getString('roll_no') ??
                    prefs.getString('student_id') ??
                    prefs.getString('roll_number') ??
                    'SP26-BCS-001';
    }

    // Auto-detect device hardware specs
    String specs = 'Android Device';
    try {
      final deviceInfo = DeviceInfoPlugin();
      final androidInfo = await deviceInfo.androidInfo;
      final manufacturer = androidInfo.manufacturer.toUpperCase();
      final model = androidInfo.model;
      final release = androidInfo.version.release;
      final sdk = androidInfo.version.sdkInt;
      specs = '$manufacturer $model • Android $release (SDK $sdk)';
    } catch (_) {}

    if (mounted) {
      setState(() {
        _userRole = detectedRole;
        _userName = name;
        _userBatch = batch;
        _rollNumber = roll;
        _deviceSpecs = specs;
      });
    }
  }

  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }

  void _submitFeedback() async {
    final comment = _commentController.text.trim();
    if (comment.isEmpty) {
      IrisHaptics.actionMedium();
      showIrisFrostedSnackBar(
        context,
        content: const Text('Please type your feedback or suggestion before sending.'),
        tint: Colors.amber,
      );
      return;
    }

    IrisHaptics.actionHeavy();
    setState(() => _isSubmitting = true);

    try {
      await FirebaseFirestore.instance.collection('feedback').add({
        'name': _userName,
        'user_role': _userRole,
        'roll_number': _rollNumber,
        'batch': _userBatch,
        'device': _deviceSpecs,
        'category': _category,
        'rating': _selectedRating,
        'comment': comment,
        'created_at': FieldValue.serverTimestamp(),
        'platform': 'Android Mobile Client',
      });

      if (mounted) {
        showIrisFrostedSnackBar(
          context,
          content: const Text(
            '✅ Feedback transmitted live to Admin Console!',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          tint: IrisTokens.brand,
        );
        _commentController.clear();
        setState(() => _selectedRating = 5);
      }
    } catch (e) {
      if (mounted) {
        showIrisFrostedSnackBar(
          context,
          content: Text('Failed to submit feedback: $e'),
          tint: Colors.redAccent,
        );
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final effectiveIsDark = widget.isDark ?? (Theme.of(context).brightness == Brightness.dark);
    return ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, style, _) {
        switch (style) {
          case IrisThemeStyle.notebook:
            return _buildNotebookFeedback(context, effectiveIsDark);
          case IrisThemeStyle.line:
            return _buildLineFeedback(context, effectiveIsDark);
          case IrisThemeStyle.poster:
            return _buildPosterFeedback(context, effectiveIsDark);
          case IrisThemeStyle.almanac:
            return _buildAlmanacFeedback(context, effectiveIsDark);
          case IrisThemeStyle.editorialAcademic:
            return _buildEditorialFeedback(context, effectiveIsDark);
          case IrisThemeStyle.materialYou:
            return _buildMaterialYouFeedback(context, effectiveIsDark);
          case IrisThemeStyle.fluidGlass:
            return _buildFluidGlassFeedback(context, effectiveIsDark);
        }
      },
    );
  }

  // ===========================================================================
  // 1. NOTEBOOK THEME
  // ===========================================================================
  Widget _buildNotebookFeedback(BuildContext context, bool effectiveIsDark) {
    final canvas = NotebookTokens.canvas(effectiveIsDark);
    final cardBg = NotebookTokens.cardSurface(effectiveIsDark);
    final heading = NotebookTokens.inkHeading(effectiveIsDark);
    final body = NotebookTokens.inkBody(effectiveIsDark);
    final muted = NotebookTokens.inkMuted(effectiveIsDark);
    final doodleRed = NotebookTokens.redDoodle(effectiveIsDark);

    return Scaffold(
      backgroundColor: canvas,
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: NotebookGraphPaperPainter(
                isDark: effectiveIsDark,
                gridSize: 22.0,
                marginX: 42.0,
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: widget.onBackPressed ?? () => Navigator.of(context).maybePop(),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: cardBg,
                            shape: BoxShape.circle,
                            border: Border.all(color: muted.withValues(alpha: 0.3), width: 1.5),
                          ),
                          child: Icon(Icons.arrow_back_rounded, color: heading, size: 20),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Text(
                          'Student Feedback',
                          style: GoogleFonts.kalam(fontSize: 22, fontWeight: FontWeight.w700, color: heading),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: NotebookTokens.tapeYellow,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          'DISPATCH',
                          style: GoogleFonts.kalam(fontSize: 11, fontWeight: FontWeight.w700, color: const Color(0xFF1A1F1C)),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(44, 8, 20, 40),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 720),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Identity Note
                            Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: cardBg,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: muted.withValues(alpha: 0.25), width: 1.5),
                              ),
                              child: Row(
                                children: [
                                  CircleAvatar(
                                    backgroundColor: doodleRed.withValues(alpha: 0.15),
                                    child: Text(_userName.isNotEmpty ? _userName[0].toUpperCase() : 'U',
                                        style: GoogleFonts.kalam(fontWeight: FontWeight.bold, color: doodleRed)),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text('$_userName ($_userRole)',
                                            style: GoogleFonts.kalam(fontSize: 15, fontWeight: FontWeight.w700, color: heading)),
                                        Text('$_userBatch • $_deviceSpecs',
                                            style: GoogleFonts.plusJakartaSans(fontSize: 11, color: muted)),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 18),

                            // Categories
                            Text('CATEGORY', style: GoogleFonts.kalam(fontSize: 13, fontWeight: FontWeight.w700, color: doodleRed)),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: _categories.map((cat) {
                                final isSelected = cat == _category;
                                return GestureDetector(
                                  onTap: () {
                                    IrisHaptics.chipSelect();
                                    setState(() => _category = cat);
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                    decoration: BoxDecoration(
                                      color: isSelected ? NotebookTokens.stickyNote(effectiveIsDark) : cardBg,
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(color: isSelected ? doodleRed : muted.withValues(alpha: 0.3), width: 1.2),
                                    ),
                                    child: Text(
                                      cat,
                                      style: GoogleFonts.kalam(
                                        fontSize: 12,
                                        fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                                        color: isSelected ? const Color(0xFF1A1F1C) : body,
                                      ),
                                    ),
                                  ),
                                );
                              }).toList(),
                            ),
                            const SizedBox(height: 18),

                            // Rating
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              decoration: BoxDecoration(
                                color: cardBg,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: muted.withValues(alpha: 0.25), width: 1.5),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('EXPERIENCE RATING', style: GoogleFonts.kalam(fontSize: 12, fontWeight: FontWeight.w700, color: doodleRed)),
                                  Row(
                                    children: List.generate(5, (index) {
                                      final starRating = index + 1;
                                      final isFilled = starRating <= _selectedRating;
                                      return GestureDetector(
                                        onTap: () {
                                          IrisHaptics.selectionClick();
                                          setState(() => _selectedRating = starRating);
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(horizontal: 4),
                                          child: Icon(
                                            isFilled ? Icons.star_rounded : Icons.star_outline_rounded,
                                            color: isFilled ? const Color(0xFFF59E0B) : muted.withValues(alpha: 0.4),
                                            size: 28,
                                          ),
                                        ),
                                      );
                                    }),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 18),

                            // Comment Box
                            Text('YOUR THOUGHTS / SUGGESTION', style: GoogleFonts.kalam(fontSize: 13, fontWeight: FontWeight.w700, color: doodleRed)),
                            const SizedBox(height: 8),
                            Container(
                              decoration: BoxDecoration(
                                color: cardBg,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: muted.withValues(alpha: 0.3), width: 1.5),
                              ),
                              child: TextFormField(
                                controller: _commentController,
                                maxLines: 5,
                                style: GoogleFonts.plusJakartaSans(fontSize: 13.5, color: body),
                                decoration: InputDecoration(
                                  hintText: 'Jot down bugs, ideas, or timetable discrepancies...',
                                  hintStyle: GoogleFonts.kalam(fontSize: 13, color: muted.withValues(alpha: 0.7)),
                                  border: InputBorder.none,
                                  contentPadding: const EdgeInsets.all(14),
                                ),
                              ),
                            ),
                            const SizedBox(height: 24),

                            // Submit Button
                            GestureDetector(
                              onTap: _isSubmitting ? null : _submitFeedback,
                              child: Container(
                                width: double.infinity,
                                height: 50,
                                decoration: BoxDecoration(
                                  color: NotebookTokens.stickyNote(effectiveIsDark),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: const Color(0xFF1A1F1C), width: 1.5),
                                  boxShadow: [
                                    BoxShadow(color: Colors.black.withValues(alpha: 0.12), blurRadius: 6, offset: const Offset(0, 3)),
                                  ],
                                ),
                                alignment: Alignment.center,
                                child: Text(
                                  _isSubmitting ? 'SENDING NOTE...' : 'PIN FEEDBACK TO BOARD',
                                  style: GoogleFonts.kalam(fontSize: 15, fontWeight: FontWeight.w800, color: const Color(0xFF1A1F1C)),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ===========================================================================
  // 2. LINE THEME
  // ===========================================================================
  Widget _buildLineFeedback(BuildContext context, bool effectiveIsDark) {
    final canvas = LineTokens.canvas(effectiveIsDark);
    final cardBg = LineTokens.cardSurface(effectiveIsDark);
    final railColor = LineTokens.railLine(effectiveIsDark);
    final heading = LineTokens.inkHeading(effectiveIsDark);
    final body = LineTokens.inkBody(effectiveIsDark);
    final muted = LineTokens.inkMuted(effectiveIsDark);

    return Scaffold(
      backgroundColor: canvas,
      body: SafeArea(
        child: Column(
          children: [
            Container(height: 4, width: double.infinity, color: railColor),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: widget.onBackPressed ?? () => Navigator.of(context).maybePop(),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: cardBg,
                        border: Border.all(color: railColor, width: 1.5),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Icon(Icons.arrow_back_rounded, color: heading, size: 18),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('TRANSIT DISPATCH', style: GoogleFonts.archivoBlack(fontSize: 18, color: heading)),
                        Text('TERMINAL INCIDENT & SUGGESTION LOG', style: GoogleFonts.spaceMono(fontSize: 10, color: railColor, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(height: 1, color: muted.withValues(alpha: 0.2)),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 40),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 720),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Operator Badge
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: cardBg,
                            border: Border.all(color: railColor, width: 1.5),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            children: [
                              Container(width: 8, height: 8, decoration: const BoxDecoration(color: LineTokens.subwayGreen, shape: BoxShape.circle)),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text('OPERATOR: $_userName // $_userBatch',
                                    style: GoogleFonts.spaceMono(fontSize: 12, fontWeight: FontWeight.w700, color: heading)),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Categories
                        Text('INCIDENT CATEGORY', style: GoogleFonts.spaceMono(fontSize: 11, fontWeight: FontWeight.w900, color: railColor)),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: _categories.map((cat) {
                            final isSelected = cat == _category;
                            return GestureDetector(
                              onTap: () {
                                IrisHaptics.chipSelect();
                                setState(() => _category = cat);
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                decoration: BoxDecoration(
                                  color: isSelected ? LineTokens.subwayYellow : cardBg,
                                  border: Border.all(color: isSelected ? LineTokens.subwayYellow : muted.withValues(alpha: 0.3), width: 1.5),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  cat.toUpperCase(),
                                  style: GoogleFonts.spaceMono(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: isSelected ? Colors.black : heading,
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                        const SizedBox(height: 18),

                        // Stars
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: cardBg,
                            border: Border.all(color: muted.withValues(alpha: 0.25), width: 1.5),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('SATISFACTION INDEX', style: GoogleFonts.spaceMono(fontSize: 11, fontWeight: FontWeight.w700, color: railColor)),
                              Row(
                                children: List.generate(5, (index) {
                                  final starRating = index + 1;
                                  final isFilled = starRating <= _selectedRating;
                                  return GestureDetector(
                                    onTap: () {
                                      IrisHaptics.selectionClick();
                                      setState(() => _selectedRating = starRating);
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 4),
                                      child: Icon(
                                        isFilled ? Icons.star_rounded : Icons.star_outline_rounded,
                                        color: isFilled ? LineTokens.subwayYellow : muted.withValues(alpha: 0.3),
                                        size: 26,
                                      ),
                                    ),
                                  );
                                }),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 18),

                        // Input
                        Text('TRANSMISSION LOG', style: GoogleFonts.spaceMono(fontSize: 11, fontWeight: FontWeight.w900, color: railColor)),
                        const SizedBox(height: 8),
                        Container(
                          decoration: BoxDecoration(
                            color: cardBg,
                            border: Border.all(color: muted.withValues(alpha: 0.3), width: 1.5),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: TextFormField(
                            controller: _commentController,
                            maxLines: 5,
                            style: GoogleFonts.inter(fontSize: 13.5, color: body),
                            decoration: InputDecoration(
                              hintText: 'Transmit technical anomalies or recommendations...',
                              hintStyle: GoogleFonts.spaceMono(fontSize: 11, color: muted.withValues(alpha: 0.6)),
                              border: InputBorder.none,
                              contentPadding: const EdgeInsets.all(14),
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),

                        // Transmit Button
                        GestureDetector(
                          onTap: _isSubmitting ? null : _submitFeedback,
                          child: Container(
                            width: double.infinity,
                            height: 50,
                            decoration: BoxDecoration(
                              color: LineTokens.subwayYellow,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            alignment: Alignment.center,
                            child: Text(
                              _isSubmitting ? 'TRANSMITTING PACKET...' : 'TRANSMIT TO DISPATCH TERMINAL',
                              style: GoogleFonts.spaceMono(fontSize: 12, fontWeight: FontWeight.w900, color: Colors.black),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===========================================================================
  // 3. POSTER THEME
  // ===========================================================================
  Widget _buildPosterFeedback(BuildContext context, bool effectiveIsDark) {
    final canvas = PosterTokens.canvas(effectiveIsDark);
    final cardBg = PosterTokens.cardSurface(effectiveIsDark);
    final inkBorder = PosterTokens.inkBorder(effectiveIsDark);
    final heading = PosterTokens.inkHeading(effectiveIsDark);
    final body = PosterTokens.inkBody(effectiveIsDark);

    return Scaffold(
      backgroundColor: canvas,
      body: SafeArea(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                border: Border(bottom: BorderSide(color: inkBorder, width: 2.5)),
              ),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: widget.onBackPressed ?? () => Navigator.of(context).maybePop(),
                    child: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: cardBg,
                        border: Border.all(color: inkBorder, width: 2.5),
                      ),
                      child: Icon(Icons.arrow_back_rounded, color: heading, size: 22),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('FEEDBACK DISPATCH', style: GoogleFonts.archivoBlack(fontSize: 20, letterSpacing: -0.8, color: heading)),
                        Text('SWISS OPINION MANIFESTO', style: GoogleFonts.spaceMono(fontSize: 10, fontWeight: FontWeight.w700, color: PosterTokens.orangeHero)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 40),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 720),
                    child: Container(
                      decoration: BoxDecoration(
                        color: cardBg,
                        border: Border.all(color: inkBorder, width: 2.5),
                        boxShadow: [
                          BoxShadow(color: inkBorder, offset: const Offset(6, 6), blurRadius: 0),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                            color: PosterTokens.orangeHero,
                            child: Text(
                              'AUTHOR: $_userName // $_userBatch'.toUpperCase(),
                              style: GoogleFonts.archivoBlack(fontSize: 12, color: Colors.black),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('SELECT CLASSIFICATION', style: GoogleFonts.spaceMono(fontSize: 11, fontWeight: FontWeight.w900, color: PosterTokens.orangeHero)),
                                const SizedBox(height: 10),
                                Wrap(
                                  spacing: 8,
                                  runSpacing: 8,
                                  children: _categories.map((cat) {
                                    final isSelected = cat == _category;
                                    return GestureDetector(
                                      onTap: () {
                                        IrisHaptics.chipSelect();
                                        setState(() => _category = cat);
                                      },
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                        decoration: BoxDecoration(
                                          color: isSelected ? PosterTokens.orangeHero : cardBg,
                                          border: Border.all(color: inkBorder, width: 2.0),
                                        ),
                                        child: Text(
                                          cat.toUpperCase(),
                                          style: GoogleFonts.spaceMono(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w900,
                                            color: isSelected ? Colors.black : heading,
                                          ),
                                        ),
                                      ),
                                    );
                                  }).toList(),
                                ),
                                const SizedBox(height: 20),

                                // Stars
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text('SCORE', style: GoogleFonts.spaceMono(fontSize: 12, fontWeight: FontWeight.w900, color: PosterTokens.orangeHero)),
                                    Row(
                                      children: List.generate(5, (index) {
                                        final starRating = index + 1;
                                        final isFilled = starRating <= _selectedRating;
                                        return GestureDetector(
                                          onTap: () {
                                            IrisHaptics.selectionClick();
                                            setState(() => _selectedRating = starRating);
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(horizontal: 4),
                                            child: Icon(
                                              isFilled ? Icons.star_rounded : Icons.star_outline_rounded,
                                              color: isFilled ? PosterTokens.orangeHero : inkBorder.withValues(alpha: 0.3),
                                              size: 30,
                                            ),
                                          ),
                                        );
                                      }),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 20),

                                // Text Area
                                Text('CRITIQUE / SUGGESTION', style: GoogleFonts.spaceMono(fontSize: 11, fontWeight: FontWeight.w900, color: PosterTokens.orangeHero)),
                                const SizedBox(height: 8),
                                Container(
                                  decoration: BoxDecoration(
                                    border: Border.all(color: inkBorder, width: 2.0),
                                  ),
                                  child: TextFormField(
                                    controller: _commentController,
                                    maxLines: 5,
                                    style: GoogleFonts.inter(fontSize: 13.5, fontWeight: FontWeight.w600, color: body),
                                    decoration: InputDecoration(
                                      hintText: 'WRITE DIRECT OBSERVATIONS...',
                                      hintStyle: GoogleFonts.spaceMono(fontSize: 11, color: inkBorder.withValues(alpha: 0.4)),
                                      border: InputBorder.none,
                                      contentPadding: const EdgeInsets.all(14),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 24),

                                // Button
                                GestureDetector(
                                  onTap: _isSubmitting ? null : _submitFeedback,
                                  child: Container(
                                    width: double.infinity,
                                    height: 52,
                                    decoration: BoxDecoration(
                                      color: PosterTokens.orangeHero,
                                      border: Border.all(color: inkBorder, width: 2.5),
                                      boxShadow: [
                                        BoxShadow(color: inkBorder, offset: const Offset(4, 4), blurRadius: 0),
                                      ],
                                    ),
                                    alignment: Alignment.center,
                                    child: Text(
                                      _isSubmitting ? 'TRANSMITTING...' : 'DISPATCH TO ARCHITECTS',
                                      style: GoogleFonts.archivoBlack(fontSize: 14, letterSpacing: 0.5, color: Colors.black),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===========================================================================
  // 4. ALMANAC THEME
  // ===========================================================================
  Widget _buildAlmanacFeedback(BuildContext context, bool effectiveIsDark) {
    final canvas = AlmanacTokens.canvas(effectiveIsDark);
    final cardBg = AlmanacTokens.cardSurface(effectiveIsDark);
    final inkRule = AlmanacTokens.inkRule(effectiveIsDark);
    final heading = AlmanacTokens.inkHeading(effectiveIsDark);
    final body = AlmanacTokens.inkBody(effectiveIsDark);
    final terracotta = AlmanacTokens.accentTerracotta(effectiveIsDark);

    return Scaffold(
      backgroundColor: canvas,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Column(
                children: [
                  Container(height: 2, color: inkRule),
                  const SizedBox(height: 2),
                  Container(height: 0.8, color: inkRule),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      GestureDetector(
                        onTap: widget.onBackPressed ?? () => Navigator.of(context).maybePop(),
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(border: Border.all(color: inkRule, width: 1), shape: BoxShape.circle),
                          child: Icon(Icons.arrow_back_rounded, color: heading, size: 18),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          children: [
                            Text('THE IRIS GAZETTE · CORRESPONDENCE', style: GoogleFonts.playfairDisplay(fontSize: 12, letterSpacing: 1.5, fontWeight: FontWeight.w900, color: terracotta)),
                            Text('Letters & Feedback', style: GoogleFonts.playfairDisplay(fontSize: 22, fontStyle: FontStyle.italic, fontWeight: FontWeight.w700, color: heading)),
                          ],
                        ),
                      ),
                      const SizedBox(width: 36),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Container(height: 0.8, color: inkRule),
                  const SizedBox(height: 2),
                  Container(height: 2, color: inkRule),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 40),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 720),
                    child: Container(
                      decoration: BoxDecoration(
                        color: cardBg,
                        border: Border.all(color: inkRule.withValues(alpha: 0.35), width: 1.5),
                      ),
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Center(
                            child: Text('CORRESPONDENT: $_userName ($_userBatch)',
                                style: GoogleFonts.playfairDisplay(fontSize: 14, fontStyle: FontStyle.italic, color: terracotta)),
                          ),
                          const SizedBox(height: 18),

                          // Categories
                          Text('SUBJECT OF INQUIRY', style: GoogleFonts.spaceMono(fontSize: 11, fontWeight: FontWeight.w700, color: terracotta)),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: _categories.map((cat) {
                              final isSelected = cat == _category;
                              return GestureDetector(
                                onTap: () {
                                  IrisHaptics.chipSelect();
                                  setState(() => _category = cat);
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                  decoration: BoxDecoration(
                                    border: Border.all(color: isSelected ? terracotta : inkRule.withValues(alpha: 0.3), width: 1.2),
                                    color: isSelected ? terracotta.withValues(alpha: 0.15) : Colors.transparent,
                                  ),
                                  child: Text(cat, style: GoogleFonts.playfairDisplay(fontSize: 13, color: isSelected ? terracotta : heading)),
                                ),
                              );
                            }).toList(),
                          ),
                          const SizedBox(height: 20),

                          // Star Rating
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('RECORD OF SATISFACTION', style: GoogleFonts.spaceMono(fontSize: 11, fontWeight: FontWeight.w700, color: terracotta)),
                              Row(
                                children: List.generate(5, (index) {
                                  final starRating = index + 1;
                                  final isFilled = starRating <= _selectedRating;
                                  return GestureDetector(
                                    onTap: () {
                                      IrisHaptics.selectionClick();
                                      setState(() => _selectedRating = starRating);
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 4),
                                      child: Icon(
                                        isFilled ? Icons.star_rounded : Icons.star_outline_rounded,
                                        color: isFilled ? terracotta : inkRule.withValues(alpha: 0.3),
                                        size: 26,
                                      ),
                                    ),
                                  );
                                }),
                              ),
                            ],
                          ),
                          const SizedBox(height: 20),

                          // Text Area
                          Text('DISPATCH CONTENT', style: GoogleFonts.spaceMono(fontSize: 11, fontWeight: FontWeight.w700, color: terracotta)),
                          const SizedBox(height: 8),
                          Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: inkRule.withValues(alpha: 0.35), width: 1.0),
                            ),
                            child: TextFormField(
                              controller: _commentController,
                              maxLines: 5,
                              style: GoogleFonts.newsreader(fontSize: 14.5, color: body),
                              decoration: InputDecoration(
                                hintText: 'Inscribe your observations for the university chronicle...',
                                hintStyle: GoogleFonts.playfairDisplay(fontSize: 13, fontStyle: FontStyle.italic, color: inkRule.withValues(alpha: 0.5)),
                                border: InputBorder.none,
                                contentPadding: const EdgeInsets.all(14),
                              ),
                            ),
                          ),
                          const SizedBox(height: 24),

                          // Submit
                          GestureDetector(
                            onTap: _isSubmitting ? null : _submitFeedback,
                            child: Container(
                              width: double.infinity,
                              height: 50,
                              decoration: BoxDecoration(
                                color: terracotta,
                                border: Border.all(color: inkRule, width: 1.5),
                              ),
                              alignment: Alignment.center,
                              child: Text(
                                _isSubmitting ? 'DISPATCHING...' : 'DISPATCH TO EDITORS',
                                style: GoogleFonts.playfairDisplay(fontSize: 15, fontWeight: FontWeight.w700, color: Colors.white),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===========================================================================
  // 5. EDITORIAL ACADEMIC THEME
  // ===========================================================================
  Widget _buildEditorialFeedback(BuildContext context, bool effectiveIsDark) {
    final canvas = EditorialTokens.canvas(effectiveIsDark);
    final cardBg = EditorialTokens.cardSurface(effectiveIsDark);
    final cardBorder = EditorialTokens.cardBorder(effectiveIsDark);
    final heading = EditorialTokens.inkHeading(effectiveIsDark);
    final body = EditorialTokens.inkBody(effectiveIsDark);
    final accent = EditorialTokens.accentUpcoming;

    return Scaffold(
      backgroundColor: canvas,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: widget.onBackPressed ?? () => Navigator.of(context).maybePop(),
                    child: Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: cardBg,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: cardBorder, width: 1.2),
                      ),
                      child: Icon(Icons.arrow_back_rounded, color: heading, size: 20),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Scholarly Feedback', style: GoogleFonts.newsreader(fontSize: 22, fontWeight: FontWeight.w800, color: heading)),
                        Text('ARCHIVUM ACADEMICUM · PETITIONS', style: GoogleFonts.spaceMono(fontSize: 10, letterSpacing: 1.0, color: accent, fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 720),
                    child: Container(
                      decoration: BoxDecoration(
                        color: cardBg,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: cardBorder, width: 1.5),
                        boxShadow: [
                          BoxShadow(color: Colors.black.withValues(alpha: effectiveIsDark ? 0.35 : 0.05), blurRadius: 18, offset: const Offset(0, 6)),
                        ],
                      ),
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('PETITIONER: $_userName ($_userBatch)',
                              style: GoogleFonts.plusJakartaSans(fontSize: 13, fontWeight: FontWeight.w600, color: accent)),
                          const SizedBox(height: 18),

                          // Categories
                          Text('DISCIPLINE & TOPIC', style: GoogleFonts.spaceMono(fontSize: 11, fontWeight: FontWeight.w700, color: accent)),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: _categories.map((cat) {
                              final isSelected = cat == _category;
                              return GestureDetector(
                                onTap: () {
                                  IrisHaptics.chipSelect();
                                  setState(() => _category = cat);
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                                  decoration: BoxDecoration(
                                    color: isSelected ? accent.withValues(alpha: 0.15) : cardBg,
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(color: isSelected ? accent : cardBorder, width: 1.2),
                                  ),
                                  child: Text(cat, style: GoogleFonts.plusJakartaSans(fontSize: 12, fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500, color: heading)),
                                ),
                              );
                            }).toList(),
                          ),
                          const SizedBox(height: 20),

                          // Rating
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('COLLEGIATE APPRAISAL', style: GoogleFonts.spaceMono(fontSize: 11, fontWeight: FontWeight.w700, color: accent)),
                              Row(
                                children: List.generate(5, (index) {
                                  final starRating = index + 1;
                                  final isFilled = starRating <= _selectedRating;
                                  return GestureDetector(
                                    onTap: () {
                                      IrisHaptics.selectionClick();
                                      setState(() => _selectedRating = starRating);
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 4),
                                      child: Icon(
                                        isFilled ? Icons.star_rounded : Icons.star_outline_rounded,
                                        color: isFilled ? accent : cardBorder,
                                        size: 26,
                                      ),
                                    ),
                                  );
                                }),
                              ),
                            ],
                          ),
                          const SizedBox(height: 20),

                          // Text Area
                          Text('ACADEMIC COMMENTARY', style: GoogleFonts.spaceMono(fontSize: 11, fontWeight: FontWeight.w700, color: accent)),
                          const SizedBox(height: 8),
                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: cardBorder, width: 1.2),
                            ),
                            child: TextFormField(
                              controller: _commentController,
                              maxLines: 5,
                              style: GoogleFonts.plusJakartaSans(fontSize: 13.5, color: body),
                              decoration: InputDecoration(
                                hintText: 'Record constructive feedback or feature proposals...',
                                hintStyle: GoogleFonts.plusJakartaSans(fontSize: 13, color: EditorialTokens.inkMuted(effectiveIsDark)),
                                border: InputBorder.none,
                                contentPadding: const EdgeInsets.all(14),
                              ),
                            ),
                          ),
                          const SizedBox(height: 24),

                          // Submit
                          GestureDetector(
                            onTap: _isSubmitting ? null : _submitFeedback,
                            child: Container(
                              width: double.infinity,
                              height: 50,
                              decoration: BoxDecoration(
                                color: accent,
                                borderRadius: BorderRadius.circular(14),
                              ),
                              alignment: Alignment.center,
                              child: Text(
                                _isSubmitting ? 'TRANSMITTING...' : 'TRANSMIT SCHOLARLY PETITION',
                                style: GoogleFonts.plusJakartaSans(fontSize: 14, fontWeight: FontWeight.w800, color: Colors.black87),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===========================================================================
  // 6. MATERIAL 3 EXPRESSIVE THEME
  // ===========================================================================
  Widget _buildMaterialYouFeedback(BuildContext context, bool effectiveIsDark) {
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  IconButton.filledTonal(
                    onPressed: widget.onBackPressed ?? () => Navigator.of(context).maybePop(),
                    icon: const Icon(Icons.arrow_back_rounded),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Feedback', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: colorScheme.onSurface)),
                        Text('Share suggestions with developers', style: TextStyle(fontSize: 12, color: colorScheme.onSurfaceVariant)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 720),
                    child: Container(
                      decoration: BoxDecoration(
                        color: colorScheme.surfaceContainer,
                        borderRadius: BorderRadius.circular(28),
                        border: Border.all(color: colorScheme.outlineVariant.withValues(alpha: 0.5)),
                      ),
                      padding: const EdgeInsets.all(22),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: colorScheme.primaryContainer,
                                child: Text(_userName.isNotEmpty ? _userName[0].toUpperCase() : 'U',
                                    style: TextStyle(fontWeight: FontWeight.bold, color: colorScheme.onPrimaryContainer)),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('$_userName ($_userRole)', style: TextStyle(fontWeight: FontWeight.w800, color: colorScheme.onSurface)),
                                    Text('$_userBatch • $_deviceSpecs', style: TextStyle(fontSize: 11, color: colorScheme.onSurfaceVariant)),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 20),

                          Text('CATEGORY', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.0, color: colorScheme.primary)),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: _categories.map((cat) {
                              final isSelected = cat == _category;
                              return FilterChip(
                                label: Text(cat),
                                selected: isSelected,
                                onSelected: (sel) {
                                  IrisHaptics.chipSelect();
                                  setState(() => _category = cat);
                                },
                              );
                            }).toList(),
                          ),
                          const SizedBox(height: 20),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('RATING', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.0, color: colorScheme.primary)),
                              Row(
                                children: List.generate(5, (index) {
                                  final starRating = index + 1;
                                  final isFilled = starRating <= _selectedRating;
                                  return IconButton(
                                    icon: Icon(isFilled ? Icons.star_rounded : Icons.star_outline_rounded,
                                        color: isFilled ? const Color(0xFFF59E0B) : colorScheme.outlineVariant),
                                    onPressed: () {
                                      IrisHaptics.selectionClick();
                                      setState(() => _selectedRating = starRating);
                                    },
                                  );
                                }),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),

                          Text('FEEDBACK', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.0, color: colorScheme.primary)),
                          const SizedBox(height: 8),
                          Container(
                            decoration: BoxDecoration(
                              color: colorScheme.surfaceContainerHigh,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: TextFormField(
                              controller: _commentController,
                              maxLines: 5,
                              style: TextStyle(fontSize: 14, color: colorScheme.onSurface),
                              decoration: InputDecoration(
                                hintText: 'Type your feedback, bug report, or feature proposal...',
                                hintStyle: TextStyle(fontSize: 13, color: colorScheme.onSurfaceVariant.withValues(alpha: 0.7)),
                                border: InputBorder.none,
                                contentPadding: const EdgeInsets.all(16),
                              ),
                            ),
                          ),
                          const SizedBox(height: 24),

                          SizedBox(
                            width: double.infinity,
                            height: 52,
                            child: FilledButton(
                              onPressed: _isSubmitting ? null : _submitFeedback,
                              child: Text(_isSubmitting ? 'TRANSMITTING...' : 'SUBMIT FEEDBACK'),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===========================================================================
  // 7. FLUID GLASS THEME (PRESERVED)
  // ===========================================================================
  Widget _buildFluidGlassFeedback(BuildContext context, bool effectiveIsDark) {
    final textColor = effectiveIsDark ? Colors.white : const Color(0xFF0F172A);
    final mutedTextColor = effectiveIsDark ? Colors.white.withValues(alpha: 0.6) : const Color(0xFF64748B);

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: irisFrostedAppBar(
        title: 'Feedback',
        isDark: effectiveIsDark,
        leading: AppBackButton(
          isDark: effectiveIsDark,
          onPressed: widget.onBackPressed,
        ),
      ),
      body: Stack(
        children: [
          ObsidianPulse(isDark: effectiveIsDark),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
              physics: const BouncingScrollPhysics(),
              child: Align(
                alignment: Alignment.topCenter,
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 720),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: IrisTokens.brandGradient,
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [
                                BoxShadow(
                                  color: IrisTokens.brand.withValues(alpha: 0.3),
                                  blurRadius: 14,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: const Icon(Icons.rate_review_rounded, color: Colors.white, size: 24),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Send Feedback',
                                  style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.w900,
                                    color: textColor,
                                    letterSpacing: 0.2,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  'Share your thoughts with the IRIS team',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: mutedTextColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),

                      GlassCard(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: 18,
                              backgroundColor: IrisTokens.brand.withValues(alpha: 0.2),
                              child: Text(
                                _userName.isNotEmpty ? _userName[0].toUpperCase() : 'U',
                                style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: IrisTokens.brand,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Flexible(
                                        child: Text(
                                          _userName,
                                          style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w800,
                                            color: textColor,
                                          ),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                        decoration: BoxDecoration(
                                          color: _userRole == 'Faculty'
                                              ? (effectiveIsDark ? Colors.purple.withValues(alpha: 0.25) : const Color(0xFFF3E8FF))
                                              : IrisTokens.brand.withValues(alpha: effectiveIsDark ? 0.2 : 0.12),
                                          borderRadius: BorderRadius.circular(6),
                                          border: Border.all(
                                            color: _userRole == 'Faculty'
                                                ? Colors.purple.withValues(alpha: 0.4)
                                                : IrisTokens.brand.withValues(alpha: 0.3),
                                            width: 0.8,
                                          ),
                                        ),
                                        child: Text(
                                          _userRole.toUpperCase(),
                                          style: TextStyle(
                                            fontSize: 8.5,
                                            fontWeight: FontWeight.w900,
                                            color: _userRole == 'Faculty'
                                                ? (effectiveIsDark ? Colors.purpleAccent : const Color(0xFF7C3AED))
                                                : IrisTokens.brand,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    '$_userBatch • $_deviceSpecs',
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w500,
                                      color: mutedTextColor,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                            Icon(
                              Icons.verified_user_rounded,
                              size: 18,
                              color: IrisTokens.brand,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),

                      Text(
                        'FEEDBACK CATEGORY',
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w900,
                          color: IrisTokens.brand,
                          letterSpacing: 0.8,
                        ),
                      ),
                      const SizedBox(height: 8),
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        physics: const BouncingScrollPhysics(),
                        child: Row(
                          children: _categories.map((cat) {
                            final isSelected = cat == _category;
                            return Padding(
                              padding: const EdgeInsets.only(right: 8),
                              child: GestureDetector(
                                onTap: () {
                                  IrisHaptics.chipSelect();
                                  setState(() => _category = cat);
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                  decoration: BoxDecoration(
                                    color: isSelected
                                        ? IrisTokens.brand.withValues(alpha: effectiveIsDark ? 0.22 : 0.14)
                                        : (effectiveIsDark ? Colors.white.withValues(alpha: 0.05) : Colors.black.withValues(alpha: 0.03)),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                      color: isSelected
                                          ? IrisTokens.brand
                                          : (effectiveIsDark ? Colors.white.withValues(alpha: 0.1) : Colors.black.withValues(alpha: 0.08)),
                                      width: isSelected ? 1.4 : 1.0,
                                    ),
                                  ),
                                  child: Text(
                                    cat,
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                                      color: isSelected
                                          ? IrisTokens.brand
                                          : (effectiveIsDark ? Colors.white70 : const Color(0xFF475569)),
                                    ),
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                      const SizedBox(height: 20),

                      GlassCard(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        child: Column(
                          children: [
                            Text(
                              'RATE YOUR EXPERIENCE',
                              style: TextStyle(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w900,
                                color: IrisTokens.brand,
                                letterSpacing: 0.8,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: List.generate(5, (index) {
                                final starRating = index + 1;
                                final isFilled = starRating <= _selectedRating;
                                return IconButton(
                                  iconSize: 32,
                                  padding: const EdgeInsets.symmetric(horizontal: 4),
                                  icon: Icon(
                                    isFilled ? Icons.star_rounded : Icons.star_outline_rounded,
                                    color: isFilled ? const Color(0xFFF59E0B) : (effectiveIsDark ? Colors.white24 : Colors.black26),
                                  ),
                                  onPressed: () {
                                    IrisHaptics.selectionClick();
                                    setState(() => _selectedRating = starRating);
                                  },
                                );
                              }),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),

                      Text(
                        'YOUR FEEDBACK / SUGGESTION',
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w900,
                          color: IrisTokens.brand,
                          letterSpacing: 0.8,
                        ),
                      ),
                      const SizedBox(height: 8),
                      GlassCard(
                        padding: const EdgeInsets.all(4),
                        child: TextFormField(
                          controller: _commentController,
                          maxLines: 5,
                          style: TextStyle(
                            fontSize: 14,
                            color: textColor,
                            fontWeight: FontWeight.w500,
                          ),
                          decoration: InputDecoration(
                            hintText: 'Type your feedback, bug report, or feature request here...',
                            hintStyle: TextStyle(
                              fontSize: 13,
                              color: mutedTextColor.withValues(alpha: 0.6),
                            ),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.all(14),
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),

                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: IrisLiquidButton(
                          text: _isSubmitting ? 'TRANSMITTING...' : 'TRANSMIT FEEDBACK TO ADMIN',
                          icon: _isSubmitting ? Icons.hourglass_top_rounded : Icons.send_rounded,
                          onTap: _isSubmitting ? null : _submitFeedback,
                          color: IrisTokens.brand,
                          isDark: effectiveIsDark,
                          height: 52,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

