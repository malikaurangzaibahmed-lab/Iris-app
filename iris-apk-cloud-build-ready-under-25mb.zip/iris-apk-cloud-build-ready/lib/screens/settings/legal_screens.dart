import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/animations.dart';
import '../../core/tokens.dart';
import '../../core/theme_signals.dart';
import '../../core/vital_theme.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/iris_components.dart';

class LegalSectionData {
  final String number;
  final String title;
  final String body;

  const LegalSectionData({
    required this.number,
    required this.title,
    required this.body,
  });
}

class PrivacyPolicyScreen extends StatelessWidget {
  final VoidCallback? onBackPressed;
  final bool? isDark;

  const PrivacyPolicyScreen({
    super.key,
    this.onBackPressed,
    this.isDark,
  });

  static const List<LegalSectionData> sections = [
    LegalSectionData(
      number: '1',
      title: 'DATA CONTROLLER',
      body: 'Nexsync (IRIS) operates as a localized intelligence companion. All data sync mechanisms are run locally on your device. We do not operate remote centralized database clusters for profiling, meaning your data remains solely in your custody.',
    ),
    LegalSectionData(
      number: '2',
      title: 'INFORMATION PROCESSING',
      body: 'We collect and store local preferences using secure key-value stores (SharedPreferences):\n\n'
          '• Identity telemetry: Display Name, User Role (Student/Faculty), and Academic Batch Key.\n'
          '• Hyper-Sync metadata: Class schedule details, course timings, located teacher identifiers, and room allocations.\n'
          '• User preferences: Notification toggles, timetable display filters, and theme configuration.',
    ),
    LegalSectionData(
      number: '3',
      title: 'TIMETABLE SYNCHRONIZATION',
      body: 'Timetable data is securely synchronized from our optimized edge-cached cloud storage (Supabase) to your local device. This architecture prevents excessive traffic on university portals while ensuring you have rapid access to your schedule. No personal authentication tokens are transmitted during this process.',
    ),
    LegalSectionData(
      number: '4',
      title: 'SECURITY STANDARDS',
      body: 'We apply strict device-level formatting bounds to ensure no SQL injections or memory buffer overflow leaks can trigger code execution vulnerabilities. Local cache encryption layers protect persistent session variables from unauthorized access.',
    ),
    LegalSectionData(
      number: '5',
      title: 'CONTACT & AUDIT',
      body: 'For questions regarding security audits or local storage keys, contact the development group:\nmalikaurangzaibahmed@gmail.com',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final effectiveIsDark = isDark ?? (Theme.of(context).brightness == Brightness.dark);
    return ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, style, _) {
        return _ThemedLegalScreenScaffold(
          title: 'Privacy Policy',
          subtitle: 'nexsync database & local sync protocols',
          documentBadge: 'CONFIDENTIAL // DATA CHARTER',
          icon: Icons.security_rounded,
          sections: sections,
          effectiveIsDark: effectiveIsDark,
          style: style,
          onBackPressed: onBackPressed,
        );
      },
    );
  }
}

class TermsOfServiceScreen extends StatelessWidget {
  final VoidCallback? onBackPressed;
  final bool? isDark;

  const TermsOfServiceScreen({
    super.key,
    this.onBackPressed,
    this.isDark,
  });

  static const List<LegalSectionData> sections = [
    LegalSectionData(
      number: '1',
      title: 'AGREEMENT TO TERMS',
      body: 'By initializing and running IRIS client services, you agree to comply with the rules outlined herein. This application is an unofficial companion and has no direct corporate affiliation with the University.',
    ),
    LegalSectionData(
      number: '2',
      title: 'NETWORK & INFRASTRUCTURE',
      body: 'Data synchronization leverages edge-cached cloud endpoints designed to prevent request floods on official university portals. You agree not to bypass our local caching systems or execute automated queries against our backend infrastructure.',
    ),
    LegalSectionData(
      number: '3',
      title: 'DISCLAIMER OF WARRANTIES',
      body: 'IRIS is provided "as-is". While our parsing algorithms are highly accurate, timetables are subject to sudden shifts, cancellations, or administrative changes. The authors are not liable for attendance deficits, scheduling conflicts, or class/exam missed slots due to data desynchronization.',
    ),
    LegalSectionData(
      number: '4',
      title: 'SYSTEM RESTRAINTS',
      body: 'You may not modify the compiled APK, perform reverse engineering of local haptic curves, or use the timetable database extraction tools for commercial purposes without explicit permission.',
    ),
    LegalSectionData(
      number: '5',
      title: 'PROTOCOL REVISIONS',
      body: 'We reserve the right to revise these terms to align with portal structure updates or security requirements. Continued usage of IRIS constitutes acceptance of updated disclaimers.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final effectiveIsDark = isDark ?? (Theme.of(context).brightness == Brightness.dark);
    return ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, style, _) {
        return _ThemedLegalScreenScaffold(
          title: 'Terms of Service',
          subtitle: 'legal framework & user guidelines',
          documentBadge: 'REGULATION // CODE OF USAGE',
          icon: Icons.gavel_rounded,
          sections: sections,
          effectiveIsDark: effectiveIsDark,
          style: style,
          onBackPressed: onBackPressed,
        );
      },
    );
  }
}

class _ThemedLegalScreenScaffold extends StatelessWidget {
  final String title;
  final String subtitle;
  final String documentBadge;
  final IconData icon;
  final List<LegalSectionData> sections;
  final bool effectiveIsDark;
  final IrisThemeStyle style;
  final VoidCallback? onBackPressed;

  const _ThemedLegalScreenScaffold({
    required this.title,
    required this.subtitle,
    required this.documentBadge,
    required this.icon,
    required this.sections,
    required this.effectiveIsDark,
    required this.style,
    this.onBackPressed,
  });

  @override
  Widget build(BuildContext context) {
    switch (style) {
      case IrisThemeStyle.notebook:
        return _buildNotebookScaffold(context);
      case IrisThemeStyle.line:
        return _buildLineScaffold(context);
      case IrisThemeStyle.poster:
        return _buildPosterScaffold(context);
      case IrisThemeStyle.almanac:
        return _buildAlmanacScaffold(context);
      case IrisThemeStyle.editorialAcademic:
        return _buildEditorialScaffold(context);
      case IrisThemeStyle.materialYou:
        return _buildMaterialYouScaffold(context);
      case IrisThemeStyle.fluidGlass:
        return _buildFluidGlassScaffold(context);
    }
  }

  // ===========================================================================
  // 1. NOTEBOOK / STATIONERY THEME SCAFFOLD
  // ===========================================================================
  Widget _buildNotebookScaffold(BuildContext context) {
    final canvasColor = NotebookTokens.canvas(effectiveIsDark);
    final cardBg = NotebookTokens.cardSurface(effectiveIsDark);
    final inkHeading = NotebookTokens.inkHeading(effectiveIsDark);
    final inkBody = NotebookTokens.inkBody(effectiveIsDark);
    final inkMuted = NotebookTokens.inkMuted(effectiveIsDark);
    final doodleRed = NotebookTokens.redDoodle(effectiveIsDark);

    return Scaffold(
      backgroundColor: canvasColor,
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: NotebookGraphPaperPainter(
                isDark: effectiveIsDark,
                gridSize: 22.0,
                marginX: 42.0,
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: onBackPressed ?? () => Navigator.of(context).maybePop(),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: cardBg,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: inkMuted.withValues(alpha: 0.3),
                              width: 1.5,
                            ),
                          ),
                          child: Icon(Icons.arrow_back_rounded, color: inkHeading, size: 20),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Text(
                          title,
                          style: GoogleFonts.kalam(
                            fontSize: 22,
                            fontWeight: FontWeight.w700,
                            color: inkHeading,
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: NotebookTokens.tapeYellow,
                          borderRadius: BorderRadius.circular(4),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.08),
                              blurRadius: 4,
                              offset: const Offset(0, 1),
                            ),
                          ],
                        ),
                        child: Text(
                          'OFFICIAL',
                          style: GoogleFonts.kalam(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: const Color(0xFF1A1F1C),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(44, 8, 20, 40),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 720),
                        child: Container(
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: inkMuted.withValues(alpha: 0.25),
                              width: 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: effectiveIsDark ? 0.3 : 0.06),
                                blurRadius: 14,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Stack(
                            clipBehavior: Clip.none,
                            children: [
                              Positioned(
                                top: -12,
                                right: 28,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: NotebookTokens.stickyNote(effectiveIsDark),
                                    borderRadius: BorderRadius.circular(6),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withValues(alpha: 0.12),
                                        blurRadius: 4,
                                        offset: const Offset(0, 2),
                                      ),
                                    ],
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(Icons.push_pin_rounded, size: 14, color: doodleRed),
                                      const SizedBox(width: 4),
                                      Text(
                                        'BINDING RULES',
                                        style: GoogleFonts.kalam(
                                          fontSize: 11,
                                          fontWeight: FontWeight.w700,
                                          color: const Color(0xFF1A1F1C),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(24),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Icon(icon, color: doodleRed, size: 24),
                                        const SizedBox(width: 10),
                                        Expanded(
                                          child: Text(
                                            subtitle,
                                            style: GoogleFonts.kalam(
                                              fontSize: 13,
                                              color: inkMuted,
                                              fontWeight: FontWeight.w700,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 20),
                                    for (int i = 0; i < sections.length; i++) ...[
                                      if (i > 0)
                                        Padding(
                                          padding: const EdgeInsets.symmetric(vertical: 16),
                                          child: CustomPaint(
                                            size: const Size(double.infinity, 1),
                                            painter: _DashedLinePainter(
                                              color: inkMuted.withValues(alpha: 0.3),
                                            ),
                                          ),
                                        ),
                                      Text(
                                        '§ ${sections[i].number}. ${sections[i].title}',
                                        style: GoogleFonts.kalam(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w700,
                                          color: doodleRed,
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        sections[i].body,
                                        style: GoogleFonts.plusJakartaSans(
                                          fontSize: 13,
                                          height: 1.6,
                                          color: inkBody,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ===========================================================================
  // 2. LINE / METRO TRANSIT THEME SCAFFOLD
  // ===========================================================================
  Widget _buildLineScaffold(BuildContext context) {
    final canvasColor = LineTokens.canvas(effectiveIsDark);
    final cardBg = LineTokens.cardSurface(effectiveIsDark);
    final railColor = LineTokens.railLine(effectiveIsDark);
    final headingColor = LineTokens.inkHeading(effectiveIsDark);
    final bodyColor = LineTokens.inkBody(effectiveIsDark);
    final mutedColor = LineTokens.inkMuted(effectiveIsDark);

    return Scaffold(
      backgroundColor: canvasColor,
      body: SafeArea(
        child: Column(
          children: [
            Container(height: 4, width: double.infinity, color: railColor),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: onBackPressed ?? () => Navigator.of(context).maybePop(),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: cardBg,
                        border: Border.all(color: railColor, width: 1.5),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.arrow_back_rounded, color: headingColor, size: 16),
                          const SizedBox(width: 4),
                          Text(
                            'RETURN',
                            style: GoogleFonts.spaceMono(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: headingColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title.toUpperCase(),
                          style: GoogleFonts.archivoBlack(
                            fontSize: 18,
                            letterSpacing: -0.5,
                            color: headingColor,
                          ),
                        ),
                        Text(
                          documentBadge,
                          style: GoogleFonts.spaceMono(
                            fontSize: 10,
                            letterSpacing: 1.2,
                            fontWeight: FontWeight.w700,
                            color: railColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      color: LineTokens.subwayGreen,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: LineTokens.subwayGreen.withValues(alpha: 0.6),
                          blurRadius: 6,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 1,
              color: mutedColor.withValues(alpha: 0.2),
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 40),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 740),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        for (int i = 0; i < sections.length; i++) ...[
                          Container(
                            margin: const EdgeInsets.only(bottom: 16),
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: cardBg,
                              border: Border.all(
                                color: i == 0 ? railColor : mutedColor.withValues(alpha: 0.25),
                                width: 1.5,
                              ),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Column(
                                  children: [
                                    Container(
                                      width: 26,
                                      height: 26,
                                      decoration: BoxDecoration(
                                        color: railColor,
                                        shape: BoxShape.circle,
                                      ),
                                      alignment: Alignment.center,
                                      child: Text(
                                        sections[i].number,
                                        style: GoogleFonts.spaceMono(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w900,
                                          color: Colors.black,
                                        ),
                                      ),
                                    ),
                                    if (i < sections.length - 1) ...[
                                      const SizedBox(height: 4),
                                      Container(
                                        width: 2,
                                        height: 30,
                                        color: mutedColor.withValues(alpha: 0.3),
                                      ),
                                    ],
                                  ],
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        sections[i].title,
                                        style: GoogleFonts.spaceGrotesk(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w800,
                                          letterSpacing: 0.5,
                                          color: headingColor,
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        sections[i].body,
                                        style: GoogleFonts.inter(
                                          fontSize: 13,
                                          height: 1.55,
                                          color: bodyColor,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===========================================================================
  // 3. POSTER / SWISS BRUTALISM THEME SCAFFOLD
  // ===========================================================================
  Widget _buildPosterScaffold(BuildContext context) {
    final canvasColor = PosterTokens.canvas(effectiveIsDark);
    final cardBg = PosterTokens.cardSurface(effectiveIsDark);
    final inkBorder = PosterTokens.inkBorder(effectiveIsDark);
    final headingColor = PosterTokens.inkHeading(effectiveIsDark);
    final bodyColor = PosterTokens.inkBody(effectiveIsDark);

    return Scaffold(
      backgroundColor: canvasColor,
      body: SafeArea(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: inkBorder, width: 2.5),
                ),
              ),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: onBackPressed ?? () => Navigator.of(context).maybePop(),
                    child: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: cardBg,
                        border: Border.all(color: inkBorder, width: 2.5),
                      ),
                      child: Icon(Icons.arrow_back_rounded, color: headingColor, size: 22),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title.toUpperCase(),
                          style: GoogleFonts.archivoBlack(
                            fontSize: 20,
                            letterSpacing: -1.0,
                            color: headingColor,
                          ),
                        ),
                        Text(
                          'SWISS REGULATORY MANIFESTO // V1.0',
                          style: GoogleFonts.spaceMono(
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1.0,
                            color: PosterTokens.orangeHero,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: PosterTokens.orangeHero,
                      border: Border.all(color: inkBorder, width: 2.0),
                    ),
                    child: Text(
                      '${sections.length} CLAUSES',
                      style: GoogleFonts.spaceMono(
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 40),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 740),
                    child: Container(
                      decoration: BoxDecoration(
                        color: cardBg,
                        border: Border.all(color: inkBorder, width: 2.5),
                        boxShadow: [
                          BoxShadow(
                            color: inkBorder,
                            offset: const Offset(6, 6),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                            color: PosterTokens.orangeHero,
                            child: Row(
                              children: [
                                Icon(icon, color: Colors.black, size: 22),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    subtitle.toUpperCase(),
                                    style: GoogleFonts.archivoBlack(
                                      fontSize: 12,
                                      letterSpacing: 0.5,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(24),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                for (int i = 0; i < sections.length; i++) ...[
                                  if (i > 0) ...[
                                    const SizedBox(height: 20),
                                    Divider(color: inkBorder, thickness: 2.0, height: 2),
                                    const SizedBox(height: 20),
                                  ],
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.baseline,
                                    textBaseline: TextBaseline.alphabetic,
                                    children: [
                                      Text(
                                        '0${sections[i].number} //',
                                        style: GoogleFonts.spaceMono(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w900,
                                          color: PosterTokens.orangeHero,
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Text(
                                          sections[i].title,
                                          style: GoogleFonts.archivoBlack(
                                            fontSize: 15,
                                            letterSpacing: -0.3,
                                            color: headingColor,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 10),
                                  Text(
                                    sections[i].body,
                                    style: GoogleFonts.inter(
                                      fontSize: 13,
                                      height: 1.6,
                                      fontWeight: FontWeight.w600,
                                      color: bodyColor,
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===========================================================================
  // 4. ALMANAC / HISTORIC BROADSHEET THEME SCAFFOLD
  // ===========================================================================
  Widget _buildAlmanacScaffold(BuildContext context) {
    final canvasColor = AlmanacTokens.canvas(effectiveIsDark);
    final cardBg = AlmanacTokens.cardSurface(effectiveIsDark);
    final inkRule = AlmanacTokens.inkRule(effectiveIsDark);
    final headingColor = AlmanacTokens.inkHeading(effectiveIsDark);
    final bodyColor = AlmanacTokens.inkBody(effectiveIsDark);
    final terracotta = AlmanacTokens.accentTerracotta(effectiveIsDark);

    return Scaffold(
      backgroundColor: canvasColor,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Column(
                children: [
                  Container(height: 2, color: inkRule),
                  const SizedBox(height: 2),
                  Container(height: 0.8, color: inkRule),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      GestureDetector(
                        onTap: onBackPressed ?? () => Navigator.of(context).maybePop(),
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            border: Border.all(color: inkRule, width: 1),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(Icons.arrow_back_rounded, color: headingColor, size: 18),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              'THE IRIS GAZETTE · LEGAL SUPPLEMENT',
                              style: GoogleFonts.playfairDisplay(
                                fontSize: 13,
                                letterSpacing: 2.0,
                                fontWeight: FontWeight.w900,
                                color: terracotta,
                              ),
                            ),
                            Text(
                              title,
                              style: GoogleFonts.playfairDisplay(
                                fontSize: 24,
                                fontStyle: FontStyle.italic,
                                fontWeight: FontWeight.w700,
                                color: headingColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 36),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Container(height: 0.8, color: inkRule),
                  const SizedBox(height: 2),
                  Container(height: 2, color: inkRule),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 40),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 720),
                    child: Container(
                      decoration: BoxDecoration(
                        color: cardBg,
                        border: Border.all(color: inkRule.withValues(alpha: 0.35), width: 1.5),
                      ),
                      padding: const EdgeInsets.all(26),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Center(
                            child: Text(
                              'ORDINANCES & REGULATORY STATUTES',
                              style: GoogleFonts.spaceMono(
                                fontSize: 11,
                                letterSpacing: 1.5,
                                fontWeight: FontWeight.w700,
                                color: terracotta,
                              ),
                            ),
                          ),
                          const SizedBox(height: 18),
                          for (int i = 0; i < sections.length; i++) ...[
                            if (i > 0) ...[
                              const SizedBox(height: 20),
                              Center(
                                child: Text(
                                  '•  •  •',
                                  style: TextStyle(
                                    color: inkRule.withValues(alpha: 0.4),
                                    letterSpacing: 6,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 20),
                            ],
                            Text(
                              'SECTION ${_toRoman(i + 1)}. ${sections[i].title}',
                              style: GoogleFonts.playfairDisplay(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                fontStyle: FontStyle.italic,
                                color: terracotta,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              sections[i].body,
                              style: GoogleFonts.newsreader(
                                fontSize: 14.5,
                                height: 1.65,
                                color: bodyColor,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===========================================================================
  // 5. EDITORIAL ACADEMIC THEME SCAFFOLD
  // ===========================================================================
  Widget _buildEditorialScaffold(BuildContext context) {
    final canvasColor = EditorialTokens.canvas(effectiveIsDark);
    final cardBg = EditorialTokens.cardSurface(effectiveIsDark);
    final cardBorder = EditorialTokens.cardBorder(effectiveIsDark);
    final headingColor = EditorialTokens.inkHeading(effectiveIsDark);
    final bodyColor = EditorialTokens.inkBody(effectiveIsDark);
    final accent = EditorialTokens.accentUpcoming;

    return Scaffold(
      backgroundColor: canvasColor,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: onBackPressed ?? () => Navigator.of(context).maybePop(),
                    child: Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: cardBg,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: cardBorder, width: 1.2),
                      ),
                      child: Icon(Icons.arrow_back_rounded, color: headingColor, size: 20),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: GoogleFonts.newsreader(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: headingColor,
                          ),
                        ),
                        Text(
                          'ARCHIVUM ACADEMICUM · REGULATORY CHARTER',
                          style: GoogleFonts.spaceMono(
                            fontSize: 10,
                            letterSpacing: 1.0,
                            fontWeight: FontWeight.w700,
                            color: accent,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 720),
                    child: Container(
                      decoration: BoxDecoration(
                        color: cardBg,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: cardBorder, width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: effectiveIsDark ? 0.35 : 0.05),
                            blurRadius: 18,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      padding: const EdgeInsets.all(26),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: accent.withValues(alpha: 0.15),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Icon(icon, color: accent, size: 22),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Text(
                                  subtitle,
                                  style: GoogleFonts.plusJakartaSans(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                    color: EditorialTokens.inkMuted(effectiveIsDark),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 24),
                          for (int i = 0; i < sections.length; i++) ...[
                            if (i > 0)
                              Padding(
                                padding: const EdgeInsets.symmetric(vertical: 18),
                                child: Divider(
                                  color: cardBorder,
                                  height: 1,
                                ),
                              ),
                            Text(
                              '§ ${sections[i].number}. ${sections[i].title}',
                              style: GoogleFonts.newsreader(
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                color: accent,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              sections[i].body,
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 13.5,
                                height: 1.6,
                                color: bodyColor,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===========================================================================
  // 6. MATERIAL 3 EXPRESSIVE THEME SCAFFOLD
  // ===========================================================================
  Widget _buildMaterialYouScaffold(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  IconButton.filledTonal(
                    onPressed: onBackPressed ?? () => Navigator.of(context).maybePop(),
                    icon: const Icon(Icons.arrow_back_rounded),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -0.2,
                            color: colorScheme.onSurface,
                          ),
                        ),
                        Text(
                          subtitle,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 740),
                    child: Container(
                      decoration: BoxDecoration(
                        color: colorScheme.surfaceContainer,
                        borderRadius: BorderRadius.circular(28),
                        border: Border.all(
                          color: colorScheme.outlineVariant.withValues(alpha: 0.5),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.05),
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          for (int i = 0; i < sections.length; i++) ...[
                            if (i > 0)
                              Padding(
                                padding: const EdgeInsets.symmetric(vertical: 16),
                                child: Divider(
                                  color: colorScheme.outlineVariant.withValues(alpha: 0.4),
                                  height: 1,
                                ),
                              ),
                            Text(
                              sections[i].title,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.2,
                                color: colorScheme.primary,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              sections[i].body,
                              style: TextStyle(
                                fontSize: 13.5,
                                height: 1.6,
                                fontWeight: FontWeight.w500,
                                color: colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===========================================================================
  // 7. FLUID GLASS THEME SCAFFOLD
  // ===========================================================================
  Widget _buildFluidGlassScaffold(BuildContext context) {
    const purple = IrisTokens.purple;
    const purpleLight = IrisTokens.purpleLight;

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: irisFrostedAppBar(
        title: title,
        isDark: effectiveIsDark,
        leading: AppBackButton(
          isDark: effectiveIsDark,
          onPressed: onBackPressed,
        ),
      ),
      body: Stack(
        children: [
          ObsidianPulse(isDark: effectiveIsDark),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 40),
              physics: const BouncingScrollPhysics(),
              child: Align(
                alignment: Alignment.topCenter,
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 780),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [purple, purpleLight],
                              ),
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [
                                BoxShadow(
                                  color: purple.withValues(alpha: 0.3),
                                  blurRadius: 10,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Icon(icon, color: Colors.white, size: 24),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  title,
                                  style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.w900,
                                    color: effectiveIsDark ? Colors.white : const Color(0xFF0F172A),
                                    letterSpacing: 0.2,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  subtitle,
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: effectiveIsDark
                                        ? Colors.white.withValues(alpha: 0.55)
                                        : const Color(0xFF64748B),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),
                      GlassCard(
                        padding: const EdgeInsets.all(24),
                        borderRadius: 24,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            for (int i = 0; i < sections.length; i++) ...[
                              if (i > 0)
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 18),
                                  child: Divider(
                                    height: 1,
                                    color: (effectiveIsDark ? Colors.white : Colors.black)
                                        .withValues(alpha: 0.08),
                                  ),
                                ),
                              Padding(
                                padding: const EdgeInsets.only(bottom: 10),
                                child: Text(
                                  sections[i].title.toUpperCase(),
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.5,
                                    color: IrisTokens.brand,
                                  ),
                                ),
                              ),
                              Text(
                                sections[i].body,
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w500,
                                  height: 1.6,
                                  color: (effectiveIsDark ? Colors.white : Colors.black)
                                      .withValues(alpha: 0.65),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  static String _toRoman(int number) {
    switch (number) {
      case 1:
        return 'I';
      case 2:
        return 'II';
      case 3:
        return 'III';
      case 4:
        return 'IV';
      case 5:
        return 'V';
      default:
        return '$number';
    }
  }
}

class _DashedLinePainter extends CustomPainter {
  final Color color;

  _DashedLinePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1.0;
    const dashWidth = 5.0;
    const dashSpace = 4.0;
    double startX = 0.0;
    while (startX < size.width) {
      canvas.drawLine(Offset(startX, 0), Offset(startX + dashWidth, 0), paint);
      startX += dashWidth + dashSpace;
    }
  }

  @override
  bool shouldRepaint(covariant _DashedLinePainter oldDelegate) => oldDelegate.color != color;
}

