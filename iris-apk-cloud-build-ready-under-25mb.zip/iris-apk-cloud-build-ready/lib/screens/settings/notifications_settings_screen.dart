import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/vital_theme.dart';
import '../../core/theme_signals.dart';
import '../../core/animations.dart';
import '../../services/notification_service.dart';
import '../../services/ui_feedback.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/iris_components.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';

/// Phone-like Notifications & Alerts Settings Sub-Screen.
/// Manages Android persistent tracker service, advance lecture alarms, and disturbance rules.
class NotificationsSettingsScreen extends StatefulWidget {
  const NotificationsSettingsScreen({super.key});

  @override
  State<NotificationsSettingsScreen> createState() => _NotificationsSettingsScreenState();
}

class _NotificationsSettingsScreenState extends State<NotificationsSettingsScreen> {
  bool _persistentTracker = true;
  bool _lectureReminders = true;
  int _leadTimeMinutes = 15;
  bool _timetableDiffAlerts = true;
  bool _vacationSilencing = true;
  bool _hapticsEnabled = true;

  @override
  void initState() {
    super.initState();
    _persistentTracker = NotificationSyncService.instance.persistentTrackerEnabled.value;
    _lectureReminders = NotificationSyncService.instance.lectureRemindersEnabled.value;
    _loadNotificationPreferences();
  }

  Future<void> _loadNotificationPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        _leadTimeMinutes = prefs.getInt('lecture_alert_lead_minutes') ?? 15;
        _timetableDiffAlerts = prefs.getBool('timetable_diff_alerts_enabled') ?? true;
        _vacationSilencing = prefs.getBool('vacation_silencing_enabled') ?? true;
        _hapticsEnabled = prefs.getBool('app_haptics_enabled') ?? true;
      });
    }
  }

  Future<void> _toggleTracker(bool val) async {
    IrisHaptics.selectionClick();
    setState(() => _persistentTracker = val);
    await NotificationSyncService.instance.setPersistentTrackerEnabled(val, context: context);
  }

  Future<void> _toggleLectureReminders(bool val) async {
    IrisHaptics.selectionClick();
    setState(() => _lectureReminders = val);
    await NotificationSyncService.instance.setLectureRemindersEnabled(val);
  }

  Future<void> _setLeadTime(int mins) async {
    IrisHaptics.chipSelect();
    setState(() => _leadTimeMinutes = mins);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('lecture_alert_lead_minutes', mins);
    if (_lectureReminders) {
      await NotificationSyncService.instance.syncClassRemindersFromPrefs();
    }
  }

  Future<void> _togglePreference(String key, bool val, ValueSetter<bool> updater) async {
    IrisHaptics.selectionClick();
    updater(val);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(key, val);

    if (key == 'app_haptics_enabled') {
      await IrisHaptics.setEnabled(val);
    } else if (key == 'vacation_silencing_enabled') {
      if (_lectureReminders) {
        await NotificationSyncService.instance.syncClassRemindersFromPrefs();
      }
      if (_persistentTracker) {
        await NotificationSyncService.instance.startOrUpdateForegroundTask();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorial;
    final isNotebook = ThemeSignals.isNotebook;
    final isLine = ThemeSignals.isLine;
    final isPoster = ThemeSignals.isPoster;
    final cs = Theme.of(context).colorScheme;

    final TextStyle appBarTitleStyle;
    if (isAlmanac) {
      appBarTitleStyle = AlmanacTokens.serifHeadline(isDark, fontSize: 18, fontWeight: FontWeight.w800);
    } else if (isEditorial) {
      appBarTitleStyle = EditorialTokens.headingSerif(isDark, fontSize: 18, fontWeight: FontWeight.w900);
    } else if (isNotebook) {
      appBarTitleStyle = NotebookTokens.boldScript(isDark, fontSize: 19);
    } else if (isLine) {
      appBarTitleStyle = LineTokens.stationName(isDark).copyWith(fontSize: 17, fontWeight: FontWeight.w900);
    } else if (isPoster) {
      appBarTitleStyle = PosterTokens.classTitle(isDark).copyWith(fontSize: 17, fontWeight: FontWeight.w900);
    } else if (isM3) {
      appBarTitleStyle = TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: cs.onSurface);
    } else {
      appBarTitleStyle = TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w900,
        color: isDark ? Colors.white : const Color(0xFF0F172A),
      );
    }

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: ExpressiveInteractivePress(
          pressedScale: 0.90,
          onTap: () => Navigator.of(context).pop(),
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: isM3
                  ? cs.surfaceContainer
                  : (isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.06)),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.arrow_back_rounded,
              size: 20,
              color: isDark ? Colors.white : const Color(0xFF0F172A),
            ),
          ),
        ),
        title: Text(
          'Notifications & Alerts',
          style: appBarTitleStyle,
        ),
      ),
      body: Stack(
        children: [
          ObsidianPulse(isDark: isDark),
          SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 720),
                child: ListView(
                  physics: const ButterScrollPhysics(
                    parent: AlwaysScrollableScrollPhysics(),
                  ),
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
                  children: [
                    // 1. Android Persistent Tracker
                    _buildSectionHeader('Live Class Tracker Service'),
                    const SizedBox(height: 10),
                    GlassCard(
                      borderRadius: 22,
                      elevation: 2,
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF10B981).withValues(alpha: isDark ? 0.20 : 0.12),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: const Icon(Icons.notifications_active_rounded, color: Color(0xFF10B981), size: 22),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Status Bar Class Tracker',
                                      style: TextStyle(
                                        fontSize: 14.5,
                                        fontWeight: FontWeight.w900,
                                        color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      'Pinned Android notification showing live lecture progress, room, and countdown',
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              IrisGlassSwitch(
                                value: _persistentTracker,
                                onChanged: _toggleTracker,
                                activeColor: const Color(0xFF10B981),
                              ),
                            ],
                          ),
                          if (_persistentTracker) ...[
                            const SizedBox(height: 16),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                              decoration: BoxDecoration(
                                color: (isDark ? Colors.black26 : Colors.black.withValues(alpha: 0.04)),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: const Color(0xFF10B981).withValues(alpha: 0.25),
                                  width: 1.0,
                                ),
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 8,
                                    height: 8,
                                    decoration: const BoxDecoration(
                                      color: Color(0xFF10B981),
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Text(
                                      'Foreground service active · Updates automatically during class hours',
                                      style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w600,
                                        color: isM3 ? cs.onSurface : (isDark ? Colors.white70 : const Color(0xFF334155)),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // 2. Advance Lecture Alarms
                    _buildSectionHeader('Advance Lecture Alarms'),
                    const SizedBox(height: 10),
                    GlassCard(
                      borderRadius: 22,
                      elevation: 2,
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFF59E0B).withValues(alpha: isDark ? 0.20 : 0.12),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: const Icon(Icons.alarm_rounded, color: Color(0xFFF59E0B), size: 22),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Upcoming Lecture Reminders',
                                      style: TextStyle(
                                        fontSize: 14.5,
                                        fontWeight: FontWeight.w900,
                                        color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      'Heads-up alert before class begins to give you time to reach your hall',
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              IrisGlassSwitch(
                                value: _lectureReminders,
                                onChanged: _toggleLectureReminders,
                                activeColor: const Color(0xFFF59E0B),
                              ),
                            ],
                          ),
                          if (_lectureReminders) ...[
                            const SizedBox(height: 18),
                            Text(
                              'ALERT TIMING',
                              style: TextStyle(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.8,
                                color: isM3 ? cs.primary : (isDark ? Colors.white60 : Colors.black54),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                _buildLeadTimeChip(5, '5 min before'),
                                const SizedBox(width: 8),
                                _buildLeadTimeChip(10, '10 min before'),
                                const SizedBox(width: 8),
                                _buildLeadTimeChip(15, '15 min before'),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // 3. Smart Delivery & Disruption
                    _buildSectionHeader('Smart Delivery & Intelligence'),
                    const SizedBox(height: 10),
                    GlassCard(
                      borderRadius: 22,
                      elevation: 2,
                      padding: EdgeInsets.zero,
                      child: Column(
                        children: [
                          _buildSwitchTile(
                            title: 'Timetable Change Alerts',
                            subtitle: 'Instant heads-up when room or lecture slot shifts',
                            icon: Icons.sync_problem_rounded,
                            iconColor: VitalTokens.blue,
                            value: _timetableDiffAlerts,
                            onChanged: (v) => _togglePreference(
                              'timetable_diff_alerts_enabled',
                              v,
                              (val) => setState(() => _timetableDiffAlerts = val),
                            ),
                          ),
                          const Divider(height: 1, indent: 58),
                          _buildSwitchTile(
                            title: 'Vacation & Break Silencing',
                            subtitle: 'Automatically suppress class notifications on holidays',
                            icon: Icons.beach_access_rounded,
                            iconColor: const Color(0xFF8B5CF6),
                            value: _vacationSilencing,
                            onChanged: (v) => _togglePreference(
                              'vacation_silencing_enabled',
                              v,
                              (val) => setState(() => _vacationSilencing = val),
                            ),
                          ),
                          const Divider(height: 1, indent: 58),
                          _buildSwitchTile(
                            title: 'Tactile Haptic Responses',
                            subtitle: 'Spring vibration on selection clicks and transitions',
                            icon: Icons.vibration_rounded,
                            iconColor: Colors.teal,
                            value: _hapticsEnabled,
                            onChanged: (v) => _togglePreference(
                              'app_haptics_enabled',
                              v,
                              (val) => setState(() => _hapticsEnabled = val),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String label) {
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorial;
    final isNotebook = ThemeSignals.isNotebook;
    final isLine = ThemeSignals.isLine;
    final isPoster = ThemeSignals.isPoster;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    if (isAlmanac) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Row(
          children: [
            Text(
              '§ ${label.toUpperCase()}',
              style: AlmanacTokens.monoHeader(
                isDark,
                fontSize: 10.5,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.2,
                color: AlmanacTokens.accentTerracotta(isDark),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Container(
                height: 0.8,
                color: AlmanacTokens.inkRuleSubtle(isDark),
              ),
            ),
          ],
        ),
      );
    }

    if (isEditorial) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Row(
          children: [
            Text(
              label.toUpperCase(),
              style: EditorialTokens.monoLabel(
                isDark,
                fontSize: 10.5,
              ).copyWith(letterSpacing: 1.2, fontWeight: FontWeight.w800),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Container(
                height: 0.8,
                color: EditorialTokens.cardBorder(isDark),
              ),
            ),
          ],
        ),
      );
    }

    if (isLine) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Text(
          '[SECTION // ${label.toUpperCase()}]',
          style: LineTokens.stationMeta(isDark).copyWith(
            fontSize: 10.5,
            fontWeight: FontWeight.w800,
            color: LineTokens.railLine(isDark),
          ),
        ),
      );
    }

    if (isNotebook) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Text(
          '• $label',
          style: NotebookTokens.boldScript(
            isDark,
            fontSize: 14,
          ).copyWith(color: NotebookTokens.redDoodle(isDark)),
        ),
      );
    }

    if (isPoster) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: PosterTokens.orangeHero,
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text(
            label.toUpperCase(),
            style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w900,
              color: Colors.black,
              letterSpacing: 0.8,
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(left: 6),
      child: Text(
        label.toUpperCase(),
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.1,
          color: isM3 ? cs.primary : (isDark ? Colors.white60 : const Color(0xFF64748B)),
        ),
      ),
    );
  }

  Widget _buildLeadTimeChip(int minutes, String label) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;
    final isSelected = _leadTimeMinutes == minutes;

    return Expanded(
      child: GestureDetector(
        onTap: () => _setLeadTime(minutes),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: isSelected
                ? (isM3 ? cs.primary : const Color(0xFFF59E0B))
                : (isM3 ? cs.surfaceContainer : (isDark ? Colors.white.withValues(alpha: 0.05) : Colors.black.withValues(alpha: 0.04))),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Center(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: isSelected ? FontWeight.w900 : FontWeight.w600,
                color: isSelected ? Colors.white : (isDark ? Colors.white70 : Colors.black87),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSwitchTile({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color iconColor,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: isDark ? 0.20 : 0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: iconColor, size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w800,
                    color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 10.5,
                    color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          IrisGlassSwitch(
            value: value,
            onChanged: onChanged,
            activeColor: isM3 ? cs.primary : iconColor,
          ),
        ],
      ),
    );
  }
}
