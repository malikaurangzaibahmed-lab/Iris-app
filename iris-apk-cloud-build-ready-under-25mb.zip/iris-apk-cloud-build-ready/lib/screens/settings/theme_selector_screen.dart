import 'package:flutter/material.dart';
import '../../core/theme_signals.dart';
import '../../core/glass.dart';
import '../../core/vital_theme.dart';
import '../../core/material_you_theme.dart';
import '../../core/animations.dart';
import '../../services/ui_feedback.dart';
import 'package:iris/widgets/controls/iris_liquid_button.dart';
import '../../widgets/iris_components.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import 'package:google_fonts/google_fonts.dart';

/// Premier Ground-Redesigned Theme & Visual Engine Selector for IRIS.
///
/// Features:
/// 1. Real-time Interactive Preview Stage (Live class session card morphs between M3 and Glass).
/// 2. Dual Engine Selector with high-tactility spring physics.
/// 3. Monet Accent Palette Studio (10 curated Material 3 seed presets).
/// 4. Glass Refraction Studio (Discrete level chips & fine-tuning slider).
/// 5. Appearance Mode Segmented Pill (System / Dark / Light).
class IrisThemeSelectorScreen extends StatelessWidget {
  final VoidCallback? onCompleted;

  const IrisThemeSelectorScreen({super.key, this.onCompleted});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: irisFrostedAppBar(
        title: 'Visual Experience',
        isDark: isDark,
        leading: AppBackButton(isDark: isDark),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          ObsidianPulse(isDark: isDark),
          SafeArea(
            child: IrisThemeSelectorView(
              isEmbedded: false,
              onConfirm: () {
                IrisHaptics.actionHeavy();
                if (onCompleted != null) {
                  onCompleted!();
                } else {
                  Navigator.of(context).maybePop();
                }
              },
              confirmButtonText: 'APPLY & CONTINUE',
            ),
          ),
        ],
      ),
    );
  }
}

/// Standalone or Embeddable Theme Selector View.
class IrisThemeSelectorView extends StatefulWidget {
  final bool isEmbedded;
  final IrisThemeStyle? initialStyle;
  final Color? initialSeedColor;
  final String? initialThemeMode;
  final ValueChanged<IrisThemeStyle>? onThemeStyleChanged;
  final ValueChanged<Color>? onSeedColorChanged;
  final ValueChanged<String>? onThemeModeChanged;
  final VoidCallback? onConfirm;
  final String? confirmButtonText;
  final Widget? bottomChild;

  const IrisThemeSelectorView({
    super.key,
    this.isEmbedded = false,
    this.initialStyle,
    this.initialSeedColor,
    this.initialThemeMode,
    this.onThemeStyleChanged,
    this.onSeedColorChanged,
    this.onThemeModeChanged,
    this.onConfirm,
    this.confirmButtonText,
    this.bottomChild,
  });

  @override
  State<IrisThemeSelectorView> createState() => _IrisThemeSelectorViewState();
}

class _IrisThemeSelectorViewState extends State<IrisThemeSelectorView> {
  late IrisThemeStyle _activeStyle;
  late Color _activeSeedColor;
  late String _activeMode;

  @override
  void initState() {
    super.initState();
    _activeStyle = widget.initialStyle ?? ThemeSignals.themeStyle.value;
    _activeSeedColor = widget.initialSeedColor ?? ThemeSignals.m3eSeedColor.value;
    _activeMode = widget.initialThemeMode ?? 'system';
  }

  void _setStyle(IrisThemeStyle style) {
    if (_activeStyle == style) return;
    IrisHaptics.selectionClick();
    setState(() => _activeStyle = style);
    ThemeSignals.switchThemeWithMorph(context, style: style);
    widget.onThemeStyleChanged?.call(style);
  }

  void _setSeedColor(Color color) {
    IrisHaptics.chipSelect();
    setState(() => _activeSeedColor = color);
    ThemeSignals.setSeedColor(color);
    widget.onSeedColorChanged?.call(color);
  }

  void _setMode(String mode) {
    IrisHaptics.chipSelect();
    setState(() => _activeMode = mode);
    widget.onThemeModeChanged?.call(mode);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = _activeStyle == IrisThemeStyle.materialYou;
    final isEditorial = _activeStyle == IrisThemeStyle.editorialAcademic;
    final isGlass = _activeStyle == IrisThemeStyle.fluidGlass;
    final isAlmanac = _activeStyle == IrisThemeStyle.almanac;
    final isNotebook = _activeStyle == IrisThemeStyle.notebook;
    final isLine = _activeStyle == IrisThemeStyle.line;
    final isPoster = _activeStyle == IrisThemeStyle.poster;
    final cs = Theme.of(context).colorScheme;

    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 680),
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: EdgeInsets.symmetric(
            horizontal: widget.isEmbedded ? 0 : 20,
            vertical: 12,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 1. LIVE INTERACTIVE ENGINE PREVIEW STAGE (Standalone Theme Studio)
              if (!widget.isEmbedded) ...[
                _buildLivePreviewStage(isDark, cs),
                const SizedBox(height: 20),
              ],

              // 2. DESIGN ENGINE SHOWCASE CARDS
              _buildSectionHeader(
                title: 'DESIGN LANGUAGE',
                subtitle: 'Select the core rendering architecture',
                isDark: isDark,
                cs: cs,
              ),
              const SizedBox(height: 10),

              Row(
                children: [
                  Expanded(
                    child: _buildEngineOptionCard(
                      style: IrisThemeStyle.materialYou,
                      isSelected: isM3,
                      title: 'Material 3',
                      subtitle: 'Google Pixel',
                      badge: '120 FPS LOCKED',
                      badgeColor: const Color(0xFF0061A4),
                      icon: Icons.auto_awesome_rounded,
                      isDark: isDark,
                      cs: cs,
                      keyPoints: const ['Locked 120 FPS', 'Monet Palettes', 'Zero Blur'],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildEngineOptionCard(
                      style: IrisThemeStyle.almanac,
                      isSelected: isAlmanac,
                      title: 'Almanac',
                      subtitle: 'Classical Newsprint',
                      badge: 'BROADSIDE PRINT',
                      badgeColor: const Color(0xFFC84B31),
                      icon: Icons.newspaper_rounded,
                      isDark: isDark,
                      cs: cs,
                      keyPoints: const ['Scotch Roman', 'Double Hairlines', '3-Column Table'],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _buildEngineOptionCard(
                      style: IrisThemeStyle.editorialAcademic,
                      isSelected: isEditorial,
                      title: 'Editorial',
                      subtitle: 'Literary Study',
                      badge: 'COZY SERIF',
                      badgeColor: const Color(0xFFE5A83B),
                      icon: Icons.auto_stories_rounded,
                      isDark: isDark,
                      cs: cs,
                      keyPoints: const ['Warm Parchment', 'Fraunces Serif', 'Cozy Accents'],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildEngineOptionCard(
                      style: IrisThemeStyle.fluidGlass,
                      isSelected: isGlass,
                      title: 'Liquid Glass',
                      subtitle: 'Refractive Optics',
                      badge: 'SIGNATURE OPTICS',
                      badgeColor: const Color(0xFF8B5CF6),
                      icon: Icons.water_drop_rounded,
                      isDark: isDark,
                      cs: cs,
                      keyPoints: const ['Frosted Blur', 'Specular Rims', 'Organic Shaders'],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _buildEngineOptionCard(
                      style: IrisThemeStyle.notebook,
                      isSelected: isNotebook,
                      title: 'Notebook',
                      subtitle: 'Bullet Journal',
                      badge: 'HAND-DRAWN',
                      badgeColor: const Color(0xFFE11D48),
                      icon: Icons.edit_note_rounded,
                      isDark: isDark,
                      cs: cs,
                      keyPoints: const ['3D Spiral Rings', 'Washi Tape', 'Paper Notes'],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildEngineOptionCard(
                      style: IrisThemeStyle.line,
                      isSelected: isLine,
                      title: 'Line',
                      subtitle: 'Subway Transit',
                      badge: 'ELEVATED RAIL',
                      badgeColor: const Color(0xFFFFD500),
                      icon: Icons.subway_rounded,
                      isDark: isDark,
                      cs: cs,
                      keyPoints: const ['3D Rail Line', 'Station Nodes', 'Amber LED Signs'],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _buildEngineOptionCard(
                      style: IrisThemeStyle.poster,
                      isSelected: isPoster,
                      title: 'Poster',
                      subtitle: 'Swiss Brutalism',
                      badge: 'MONOLITHIC',
                      badgeColor: const Color(0xFFFF451A),
                      icon: Icons.view_quilt_rounded,
                      isDark: isDark,
                      cs: cs,
                      keyPoints: const ['International Orange', 'Hard 3D Shadows', 'Architectural Rules'],
                    ),
                  ),
                ],
              ),
              SizedBox(height: widget.isEmbedded ? 16 : 24),

              // 3. ENGINE CUSTOMIZATION STUDIO
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 260),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeInCubic,
                child: KeyedSubtree(
                  key: ValueKey(_activeStyle),
                  child: switch (_activeStyle) {
                    IrisThemeStyle.materialYou => _buildMonetPaletteStudio(isDark, cs),
                    IrisThemeStyle.editorialAcademic => _buildEditorialStudio(isDark, cs),
                    IrisThemeStyle.fluidGlass => _buildGlassCustomizationStudio(isDark, cs),
                    IrisThemeStyle.almanac => _buildAlmanacStudio(isDark, cs),
                    IrisThemeStyle.notebook => _buildNotebookStudio(isDark, cs),
                    IrisThemeStyle.line => _buildLineStudio(isDark, cs),
                    IrisThemeStyle.poster => _buildPosterStudio(isDark, cs),
                  },
                ),
              ),
              SizedBox(height: widget.isEmbedded ? 16 : 24),

              // 4. APPEARANCE MODE SELECTOR (System, Dark, Light)
              _buildSectionHeader(
                title: 'APPEARANCE MODE',
                subtitle: 'Automatic solar or manual contrast preference',
                isDark: isDark,
                cs: cs,
              ),
              const SizedBox(height: 10),
              _buildAppearanceModeSelector(isDark, cs, isM3),
              SizedBox(height: widget.isEmbedded ? 16 : 24),

              // 5. EMBEDDED BOTTOM CONTENT (if provided)
              if (widget.bottomChild != null) widget.bottomChild!,

              // 6. CONFIRMATION ACTION BUTTON (if applicable)
              if (widget.onConfirm != null) ...[
                SizedBox(
                  width: double.infinity,
                  child: IrisLiquidButton(
                    text: widget.confirmButtonText ?? 'APPLY & CONTINUE',
                    icon: Icons.check_circle_rounded,
                    onTap: widget.onConfirm!,
                    color: isM3 ? cs.primary : const Color(0xFF0061A4),
                    height: 50,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ],
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 1. LIVE PREVIEW STAGE
  // ---------------------------------------------------------------------------
  Widget _buildLivePreviewStage(bool isDark, ColorScheme cs) {
    final isM3 = _activeStyle == IrisThemeStyle.materialYou;
    final isEditorial = _activeStyle == IrisThemeStyle.editorialAcademic;
    final isAlmanac = _activeStyle == IrisThemeStyle.almanac;
    final isNotebook = _activeStyle == IrisThemeStyle.notebook;
    final isLine = _activeStyle == IrisThemeStyle.line;
    final isPoster = _activeStyle == IrisThemeStyle.poster;

    final previewAccent = isM3
        ? _activeSeedColor
        : (isEditorial
            ? const Color(0xFFE5A83B)
            : (isAlmanac
                ? const Color(0xFFC84B31)
                : (isNotebook
                    ? const Color(0xFFE11D48)
                    : (isLine
                        ? LineTokens.railLine(isDark)
                        : (isPoster
                            ? PosterTokens.orangeHero
                            : const Color(0xFF00F2FE))))));

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: isM3
            ? cs.surfaceContainerHigh
            : (isEditorial
                ? EditorialTokens.canvasSurface(isDark)
                : (isAlmanac
                    ? AlmanacTokens.canvas(isDark)
                    : (isNotebook
                        ? NotebookTokens.canvas(isDark)
                        : (isLine
                            ? LineTokens.canvas(isDark)
                            : (isPoster
                                ? PosterTokens.canvas(isDark)
                                : (isDark ? const Color(0xFF0D1424) : const Color(0xFFF1F5F9))))))),
        borderRadius: BorderRadius.circular(
          (isAlmanac || isPoster) ? 0 : (isLine ? 16 : (isNotebook ? 20 : 28)),
        ),
        border: Border.all(
          color: isM3
              ? cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55)
              : (isEditorial
                  ? EditorialTokens.cardBorder(isDark)
                  : (isAlmanac
                      ? AlmanacTokens.inkRule(isDark)
                      : (isNotebook
                          ? (isDark ? const Color(0xFF2F453B) : const Color(0xFFBDC7BC))
                          : (isLine
                              ? (isDark ? const Color(0xFF252D38) : const Color(0xFFD4CEBF))
                              : (isPoster
                                  ? PosterTokens.inkBorder(isDark)
                                  : previewAccent.withValues(alpha: isDark ? 0.25 : 0.20)))))),
          width: isPoster ? 2.2 : (isLine ? 1.5 : 1.2),
        ),
        boxShadow: isPoster
            ? PosterTokens.extrudedBlockShadow(isDark, offset: 4.0)
            : (isAlmanac
                ? null
                : [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.06),
                      blurRadius: 18,
                      offset: const Offset(0, 6),
                    ),
                  ]),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Live Preview Stage Tag
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 8,
            runSpacing: 6,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: previewAccent,
                      shape: (isAlmanac || isPoster) ? BoxShape.rectangle : BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: previewAccent.withValues(alpha: 0.6),
                          blurRadius: 6,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'LIVE INTERACTIVE PREVIEW',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.8,
                      color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: previewAccent.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular((isAlmanac || isPoster) ? 2 : 999),
                  border: Border.all(
                    color: previewAccent.withValues(alpha: 0.35),
                    width: 0.8,
                  ),
                ),
                child: Text(
                  isM3
                      ? '120 FPS · MONET'
                      : (isEditorial
                          ? 'COZY SERIF · PARCHMENT'
                          : (isAlmanac
                              ? 'BROADSIDE · SCOTCH ROMAN'
                              : (isNotebook
                                  ? 'BULLET JOURNAL · GRAPH PAPER'
                                  : (isLine
                                      ? 'SUBWAY TRANSIT · ELEVATED RAIL'
                                      : (isPoster
                                          ? 'SWISS BRUTALISM · MONOLITHIC'
                                          : 'FROSTED GLASS'))))),
                  style: TextStyle(
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                    color: previewAccent,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // Morphing Preview Class Card
          AnimatedContainer(
            duration: const Duration(milliseconds: 280),
            curve: Curves.fastOutSlowIn,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: isM3
                  ? cs.surfaceContainer
                  : (isEditorial
                      ? EditorialTokens.cardSurface(isDark)
                      : (isAlmanac
                          ? AlmanacTokens.cardSurface(isDark)
                          : (isNotebook
                              ? NotebookTokens.cardSurface(isDark)
                              : (isLine
                                  ? LineTokens.cardSurface(isDark)
                                  : (isPoster
                                      ? PosterTokens.cardSurface(isDark)
                                      : (isDark
                                          ? const Color(0xFF0F172A).withValues(alpha: 0.70)
                                          : Colors.white.withValues(alpha: 0.85))))))),
              borderRadius: BorderRadius.circular(
                (isAlmanac || isPoster) ? 0 : (isLine ? 14 : (isNotebook ? 16 : (isEditorial ? 20 : 22))),
              ),
              border: Border.all(
                color: isM3
                    ? cs.primary.withValues(alpha: isDark ? 0.35 : 0.45)
                    : (isEditorial
                        ? EditorialTokens.cardBorder(isDark)
                        : (isAlmanac
                            ? AlmanacTokens.inkRuleSubtle(isDark)
                            : (isNotebook
                                ? (isDark ? const Color(0xFF3B5649) : const Color(0xFFC5D1C5))
                                : (isLine
                                    ? LineTokens.railLine(isDark)
                                    : (isPoster
                                        ? PosterTokens.inkBorder(isDark)
                                        : previewAccent.withValues(alpha: isDark ? 0.40 : 0.30)))))),
                width: isPoster ? 2.2 : (isLine ? 2.0 : (isAlmanac ? 1.0 : 1.5)),
              ),
              boxShadow: isPoster
                  ? PosterTokens.extrudedBlockShadow(isDark, offset: 4.0)
                  : (isAlmanac
                      ? null
                      : (isEditorial
                          ? EditorialTokens.cardShadow(isDark)
                          : (isLine
                              ? [
                                  BoxShadow(
                                    color: LineTokens.railLine(isDark).withValues(alpha: 0.18),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  ),
                                ]
                              : (isNotebook
                                  ? [
                                      BoxShadow(
                                        color: Colors.black.withValues(alpha: isDark ? 0.30 : 0.08),
                                        blurRadius: 12,
                                        offset: const Offset(0, 4),
                                      ),
                                    ]
                                  : [
                                      BoxShadow(
                                        color: (isM3 ? cs.primary : previewAccent).withValues(
                                          alpha: isDark ? 0.16 : 0.10,
                                        ),
                                        blurRadius: 14,
                                        offset: const Offset(0, 4),
                                      ),
                                    ])))),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Automata & Formal Languages',
                            style: isEditorial
                                ? EditorialTokens.headingSerif(
                                    isDark,
                                    fontSize: 16,
                                    letterSpacing: -0.2,
                                  )
                                : (isAlmanac
                                    ? AlmanacTokens.serifHeadline(
                                        isDark,
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      )
                                    : (isNotebook
                                        ? NotebookTokens.boldScript(
                                            isDark,
                                            fontSize: 17,
                                          )
                                        : (isLine
                                            ? LineTokens.stationName(isDark).copyWith(fontSize: 16)
                                            : (isPoster
                                                ? PosterTokens.classTitle(isDark).copyWith(fontSize: 16)
                                                : TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w900,
                                                    height: 1.2,
                                                    color: isM3 ? cs.onSurface : (isDark ? Colors.white : Colors.black87),
                                                  ))))),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            'Dr. Tauseef Rana · CS-201',
                            style: isEditorial
                                ? EditorialTokens.handwrittenScript(
                                    isDark,
                                    fontSize: 13,
                                  )
                                : (isAlmanac
                                    ? AlmanacTokens.monoMeta(
                                        isDark,
                                        fontSize: 11.5,
                                      )
                                    : (isNotebook
                                        ? NotebookTokens.handwrittenBody(
                                            isDark,
                                            fontSize: 12.5,
                                            color: NotebookTokens.inkMuted(isDark),
                                          )
                                        : (isLine
                                            ? LineTokens.stationMeta(isDark).copyWith(fontSize: 12)
                                            : (isPoster
                                                ? GoogleFonts.spaceMono(
                                                    fontSize: 11.5,
                                                    fontWeight: FontWeight.w700,
                                                    color: PosterTokens.inkMuted(isDark),
                                                  )
                                                : TextStyle(
                                                    fontSize: 11.5,
                                                    fontWeight: FontWeight.w600,
                                                    color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white54 : Colors.black54),
                                                  ))))),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: (isPoster
                                ? PosterTokens.orangeHero
                                : (isAlmanac
                                    ? AlmanacTokens.accentTerracotta(isDark)
                                    : (isLine
                                        ? LineTokens.subwayYellow
                                        : (isNotebook
                                            ? const Color(0xFFE11D48)
                                            : const Color(0xFF10B981)))))
                            .withValues(alpha: (isPoster || isLine) ? 1.0 : 0.16),
                        borderRadius: BorderRadius.circular((isAlmanac || isPoster) ? 0 : 999),
                        border: Border.all(
                          color: (isPoster
                              ? PosterTokens.inkBorder(isDark)
                              : (isAlmanac
                                  ? AlmanacTokens.accentTerracotta(isDark)
                                  : (isLine
                                      ? LineTokens.subwayYellow
                                      : (isNotebook ? const Color(0xFFE11D48) : const Color(0xFF10B981)))))
                              .withValues(alpha: (isPoster || isLine) ? 1.0 : 0.4),
                          width: isPoster ? 1.5 : 1.0,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.circle,
                            size: 7,
                            color: (isPoster || isLine)
                                ? Colors.black
                                : (isAlmanac
                                    ? AlmanacTokens.accentTerracotta(isDark)
                                    : (isNotebook ? const Color(0xFFE11D48) : const Color(0xFF10B981))),
                          ),
                          const SizedBox(width: 5),
                          Text(
                            'LIVE',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w900,
                              color: (isPoster || isLine)
                                  ? Colors.black
                                  : (isAlmanac
                                      ? AlmanacTokens.accentTerracotta(isDark)
                                      : (isNotebook ? const Color(0xFFE11D48) : const Color(0xFF10B981))),
                              letterSpacing: 0.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                // Location & Time Capsule Row
                Wrap(
                  spacing: 8,
                  runSpacing: 6,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                      decoration: BoxDecoration(
                        color: isM3
                            ? cs.surfaceContainerHighest
                            : (isEditorial
                                ? EditorialTokens.chipSurface(isDark)
                                : (isAlmanac
                                    ? AlmanacTokens.cardSurface(isDark)
                                    : (isNotebook
                                        ? NotebookTokens.canvas(isDark)
                                        : (isLine
                                            ? LineTokens.canvas(isDark)
                                            : (isPoster
                                                ? PosterTokens.canvas(isDark)
                                                : (isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.05))))))),
                        borderRadius: BorderRadius.circular((isAlmanac || isPoster) ? 0 : (isNotebook ? 8 : (isLine ? 8 : 999))),
                        border: (isAlmanac || isPoster || isNotebook || isLine)
                            ? Border.all(
                                color: isPoster
                                    ? PosterTokens.inkBorder(isDark)
                                    : (isAlmanac
                                        ? AlmanacTokens.inkRuleSubtle(isDark)
                                        : (isLine
                                            ? LineTokens.railLine(isDark).withValues(alpha: 0.4)
                                            : (isDark ? const Color(0xFF2F453B) : const Color(0xFFBDC7BC)))),
                                width: isPoster ? 1.2 : 0.8,
                              )
                            : null,
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.schedule_rounded,
                            size: 13,
                            color: isM3 ? cs.primary : previewAccent,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            '11:00 AM - 12:30 PM',
                            style: isEditorial
                                ? EditorialTokens.bodySans(
                                    isDark,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                  )
                                : (isAlmanac
                                    ? AlmanacTokens.monoMeta(
                                        isDark,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w700,
                                      )
                                    : (isNotebook
                                        ? NotebookTokens.handwrittenBody(
                                            isDark,
                                            fontSize: 11,
                                            fontWeight: FontWeight.w700,
                                          )
                                        : (isLine
                                            ? GoogleFonts.spaceMono(
                                                fontSize: 10.5,
                                                fontWeight: FontWeight.w700,
                                                color: LineTokens.inkHeading(isDark),
                                              )
                                            : (isPoster
                                                ? GoogleFonts.spaceMono(
                                                    fontSize: 10.5,
                                                    fontWeight: FontWeight.w700,
                                                    color: PosterTokens.inkHeading(isDark),
                                                  )
                                                : TextStyle(
                                                    fontSize: 11,
                                                    fontWeight: FontWeight.w700,
                                                    color: isM3 ? cs.onSurface : (isDark ? Colors.white70 : Colors.black87),
                                                  ))))),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                      decoration: BoxDecoration(
                        color: isM3
                            ? cs.surfaceContainerHighest
                            : (isEditorial
                                ? EditorialTokens.chipSurface(isDark)
                                : (isAlmanac
                                    ? AlmanacTokens.cardSurface(isDark)
                                    : (isNotebook
                                        ? NotebookTokens.canvas(isDark)
                                        : (isLine
                                            ? LineTokens.canvas(isDark)
                                            : (isPoster
                                                ? PosterTokens.canvas(isDark)
                                                : (isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.05))))))),
                        borderRadius: BorderRadius.circular((isAlmanac || isPoster) ? 0 : (isNotebook ? 8 : (isLine ? 8 : 999))),
                        border: (isAlmanac || isPoster || isNotebook || isLine)
                            ? Border.all(
                                color: isPoster
                                    ? PosterTokens.inkBorder(isDark)
                                    : (isAlmanac
                                        ? AlmanacTokens.inkRuleSubtle(isDark)
                                        : (isLine
                                            ? LineTokens.railLine(isDark).withValues(alpha: 0.4)
                                            : (isDark ? const Color(0xFF2F453B) : const Color(0xFFBDC7BC)))),
                                width: isPoster ? 1.2 : 0.8,
                              )
                            : null,
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.location_on_rounded,
                            size: 13,
                            color: isM3 ? cs.primary : previewAccent,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Room 4-12',
                            style: isEditorial
                                ? EditorialTokens.bodySans(
                                    isDark,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w800,
                                  )
                                : (isAlmanac
                                    ? AlmanacTokens.monoMeta(
                                        isDark,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w800,
                                      )
                                    : (isNotebook
                                        ? NotebookTokens.handwrittenBody(
                                            isDark,
                                            fontSize: 11,
                                            fontWeight: FontWeight.w800,
                                          )
                                        : (isLine
                                            ? GoogleFonts.archivoBlack(
                                                fontSize: 11,
                                                color: LineTokens.inkHeading(isDark),
                                              )
                                            : (isPoster
                                                ? GoogleFonts.archivoBlack(
                                                    fontSize: 11,
                                                    color: PosterTokens.inkHeading(isDark),
                                                  )
                                                : TextStyle(
                                                    fontSize: 11,
                                                    fontWeight: FontWeight.w800,
                                                    color: isM3 ? cs.onSurface : (isDark ? Colors.white70 : Colors.black87),
                                                  ))))),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // Progress Capsule
                ClipRRect(
                  borderRadius: BorderRadius.circular((isAlmanac || isPoster) ? 0 : 99),
                  child: Container(
                    height: (isAlmanac || isPoster) ? 3 : 5,
                    width: double.infinity,
                    color: (isDark ? Colors.white : Colors.black).withValues(alpha: (isAlmanac || isPoster) ? 0.15 : 0.08),
                    child: FractionallySizedBox(
                      alignment: Alignment.centerLeft,
                      widthFactor: 0.65,
                      child: Container(
                        decoration: BoxDecoration(
                          color: isM3 ? cs.primary : previewAccent,
                          borderRadius: BorderRadius.circular((isAlmanac || isPoster) ? 0 : 99),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 2. ENGINE SELECTION CARDS
  // ---------------------------------------------------------------------------
  Widget _buildEngineOptionCard({
    required IrisThemeStyle style,
    required bool isSelected,
    required String title,
    required String subtitle,
    required String badge,
    required Color badgeColor,
    required IconData icon,
    required bool isDark,
    required ColorScheme cs,
    required List<String> keyPoints,
  }) {
    final isM3 = style == IrisThemeStyle.materialYou;

    return ExpressiveInteractivePress(
      onTap: () => _setStyle(style),
      pressedScale: 0.96,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 240),
        curve: Curves.fastOutSlowIn,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected
              ? (isDark
                  ? (isM3 ? cs.surfaceContainerHigh : const Color(0xFF141C2E))
                  : (isM3 ? cs.surfaceContainerLow : Colors.white))
              : (isDark ? const Color(0xFF0B101C) : const Color(0xFFF1F5F9)),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: isSelected
                ? (isM3 ? cs.primary : badgeColor)
                : (isDark ? Colors.white.withValues(alpha: 0.10) : Colors.black.withValues(alpha: 0.08)),
            width: isSelected ? 2.0 : 1.0,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: (isM3 ? cs.primary : badgeColor).withValues(
                      alpha: isDark ? 0.28 : 0.16,
                    ),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ]
              : null,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top Row: Icon + Selection Checkmark Circle
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: isSelected
                        ? (isM3 ? cs.primary : badgeColor)
                        : (isDark ? Colors.white12 : Colors.black12),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: isSelected
                        ? [
                            BoxShadow(
                              color: (isM3 ? cs.primary : badgeColor).withValues(alpha: 0.35),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ]
                        : null,
                  ),
                  child: Icon(
                    icon,
                    size: 20,
                    color: isSelected
                        ? (isM3 ? cs.onPrimary : Colors.white)
                        : (isDark ? Colors.white70 : Colors.black54),
                  ),
                ),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isSelected
                        ? (isM3 ? cs.primary : badgeColor)
                        : Colors.transparent,
                    border: Border.all(
                      color: isSelected
                          ? (isM3 ? cs.primary : badgeColor)
                          : (isDark ? Colors.white30 : Colors.black26),
                      width: 2.0,
                    ),
                  ),
                  child: isSelected
                      ? Icon(
                          Icons.check_rounded,
                          size: 14,
                          color: isM3 ? cs.onPrimary : Colors.white,
                        )
                      : null,
                ),
              ],
            ),
            const SizedBox(height: 14),

            // Badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2.5),
              decoration: BoxDecoration(
                color: (isSelected ? (isM3 ? cs.primary : badgeColor) : badgeColor).withValues(alpha: 0.14),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                badge,
                style: TextStyle(
                  fontSize: 8.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.6,
                  color: isSelected ? (isM3 ? cs.primary : badgeColor) : badgeColor,
                ),
              ),
            ),
            const SizedBox(height: 6),

            // Title & Subtitle
            Text(
              title,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w900,
                color: isDark ? Colors.white : Colors.black87,
                letterSpacing: -0.2,
              ),
            ),
            Text(
              subtitle,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w500,
                color: isDark ? Colors.white54 : Colors.black54,
              ),
            ),
            const SizedBox(height: 12),

            // Key Points
            ...keyPoints.map((pt) => Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Row(
                children: [
                  Icon(
                    Icons.check_circle_outline_rounded,
                    size: 11,
                    color: isSelected
                        ? (isM3 ? cs.primary : badgeColor)
                        : (isDark ? Colors.white38 : Colors.black38),
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    child: Text(
                      pt,
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: isDark ? Colors.white70 : Colors.black87,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            )),
          ],
        ),
      ),
    );
  }


  // ---------------------------------------------------------------------------
  // 3A. EDITORIAL ACADEMIC STUDIO
  // ---------------------------------------------------------------------------
  Widget _buildEditorialStudio(bool isDark, ColorScheme cs) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: EditorialTokens.cardSurface(isDark),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: EditorialTokens.cardBorder(isDark),
          width: 1.0,
        ),
        boxShadow: EditorialTokens.cardShadow(isDark),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'EDITORIAL PALETTE & TYPOGRAPHY',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.8,
                        color: EditorialTokens.inkHeading(isDark),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Warm biscuit parchment with Fraunces & Caveat script',
                      style: TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w500,
                        color: EditorialTokens.inkMuted(isDark),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: const Color(0xFFE5A83B).withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  'Cozy Study',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFFE5A83B),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              _buildEditorialColorSwatch('Live', EditorialTokens.accentLive, 'Emerald'),
              const SizedBox(width: 8),
              _buildEditorialColorSwatch('Lab', EditorialTokens.accentLab, 'Terracotta'),
              const SizedBox(width: 8),
              _buildEditorialColorSwatch('Upcoming', EditorialTokens.accentUpcoming, 'Amber'),
              const SizedBox(width: 8),
              _buildEditorialColorSwatch('Notice', EditorialTokens.accentNotice, 'Indigo'),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF141926) : const Color(0xFFF3EFE6),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: EditorialTokens.cardBorder(isDark),
                width: 0.8,
              ),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.format_quote_rounded,
                  size: 20,
                  color: const Color(0xFFE5A83B).withValues(alpha: 0.8),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '"The beautiful thing about learning is nobody can take it away."',
                    style: EditorialTokens.headingSerif(
                      isDark,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 3D. ALMANAC BROADSIDE STUDIO
  // ---------------------------------------------------------------------------
  Widget _buildAlmanacStudio(bool isDark, ColorScheme cs) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AlmanacTokens.cardSurface(isDark),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: AlmanacTokens.inkRule(isDark),
          width: 1.0,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.05),
            blurRadius: 14,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'ALMANAC BROADSIDE PRINT',
                      style: AlmanacTokens.monoHeader(
                        isDark,
                        fontSize: 11,
                        letterSpacing: 0.8,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Classical newspaper with Scotch Roman & Space Mono',
                      style: TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w500,
                        color: AlmanacTokens.inkMuted(isDark),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AlmanacTokens.accentTerracotta(isDark).withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  'Vol. 1',
                  style: AlmanacTokens.monoMeta(
                    isDark,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    color: AlmanacTokens.accentTerracotta(isDark),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              _buildEditorialColorSwatch(
                'Terracotta',
                AlmanacTokens.accentTerracotta(isDark),
                'Terracotta',
              ),
              const SizedBox(width: 8),
              _buildEditorialColorSwatch(
                'Newsprint',
                AlmanacTokens.canvas(isDark),
                isDark ? 'Obsidian' : 'Ivory',
              ),
              const SizedBox(width: 8),
              _buildEditorialColorSwatch(
                'Ink Rule',
                AlmanacTokens.inkRule(isDark),
                'Hairline',
              ),
              const SizedBox(width: 8),
              _buildEditorialColorSwatch(
                'Ink Muted',
                AlmanacTokens.inkMuted(isDark),
                'Subhead',
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF181818) : const Color(0xFFF7F5F0),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: AlmanacTokens.inkRuleSubtle(isDark),
                width: 0.8,
              ),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.newspaper_rounded,
                  size: 20,
                  color: AlmanacTokens.accentTerracotta(isDark),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    '"Broadside journalism meets high-velocity academic scheduling."',
                    style: AlmanacTokens.serifHeadline(
                      isDark,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 3E. NOTEBOOK STATIONERY STUDIO
  // ---------------------------------------------------------------------------
  Widget _buildNotebookStudio(bool isDark, ColorScheme cs) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: NotebookTokens.cardSurface(isDark),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: isDark ? const Color(0xFF2F453B) : const Color(0xFFBDC7BC),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.06),
            blurRadius: 14,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'NOTEBOOK STATIONERY STUDIO',
                      style: NotebookTokens.boldScript(
                        isDark,
                        fontSize: 12,
                      ).copyWith(letterSpacing: 0.5),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Hand-drawn bullet journal styling, washi tapes & grid paper',
                      style: TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w500,
                        color: NotebookTokens.inkMuted(isDark),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: NotebookTokens.stickyYellowLight,
                  borderRadius: BorderRadius.circular(6),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.12),
                      blurRadius: 4,
                      offset: const Offset(0, 1),
                    ),
                  ],
                ),
                child: Text(
                  'Kalam & Caveat',
                  style: GoogleFonts.kalam(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: Colors.black87,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              _buildEditorialColorSwatch(
                'Sticky Note',
                NotebookTokens.stickyYellowLight,
                'Yellow Pad',
              ),
              const SizedBox(width: 8),
              _buildEditorialColorSwatch(
                'Doodle Red',
                NotebookTokens.redDoodle(isDark),
                'Doodle Red',
              ),
              const SizedBox(width: 8),
              _buildEditorialColorSwatch(
                'Highlighter',
                NotebookTokens.highlighterPink,
                'Pink Neon',
              ),
              const SizedBox(width: 8),
              _buildEditorialColorSwatch(
                'Washi Mint',
                NotebookTokens.tapeMint,
                'Mint Tape',
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: NotebookTokens.canvas(isDark),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: isDark ? const Color(0xFF2F453B) : const Color(0xFFBDC7BC),
                width: 0.8,
              ),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.edit_note_rounded,
                  size: 20,
                  color: NotebookTokens.redDoodle(isDark),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    '"Turn chaotic semesters into calm, tactile handwritten clarity."',
                    style: NotebookTokens.boldScript(
                      isDark,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 3F. LINE TRANSIT STUDIO
  // ---------------------------------------------------------------------------
  Widget _buildLineStudio(bool isDark, ColorScheme cs) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: LineTokens.cardSurface(isDark),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: LineTokens.railLine(isDark),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: LineTokens.railLine(isDark).withValues(alpha: 0.15),
            blurRadius: 14,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'SUBWAY TRANSIT STUDIO',
                      style: LineTokens.lineTag(isDark).copyWith(fontSize: 11),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Elevated rail lines, station stops & luminous amber LED signs',
                      style: TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w500,
                        color: LineTokens.inkMuted(isDark),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: LineTokens.subwayYellow,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  'Archivo Black',
                  style: GoogleFonts.archivoBlack(
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    color: LineTokens.ledBlack,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              _buildEditorialColorSwatch(
                'Subway Yellow',
                LineTokens.subwayYellow,
                'Yellow Line',
              ),
              const SizedBox(width: 8),
              _buildEditorialColorSwatch(
                'Express Red',
                LineTokens.subwayRed,
                'Express Red',
              ),
              const SizedBox(width: 8),
              _buildEditorialColorSwatch(
                'Cobalt Blue',
                LineTokens.subwayCobalt,
                'Metro Cobalt',
              ),
              const SizedBox(width: 8),
              _buildEditorialColorSwatch(
                'Sign Enclosure',
                LineTokens.ledBlack,
                'LED Enclosure',
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: LineTokens.ledBlack,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: LineTokens.subwayYellow.withValues(alpha: 0.5),
                width: 1.0,
              ),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.subway_rounded,
                  size: 20,
                  color: LineTokens.ledAmber,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'NEXT ARRIVAL: ROOM 4-12 · ON PLATFORM 02 · ON TIME',
                    style: GoogleFonts.spaceMono(
                      fontSize: 10.5,
                      fontWeight: FontWeight.w700,
                      color: LineTokens.ledAmber,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 3G. SWISS POSTER STUDIO
  // ---------------------------------------------------------------------------
  Widget _buildPosterStudio(bool isDark, ColorScheme cs) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: PosterTokens.cardSurface(isDark),
        borderRadius: BorderRadius.zero,
        border: Border.all(
          color: PosterTokens.inkBorder(isDark),
          width: 2.2,
        ),
        boxShadow: PosterTokens.extrudedBlockShadow(isDark, offset: 4.0),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'SWISS POSTER STUDIO',
                      style: GoogleFonts.spaceMono(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: PosterTokens.inkHeading(isDark),
                        letterSpacing: 0.8,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Monolithic typography, hard 3D extruded shadows & international orange',
                      style: TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w500,
                        color: PosterTokens.inkMuted(isDark),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: const BoxDecoration(
                  color: PosterTokens.orangeHero,
                  borderRadius: BorderRadius.zero,
                ),
                child: Text(
                  'Monolith',
                  style: GoogleFonts.archivoBlack(
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    color: Colors.black,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              _buildEditorialColorSwatch(
                'Intl Orange',
                PosterTokens.orangeHero,
                'Orange Hero',
              ),
              const SizedBox(width: 8),
              _buildEditorialColorSwatch(
                'Solid Ink',
                PosterTokens.inkBorder(isDark),
                '2.2dp Rule',
              ),
              const SizedBox(width: 8),
              _buildEditorialColorSwatch(
                'Canvas',
                PosterTokens.canvas(isDark),
                'Newsprint',
              ),
              const SizedBox(width: 8),
              _buildEditorialColorSwatch(
                'Block Face',
                isDark ? const Color(0xFF1F2937) : const Color(0xFFE5E7EB),
                'Monolith',
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: PosterTokens.canvas(isDark),
              borderRadius: BorderRadius.zero,
              border: Border.all(
                color: PosterTokens.inkBorder(isDark),
                width: 1.5,
              ),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.view_quilt_rounded,
                  size: 20,
                  color: PosterTokens.orangeHero,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    '"FORM FOLLOWS CLARITY. ZERO AMBIGUITY. BOLD ARCHITECTURAL IMPACT."',
                    style: GoogleFonts.archivoBlack(
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      color: PosterTokens.inkHeading(isDark),
                      letterSpacing: -0.2,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEditorialColorSwatch(String label, Color color, String name) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withValues(alpha: 0.35), width: 1.0),
        ),
        child: Column(
          children: [
            Container(
              width: 14,
              height: 14,
              decoration: BoxDecoration(
                color: color,
                shape: BoxShape.circle,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              name,
              style: TextStyle(
                fontSize: 9.5,
                fontWeight: FontWeight.w800,
                color: color,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 3. MONET PALETTE STUDIO
  // ---------------------------------------------------------------------------
  Widget _buildMonetPaletteStudio(bool isDark, ColorScheme cs) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: cs.surfaceContainerLow,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55),
          width: 1.0,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'MONET ACCENT PALETTES',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.8,
                        color: cs.onSurface,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Curated Android 15 dynamic color seeds',
                      style: TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w500,
                        color: cs.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: _activeSeedColor.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _getColorName(_activeSeedColor),
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    color: _activeSeedColor,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // Presets Grid
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: M3EPalettes.presets.map((preset) {
              final isChosen = _activeSeedColor.toARGB32() == preset.seedColor.toARGB32();
              return GestureDetector(
                onTap: () => _setSeedColor(preset.seedColor),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: preset.seedColor,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: isChosen
                          ? (isDark ? Colors.white : Colors.black87)
                          : Colors.transparent,
                      width: isChosen ? 3.0 : 0.0,
                    ),
                    boxShadow: isChosen
                        ? [
                            BoxShadow(
                              color: preset.seedColor.withValues(alpha: 0.55),
                              blurRadius: 10,
                              offset: const Offset(0, 3),
                            ),
                          ]
                        : null,
                  ),
                  child: isChosen
                      ? const Center(
                          child: Icon(
                            Icons.check_rounded,
                            size: 20,
                            color: Colors.white,
                          ),
                        )
                      : null,
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 3B. GLASS REFRACTION STUDIO
  // ---------------------------------------------------------------------------
  Widget _buildGlassCustomizationStudio(bool isDark, ColorScheme cs) {
    return ValueListenableBuilder<double>(
      valueListenable: ThemeSignals.glassTransparency,
      builder: (context, transparency, _) {
        final activeLevel = IrisGlassLevel.fromValue(transparency);

        return ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: GlassSurface(
            settings: IrisGlass.settings(
              context,
              blur: 18.0,
              thickness: 16.0,
              ambientStrength: 0.78,
            ),
            radius: 22,
            borderSide: BorderSide(
              color: const Color(0xFF8B5CF6).withValues(alpha: isDark ? 0.35 : 0.25),
              width: 1.2,
            ),
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'GLASS REFRACTION LEVEL',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.8,
                            color: isDark ? Colors.white : Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'Balance blur intensity vs battery efficiency',
                          style: TextStyle(
                            fontSize: 10.5,
                            fontWeight: FontWeight.w500,
                            color: isDark ? Colors.white54 : Colors.black54,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: const Color(0xFF8B5CF6).withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      '${(transparency * 100).toInt()}% BLUR',
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF8B5CF6),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),

              // Discrete Level Chips
              Row(
                children: [
                  Expanded(
                    child: _buildGlassLevelChip(
                      label: 'Opaque',
                      sublabel: '0% Blur · Eco',
                      selected: activeLevel == IrisGlassLevel.opaque,
                      onTap: () => ThemeSignals.setGlassLevel(IrisGlassLevel.opaque),
                      isDark: isDark,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _buildGlassLevelChip(
                      label: 'Balanced',
                      sublabel: '50% Frosted',
                      selected: activeLevel == IrisGlassLevel.medium,
                      onTap: () => ThemeSignals.setGlassLevel(IrisGlassLevel.medium),
                      isDark: isDark,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _buildGlassLevelChip(
                      label: 'Translucent',
                      sublabel: '100% Deep Glass',
                      selected: activeLevel == IrisGlassLevel.maximum,
                      onTap: () => ThemeSignals.setGlassLevel(IrisGlassLevel.maximum),
                      isDark: isDark,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // Smooth slider
              SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  activeTrackColor: const Color(0xFF8B5CF6),
                  inactiveTrackColor: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.10),
                  thumbColor: const Color(0xFF8B5CF6),
                  trackHeight: 4,
                ),
                child: Slider(
                  value: transparency,
                  min: 0.0,
                  max: 1.0,
                  onChanged: (v) => ThemeSignals.setGlassTransparency(v),
                ),
              ),
            ],
          ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildGlassLevelChip({
    required String label,
    required String sublabel,
    required bool selected,
    required VoidCallback onTap,
    required bool isDark,
  }) {
    const accent = Color(0xFF8B5CF6);

    return GestureDetector(
      onTap: () {
        IrisHaptics.selectionClick();
        onTap();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
          color: selected
              ? accent.withValues(alpha: isDark ? 0.22 : 0.12)
              : (isDark ? Colors.white.withValues(alpha: 0.05) : Colors.black.withValues(alpha: 0.04)),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected
                ? accent
                : (isDark ? Colors.white12 : Colors.black12),
            width: selected ? 1.5 : 1.0,
          ),
        ),
        child: Column(
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: selected ? FontWeight.w900 : FontWeight.w700,
                color: selected ? accent : (isDark ? Colors.white : Colors.black87),
              ),
            ),
            const SizedBox(height: 2),
            Text(
              sublabel,
              style: TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.w500,
                color: isDark ? Colors.white54 : Colors.black54,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 4. APPEARANCE MODE SELECTOR (System, Dark, Light)
  // ---------------------------------------------------------------------------
  Widget _buildAppearanceModeSelector(bool isDark, ColorScheme cs, bool isM3) {
    return Container(
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: isM3
            ? cs.surfaceContainerHigh
            : (isDark ? const Color(0xFF141C2E) : const Color(0xFFF1F5F9)),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: isM3
              ? cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55)
              : (isDark ? Colors.white12 : Colors.black12),
        ),
      ),
      child: Row(
        children: [
          _buildModePill(
            key: 'system',
            label: 'System Auto',
            icon: Icons.brightness_auto_rounded,
            active: _activeMode == 'system',
            isDark: isDark,
            cs: cs,
            isM3: isM3,
          ),
          _buildModePill(
            key: 'dark',
            label: 'Dark Mode',
            icon: Icons.dark_mode_rounded,
            active: _activeMode == 'dark',
            isDark: isDark,
            cs: cs,
            isM3: isM3,
          ),
          _buildModePill(
            key: 'light',
            label: 'Light Mode',
            icon: Icons.light_mode_rounded,
            active: _activeMode == 'light',
            isDark: isDark,
            cs: cs,
            isM3: isM3,
          ),
        ],
      ),
    );
  }

  Widget _buildModePill({
    required String key,
    required String label,
    required IconData icon,
    required bool active,
    required bool isDark,
    required ColorScheme cs,
    required bool isM3,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: () => _setMode(key),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          curve: Curves.fastOutSlowIn,
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: active
                ? (isM3
                    ? cs.surfaceContainerHighest
                    : (isDark ? const Color(0xFF243048) : Colors.white))
                : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
            boxShadow: active
                ? [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.06),
                      blurRadius: 6,
                      offset: const Offset(0, 2),
                    ),
                  ]
                : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 15,
                color: active
                    ? (isM3 ? cs.primary : const Color(0xFF0061A4))
                    : (isDark ? Colors.white54 : Colors.black54),
              ),
              const SizedBox(width: 5),
              Flexible(
                child: Text(
                  label,
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: active ? FontWeight.w900 : FontWeight.w600,
                    color: active
                        ? (isDark ? Colors.white : Colors.black87)
                        : (isDark ? Colors.white54 : Colors.black54),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader({
    required String title,
    required String subtitle,
    required bool isDark,
    required ColorScheme cs,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.0,
            color: isDark ? Colors.white70 : Colors.black87,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          subtitle,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w500,
            color: isDark ? Colors.white54 : Colors.black54,
          ),
        ),
      ],
    );
  }

  String _getColorName(Color color) {
    return M3EPalettes.presets.firstWhere(
      (p) => p.seedColor.toARGB32() == color.toARGB32(),
      orElse: () => M3EPalettes.presets.first,
    ).name;
  }
}
