import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/tokens.dart';
import '../../core/vital_theme.dart';
import '../../core/theme_signals.dart';
import '../../core/animations.dart';
import '../../core/models.dart';
import '../../core/omni_brain.dart';
import '../../core/repeater_planner_engine.dart';
import '../../services/ui_feedback.dart';
import 'package:iris/widgets/controls/glowing_input_wrapper.dart';
import '../../widgets/glass_card.dart';

/// Full-featured interactive Course Selector, Clash Detection Engine,
/// and Timetable Builder for university repeater/improvement students.
class RepeaterCoursePlannerScreen extends StatefulWidget {
  final UniversityMemory memory;
  final OmniBrain? brain;
  final String? initialBatch;
  final VoidCallback? onScheduleActivated;
  final bool isModalMode;

  const RepeaterCoursePlannerScreen({
    super.key,
    required this.memory,
    this.brain,
    this.initialBatch,
    this.onScheduleActivated,
    this.isModalMode = false,
  });

  @override
  State<RepeaterCoursePlannerScreen> createState() =>
      _RepeaterCoursePlannerScreenState();
}

class _RepeaterCoursePlannerScreenState
    extends State<RepeaterCoursePlannerScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  String _currentBaseBatch = '';
  List<ClassSession> _baseBatchSessions = [];
  List<String> _allAvailableCourses = [];

  // Courses the student wants to repeat / improve
  final List<String> _repeatCourses = [];

  // Chosen offering per repeat course (courseName -> CourseOffering)
  final Map<String, CourseOffering> _selectedOfferings = {};

  // Analyzed offerings per repeat course (courseName -> List<AnalyzedOffering>)
  final Map<String, List<AnalyzedOffering>> _analyzedOfferingsMap = {};

  // Per-course filter toggle: true = clash-free only, false = all sections
  final Map<String, bool> _clashFreeFilterMap = {};

  bool _isLoading = true;
  int _previewDayIndex = 1; // 1 = Monday ... 5 = Friday

  @override
  void initState() {
    super.initState();
    _previewDayIndex = DateTime.now().weekday.clamp(1, 5);
    _initializeData();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _initializeData() async {
    setState(() => _isLoading = true);

    // 1. Resolve student's base regular batch
    final savedBase = await RepeaterScheduleStorage.getBaseBatch();
    final prefs = await SharedPreferences.getInstance();
    final storedBatch = prefs.getString('user_batch') ?? prefs.getString('student_batch');

    String resolvedBatch = '';
    if (widget.initialBatch != null && widget.initialBatch!.trim().isNotEmpty) {
      resolvedBatch = widget.initialBatch!.trim();
    } else if (savedBase != null && savedBase.trim().isNotEmpty) {
      resolvedBatch = savedBase.trim();
    } else if (storedBatch != null && storedBatch.trim().isNotEmpty) {
      resolvedBatch = storedBatch.trim();
    } else {
      final batches = widget.memory.allBatches;
      resolvedBatch = batches.isNotEmpty ? batches.first : 'BCS-6A';
    }

    _currentBaseBatch = resolvedBatch;
    _baseBatchSessions = RepeaterPlannerEngine.getBaseBatchSessions(
      widget.memory,
      _currentBaseBatch,
    );

    // 2. Extract distinct courses across the university
    _allAvailableCourses = RepeaterPlannerEngine.extractUniqueCourses(widget.memory);

    // 3. Load previously saved repeater choices if any
    final savedCourses = await RepeaterScheduleStorage.getSelectedCourses();
    final savedOfferingsMap = await RepeaterScheduleStorage.getSelectedOfferingsMap();

    if (savedCourses.isNotEmpty) {
      _repeatCourses.addAll(savedCourses);
      for (final c in savedCourses) {
        _analyzeOfferingsFor(c);
        final analyzed = _analyzedOfferingsMap[c] ?? [];
        if (analyzed.isNotEmpty) {
          final targetBatch = savedOfferingsMap[c];
          final match = analyzed.firstWhere(
            (a) => a.offering.batch == targetBatch,
            orElse: () => analyzed.first,
          );
          _selectedOfferings[c] = match.offering;
        }
      }
    }

    if (mounted) {
      setState(() => _isLoading = false);
    }
  }

  void _analyzeOfferingsFor(String courseName) {
    final analyzed = RepeaterPlannerEngine.analyzeOfferingsForCourse(
      memory: widget.memory,
      courseName: courseName,
      baseBatch: _currentBaseBatch,
    );
    _analyzedOfferingsMap[courseName] = analyzed;
  }

  void _reanalyzeAllCourses() {
    _baseBatchSessions = RepeaterPlannerEngine.getBaseBatchSessions(
      widget.memory,
      _currentBaseBatch,
    );
    for (final c in _repeatCourses) {
      _analyzeOfferingsFor(c);
      final analyzed = _analyzedOfferingsMap[c] ?? [];
      // Keep selection if still valid, or re-pin to first clash-free
      if (analyzed.isNotEmpty) {
        final current = _selectedOfferings[c];
        final match = analyzed.firstWhere(
          (a) => a.offering.batch == current?.batch,
          orElse: () => analyzed.firstWhere((a) => a.isClashFree, orElse: () => analyzed.first),
        );
        _selectedOfferings[c] = match.offering;
      }
    }
  }

  void _onSwitchBaseBatch(String newBatch) {
    if (newBatch.trim().isEmpty || newBatch == _currentBaseBatch) return;
    IrisHaptics.actionMedium();
    setState(() {
      _currentBaseBatch = newBatch.trim();
      RepeaterPlannerEngine.clearCaches();
      _reanalyzeAllCourses();
    });
    RepeaterScheduleStorage.setBaseBatch(_currentBaseBatch);
    showIrisFrostedSnackBar(
      context,
      dedupeKey: 'switched_base_batch',
      content: Text('Switched base batch to $_currentBaseBatch'),
    );
  }

  void _addRepeatCourse(String courseName) {
    if (_repeatCourses.contains(courseName)) return;
    IrisHaptics.chipSelect();

    setState(() {
      _repeatCourses.add(courseName);
      _analyzeOfferingsFor(courseName);
      final analyzed = _analyzedOfferingsMap[courseName] ?? [];
      if (analyzed.isNotEmpty) {
        // Pre-select the first clash-free offering if available!
        final best = analyzed.firstWhere(
          (a) => a.isClashFree,
          orElse: () => analyzed.first,
        );
        _selectedOfferings[courseName] = best.offering;
      }
      _searchController.clear();
      _searchQuery = '';
    });
  }

  void _removeRepeatCourse(String courseName) {
    IrisHaptics.chipSelect();
    setState(() {
      _repeatCourses.remove(courseName);
      _selectedOfferings.remove(courseName);
      _analyzedOfferingsMap.remove(courseName);
    });
  }

  void _selectOfferingForCourse(String courseName, CourseOffering offering) {
    IrisHaptics.selectionClick();
    setState(() {
      _selectedOfferings[courseName] = offering;
    });
  }

  Future<void> _saveAndActivateSchedule() async {
    if (_repeatCourses.isEmpty) return;
    IrisHaptics.actionHeavy();

    final combinedSessions = RepeaterPlannerEngine.buildCombinedSchedule(
      memory: widget.memory,
      baseBatch: _currentBaseBatch,
      repeatCourses: _repeatCourses,
      selectedOfferings: _selectedOfferings,
    );

    await RepeaterScheduleStorage.saveRepeaterSchedule(
      baseBatch: _currentBaseBatch,
      courses: _repeatCourses,
      offerings: _selectedOfferings,
      sessions: combinedSessions,
    );

    if (widget.brain != null) {
      widget.brain!.customRepeaterSessions = combinedSessions;
      widget.brain!.repeaterActiveBatch = _currentBaseBatch;
      widget.brain!.invalidateBatchCaches(_currentBaseBatch);
      widget.brain!.clearAllCaches();
    }

    if (mounted) {
      showIrisFrostedSnackBar(
        context,
        dedupeKey: 'repeater_activated',
        content: const Text(
          '✓ Custom Repeater Timetable activated for your profile!',
        ),
      );
      widget.onScheduleActivated?.call();
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop(true);
      }
    }
  }

  Future<void> _clearCustomScheduleAndExit() async {
    IrisHaptics.actionMedium();
    await RepeaterScheduleStorage.clearRepeaterSchedule();
    if (widget.brain != null) {
      widget.brain!.customRepeaterSessions = null;
      widget.brain!.repeaterActiveBatch = null;
      widget.brain!.invalidateBatchCaches(_currentBaseBatch);
      widget.brain!.clearAllCaches();
    }
    if (mounted) {
      showIrisFrostedSnackBar(
        context,
        dedupeKey: 'repeater_cleared',
        content: const Text('Reverted to standard batch timetable.'),
      );
      widget.onScheduleActivated?.call();
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop(true);
      }
    }
  }

  void _showBatchPickerModal() {
    IrisHaptics.actionSoft();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final batches = widget.memory.allBatches;
    final searchCtrl = TextEditingController();

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: isDark ? const Color(0xFF0F172A) : Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        String filter = '';
        return StatefulBuilder(
          builder: (modalCtx, setModalState) {
            final matching = batches
                .where((b) => b.toLowerCase().contains(filter.toLowerCase()))
                .toList();

            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(modalCtx).viewInsets.bottom,
                left: 16,
                right: 16,
                top: 16,
              ),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxHeight: MediaQuery.of(modalCtx).size.height * 0.70,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey.withValues(alpha: 0.4),
                        borderRadius: BorderRadius.circular(999),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Select Your Base Batch',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        color: isDark ? Colors.white : Colors.black,
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: searchCtrl,
                      autofocus: false,
                      decoration: InputDecoration(
                        hintText: 'Search batch (e.g. BCS-6A)...',
                        prefixIcon: const Icon(Icons.search_rounded, size: 18),
                        filled: true,
                        fillColor: (isDark ? Colors.white : Colors.black)
                            .withValues(alpha: 0.05),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide.none,
                        ),
                      ),
                      onChanged: (val) => setModalState(() => filter = val),
                    ),
                    const SizedBox(height: 12),
                    Expanded(
                      child: ListView.separated(
                        itemCount: matching.length,
                        separatorBuilder: (_, _) => const Divider(height: 1),
                        itemBuilder: (_, idx) {
                          final b = matching[idx];
                          final isSelected = b == _currentBaseBatch;
                          return ListTile(
                            title: Text(
                              b,
                              style: TextStyle(
                                fontWeight: isSelected
                                    ? FontWeight.w900
                                    : FontWeight.w600,
                                color: isSelected
                                    ? IrisTokens.brand
                                    : (isDark ? Colors.white : Colors.black),
                              ),
                            ),
                            trailing: isSelected
                                ? const Icon(
                                    Icons.check_circle_rounded,
                                    color: IrisTokens.brand,
                                    size: 20,
                                  )
                                : null,
                            onTap: () {
                              Navigator.pop(ctx);
                              _onSwitchBaseBatch(b);
                            },
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: Text(
          'Repeater Course Planner',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w900,
            color: isM3
                ? cs.onSurface
                : (isDark ? Colors.white : Colors.black87),
          ),
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
        scrolledUnderElevation: 0,
        leading: IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: Icon(
            widget.isModalMode
                ? Icons.close_rounded
                : Icons.arrow_back_ios_new_rounded,
            size: 18,
          ),
        ),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert_rounded, size: 20),
            onSelected: (val) {
              if (val == 'clear') {
                _clearCustomScheduleAndExit();
              } else if (val == 'switch_batch') {
                _showBatchPickerModal();
              }
            },
            itemBuilder: (ctx) => [
              const PopupMenuItem(
                value: 'switch_batch',
                child: Row(
                  children: [
                    Icon(
                      Icons.swap_horiz_rounded,
                      size: 18,
                      color: Color(0xFF8B5CF6),
                    ),
                    SizedBox(width: 8),
                    Text('Switch Base Batch'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'clear',
                child: Row(
                  children: [
                    Icon(
                      Icons.delete_outline_rounded,
                      size: 18,
                      color: IrisTokens.error,
                    ),
                    SizedBox(width: 8),
                    Text('Clear Custom Schedule'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          ObsidianPulse(isDark: isDark),
          _isLoading
              ? const Center(
                  child: CircularProgressIndicator(color: IrisTokens.brand),
                )
              : SafeArea(
                  child: ListView(
                    physics: ScrollConfiguration.of(context).getScrollPhysics(context),
                    cacheExtent: 450.0,
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
                    children: [
                      _buildBaseBatchHeader(isDark, isM3, cs),
                      _buildSearchAndAddBar(isDark, isM3, cs),
                      const SizedBox(height: 14),
                      _buildRepeatCoursesSection(isDark, isM3, cs),
                      const SizedBox(height: 16),
                      _buildCombinedWeeklyPreview(isDark, isM3, cs),
                    ],
                  ),
                ),
        ],
      ),
      bottomNavigationBar: _repeatCourses.isNotEmpty
          ? _buildBottomActionBar(isDark, isM3, cs)
          : null,
    );
  }

  Widget _buildBaseBatchHeader(bool isDark, bool isM3, ColorScheme cs) {
    final courseCount = _baseBatchSessions
        .map((s) => RepeaterPlannerEngine.normalizeCourseName(s.subject))
        .toSet()
        .length;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GlassCard(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        borderRadius: 16,
        accentColor: const Color(0xFF8B5CF6),
        child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              color: const Color(0xFF8B5CF6).withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.school_rounded,
              size: 16,
              color: Color(0xFF8B5CF6),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text(
                      'Base Batch: ',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF8B5CF6),
                      ),
                    ),
                    Text(
                      _currentBaseBatch,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF8B5CF6),
                      ),
                    ),
                  ],
                ),
                Text(
                  '$courseCount normal course(s) scheduled · Tested for clashes',
                  style: TextStyle(
                    fontSize: 10.5,
                    color: isM3
                        ? cs.onSurfaceVariant
                        : (isDark ? Colors.white60 : Colors.black54),
                  ),
                ),
              ],
            ),
          ),
          ExpressiveInteractivePress(
            onTap: _showBatchPickerModal,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: const Color(0xFF8B5CF6).withValues(alpha: 0.20),
                borderRadius: BorderRadius.circular(999),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.swap_horiz_rounded, size: 12, color: Color(0xFF8B5CF6)),
                  SizedBox(width: 3),
                  Text(
                    'Change',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF8B5CF6),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    ),
    );
  }

  Widget _buildSearchAndAddBar(bool isDark, bool isM3, ColorScheme cs) {
    final query = _searchQuery.trim().toLowerCase();
    final matches = query.isEmpty
        ? <String>[]
        : _allAvailableCourses
            .where(
              (c) =>
                  c.toLowerCase().contains(query) &&
                  !_repeatCourses.contains(c),
            )
            .take(6)
            .toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        IrisTextField(
          controller: _searchController,
          isDark: isDark,
          hint: 'Search repeat course (e.g. Calculus, OOP, OS)...',
          prefixIcon: Icons.search_rounded,
          onChanged: (val) => setState(() => _searchQuery = val),
        ),
        if (matches.isNotEmpty) ...[
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: isM3
                  ? cs.surfaceContainerHigh
                  : (isDark
                      ? Colors.white.withValues(alpha: 0.08)
                      : Colors.black.withValues(alpha: 0.04)),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: isM3
                    ? cs.outlineVariant.withValues(alpha: isDark ? 0.3 : 0.5)
                    : (isDark ? Colors.white12 : Colors.black12),
              ),
            ),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: matches.map((c) {
                return ExpressiveInteractivePress(
                  onTap: () => _addRepeatCourse(c),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: IrisTokens.brand.withValues(
                        alpha: isDark ? 0.22 : 0.12,
                      ),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: IrisTokens.brand.withValues(alpha: 0.4),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.add_rounded,
                          size: 14,
                          color: IrisTokens.brand,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          c,
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: IrisTokens.brand,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildRepeatCoursesSection(bool isDark, bool isM3, ColorScheme cs) {
    if (_repeatCourses.isEmpty) {
      return GlassCard(
        padding: const EdgeInsets.all(16),
        borderRadius: 18,
        child: Column(
          children: [
            const Icon(
              Icons.auto_stories_rounded,
              size: 32,
              color: IrisTokens.brand,
            ),
            const SizedBox(height: 8),
            Text(
              'No repeat courses selected yet',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: isDark ? Colors.white : Colors.black87,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Search for any university course above. IRIS will show all teaching faculty, classrooms, batches, and highlight if it has any clash with your $_currentBaseBatch classes.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 11.5,
                color: isDark ? Colors.white60 : Colors.black54,
              ),
            ),
          ],
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Courses to Repeat (${_repeatCourses.length})',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w900,
                color: isM3 ? cs.onSurface : (isDark ? Colors.white : Colors.black87),
              ),
            ),
            Text(
              'Choose section per course',
              style: TextStyle(
                fontSize: 11,
                color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white54 : Colors.black54),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        ..._repeatCourses.map((c) => _buildRepeatCourseCard(c, isDark, isM3, cs)),
      ],
    );
  }

  Widget _buildRepeatCourseCard(
    String courseName,
    bool isDark,
    bool isM3,
    ColorScheme cs,
  ) {
    final analyzedList = _analyzedOfferingsMap[courseName] ?? [];
    final chosenOffering = _selectedOfferings[courseName];
    final showClashFreeOnly = _clashFreeFilterMap[courseName] ?? false;

    // Filter list if requested
    final displayedOfferings = showClashFreeOnly
        ? analyzedList.where((a) => a.isClashFree).toList()
        : analyzedList;

    final clashFreeCount = analyzedList.where((a) => a.isClashFree).length;
    final totalCount = analyzedList.length;

    // Selected offering clash status
    final chosenAnalyzed = analyzedList.firstWhere(
      (a) => a.offering.batch == chosenOffering?.batch,
      orElse: () => analyzedList.isNotEmpty
          ? analyzedList.first
          : AnalyzedOffering(
              offering: CourseOffering(
                courseName: courseName,
                batch: '',
                teacher: '',
                room: '',
                sessions: const [],
              ),
              hasClash: false,
            ),
    );

    final isSelectedClashing = chosenAnalyzed.hasClash;

    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: GlassCard(
        padding: EdgeInsets.zero,
        borderRadius: 20,
        accentColor: isSelectedClashing ? const Color(0xFFEF4444) : null,
        child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          initiallyExpanded: true,
          key: ValueKey(courseName),
          tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
          leading: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: (isSelectedClashing
                      ? const Color(0xFFEF4444)
                      : const Color(0xFF10B981))
                  .withValues(alpha: 0.16),
              shape: BoxShape.circle,
            ),
            child: Icon(
              isSelectedClashing
                  ? Icons.warning_amber_rounded
                  : Icons.check_circle_rounded,
              size: 20,
              color: isSelectedClashing
                  ? const Color(0xFFEF4444)
                  : const Color(0xFF10B981),
            ),
          ),
          title: Row(
            children: [
              Expanded(
                child: Text(
                  courseName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    color: isM3 ? cs.onSurface : (isDark ? Colors.white : Colors.black),
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(
                  Icons.close_rounded,
                  size: 16,
                  color: Colors.grey,
                ),
                onPressed: () => _removeRepeatCourse(courseName),
                constraints: const BoxConstraints(),
                padding: EdgeInsets.zero,
              ),
            ],
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 4),
              if (chosenOffering != null) ...[
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: IrisTokens.brand.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        'Enrolled: ${chosenOffering.batch}',
                        style: const TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                          color: IrisTokens.brand,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Flexible(
                      child: Text(
                        '· ${chosenOffering.teacher} (${chosenOffering.room.isEmpty ? "TBA" : chosenOffering.room})',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: isM3
                              ? cs.onSurfaceVariant
                              : (isDark ? Colors.white70 : Colors.black54),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 3),
                // Clash badge for current selection
                if (isSelectedClashing)
                  Text(
                    '⚠️ ${chosenAnalyzed.clashSummary}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 10.5,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFFEF4444),
                    ),
                  )
                else
                  const Text(
                    '✅ Conflict-Free · Fits your regular timetable',
                    style: TextStyle(
                      fontSize: 10.5,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF10B981),
                    ),
                  ),
              ] else
                const Text(
                  'No section selected yet',
                  style: TextStyle(fontSize: 11, color: Colors.grey),
                ),
            ],
          ),
          children: [
            // Filter Pills Bar (All Sections vs Clash-Free Only)
            Row(
              children: [
                Text(
                  'Offerings Across Campus:',
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w800,
                    color: isM3
                        ? cs.onSurfaceVariant
                        : (isDark ? Colors.white70 : Colors.black54),
                  ),
                ),
                const Spacer(),
                // Filter Toggle
                ExpressiveInteractivePress(
                  onTap: () {
                    IrisHaptics.selectionClick();
                    setState(() {
                      _clashFreeFilterMap[courseName] = !showClashFreeOnly;
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: showClashFreeOnly
                          ? const Color(0xFF10B981).withValues(alpha: 0.20)
                          : (isDark ? Colors.white12 : Colors.black12),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(
                        color: showClashFreeOnly
                            ? const Color(0xFF10B981)
                            : Colors.transparent,
                        width: 1.0,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          showClashFreeOnly
                              ? Icons.check_rounded
                              : Icons.filter_list_rounded,
                          size: 11,
                          color: showClashFreeOnly
                              ? const Color(0xFF10B981)
                              : (isDark ? Colors.white70 : Colors.black87),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          showClashFreeOnly
                              ? 'Clash-Free Only ($clashFreeCount)'
                              : 'All ($totalCount)',
                          style: TextStyle(
                            fontSize: 10.5,
                            fontWeight: FontWeight.w800,
                            color: showClashFreeOnly
                                ? const Color(0xFF10B981)
                                : (isDark ? Colors.white70 : Colors.black87),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),

            // Offerings cards list
            if (displayedOfferings.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  'No clash-free sections available for this course.',
                  style: TextStyle(
                    fontSize: 11,
                    color: isDark ? Colors.white54 : Colors.black45,
                  ),
                ),
              )
            else
              ...displayedOfferings.map((analyzed) {
                final off = analyzed.offering;
                final isSelected = chosenOffering?.batch == off.batch;
                final hasClash = analyzed.hasClash;

                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: ExpressiveInteractivePress(
                    onTap: () => _selectOfferingForCourse(courseName, off),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? IrisTokens.brand.withValues(
                                alpha: isDark ? 0.25 : 0.12,
                              )
                            : (hasClash
                                ? (isDark
                                    ? const Color(0xFFEF4444).withValues(alpha: 0.08)
                                    : const Color(0xFFFEF2F2))
                                : (isDark
                                    ? Colors.white.withValues(alpha: 0.04)
                                    : Colors.black.withValues(alpha: 0.02))),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: isSelected
                              ? IrisTokens.brand
                              : (hasClash
                                  ? const Color(0xFFEF4444).withValues(alpha: 0.35)
                                  : (isDark ? Colors.white12 : Colors.black12)),
                          width: isSelected ? 1.6 : 1.0,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                isSelected
                                    ? Icons.radio_button_checked_rounded
                                    : Icons.radio_button_off_rounded,
                                size: 16,
                                color: isSelected ? IrisTokens.brand : Colors.grey,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                off.batch,
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w900,
                                  color: isSelected
                                      ? IrisTokens.brand
                                      : (isDark ? Colors.white : Colors.black),
                                ),
                              ),
                              const SizedBox(width: 8),
                              // Instructor chip
                              Flexible(
                                child: Text(
                                  off.teacher,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    color: isDark ? Colors.white70 : Colors.black87,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 6),
                              // Room pill
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 6,
                                  vertical: 2,
                                ),
                                decoration: BoxDecoration(
                                  color: (isDark ? Colors.white : Colors.black)
                                      .withValues(alpha: 0.06),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  off.room.isNotEmpty ? 'Room ${off.room}' : 'TBA',
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w700,
                                    color: isDark ? Colors.white70 : Colors.black87,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          // Slots summary
                          Text(
                            off.timeSlotsSummary,
                            style: TextStyle(
                              fontSize: 11,
                              color: isDark ? Colors.white60 : Colors.black54,
                            ),
                          ),
                          const SizedBox(height: 6),
                          // Clash Status Line
                          Row(
                            children: [
                              if (hasClash) ...[
                                const Icon(
                                  Icons.warning_amber_rounded,
                                  size: 13,
                                  color: Color(0xFFEF4444),
                                ),
                                const SizedBox(width: 4),
                                Expanded(
                                  child: Text(
                                    analyzed.clashSummary,
                                    style: const TextStyle(
                                      fontSize: 10.5,
                                      fontWeight: FontWeight.w700,
                                      color: Color(0xFFEF4444),
                                    ),
                                  ),
                                ),
                              ] else ...[
                                const Icon(
                                  Icons.check_circle_rounded,
                                  size: 13,
                                  color: Color(0xFF10B981),
                                ),
                                const SizedBox(width: 4),
                                const Text(
                                  'Conflict-Free · Fits your regular timetable',
                                  style: TextStyle(
                                    fontSize: 10.5,
                                    fontWeight: FontWeight.w700,
                                    color: Color(0xFF10B981),
                                  ),
                                ),
                              ],
                              if (isSelected)
                                Container(
                                  margin: const EdgeInsets.only(left: 6),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 6,
                                    vertical: 2,
                                  ),
                                  decoration: BoxDecoration(
                                    color: IrisTokens.brand,
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                  child: const Text(
                                    'SELECTED',
                                    style: TextStyle(
                                      fontSize: 9,
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
          ],
        ),
      ),
    ),
    );
  }

  Widget _buildCombinedWeeklyPreview(bool isDark, bool isM3, ColorScheme cs) {
    if (_repeatCourses.isEmpty) return const SizedBox.shrink();

    final combinedSessions = RepeaterPlannerEngine.buildCombinedSchedule(
      memory: widget.memory,
      baseBatch: _currentBaseBatch,
      repeatCourses: _repeatCourses,
      selectedOfferings: _selectedOfferings,
    );

    final daySessions = combinedSessions
        .where((s) => s.dayIndex == _previewDayIndex)
        .toList()
      ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));

    final days = [
      {'name': 'Mon', 'day': 1},
      {'name': 'Tue', 'day': 2},
      {'name': 'Wed', 'day': 3},
      {'name': 'Thu', 'day': 4},
      {'name': 'Fri', 'day': 5},
    ];

    final repeatNormSet = _repeatCourses
        .map((c) => RepeaterPlannerEngine.normalizeCourseName(c).toLowerCase())
        .toSet();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Combined Weekly Timetable',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w900,
                color: isM3 ? cs.onSurface : (isDark ? Colors.white : Colors.black87),
              ),
            ),
            Text(
              'Normal + Repeater Classes',
              style: TextStyle(
                fontSize: 11,
                color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white54 : Colors.black54),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 36,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: days.length,
            separatorBuilder: (_, _) => const SizedBox(width: 8),
            itemBuilder: (context, index) {
              final d = days[index];
              final dIdx = d['day'] as int;
              final isSelected = dIdx == _previewDayIndex;
              final count = combinedSessions.where((s) => s.dayIndex == dIdx).length;

              return ExpressiveInteractivePress(
                onTap: () {
                  IrisHaptics.chipSelect();
                  setState(() => _previewDayIndex = dIdx);
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? IrisTokens.brand
                        : (isM3
                            ? cs.surfaceContainerHigh
                            : (isDark
                                ? Colors.white10
                                : Colors.black.withValues(alpha: 0.05))),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(
                      color: isSelected
                          ? IrisTokens.brand
                          : (isDark ? Colors.white12 : Colors.black12),
                    ),
                  ),
                  child: Text(
                    '${d['name']} ($count)',
                    style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                      color: isSelected
                          ? Colors.white
                          : (isDark ? Colors.white70 : Colors.black87),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        if (daySessions.isEmpty)
          GlassCard(
            padding: const EdgeInsets.all(16),
            borderRadius: 16,
            child: Center(
              child: Text(
                'No classes scheduled on this day.',
                style: TextStyle(
                  fontSize: 12,
                  color: isDark ? Colors.white54 : Colors.black45,
                ),
              ),
            ),
          )
        else
          ...daySessions.map((s) {
            final isRepeaterSession = repeatNormSet
                .contains(RepeaterPlannerEngine.normalizeCourseName(s.subject).toLowerCase());

            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: GlassCard(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                borderRadius: 14,
                accentColor: isRepeaterSession ? const Color(0xFF10B981) : null,
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: (isRepeaterSession ? const Color(0xFF10B981) : IrisTokens.brand)
                            .withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        '${s.startTime} - ${s.endTime}',
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                          color: isRepeaterSession ? const Color(0xFF10B981) : IrisTokens.brand,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  s.subject,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w800,
                                    color: isDark ? Colors.white : Colors.black,
                                  ),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: (isRepeaterSession ? const Color(0xFF10B981) : const Color(0xFF8B5CF6))
                                      .withValues(alpha: 0.18),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  isRepeaterSession ? 'REPEATER' : 'BASE BATCH',
                                  style: TextStyle(
                                    fontSize: 9,
                                    fontWeight: FontWeight.w900,
                                    color: isRepeaterSession ? const Color(0xFF10B981) : const Color(0xFF8B5CF6),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Text(
                            'Batch ${s.batchKey.batch} · Room ${s.room.isEmpty ? "TBA" : s.room} · ${s.teacher}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 10.5,
                              color: isDark ? Colors.white60 : Colors.black54,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          }),
      ],
    );
  }

  Widget _buildBottomActionBar(bool isDark, bool isM3, ColorScheme cs) {
    int clashingCount = 0;
    for (final c in _repeatCourses) {
      final chosen = _selectedOfferings[c];
      final analyzed = _analyzedOfferingsMap[c] ?? [];
      final match = analyzed.firstWhere(
        (a) => a.offering.batch == chosen?.batch,
        orElse: () => analyzed.isNotEmpty ? analyzed.first : AnalyzedOffering(
          offering: CourseOffering(courseName: c, batch: '', teacher: '', room: '', sessions: const []),
          hasClash: false,
        ),
      );
      if (match.hasClash) clashingCount++;
    }

    final hasClash = clashingCount > 0;

    return GlassCard(
      borderRadius: 0,
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      enableOverlay: true,
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${_repeatCourses.length} Repeat Course(s)',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: isDark ? Colors.white : Colors.black,
                    ),
                  ),
                  Row(
                    children: [
                      Icon(
                        hasClash ? Icons.warning_amber_rounded : Icons.check_circle_rounded,
                        size: 12,
                        color: hasClash ? const Color(0xFFEF4444) : const Color(0xFF10B981),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        hasClash
                            ? '$clashingCount course(s) have clash'
                            : 'All Conflict-Free ✓',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: hasClash ? const Color(0xFFEF4444) : const Color(0xFF10B981),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            ElevatedButton.icon(
              onPressed: _saveAndActivateSchedule,
              style: ElevatedButton.styleFrom(
                backgroundColor: IrisTokens.brand,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                elevation: 2,
              ),
              icon: const Icon(Icons.check_rounded, size: 18),
              label: const Text(
                'Activate Timetable',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
