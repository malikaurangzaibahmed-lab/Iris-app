import '../../core/vital_theme.dart';
import 'package:flutter/material.dart';
import '../../widgets/glass_card.dart';
import 'package:iris/widgets/effects/nature_particles.dart';
import '../../core/tokens.dart';
import '../../core/theme_signals.dart';
import 'package:iris/widgets/navigation/iris_expressive_header.dart';

// ==========================================================================
// STUDENTS WEEK HEADER CARD WITH STATIC COMIC ARTWORK (0% IDLE CPU)
// ==========================================================================

class StudentsWeekHeaderCard extends StatelessWidget {
  final String userName;
  final String batch;
  final VoidCallback onToggleTheme;

  const StudentsWeekHeaderCard({
    required this.userName,
    required this.batch,
    required this.onToggleTheme,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    if (ThemeSignals.isMaterialYou) {
      final cs = Theme.of(context).colorScheme;
      return Container(
        decoration: BoxDecoration(
          color: isDark ? cs.surfaceContainer : cs.surfaceContainerLow,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(
            color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.6),
            width: 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF10B981).withValues(alpha: isDark ? 0.12 : 0.08),
              blurRadius: 20,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: cs.primaryContainer,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    "🏆 STUDENTS' GALA ${DateTime.now().year}",
                    style: TextStyle(
                      fontSize: 10.5,
                      fontWeight: FontWeight.w900,
                      color: cs.onPrimaryContainer,
                      letterSpacing: 1.0,
                    ),
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: cs.secondaryContainer,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    batch,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: cs.onSecondaryContainer,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              "Sports Gala & Campus Events",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.4,
                color: cs.onSurface,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              "Athletic fixtures active across campus. Class and lab timetables are scheduled below.",
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: cs.onSurfaceVariant,
                height: 1.35,
              ),
            ),
          ],
        ),
      );
    }

    return StudentsWeekAnimationWidget(
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: isDark
                        ? const Color(0xFF10B981).withValues(alpha: 0.16)
                        : const Color(0xFFECFDF5),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: isDark
                          ? const Color(0xFF10B981).withValues(alpha: 0.35)
                          : const Color(0xFF10B981).withValues(alpha: 0.45),
                      width: 1,
                    ),
                  ),
                  child: Text(
                    "🏆 STUDENTS' GALA ${DateTime.now().year}",
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      color: isDark
                          ? const Color(0xFF10B981)
                          : const Color(0xFF047857),
                      letterSpacing: 1.2,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'Unleash the\nAthletic Brain',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -0.5,
                    height: 1.1,
                    color: isDark ? Colors.white : Theme.of(context).colorScheme.onSurface,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  "Sports gala events active across campus! Timetables and scheduled classes.",
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: isDark
                        ? Colors.white.withValues(alpha: 0.70)
                        : Theme.of(context).colorScheme.onSurfaceVariant,
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 80),
        ],
      ),
    );
  }
}

// ==========================================================================
// STATIC COMIC HEADER CARD BASE COMPONENT (0% CPU, RIGID, SCRIM GRADIENT)
// ==========================================================================

class HeaderImageCard extends StatelessWidget {
  final String? imageAsset;
  final Widget child;
  final Widget? bottomWidget;
  final Color accentColor;
  final double borderRadius;
  final double? minHeight;

  const HeaderImageCard({
    this.imageAsset,
    required this.child,
    this.bottomWidget,
    required this.accentColor,
    this.borderRadius = 32.0,
    this.minHeight,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final screenH = MediaQuery.sizeOf(context).height;
    final isCompactHeight = screenH < 520;

    return ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, themeStyle, _) {
        final isM3 = themeStyle == IrisThemeStyle.materialYou;

        if (isM3) {
          // Pixel-style authentic Material 3 Expressive header:
          // Compact, content-driven, zero bloated 480dp dead space
          return RepaintBoundary(
            child: IrisExpressiveHeaderCanvas(
              domain: identifyHeaderDomain(imageAsset),
              accentColor: accentColor,
              borderRadius: 28.0,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    child,
                    if (bottomWidget != null) ...[
                      const SizedBox(height: 10),
                      bottomWidget!,
                    ],
                  ],
                ),
              ),
            ),
          );
        } else if (themeStyle != IrisThemeStyle.fluidGlass) {
          // Almanac, Editorial, Notebook, Line, and Poster:
          // Pure paper/ink/brutalist card without comic bitmap artwork
          return RepaintBoundary(
            child: GlassCard(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
              borderRadius: borderRadius,
              accentColor: accentColor,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  child,
                  if (bottomWidget != null) ...[
                    const SizedBox(height: 10),
                    bottomWidget!,
                  ],
                ],
              ),
            ),
          );
        } else {
          // Fluid Glass / Liquid Theme: Preserves high-res comic artwork with frosted glass refraction
          final effectiveMinHeight =
              minHeight ??
              (bottomWidget != null
                  ? (isCompactHeight ? 150.0 : 180.0)
                  : (isCompactHeight ? 100.0 : 130.0));
          final middleGap = isCompactHeight ? 10.0 : 14.0;
          final contentPadding = isCompactHeight
              ? const EdgeInsets.fromLTRB(14, 12, 14, 12)
              : const EdgeInsets.fromLTRB(16, 14, 16, 14);

          return RepaintBoundary(
            child: HeaderAtmosphereWrapper(
            radius: borderRadius,
            themeColor: accentColor,
            child: GlassCard(
              padding: EdgeInsets.zero,
              borderRadius: borderRadius,
              accentColor: accentColor,
              border: Border.all(
                color: accentColor.withValues(alpha: isDark ? 0.25 : 0.35),
                width: 1.2,
              ),
              glow: true,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(borderRadius),
                child: Stack(
                  children: [
                    if (imageAsset != null && imageAsset!.isNotEmpty) ...[
                      // 1. Comic Widescreen Background Artwork for Liquid Theme
                      Positioned.fill(
                        child: Image.asset(
                          imageAsset!,
                          fit: BoxFit.cover,
                          cacheWidth: 1080,
                          errorBuilder: (context, error, stackTrace) => Container(
                            color: isDark
                                ? const Color(0xFF0B101E)
                                : const Color(0xFFF1F5F9),
                          ),
                        ),
                      ),
                      // 2. High-legibility Contrast Scrim matched to brightness
                      Positioned.fill(
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                (isDark ? const Color(0xFF030712) : Colors.white)
                                    .withValues(alpha: isDark ? 0.68 : 0.78),
                                (isDark ? const Color(0xFF030712) : Colors.white)
                                    .withValues(alpha: isDark ? 0.32 : 0.56),
                                (isDark ? const Color(0xFF030712) : Colors.white)
                                    .withValues(alpha: isDark ? 0.62 : 0.78),
                              ],
                              stops: const [0.0, 0.45, 1.0],
                            ),
                          ),
                        ),
                      ),
                    ],
                    // Foreground Content
                    Padding(
                      padding: contentPadding,
                      child: Container(
                        constraints: BoxConstraints(minHeight: effectiveMinHeight),
                        alignment: Alignment.topLeft,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            child,
                            if (bottomWidget != null) ...[
                              SizedBox(height: middleGap),
                              bottomWidget!,
                            ],
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }
      },
    );
  }
}

enum StudentsWeekAnimationMode { cricket, football, animals, singers }

class StudentsWeekAnimationWidget extends StatelessWidget {
  final Widget child;
  final Widget? bottomWidget;
  const StudentsWeekAnimationWidget({
    required this.child,
    this.bottomWidget,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return HeaderImageCard(
      imageAsset: 'assets/headers/header_sports_gala.jpg',
      accentColor: const Color(0xFF10B981),
      borderRadius: 36.0,
      bottomWidget: bottomWidget,
      child: child,
    );
  }
}

// ==========================================================================
// CLASSES (NORMAL PERIOD) HEADER: DAY & NIGHT COMIC ARTWORK
// ==========================================================================

enum DayPeriod { morning, day, night }

class ClassesAnimationWidget extends StatelessWidget {
  final Widget child;
  final Widget? bottomWidget;
  const ClassesAnimationWidget({
    required this.child,
    this.bottomWidget,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final hour = DateTime.now().hour;
    final isNight = hour < 6 || hour >= 18;
    final imageAsset = isNight
        ? 'assets/headers/header_classes_night.jpg'
        : 'assets/headers/header_classes_day.jpg';

    return HeaderImageCard(
      imageAsset: imageAsset,
      accentColor: IrisTokens.brand,
      borderRadius: 36.0,
      bottomWidget: bottomWidget,
      child: child,
    );
  }
}

// ==========================================================================
// MIDTERMS HEADER: STOPWATCH, GRAPH & CALC COMIC ARTWORK
// ==========================================================================

class MidtermsAnimationWidget extends StatelessWidget {
  final Widget child;
  final Widget? bottomWidget;
  const MidtermsAnimationWidget({
    required this.child,
    this.bottomWidget,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return HeaderImageCard(
      imageAsset: 'assets/headers/header_midterms_mode.jpg',
      accentColor: const Color(0xFFF59E0B),
      borderRadius: 32.0,
      bottomWidget: bottomWidget,
      child: child,
    );
  }
}

// ==========================================================================
// RAMADAN MODE HEADER: FANCOUS LANTERN & COURTYARD COMIC ARTWORK
// ==========================================================================

class RamadanAnimationWidget extends StatelessWidget {
  final Widget child;
  final Widget? bottomWidget;
  const RamadanAnimationWidget({
    required this.child,
    this.bottomWidget,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return HeaderImageCard(
      imageAsset: 'assets/headers/header_ramadan_mode.jpg',
      accentColor: const Color(0xFF10B981),
      borderRadius: 32.0,
      bottomWidget: bottomWidget,
      child: child,
    );
  }
}

// ==========================================================================
// FINALS WEEK HEADER: GRADUATION CAP & HALL COMIC ARTWORK
// ==========================================================================

class FinalsAnimationWidget extends StatelessWidget {
  final Widget child;
  final Widget? bottomWidget;
  const FinalsAnimationWidget({
    required this.child,
    this.bottomWidget,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return HeaderImageCard(
      imageAsset: 'assets/headers/header_finals_week.jpg',
      accentColor: const Color(0xFF6366F1),
      borderRadius: 32.0,
      bottomWidget: bottomWidget,
      child: child,
    );
  }
}

// ==========================================================================
// TEACHER LOCATOR HEADER: BLUEPRINT & COMPASS COMIC ARTWORK
// ==========================================================================

class TeacherLocatorAnimationWidget extends StatelessWidget {
  final Widget child;
  final Widget? bottomWidget;
  const TeacherLocatorAnimationWidget({
    required this.child,
    this.bottomWidget,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return HeaderImageCard(
      imageAsset: 'assets/headers/header_room_finder.jpg',
      accentColor: IrisTokens.brand,
      borderRadius: 32.0,
      bottomWidget: bottomWidget,
      child: child,
    );
  }
}

// ==========================================================================
// ROOM FINDER HEADER: BLUEPRINT & CAMPUS MAP COMIC ARTWORK
// ==========================================================================

class RoomFinderAnimationWidget extends StatelessWidget {
  final Widget child;
  final Widget? bottomWidget;
  const RoomFinderAnimationWidget({
    required this.child,
    this.bottomWidget,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return HeaderImageCard(
      imageAsset: 'assets/headers/header_room_finder.jpg',
      accentColor: IrisTokens.purple,
      borderRadius: 32.0,
      bottomWidget: bottomWidget,
      child: child,
    );
  }
}

// ==========================================================================
// ACADEMICS / CGPA CALCULATOR HEADER: CGPA GAUGE COMIC ARTWORK
// ==========================================================================

class CgpaCalculatorAnimationWidget extends StatelessWidget {
  final Widget child;
  final Widget? bottomWidget;
  const CgpaCalculatorAnimationWidget({
    required this.child,
    this.bottomWidget,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return HeaderImageCard(
      imageAsset: 'assets/headers/header_academics_hub.jpg',
      accentColor: const Color(0xFF8B5CF6),
      borderRadius: 32.0,
      bottomWidget: bottomWidget,
      child: child,
    );
  }
}

// ==========================================================================
// FACULTY DIRECTORY & DEPARTMENT HUB HEADER: AUDITORIUM COMIC ARTWORK
// ==========================================================================

class DirectoryAnimationWidget extends StatelessWidget {
  final Widget child;
  final Widget? bottomWidget;
  const DirectoryAnimationWidget({
    required this.child,
    this.bottomWidget,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return HeaderImageCard(
      imageAsset: 'assets/headers/header_faculty_hub.jpg',
      accentColor: IrisTokens.purple,
      borderRadius: 32.0,
      bottomWidget: bottomWidget,
      child: child,
    );
  }
}

class DirectoryBackgroundWidget extends StatelessWidget {
  const DirectoryBackgroundWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final accentColor = IrisTokens.purple;

    if (isM3) {
      final cs = Theme.of(context).colorScheme;
      return Container(
        decoration: BoxDecoration(
          color: isDark ? cs.surfaceContainer : cs.surface,
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color.alphaBlend(
                accentColor.withValues(alpha: isDark ? 0.16 : 0.08),
                isDark ? cs.surfaceContainerHigh : cs.surfaceContainerLow,
              ),
              isDark ? cs.surface : cs.surfaceBright,
            ],
          ),
        ),
      );
    }

    if (!ThemeSignals.isFluidGlass) {
      return ObsidianPulse(isDark: isDark);
    }

    return Stack(
      children: [
        Positioned.fill(
          child: Image.asset(
            'assets/headers/header_faculty_hub.jpg',
            fit: BoxFit.cover,
            cacheWidth: 1080,
            errorBuilder: (context, error, stackTrace) => Container(
              color: isDark ? const Color(0xFF0B101E) : const Color(0xFFF1F5F9),
            ),
          ),
        ),
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.transparent,
                  (isDark ? Colors.black : Colors.white).withValues(alpha: 0.8),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ==========================================================================
// IRIS HUB HEADER: HIGH-TECH COMMAND LAB COMIC ARTWORK
// ==========================================================================

class IrisHubAnimationWidget extends StatelessWidget {
  final Widget child;
  final Widget? bottomWidget;
  const IrisHubAnimationWidget({
    required this.child,
    this.bottomWidget,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return HeaderImageCard(
      imageAsset: 'assets/headers/header_iris_hub.jpg',
      accentColor: IrisTokens.brand,
      borderRadius: 32.0,
      bottomWidget: bottomWidget,
      child: child,
    );
  }
}
