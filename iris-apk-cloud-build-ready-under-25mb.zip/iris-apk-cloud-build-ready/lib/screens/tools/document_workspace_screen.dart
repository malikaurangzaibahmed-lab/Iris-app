import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:path_provider/path_provider.dart';
import 'package:open_filex/open_filex.dart';
import '../../core/tokens.dart';
import '../../core/models.dart';
import '../../core/theme_signals.dart';
import '../../core/glass.dart';
import '../../services/ui_feedback.dart';
import 'package:iris/widgets/controls/iris_liquid_button.dart';
import '../../services/cover_page_generator.dart';
import '../../services/docx_generator.dart';
import '../../core/material_you_theme.dart';
import '../../core/animations.dart';
import 'package:iris/widgets/iris_components.dart';

import '../../core/vital_theme.dart';
import '../../models/document_studio_models.dart';
import '../../widgets/document/document_converter_view.dart';
import '../../widgets/document/document_splitter_view.dart';
export '../../models/document_studio_models.dart';
export '../../widgets/document/document_converter_view.dart';
export '../../widgets/document/document_splitter_view.dart';

class DocumentWorkspaceScreen extends StatefulWidget {
  const DocumentWorkspaceScreen({super.key});

  @override
  State<DocumentWorkspaceScreen> createState() => _DocumentWorkspaceScreenState();
}

class _DocumentWorkspaceScreenState extends State<DocumentWorkspaceScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isDraggingImage = false;
  
  // Document Maker Wizard State
  bool _hasActiveDocument = false;
  String _docType = 'Assignment'; // 'Assignment', 'Quiz Prep', 'Project Report'
  final TextEditingController _courseController = TextEditingController();
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _authorController = TextEditingController();
  final TextEditingController _regIdController = TextEditingController();
  final TextEditingController _deptController = TextEditingController(text: 'Department of Computer Science');
  final TextEditingController _campusController = TextEditingController(text: 'COMSATS University Islamabad, Sahiwal Campus');
  List<CoverPageField> _customCoverFields = [];
  
  // Document Editor State
  final TextEditingController _editorController = TextEditingController();
  final List<DraggableStudioImage> _attachedImages = [];
  final List<StudioBlock> _floatingBlocks = [];
  bool _includeCoverPage = true;
  int _ribbonTabIndex = 0; // 0 = Home, 1 = Insert, 2 = Layout
  String _paperColorMode = 'White'; // 'White', 'Sepia', 'Dark'

  // Document Exporter State
  bool _isExporting = false;
  double _exportProgress = 0.0;
  bool _exportSuccess = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadDraftDocument();
    _smartAutofillIdentity();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _courseController.dispose();
    _titleController.dispose();
    _authorController.dispose();
    _regIdController.dispose();
    _deptController.dispose();
    _campusController.dispose();
    _editorController.dispose();
    super.dispose();
  }

  Future<void> _smartAutofillIdentity({bool showFeedback = false}) async {
    final prefs = await SharedPreferences.getInstance();
    final savedName = prefs.getString('student_user_name')?.trim().isNotEmpty == true
        ? prefs.getString('student_user_name')!.trim()
        : (prefs.getString('faculty_user_name')?.trim().isNotEmpty == true
            ? prefs.getString('faculty_user_name')!.trim()
            : prefs.getString('user_name')?.trim() ?? '');

    final rawBatch = prefs.getString('student_batch') ?? prefs.getString('user_batch') ?? prefs.getString('current_batch') ?? '';
    final savedRoll = prefs.getString('student_roll_no') ?? prefs.getString('roll_no') ?? '';

    String formattedRegId = '';
    if (rawBatch.isNotEmpty) {
      final key = BatchKey.parse(rawBatch);
      final term = key.intake;
      final program = key.program;
      if (savedRoll.isNotEmpty) {
        formattedRegId = [term, program, savedRoll.padLeft(3, '0')].where((s) => s.isNotEmpty).join('-');
      } else {
        formattedRegId = [term, program].where((s) => s.isNotEmpty).join('-');
      }
    } else if (savedRoll.isNotEmpty) {
      formattedRegId = savedRoll.padLeft(3, '0');
    }

    final activeCourse = prefs.getString('widget_subject') ?? prefs.getString('active_subject') ?? prefs.getString('current_course') ?? '';
    final activeDept = prefs.getString('user_department') ?? prefs.getString('department') ?? 'Department of Computer Science';

    setState(() {
      if (savedName.isNotEmpty && _authorController.text.isEmpty) {
        _authorController.text = savedName;
      }
      if (formattedRegId.isNotEmpty && _regIdController.text.isEmpty) {
        _regIdController.text = formattedRegId;
      }
      if (activeCourse.isNotEmpty && _courseController.text.isEmpty) {
        _courseController.text = activeCourse;
      }
      if (activeDept.isNotEmpty) {
        _deptController.text = activeDept;
      }
    });

    if (showFeedback && mounted && (savedName.isNotEmpty || formattedRegId.isNotEmpty)) {
      IrisHaptics.actionSoft();
      showIrisFrostedSnackBar(
        context,
        content: Text('⚡ Intelligent App-Data Prefilled: ${formattedRegId.isNotEmpty ? formattedRegId : savedName}'),
      );
    }
  }

  Future<void> _loadDraftDocument() async {
    final prefs = await SharedPreferences.getInstance();
    final hasDraft = prefs.getBool('helpdesk_has_doc_draft') ?? false;
    if (hasDraft) {
      setState(() {
        _hasActiveDocument = true;
        _docType = prefs.getString('helpdesk_doc_type') ?? 'Assignment';
        _courseController.text = prefs.getString('helpdesk_doc_course') ?? '';
        _titleController.text = prefs.getString('helpdesk_doc_title') ?? '';
        _authorController.text = prefs.getString('helpdesk_doc_author') ?? '';
        _regIdController.text = prefs.getString('helpdesk_doc_reg') ?? '';
        _editorController.text = prefs.getString('helpdesk_doc_content') ?? '';
        
        final imagesJson = prefs.getString('helpdesk_doc_images') ?? '[]';
        try {
          final List<dynamic> decoded = jsonDecode(imagesJson);
          _attachedImages.clear();
          for (var item in decoded) {
            final pFile = PlatformFile(
              name: item['name'] ?? 'image.jpg',
              size: item['size'] ?? 0,
              path: item['path'],
            );
            _attachedImages.add(
              DraggableStudioImage(
                id: 'img_${DateTime.now().millisecondsSinceEpoch}',
                file: pFile,
              ),
            );
          }
        } catch (_) {}
      });
    } else {
      await _smartAutofillIdentity(showFeedback: false);
    }
  }

  Future<void> _saveDraftDocument() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('helpdesk_has_doc_draft', _hasActiveDocument);
    if (_hasActiveDocument) {
      await prefs.setString('helpdesk_doc_type', _docType);
      await prefs.setString('helpdesk_doc_course', _courseController.text);
      await prefs.setString('helpdesk_doc_title', _titleController.text);
      await prefs.setString('helpdesk_doc_author', _authorController.text);
      await prefs.setString('helpdesk_doc_reg', _regIdController.text);
      await prefs.setString('helpdesk_doc_content', _editorController.text);
      
      final List<Map<String, dynamic>> imagesList = _attachedImages.map((e) => {
        'name': e.file.name,
        'size': e.file.size,
        'path': e.file.path,
      }).toList();
      await prefs.setString('helpdesk_doc_images', jsonEncode(imagesList));
    }
  }

  void _initializeTemplate() {
    String template = '';
    
    if (_docType == 'Assignment') {
      template = '''# 1. Introduction
Write your introductory notes, definitions, or literature background here...

# 2. Problem Statement & Requirements
Explain the assignment questions, requirements, or problem description here...

# 3. Methodology & Theoretical Approach
Write step-by-step logic, code segments, or theoretical diagrams here...

# 4. Implementation & Results
Attach code outputs or explain execution screens...

# 5. Conclusion & References
Summarize results and add project references...
''';
    } else if (_docType == 'Quiz Prep') {
      template = '''# 1. Key Formulas & Core Theories
1. [Formula 1 Name]: description / equation
2. [Theory 2 Name]: quick bullet summary

# 2. Core Lecture Notes & Concepts
- Topic 1 Core Takeaway: write summary note...
- Topic 2 Core Takeaway: write summary note...

# 3. Sample & Past Paper Questions
1. [Past Question 1]
   - Solution Roadmap / Hint: write solution steps here...
2. [Past Question 2]
   - Solution Roadmap / Hint: write solution steps here...
''';
    } else {
      template = '''# 1. Executive Summary
Provide a high-level summary of the semester project goals, architecture, and current execution status...

# 2. Technology Stack & Frameworks
- Frontend: Flutter & Liquid Glass Canvas
- Backend: Node.js / Kotlin AppWidget providers
- Database: SharedPreferences local syncs

# 3. Implementation Milestones & Architecture
- Phase 1: Requirement gathering and vector design validation
- Phase 2: Complete RemoteViews frame layout changes
- Phase 3: Connect document export engine modules

# 4. Results & Screenshots
Attach output previews and write comments below...
''';
    }

    setState(() {
      _editorController.text = template;
      _attachedImages.clear();
      _hasActiveDocument = true;
      _exportSuccess = false;
    });
    IrisHaptics.actionHeavy();
    _saveDraftDocument();
  }

  void _generateAIOutline() {
    IrisHaptics.actionHeavy();
    final outline = '''
# 1. Introduction
Write your introductory notes, definitions, or literature background here...

# 2. Problem Statement & Objectives
Explain the assignment questions, requirements, or problem description here...

# 3. Methodology & Algorithm Design
Write step-by-step logic, code segments, or theoretical diagrams here...

# 4. Implementation & Experimental Results
Attach code outputs or explain execution screens...

# 5. Conclusion & References
Summarize key findings, experimental outcomes, and list project references...
''';

    _insertEditorText('\n$outline\n');
    showIrisFrostedSnackBar(context, content: const Text('⚡ AI Academic Document Outline Generated!'));
  }

  void _applyFormatToSelection(String prefix, String suffix, String defaultText) {
    final text = _editorController.text;
    final selection = _editorController.selection;
    
    if (selection.start >= 0 && selection.end >= 0 && selection.start != selection.end) {
      final selectedText = text.substring(selection.start, selection.end);
      if (selectedText.startsWith(prefix) && selectedText.endsWith(suffix) && selectedText.length >= prefix.length + suffix.length) {
        final unwrapped = selectedText.substring(prefix.length, selectedText.length - suffix.length);
        final newText = text.replaceRange(selection.start, selection.end, unwrapped);
        _editorController.text = newText;
        _editorController.selection = TextSelection(
          baseOffset: selection.start,
          extentOffset: selection.start + unwrapped.length,
        );
      } else {
        final wrapped = '$prefix$selectedText$suffix';
        final newText = text.replaceRange(selection.start, selection.end, wrapped);
        _editorController.text = newText;
        _editorController.selection = TextSelection(
          baseOffset: selection.start + prefix.length,
          extentOffset: selection.start + prefix.length + selectedText.length,
        );
      }
    } else {
      final snippet = '$prefix$defaultText$suffix';
      final start = selection.start >= 0 ? selection.start : text.length;
      final newText = text.replaceRange(start, start, snippet);
      _editorController.text = newText;
      _editorController.selection = TextSelection(
        baseOffset: start + prefix.length,
        extentOffset: start + prefix.length + defaultText.length,
      );
    }
    _saveDraftDocument();
    IrisHaptics.actionSoft();
  }

  Future<void> _attachImage() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.image,
      );
      if (result != null && result.files.isNotEmpty) {
        setState(() {
          final file = result.files.first;
          _attachedImages.add(
            DraggableStudioImage(
              id: 'img_${DateTime.now().millisecondsSinceEpoch}',
              file: file,
            ),
          );
          // Insert image markdown placeholder in editor
          final imageName = file.name;
          final currentPos = _editorController.selection.baseOffset;
          final markdownTag = '\n![Image Attachment: $imageName](Attached Asset)\n';
          
          if (currentPos >= 0 && currentPos <= _editorController.text.length) {
            final text = _editorController.text;
            _editorController.text = text.substring(0, currentPos) + markdownTag + text.substring(currentPos);
          } else {
            _editorController.text += markdownTag;
          }
        });
        IrisHaptics.chipSelect();
        _saveDraftDocument();
      }
    } catch (e) {
      debugPrint('Image attach error: $e');
    }
  }

  Future<void> _exportDocument() async {
    setState(() {
      _isExporting = true;
      _exportProgress = 0.1;
      _exportSuccess = false;
    });

    try {
      final docText = _editorController.text;
      
      setState(() => _exportProgress = 0.3);
      
      final document = PdfDocument();
      document.pageSettings.margins.all = 36.0;
      document.pageSettings.size = PdfPageSize.a4;

      if (_includeCoverPage) {
        final coverData = await CoverPageData.resolveDefaults(
          course: _courseController.text,
          title: _titleController.text,
          teacher: _authorController.text.isNotEmpty ? _authorController.text : 'Dr. Wasim',
          type: _docType,
          department: _deptController.text.isNotEmpty ? _deptController.text : 'Department of Computer Science',
        );
        if (_customCoverFields.isNotEmpty) {
          coverData.customFields = List.from(_customCoverFields);
        }
        await CoverPageGenerator.drawCoverPageOnDocument(document, coverData);
      }

      setState(() => _exportProgress = 0.5);

      StringBuffer fullBody = StringBuffer(docText);
      if (_floatingBlocks.isNotEmpty) {
        fullBody.writeln('\n\n---');
        fullBody.writeln('### ADDITIONAL NOTES & CALLOUTS');
        for (final block in _floatingBlocks) {
          if (block.controller.text.trim().isNotEmpty) {
            fullBody.writeln('* ${block.type.toUpperCase()}: ${block.controller.text.trim()}');
          }
        }
      }

      // Render rich formatted Markdown text into PDF pages
      RichMarkdownPdfRenderer.renderMarkdownToDocument(
        document: document,
        markdownText: fullBody.toString(),
        hasCoverPage: _includeCoverPage,
        docTitle: _titleController.text,
      );

      // Embed attached figures/images at user's exact dragged position and size on the PDF document page
      if (_attachedImages.isNotEmpty) {
        final targetPageIdx = _includeCoverPage ? 1 : 0;
        final targetPage = document.pages.count > targetPageIdx 
            ? document.pages[targetPageIdx] 
            : document.pages.add();

        for (final imgItem in _attachedImages) {
          if (imgItem.file.path != null && File(imgItem.file.path!).existsSync()) {
            final imageBytes = File(imgItem.file.path!).readAsBytesSync();
            final bitmap = PdfBitmap(imageBytes);
            targetPage.graphics.drawImage(
              bitmap,
              Rect.fromLTWH(
                imgItem.offset.dx.clamp(0.0, targetPage.getClientSize().width - 40.0),
                imgItem.offset.dy.clamp(0.0, targetPage.getClientSize().height - 40.0),
                imgItem.width,
                imgItem.height,
              ),
            );
          }
        }
      }
      
      setState(() => _exportProgress = 0.7);
      
      final List<int> bytes = await document.save();
      document.dispose();
      
      final dir = await getApplicationDocumentsDirectory();
      final safeTitle = _titleController.text.replaceAll(RegExp(r'[^a-zA-Z0-9_\-]'), '_');
      final fileName = '${safeTitle}_${DateTime.now().millisecondsSinceEpoch}.pdf';
      final file = File('${dir.path}/$fileName');
      await file.writeAsBytes(bytes);
      
      setState(() {
        _exportProgress = 1.0;
        _isExporting = false;
        _exportSuccess = true;
      });
      
      IrisHaptics.actionHeavy();
      if (!mounted) return;
      showIrisFrostedSnackBar(context, content: Text('Document exported successfully: $fileName'));
      
      await OpenFilex.open(file.path);
    } catch (e) {
      setState(() {
        _isExporting = false;
        _exportSuccess = false;
      });
      if (!mounted) return;
      showIrisFrostedSnackBar(context, content: Text('Export failed: $e'));
    }
  }

  Future<void> _exportDocumentWithFormat(String format) async {
    final docText = _editorController.text;
    final dir = await getApplicationDocumentsDirectory();
    final safeTitle = _titleController.text.isNotEmpty 
        ? _titleController.text.replaceAll(RegExp(r'[^a-zA-Z0-9_\-]'), '_')
        : 'Document';
    final timestamp = DateTime.now().millisecondsSinceEpoch;

    if (format.contains('.docx')) {
      final fileName = '${safeTitle}_$timestamp.docx';
      final filePath = '${dir.path}/$fileName';
      
      CoverPageData? coverData;
      if (_includeCoverPage) {
        coverData = await CoverPageData.resolveDefaults(
          course: _courseController.text,
          title: _titleController.text,
          teacher: _authorController.text,
          type: _docType,
          department: _deptController.text.isNotEmpty ? _deptController.text : 'Department of Computer Science',
        );
        if (_customCoverFields.isNotEmpty) {
          coverData.customFields = List.from(_customCoverFields);
        }
      }

      StringBuffer fullBody = StringBuffer(docText);
      if (_floatingBlocks.isNotEmpty) {
        fullBody.writeln('\n\n---');
        fullBody.writeln('### ADDITIONAL NOTES & CALLOUTS');
        for (final block in _floatingBlocks) {
          if (block.controller.text.trim().isNotEmpty) {
            fullBody.writeln('* ${block.type.toUpperCase()}: ${block.controller.text.trim()}');
          }
        }
      }

      final file = await DocxGenerator.generateDocx(
        filePath: filePath,
        markdownBody: fullBody.toString(),
        coverData: coverData,
      );

      IrisHaptics.actionHeavy();
      if (!mounted) return;
      showIrisFrostedSnackBar(context, content: Text('Native Word Document exported: $fileName'));
      await OpenFilex.open(file.path);
    } else if (format.contains('.txt')) {
      final fileName = '${safeTitle}_$timestamp.txt';
      final file = File('${dir.path}/$fileName');
      await file.writeAsString(docText);
      IrisHaptics.actionHeavy();
      if (!mounted) return;
      showIrisFrostedSnackBar(context, content: Text('Plain Text exported: $fileName'));
      await OpenFilex.open(file.path);
    } else {
      await _exportDocument();
    }
  }

  void _smartAIAutoFormatDocument() {
    String text = _editorController.text.trim();
    if (text.isEmpty) {
      showIrisFrostedSnackBar(context, content: const Text('Type some content first to auto-format.'));
      return;
    }

    final lines = text.split('\n');
    final formattedLines = <String>[];
    int sectionCounter = 1;

    for (var line in lines) {
      final trimmed = line.trim();
      if (trimmed.isEmpty) {
        formattedLines.add('');
        continue;
      }

      if (!trimmed.startsWith('#') && (trimmed.toLowerCase().startsWith('intro') || trimmed.toLowerCase().startsWith('problem') || trimmed.toLowerCase().startsWith('result') || trimmed.toLowerCase().startsWith('conclusion') || trimmed.endsWith(':'))) {
        final cleanTitle = trimmed.replaceAll(RegExp(r'^[0-9]+\.|\:'), '').trim();
        formattedLines.add('\n# $sectionCounter. $cleanTitle');
        sectionCounter++;
      } else if (trimmed.startsWith('* ') || trimmed.startsWith('- ') || trimmed.startsWith('+ ')) {
        formattedLines.add('- ${trimmed.substring(2).trim()}');
      } else {
        formattedLines.add(line);
      }
    }

    _editorController.text = formattedLines.join('\n');
    _saveDraftDocument();
    IrisHaptics.actionHeavy();
    showIrisFrostedSnackBar(context, content: const Text('🪄 Smart AI Auto-Format Applied!'));
  }

  void _addFloatingBlock(String type, String defaultText) {
    final block = StudioBlock(
      id: 'block_${DateTime.now().millisecondsSinceEpoch}',
      type: type,
      initialContent: defaultText,
    );
    setState(() {
      _floatingBlocks.add(block);
    });
    IrisHaptics.actionSoft();
    _saveDraftDocument();
  }

  void _removeFloatingBlock(String id) {
    setState(() {
      _floatingBlocks.removeWhere((b) => b.id == id);
    });
    IrisHaptics.actionSoft();
    _saveDraftDocument();
  }

  Future<void> _generate1TapCoverPagePdf() async {
    IrisHaptics.actionHeavy();
    try {
      final coverData = await CoverPageData.resolveDefaults(
        course: _courseController.text,
        title: _titleController.text,
        teacher: _authorController.text.isNotEmpty ? 'Dr. Wasim' : null,
        type: _docType,
      );

      final pdfFile = await CoverPageGenerator.generateOfficialCoverPdf(coverData);
      
      if (!mounted) return;
      showIrisFrostedSnackBar(
        context,
        content: Text('⚡ Official Cover Page Generated: ${pdfFile.path.split('/').last}'),
      );
      
      await OpenFilex.open(pdfFile.path);
    } catch (e) {
      debugPrint('Cover Page PDF Error: $e');
      if (!mounted) return;
      showIrisFrostedSnackBar(context, content: Text('Generation failed: $e'));
    }
  }

  Future<void> _showCustomizeFieldsSheet() async {
    if (_customCoverFields.isEmpty) {
      final coverData = await CoverPageData.resolveDefaults(
        course: _courseController.text,
        title: _titleController.text,
        teacher: _authorController.text,
        type: _docType,
      );

      _customCoverFields = [
        CoverPageField('Student Name', _authorController.text.isNotEmpty ? _authorController.text : coverData.studentName),
        CoverPageField('Registration ID', _regIdController.text.isNotEmpty ? _regIdController.text : coverData.registrationId),
        CoverPageField('Program & Batch', coverData.batch),
        CoverPageField('Submitted To', coverData.instructorName),
        CoverPageField('Submission Date', coverData.submissionDate),
      ];
    }

    final fields = List<CoverPageField>.from(_customCoverFields);

    if (!mounted) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            final isDark = Theme.of(context).brightness == Brightness.dark;
            final isM3 = ThemeSignals.isMaterialYou;
            Widget sheetBody = Container(
              height: MediaQuery.sizeOf(context).height * 0.85,
              decoration: BoxDecoration(
                color: isM3
                    ? Theme.of(context).colorScheme.surfaceContainerHigh
                    : (isDark ? IrisTokens.surfaceDark : IrisTokens.surfaceLight),
                borderRadius: BorderRadius.vertical(top: Radius.circular(isM3 ? 28 : 24)),
              ),
              padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.viewInsetsOf(context).bottom + 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.tune_rounded, color: IrisTokens.brand),
                      const SizedBox(width: 10),
                      const Text(
                        'Customize Cover Page Fields',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const Spacer(),
                      IconButton(
                        icon: const Icon(Icons.close_rounded),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Add, edit, or remove fields for your official cover sheet table.',
                    style: TextStyle(fontSize: 12, color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.6)),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    'DEPARTMENT / FACULTY HEADER',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      color: (isDark ? Colors.white54 : Colors.black54),
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 6),
                  TextFormField(
                    controller: _deptController,
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: isDark ? Colors.white : Colors.black87),
                    decoration: InputDecoration(
                      hintText: 'e.g. Department of Computer Science',
                      isDense: true,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Expanded(
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      itemCount: fields.length,
                      itemBuilder: (context, idx) {
                        final item = fields[idx];
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Row(
                            children: [
                              Expanded(
                                flex: 4,
                                child: TextFormField(
                                  initialValue: item.label,
                                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: isDark ? Colors.white : Colors.black87),
                                  decoration: InputDecoration(
                                    labelText: 'Field Label',
                                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                                  ),
                                  onChanged: (val) => item.label = val,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                flex: 5,
                                child: TextFormField(
                                  initialValue: item.value,
                                  style: TextStyle(fontSize: 13, color: isDark ? Colors.white : Colors.black87),
                                  decoration: InputDecoration(
                                    labelText: 'Field Value',
                                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                                  ),
                                  onChanged: (val) => item.value = val,
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent, size: 20),
                                onPressed: () {
                                  setSheetState(() {
                                    fields.removeAt(idx);
                                  });
                                  IrisHaptics.actionSoft();
                                },
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      OutlinedButton.icon(
                        onPressed: () {
                          setSheetState(() {
                            fields.add(CoverPageField('Custom Field', 'Value'));
                          });
                          IrisHaptics.actionSoft();
                        },
                        icon: const Icon(Icons.add_rounded, size: 18),
                        label: const Text('Add Field'),
                        style: OutlinedButton.styleFrom(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                      const Spacer(),
                      ElevatedButton.icon(
                        onPressed: () {
                          setState(() {
                            _customCoverFields = List.from(fields);
                            for (final f in fields) {
                              final label = f.label.toLowerCase();
                              if (label.contains('student') || label.contains('name') || label.contains('author')) {
                                _authorController.text = f.value;
                              } else if (label.contains('registration') || label.contains('id') || label.contains('roll')) {
                                _regIdController.text = f.value;
                              } else if (label.contains('course')) {
                                _courseController.text = f.value;
                              } else if (label.contains('title')) {
                                _titleController.text = f.value;
                              }
                            }
                          });
                          _saveDraftDocument();
                          Navigator.pop(context);
                          showIrisFrostedSnackBar(
                            context,
                            content: const Text('💾 Cover Page Fields Saved & Applied!'),
                          );
                        },
                        icon: const Icon(Icons.save_rounded, size: 18),
                        label: const Text('Save & Apply', style: TextStyle(fontWeight: FontWeight.bold)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: IrisTokens.brand,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );

            if (ThemeSignals.isFluidGlass) {
              sheetBody = ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                child: GlassSurface(
                  settings: IrisGlass.settings(context, blur: 16.0, thickness: 14.0),
                  radius: 24,
                  child: sheetBody,
                ),
              );
            }

            return sheetBody;
          },
        );
      },
    );
  }

  Future<void> _closeDocument() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Close Document?'),
        content: const Text('Save your current draft before closing. Unsaved session edits will be kept in offline storage.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          IrisLiquidButton(
            onTap: () => Navigator.pop(ctx, true),
            text: 'Confirm',
          ),
        ],
      ),
    );

    if (confirm == true) {
      setState(() {
        _hasActiveDocument = false;
      });
      _saveDraftDocument();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: irisFrostedAppBar(
        title: 'Document Workspace',
        isDark: isDark,
      ),
      body: Stack(
        children: [
          ObsidianPulse(isDark: isDark),
          SafeArea(
            child: Align(
              alignment: Alignment.topCenter,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 840),
                child: Column(
                  children: [
                // Custom Sliding Tab Segment
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.black.withValues(alpha: 0.03),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: (isDark ? Colors.white10 : Colors.black12)),
                    ),
                    child: TabBar(
                      controller: _tabController,
                      indicator: BoxDecoration(
                        color: isDark ? const Color(0xFF1E293B) : Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.05),
                            blurRadius: 4,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      labelColor: isDark ? Colors.white : Colors.black87,
                      unselectedLabelColor: isDark ? Colors.white38 : Colors.black45,
                      labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                      indicatorSize: TabBarIndicatorSize.tab,
                      dividerColor: Colors.transparent,
                      tabs: const [
                        Tab(text: 'Doc Maker'),
                        Tab(text: 'Converter'),
                        Tab(text: 'Splitter'),
                      ],
                    ),
                  ),
                ),
                
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    physics: const NeverScrollableScrollPhysics(),
                    children: [
                      // Tab 1: Document Maker
                      _buildDocMakerTab(isDark),
                      // Tab 2: Converter
                      DocumentConverterView(isDark: isDark),
                      // Tab 3: Splitter
                      DocumentSplitterView(isDark: isDark),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
        ],
      ),
    );
  }

  Widget _buildDocMakerTab(bool isDark) {
    if (!_hasActiveDocument) {
      return _buildCreationWizard(isDark);
    }
    return _buildDocumentEditor(isDark);
  }
  Widget _buildInputField(String label, TextEditingController controller, String hint, bool isDark) {
    final isM3 = ThemeSignals.isMaterialYou;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label.toUpperCase(),
          style: TextStyle(
            fontSize: 9.5,
            fontWeight: FontWeight.w900,
            color: (isDark ? Colors.white54 : Colors.black54),
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(
            color: isM3
                ? (isDark ? MaterialYouTokens.surfaceContainerHighDark : MaterialYouTokens.surfaceContainerHighLight)
                : (isDark ? Colors.white.withValues(alpha: 0.03) : Colors.white),
            borderRadius: BorderRadius.circular(isM3 ? 18 : 14),
            border: Border.all(
              color: isM3
                  ? (isDark ? MaterialYouTokens.outlineVariantDark : MaterialYouTokens.outlineVariantLight)
                  : (isDark ? Colors.white10 : Colors.black12),
            ),
          ),
          child: TextField(
            controller: controller,
            style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: isDark ? Colors.white : Colors.black87),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: Colors.grey, fontSize: 12),
              isDense: true,
              filled: false,
              fillColor: Colors.transparent,
              contentPadding: const EdgeInsets.symmetric(vertical: 12),
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTypeCard(String value, IconData icon, Color color, bool isDark) {
    final isSelected = _docType == value;
    final isM3 = ThemeSignals.isMaterialYou;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() => _docType = value);
          IrisHaptics.chipSelect();
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
          decoration: BoxDecoration(
            color: isSelected
                ? color.withValues(alpha: isDark ? 0.20 : 0.12)
                : (isM3
                    ? (isDark ? MaterialYouTokens.surfaceContainerHighDark : MaterialYouTokens.surfaceContainerHighLight)
                    : (isDark ? Colors.white.withValues(alpha: 0.02) : Colors.white)),
            borderRadius: BorderRadius.circular(isM3 ? 20 : 18),
            border: Border.all(
              color: isSelected
                  ? color
                  : (isM3
                      ? (isDark ? MaterialYouTokens.outlineVariantDark : MaterialYouTokens.outlineVariantLight)
                      : (isDark ? Colors.white10 : Colors.black12)),
              width: isSelected ? 1.5 : 1.0,
            ),
          ),
          child: Column(
            children: [
              Icon(icon, color: isSelected ? color : (isDark ? Colors.white54 : Colors.black54), size: 26),
              const SizedBox(height: 10),
              FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  value,
                  maxLines: 1,
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w900,
                    color: isSelected ? color : (isDark ? Colors.white70 : Colors.black87),
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCreationWizard(bool isDark) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header Introduction
          Text(
            'Academic Document Templates',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w900,
              color: isDark ? Colors.white : Colors.black87,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Select document format layout type to instantly scaffold your coursework.',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              color: (isDark ? Colors.white54 : Colors.black54),
            ),
          ),
          const SizedBox(height: 20),

          // Template Type Select Grid
          Row(
            children: [
              _buildTypeCard('Assignment', Icons.assignment_turned_in_rounded, IrisTokens.brand, isDark),
              const SizedBox(width: 8),
              _buildTypeCard('Quiz Prep', Icons.quiz_rounded, IrisTokens.warning, isDark),
              const SizedBox(width: 8),
              _buildTypeCard('Project Report', Icons.assessment_rounded, IrisTokens.success, isDark),
            ],
          ),
          const SizedBox(height: 24),

          // Configuration Inputs
          _buildInputField('Course Title', _courseController, 'e.g. Object Oriented Programming', isDark),
          const SizedBox(height: 14),
          _buildInputField('Document Subtitle / Title', _titleController, 'e.g. Assignment 3 or Final Report', isDark),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _buildInputField('Student Name', _authorController, 'Your Full Name', isDark),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildInputField('Registration ID', _regIdController, 'e.g. FA22-BCS-089', isDark),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: () => _smartAutofillIdentity(showFeedback: true),
              icon: const Icon(Icons.bolt_rounded, size: 14, color: IrisTokens.brand),
              label: const Text(
                'Auto-Fill Saved Roll & Name',
                style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: IrisTokens.brand),
              ),
            ),
          ),
          const SizedBox(height: 14),

          // Include Cover Page Toggle Switch Card
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.black.withValues(alpha: 0.04),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: IrisTokens.brand.withValues(alpha: 0.3)),
            ),
            child: Row(
              children: [
                const Icon(Icons.picture_as_pdf_rounded, color: IrisTokens.brand, size: 22),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Include Official Cover Title Page',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                      ),
                      SizedBox(height: 2),
                      Text(
                        'Auto-prefills COMSATS logo & student details as Page 1',
                        style: TextStyle(fontSize: 11, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
                IrisGlassSwitch(
                  value: _includeCoverPage,
                  activeColor: IrisTokens.brand,
                  onChanged: (val) {
                    setState(() => _includeCoverPage = val);
                    IrisHaptics.chipSelect();
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Action Triggers
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 54,
                  child: ElevatedButton.icon(
                    onPressed: _generate1TapCoverPagePdf,
                    icon: const Icon(Icons.picture_as_pdf_rounded, size: 20),
                    label: const FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        '⚡ 1-Tap Cover Page PDF',
                        maxLines: 1,
                        style: TextStyle(fontWeight: FontWeight.w900, fontSize: 13.5),
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: IrisTokens.brand,
                      foregroundColor: Colors.white,
                      elevation: 4,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              SizedBox(
                height: 54,
                child: OutlinedButton(
                  onPressed: _showCustomizeFieldsSheet,
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    side: const BorderSide(color: IrisTokens.brand, width: 1.2),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.tune_rounded, size: 18, color: IrisTokens.brand),
                      SizedBox(width: 4),
                      Text('Fields', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: IrisTokens.brand)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: OutlinedButton.icon(
              onPressed: _initializeTemplate,
              icon: const Icon(Icons.description_rounded, size: 18),
              label: const Text('Generate Full Document Workspace', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5)),
              style: OutlinedButton.styleFrom(
                foregroundColor: isDark ? Colors.white70 : Colors.black87,
                side: BorderSide(color: isDark ? Colors.white24 : Colors.black26),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRibbonTab(String title, int index) {
    final isSelected = _ribbonTabIndex == index;
    return GestureDetector(
      onTap: () {
        setState(() => _ribbonTabIndex = index);
        IrisHaptics.chipSelect();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: isSelected ? Colors.white : Colors.transparent,
              width: 2.5,
            ),
          ),
        ),
        child: Text(
          title,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white70,
            fontSize: 11,
            fontWeight: isSelected ? FontWeight.w900 : FontWeight.w600,
          ),
        ),
      ),
    );
  }

  Widget _buildRibbonBtn(String label, IconData icon, VoidCallback onTap, {bool active = false}) {
    return Padding(
      padding: const EdgeInsets.only(right: 6),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(6),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: active ? IrisTokens.brand.withValues(alpha: 0.15) : Colors.transparent,
            borderRadius: BorderRadius.circular(6),
            border: Border.all(
              color: active ? IrisTokens.brand : Colors.transparent,
            ),
          ),
          child: Row(
            children: [
              Icon(icon, size: 15, color: active ? IrisTokens.brand : null),
              const SizedBox(width: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: active ? FontWeight.bold : FontWeight.w600,
                  color: active ? IrisTokens.brand : null,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _insertEditorText(String snippet) {
    final text = _editorController.text;
    final selection = _editorController.selection;
    if (selection.start >= 0 && selection.end >= 0) {
      final newText = text.replaceRange(selection.start, selection.end, snippet);
      _editorController.text = newText;
      _editorController.selection = TextSelection.collapsed(offset: selection.start + snippet.length);
    } else {
      _editorController.text = text + snippet;
    }
    _saveDraftDocument();
    IrisHaptics.actionSoft();
  }

  Widget _buildDocumentEditor(bool isDark) {
    Color paperBg = Colors.white;
    Color paperText = Colors.black87;
    if (_paperColorMode == 'Sepia') {
      paperBg = const Color(0xFFFDF6E3);
      paperText = const Color(0xFF433422);
    } else if (_paperColorMode == 'Dark') {
      paperBg = const Color(0xFF0F172A);
      paperText = const Color(0xFFF8FAFC);
    }

    return Column(
      children: [
        // 1. MS Word Title & Ribbon Header Container
        Container(
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF1E293B) : const Color(0xFF2B579A), // Official Word Blue Accent
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.15),
                blurRadius: 6,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            children: [
              // Top Title Bar
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 8, 14, 4),
                child: Row(
                  children: [
                    const Icon(Icons.description_rounded, color: Colors.white, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '${_titleController.text.isNotEmpty ? _titleController.text : "Document 1"} - MS Word Studio',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    IrisGlassMenu(
                      menuAlignment: lgw.GlassMenuAlignment.bottomRight,
                      menuWidth: 240,
                      triggerBuilder: (context, toggleMenu) {
                        return InkWell(
                          onTap: _isExporting ? null : toggleMenu,
                          borderRadius: BorderRadius.circular(20),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                            decoration: BoxDecoration(
                              color: _exportSuccess ? Colors.green : IrisTokens.brand,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (_isExporting) ...[
                                  const SizedBox(
                                    width: 12,
                                    height: 12,
                                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                  ),
                                  const SizedBox(width: 6),
                                  Text('${(_exportProgress * 100).toInt()}%', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white)),
                                ] else ...[
                                  const Icon(Icons.file_download_rounded, size: 14, color: Colors.white),
                                  const SizedBox(width: 4),
                                  const Text('Export', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white)),
                                  const SizedBox(width: 2),
                                  const Icon(Icons.arrow_drop_down_rounded, size: 16, color: Colors.white),
                                ],
                              ],
                            ),
                          ),
                        );
                      },
                      items: [
                        lgw.GlassMenuItem(
                          title: 'PDF Document (.pdf)',
                          icon: const Icon(Icons.picture_as_pdf_rounded, color: Colors.redAccent, size: 20),
                          onTap: () => _exportDocumentWithFormat('PDF (.pdf)'),
                        ),
                        lgw.GlassMenuItem(
                          title: 'Word Document (.docx)',
                          icon: const Icon(Icons.description_rounded, color: Color(0xFF2B579A), size: 20),
                          onTap: () => _exportDocumentWithFormat('Word (.docx)'),
                        ),
                        lgw.GlassMenuItem(
                          title: 'Plain Text (.txt)',
                          icon: const Icon(Icons.article_rounded, color: Colors.grey, size: 20),
                          onTap: () => _exportDocumentWithFormat('Text (.txt)'),
                        ),
                      ],
                    ),
                    IconButton(
                      onPressed: _closeDocument,
                      icon: const Icon(Icons.close_rounded, color: Colors.white, size: 18),
                      tooltip: 'Close Studio',
                    ),
                  ],
                ),
              ),

              // Ribbon Tab Bar (HOME, INSERT, LAYOUT)
              Container(
                color: isDark ? const Color(0xFF0F172A) : const Color(0xFF1F4478),
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  children: [
                    _buildRibbonTab('HOME', 0),
                    _buildRibbonTab('INSERT', 1),
                    _buildRibbonTab('LAYOUT', 2),
                  ],
                ),
              ),

              // Ribbon Tools Sub-Bar
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF1F5F9),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      if (_ribbonTabIndex == 0) ...[
                        // HOME TAB TOOLS
                        _buildRibbonBtn('AI Format', Icons.auto_awesome_rounded, _smartAIAutoFormatDocument, active: true),
                        _buildRibbonBtn('AI Outline', Icons.schema_rounded, _generateAIOutline, active: true),
                        _buildRibbonBtn('Bold', Icons.format_bold_rounded, () => _applyFormatToSelection('**', '**', 'Bold Text')),
                        _buildRibbonBtn('Italic', Icons.format_italic_rounded, () => _applyFormatToSelection('*', '*', 'Italic Text')),
                        _buildRibbonBtn('H1', Icons.title_rounded, () => _applyFormatToSelection('# ', '\n', 'Section Title')),
                        _buildRibbonBtn('H2', Icons.text_fields_rounded, () => _applyFormatToSelection('## ', '\n', 'Subsection Title')),
                        _buildRibbonBtn('Bullets', Icons.format_list_bulleted_rounded, () => _insertEditorText('- Bullet point\n')),
                        _buildRibbonBtn('Numbers', Icons.format_list_numbered_rounded, () => _insertEditorText('1. Numbered item\n')),
                        _buildRibbonBtn('Code', Icons.code_rounded, () => _insertEditorText('```\n// Code snippet\n```\n')),
                      ] else if (_ribbonTabIndex == 1) ...[
                        // INSERT TAB TOOLS
                        _buildRibbonBtn('Cover Page', Icons.picture_as_pdf_rounded, () {
                          setState(() => _includeCoverPage = !_includeCoverPage);
                          IrisHaptics.chipSelect();
                        }, active: _includeCoverPage),
                        _buildRibbonBtn('Customize Cover', Icons.tune_rounded, _showCustomizeFieldsSheet, active: true),
                        _buildRibbonBtn('+ Text Box', Icons.text_fields_rounded, () => _addFloatingBlock('text', 'Write custom note or callout here...')),
                        _buildRibbonBtn('+ Bullets', Icons.format_list_bulleted_rounded, () => _addFloatingBlock('bullet', '- Custom point 1\n- Custom point 2')),
                        _buildRibbonBtn('+ Formula', Icons.functions_rounded, () => _addFloatingBlock('formula', r'\[ E = mc^2 \]')),
                        _buildRibbonBtn('+ Note Box', Icons.warning_amber_rounded, () => _addFloatingBlock('note', 'Note for Instructor / Grader: See Attached Diagram.')),
                        _buildRibbonBtn('Attach Image', Icons.add_photo_alternate_rounded, _attachImage),
                        _buildRibbonBtn('Table Grid', Icons.grid_on_rounded, () => _insertEditorText('| Header 1 | Header 2 |\n| --- | --- |\n| Data 1 | Data 2 |\n')),
                        _buildRibbonBtn('Rule Line', Icons.horizontal_rule_rounded, () => _insertEditorText('\n---\n')),
                        _buildRibbonBtn('Date Stamp', Icons.today_rounded, () => _insertEditorText(DateTime.now().toString().substring(0, 10))),
                      ] else if (_ribbonTabIndex == 2) ...[
                        // LAYOUT TAB TOOLS
                        _buildRibbonBtn('White Paper', Icons.description_outlined, () {
                          setState(() => _paperColorMode = 'White');
                          IrisHaptics.chipSelect();
                        }, active: _paperColorMode == 'White'),
                        _buildRibbonBtn('Cream Sepia', Icons.menu_book_rounded, () {
                          setState(() => _paperColorMode = 'Sepia');
                          IrisHaptics.chipSelect();
                        }, active: _paperColorMode == 'Sepia'),
                        _buildRibbonBtn('Dark Slate', Icons.dark_mode_rounded, () {
                          setState(() => _paperColorMode = 'Dark');
                          IrisHaptics.chipSelect();
                        }, active: _paperColorMode == 'Dark'),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),

        // 2. Realistic MS Word A4 Canvas Paper View
        Expanded(
          child: Container(
            color: isDark ? const Color(0xFF0F172A) : const Color(0xFFE2E8F0), // Desk surface background
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
              physics: _isDraggingImage ? const NeverScrollableScrollPhysics() : const BouncingScrollPhysics(),
              child: Column(
                children: [
                  // A4 Ruler Header Line
                  Container(
                    constraints: const BoxConstraints(maxWidth: 540),
                    margin: const EdgeInsets.only(bottom: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('▲ 0.5" Margin', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: isDark ? Colors.white38 : Colors.black38)),
                        Text('A4 (210 × 297 mm)', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: isDark ? Colors.white38 : Colors.black38)),
                        Text('0.5" Margin ▲', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: isDark ? Colors.white38 : Colors.black38)),
                      ],
                    ),
                  ),

                  // A4 Paper Sheet Card with Freeform Draggable Overlay Stack
                  Center(
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        // Main A4 Paper Card
                        Container(
                          width: double.infinity,
                          constraints: const BoxConstraints(maxWidth: 540, minHeight: 650),
                          decoration: BoxDecoration(
                            color: paperBg,
                            borderRadius: BorderRadius.circular(4),
                            border: Border.all(
                              color: isDark ? Colors.white.withValues(alpha: 0.15) : Colors.black.withValues(alpha: 0.15),
                              width: 1.0,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.2),
                                blurRadius: 18,
                                offset: const Offset(0, 10),
                              ),
                            ],
                          ),
                          padding: const EdgeInsets.all(28),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Page Header Banner Badge
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF2B579A).withValues(alpha: 0.12),
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                    child: Text(
                                      _includeCoverPage ? 'PAGE 1 OF 2 • COVER & CONTENT' : 'PAGE 1 OF 1 • DOCUMENT BODY',
                                      style: const TextStyle(fontSize: 8.5, fontWeight: FontWeight.w900, color: Color(0xFF2B579A)),
                                    ),
                                  ),
                                  const Spacer(),
                                  const Icon(Icons.print_rounded, size: 14, color: Colors.grey),
                                ],
                              ),
                              const SizedBox(height: 16),

                              // Render Official COMSATS Sahiwal Campus Cover Page Preview if enabled
                              if (_includeCoverPage) ...[
                                Container(
                                  padding: const EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                    color: paperBg == Colors.white ? const Color(0xFFF8FAFC) : paperBg,
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(color: Colors.grey.withValues(alpha: 0.3), width: 1.0),
                                  ),
                                  child: Column(
                                    children: [
                                      Image.asset(
                                        'assets/comsats_logo.png',
                                        width: 52,
                                        height: 52,
                                        cacheWidth: 156,
                                        cacheHeight: 156,
                                        errorBuilder: (_, _, _) => const Icon(Icons.school_rounded, color: Color(0xFF2B579A), size: 44),
                                      ),
                                      const SizedBox(height: 8),
                                      const Text(
                                        'COMSATS UNIVERSITY ISLAMABAD',
                                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: Color(0xFF0F172A)),
                                        textAlign: TextAlign.center,
                                      ),
                                      const Text(
                                        'SAHIWAL CAMPUS',
                                        style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Color(0xFF1D4ED8)),
                                        textAlign: TextAlign.center,
                                      ),
                                      Text(
                                        _deptController.text.isNotEmpty ? _deptController.text.toUpperCase() : 'DEPARTMENT OF COMPUTER SCIENCE',
                                        style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700, color: paperText.withValues(alpha: 0.8)),
                                        textAlign: TextAlign.center,
                                      ),
                                      const Divider(height: 18),
                                      Text(
                                        _docType.toUpperCase(),
                                        style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Color(0xFF1D4ED8)),
                                        textAlign: TextAlign.center,
                                      ),
                                      if (_titleController.text.isNotEmpty) ...[
                                        const SizedBox(height: 4),
                                        Text(
                                          _titleController.text,
                                          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: paperText),
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                      if (_courseController.text.isNotEmpty) ...[
                                        const SizedBox(height: 4),
                                        Text(
                                          'COURSE: ${_courseController.text.toUpperCase()}',
                                          style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: paperText.withValues(alpha: 0.9)),
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                      const SizedBox(height: 12),
                                      // 1-to-1 Custom Cover Fields Table Grid
                                      if (_customCoverFields.isNotEmpty) ...[
                                        Container(
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(4),
                                            border: Border.all(color: Colors.grey.withValues(alpha: 0.3)),
                                          ),
                                          child: Column(
                                            children: _customCoverFields.map((field) {
                                              return Container(
                                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                                decoration: BoxDecoration(
                                                  border: Border(bottom: BorderSide(color: Colors.grey.withValues(alpha: 0.15))),
                                                ),
                                                child: Row(
                                                  children: [
                                                    Expanded(
                                                      flex: 4,
                                                      child: Text(
                                                        field.label,
                                                        style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.bold, color: paperText),
                                                      ),
                                                    ),
                                                    Expanded(
                                                      flex: 6,
                                                      child: Text(
                                                        field.value,
                                                        style: TextStyle(fontSize: 9.5, color: paperText.withValues(alpha: 0.85)),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              );
                                            }).toList(),
                                          ),
                                        ),
                                      ],
                                      const SizedBox(height: 10),
                                      Align(
                                        alignment: Alignment.centerRight,
                                        child: InkWell(
                                          onTap: _showCustomizeFieldsSheet,
                                          borderRadius: BorderRadius.circular(6),
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                            decoration: BoxDecoration(
                                              color: const Color(0xFF2B579A).withValues(alpha: 0.1),
                                              borderRadius: BorderRadius.circular(6),
                                            ),
                                            child: const Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Icon(Icons.tune_rounded, size: 12, color: Color(0xFF2B579A)),
                                                SizedBox(width: 4),
                                                Text('Edit Department & Fields', style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.bold, color: Color(0xFF2B579A))),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                              
                              // Main WYSIWYG Document Editor Text Field
                              TextField(
                                controller: _editorController,
                                maxLines: null,
                                keyboardType: TextInputType.multiline,
                                style: TextStyle(fontSize: 14, height: 1.6, color: paperText),
                                decoration: InputDecoration(
                                  hintText: 'Type your document body here...\n\n# 1. Introduction\nWrite assignment definitions and notes...\n\n# 2. Results\nAttach screenshots below...',
                                  hintStyle: TextStyle(color: paperText.withValues(alpha: 0.4)),
                                  border: InputBorder.none,
                                ),
                                onChanged: (_) => _saveDraftDocument(),
                              ),

                              // Freeform Floating Blocks Canvas
                              if (_floatingBlocks.isNotEmpty) ...[
                                const SizedBox(height: 16),
                                const Divider(),
                                const SizedBox(height: 8),
                                Column(
                                  children: _floatingBlocks.map((block) {
                                    final isNote = block.type == 'note';
                                    final isFormula = block.type == 'formula';
                                    return Container(
                                      margin: const EdgeInsets.only(bottom: 12),
                                      padding: const EdgeInsets.all(12),
                                      decoration: BoxDecoration(
                                        color: isNote
                                            ? const Color(0xFFFEF3C7)
                                            : (isFormula ? const Color(0xFFEFF6FF) : paperBg),
                                        borderRadius: BorderRadius.circular(8),
                                        border: Border.all(
                                          color: isNote
                                              ? const Color(0xFFF59E0B)
                                              : (isFormula ? const Color(0xFF3B82F6) : paperText.withValues(alpha: 0.2)),
                                        ),
                                      ),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              Icon(
                                                isNote
                                                    ? Icons.warning_amber_rounded
                                                    : (isFormula ? Icons.functions_rounded : Icons.post_add_rounded),
                                                size: 14,
                                                color: isNote ? const Color(0xFFD97706) : Colors.blue,
                                              ),
                                              const SizedBox(width: 6),
                                              Text(
                                                block.type.toUpperCase(),
                                                style: TextStyle(
                                                  fontSize: 9,
                                                  fontWeight: FontWeight.bold,
                                                  color: isNote ? const Color(0xFFD97706) : Colors.blue,
                                                ),
                                              ),
                                              const Spacer(),
                                              GestureDetector(
                                                onTap: () => _removeFloatingBlock(block.id),
                                                child: const Icon(Icons.close_rounded, size: 14, color: Colors.grey),
                                              ),
                                            ],
                                          ),
                                          const SizedBox(height: 6),
                                          TextField(
                                            controller: block.controller,
                                            maxLines: null,
                                            style: TextStyle(
                                              fontSize: 13,
                                              color: isNote ? const Color(0xFF78350F) : paperText,
                                            ),
                                            decoration: const InputDecoration(
                                              border: InputBorder.none,
                                              isDense: true,
                                            ),
                                            onChanged: (_) => _saveDraftDocument(),
                                          ),
                                        ],
                                      ),
                                    );
                                  }).toList(),
                                ),
                              ],
                            ],
                          ),
                        ),

                        // MS Word Style Interactive Draggable & Resizable Image Layer
                        ..._attachedImages.map((image) {
                          final path = image.file.path;
                          return Positioned(
                            left: image.offset.dx,
                            top: image.offset.dy,
                            child: Listener(
                              onPointerDown: (_) {
                                if (!_isDraggingImage) {
                                  setState(() => _isDraggingImage = true);
                                }
                              },
                              onPointerUp: (_) {
                                if (_isDraggingImage) {
                                  setState(() => _isDraggingImage = false);
                                }
                              },
                              onPointerCancel: (_) {
                                if (_isDraggingImage) {
                                  setState(() => _isDraggingImage = false);
                                }
                              },
                              onPointerMove: (event) {
                                setState(() {
                                  _isDraggingImage = true;
                                  image.offset = Offset(
                                    math.max(0.0, image.offset.dx + event.delta.dx),
                                    math.max(0.0, image.offset.dy + event.delta.dy),
                                  );
                                });
                                _saveDraftDocument();
                              },
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // MS Word Style Quick Action Toolbar above Image
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                                    margin: const EdgeInsets.only(bottom: 4),
                                    decoration: BoxDecoration(
                                      color: const Color(0xEE1E293B),
                                      borderRadius: BorderRadius.circular(8),
                                      boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 6, offset: Offset(0, 2))],
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        // Drag Handle
                                        const Padding(
                                          padding: EdgeInsets.symmetric(horizontal: 2),
                                          child: Icon(Icons.drag_indicator_rounded, size: 14, color: Colors.white),
                                        ),
                                        const SizedBox(width: 4),
                                        // Insert In-Line with Text Button
                                        GestureDetector(
                                          onTap: () {
                                            final imageName = image.file.name;
                                            final tag = '\n\n![Image Attachment: $imageName](${image.file.path ?? "Asset"})\n\n';
                                            final pos = _editorController.selection.baseOffset;
                                            if (pos >= 0 && pos <= _editorController.text.length) {
                                              final txt = _editorController.text;
                                              _editorController.text = txt.substring(0, pos) + tag + txt.substring(pos);
                                            } else {
                                              _editorController.text += tag;
                                            }
                                            IrisHaptics.actionSoft();
                                            _saveDraftDocument();
                                            showIrisFrostedSnackBar(context, content: const Text('📌 Image placed in-line within text stream!'));
                                          },
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                            decoration: BoxDecoration(
                                              color: const Color(0xFF2B579A),
                                              borderRadius: BorderRadius.circular(4),
                                            ),
                                            child: const Row(
                                              children: [
                                                Icon(Icons.notes_rounded, size: 10, color: Colors.white),
                                                SizedBox(width: 3),
                                                Text('In-Line Text', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.white)),
                                              ],
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 4),
                                        // Align Left
                                        GestureDetector(
                                          onTap: () {
                                            setState(() => image.offset = Offset(20, image.offset.dy));
                                            IrisHaptics.actionSoft();
                                          },
                                          child: const Padding(
                                            padding: EdgeInsets.symmetric(horizontal: 3),
                                            child: Icon(Icons.format_align_left_rounded, size: 13, color: Colors.white),
                                          ),
                                        ),
                                        // Align Center
                                        GestureDetector(
                                          onTap: () {
                                            setState(() => image.offset = Offset(160, image.offset.dy));
                                            IrisHaptics.actionSoft();
                                          },
                                          child: const Padding(
                                            padding: EdgeInsets.symmetric(horizontal: 3),
                                            child: Icon(Icons.format_align_center_rounded, size: 13, color: Colors.white),
                                          ),
                                        ),
                                        // Align Right
                                        GestureDetector(
                                          onTap: () {
                                            setState(() => image.offset = Offset(280, image.offset.dy));
                                            IrisHaptics.actionSoft();
                                          },
                                          child: const Padding(
                                            padding: EdgeInsets.symmetric(horizontal: 3),
                                            child: Icon(Icons.format_align_right_rounded, size: 13, color: Colors.white),
                                          ),
                                        ),
                                        const SizedBox(width: 4),
                                        // Close / Delete
                                        GestureDetector(
                                          onTap: () {
                                            setState(() => _attachedImages.removeWhere((img) => img.id == image.id));
                                            IrisHaptics.actionSoft();
                                            _saveDraftDocument();
                                          },
                                          child: const Icon(Icons.close_rounded, size: 13, color: Colors.redAccent),
                                        ),
                                      ],
                                    ),
                                  ),

                                  // Image Canvas Stack
                                  Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Container(
                                        width: image.width,
                                        height: image.height,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(8),
                                          border: Border.all(color: const Color(0xFF2B579A), width: 2.0),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Colors.black.withValues(alpha: 0.25),
                                              blurRadius: 10,
                                              offset: const Offset(0, 4),
                                            ),
                                          ],
                                        ),
                                        child: ClipRRect(
                                          borderRadius: BorderRadius.circular(6),
                                          child: path != null
                                              ? Image.file(File(path), width: image.width, height: image.height, fit: BoxFit.cover)
                                              : const Icon(Icons.image_rounded),
                                        ),
                                      ),

                                      // Corner Resizers
                                      Positioned(
                                        left: -5,
                                        top: -5,
                                        child: Container(width: 10, height: 10, decoration: const BoxDecoration(color: Color(0xFF2B579A), shape: BoxShape.circle)),
                                      ),
                                      Positioned(
                                        right: -5,
                                        top: -5,
                                        child: Container(width: 10, height: 10, decoration: const BoxDecoration(color: Color(0xFF2B579A), shape: BoxShape.circle)),
                                      ),
                                      Positioned(
                                        left: -5,
                                        bottom: -5,
                                        child: Container(width: 10, height: 10, decoration: const BoxDecoration(color: Color(0xFF2B579A), shape: BoxShape.circle)),
                                      ),
                                      // Bottom Right Active Resizer Handle
                                      Positioned(
                                        right: -10,
                                        bottom: -10,
                                        child: Listener(
                                          onPointerDown: (_) {
                                            if (!_isDraggingImage) {
                                              setState(() => _isDraggingImage = true);
                                            }
                                          },
                                          onPointerUp: (_) {
                                            if (_isDraggingImage) {
                                              setState(() => _isDraggingImage = false);
                                            }
                                          },
                                          onPointerCancel: (_) {
                                            if (_isDraggingImage) {
                                              setState(() => _isDraggingImage = false);
                                            }
                                          },
                                          onPointerMove: (event) {
                                            setState(() {
                                              _isDraggingImage = true;
                                              image.width = math.max(80.0, image.width + event.delta.dx);
                                              image.height = math.max(60.0, image.height + event.delta.dy);
                                            });
                                            _saveDraftDocument();
                                          },
                                          child: Container(
                                            width: 22,
                                            height: 22,
                                            decoration: BoxDecoration(
                                              color: const Color(0xFF2B579A),
                                              shape: BoxShape.circle,
                                              border: Border.all(color: Colors.white, width: 2.0),
                                              boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4)],
                                            ),
                                            child: const Icon(Icons.aspect_ratio_rounded, size: 12, color: Colors.white),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        }),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),

        // 3. Obsidian Studio Document Analytics & Control Console Status Bar
        Builder(
          builder: (_) {
            final text = _editorController.text;
            final charCount = text.length;
            final wordCount = text.trim().isEmpty ? 0 : text.trim().split(RegExp(r'\s+')).length;
            final readTime = (wordCount / 200).ceil();
            final estPages = _includeCoverPage ? (1 + (wordCount / 350).ceil()) : (wordCount / 350).ceil();

            return Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              color: isDark ? const Color(0xFF020617) : const Color(0xFF1E293B),
              child: Row(
                children: [
                  Icon(Icons.notes_rounded, size: 14, color: Colors.white.withValues(alpha: 0.7)),
                  const SizedBox(width: 6),
                  Text(
                    '$wordCount Words  •  $charCount Chars',
                    style: const TextStyle(fontSize: 11, color: Colors.white, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(width: 14),
                  Icon(Icons.timer_outlined, size: 13, color: Colors.white.withValues(alpha: 0.7)),
                  const SizedBox(width: 4),
                  Text(
                    '${readTime < 1 ? 1 : readTime} min read',
                    style: TextStyle(fontSize: 11, color: Colors.white.withValues(alpha: 0.8)),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: IrisTokens.brand.withValues(alpha: 0.3),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      'EST. $estPages A4 ${estPages == 1 ? "PAGE" : "PAGES"}',
                      style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 0.5),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }
}
