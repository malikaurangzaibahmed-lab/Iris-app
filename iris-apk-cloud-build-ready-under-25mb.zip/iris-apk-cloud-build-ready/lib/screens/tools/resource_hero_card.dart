import 'package:flutter/material.dart';
import '../../core/theme_signals.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../../widgets/glass_card.dart';

class ResourceHeroCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final bool isDark;

  const ResourceHeroCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, style, _) {
        if (style == IrisThemeStyle.almanac) {
          final ruleColor = AlmanacTokens.inkRule(isDark);
          final terra = AlmanacTokens.accentTerracotta(isDark);
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            decoration: BoxDecoration(
              color: AlmanacTokens.cardSurface(isDark),
              border: Border(
                top: BorderSide(color: ruleColor, width: 2.0),
                bottom: BorderSide(color: ruleColor, width: 2.0),
                left: BorderSide(color: ruleColor, width: 1.0),
                right: BorderSide(color: ruleColor, width: 1.0),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: terra.withValues(alpha: 0.14),
                    border: Border.all(color: terra, width: 1.2),
                  ),
                  child: Icon(icon, color: terra, size: 22),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'GAZETTE DIRECTORY // CAMPUS UTILITY',
                        style: AlmanacTokens.monoHeader(
                          isDark,
                          fontSize: 9.5,
                          color: terra,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        title,
                        style: AlmanacTokens.serifHeadline(
                          isDark,
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        style: AlmanacTokens.countdownNarrative(isDark).copyWith(
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }

        if (style == IrisThemeStyle.editorialAcademic) {
          final heroBg = EditorialTokens.heroCard(isDark);
          final heroText = EditorialTokens.heroCardText(isDark);
          final heroMuted = EditorialTokens.heroCardMutedText(isDark);
          return Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: heroBg,
              borderRadius: BorderRadius.circular(24),
              boxShadow: EditorialTokens.heroShadow(isDark),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: EditorialTokens.accentUpcoming.withValues(alpha: 0.22),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: EditorialTokens.accentUpcoming.withValues(alpha: 0.5),
                    ),
                  ),
                  child: Icon(
                    icon,
                    color: EditorialTokens.accentUpcoming,
                    size: 26,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: EditorialTokens.headingSerif(
                          isDark,
                          fontSize: 19,
                          fontWeight: FontWeight.w900,
                        ).copyWith(color: heroText),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: EditorialTokens.bodySans(
                          isDark,
                          fontSize: 12.5,
                          color: heroMuted,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }

        if (style == IrisThemeStyle.notebook) {
          return Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                padding: const EdgeInsets.fromLTRB(18, 20, 18, 16),
                decoration: BoxDecoration(
                  color: NotebookTokens.stickyNote(isDark),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: const Color(0xFF1A1F1C).withValues(alpha: 0.28),
                    width: 1.2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.12),
                      offset: const Offset(2, 4),
                      blurRadius: 6,
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.65),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: NotebookTokens.redDoodle(false),
                          width: 1.5,
                        ),
                      ),
                      child: Icon(
                        icon,
                        color: NotebookTokens.redDoodle(false),
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            style: NotebookTokens.boldScript(
                              false,
                              fontSize: 20,
                              color: const Color(0xFF1A1F1C),
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            subtitle,
                            style: NotebookTokens.handwrittenBody(
                              false,
                              fontSize: 13.5,
                              color: const Color(0xFF2C3530),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const Positioned(
                top: -9,
                left: 24,
                child: WashiTapeOverhang(
                  width: 64,
                  height: 18,
                  color: NotebookTokens.tapeCoral,
                  rotation: -0.04,
                ),
              ),
            ],
          );
        }

        if (style == IrisThemeStyle.line) {
          final railColor = LineTokens.railLine(isDark);
          return Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: LineTokens.cardSurface(isDark),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: railColor, width: 2.0),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: isDark ? 0.30 : 0.08),
                  offset: const Offset(0, 4),
                  blurRadius: 8,
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: LineTokens.subwayYellow,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.black, width: 2.2),
                  ),
                  child: Icon(icon, color: Colors.black, size: 22),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'TRANSIT STATION // TERMINAL',
                        style: LineTokens.lineTag(isDark).copyWith(
                          fontSize: 10,
                          color: railColor,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        title.toUpperCase(),
                        style: LineTokens.stationName(isDark).copyWith(
                          fontSize: 19,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        subtitle,
                        style: LineTokens.stationMeta(isDark).copyWith(
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }

        if (style == IrisThemeStyle.poster) {
          return Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: PosterTokens.orangeHero,
              border: Border.all(color: Colors.black, width: 2.5),
              boxShadow: PosterTokens.extrudedBlockShadow(isDark, offset: 5.0),
            ),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.black, width: 2.2),
                  ),
                  child: Icon(icon, color: Colors.black, size: 26),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title.toUpperCase(),
                        style: PosterTokens.heroOrangeTitle(isDark).copyWith(
                          fontSize: 20,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle.toUpperCase(),
                        style: PosterTokens.heroOrangeTag(isDark).copyWith(
                          fontSize: 10.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }

        return GlassCard(
          borderRadius: 32,
          elevation: 2,
          glow: true,
          padding: const EdgeInsets.all(20),
          accentColor: accent,
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: isDark ? 0.25 : 0.15),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Icon(icon, color: accent, size: 28),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.4,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: TextStyle(
                        fontSize: 12,
                        color: (isDark ? Colors.white : Colors.black)
                            .withValues(alpha: 0.6),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
