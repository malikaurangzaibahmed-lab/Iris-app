import 'package:flutter/material.dart';
import '../../core/animations.dart';
import '../../core/vital_theme.dart';
import '../../services/helpdesk_schedule_data_service.dart';
import '../../services/remote_config_service.dart';
import '../../services/ui_feedback.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/iris_components.dart';
import 'resource_hero_card.dart';

class SemesterScheduleScreen extends StatefulWidget {
  final String batch;
  const SemesterScheduleScreen({super.key, required this.batch});

  @override
  State<SemesterScheduleScreen> createState() => _SemesterScheduleScreenState();
}

class _SemesterScheduleScreenState extends State<SemesterScheduleScreen> {
  final HelpdeskScheduleDataService _service = HelpdeskScheduleDataService();
  late Future<CampusSchedulePayload> _payloadFuture;
  String _selectedFilter = 'All';

  static const List<String> _filters = [
    'All',
    'Active & Next',
    'Completed',
    'Deadlines',
  ];

  @override
  void initState() {
    super.initState();
    _payloadFuture = _service.fetchSchedulePayload();
  }

  Future<void> _refresh() async {
    IrisHaptics.refreshStart();
    setState(() {
      _payloadFuture = _service.fetchSchedulePayload();
    });
    await _payloadFuture;
    IrisHaptics.refreshSuccess();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final onSurface = Theme.of(context).colorScheme.onSurface;
    final topInset = MediaQuery.paddingOf(context).top + kToolbarHeight + 12;

    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: irisFrostedAppBar(
        title: 'Academic Calendar',
        isDark: isDark,
        actions: [
          IconButton(
            onPressed: _refresh,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: Stack(
        children: [
          ObsidianPulse(isDark: isDark),
          FutureBuilder<CampusSchedulePayload>(
            future: _payloadFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: IrisComponents.loadingSpinner(size: 28));
              }

              final payload = snapshot.data;
              if (payload == null) {
                return const Center(
                  child: Text('No semester schedule available.'),
                );
              }

              final allMilestones = payload.semesterSchedule;
              final completedCount =
                  allMilestones.where((m) => m.isDone).length;
              final activeCount = allMilestones
                  .where((m) => m.dynamicStatus == 'active')
                  .length;
              final upcomingCount = allMilestones
                  .where((m) => !m.isDone && m.dynamicStatus != 'active')
                  .length;
              final progress = allMilestones.isEmpty
                  ? 0.0
                  : ((completedCount + (activeCount * 0.5)) /
                          allMilestones.length)
                      .clamp(0.0, 1.0);

              final filteredMilestones = allMilestones.where((m) {
                if (_selectedFilter == 'Completed') return m.isDone;
                if (_selectedFilter == 'Active & Next') return !m.isDone;
                if (_selectedFilter == 'Deadlines') return false;
                return true;
              }).toList();

              final showDeadlines = _selectedFilter == 'All' ||
                  _selectedFilter == 'Deadlines' ||
                  _selectedFilter == 'Active & Next';

              return IrisComponents.refreshIndicator(
                onRefresh: _refresh,
                child: ListView(
                  physics: const ButterScrollPhysics(
                    parent: AlwaysScrollableScrollPhysics(),
                  ),
                  padding: EdgeInsets.fromLTRB(16, topInset, 16, 48),
                  children: [
                    ValueListenableBuilder<String>(
                      valueListenable: RemoteConfigService.activeAcademicPeriod,
                      builder: (context, period, _) {
                        final modeLabel = switch (period) {
                          'midterms' => 'MIDTERMS ACTIVE',
                          'finals' => 'FINALS ACTIVE',
                          'ramadan' => 'RAMADAN MODE',
                          'sports_week' => 'SPORTS WEEK',
                          'vacation' || 'break' => 'VACATION BREAK',
                          _ => 'REGULAR CLASSES',
                        };
                        return ResourceHeroCard(
                          title: 'Academic Calendar & Roadmap',
                          subtitle:
                              'Active Mode: $modeLabel • Official milestones & deadlines for ${widget.batch}',
                          icon: Icons.calendar_month_rounded,
                          accent: const Color(0xFF10B981),
                          isDark: isDark,
                        );
                      },
                    ),
                    const SizedBox(height: 16),

                    // Semester Completion Progress Card
                    GlassCard(
                      borderRadius: 24,
                      accentColor: const Color(0xFF10B981),
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 9,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF10B981)
                                      .withValues(alpha: 0.16),
                                  borderRadius: BorderRadius.circular(999),
                                ),
                                child: Text(
                                  payload.source == CampusScheduleSource.live
                                      ? 'LIVE CLOUD CALENDAR'
                                      : 'OFFICIAL SEMESTER ROADMAP',
                                  style: const TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 0.5,
                                    color: Color(0xFF10B981),
                                  ),
                                ),
                              ),
                              const Spacer(),
                              Text(
                                '${(progress * 100).round()}% Complete',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w900,
                                  color: onSurface,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(999),
                            child: LinearProgressIndicator(
                              value: progress,
                              minHeight: 8,
                              backgroundColor:
                                  onSurface.withValues(alpha: 0.10),
                              valueColor: const AlwaysStoppedAnimation<Color>(
                                Color(0xFF10B981),
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          Row(
                            children: [
                              _buildStatPill(
                                label: 'Done',
                                count: completedCount,
                                color: const Color(0xFF64748B),
                                isDark: isDark,
                              ),
                              const SizedBox(width: 8),
                              _buildStatPill(
                                label: 'Active',
                                count: activeCount,
                                color: const Color(0xFF10B981),
                                isDark: isDark,
                              ),
                              const SizedBox(width: 8),
                              _buildStatPill(
                                label: 'Upcoming',
                                count: upcomingCount,
                                color: const Color(0xFF3B82F6),
                                isDark: isDark,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 14),

                    // Filter Chips
                    SizedBox(
                      height: 36,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: _filters.length,
                        separatorBuilder: (_, _) => const SizedBox(width: 8),
                        itemBuilder: (context, index) {
                          final f = _filters[index];
                          final selected = _selectedFilter == f;
                          return GestureDetector(
                            onTap: () {
                              IrisHaptics.chipSelect();
                              setState(() => _selectedFilter = f);
                            },
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 180),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 8,
                              ),
                              decoration: BoxDecoration(
                                color: selected
                                    ? const Color(0xFF10B981)
                                    : onSurface.withValues(alpha: 0.07),
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Text(
                                f,
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: selected
                                      ? FontWeight.w800
                                      : FontWeight.w600,
                                  color: selected
                                      ? Colors.white
                                      : onSurface.withValues(alpha: 0.80),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),

                    if (showDeadlines && payload.deadlines.isNotEmpty) ...[
                      const SizedBox(height: 20),
                      Text(
                        'Key Academic Deadlines',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: onSurface.withValues(alpha: 0.92),
                        ),
                      ),
                      const SizedBox(height: 10),
                      ...payload.deadlines.map((dl) {
                        final isDone = dl.isDone;
                        final accent = isDone
                            ? const Color(0xFF64748B)
                            : const Color(0xFFEF4444);
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: GlassCard(
                            borderRadius: 20,
                            accentColor: accent,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 14,
                            ),
                            child: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(9),
                                  decoration: BoxDecoration(
                                    color: accent.withValues(alpha: 0.15),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Icon(
                                    isDone
                                        ? Icons.task_alt_rounded
                                        : Icons.timer_outlined,
                                    size: 18,
                                    color: accent,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        dl.title,
                                        style: TextStyle(
                                          fontSize: 13.5,
                                          fontWeight: FontWeight.w800,
                                          decoration: isDone
                                              ? TextDecoration.lineThrough
                                              : null,
                                          color: onSurface.withValues(
                                            alpha: isDone ? 0.60 : 0.95,
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        dl.date,
                                        style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600,
                                          color: onSurface.withValues(
                                            alpha: 0.62,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 4,
                                  ),
                                  decoration: BoxDecoration(
                                    color: accent.withValues(alpha: 0.14),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    isDone ? 'PASSED' : 'DEADLINE',
                                    style: TextStyle(
                                      fontSize: 9.5,
                                      fontWeight: FontWeight.w900,
                                      color: accent,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      }),
                    ],

                    if (_selectedFilter != 'Deadlines') ...[
                      const SizedBox(height: 20),
                      Text(
                        'Semester Milestones (${filteredMilestones.length})',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: onSurface.withValues(alpha: 0.92),
                        ),
                      ),
                      const SizedBox(height: 12),
                      ...List.generate(filteredMilestones.length, (idx) {
                        final milestone = filteredMilestones[idx];
                        final status = milestone.dynamicStatus;
                        final isDone = milestone.isDone;
                        final isActive = status == 'active';
                        final isLast = idx == filteredMilestones.length - 1;
                        final Color statusColor = isActive
                            ? const Color(0xFF10B981)
                            : isDone
                                ? const Color(0xFF64748B)
                                : const Color(0xFF3B82F6);

                        return IntrinsicHeight(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Column(
                                children: [
                                  Container(
                                    width: 26,
                                    height: 26,
                                    decoration: BoxDecoration(
                                      color: statusColor.withValues(alpha: 0.18),
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: statusColor,
                                        width: 1.5,
                                      ),
                                    ),
                                    child: Icon(
                                      isActive
                                          ? Icons.play_arrow_rounded
                                          : isDone
                                              ? Icons.check_rounded
                                              : Icons.schedule_rounded,
                                      size: 14,
                                      color: statusColor,
                                    ),
                                  ),
                                  if (!isLast)
                                    Expanded(
                                      child: Container(
                                        width: 2,
                                        margin: const EdgeInsets.symmetric(
                                          vertical: 4,
                                        ),
                                        color:
                                            statusColor.withValues(alpha: 0.25),
                                      ),
                                    ),
                                ],
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.only(bottom: 12),
                                  child: GlassCard(
                                    borderRadius: 20,
                                    accentColor:
                                        isActive ? statusColor : null,
                                    padding: const EdgeInsets.all(15),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                milestone.title,
                                                style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.w800,
                                                  decoration: isDone
                                                      ? TextDecoration
                                                          .lineThrough
                                                      : null,
                                                  color: onSurface.withValues(
                                                    alpha: isDone ? 0.60 : 0.96,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 8,
                                                    vertical: 3,
                                                  ),
                                              decoration: BoxDecoration(
                                                color: statusColor.withValues(
                                                  alpha: 0.14,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(6),
                                              ),
                                              child: Text(
                                                isActive
                                                    ? 'ACTIVE NOW'
                                                    : isDone
                                                        ? 'COMPLETED'
                                                        : 'UPCOMING',
                                                style: TextStyle(
                                                  fontSize: 9.5,
                                                  fontWeight: FontWeight.w900,
                                                  letterSpacing: 0.4,
                                                  color: statusColor,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 6),
                                        Row(
                                          children: [
                                            Icon(
                                              Icons.event_rounded,
                                              size: 13,
                                              color: onSurface.withValues(
                                                alpha: 0.50,
                                              ),
                                            ),
                                            const SizedBox(width: 5),
                                            Expanded(
                                              child: Text(
                                                milestone.date,
                                                style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w600,
                                                  color: onSurface.withValues(
                                                    alpha: 0.68,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      }),
                    ],
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildStatPill({
    required String label,
    required int count,
    required Color color,
    required bool isDark,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
        decoration: BoxDecoration(
          color: color.withValues(alpha: isDark ? 0.16 : 0.10),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: color.withValues(alpha: isDark ? 0.32 : 0.22),
          ),
        ),
        child: Column(
          children: [
            Text(
              '$count',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w900,
                color: color,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                fontSize: 10.5,
                fontWeight: FontWeight.w700,
                color: color.withValues(alpha: 0.90),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
