import '../../services/remote_config_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/animations.dart';
import '../../core/vital_theme.dart';
import '../../services/helpdesk_schedule_data_service.dart';
import '../../services/ui_feedback.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/iris_components.dart';
import 'resource_hero_card.dart';

class TransportScheduleScreen extends StatefulWidget {
  const TransportScheduleScreen({super.key});

  @override
  State<TransportScheduleScreen> createState() =>
      _TransportScheduleScreenState();
}

class _TransportScheduleScreenState extends State<TransportScheduleScreen> {
  final HelpdeskScheduleDataService _service = HelpdeskScheduleDataService();
  final TextEditingController _searchController = TextEditingController();
  List<TransportRouteData> _allRoutes = [];
  List<TransportRouteData> _filteredRoutes = [];
  int? _expandedIndex = 0;
  bool _isLoading = true;
  CampusScheduleSource _source = CampusScheduleSource.asset;

  @override
  void initState() {
    super.initState();
    _loadData();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    final payload = await _service.fetchSchedulePayload();
    if (mounted) {
      setState(() {
        _allRoutes = payload.transportRoutes;
        _filteredRoutes = _allRoutes;
        _source = payload.source;
        _isLoading = false;
      });
    }
  }

  void _onSearchChanged() {
    final query = _searchController.text.trim().toLowerCase();
    setState(() {
      if (query.isEmpty) {
        _filteredRoutes = _allRoutes;
      } else {
        _filteredRoutes = _allRoutes.where((r) {
          final matchesName = r.route.toLowerCase().contains(query);
          final matchesDriver = r.driverName.toLowerCase().contains(query);
          final matchesHelper = r.helperName.toLowerCase().contains(query);
          final matchesStop = r.stops.any(
            (s) =>
                s.point.toLowerCase().contains(query) ||
                s.time.toLowerCase().contains(query),
          );
          return matchesName || matchesDriver || matchesHelper || matchesStop;
        }).toList();
      }
    });
  }

  void _copyPhone(String label, String phone) {
    if (phone.isEmpty) return;
    IrisHaptics.actionMedium();
    Clipboard.setData(ClipboardData(text: phone));
    showIrisFrostedSnackBar(
      context,
      tint: const Color(0xFF06B6D4),
      content: Text('Copied $label phone ($phone) to clipboard'),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final onSurface = Theme.of(context).colorScheme.onSurface;
    final topInset = MediaQuery.paddingOf(context).top + kToolbarHeight + 12;
    final query = _searchController.text.trim().toLowerCase();

    final totalStops = _allRoutes.fold<int>(0, (sum, r) => sum + r.stops.length);

    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: irisFrostedAppBar(
        title: 'Campus Transit Hub',
        isDark: isDark,
        actions: [
          IconButton(
            onPressed: () {
              IrisHaptics.refreshStart();
              setState(() => _isLoading = true);
              _loadData();
            },
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: Stack(
        children: [
          ObsidianPulse(isDark: isDark),
          if (_isLoading)
            Center(child: IrisComponents.loadingSpinner(size: 28))
          else
            ListView(
              physics: const ButterScrollPhysics(
                parent: AlwaysScrollableScrollPhysics(),
              ),
              padding: EdgeInsets.fromLTRB(16, topInset, 16, 48),
              children: [
                ValueListenableBuilder<String>(
                  valueListenable: RemoteConfigService.activeAcademicPeriod,
                  builder: (context, period, _) {
                    final modeScheduleNote = switch (period) {
                      'ramadan' => 'Ramadan Timings (07:30 AM & 01:45 PM Departures)',
                      'midterms' || 'finals' => 'Exam Shuttle Schedule (Morning & Afternoon Shifts)',
                      'sports_week' => 'Sports Week Active • Regular Campus Shuttle Timings',
                      'vacation' || 'break' => 'Vacation Skeleton Fleet • Staff & Lab Routes Only',
                      _ => '${_allRoutes.length} active bus routes • $totalStops verified stops & staff contacts',
                    };
                    return ResourceHeroCard(
                      title: 'Campus Transit Network',
                      subtitle: modeScheduleNote,
                      icon: Icons.directions_bus_rounded,
                      accent: const Color(0xFF06B6D4),
                      isDark: isDark,
                    );
                  },
                ),
                const SizedBox(height: 14),
                // Live Search Bar
                GlassCard(
                  borderRadius: 20,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 4,
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.search_rounded,
                        size: 20,
                        color: Color(0xFF06B6D4),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          controller: _searchController,
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 13.5,
                            color: onSurface,
                          ),
                          decoration: InputDecoration(
                            hintText:
                                'Search route, bus stop, driver or time...',
                            hintStyle: TextStyle(
                              fontSize: 12.5,
                              color: onSurface.withValues(alpha: 0.45),
                            ),
                            border: InputBorder.none,
                            isDense: true,
                          ),
                        ),
                      ),
                      if (query.isNotEmpty)
                        IconButton(
                          icon: const Icon(Icons.close_rounded, size: 18),
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(),
                          onPressed: () => _searchController.clear(),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                // Summary Strip
                Row(
                  children: [
                    _buildSummaryChip(
                      isDark: isDark,
                      icon: Icons.route_rounded,
                      label: '${_filteredRoutes.length} Routes',
                      accent: const Color(0xFF06B6D4),
                    ),
                    const SizedBox(width: 8),
                    _buildSummaryChip(
                      isDark: isDark,
                      icon: Icons.pin_drop_rounded,
                      label: '$totalStops Stops',
                      accent: const Color(0xFF10B981),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _buildSummaryChip(
                        isDark: isDark,
                        icon: _source == CampusScheduleSource.live
                            ? Icons.cloud_done_rounded
                            : Icons.verified_rounded,
                        label: _source == CampusScheduleSource.live
                            ? 'Live Feed'
                            : 'Official Fleet',
                        accent: const Color(0xFF8B5CF6),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                if (_filteredRoutes.isEmpty)
                  GlassCard(
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      children: [
                        Icon(
                          Icons.directions_bus_filled_outlined,
                          size: 42,
                          color: onSurface.withValues(alpha: 0.35),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'No matching transit routes or stops',
                          style: TextStyle(
                            fontSize: 14.5,
                            fontWeight: FontWeight.w800,
                            color: onSurface.withValues(alpha: 0.85),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Try searching another landmark, chowk, or route number.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 12,
                            color: onSurface.withValues(alpha: 0.55),
                          ),
                        ),
                      ],
                    ),
                  )
                else
                  ...List.generate(_filteredRoutes.length, (index) {
                    final route = _filteredRoutes[index];
                    final isExpanded = query.isNotEmpty || _expandedIndex == index;
                    final firstTime =
                        route.stops.isNotEmpty ? route.stops.first.time : '--';
                    final lastStop =
                        route.stops.isNotEmpty ? route.stops.last.point : '';

                    return Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: GlassCard(
                        borderRadius: 22,
                        accentColor: const Color(0xFF06B6D4),
                        padding: const EdgeInsets.all(16),
                        onTap: () {
                          IrisHaptics.selectionClick();
                          setState(() {
                            _expandedIndex = isExpanded ? null : index;
                          });
                        },
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Route Header
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 44,
                                  height: 44,
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      colors: [
                                        Color(0xFF06B6D4),
                                        Color(0xFF3B82F6),
                                      ],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                    borderRadius: BorderRadius.circular(14),
                                    boxShadow: [
                                      BoxShadow(
                                        color: const Color(0xFF06B6D4)
                                            .withValues(alpha: 0.30),
                                        blurRadius: 12,
                                        offset: const Offset(0, 4),
                                      ),
                                    ],
                                  ),
                                  child: const Icon(
                                    Icons.directions_bus_rounded,
                                    color: Colors.white,
                                    size: 22,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        route.route,
                                        style: TextStyle(
                                          fontSize: 15.5,
                                          fontWeight: FontWeight.w900,
                                          letterSpacing: -0.2,
                                          color: onSurface,
                                        ),
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        firstTime != '--'
                                            ? 'Departs $firstTime • Arrives $lastStop'
                                            : '${route.stops.length} scheduled stops',
                                        style: TextStyle(
                                          fontSize: 11.5,
                                          fontWeight: FontWeight.w600,
                                          color: onSurface.withValues(
                                            alpha: 0.62,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 9,
                                    vertical: 4,
                                  ),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF06B6D4)
                                        .withValues(alpha: 0.16),
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        '${route.stops.length} Stops',
                                        style: const TextStyle(
                                          fontSize: 10.5,
                                          fontWeight: FontWeight.w800,
                                          color: Color(0xFF06B6D4),
                                        ),
                                      ),
                                      const SizedBox(width: 4),
                                      Icon(
                                        isExpanded
                                            ? Icons.keyboard_arrow_up_rounded
                                            : Icons.keyboard_arrow_down_rounded,
                                        size: 15,
                                        color: const Color(0xFF06B6D4),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),

                            // Driver & Conductor Contact Pills
                            if (route.driverName.isNotEmpty ||
                                route.helperName.isNotEmpty) ...[
                              const SizedBox(height: 12),
                              Wrap(
                                spacing: 8,
                                runSpacing: 8,
                                children: [
                                  if (route.driverName.isNotEmpty)
                                    _buildStaffContactChip(
                                      isDark: isDark,
                                      role: 'Driver',
                                      name: route.driverName,
                                      phone: route.driverPhone,
                                      accent: const Color(0xFF10B981),
                                    ),
                                  if (route.helperName.isNotEmpty)
                                    _buildStaffContactChip(
                                      isDark: isDark,
                                      role: 'Conductor',
                                      name: route.helperName,
                                      phone: route.helperPhone,
                                      accent: const Color(0xFF8B5CF6),
                                    ),
                                ],
                              ),
                            ],

                            // Interactive Connected Stop Timeline
                            if (isExpanded && route.stops.isNotEmpty) ...[
                              const SizedBox(height: 14),
                              Divider(
                                height: 1,
                                color: onSurface.withValues(alpha: 0.10),
                              ),
                              const SizedBox(height: 12),
                              ...List.generate(route.stops.length, (sIdx) {
                                final stop = route.stops[sIdx];
                                final isFirst = sIdx == 0;
                                final isLast = sIdx == route.stops.length - 1;
                                final isMatch = query.isNotEmpty &&
                                    (stop.point.toLowerCase().contains(query) ||
                                        stop.time.toLowerCase().contains(query));

                                final Color nodeColor = isFirst
                                    ? const Color(0xFF06B6D4)
                                    : isLast
                                        ? const Color(0xFF10B981)
                                        : isMatch
                                            ? const Color(0xFFF59E0B)
                                            : onSurface.withValues(alpha: 0.35);

                                return IntrinsicHeight(
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.stretch,
                                    children: [
                                      SizedBox(
                                        width: 68,
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                            top: 2,
                                            right: 8,
                                          ),
                                          child: Text(
                                            stop.time,
                                            textAlign: TextAlign.right,
                                            style: TextStyle(
                                              fontSize: 11,
                                              fontWeight: (isFirst ||
                                                      isLast ||
                                                      isMatch)
                                                  ? FontWeight.w800
                                                  : FontWeight.w600,
                                              color: isMatch
                                                  ? const Color(0xFFF59E0B)
                                                  : onSurface.withValues(
                                                      alpha: 0.75,
                                                    ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Column(
                                        children: [
                                          Container(
                                            width: (isFirst || isLast || isMatch)
                                                ? 12
                                                : 8,
                                            height:
                                                (isFirst || isLast || isMatch)
                                                    ? 12
                                                    : 8,
                                            margin: const EdgeInsets.only(top: 4),
                                            decoration: BoxDecoration(
                                              color: nodeColor,
                                              shape: BoxShape.circle,
                                              boxShadow: (isFirst ||
                                                      isLast ||
                                                      isMatch)
                                                  ? [
                                                      BoxShadow(
                                                        color: nodeColor
                                                            .withValues(
                                                              alpha: 0.45,
                                                            ),
                                                        blurRadius: 6,
                                                      ),
                                                    ]
                                                  : null,
                                            ),
                                          ),
                                          if (!isLast)
                                            Expanded(
                                              child: Container(
                                                width: 1.8,
                                                margin:
                                                    const EdgeInsets.symmetric(
                                                      vertical: 2,
                                                    ),
                                                color: const Color(0xFF06B6D4)
                                                    .withValues(alpha: 0.25),
                                              ),
                                            ),
                                        ],
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                            bottom: 10,
                                          ),
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 10,
                                              vertical: 6,
                                            ),
                                            decoration: BoxDecoration(
                                              color: isMatch
                                                  ? const Color(0xFFF59E0B)
                                                      .withValues(alpha: 0.14)
                                                  : (isFirst || isLast)
                                                      ? nodeColor.withValues(
                                                          alpha: 0.10,
                                                        )
                                                      : Colors.transparent,
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  child: Text(
                                                    stop.point,
                                                    style: TextStyle(
                                                      fontSize: 12.5,
                                                      fontWeight: (isFirst ||
                                                              isLast ||
                                                              isMatch)
                                                          ? FontWeight.w800
                                                          : FontWeight.w600,
                                                      color: onSurface.withValues(
                                                        alpha: (isFirst ||
                                                                isLast ||
                                                                isMatch)
                                                            ? 0.95
                                                            : 0.80,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                if (isFirst)
                                                  _buildStopBadge(
                                                    'ORIGIN',
                                                    const Color(0xFF06B6D4),
                                                  )
                                                else if (isLast)
                                                  _buildStopBadge(
                                                    'CAMPUS',
                                                    const Color(0xFF10B981),
                                                  ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              }),
                            ],
                          ],
                        ),
                      ),
                    );
                  }),
              ],
            ),
        ],
      ),
    );
  }

  Widget _buildSummaryChip({
    required bool isDark,
    required IconData icon,
    required String label,
    required Color accent,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: accent.withValues(alpha: isDark ? 0.16 : 0.10),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: accent.withValues(alpha: isDark ? 0.35 : 0.25),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: accent),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: accent,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStaffContactChip({
    required bool isDark,
    required String role,
    required String name,
    required String phone,
    required Color accent,
  }) {
    final onSurface = Theme.of(context).colorScheme.onSurface;
    return GestureDetector(
      onTap: phone.isNotEmpty ? () => _copyPhone('$role $name', phone) : null,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: accent.withValues(alpha: isDark ? 0.14 : 0.09),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: accent.withValues(alpha: isDark ? 0.32 : 0.22),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              role == 'Driver'
                  ? Icons.airline_seat_recline_normal_rounded
                  : Icons.support_agent_rounded,
              size: 14,
              color: accent,
            ),
            const SizedBox(width: 6),
            Text(
              '$role: $name',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: onSurface.withValues(alpha: 0.90),
              ),
            ),
            if (phone.isNotEmpty) ...[
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.18),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.copy_rounded, size: 10, color: accent),
                    const SizedBox(width: 3),
                    Text(
                      phone,
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        color: accent,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildStopBadge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.18),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 9,
          fontWeight: FontWeight.w900,
          letterSpacing: 0.4,
          color: color,
        ),
      ),
    );
  }
}
