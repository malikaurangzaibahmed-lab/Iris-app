import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';

enum HelpdeskFacultySource { live, cache, backup, none }

class FacultyFetchPayload {
  final List<FacultyProfile> items;
  final HelpdeskFacultySource source;

  const FacultyFetchPayload({required this.items, required this.source});
}

class FacultyProfile {
  final String id;
  final String name;
  final String gender;
  final String department;
  final String location;
  final String email;
  final String contact;
  final String image;
  final String designation;
  final DateTime? updatedAt;
  final List<String> aliases;

  const FacultyProfile({
    required this.id,
    required this.name,
    required this.gender,
    required this.department,
    required this.location,
    required this.email,
    required this.contact,
    required this.image,
    this.designation = '',
    this.updatedAt,
    this.aliases = const [],
  });

  factory FacultyProfile.fromJson(Map<String, dynamic> json) {
    return FacultyProfile(
      id: (json['_id'] ?? json['id'] ?? '').toString(),
      name: (json['name'] ?? '').toString(),
      gender: (json['gender'] ?? '').toString(),
      department: (json['department'] ?? '').toString(),
      location: (json['location'] ?? '').toString(),
      email: (json['email'] ?? '').toString(),
      contact: (json['contact'] ?? '').toString(),
      image: (json['image'] ?? '').toString(),
      designation: (json['designation'] ?? '').toString(),
      updatedAt: DateTime.tryParse((json['updatedAt'] ?? '').toString()),
      aliases: (json['aliases'] is List)
          ? (json['aliases'] as List).map((e) => e.toString()).toList()
          : const [],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'name': name,
      'gender': gender,
      'department': department,
      'location': location,
      'email': email,
      'contact': contact,
      'image': image,
      'designation': designation,
      'updatedAt': updatedAt?.toIso8601String(),
      'aliases': aliases,
    };
  }

  FacultyProfile copyWith({
    String? id,
    String? name,
    String? gender,
    String? department,
    String? location,
    String? email,
    String? contact,
    String? image,
    String? designation,
    DateTime? updatedAt,
    List<String>? aliases,
  }) {
    return FacultyProfile(
      id: id ?? this.id,
      name: name ?? this.name,
      gender: gender ?? this.gender,
      department: department ?? this.department,
      location: location ?? this.location,
      email: email ?? this.email,
      contact: contact ?? this.contact,
      image: image ?? this.image,
      designation: designation ?? this.designation,
      updatedAt: updatedAt ?? this.updatedAt,
      aliases: aliases ?? this.aliases,
    );
  }

  bool get hasImage => image.trim().isNotEmpty;
}

class HelpdeskFacultyService {
  // static const String _liveUrl = 'https://cui-helpdesk-backend.onrender.com/api/faculty';
  static const String _cacheKey = 'helpdesk_faculty_cache_v2';
  static const String _assetPath = 'assets/helpdesk_backup/helpdesk_full_snapshot_cli.json';

  static List<FacultyProfile> _memoryCache = const [];
  static List<FacultyProfile> _cachedPureTimetableProfiles = const [];

  static List<FacultyProfile> get cachedPureTimetableProfiles => _cachedPureTimetableProfiles;
  static bool get hasCachedPureTimetableProfiles => _cachedPureTimetableProfiles.isNotEmpty;

  static void invalidatePureTimetableCache() {
    _cachedPureTimetableProfiles = const [];
  }

  static const Set<String> _honorificTokens = {
    'dr',
    'mr',
    'mrs',
    'ms',
    'miss',
    'prof',
    'professor',
    'eng',
    'engr',
    'sir',
    'madam',
    'lecturer',
    'asst',
    'assistant',
    'ch',
    'chaudhry',
    'choudhry',
    'hafiz',
    'syed',
    'syeda',
    'molana',
    'maulana',
  };

  static const Map<String, String> _spellingEquivalents = {
    'kousar': 'kausar',
    'shehzad': 'shahzad',
    'mehmood': 'mahmood',
    'ameen': 'amin',
    'fayez': 'faiz',
    'mudassar': 'mudasar',
    'muzammil': 'muzamil',
    'sufiyan': 'sufyan',
    'marriam': 'mariam',
    'muhmmad': 'muhammad',
    'm': 'muhammad',
    'md': 'muhammad',
    'mohd': 'muhammad',
    'shoaib': 'shoaib',
    'shoiab': 'shoaib',
    'shuaib': 'shoaib',
    'qaiser': 'qaisar',
    'naseem': 'nasim',
    'nasim': 'nasim',
    'irfan': 'irfan',
    'ayyaz': 'ayaz',
    'zahoor': 'zahur',
  };

  static final RegExp _compoundDeptTitleRegExp = RegExp(
    r'^(?:MS|BI|CS|SE|EE|ME|CE|CVE|MT|HUM|VS)\.?\s+(?=(?:Dr|Mr|Ms|Mrs|Prof|Engr)\b)',
    caseSensitive: false,
  );

  static final RegExp _standaloneDeptPrefixRegExp = RegExp(
    r'^(?:BI|CS|SE|EE|ME|CE|CVE|MT|HUM|VS)\.?\s+',
    caseSensitive: false,
  );

  static final RegExp _deptNoSpacePrefixRegExp = RegExp(
    r'^(?:BI|CS|SE|EE|ME|CE|CVE|MT|HUM|VS)\s+(Ms\.)([A-Za-z])',
    caseSensitive: false,
  );

  static final RegExp _titleNoSpaceRegExp = RegExp(
    r'\b(Dr|Engr|Mr|Ms|Mrs|Prof)\.([A-Za-z])',
    caseSensitive: false,
  );

  /// Strips university timetable department prefix abbreviations and normalizes compound prefixes
  /// e.g. 'MS. Dr. Qamar' -> 'Dr. Qamar', 'Ms. Mr. M. Shoaib Bajwa' -> 'Mr. M. Shoaib Bajwa',
  /// 'BI Prof. Dr. Abrar' -> 'Prof. Dr. Abrar', 'BI Ms.Sunaina' -> 'Ms. Sunaina'.
  static String stripDepartmentPrefix(String input) {
    var raw = input.trim();
    if (raw.isEmpty) return '';

    // 1. Strip compound department code followed by title (e.g. "MS. Dr.", "Ms. Mr.")
    raw = raw.replaceFirst(_compoundDeptTitleRegExp, '');

    // 2. Strip standalone department prefix (e.g. "BI Prof.", "BI Dr.", "CS ")
    raw = raw.replaceFirst(_standaloneDeptPrefixRegExp, '');

    // 3. Fix missing space in "BI Ms.Sunaina" -> "Ms. Sunaina"
    raw = raw.replaceAllMapped(_deptNoSpacePrefixRegExp, (m) => '${m[1]} ${m[2]}');

    // 4. Fix missing space after dot in title "Dr.H.M" -> "Dr. H.M"
    raw = raw.replaceAllMapped(_titleNoSpaceRegExp, (m) => '${m[1]}. ${m[2]}');

    return raw.replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  /// Extracts the canonical academic title / honorific category from a name
  static String extractHonorificCategory(String name) {
    final clean = stripDepartmentPrefix(name);
    final cleaned = clean.toLowerCase().replaceAll(RegExp(r'[^a-z0-9\s]+'), ' ');
    final words = cleaned.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    for (int i = 0; i < math.min(words.length, 4); i++) {
      final w = words[i];
      // Note: In university faculty rankings, Prof. and Dr. are both doctorate categories
      // and should unify (e.g. Prof. Dr. Abrar Hussain is Dr. Abrar Hussain).
      if (w == 'dr' || w == 'doctor' || w == 'phd' || w == 'prof' || w == 'professor') return 'dr';
      if (w == 'engr' || w == 'eng' || w == 'engineer') return 'engr';
      if (w == 'mr') return 'mr';
      if (w == 'ms' || w == 'mrs' || w == 'miss') return 'ms';
    }
    return '';
  }

  /// Determines if two titles are in direct academic conflict (e.g. Dr vs Mr or Dr vs Engr).
  /// An un-titled name (empty category) is NEVER in conflict with a titled name
  /// (e.g. "Dr. Abrar Hussain" and "Abrar Hussain" are the same person).
  static bool areHonorificsConflicting(String title1, String title2) {
    if (title1.isEmpty || title2.isEmpty) return false;
    return title1 != title2;
  }

  /// Canonical department abbreviation for disambiguation
  static String normalizeDepartment(String department) {
    final d = department.toLowerCase().trim();
    if (d.contains('comput') || d.split(RegExp(r'\s+')).contains('cs')) return 'cs';
    if (d.contains('elect') || d.split(RegExp(r'\s+')).contains('ee')) return 'ee';
    if (d.contains('mechan') || d.contains('mech')) return 'mech';
    if (d.contains('civil') || d.split(RegExp(r'\s+')).contains('ce')) return 'civil';
    if (d.contains('math')) return 'math';
    if (d.contains('manag') || d.contains('mgmt') || d.split(RegExp(r'\s+')).contains('ms') || d.contains('business')) return 'ms';
    if (d.contains('bio')) return 'bio';
    if (d.contains('human')) return 'hum';
    return d;
  }

  /// Maps timetable short batch department code to clean user-facing department name
  static String departmentNameFromCode(String code) {
    switch (code.toLowerCase()) {
      case 'bcs':
      case 'bse':
      case 'rcs':
      case 'pcs':
        return 'Computer Science';
      case 'bba':
      case 'baf':
      case 'rms':
        return 'Management Sciences';
      case 'bty':
      case 'rbs':
      case 'bbc':
        return 'Biosciences';
      case 'fsn':
      case 'hnd':
      case 'rhnd':
        return 'Food Sciences & Nutrition';
      case 'bee':
      case 'ree':
        return 'Electrical Engineering';
      case 'bsme':
        return 'Mechanical Engineering';
      case 'bscve':
      case 'bce':
        return 'Civil Engineering';
      case 'ben':
        return 'Humanities & English';
      case 'bsm':
      case 'pmt':
      case 'rmt':
      case 'bmd':
        return 'Mathematics';
      case 'pmi':
        return 'Islamic Studies';
      default:
        return 'Academic Faculty';
    }
  }

  /// Extracts meaningful normalized tokens stripped of titles and spelling variations
  static List<String> extractCoreTokens(String input) {
    final withoutPrefix = stripDepartmentPrefix(input);
    final cleaned = withoutPrefix
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9\s]+'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    if (cleaned.isEmpty) return const [];
    final words = cleaned.split(' ');
    final result = <String>[];
    for (final w in words) {
      if (w.isEmpty || _honorificTokens.contains(w)) continue;
      final normalized = _spellingEquivalents[w] ?? w;
      if (normalized.isNotEmpty) {
        result.add(normalized);
      }
    }
    return result;
  }

  /// Normalizes a faculty name into a clean canonical search string
  static String normalizeFacultyName(String input) {
    final tokens = extractCoreTokens(input);
    return tokens.join(' ').trim();
  }

  /// Computes a fuzzy semantic similarity score between two faculty/teacher names [0.0 - 1.0]
  /// Incorporates strict honorific disambiguation so Dr. and Mr. with the same base name NEVER collide.
  static double calculateSimilarity(String name1, String name2) {
    final c1 = stripDepartmentPrefix(name1);
    final c2 = stripDepartmentPrefix(name2);
    if (c1.trim().toLowerCase() == c2.trim().toLowerCase()) return 1.0;

    final h1 = extractHonorificCategory(c1);
    final h2 = extractHonorificCategory(c2);
    // If both have explicit titles and they conflict (e.g. Dr vs Mr or Engr vs Dr), they are distinct individuals
    final bool hasConflictingTitle = areHonorificsConflicting(h1, h2);

    final t1 = extractCoreTokens(c1);
    final t2 = extractCoreTokens(c2);
    if (t1.isEmpty || t2.isEmpty) return 0.0;

    final k1 = t1.join(' ');
    final k2 = t2.join(' ');
    double baseScore = 0.0;

    if (k1 == k2) {
      baseScore = 1.0;
    } else {
      final s1 = t1.toSet();
      final s2 = t2.toSet();
      final intersection = s1.intersection(s2);
      if (intersection.isEmpty) return 0.0;

      // Subset match (e.g. "Fayez Afzaal" in "Muhammad Fayez Afzaal", or "Abrar Hussain" in "Dr. Abrar Hussain")
      if (s1.containsAll(s2) || s2.containsAll(s1)) {
        if (intersection.length >= 2) {
          baseScore = 0.95;
        } else if (intersection.length == 1 && (s1.length == 1 || s2.length == 1)) {
          // Single unique token match (e.g. "Zunaira", "Saqlain", "Manzoor")
          baseScore = 0.72;
        }
      } else {
        final union = s1.union(s2);
        final jaccard = intersection.length / union.length;
        final minLen = math.min(s1.length, s2.length);
        final overlap = minLen == 0 ? 0.0 : intersection.length / minLen;
        baseScore = (jaccard * 0.4) + (overlap * 0.6);
      }
    }

    if (hasConflictingTitle) {
      // Strictly penalize conflicting academic titles so Dr. Shoaib never matches Mr. Shoaib or Engr.
      return math.max(0.0, baseScore - 0.55);
    }
    if (h1.isNotEmpty && h2.isNotEmpty && h1 == h2) {
      return math.min(1.0, baseScore + 0.10);
    }
    return baseScore;
  }

  /// Checks if two name variants belong to the same faculty member
  static bool isNameMatch(String name1, String name2, {double threshold = 0.70}) {
    final c1 = stripDepartmentPrefix(name1);
    final c2 = stripDepartmentPrefix(name2);
    if (c1.trim().toLowerCase() == c2.trim().toLowerCase()) return true;
    final h1 = extractHonorificCategory(c1);
    final h2 = extractHonorificCategory(c2);
    if (areHonorificsConflicting(h1, h2)) return false;
    return calculateSimilarity(c1, c2) >= threshold;
  }

  /// Finds the best matching FacultyProfile from a list of profiles
  static FacultyProfile? matchFacultyProfile(
    String teacherName,
    List<FacultyProfile> profiles, {
    double threshold = 0.65,
    String? preferredDepartment,
  }) {
    if (profiles.isEmpty || teacherName.trim().isEmpty) return null;

    final lowerClean = teacherName.trim().toLowerCase();
    final prefDeptNorm = preferredDepartment != null ? normalizeDepartment(preferredDepartment) : null;
    final queryHonorific = extractHonorificCategory(teacherName);

    // 1. Direct exact name or alias check with strict title protection
    for (final profile in profiles) {
      final deptMatches = prefDeptNorm == null || normalizeDepartment(profile.department) == prefDeptNorm;
      final profHonorific = extractHonorificCategory(profile.name);
      final hasTitleConflict = areHonorificsConflicting(queryHonorific, profHonorific);
      if (hasTitleConflict) continue;

      if (profile.name.trim().toLowerCase() == lowerClean && deptMatches) {
        return profile;
      }
      for (final alias in profile.aliases) {
        if (alias.trim().toLowerCase() == lowerClean && deptMatches) {
          return profile;
        }
      }
    }

    // 2. High-precision title-aware fuzzy similarity check
    FacultyProfile? bestProfile;
    var bestScore = -1.0;

    for (final profile in profiles) {
      final profHonorific = extractHonorificCategory(profile.name);
      // Strictly disqualify candidates only if there is an explicit title conflict (e.g. Dr vs Mr vs Engr)
      if (areHonorificsConflicting(queryHonorific, profHonorific)) {
        continue;
      }

      var score = calculateSimilarity(teacherName, profile.name);
      if (teacherName.toLowerCase().contains('bajwa') &&
          profile.email.toLowerCase().contains('bajwa') &&
          !areHonorificsConflicting(queryHonorific, profHonorific)) {
        score = math.max(score, 0.98);
      }

      for (final alias in profile.aliases) {
        final aliasHonorific = extractHonorificCategory(alias);
        if (areHonorificsConflicting(queryHonorific, aliasHonorific)) {
          continue;
        }
        var aliasScore = calculateSimilarity(teacherName, alias);
        if (teacherName.toLowerCase().contains('bajwa') &&
            alias.toLowerCase().contains('bajwa')) {
          aliasScore = math.max(aliasScore, 0.98);
        }
        if (aliasScore > score) score = aliasScore;
      }

      if (prefDeptNorm != null) {
        final candidateDeptNorm = normalizeDepartment(profile.department);
        if (candidateDeptNorm == prefDeptNorm) {
          score += 0.25; // Strong boost for same department
        } else if (candidateDeptNorm.isNotEmpty) {
          score -= 0.20; // Penalize cross-department collision
        }
      }

      if (score > bestScore) {
        bestScore = score;
        bestProfile = profile;
      }
    }

    if (bestProfile != null && bestScore >= threshold) {
      return bestProfile;
    }
    return null;
  }

  /// Resolves the local or remote asset image path for any teacher name
  static String resolveTeacherImagePath(String teacherName, {String? department}) {
    final clean = stripDepartmentPrefix(teacherName).trim();
    if (clean.isEmpty || _memoryCache.isEmpty) return '';
    final match = matchFacultyProfile(clean, _memoryCache, preferredDepartment: department);
    if (match != null && match.image.trim().isNotEmpty) {
      final raw = match.image.trim();
      if (raw.startsWith('http://') || raw.startsWith('https://')) {
        return raw;
      }
    }
    return '';
  }

  /// Deduplicates faculty profiles while strictly preserving distinct honorifics (Dr vs Mr vs Engr)
  /// and department identities, while unifying un-titled variants (e.g. "Dr. Abrar Hussain" and "Abrar Hussain").
  static List<FacultyProfile> deduplicateProfiles(List<FacultyProfile> items) {
    if (items.isEmpty) return const [];
    final map = <String, FacultyProfile>{};

    for (final item in items) {
      final cleanName = item.name.trim();
      final normName = normalizeFacultyName(cleanName);
      if (normName.isEmpty) continue;
      final title = extractHonorificCategory(cleanName);
      final dept = normalizeDepartment(item.department);

      final baseKey = '${normName}_$dept';

      if (!map.containsKey(baseKey)) {
        map[baseKey] = item.copyWith(name: cleanName);
      } else {
        final existing = map[baseKey]!;
        final existingTitle = extractHonorificCategory(existing.name);

        // If titles explicitly conflict (e.g. Dr. Shoaib vs Mr. Shoaib in the same department),
        // they must remain separate entries
        if (areHonorificsConflicting(title, existingTitle)) {
          final specificKey = '${title.isNotEmpty ? "${title}_" : ""}${normName}_$dept';
          map[specificKey] = item.copyWith(name: cleanName);
          continue;
        }

        // Compatible or same person (e.g. "Dr. Abrar Hussain" and "Abrar Hussain"):
        // Merge into the richer entry
        final existingScore = (existing.hasImage ? 6 : 0) +
            (existingTitle.isNotEmpty ? 4 : 0) +
            (existing.email.isNotEmpty ? 2 : 0) +
            (existing.contact.isNotEmpty ? 1 : 0);
        final itemScore = (item.hasImage ? 6 : 0) +
            (title.isNotEmpty ? 4 : 0) +
            (item.email.isNotEmpty ? 2 : 0) +
            (item.contact.isNotEmpty ? 1 : 0);

        final mergedAliases = {...existing.aliases, ...item.aliases, existing.name.trim(), cleanName}.toList();
        final bestImage = existing.hasImage ? existing.image : item.image;
        final bestName = existingTitle.isNotEmpty
            ? existing.name.trim()
            : (title.isNotEmpty ? cleanName : existing.name.trim());

        if (itemScore > existingScore) {
          map[baseKey] = item.copyWith(
            name: bestName,
            image: bestImage,
            aliases: mergedAliases,
          );
        } else {
          map[baseKey] = existing.copyWith(
            name: bestName,
            image: bestImage,
            aliases: mergedAliases,
          );
        }
      }
    }
    return map.values.toList();
  }

  /// Seamlessly merges Timetable teachers with Helpdesk snapshot without duplicate fragmentation
  static List<FacultyProfile> mergeWithTimetableTeachers({
    required List<FacultyProfile> helpdeskProfiles,
    required Iterable<String> timetableTeachers,
  }) {
    final cleanHelpdesk = deduplicateProfiles(helpdeskProfiles);
    final result = List<FacultyProfile>.from(cleanHelpdesk);
    final profileAliases = <String, Set<String>>{};
    for (final p in result) {
      profileAliases[p.id] = p.aliases.toSet();
    }

    for (final rawTeacher in timetableTeachers) {
      final clean = rawTeacher.trim();
      final stripped = stripDepartmentPrefix(clean);
      if (stripped.isEmpty ||
          stripped.toLowerCase() == 'unknown' ||
          stripped.toLowerCase() == 'na' ||
          stripped.toLowerCase() == 'staff' ||
          stripped.toLowerCase().startsWith('tbd') ||
          stripped.toLowerCase().startsWith('to be announced')) {
        continue;
      }

      final queryTitle = extractHonorificCategory(stripped);

      // Check if already matches any existing profile in result
      FacultyProfile? bestProfile;
      double bestScore = 0.0;

      for (final profile in result) {
        final profTitle = extractHonorificCategory(profile.name);
        if (areHonorificsConflicting(queryTitle, profTitle)) continue;

        final isBajwaMatch = (stripped.toLowerCase().contains('bajwa') || clean.toLowerCase().contains('bajwa')) &&
            profile.email.toLowerCase().contains('bajwa');

        if (profile.name.toLowerCase() == stripped.toLowerCase() ||
            profile.name.toLowerCase() == clean.toLowerCase() ||
            profileAliases[profile.id]!.contains(stripped.toLowerCase()) ||
            profileAliases[profile.id]!.contains(clean.toLowerCase()) ||
            isBajwaMatch) {
          bestProfile = profile;
          bestScore = 1.0;
          break;
        }

        final score = calculateSimilarity(stripped, profile.name);
        if (score > bestScore) {
          bestScore = score;
          bestProfile = profile;
        }
      }

      if (bestProfile != null && bestScore >= 0.65) {
        // Associate alias to the existing rich profile
        profileAliases[bestProfile.id]!.add(stripped);
        profileAliases[bestProfile.id]!.add(clean);
        profileAliases[bestProfile.id]!.add(stripped.toLowerCase());
        profileAliases[bestProfile.id]!.add(clean.toLowerCase());
        // If the existing profile was un-titled and the timetable has a titled name (e.g. Dr.), promote the title
        final existingTitle = extractHonorificCategory(bestProfile.name);
        if (existingTitle.isEmpty && queryTitle.isNotEmpty) {
          final idx = result.indexOf(bestProfile);
          if (idx != -1) {
            result[idx] = bestProfile.copyWith(name: stripped);
          }
        }
      } else {
        // Truly unique teacher not in Helpdesk snapshot (e.g. visiting or new faculty)
        final newProfile = FacultyProfile(
          id: 'pdf_${stripped.hashCode}',
          name: stripped,
          gender: 'N/A',
          department: 'Academic Faculty',
          location: 'COMSATS Campus',
          contact: 'Campus Office',
          email: '',
          image: '',
          designation: 'Faculty Member',
          aliases: [stripped, clean],
        );
        result.add(newProfile);
        profileAliases[newProfile.id] = {stripped, clean};
      }
    }

    // Return with aliases populated
    return result.map((p) {
      final currentAliases = profileAliases[p.id] ?? const {};
      if (currentAliases.isEmpty) return p;
      return p.copyWith(aliases: currentAliases.toList());
    }).toList();
  }

  /// Builds a pure timetable faculty roster (100% active teaching faculty, zero photos, zero non-teaching staff).
  /// Optional Helpdesk profiles are used exclusively for secondary metadata enrichment (official email).
  static List<FacultyProfile> buildPureTimetableProfiles({
    required Iterable<String> timetableTeachers,
    String? Function(String teacher)? departmentLookup,
    List<String> Function(String teacher)? roomsLookup,
    List<FacultyProfile> enrichmentProfiles = const [],
  }) {
    // 0. Pre-index enrichment profiles for O(1) matching
    final exactEnrichmentMap = <String, FacultyProfile>{};
    final normEnrichmentMap = <String, FacultyProfile>{};
    if (enrichmentProfiles.isNotEmpty) {
      for (final profile in enrichmentProfiles) {
        final nameLower = profile.name.trim().toLowerCase();
        if (nameLower.isNotEmpty) {
          exactEnrichmentMap.putIfAbsent(nameLower, () => profile);
          final norm = normalizeFacultyName(profile.name);
          if (norm.isNotEmpty) {
            normEnrichmentMap.putIfAbsent(norm, () => profile);
          }
        }
        for (final alias in profile.aliases) {
          final aLower = alias.trim().toLowerCase();
          if (aLower.isNotEmpty) {
            exactEnrichmentMap.putIfAbsent(aLower, () => profile);
            final normA = normalizeFacultyName(alias);
            if (normA.isNotEmpty) {
              normEnrichmentMap.putIfAbsent(normA, () => profile);
            }
          }
        }
      }
    }

    final Map<String, FacultyProfile> profiles = {};

    for (final rawTeacher in timetableTeachers) {
      final clean = rawTeacher.trim();
      final stripped = stripDepartmentPrefix(clean);
      if (stripped.isEmpty ||
          stripped.toLowerCase() == 'unknown' ||
          stripped.toLowerCase() == 'na' ||
          stripped.toLowerCase() == 'staff' ||
          stripped.toLowerCase().startsWith('tbd') ||
          stripped.toLowerCase().startsWith('to be announced')) {
        continue;
      }

      final strippedLower = stripped.toLowerCase();
      final rawLower = clean.toLowerCase();
      final queryTitle = extractHonorificCategory(stripped);

      // 1. Determine Department
      String department = '';

      // Check raw teacher prefix code (e.g., 'BI Dr...', 'MS. Dr...')
      final tokens = clean.split(RegExp(r'\s+'));
      if (tokens.isNotEmpty) {
        final prefix = tokens.first.replaceAll('.', '').toLowerCase();
        final mappedDept = departmentNameFromCode(prefix);
        if (mappedDept != 'Academic Faculty') {
          department = mappedDept;
        }
      }

      // Check external department lookup (e.g. from pre-indexed active sessions)
      if (department.isEmpty && departmentLookup != null) {
        final lookupDept = departmentLookup(rawTeacher) ?? departmentLookup(stripped);
        if (lookupDept != null && lookupDept.isNotEmpty && lookupDept != 'Academic Faculty') {
          department = lookupDept;
        }
      }

      // 1.5 Fast O(1) enrichment profile matching
      FacultyProfile? matchedEnrichment;
      if (enrichmentProfiles.isNotEmpty) {
        final normStripped = normalizeFacultyName(stripped);
        FacultyProfile? candidate = exactEnrichmentMap[strippedLower] ??
            exactEnrichmentMap[rawLower] ??
            normEnrichmentMap[normStripped];

        if (candidate != null) {
          final candHonorific = extractHonorificCategory(candidate.name);
          if (!areHonorificsConflicting(queryTitle, candHonorific)) {
            matchedEnrichment = candidate;
          }
        }

        // Fallback to fuzzy match only if candidate not found via O(1) index
        matchedEnrichment ??= matchFacultyProfile(
          stripped,
          enrichmentProfiles,
          preferredDepartment: department.isNotEmpty ? department : null,
        );

        if (department.isEmpty && matchedEnrichment != null && matchedEnrichment.department.isNotEmpty) {
          department = matchedEnrichment.department;
        }
      }

      if (department.isEmpty) {
        department = 'Academic Faculty';
      }

      // 2. Determine Academic Designation
      String designation = '';
      if (strippedLower.contains('prof. dr.') || strippedLower.startsWith('prof.')) {
        designation = 'Professor';
      } else if (strippedLower.startsWith('dr.') || strippedLower.contains(' dr.')) {
        designation = 'Assistant Professor';
      } else if (strippedLower.startsWith('engr.') || strippedLower.contains('engr.')) {
        designation = 'Lecturer / Engineer';
      } else if (strippedLower.startsWith('ms.') || strippedLower.startsWith('mr.')) {
        designation = 'Lecturer';
      } else {
        designation = (matchedEnrichment != null && matchedEnrichment.designation.isNotEmpty)
            ? matchedEnrichment.designation
            : 'Faculty Member';
      }

      // 3. Location from timetable rooms or enrichment (O(1) pre-indexed lookup)
      final rooms = roomsLookup?.call(rawTeacher) ?? roomsLookup?.call(stripped) ?? const <String>[];
      String location = rooms.isNotEmpty ? rooms.take(3).join(', ') : '';
      if (location.isEmpty) {
        location = (matchedEnrichment != null && matchedEnrichment.location.isNotEmpty)
            ? matchedEnrichment.location
            : 'COMSATS Campus';
      }

      // 4. Contact & verified email
      final email = matchedEnrichment?.email ?? '';
      final contact = (matchedEnrichment != null && matchedEnrichment.contact.isNotEmpty)
          ? matchedEnrichment.contact
          : 'Campus Office';

      // Disambiguate key by department to allow legitimate same-name teachers across departments
      final deptKey = normalizeDepartment(department);
      final key = '${deptKey}_$strippedLower';

      if (profiles.containsKey(key)) {
        final existing = profiles[key]!;
        final combinedAliases = {...existing.aliases, rawTeacher, clean, stripped}.toList();
        profiles[key] = existing.copyWith(
          aliases: combinedAliases,
          location: existing.location == 'COMSATS Campus' && location != 'COMSATS Campus'
              ? location
              : existing.location,
          email: existing.email.isEmpty ? email : existing.email,
        );
      } else {
        profiles[key] = FacultyProfile(
          id: 'tt_${key.hashCode.abs()}',
          name: stripped,
          gender: matchedEnrichment?.gender ?? 'N/A',
          department: department,
          location: location,
          email: email,
          contact: contact,
          image: '', // Zero photo dependency
          designation: designation,
          aliases: [rawTeacher, clean, stripped],
        );
      }
    }

    final list = profiles.values.toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    if (list.isNotEmpty) {
      _cachedPureTimetableProfiles = list;
    }
    return list;
  }

  /// Returns a payload with items and source, for main.dart compatibility
  Future<FacultyFetchPayload> fetchLiveFirstWithFallbackPayload() async {
    final items = await fetchOfflineOnly();
    return FacultyFetchPayload(
      items: items,
      source: items.isNotEmpty ? HelpdeskFacultySource.cache : HelpdeskFacultySource.none,
    );
  }

  /// Returns only offline data (memory, cache, or asset)
  Future<List<FacultyProfile>> fetchOfflineOnly() async {
    if (_memoryCache.isNotEmpty) {
      return _memoryCache;
    }
    final cached = await _loadFromCache();
    if (cached.isNotEmpty) {
      _memoryCache = cached;
      return cached;
    }
    final backup = await _loadFromAsset();
    if (backup.isNotEmpty) {
      _memoryCache = backup;
      await _saveCache(backup);
      return backup;
    }
    return const [];
  }

  Future<void> _saveCache(List<FacultyProfile> items) async {
    final prefs = await SharedPreferences.getInstance();
    final payload = items.map((e) => e.toJson()).toList(growable: false);
    await prefs.setString(_cacheKey, jsonEncode(payload));
  }

  Future<List<FacultyProfile>> _loadFromCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_cacheKey);
      if (raw == null || raw.isEmpty) return const [];
      final dynamic decoded = jsonDecode(raw);
      if (decoded is! List) return const [];
      final items = decoded
          .whereType<Map<String, dynamic>>()
          .map(FacultyProfile.fromJson)
          .where((e) => e.name.trim().isNotEmpty)
          .toList();
      return deduplicateProfiles(items);
    } catch (_) {
      return const [];
    }
  }

  Future<List<FacultyProfile>> _loadFromAsset() async {
    try {
      final raw = await rootBundle.loadString(_assetPath);
      final dynamic decoded = jsonDecode(raw);
      final data = (decoded is Map<String, dynamic>) ? decoded['public'] : null;
      final faculty = (data is Map<String, dynamic>) ? data['faculty'] : null;
      if (faculty is! List) return const [];
      final items = faculty
          .whereType<Map<String, dynamic>>()
          .map(FacultyProfile.fromJson)
          .where((e) => e.name.trim().isNotEmpty)
          .toList();
      return deduplicateProfiles(items);
    } catch (_) {
      return const [];
    }
  }
}
