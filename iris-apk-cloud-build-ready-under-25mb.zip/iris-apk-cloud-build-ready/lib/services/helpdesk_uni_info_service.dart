import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

class UniInfoPayload {
  final List<dynamic> societies;
  final List<dynamic> alumni;
  final List<dynamic> books;

  const UniInfoPayload({
    required this.societies,
    required this.alumni,
    required this.books,
  });
}

class HelpdeskUniInfoService {
  static const String _primaryAssetPath =
      'assets/helpdesk_backup/helpdesk_full_snapshot_cli.json';
  static const String _fallbackAssetPath =
      'assets/helpdesk_backup/helpdesk_snapshot.json';

  static List<dynamic> _extractList(dynamic node) {
    if (node is List) return node;
    if (node is Map && node['data'] is List) return node['data'] as List;
    return const [];
  }

  Future<UniInfoPayload> fetchUniInfo() async {
    for (final path in [_primaryAssetPath, _fallbackAssetPath]) {
      try {
        final raw = await rootBundle.loadString(path);
        final dynamic decoded = jsonDecode(raw);
        if (decoded is! Map<String, dynamic>) continue;

        final container = decoded['public'] is Map<String, dynamic>
            ? decoded['public'] as Map<String, dynamic>
            : (decoded['data'] is Map<String, dynamic>
                  ? decoded['data'] as Map<String, dynamic>
                  : decoded);

        final societiesRaw = _extractList(container['societies']);
        final alumniRaw = _extractList(container['alumni']);
        final booksRaw = _extractList(container['books']);

        if (societiesRaw.isNotEmpty ||
            alumniRaw.isNotEmpty ||
            booksRaw.isNotEmpty) {
          return UniInfoPayload(
            societies: societiesRaw,
            alumni: alumniRaw,
            books: booksRaw,
          );
        }
      } catch (_) {}
    }
    return const UniInfoPayload(societies: [], alumni: [], books: []);
  }
}
