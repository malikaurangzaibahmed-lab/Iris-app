import 'package:iris/core/models.dart';
import 'package:iris/core/format_guard.dart';
import 'room_persistence_service.dart';
import 'remote_config_service.dart';

class RoomOccupancyService {
  final Map<String, Room> _rooms = {};
  final Map<String, Department> _departments = {};
  static final Map<String, RoomLocationDetails> _parsedLocationCache = {};
  final Map<int, Map<String, List<ClassSession>>> _daySessionIndexCache = {};
  static final Map<String, List<TimeSlot>> _dynamicSlotsCache = {};

  // Standard 85-minute university lecture slots
  static const List<TimeSlot> standardSlots = [
    TimeSlot(8.5, 9.9167),
    TimeSlot(9.9167, 11.3333),
    TimeSlot(11.3333, 12.75),
    TimeSlot(13.6667, 15.0833),
    TimeSlot(15.0833, 16.5),
  ];

  // Official 1-hour cut-off lecture slots (aligned with official slot starts)
  static const List<TimeSlot> standardCutOffSlots = [
    TimeSlot(8.5, 9.5),
    TimeSlot(9.9167, 10.9167),
    TimeSlot(11.3333, 12.3333),
    TimeSlot(13.6667, 14.6667),
    TimeSlot(15.0833, 16.0833),
  ];

  // Friday special 2-hour lab / lecture slot
  static const TimeSlot fridaySlot3Lab = TimeSlot(11.3333, 13.3333);

  // Ramadan 60-minute university lecture slots
  static const List<TimeSlot> ramadanSlots = [
    TimeSlot(8.5, 9.5),
    TimeSlot(9.5, 10.5),
    TimeSlot(10.5, 11.5),
    TimeSlot(11.5, 12.5),
    TimeSlot(12.5, 13.5),
    TimeSlot(13.5, 14.5),
  ];

  static List<TimeSlot> getDefaultSlots({String? period, int? dayIndex}) {
    final activePeriod = period ?? RemoteConfigService.activeAcademicPeriod.value;
    if (activePeriod == 'ramadan') {
      return ramadanSlots;
    }
    return standardSlots;
  }

  void clearSessionCache() {
    _daySessionIndexCache.clear();
    _dynamicSlotsCache.clear();
  }

  void registerDepartment(String departmentId, String departmentName) {
    _departments[departmentId] = Department(
      id: departmentId,
      name: departmentName,
      registeredAt: DateTime.now(),
    );
  }

  void registerRoom(String roomId, String building, int capacity, List<String> amenities) {
    final cleanId = FormatGuard.sanitizeRoom(roomId);
    _rooms[cleanId] = Room(
      id: cleanId,
      building: building,
      capacity: capacity,
      amenities: amenities,
      registeredAt: DateTime.now(),
    );
  }

  void registerRoomModel(Room room) {
    final cleanId = FormatGuard.sanitizeRoom(room.id);
    _rooms[cleanId] = room;
  }

  static String _getFormattedLocation(String roomId) {
    return _parsedLocationCache.putIfAbsent(
      roomId,
      () => RoomPersistenceService.parseRoomCode(roomId),
    ).formattedLocation;
  }

  /// Helper to index sessions by roomId + dayIndex with caching
  Map<String, List<ClassSession>> _indexSessionsByRoomDay(
    List<ClassSession> allSessions,
    int dayIndex,
  ) {
    if (_daySessionIndexCache.containsKey(dayIndex)) {
      return _daySessionIndexCache[dayIndex]!;
    }
    final map = <String, List<ClassSession>>{};
    for (final s in allSessions) {
      if (s.dayIndex == dayIndex) {
        final cleanRoom = FormatGuard.sanitizeRoom(s.room);
        map.putIfAbsent(cleanRoom, () => []).add(s);
      }
    }
    _daySessionIndexCache[dayIndex] = map;
    return map;
  }

  static List<TimeSlot> extractDynamicSlots(
    List<ClassSession> allSessions,
    int dayIndex, {
    String? period,
  }) {
    return getDefaultSlots(period: period, dayIndex: dayIndex);
  }

  List<bool> _calculateSlotOccupancy(List<ClassSession> roomSessions, List<TimeSlot> slots) {
    if (roomSessions.isEmpty) return List.filled(slots.length, false);
    return List<bool>.generate(slots.length, (slotIndex) {
      final slotMiddle = slots[slotIndex].start + (slots[slotIndex].end - slots[slotIndex].start) / 2;
      return roomSessions.any((s) => s.safeStartVal <= slotMiddle && slotMiddle < s.actualEndVal);
    });
  }

  /// Get all available rooms right now
  List<RoomAvailability> getAvailableRoomsNow(
    List<ClassSession> allSessions,
  ) {
    final now = DateTime.now();
    final currentHour = now.hour + (now.minute / 60.0);
    final dayIndex = now.weekday;

    return _computeRoomAvailability(allSessions, currentHour, dayIndex);
  }

  /// Get availability for a specific future time
  List<RoomAvailability> getRoomAvailabilityAt(
    List<ClassSession> allSessions,
    double targetHour,
    int dayIndex,
  ) {
    return _computeRoomAvailability(allSessions, targetHour, dayIndex);
  }

  List<RoomAvailability> _computeRoomAvailability(
    List<ClassSession> allSessions,
    double targetHour,
    int dayIndex,
  ) {
    final indexedSessions = _indexSessionsByRoomDay(allSessions, dayIndex);
    final dynamicSlots = extractDynamicSlots(allSessions, dayIndex);
    final rawAvailability = <RoomAvailability>[];

    for (final room in _rooms.values) {
      final cleanRoomId = FormatGuard.sanitizeRoom(room.id);
      final roomSessions = indexedSessions[cleanRoomId] ?? const <ClassSession>[];

      ClassSession? occupyingSession;
      for (final s in roomSessions) {
        if (s.safeStartVal <= targetHour && targetHour < s.actualEndVal) {
          occupyingSession = s;
          break;
        }
      }

      final isAvailable = occupyingSession == null;
      ClassSession? nextSession;
      if (isAvailable && roomSessions.isNotEmpty) {
        for (final s in roomSessions) {
          if (s.safeStartVal > targetHour) {
            if (nextSession == null || s.safeStartVal < nextSession.safeStartVal) {
              nextSession = s;
            }
          }
        }
      }

      final slotOccupancy = _calculateSlotOccupancy(roomSessions, dynamicSlots);
      final formattedLoc = _getFormattedLocation(room.id);

      if (isAvailable) {
        rawAvailability.add(RoomAvailability(
          roomId: room.id,
          building: room.building,
          capacity: room.capacity,
          amenities: room.amenities,
          isAvailable: true,
          occupiedUntil: null,
          nextSessionAt: nextSession?.safeStartVal,
          nextSessionSubject: nextSession?.subject,
          minulesFreeUntilNextSession: nextSession != null
              ? ((nextSession.safeStartVal - targetHour) * 60).toInt()
              : null,
          studyScore: 0,
          slotOccupancy: slotOccupancy,
          formattedLocation: formattedLoc,
        ));
      } else {
        rawAvailability.add(RoomAvailability(
          roomId: room.id,
          building: room.building,
          capacity: room.capacity,
          amenities: room.amenities,
          isAvailable: false,
          occupiedUntil: occupyingSession.actualEndVal,
          occupiedBy: occupyingSession.subject,
          occupiedByTeacher: occupyingSession.teacher,
          minulesFreeUntilNextSession: ((occupyingSession.actualEndVal - targetHour) * 60).toInt(),
          studyScore: 0,
          slotOccupancy: slotOccupancy,
          formattedLocation: formattedLoc,
        ));
      }
    }

    final availability = rawAvailability.map((a) {
      if (!a.isAvailable) return a;
      final room = _rooms[a.roomId]!;
      ClassSession? nextSession;
      final cleanRoomId = FormatGuard.sanitizeRoom(room.id);
      final roomSessions = indexedSessions[cleanRoomId] ?? const <ClassSession>[];
      for (final s in roomSessions) {
        if (s.safeStartVal > targetHour) {
          if (nextSession == null || s.safeStartVal < nextSession.safeStartVal) {
            nextSession = s;
          }
        }
      }

      return RoomAvailability(
        roomId: a.roomId,
        building: a.building,
        capacity: a.capacity,
        amenities: a.amenities,
        isAvailable: true,
        occupiedUntil: null,
        nextSessionAt: a.nextSessionAt,
        nextSessionSubject: a.nextSessionSubject,
        minulesFreeUntilNextSession: a.minulesFreeUntilNextSession,
        studyScore: _calculateStudyScore(room, nextSession, rawAvailability),
        slotOccupancy: a.slotOccupancy,
        formattedLocation: a.formattedLocation,
      );
    }).toList();

    availability.sort((a, b) => b.studyScore.compareTo(a.studyScore));
    return availability;
  }

  /// Get availability for a specific time range (e.g. standard university slot)
  List<RoomAvailability> getRoomAvailabilityForSlotRange(
    List<ClassSession> allSessions,
    double startHour,
    double endHour,
    int dayIndex,
  ) {
    final indexedSessions = _indexSessionsByRoomDay(allSessions, dayIndex);
    final dynamicSlots = extractDynamicSlots(allSessions, dayIndex);
    final rawAvailability = <RoomAvailability>[];

    for (final room in _rooms.values) {
      final cleanRoomId = FormatGuard.sanitizeRoom(room.id);
      final roomSessions = indexedSessions[cleanRoomId] ?? const <ClassSession>[];

      ClassSession? occupyingSession;
      for (final s in roomSessions) {
        if (s.safeStartVal < (endHour - 0.03) && s.actualEndVal > (startHour + 0.03)) {
          occupyingSession = s;
          break;
        }
      }

      final isAvailable = occupyingSession == null;
      ClassSession? nextSession;
      if (isAvailable && roomSessions.isNotEmpty) {
        for (final s in roomSessions) {
          if (s.safeStartVal >= (endHour - 0.03)) {
            if (nextSession == null || s.safeStartVal < nextSession.safeStartVal) {
              nextSession = s;
            }
          }
        }
      }

      final slotOccupancy = _calculateSlotOccupancy(roomSessions, dynamicSlots);
      final formattedLoc = _getFormattedLocation(room.id);

      if (isAvailable) {
        rawAvailability.add(RoomAvailability(
          roomId: room.id,
          building: room.building,
          capacity: room.capacity,
          amenities: room.amenities,
          isAvailable: true,
          occupiedUntil: null,
          nextSessionAt: nextSession?.safeStartVal,
          nextSessionSubject: nextSession?.subject,
          minulesFreeUntilNextSession: nextSession != null
              ? ((nextSession.safeStartVal - startHour) * 60).toInt()
              : null,
          studyScore: 0,
          slotOccupancy: slotOccupancy,
          formattedLocation: formattedLoc,
        ));
      } else {
        rawAvailability.add(RoomAvailability(
          roomId: room.id,
          building: room.building,
          capacity: room.capacity,
          amenities: room.amenities,
          isAvailable: false,
          occupiedUntil: occupyingSession.actualEndVal,
          occupiedBy: occupyingSession.subject,
          occupiedByTeacher: occupyingSession.teacher,
          minulesFreeUntilNextSession: ((occupyingSession.actualEndVal - startHour) * 60).toInt(),
          studyScore: 0,
          slotOccupancy: slotOccupancy,
          formattedLocation: formattedLoc,
        ));
      }
    }

    final availability = rawAvailability.map((a) {
      if (!a.isAvailable) return a;
      final room = _rooms[a.roomId]!;
      ClassSession? nextSession;
      final cleanRoomId = FormatGuard.sanitizeRoom(room.id);
      final roomSessions = indexedSessions[cleanRoomId] ?? const <ClassSession>[];
      for (final s in roomSessions) {
        if (s.safeStartVal >= (endHour - 0.03)) {
          if (nextSession == null || s.safeStartVal < nextSession.safeStartVal) {
            nextSession = s;
          }
        }
      }

      return RoomAvailability(
        roomId: a.roomId,
        building: a.building,
        capacity: a.capacity,
        amenities: a.amenities,
        isAvailable: true,
        occupiedUntil: null,
        nextSessionAt: a.nextSessionAt,
        nextSessionSubject: a.nextSessionSubject,
        minulesFreeUntilNextSession: a.minulesFreeUntilNextSession,
        studyScore: _calculateStudyScore(room, nextSession, rawAvailability),
        slotOccupancy: a.slotOccupancy,
        formattedLocation: a.formattedLocation,
      );
    }).toList();

    availability.sort((a, b) {
      if (a.isAvailable != b.isAvailable) {
        return a.isAvailable ? -1 : 1;
      }
      return b.studyScore.compareTo(a.studyScore);
    });
    return availability;
  }

  /// Get available rooms for a specific time RANGE (not just a point in time)
  /// Check if room is free for entire duration
  List<String> getAvailableRoomsForTimeRange(
    List<ClassSession> allSessions,
    int dayIndex,
    double startTime,
    double endTime,
  ) {
    final availableRooms = <String>[];

    for (final room in _rooms.values) {
      final cleanRoomId = FormatGuard.sanitizeRoom(room.id);
      // Check if any session overlaps with this time range
      final conflicts = allSessions.where((s) =>
          FormatGuard.sanitizeRoom(s.room) == cleanRoomId &&
          s.dayIndex == dayIndex &&
          // Overlap check: not (one ends before other starts)
          !(s.actualEndVal <= startTime || s.safeStartVal >= endTime));

      if (conflicts.isEmpty) {
        availableRooms.add(room.id);
      }
    }

    return availableRooms;
  }

  /// Detect room conflicts across departments
  List<RoomConflict> detectRoomConflicts(List<ClassSession> allSessions) {
    final conflicts = <RoomConflict>[];
    final sessionsByRoom = <String, List<ClassSession>>{};

    // Group sessions by room
    for (final session in allSessions) {
      final cleanRoom = FormatGuard.sanitizeRoom(session.room);
      sessionsByRoom.putIfAbsent(cleanRoom, () => []).add(session);
    }

    // Check for overlaps in each room
    for (final sessions in sessionsByRoom.values) {
      for (int i = 0; i < sessions.length; i++) {
        for (int j = i + 1; j < sessions.length; j++) {
          final s1 = sessions[i];
          final s2 = sessions[j];

          // Check if same day and time overlap
          if (s1.dayIndex == s2.dayIndex &&
              !(s1.actualEndVal <= s2.safeStartVal || s2.actualEndVal <= s1.safeStartVal)) {
            conflicts.add(RoomConflict(
              room: s1.room,
              session1: s1,
              session2: s2,
              overlapMinutes:
                  ((_getMinTime(s1.actualEndVal, s2.actualEndVal) - _getMaxTime(s1.safeStartVal, s2.safeStartVal)) * 60).toInt(),
              severity: _calculateConflictSeverity(s1, s2),
            ));
          }
        }
      }
    }

    return conflicts;
  }

  /// Get occupancy heatmap for a room across the week
  Map<String, double> getRoomHeatmap(String roomId, List<ClassSession> allSessions) {
    final heatmap = <String, double>{};
    final cleanTarget = FormatGuard.sanitizeRoom(roomId);
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    const hours = [
      '08:00', '09:00', '10:00', '11:00', '12:00', '13:00',
      '14:00', '15:00', '16:00', '17:00', '18:00'
    ];

    // Initialize heatmap
    for (final day in days) {
      for (final hour in hours) {
        heatmap['$day-$hour'] = 0.0;
      }
    }

    // Calculate occupancy density
    for (final session in allSessions) {
      if (FormatGuard.sanitizeRoom(session.room) == cleanTarget) {
        final day = days[session.dayIndex - 1];
        final startHour = session.safeStartVal.toInt();
        final baseName = '$day-$startHour:00';
        heatmap[baseName] = (heatmap[baseName] ?? 0.0) + 1.0;
      }
    }

    return heatmap;
  }

  /// Smart recommendation engine
  RoomRecommendation getSmartRecommendation(
    List<ClassSession> allSessions,
    List<ClassSession> userSchedule,
    int proximityPreference, // 0-100, higher = closer to user's classes
  ) {
    final now = DateTime.now();
    final currentHour = now.hour + (now.minute / 60.0);
    final available = getAvailableRoomsNow(allSessions);

    if (available.isEmpty) {
      return RoomRecommendation(
        recommended: null,
        reason: 'No study spaces available right now',
        alternatives: [],
      );
    }

    // Find user's next class room
    final nextUserClass = userSchedule
        .where((s) =>
            s.dayIndex == now.weekday && s.safeStartVal > currentHour)
        .fold<ClassSession?>(null, (prev, current) =>
            prev == null || current.safeStartVal < prev.safeStartVal
                ? current
                : prev);

    // Score rooms based on:
    // 1. Time until next occupied (longer is better)
    // 2. Proximity to next user class
    final scoredRooms = available.map((room) {
      double score = room.studyScore;

      // Bonus for being near user's next class
      if (nextUserClass != null) {
        final sameBuilding = room.building == nextUserClass.room.split('-').first;
        if (sameBuilding) {
          score += (proximityPreference / 100.0) * 30; // Up to +30 for same building
        }
      }

      return MapEntry(room, score);
    }).toList();

    scoredRooms.sort((a, b) => b.value.compareTo(a.value));

    final best = scoredRooms.first.key;
    final alternatives = scoredRooms.skip(1).take(3).map((e) => e.key).toList();

    String reason = 'Quiet space in ${best.building}';
    if (best.minulesFreeUntilNextSession != null) {
      reason += ' • Free for ${best.minulesFreeUntilNextSession} mins';
    } else {
      reason += ' • Free rest of day';
    }

    return RoomRecommendation(
      recommended: best,
      reason: reason,
      alternatives: alternatives,
    );
  }

  double _calculateStudyScore(Room room, ClassSession? nextSession, List<RoomAvailability> allAvailability) {
    double score = 100.0;
    
    // 1. Duration Bonus: Longer free time is better for study
    if (nextSession != null) {
      final now = DateTime.now();
      final currentHour = now.hour + (now.minute / 60.0);
      final freeMinutes = (nextSession.safeStartVal - currentHour) * 60;
      
      if (freeMinutes < 30) {
        score -= 40; // Too short
      } else if (freeMinutes < 60) {
        score -= 20;
      } else {
        score += 10; // Good duration
      }
    } else {
      score += 20; // Free for the rest of the day
    }
    
    // 2. Noise Level Estimation: How many occupied rooms are in the same building?
    final buildingOccupancy = allAvailability.where((a) => a.building == room.building && !a.isAvailable).length;
    final buildingTotal = allAvailability.where((a) => a.building == room.building).length;
    
    if (buildingTotal > 0) {
      double density = buildingOccupancy / buildingTotal;
      score -= (density * 30); // Higher density = lower study score (potential noise)
    }
    
    // 3. Amenity Bonus
    if (room.amenities.contains('AC')) score += 15;
    if (room.amenities.contains('PC')) score += 10;
    if (room.amenities.contains('Internet')) score += 5;
    
    return score.clamp(0, 100);
  }

  String _calculateConflictSeverity(ClassSession s1, ClassSession s2) {
    final overlap = _getMinTime(s1.actualEndVal, s2.actualEndVal) -
        _getMaxTime(s1.safeStartVal, s2.safeStartVal);
    if (overlap >= 0.5) return 'HIGH';
    if (overlap >= 0.25) return 'MEDIUM';
    return 'LOW';
  }

  double _getMinTime(double a, double b) => a < b ? a : b;
  double _getMaxTime(double a, double b) => a > b ? a : b;

  /// Get all sessions for a specific room on a given day, ordered by start time
  List<ClassSession> getRoomSchedule(
    List<ClassSession> allSessions,
    String roomId,
    int dayIndex,
  ) {
    final cleanRoomId = FormatGuard.sanitizeRoom(roomId);
    final sessions = allSessions
        .where((s) => s.dayIndex == dayIndex && FormatGuard.sanitizeRoom(s.room) == cleanRoomId)
        .toList()
      ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));
    return sessions;
  }
}
