import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter/foundation.dart' show debugPrint;
import 'package:shared_preferences/shared_preferences.dart';
import '../core/models.dart';

class RoomLocationDetails {
  final String block;
  final String floor;
  final String roomName;
  final int floorNumber;
  final String? attendant;
  final String? mobile;

  const RoomLocationDetails({
    required this.block,
    required this.floor,
    required this.roomName,
    required this.floorNumber,
    this.attendant,
    this.mobile,
  });

  String get formattedLocation {
    if (block == 'Other') {
      return roomName;
    }
    return '$block • $floor • $roomName';
  }
}

class RoomPersistenceService {
  static const String _key = 'iris_rooms';

  static const Map<String, RoomLocationDetails> _groundTruthRooms = {
    'CLAB1': RoomLocationDetails(block: 'C Block', floor: '1st Floor', roomName: 'Clab-1', floorNumber: 1, attendant: 'Mr. Khan Shabir', mobile: '03004083616'),
    'CLAB2': RoomLocationDetails(block: 'C Block', floor: '1st Floor', roomName: 'Clab-2', floorNumber: 1, attendant: 'Mr. Jawad', mobile: '03057351584'),
    'CLAB3': RoomLocationDetails(block: 'C Block', floor: '1st Floor', roomName: 'Clab-3', floorNumber: 1, attendant: 'Mr. Nadeem Akhtar', mobile: '03006937881'),
    'CLAB4': RoomLocationDetails(block: 'C Block', floor: '1st Floor', roomName: 'Clab-4', floorNumber: 1, attendant: 'Mr. Wasim Akram', mobile: '03088371674'),
    'CLAB5': RoomLocationDetails(block: 'C Block', floor: '2nd Floor', roomName: 'Clab-5', floorNumber: 2, attendant: 'Mr. M. Kaleem', mobile: '03441620786'),
    'CLAB6': RoomLocationDetails(block: 'C Block', floor: '2nd Floor', roomName: 'Clab-6', floorNumber: 2, attendant: 'Mr. Sajjad', mobile: '03003784327'),
    'CLAB7': RoomLocationDetails(block: 'C Block', floor: '2nd Floor', roomName: 'Clab-7', floorNumber: 2, attendant: 'Mr. Mubeen Lodhi', mobile: '03063977109'),
    'CLAB8': RoomLocationDetails(block: 'C Block', floor: '2nd Floor', roomName: 'Clab-8', floorNumber: 2, attendant: 'Mr. Ashraf Zia', mobile: '03457837544'),
    'CLAB9': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'Clab-9', floorNumber: 0, attendant: 'Mr. Salman', mobile: '03017994428'),
    'CLAB10': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'Clab-10', floorNumber: 0, attendant: 'Mr. Ghulam Shabir', mobile: '03048290567'),
    'CLAB11': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'Clab-11', floorNumber: 1, attendant: 'Mr. Khalid Nawaz', mobile: '03016859658'),
    'CLAB12': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'Clab-12', floorNumber: 1, attendant: 'Mr. Nadeem Akhtar', mobile: '03040447147'),
    'A1': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'A-1', floorNumber: 0),
    'A2': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'A-2', floorNumber: 0),
    'LIBRARY': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'Library', floorNumber: 0),
    'ADMINOFFICE': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'Admin Office', floorNumber: 0),
    'CONFERENCEROOM': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'Conference Room', floorNumber: 0),
    'FIRSTAID': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'First aid', floorNumber: 0),
    'BADMINTONCOURT': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'Badminton Court', floorNumber: 0),
    'OFFICEOFMECHANICALENGINEERING': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'Office of mechanical engineering', floorNumber: 0),
    'HODOFFICEOFMECHANICALENGINEERING': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'HOD office of Mechanical Engineering', floorNumber: 0),
    'MECHANICSOFMATERIALLABORATORY': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'Mechanics of material Laboratory', floorNumber: 0),
    'THERMODYNAMICANDENGINELABORATORY': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'Thermodynamic and Engine Laboratory', floorNumber: 0),
    'ENGINEERINGMECHANICSLABORATORY': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'Engineering Mechanics Laboratory', floorNumber: 0),
    'SERVERROOM': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'Server Room', floorNumber: 0),
    'ITDEPARTMENTOFFICE': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'IT department office', floorNumber: 0),
    'REGISTRATIONOFFICEOFHUMANRESOURCESDEPARTMENT': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'Registration office of human resources department', floorNumber: 0),
    'JUNAIDZAIDIAUDITORIUM': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'Junaid Zaidi Auditorium', floorNumber: 1),
    'A11': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'A-1.1', floorNumber: 1),
    'A12': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'A-1.2', floorNumber: 1),
    'A13': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'A-1.3', floorNumber: 1),
    'PHYSICSLAB': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'Physics Lab', floorNumber: 1),
    'HEATANDMASSTRANSFERLABORATORY': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'Heat and mass transfer laboratory', floorNumber: 1),
    'REFRIGERATIONANDCONDUCTIONLABORATORY': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'Refrigeration and conduction laboratory', floorNumber: 1),
    'RECEPTIONSECTIONANDFEECHALLANISSUANCE': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'Reception section and fee challan issuance', floorNumber: 1),
    'PURCHASEANDSTOREDEPTT': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'Purchase and store DEPTT.', floorNumber: 1),
    'TREASUREOFFICE': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'Treasure office', floorNumber: 1),
    'MECHANICSANDMACHINELABORATORY': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'Mechanics and machine laboratory', floorNumber: 1),
    'FLUIDMECHANICSLABORATORY': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'Fluid mechanics laboratory', floorNumber: 1),
    'INSTRUMENTATIONANDCONTROLLAB': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'Instrumentation and control lab', floorNumber: 1),
    'A21': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'A-2.1', floorNumber: 2),
    'A22': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'A-2.2', floorNumber: 2),
    'A23': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'A-2.3', floorNumber: 2),
    'A24': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'A-2.4', floorNumber: 2),
    'A25': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'A-2.5', floorNumber: 2),
    'A26': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'A-2.6', floorNumber: 2),
    'A27': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'A-2.7', floorNumber: 2),
    'CLAB13': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'C Lab 13', floorNumber: 2),
    'DLDLAB': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'DLD Lab', floorNumber: 2),
    'NETWORKINGLAB': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'Networking Lab', floorNumber: 2),
    'POWERELECTRONICSLAB': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'Power electronics lab', floorNumber: 2),
    'CIRCUITSANDELECTRONICSLABORATORY': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'Circuits and electronics laboratory', floorNumber: 2),
    'DCOOFFICEOFELECTRICALENGINEERING': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'DCO office of Electrical engineering', floorNumber: 2),
    'B1': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'B-1', floorNumber: 0),
    'B2': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'B-2', floorNumber: 0),
    'B3': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'B-3', floorNumber: 0),
    'B4': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'B-4', floorNumber: 0),
    'B5': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'B-5', floorNumber: 0),
    'B6': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'B-6', floorNumber: 0),
    'B7': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'B-7', floorNumber: 0),
    'B8': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'B-8', floorNumber: 0),
    'B9': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'B-9', floorNumber: 0),
    'B10': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'B-10', floorNumber: 0),
    'B11': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'B-11', floorNumber: 0),
    'B12': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'B-12', floorNumber: 0),
    'B13': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'B-13', floorNumber: 0),
    'B14': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'B-14', floorNumber: 0),
    'CLAB14': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'C Lab 14', floorNumber: 0),
    'FACULTYOFFICES': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'Faculty offices', floorNumber: 0),
    'HODOFMANAGEMENTSCIENCE': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'HOD of Management Science', floorNumber: 0),
    'SEMINARROOM': RoomLocationDetails(block: 'B Block', floor: 'Ground Floor', roomName: 'Seminar Room', floorNumber: 0),
    'C1': RoomLocationDetails(block: 'C Block', floor: 'Ground Floor', roomName: 'C-1', floorNumber: 0),
    'C2': RoomLocationDetails(block: 'C Block', floor: 'Ground Floor', roomName: 'C-2', floorNumber: 0),
    'C3': RoomLocationDetails(block: 'C Block', floor: 'Ground Floor', roomName: 'C-3', floorNumber: 0),
    'C4': RoomLocationDetails(block: 'C Block', floor: 'Ground Floor', roomName: 'C-4', floorNumber: 0),
    'C5': RoomLocationDetails(block: 'C Block', floor: 'Ground Floor', roomName: 'C-5', floorNumber: 0),
    'HODOFFICEOFCOMPUTERSCIENCE': RoomLocationDetails(block: 'C Block', floor: 'Ground Floor', roomName: 'HOD office of Computer Science', floorNumber: 0),
    'HODOFFICEOFBIOSCIENCE': RoomLocationDetails(block: 'C Block', floor: 'Ground Floor', roomName: 'HOD office of Bio-Science', floorNumber: 0),
    'DCOOFFICEOFCOMPUTERSCIENCE': RoomLocationDetails(block: 'C Block', floor: 'Ground Floor', roomName: 'DCO office of Computer Science', floorNumber: 0),
    'HODOFFICEOFMATHEMATICS': RoomLocationDetails(block: 'C Block', floor: 'Ground Floor', roomName: 'HOD office of Mathematics', floorNumber: 0),
    'C11': RoomLocationDetails(block: 'C Block', floor: '1st Floor', roomName: 'C-1.1', floorNumber: 1),
    'C12': RoomLocationDetails(block: 'C Block', floor: '1st Floor', roomName: 'C-1.2', floorNumber: 1),
    'C13': RoomLocationDetails(block: 'C Block', floor: '1st Floor', roomName: 'C-1.3', floorNumber: 1),
    'C14': RoomLocationDetails(block: 'C Block', floor: '1st Floor', roomName: 'C-1.4', floorNumber: 1),
    'C15': RoomLocationDetails(block: 'C Block', floor: '1st Floor', roomName: 'C-1.5', floorNumber: 1),
    'C16': RoomLocationDetails(block: 'C Block', floor: '1st Floor', roomName: 'C-1.6', floorNumber: 1),
    'C17': RoomLocationDetails(block: 'C Block', floor: '1st Floor', roomName: 'C-1.7', floorNumber: 1),
    'GIRLSCOMMONROOM': RoomLocationDetails(block: 'C Block', floor: '1st Floor', roomName: 'Girls Common Room', floorNumber: 1),
    'RESEARCHCENTER': RoomLocationDetails(block: 'C Block', floor: '1st Floor', roomName: 'Research center', floorNumber: 1),
    'ITOFFICE': RoomLocationDetails(block: 'C Block', floor: '1st Floor', roomName: 'IT office', floorNumber: 1),
    'C21': RoomLocationDetails(block: 'C Block', floor: '2nd Floor', roomName: 'C-2.1', floorNumber: 2),
    'C22': RoomLocationDetails(block: 'C Block', floor: '2nd Floor', roomName: 'C-2.2', floorNumber: 2),
    'C23': RoomLocationDetails(block: 'C Block', floor: '2nd Floor', roomName: 'C-2.3', floorNumber: 2),
    'C24': RoomLocationDetails(block: 'C Block', floor: '2nd Floor', roomName: 'C-2.4', floorNumber: 2),
    'C25': RoomLocationDetails(block: 'C Block', floor: '2nd Floor', roomName: 'C-2.5', floorNumber: 2),
    'FYPSELAB': RoomLocationDetails(block: 'C Block', floor: '2nd Floor', roomName: 'FYP-SE Lab', floorNumber: 2),
    'D1': RoomLocationDetails(block: 'D Block', floor: 'Ground Floor', roomName: 'D-1', floorNumber: 0),
    'D2': RoomLocationDetails(block: 'D Block', floor: 'Ground Floor', roomName: 'D-2', floorNumber: 0),
    'D3': RoomLocationDetails(block: 'D Block', floor: 'Ground Floor', roomName: 'D-3', floorNumber: 0),
    'D4': RoomLocationDetails(block: 'D Block', floor: 'Ground Floor', roomName: 'D-4', floorNumber: 0),
    'D5': RoomLocationDetails(block: 'D Block', floor: 'Ground Floor', roomName: 'D-5', floorNumber: 0),
    'D6': RoomLocationDetails(block: 'D Block', floor: 'Ground Floor', roomName: 'D-6', floorNumber: 0),
    'D7': RoomLocationDetails(block: 'D Block', floor: 'Ground Floor', roomName: 'D-7', floorNumber: 0),
    'D8': RoomLocationDetails(block: 'D Block', floor: 'Ground Floor', roomName: 'D-8', floorNumber: 0),
    'D9': RoomLocationDetails(block: 'D Block', floor: 'Ground Floor', roomName: 'D-9', floorNumber: 0),
    'NUTRITIONLAB': RoomLocationDetails(block: 'D Block', floor: 'Ground Floor', roomName: 'Nutrition Lab', floorNumber: 0),
    'FOODPROCESSINGLAB': RoomLocationDetails(block: 'D Block', floor: 'Ground Floor', roomName: 'Food Processing Lab', floorNumber: 0),
    'STOREROOM': RoomLocationDetails(block: 'D Block', floor: 'Ground Floor', roomName: 'Store Room', floorNumber: 0),
    'FACULTYOFFICES1': RoomLocationDetails(block: 'D Block', floor: '1st Floor', roomName: 'Faculty Offices 1', floorNumber: 1),
    'FACULTYOFFICES2': RoomLocationDetails(block: 'D Block', floor: '1st Floor', roomName: 'Faculty Offices 2', floorNumber: 1),
    'PROJECTLAB': RoomLocationDetails(block: 'W Block', floor: 'Ground Floor', roomName: 'Project Lab', floorNumber: 0),
    'MACHINESHOP': RoomLocationDetails(block: 'W Block', floor: 'Ground Floor', roomName: 'Machine Shop', floorNumber: 0),
    'FITTINGSHOP': RoomLocationDetails(block: 'W Block', floor: 'Ground Floor', roomName: 'Fitting Shop', floorNumber: 0),
    'CNCLAB': RoomLocationDetails(block: 'W Block', floor: 'Ground Floor', roomName: 'CNC Lab', floorNumber: 0),
    'UTMLAB': RoomLocationDetails(block: 'W Block', floor: 'Ground Floor', roomName: 'UTM Lab', floorNumber: 0),
    'GEOTECHNICALLAB': RoomLocationDetails(block: 'W Block', floor: 'Ground Floor', roomName: 'Geotechnical Lab', floorNumber: 0),
    'W1': RoomLocationDetails(block: 'W Block', floor: '1st Floor', roomName: 'W-1', floorNumber: 1),
    'W2': RoomLocationDetails(block: 'W Block', floor: '1st Floor', roomName: 'W-2', floorNumber: 1),
    'W3': RoomLocationDetails(block: 'W Block', floor: '1st Floor', roomName: 'W-3', floorNumber: 1),
    'W4': RoomLocationDetails(block: 'W Block', floor: '1st Floor', roomName: 'W-4', floorNumber: 1),
    'CARPENTRYSHOP': RoomLocationDetails(block: 'W Block', floor: '2nd Floor', roomName: 'Carpentry Shop', floorNumber: 2),
    'WATERSUPPLYENGINEERINGLABORATORY': RoomLocationDetails(block: 'W Block', floor: '2nd Floor', roomName: 'Water supply engineering laboratory', floorNumber: 2),
    'MECHANICSOFSOLIDSLABORATORY': RoomLocationDetails(block: 'W Block', floor: '2nd Floor', roomName: 'Mechanics of solids laboratory', floorNumber: 2),
    'ADMISSIONS&INFORMATIONDESK': RoomLocationDetails(block: 'Admission Block', floor: 'Ground Floor', roomName: 'Admissions & Information Desk', floorNumber: 0),
    'ADMISSIONSINFORMATIONDESK': RoomLocationDetails(block: 'Admission Block', floor: 'Ground Floor', roomName: 'Admissions & Information Desk', floorNumber: 0),
    'FEE&CHALLANCLEARANCEDESK': RoomLocationDetails(block: 'Admission Block', floor: 'Ground Floor', roomName: 'Fee & Challan Clearance Desk', floorNumber: 0),
    'FEECHALLANCLEARANCEDESK': RoomLocationDetails(block: 'Admission Block', floor: 'Ground Floor', roomName: 'Fee & Challan Clearance Desk', floorNumber: 0),
    'TRANSPORT&BUSPASSCELL': RoomLocationDetails(block: 'Admission Block', floor: 'Ground Floor', roomName: 'Transport & Bus Pass Cell', floorNumber: 0),
    'TRANSPORTBUSPASSCELL': RoomLocationDetails(block: 'Admission Block', floor: 'Ground Floor', roomName: 'Transport & Bus Pass Cell', floorNumber: 0),
    'SCHOLARSHIPS&FINANCIALAID(EHSAAS/HEC)': RoomLocationDetails(block: 'Admission Block', floor: 'Ground Floor', roomName: 'Scholarships & Financial Aid (EHSAAS / HEC)', floorNumber: 0),
    'SCHOLARSHIPSFINANCIALAIDEHSAASHEC': RoomLocationDetails(block: 'Admission Block', floor: 'Ground Floor', roomName: 'Scholarships & Financial Aid (EHSAAS / HEC)', floorNumber: 0),
    'STUDENTAFFAIRS&REGISTRAROFFICE': RoomLocationDetails(block: 'Admission Block', floor: 'Ground Floor', roomName: 'Student Affairs & Registrar Office', floorNumber: 0),
    'STUDENTAFFAIRSREGISTRAROFFICE': RoomLocationDetails(block: 'Admission Block', floor: 'Ground Floor', roomName: 'Student Affairs & Registrar Office', floorNumber: 0),
    'MAINDININGHALL&REFRESHMENTS': RoomLocationDetails(block: 'Cafeteria', floor: 'Ground Floor', roomName: 'Main Dining Hall & Refreshments', floorNumber: 0),
    'MAINDININGHALLREFRESHMENTS': RoomLocationDetails(block: 'Cafeteria', floor: 'Ground Floor', roomName: 'Main Dining Hall & Refreshments', floorNumber: 0),
    'FASTFOOD&SNACKBAR': RoomLocationDetails(block: 'Cafeteria', floor: 'Ground Floor', roomName: 'Fast Food & Snack Bar', floorNumber: 0),
    'FASTFOODSNACKBAR': RoomLocationDetails(block: 'Cafeteria', floor: 'Ground Floor', roomName: 'Fast Food & Snack Bar', floorNumber: 0),
    'TEA&COFFEECORNER': RoomLocationDetails(block: 'Cafeteria', floor: 'Ground Floor', roomName: 'Tea & Coffee Corner', floorNumber: 0),
    'TEACOFFEECORNER': RoomLocationDetails(block: 'Cafeteria', floor: 'Ground Floor', roomName: 'Tea & Coffee Corner', floorNumber: 0),
    'JUICE&ICECREAMSTALL': RoomLocationDetails(block: 'Cafeteria', floor: 'Ground Floor', roomName: 'Juice & Ice Cream Stall', floorNumber: 0),
    'JUICEICECREAMSTALL': RoomLocationDetails(block: 'Cafeteria', floor: 'Ground Floor', roomName: 'Juice & Ice Cream Stall', floorNumber: 0),
    'EXECUTIVEFACULTYDININGLOUNGE': RoomLocationDetails(block: 'Cafeteria', floor: 'Ground Floor', roomName: 'Executive Faculty Dining Lounge', floorNumber: 0),
    // Timetable-specific aliases & additional labs verified from campus layout
    'A28': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'A-2.8', floorNumber: 2),
    'A3': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'A-3', floorNumber: 0),
    'BIOLAB': RoomLocationDetails(block: 'C Block', floor: 'Ground Floor', roomName: 'Bio-Science Lab', floorNumber: 0),
    'C&ELAB': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'Circuits & Electronics Lab', floorNumber: 2),
    'CELAB': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'Circuits & Electronics Lab', floorNumber: 2),
    'CIVILENGINEERINGMATERIALSLAB': RoomLocationDetails(block: 'W Block', floor: 'Ground Floor', roomName: 'Civil Engineering Materials Lab', floorNumber: 0),
    'CONCRETELAB': RoomLocationDetails(block: 'W Block', floor: 'Ground Floor', roomName: 'Concrete Lab', floorNumber: 0),
    'DIGITALLAB': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'Digital Lab', floorNumber: 2),
    'ENGINEERINGMECHANICSLAB': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'Engineering Mechanics Lab', floorNumber: 0),
    'ENGINEERINGSURVEYLAB': RoomLocationDetails(block: 'W Block', floor: 'Ground Floor', roomName: 'Engineering Survey Lab', floorNumber: 0),
    'FALAB': RoomLocationDetails(block: 'D Block', floor: 'Ground Floor', roomName: 'Food Analysis Lab', floorNumber: 0),
    'FPLAB': RoomLocationDetails(block: 'D Block', floor: 'Ground Floor', roomName: 'Food Processing Lab', floorNumber: 0),
    'FLUIDMECHANICSLAB': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'Fluid Mechanics Lab', floorNumber: 1),
    'GEOTECHNICALENGINEERINGLAB': RoomLocationDetails(block: 'W Block', floor: 'Ground Floor', roomName: 'Geotechnical Engineering Lab', floorNumber: 0),
    'HECSMARTCLASSROOM': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'HEC Smart Class Room', floorNumber: 1),
    'HMTLAB': RoomLocationDetails(block: 'A Block', floor: '1st Floor', roomName: 'Heat & Mass Transfer Lab', floorNumber: 1),
    'POWERLAB': RoomLocationDetails(block: 'A Block', floor: '2nd Floor', roomName: 'Power Electronics Lab', floorNumber: 2),
    'SEMINARROOMDBLOCK': RoomLocationDetails(block: 'D Block', floor: 'Ground Floor', roomName: 'Seminar Room (D Block)', floorNumber: 0),
    'THERMODYNAMICSLAB': RoomLocationDetails(block: 'A Block', floor: 'Ground Floor', roomName: 'Thermodynamics Lab', floorNumber: 0),
    'VIBRATIONSLAB': RoomLocationDetails(block: 'W Block', floor: 'Ground Floor', roomName: 'Mechanics & Vibrations Lab', floorNumber: 0),
  };

  /// Parse any COMSATS room ID (e.g. A2.4, B2, C1.1, C-204, A1.1 (63)) into Block, Floor, and Room
  static RoomLocationDetails parseRoomCode(String roomId) {
    final raw = roomId.trim().toUpperCase();
    // 1. Strip capacity suffix e.g. " (63)", " (100)", " (40)"
    final clean = raw.replaceAll(RegExp(r'\s*\(\d+\)\s*$'), '').trim();
    final normRaw = clean
        .replaceAll(' ', '')
        .replaceAll('-', '')
        .replaceAll('.', '')
        .replaceAll('&', '')
        .replaceAll('(', '')
        .replaceAll(')', '')
        .replaceAll('/', '');
    
    if (_groundTruthRooms.containsKey(normRaw)) {
      return _groundTruthRooms[normRaw]!;
    }

    if (clean.contains('SEMINAR')) {
      if (clean.contains('D') || clean.contains('DBLOCK')) {
        return const RoomLocationDetails(
          block: 'D Block',
          floor: 'Ground Floor',
          roomName: 'Seminar Room (D Block)',
          floorNumber: 0,
        );
      }
      return const RoomLocationDetails(
        block: 'B Block',
        floor: 'Ground Floor',
        roomName: 'Seminar Room',
        floorNumber: 0,
      );
    }
    
    String block = 'Other';
    String floor = 'Ground Floor';
    int floorNumber = 0;
    String roomName = clean;

    final blockMatch = RegExp(r'^([A-E|W|M|S])').firstMatch(clean);
    if (blockMatch != null) {
      final letter = blockMatch.group(1)!;
      switch (letter) {
        case 'A': block = 'A Block'; break;
        case 'B': block = 'B Block'; break;
        case 'C': block = 'C Block'; break;
        case 'D': block = 'D Block'; break;
        case 'W': block = 'W Block'; break;
        case 'S': 
          block = 'B Block'; 
          roomName = 'Seminar Room';
          break;
        default:
          block = 'Other';
          break;
      }
    } else if (clean.startsWith('CS') || clean.startsWith('C-')) {
      block = 'C Block';
    } else if (clean.startsWith('ME')) {
      block = 'W Block';
    } else if (clean.startsWith('BE')) {
      block = 'B Block';
    }

    // Format 1: Dot format e.g. A1.5, A2.4, B0.2, C1.12
    final dotMatch = RegExp(r'^[A-E|W|M|S]\s*(\d)\.(\d+)$').firstMatch(clean);
    if (dotMatch != null) {
      floorNumber = int.parse(dotMatch.group(1)!);
      final roomNum = dotMatch.group(2)!;
      floor = floorNumber == 0 ? 'Ground Floor' : '$floorNumber${_floorSuffix(floorNumber)} Floor';
      roomName = 'Room $roomNum';
    } else {
      // Format 2: Dash format e.g. C-204, A-101
      final dashMatch = RegExp(r'^[A-E]\-?(\d)(\d{2})$').firstMatch(clean);
      if (dashMatch != null) {
        floorNumber = int.parse(dashMatch.group(1)!);
        final roomNum = int.parse(dashMatch.group(2)!);
        floor = floorNumber == 0 ? 'Ground Floor' : '$floorNumber${_floorSuffix(floorNumber)} Floor';
        roomName = 'Room $roomNum';
      } else {
        // Format 3: Single digit or multi-digit format e.g. B2, B10, B14, D1, D9, W1
        final numberMatch = RegExp(r'^[A-E|W](\d+)$').firstMatch(clean);
        if (numberMatch != null) {
          final roomNum = numberMatch.group(1)!;
          if (clean.startsWith('W')) {
            // W-1 to W-4 are 1st Floor in HelpDesk Locations
            floorNumber = 1;
            floor = '1st Floor';
            roomName = 'W-$roomNum';
          } else {
            floorNumber = 0; // Ground Floor
            floor = 'Ground Floor';
            roomName = 'Room $roomNum';
          }
        }
      }
    }

    if (clean.contains('LAB')) {
      roomName = clean;
    }

    return RoomLocationDetails(
      block: block,
      floor: floor,
      roomName: roomName,
      floorNumber: floorNumber,
    );
  }

  static String _floorSuffix(int n) {
    if (n == 1) return 'st';
    if (n == 2) return 'nd';
    if (n == 3) return 'rd';
    return 'th';
  }

  /// Save a list of rooms to SharedPreferences
  Future<void> saveRooms(List<Room> rooms) async {
    final prefs = await SharedPreferences.getInstance();
    final String encoded = jsonEncode(rooms.map((r) => r.toJson()).toList());
    await prefs.setString(_key, encoded);
  }

  /// Load rooms from SharedPreferences
  Future<List<Room>> loadRooms() async {
    final prefs = await SharedPreferences.getInstance();
    final String? encoded = prefs.getString(_key);
    if (encoded == null) return [];

    try {
      final List<dynamic> decoded = jsonDecode(encoded);
      return decoded.map((item) => Room.fromJson(item as Map<String, dynamic>)).toList();
    } catch (e) {
      return [];
    }
  }

  /// Apply heuristics to a room ID to generate default metadata
  Room generateDefaultRoom(String roomId) {
    final details = parseRoomCode(roomId);
    final normalizedRoom = roomId.trim().toUpperCase();
    final isLab = normalizedRoom.contains('LAB');
    final amenities = isLab 
        ? ['PC', 'Internet', 'AC', 'Whiteboard'] 
        : ['Whiteboard', 'AC'];

    return Room(
      id: roomId,
      building: details.block,
      capacity: isLab ? 30 : 40,
      amenities: amenities,
      registeredAt: DateTime.now(),
    );
  }

  /// Load and parse the HelpDesk Locations JSON for Campus Directory
  Future<List<CampusBuilding>> loadCampusDirectory() async {
    try {
      final jsonString = await rootBundle.loadString('assets/helpdesk_backup/helpdesk_locations.json');
      final data = jsonDecode(jsonString) as Map<String, dynamic>;
      final buildingsMap = data['buildings'] as Map<String, dynamic>?;
      if (buildingsMap == null) return [];

      // Parse computer labs attendant and contact lookup map
      final Map<String, Map<String, String>> labMeta = {};
      final computerLabsRaw = data['computer_labs'] as List<dynamic>?;
      if (computerLabsRaw != null) {
        for (final l in computerLabsRaw) {
          if (l is Map<String, dynamic>) {
            final id = l['id']?.toString().toUpperCase().replaceAll(' ', '').replaceAll('-', '') ?? '';
            labMeta[id] = {
              'attendant': l['attendant']?.toString() ?? '',
              'mobile': l['mobile']?.toString() ?? '',
            };
          }
        }
      }

      final List<CampusBuilding> result = [];

      buildingsMap.forEach((buildingName, floorsRaw) {
        if (floorsRaw is! Map<String, dynamic>) return;

        // Determine building type
        String type = 'academic';
        final lowerName = buildingName.toLowerCase();
        if (lowerName.contains('cafeteria')) {
          type = 'cafeteria';
        } else if (lowerName.contains('admission') || lowerName.contains('admin')) {
          type = 'administrative';
        } else if (lowerName.contains('library')) {
          type = 'library';
        } else if (lowerName.contains('mosque')) {
          type = 'amenity';
        } else if (lowerName.contains('sports') || lowerName.contains('gym')) {
          type = 'sports';
        }

        // Realistic coordinates for CUI Sahiwal Campus hubs
        double lat = 30.6558;
        double lng = 73.1118;
        List<String> departments = ['General Academic'];

        if (buildingName.contains('A Block')) {
          lat = 30.6559; lng = 73.1115;
          departments = ['Mechanical Engineering', 'Electrical Engineering', 'Administration'];
        } else if (buildingName.contains('B Block')) {
          lat = 30.6562; lng = 73.1120;
          departments = ['Management Sciences'];
        } else if (buildingName.contains('C Block')) {
          lat = 30.6565; lng = 73.1126;
          departments = ['Computer Science', 'Mathematics', 'Biosciences'];
        } else if (buildingName.contains('D Block')) {
          lat = 30.6568; lng = 73.1132;
          departments = ['Food Sciences & Nutrition', 'Humanities'];
        } else if (buildingName.contains('W Block')) {
          lat = 30.6552; lng = 73.1108;
          departments = ['Mechanical Workshops', 'Civil Engineering'];
        } else if (buildingName.contains('Admission Block')) {
          lat = 30.6548; lng = 73.1102;
          departments = ['Student Affairs', 'Registrar', 'Admissions'];
        } else if (buildingName.contains('Cafeteria')) {
          lat = 30.6570; lng = 73.1120;
          departments = ['Food Services', 'Dining Hall'];
        }

        final List<CampusFloor> floors = [];
        floorsRaw.forEach((floorName, roomsListRaw) {
          if (roomsListRaw is! List) return;
          final level = floorName.replaceAll('Floor', '').trim();
          final List<CampusRoom> rooms = [];

          for (final item in roomsListRaw) {
            final str = item.toString().trim();
            if (str.isEmpty) continue;

            String roomType = 'classroom';
            final lowerStr = str.toLowerCase();
            if (lowerStr.contains('lab') || lowerStr.contains('laboratory')) {
              roomType = 'lab';
            } else if (lowerStr.contains('office') || lowerStr.contains('hod') || lowerStr.contains('dco') || lowerStr.contains('desk') || lowerStr.contains('reception')) {
              roomType = 'office';
            } else if (RegExp(r'^[A-Za-z]-[0-9]').hasMatch(str)) {
              roomType = 'classroom';
            } else {
              roomType = 'amenity';
            }

            String code = str;
            String displayName = str;
            if (RegExp(r'^[A-Za-z]-[0-9.]+$').hasMatch(str)) {
              code = str;
              displayName = 'Room $str';
            } else if (str.startsWith('C Lab') || str.startsWith('Clab')) {
              code = str.replaceAll(' ', '-');
              displayName = str;
            } else if (roomType == 'office') {
              code = 'OFFICE';
              displayName = str;
            } else if (str.length > 8) {
              code = str.substring(0, 4).toUpperCase();
              displayName = str;
            }

            final normItem = str.toUpperCase().replaceAll(' ', '').replaceAll('-', '');
            final attendantInfo = labMeta[normItem];
            final attendant = attendantInfo?['attendant']?.isNotEmpty == true ? attendantInfo!['attendant'] : null;
            final mobile = attendantInfo?['mobile']?.isNotEmpty == true ? attendantInfo!['mobile'] : null;

            rooms.add(CampusRoom(
              code: code,
              name: displayName,
              type: roomType,
              attendant: attendant,
              mobile: mobile,
            ));
          }

          floors.add(CampusFloor(
            level: level,
            rooms: rooms,
          ));
        });

        result.add(CampusBuilding(
          name: buildingName,
          type: type,
          latitude: lat,
          longitude: lng,
          departments: departments,
          floors: floors,
        ));
      });

      // Add Mosque as dedicated campus hub from HelpDesk Locations
      result.add(const CampusBuilding(
        name: 'Campus Mosque',
        type: 'amenity',
        latitude: 30.6550,
        longitude: 73.1110,
        departments: ['Campus Services', 'Islamic Center'],
        floors: [
          CampusFloor(
            level: 'Ground',
            rooms: [
              CampusRoom(code: 'PRAYER-M', name: 'Main Prayer Hall (Brothers)', type: 'amenity'),
              CampusRoom(code: 'WUDU', name: 'Ablution Area (Wudu Khana)', type: 'amenity'),
              CampusRoom(code: 'IMAM', name: 'Imam & Khateeb Office', type: 'office'),
            ],
          ),
          CampusFloor(
            level: '1st',
            rooms: [
              CampusRoom(code: 'PRAYER-F', name: 'Upper Prayer Gallery (Sisters)', type: 'amenity'),
            ],
          ),
        ],
      ));

      if (result.isEmpty) {
        return _getFallbackCampusDirectory();
      }

      return result;
    } catch (e) {
      debugPrint('Failed to load Campus Directory from asset: $e');
      return _getFallbackCampusDirectory();
    }
  }

  /// Guaranteed embedded fallback campus directory for CUI Sahiwal Campus
  List<CampusBuilding> _getFallbackCampusDirectory() {
    return [
      CampusBuilding(
        name: 'A Block',
        type: 'academic',
        latitude: 30.6559,
        longitude: 73.1115,
        departments: const ['Mechanical Engineering', 'Electrical Engineering', 'Administration'],
        floors: [
          CampusFloor(
            level: 'Ground',
            rooms: [
              const CampusRoom(code: 'A-01', name: 'Room A-01', type: 'classroom'),
              const CampusRoom(code: 'A-02', name: 'Room A-02', type: 'classroom'),
              const CampusRoom(code: 'A-03', name: 'Room A-03', type: 'classroom'),
              const CampusRoom(code: 'A-04', name: 'Room A-04', type: 'classroom'),
              const CampusRoom(code: 'A-05', name: 'Room A-05', type: 'classroom'),
              const CampusRoom(code: 'OFFICE', name: 'Faculty Offices Ground', type: 'office'),
            ],
          ),
          CampusFloor(
            level: '1st',
            rooms: [
              const CampusRoom(code: 'A-1.1', name: 'Room A-1.1', type: 'classroom'),
              const CampusRoom(code: 'A-1.2', name: 'Room A-1.2', type: 'classroom'),
              const CampusRoom(code: 'A-1.3', name: 'Room A-1.3', type: 'classroom'),
              const CampusRoom(code: 'OFFICE', name: 'EE Department HOD Office', type: 'office'),
            ],
          ),
          CampusFloor(
            level: '2nd',
            rooms: [
              const CampusRoom(code: 'A-2.1', name: 'Room A-2.1', type: 'classroom'),
              const CampusRoom(code: 'A-2.2', name: 'Room A-2.2', type: 'classroom'),
              const CampusRoom(code: 'A-2.3', name: 'Room A-2.3', type: 'classroom'),
            ],
          ),
        ],
      ),
      CampusBuilding(
        name: 'B Block',
        type: 'academic',
        latitude: 30.6562,
        longitude: 73.1120,
        departments: const ['Management Sciences'],
        floors: [
          CampusFloor(
            level: 'Ground',
            rooms: [
              const CampusRoom(code: 'B-01', name: 'Room B-01', type: 'classroom'),
              const CampusRoom(code: 'B-02', name: 'Room B-02', type: 'classroom'),
              const CampusRoom(code: 'B-03', name: 'Room B-03', type: 'classroom'),
              const CampusRoom(code: 'B-04', name: 'Room B-04', type: 'classroom'),
              const CampusRoom(code: 'OFFICE', name: 'Management Sciences HOD Office', type: 'office'),
            ],
          ),
        ],
      ),
      CampusBuilding(
        name: 'C Block',
        type: 'academic',
        latitude: 30.6565,
        longitude: 73.1126,
        departments: const ['Computer Science', 'Mathematics', 'Biosciences'],
        floors: [
          CampusFloor(
            level: 'Ground',
            rooms: [
              const CampusRoom(code: 'C-01', name: 'Room C-01', type: 'classroom'),
              const CampusRoom(code: 'C-02', name: 'Room C-02', type: 'classroom'),
              const CampusRoom(code: 'C-03', name: 'Room C-03', type: 'classroom'),
              const CampusRoom(code: 'OFFICE', name: 'CS Department Faculty Offices', type: 'office'),
            ],
          ),
          CampusFloor(
            level: '1st',
            rooms: [
              const CampusRoom(code: 'CLAB-1', name: 'Computer Lab 1', type: 'lab', attendant: 'Mr. Khan Shabir', mobile: '03004083616'),
              const CampusRoom(code: 'CLAB-2', name: 'Computer Lab 2', type: 'lab', attendant: 'Mr. Jawad', mobile: '03057351584'),
              const CampusRoom(code: 'CLAB-3', name: 'Computer Lab 3', type: 'lab', attendant: 'Mr. Nadeem Akhtar', mobile: '03006937881'),
              const CampusRoom(code: 'CLAB-4', name: 'Computer Lab 4', type: 'lab', attendant: 'Mr. Wasim Akram', mobile: '03088371674'),
            ],
          ),
          CampusFloor(
            level: '2nd',
            rooms: [
              const CampusRoom(code: 'CLAB-5', name: 'Computer Lab 5', type: 'lab', attendant: 'Mr. M. Kaleem', mobile: '03441620786'),
              const CampusRoom(code: 'CLAB-6', name: 'Computer Lab 6', type: 'lab', attendant: 'Mr. Sajjad', mobile: '03003784327'),
              const CampusRoom(code: 'CLAB-7', name: 'Computer Lab 7', type: 'lab', attendant: 'Mr. Mubeen Lodhi', mobile: '03063977109'),
              const CampusRoom(code: 'C-2.1', name: 'Room C-2.1', type: 'classroom'),
              const CampusRoom(code: 'C-2.2', name: 'Room C-2.2', type: 'classroom'),
              const CampusRoom(code: 'C-2.3', name: 'Room C-2.3', type: 'classroom'),
            ],
          ),
        ],
      ),
      CampusBuilding(
        name: 'D Block',
        type: 'academic',
        latitude: 30.6568,
        longitude: 73.1132,
        departments: const ['Food Sciences & Nutrition', 'Humanities'],
        floors: [
          CampusFloor(
            level: 'Ground',
            rooms: [
              const CampusRoom(code: 'D-01', name: 'Room D-01', type: 'classroom'),
              const CampusRoom(code: 'D-02', name: 'Room D-02', type: 'classroom'),
              const CampusRoom(code: 'D-03', name: 'Room D-03', type: 'classroom'),
            ],
          ),
          CampusFloor(
            level: '1st',
            rooms: [
              const CampusRoom(code: 'D-1.1', name: 'Room D-1.1', type: 'classroom'),
              const CampusRoom(code: 'D-1.2', name: 'Room D-1.2', type: 'classroom'),
              const CampusRoom(code: 'D-LAB', name: 'Food Sciences Lab', type: 'lab'),
            ],
          ),
        ],
      ),
      CampusBuilding(
        name: 'W Block',
        type: 'academic',
        latitude: 30.6552,
        longitude: 73.1108,
        departments: const ['Mechanical Workshops', 'Civil Engineering'],
        floors: [
          CampusFloor(
            level: 'Ground',
            rooms: [
              const CampusRoom(code: 'W-01', name: 'Mechanical Engineering Workshop 1', type: 'lab'),
              const CampusRoom(code: 'W-02', name: 'Mechanical Engineering Workshop 2', type: 'lab'),
              const CampusRoom(code: 'W-03', name: 'Civil Engineering Materials Lab', type: 'lab'),
            ],
          ),
        ],
      ),
      CampusBuilding(
        name: 'Admission Block',
        type: 'administrative',
        latitude: 30.6548,
        longitude: 73.1102,
        departments: const ['Student Affairs', 'Registrar', 'Admissions'],
        floors: [
          CampusFloor(
            level: 'Ground',
            rooms: [
              const CampusRoom(code: 'ADM-DESK', name: 'Admission & Information Desk', type: 'office'),
              const CampusRoom(code: 'ACCOUNTS', name: 'Accounts & Fee Section', type: 'office'),
              const CampusRoom(code: 'REGISTRAR', name: 'Registrar Office', type: 'office'),
            ],
          ),
        ],
      ),
      CampusBuilding(
        name: 'Campus Cafeteria',
        type: 'cafeteria',
        latitude: 30.6570,
        longitude: 73.1120,
        departments: const ['Food Services', 'Dining Hall'],
        floors: [
          CampusFloor(
            level: 'Ground',
            rooms: [
              const CampusRoom(code: 'CAFE-MAIN', name: 'Main Student Dining Hall', type: 'amenity'),
              const CampusRoom(code: 'CAFE-FAC', name: 'Faculty Dining Lounge', type: 'amenity'),
            ],
          ),
        ],
      ),
      CampusBuilding(
        name: 'Campus Mosque',
        type: 'amenity',
        latitude: 30.6550,
        longitude: 73.1110,
        departments: const ['Campus Services', 'Islamic Center'],
        floors: [
          CampusFloor(
            level: 'Ground',
            rooms: [
              const CampusRoom(code: 'PRAYER-M', name: 'Main Prayer Hall (Brothers)', type: 'amenity'),
              const CampusRoom(code: 'WUDU', name: 'Ablution Area (Wudu Khana)', type: 'amenity'),
              const CampusRoom(code: 'IMAM', name: 'Imam & Khateeb Office', type: 'office'),
            ],
          ),
          CampusFloor(
            level: '1st',
            rooms: [
              const CampusRoom(code: 'PRAYER-F', name: 'Upper Prayer Gallery (Sisters)', type: 'amenity'),
            ],
          ),
        ],
      ),
    ];
  }
}
