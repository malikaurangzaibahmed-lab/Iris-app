import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../core/helpdesk_api_constants.dart';
import '../core/models.dart';
import 'timetable_ota_service.dart';

/// Dedicated service for interfacing with the Supabase Live Timetable API & Storage Bucket
class SupabaseTimetableService {
  /// Test connectivity to Supabase Timetable storage
  static Future<Map<String, dynamic>> ping() async {
    final sw = Stopwatch()..start();
    try {
      final res = await http
          .head(Uri.parse(HelpdeskApiConstants.timetableUrl))
          .timeout(const Duration(seconds: 5));
      sw.stop();

      final contentLength = res.headers['content-length'] ?? '0';
      final lastModified = res.headers['last-modified'] ?? '';
      final etag = res.headers['etag'] ?? '';

      return {
        'ok': res.statusCode == 200,
        'statusCode': res.statusCode,
        'latencyMs': sw.elapsedMilliseconds,
        'contentLength': int.tryParse(contentLength) ?? 0,
        'lastModified': lastModified,
        'etag': etag,
        'url': HelpdeskApiConstants.timetableUrl,
      };
    } catch (e) {
      sw.stop();
      return {
        'ok': false,
        'statusCode': 0,
        'latencyMs': sw.elapsedMilliseconds,
        'error': e.toString(),
        'url': HelpdeskApiConstants.timetableUrl,
      };
    }
  }

  /// Ingest raw JSON directly from Supabase Storage
  static Future<String?> fetchRawJson() async {
    try {
      final res = await http
          .get(Uri.parse(HelpdeskApiConstants.timetableUrl))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200 && res.body.isNotEmpty) {
        return res.body;
      }
    } catch (e) {
      debugPrint('⚠️ SupabaseTimetableService fetchRawJson error: $e');
    }
    return null;
  }

  /// Download and parse full ClassSession list from Supabase
  static Future<List<ClassSession>> fetchClassSessions() async {
    final raw = await fetchRawJson();
    if (raw == null || raw.isEmpty) return [];

    try {
      final decoded = jsonDecode(raw);
      final rawList = <Map<String, dynamic>>[];

      if (decoded is List) {
        for (final item in decoded) {
          if (item is Map) rawList.add(Map<String, dynamic>.from(item));
        }
      } else if (decoded is Map && decoded['sessions'] is List) {
        for (final item in decoded['sessions']) {
          if (item is Map) rawList.add(Map<String, dynamic>.from(item));
        }
      }

      return rawList
          .map((json) => ClassSession.fromJson(json))
          .where((s) => !s.isBreak)
          .toList();
    } catch (e) {
      debugPrint('⚠️ SupabaseTimetableService parse error: $e');
      return [];
    }
  }

  /// Sync Supabase feed directly to local OTA cache
  static Future<bool> syncToLocalCache() async {
    final raw = await fetchRawJson();
    if (raw == null || raw.isEmpty) return false;

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(TimetableOTAService.prefCachedTimetable, raw);
      await prefs.setInt(
        TimetableOTAService.prefTimetableVersion,
        DateTime.now().millisecondsSinceEpoch,
      );
      await prefs.setInt(
        TimetableOTAService.prefLastCheckTime,
        DateTime.now().millisecondsSinceEpoch,
      );
      debugPrint('✅ Supabase Timetable synced successfully to local cache');
      return true;
    } catch (e) {
      debugPrint('⚠️ Supabase sync to local cache error: $e');
      return false;
    }
  }
}
