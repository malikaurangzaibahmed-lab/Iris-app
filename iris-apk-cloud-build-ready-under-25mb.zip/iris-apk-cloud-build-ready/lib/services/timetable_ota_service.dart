import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;
import '../core/helpdesk_api_constants.dart';
import 'remote_config_service.dart';
import 'notification_service.dart';

/// Simple OTA (Over-The-Air) timetable update service
/// Enables pushing timetable updates to users without requiring app rebuild
class TimetableOTAService {
  // ============================================================
  // CONFIGURATION: Live Supabase timetable public bucket
  // ============================================================
  static const String _timetableUrl = HelpdeskApiConstants.timetableUrl;
  
  // Metadata endpoint - optional (can be null for simple setups)
  static const String? _metadataUrl = null;

  static const String prefTimetableVersion = 'ota_timetable_version';
  static const String prefLastCheckTime = 'ota_last_check_time';
  static const String prefCachedTimetable = 'ota_cached_timetable';

  // Getter to suppress unused warnings on configuration constants
  static String get timetableUrl => _timetableUrl;
  static String? get metadataUrl => _metadataUrl;

  /// Check if new timetable version is available
  static Future<bool> isUpdateAvailable() async {
    try {
      final doc = await FirebaseFirestore.instance
          .collection('config')
          .doc('global')
          .get()
          .timeout(const Duration(seconds: 4));
      if (doc.exists) {
        final data = doc.data() ?? {};
        final remoteTimetableVersion = (data['active_timetable_version'] as num?)?.toInt() ?? 0;
        
        final prefs = await SharedPreferences.getInstance();
        final storedVersion = prefs.getInt(prefTimetableVersion) ?? 0;
        final currentVersion = storedVersion > RemoteConfigService.BUNDLED_TIMETABLE_VERSION
            ? storedVersion
            : RemoteConfigService.BUNDLED_TIMETABLE_VERSION;
        
        if (remoteTimetableVersion > currentVersion) {
          debugPrint('✅ New timetable available via Firestore! Version $remoteTimetableVersion (current: $currentVersion)');
          return true;
        } else {
          debugPrint('✅ Timetable is up-to-date (version $currentVersion)');
          return false;
        }
      }
    } catch (e) {
      debugPrint('⚠️ Firestore update check notice: $e - probing Supabase storage...');
    }

    // Fallback: Check Supabase Storage headers or cached presence
    try {
      final res = await http.head(Uri.parse(_timetableUrl)).timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final prefs = await SharedPreferences.getInstance();
        final hasCached = prefs.getString(prefCachedTimetable) != null;
        if (!hasCached) return true;
      }
    } catch (_) {}

    return false;
  }

  /// Download and cache new timetable from Firestore ledger or Supabase Storage
  static Future<int> downloadTimetableUpdate() async {
    String? timetableJson;
    int timetableVersion = 0;
    String sourceName = 'Firestore';

    // Tier 1: Try Firestore Active Ledger
    try {
      debugPrint('📥 Checking timetable update from Firestore...');
      final doc = await FirebaseFirestore.instance
          .collection('config')
          .doc('global')
          .get()
          .timeout(const Duration(seconds: 5));
      if (doc.exists) {
        final data = doc.data() ?? {};
        final remoteTimetableJson = data['active_timetable_json']?.toString() ?? '';
        final remoteTimetableVersion = (data['active_timetable_version'] as num?)?.toInt() ?? 0;
        
        if (remoteTimetableJson.isNotEmpty && remoteTimetableJson != '[]') {
          timetableJson = remoteTimetableJson;
          timetableVersion = remoteTimetableVersion;
          sourceName = 'Firestore';
        }
      }
    } catch (e) {
      debugPrint('⚠️ Firestore timetable read notice: $e');
    }

    // Tier 2: If Firestore has no JSON or timed out, pull directly from Supabase Storage
    if (timetableJson == null || timetableJson.isEmpty) {
      try {
        debugPrint('📥 Ingesting timetable directly from Supabase Storage: $_timetableUrl');
        final response = await http
            .get(Uri.parse(_timetableUrl))
            .timeout(const Duration(seconds: 10));
        if (response.statusCode == 200 && response.body.isNotEmpty) {
          timetableJson = response.body;
          timetableVersion = DateTime.now().millisecondsSinceEpoch;
          sourceName = 'Supabase';
        }
      } catch (e) {
        debugPrint('⚠️ Supabase Storage timetable read notice: $e');
      }
    }

    if (timetableJson != null && timetableJson.isNotEmpty) {
      try {
        // Validate JSON before caching
        final decoded = jsonDecode(timetableJson);
        int sessionCount = 0;
        if (decoded is List) {
          sessionCount = decoded.length;
        } else if (decoded is Map && decoded['sessions'] is List) {
          sessionCount = (decoded['sessions'] as List).length;
        } else {
          throw Exception('Invalid timetable format');
        }

        if (sessionCount == 0) {
          debugPrint('⚠️ Timetable feed contained 0 sessions, rejecting update.');
          return 0;
        }

        final prefs = await SharedPreferences.getInstance();

        // Check if content actually changed
        final cached = prefs.getString(prefCachedTimetable);
        if (cached == timetableJson) {
          debugPrint('ℹ️ Timetable ($sourceName) is already up-to-date (no changes)');
          await prefs.setInt(prefLastCheckTime, DateTime.now().millisecondsSinceEpoch);
          return 0;
        }

        // Cache the timetable JSON only if different
        await prefs.setString(prefCachedTimetable, timetableJson);
        await prefs.setInt(prefTimetableVersion, timetableVersion);
        await prefs.setInt(prefLastCheckTime, DateTime.now().millisecondsSinceEpoch);

        // Notify user and reschedule reminders if timetable diff alerts are enabled
        try {
          await NotificationSyncService.instance.showTimetableUpdateNotification(sessionCount: sessionCount);
          await NotificationSyncService.instance.syncClassRemindersFromPrefs();
        } catch (_) {}

        debugPrint('✅ Timetable updated successfully from $sourceName! ($sessionCount sessions)');
        return 1;
      } catch (e) {
        debugPrint('❌ Failed to parse or cache timetable from $sourceName: $e');
        return -1;
      }
    }

    return -1;
  }

  /// Get cached timetable JSON
  static Future<String?> getCachedTimetable() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(prefCachedTimetable);
  }

  /// Check for updates (rate-limited to once per day)
  static Future<void> checkForUpdatesIfNeeded() async {
    final prefs = await SharedPreferences.getInstance();
    final lastCheck = prefs.getInt(prefLastCheckTime) ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    
    // Only check once every 24 hours
    const checkInterval = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
    
    if (now - lastCheck > checkInterval) {
      if (await isUpdateAvailable()) {
        await downloadTimetableUpdate();
      }
    }
  }

  /// Check for updates on app startup (no rate limit)
  static Future<void> checkForUpdatesOnStartup() async {
    debugPrint('🚀 Checking for timetable updates on startup...');
    if (await isUpdateAvailable()) {
      debugPrint('📥 Update available on startup - downloading...');
      await downloadTimetableUpdate();
    } else {
      debugPrint('✅ Timetable is current');
      // Update last check time even if no update available
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(prefLastCheckTime, DateTime.now().millisecondsSinceEpoch);
    }
  }

  /// Force immediate timetable refresh (for manual update button)
  static Future<int> forceRefresh() async {
    debugPrint('🔄 Force refreshing timetable...');
    return await downloadTimetableUpdate();
  }

  /// Get update status info for UI
  static Future<Map<String, dynamic>> getUpdateStatus() async {
    final prefs = await SharedPreferences.getInstance();
    final version = prefs.getInt(prefTimetableVersion) ?? 0;
    final lastCheck = prefs.getInt(prefLastCheckTime) ?? 0;
    
    String lastCheckStr = 'Never';
    if (lastCheck > 0) {
      final lastDate = DateTime.fromMillisecondsSinceEpoch(lastCheck);
      final now = DateTime.now();
      final diff = now.difference(lastDate);
      
      if (diff.inMinutes < 60) {
        lastCheckStr = '${diff.inMinutes} min ago';
      } else if (diff.inHours < 24) {
        lastCheckStr = '${diff.inHours} hours ago';
      } else {
        lastCheckStr = '${diff.inDays} days ago';
      }
    }
    
    return {
      'version': version,
      'lastCheck': lastCheckStr,
      'hasCached': await getCachedTimetable() != null,
    };
  }

  /// Integration point: Call this from main.dart on app startup
  static Future<void> initializeOTA() async {
    debugPrint('🚀 Initializing OTA timetable service...');
    await checkForUpdatesIfNeeded();
  }
}
