import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/tokens.dart';
import 'system_broadcast_service.dart';

/// UI Audio Feedback - Permanently muted across the application.
class IrisSfx {
  const IrisSfx._();

  static const bool enabled = false;
  static const String profile = 'muted';

  static Future<void> init() async {}
  static Future<void> setEnabled(bool value) async {}
  static Future<void> setProfile(String profile) async {}

  static void navTick({int distance = 1}) {}
  static void click() {}
  static void bubblePop() {}
  static void pillTap() {}
  static void tick() {}
  static void confirm() {}
  static void error() {}
  static void downloadSuccess() {}
  static void intelligentConfirmation() {}
}

/// UI Haptic Feedback
class IrisHaptics {
  static bool _enabled = true;
  static String _profile = 'gentle';
  static int _lastPulseMs = 0;

  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _enabled = prefs.getBool('app_haptics_enabled') ?? true;
    _profile = prefs.getString('ui_feedback_profile') ?? 'gentle';
  }

  static Future<void> setEnabled(bool value) async {
    _enabled = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('app_haptics_enabled', value);
  }

  static bool get enabled => _enabled;
  static String get profile => _profile;

  static Future<void> setProfile(String profile) async {
    final normalized = switch (profile) {
      'gentle' => 'gentle',
      'crisp' => 'crisp',
      _ => 'balanced',
    };
    _profile = normalized;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('ui_feedback_profile', normalized);
  }

  static bool _throttle([int minGapMs = 40]) {
    if (!_enabled) return true;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - _lastPulseMs < minGapMs) return true;
    _lastPulseMs = now;
    return false;
  }

  static Future<void> _safePulse(Future<void> Function() pulse) async {
    if (!_enabled) return;
    try {
      await pulse();
    } catch (_) {}
  }

  static Future<void> navTransition({
    required int from,
    required int to,
  }) async {
    if (!_enabled) return;
    if (from == to) return;
    if (_throttle(26)) return;

    final distance = (to - from).abs();
    await _safePulse(HapticFeedback.selectionClick);

    if (_profile == 'gentle') return;

    if (distance > 1) {
      await Future<void>.delayed(const Duration(milliseconds: 24));
      if (_throttle(24)) return;
      await _safePulse(
        _profile == 'crisp'
            ? HapticFeedback.mediumImpact
            : HapticFeedback.lightImpact,
      );
    }
  }

  static Future<void> destinationOpen({required int destination}) async {
    if (!_enabled) return;
    await Future<void>.delayed(const Duration(milliseconds: 34));
    if (_throttle(44)) return;
    await _safePulse(
      _profile == 'gentle'
          ? HapticFeedback.selectionClick
          : HapticFeedback.lightImpact,
    );

    if (destination == 0) {
      await Future<void>.delayed(const Duration(milliseconds: 16));
      if (_throttle(20)) return;
      await _safePulse(HapticFeedback.selectionClick);
    }
  }

  static void chipSelect() {
    if (_throttle(24)) return;
    unawaited(_safePulse(HapticFeedback.selectionClick));
  }

  static void switchToggle() {
    if (_throttle(24)) return;
    unawaited(_safePulse(HapticFeedback.selectionClick));
  }

  static void selectionClick() {
    if (_throttle(24)) return;
    unawaited(_safePulse(HapticFeedback.selectionClick));
  }

  static void refreshStart() {
    if (_throttle(36)) return;
    unawaited(_safePulse(HapticFeedback.lightImpact));
  }

  static void refreshSuccess() {
    if (_throttle(64)) return;
    unawaited(() async {
      await _safePulse(HapticFeedback.mediumImpact);
      await Future<void>.delayed(const Duration(milliseconds: 34));
      if (_throttle(24)) return;
      await _safePulse(HapticFeedback.selectionClick);
    }());
  }

  static void actionSoft() {
    if (_throttle(26)) return;
    unawaited(
      _safePulse(
        _profile == 'gentle'
            ? HapticFeedback.selectionClick
            : HapticFeedback.lightImpact,
      ),
    );
  }

  static void actionMedium() {
    if (_throttle(44)) return;
    unawaited(
      _safePulse(
        _profile == 'gentle'
            ? HapticFeedback.lightImpact
            : HapticFeedback.mediumImpact,
      ),
    );
  }

  static void actionHeavy() {
    if (_throttle(90)) return;
    unawaited(() async {
      if (_profile == 'gentle') {
        await _safePulse(HapticFeedback.lightImpact);
        return;
      }
      
      // Layered Heavy Impact
      await _safePulse(HapticFeedback.heavyImpact);
      await Future<void>.delayed(const Duration(milliseconds: 32));
      await _safePulse(HapticFeedback.lightImpact);
    }());
  }

  static void intelligencePulse() {
    if (_throttle(150)) return;
    unawaited(() async {
      await _safePulse(HapticFeedback.selectionClick);
      await Future<void>.delayed(const Duration(milliseconds: 60));
      await _safePulse(HapticFeedback.selectionClick);
    }());
  }
}

final Map<String, int> _irisSnackLastShownMs = <String, int>{};


String _extractIrisSnackText(Widget widget) {
  if (widget is Text) {
    return widget.data ?? widget.textSpan?.toPlainText() ?? '';
  }
  if (widget is RichText) {
    return widget.text.toPlainText();
  }
  if (widget is DefaultTextStyle) {
    return _extractIrisSnackText(widget.child);
  }
  if (widget is Expanded) {
    return _extractIrisSnackText(widget.child);
  }
  if (widget is Flexible) {
    return _extractIrisSnackText(widget.child);
  }
  if (widget is Padding) {
    final child = widget.child;
    if (child != null) return _extractIrisSnackText(child);
    return '';
  }
  if (widget is Container) {
    final child = widget.child;
    if (child != null) return _extractIrisSnackText(child);
    return '';
  }
  if (widget is Center) {
    final child = widget.child;
    if (child != null) return _extractIrisSnackText(child);
    return '';
  }
  if (widget is Align) {
    final child = widget.child;
    if (child != null) return _extractIrisSnackText(child);
    return '';
  }
  if (widget is DecoratedBox) {
    final child = widget.child;
    if (child != null) return _extractIrisSnackText(child);
    return '';
  }
  if (widget is ClipRRect) {
    final child = widget.child;
    if (child != null) return _extractIrisSnackText(child);
    return '';
  }
  if (widget is Material) {
    final child = widget.child;
    if (child != null) return _extractIrisSnackText(child);
    return '';
  }
  if (widget is InkWell) {
    final child = widget.child;
    if (child != null) return _extractIrisSnackText(child);
    return '';
  }
  if (widget is GestureDetector) {
    final child = widget.child;
    if (child != null) return _extractIrisSnackText(child);
    return '';
  }
  if (widget is Opacity) {
    final child = widget.child;
    if (child != null) return _extractIrisSnackText(child);
    return '';
  }
  if (widget is SizedBox && widget.child != null) {
    return _extractIrisSnackText(widget.child!);
  }
  if (widget is Row) {
    return widget.children
        .map(_extractIrisSnackText)
        .where((s) => s.isNotEmpty)
        .join(' ');
  }
  if (widget is Column) {
    return widget.children
        .map(_extractIrisSnackText)
        .where((s) => s.isNotEmpty)
        .join(' ');
  }
  if (widget is Wrap) {
    return widget.children
        .map(_extractIrisSnackText)
        .where((s) => s.isNotEmpty)
        .join(' ');
  }
  return '';
}

String _compactIrisSnackText(String raw) {
  final compact = raw.replaceAll(RegExp(r'\s+'), ' ').trim();
  if (compact.isEmpty) return 'Updated';
  if (compact.length <= 62) return compact;
  return '${compact.substring(0, 59)}...';
}

void _showIrisTopPill(
  BuildContext context, {
  required String text,
  Duration duration = const Duration(seconds: 3),
  Color? tint,
  SnackBarAction? action,
  bool clearExisting = true,
}) {
  SystemBroadcastService().triggerLocalOverride(
    text,
    '',
    isUrgent: tint == IrisTokens.error,
    duration: duration,
  );
}

void showIrisFrostedSnackBar(
  BuildContext context, {
  required Widget content,
  SnackBarAction? action,
  Duration duration = const Duration(seconds: 3),
  Color? tint,
  EdgeInsetsGeometry? margin,
  String? dedupeKey,
  Duration dedupeWindow = const Duration(milliseconds: 1400),
  bool clearExisting = true,
}) {
  if (!context.mounted) return;

  if (dedupeKey != null && dedupeKey.isNotEmpty) {
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    final lastMs = _irisSnackLastShownMs[dedupeKey] ?? 0;
    if (nowMs - lastMs < dedupeWindow.inMilliseconds) {
      return;
    }
    _irisSnackLastShownMs[dedupeKey] = nowMs;
  }

  final text = _compactIrisSnackText(_extractIrisSnackText(content));
  _showIrisTopPill(
    context,
    text: text,
    duration: duration,
    tint: tint,
    action: action,
    clearExisting: clearExisting,
  );
}
