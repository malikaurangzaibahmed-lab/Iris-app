import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme_signals.dart';
import '../../core/glass.dart';
import '../../services/ui_feedback.dart';
import '../../services/remote_config_service.dart';
import '../../core/animations.dart';
import '../iris_components.dart';

/// Atmospheric animated Developer Card featuring dynamic moving cosmic gradients,
/// a starry halftone dot matrix pattern, and radiant prism sparkle icon inspired by the Gemini interface.
class DeveloperCard extends StatefulWidget {
  final bool isDark;
  final VoidCallback? onTap;

  const DeveloperCard({
    required this.isDark,
    this.onTap,
    super.key,
  });

  @override
  State<DeveloperCard> createState() => _DeveloperCardState();
}

class _DeveloperCardState extends State<DeveloperCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  int _tapCount = 0;
  Timer? _tapResetTimer;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    );
    if (!ThemeSignals.useMinimalTheme.value) {
      _controller.repeat();
    }
  }

  @override
  void dispose() {
    _tapResetTimer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _handleDevCardTap() {
    widget.onTap?.call();
    _tapResetTimer?.cancel();
    _tapCount++;
    _tapResetTimer = Timer(const Duration(seconds: 3), () {
      _tapCount = 0;
    });

    if (_tapCount >= 5) {
      _tapCount = 0;
      _showDevControlSheet();
    } else if (_tapCount >= 3) {
      IrisHaptics.selectionClick();
      if (mounted) {
        showIrisFrostedSnackBar(
          context,
          content: Text('Tap ${5 - _tapCount} more times to open Developer & Beta Suite'),
          tint: const Color(0xFF6366F1),
          duration: const Duration(seconds: 1),
        );
      }
    } else {
      IrisHaptics.selectionClick();
    }
  }

  void _showDevControlSheet() {
    IrisHaptics.actionHeavy();
    final isDark = widget.isDark;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (ctx, setSheetState) {
            final currentTrack = RemoteConfigService.activeTrack.value;
            final isMinimal = ThemeSignals.useMinimalTheme.value;

            final isM3 = ThemeSignals.isMaterialYou;

            Widget sheetBody = Container(
              padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
              decoration: BoxDecoration(
                color: isM3
                    ? Theme.of(ctx).colorScheme.surfaceContainerHigh
                    : (isDark ? const Color(0xFF0F172A) : Colors.white),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
                border: isM3
                    ? null
                    : Border.all(
                        color: const Color(0xFF8B5CF6).withValues(alpha: isDark ? 0.35 : 0.2),
                        width: 1.2,
                      ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: const Color(0xFF8B5CF6).withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.developer_mode_rounded, color: Color(0xFF8B5CF6), size: 20),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Developer & Beta Suite',
                              style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w900,
                                color: isDark ? Colors.white : const Color(0xFF0F172A),
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              'Secret unlocked via 5-tap developer gesture',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w500,
                                color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.45),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // 1. Eco Mode (High Performance) Toggle Tile
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: isDark ? Colors.white.withValues(alpha: 0.04) : Colors.black.withValues(alpha: 0.03),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.08),
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: const Color(0xFF10B981).withValues(alpha: isDark ? 0.20 : 0.12),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(Icons.bolt_rounded, color: Color(0xFF10B981), size: 20),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Eco Mode (High Performance)',
                                style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800),
                              ),
                              const SizedBox(height: 1),
                              Text(
                                'Solid theme surfaces & zero GPU shaders',
                                style: TextStyle(
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w500,
                                  color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.45),
                                ),
                              ),
                            ],
                          ),
                        ),
                        IrisGlassSwitch(
                          value: isMinimal,
                          activeColor: const Color(0xFF10B981),
                          onChanged: (val) async {
                            IrisHaptics.selectionClick();
                            ThemeSignals.useMinimalTheme.value = val;
                            final prefs = await SharedPreferences.getInstance();
                            await prefs.setBool('use_minimal_ui', val);
                            setSheetState(() {});
                            if (mounted) setState(() {});
                            if (ctx.mounted) {
                              showIrisFrostedSnackBar(
                                ctx,
                                content: Text('⚡ Eco Mode: ${val ? "ENABLED" : "DISABLED"}'),
                                tint: val ? const Color(0xFF10B981) : const Color(0xFF6366F1),
                              );
                            }
                          },
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),
                  Text(
                    'RELEASE CHANNEL & CODE PUSH TRACK',
                    style: TextStyle(
                      fontSize: 10.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.2,
                      color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.4),
                    ),
                  ),
                  const SizedBox(height: 10),

                  // 2. Stable Channel Option
                  _buildTrackTile(
                    sheetCtx: ctx,
                    isDark: isDark,
                    trackId: 'stable',
                    title: 'Production Stable Channel',
                    subline: 'Official university releases (config/global)',
                    isSelected: currentTrack == 'stable',
                    accentColor: const Color(0xFF10B981),
                    icon: Icons.verified_rounded,
                    onSelect: () {
                      RemoteConfigService.switchReleaseTrack(ctx, 'stable');
                      setSheetState(() {});
                      if (mounted) setState(() {});
                    },
                  ),
                  const SizedBox(height: 8),

                  // 3. Beta Channel Option
                  _buildTrackTile(
                    sheetCtx: ctx,
                    isDark: isDark,
                    trackId: 'beta',
                    title: 'Beta Staging Channel',
                    subline: 'Pre-release timetable & exam date sheets (config/beta)',
                    isSelected: currentTrack == 'beta',
                    accentColor: const Color(0xFF8B5CF6),
                    icon: Icons.science_rounded,
                    onSelect: () {
                      RemoteConfigService.switchReleaseTrack(ctx, 'beta');
                      setSheetState(() {});
                      if (mounted) setState(() {});
                    },
                  ),

                  const SizedBox(height: 16),
                  InkWell(
                    onTap: () async {
                      IrisHaptics.actionMedium();
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.remove('helpdesk_faculty_cache_v2');
                      await prefs.remove('helpdesk_has_doc_draft');
                      if (ctx.mounted) {
                        showIrisFrostedSnackBar(
                          ctx,
                          content: const Text('Local caches & drafts cleared!'),
                          tint: const Color(0xFF10B981),
                        );
                      }
                    },
                    borderRadius: BorderRadius.circular(12),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 11),
                      decoration: BoxDecoration(
                        color: (isDark ? Colors.white : Colors.black).withValues(alpha: isDark ? 0.05 : 0.03),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.08),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.restore_rounded, size: 16, color: isDark ? Colors.amber[300] : Colors.amber[800]),
                          const SizedBox(width: 8),
                          Text(
                            'Clear Local Caches & Drafts',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: isDark ? Colors.white : const Color(0xFF0F172A),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );

            if (ThemeSignals.isFluidGlass) {
              sheetBody = ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
                child: GlassSurface(
                  settings: IrisGlass.settings(ctx, blur: 16.0, thickness: 14.0),
                  radius: 28,
                  child: sheetBody,
                ),
              );
            }

            return sheetBody;
          },
        );
      },
    );
  }

  Widget _buildTrackTile({
    required BuildContext sheetCtx,
    required bool isDark,
    required String trackId,
    required String title,
    required String subline,
    required bool isSelected,
    required Color accentColor,
    required IconData icon,
    required VoidCallback onSelect,
  }) {
    return InkWell(
      onTap: onSelect,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isSelected
              ? accentColor.withValues(alpha: isDark ? 0.18 : 0.08)
              : (isDark ? Colors.white : Colors.black).withValues(alpha: 0.04),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected
                ? accentColor.withValues(alpha: 0.6)
                : (isDark ? Colors.white : Colors.black).withValues(alpha: 0.08),
            width: isSelected ? 1.5 : 1.0,
          ),
        ),
        child: Row(
          children: [
            Icon(icon, color: isSelected ? accentColor : (isDark ? Colors.white60 : Colors.black45), size: 20),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: isDark ? Colors.white : const Color(0xFF0F172A),
                    ),
                  ),
                  const SizedBox(height: 1),
                  Text(
                    subline,
                    style: TextStyle(
                      fontSize: 10.5,
                      fontWeight: FontWeight.w500,
                      color: isDark ? Colors.white60 : Colors.black54,
                    ),
                  ),
                ],
              ),
            ),
            if (isSelected)
              Icon(Icons.check_circle_rounded, color: accentColor, size: 18),
          ],
        ),
      ),
    );
  }

  void _openEmail() async {
    IrisHaptics.actionMedium();
    final uri = Uri.parse('mailto:malikaurangzaibahmed@gmail.com?subject=IRIS%20Inquiry');
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: ThemeSignals.useMinimalTheme,
      builder: (context, useMinimal, _) {
        if (useMinimal && _controller.isAnimating) {
          _controller.stop();
        } else if (!useMinimal && !_controller.isAnimating) {
          _controller.repeat();
        }

        return AnimatedBuilder(
          animation: _controller,
          builder: (context, _) {
            final t = useMinimal ? 0.0 : _controller.value;

        return ExpressiveInteractivePress(
          onTap: _handleDevCardTap,
          pressedScale: 0.985,
          child: Container(
          width: double.infinity,
          constraints: const BoxConstraints(minHeight: 220),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF6366F1).withValues(alpha: 0.25),
                blurRadius: 28,
                offset: const Offset(0, 8),
              ),
            ],
            border: Border.all(
              color: Colors.white.withValues(alpha: 0.16),
              width: 1.2,
            ),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(28),
            child: Stack(
              children: [
                // 1. Fluid Moving Cosmic Gradient Mesh (Universal Cosmic Theme)
                Positioned.fill(
                  child: CustomPaint(
                    painter: _MovingCosmicMeshPainter(
                      isDark: true,
                      progress: t,
                    ),
                  ),
                ),

                // 2. Starry Halftone White Dot Matrix Grid (Gemini Texture)
                Positioned.fill(
                  child: CustomPaint(
                    painter: _HalftoneDotsPainter(
                      isDark: true,
                      animationProgress: t,
                    ),
                  ),
                ),

                // 3. Foreground Content
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 34),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      // Developer Name
                      Text(
                        'Malik Aurangzaib Ahmed',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -0.4,
                          height: 1.15,
                          color: Colors.white,
                          shadows: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.7),
                              blurRadius: 12,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 18),

                      // Interactive Email Contact Pill
                      Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: _openEmail,
                          borderRadius: BorderRadius.circular(22),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 10,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.black.withValues(alpha: 0.60),
                              borderRadius: BorderRadius.circular(22),
                              border: Border.all(
                                color: Colors.white.withValues(alpha: 0.22),
                                width: 1.2,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: 0.40),
                                  blurRadius: 12,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(5),
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    gradient: LinearGradient(
                                      colors: [Color(0xFF38BDF8), Color(0xFF818CF8)],
                                    ),
                                  ),
                                  child: const Icon(
                                    Icons.mail_outline_rounded,
                                    size: 13,
                                    color: Colors.white,
                                  ),
                                ),
                                const SizedBox(width: 9),
                                const Text(
                                  'malikaurangzaibahmed@gmail.com',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: -0.1,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
},
);
}
}

/// Paints the animated moving cosmic gradient mesh inspired by Google Gemini
class _MovingCosmicMeshPainter extends CustomPainter {
  final bool isDark;
  final double progress;

  _MovingCosmicMeshPainter({
    required this.isDark,
    required this.progress,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // 1. Deep Solid Base Background
    final baseColor = isDark ? const Color(0xFF030712) : const Color(0xFFF8FAFC);
    canvas.drawRect(Rect.fromLTWH(0, 0, w, h), Paint()..color = baseColor);

    final angle = progress * 2 * math.pi;

    // Harmonic Color Palette Transition
    final color1 = _cycleColor(progress, const [
      Color(0xFF1D4ED8), // Royal Blue
      Color(0xFF6D28D9), // Deep Violet
      Color(0xFFBE185D), // Rose Magenta
      Color(0xFF0284C7), // Sky Blue
      Color(0xFF1D4ED8),
    ]);

    final color2 = _cycleColor(progress + 0.25, const [
      Color(0xFF7C3AED), // Cosmic Violet
      Color(0xFFD946EF), // Fuchsia / Neon Pink
      Color(0xFF06B6D4), // Electric Cyan
      Color(0xFF4F46E5), // Indigo
      Color(0xFF7C3AED),
    ]);

    final color3 = _cycleColor(progress + 0.50, const [
      Color(0xFFE11D48), // Rose Red
      Color(0xFF0EA5E9), // Ocean Cyan
      Color(0xFF8B5CF6), // Royal Purple
      Color(0xFFC026D3), // Magenta
      Color(0xFFE11D48),
    ]);

    final color4 = _cycleColor(progress + 0.75, const [
      Color(0xFF06B6D4), // Cyan Glow
      Color(0xFF3B82F6), // Azure
      Color(0xFFA855F7), // Orchid
      Color(0xFF2563EB), // Sapphire
      Color(0xFF06B6D4),
    ]);

    // 2. Orb 1: Primary Swirling Emitter (Bottom-Left Lissajous Orbit)
    final orb1X = w * (0.30 + math.sin(angle) * 0.22);
    final orb1Y = h * (0.80 + math.cos(angle * 1.5) * 0.16);
    final orb1Radius = w * 0.92;

    final paint1 = Paint()
      ..shader = RadialGradient(
        colors: [
          color1.withValues(alpha: isDark ? 0.82 : 0.38),
          color1.withValues(alpha: isDark ? 0.42 : 0.18),
          Colors.transparent,
        ],
        stops: const [0.0, 0.48, 1.0],
      ).createShader(Rect.fromCircle(center: Offset(orb1X, orb1Y), radius: orb1Radius));

    canvas.drawCircle(Offset(orb1X, orb1Y), orb1Radius, paint1);

    // 3. Orb 2: Secondary Swirling Emitter (Bottom-Right Harmonic Orbit)
    final orb2X = w * (0.70 + math.cos(angle + math.pi / 4) * 0.24);
    final orb2Y = h * (0.85 + math.sin(angle + math.pi / 4) * 0.14);
    final orb2Radius = w * 0.88;

    final paint2 = Paint()
      ..shader = RadialGradient(
        colors: [
          color2.withValues(alpha: isDark ? 0.78 : 0.34),
          color2.withValues(alpha: isDark ? 0.36 : 0.15),
          Colors.transparent,
        ],
        stops: const [0.0, 0.52, 1.0],
      ).createShader(Rect.fromCircle(center: Offset(orb2X, orb2Y), radius: orb2Radius));

    canvas.drawCircle(Offset(orb2X, orb2Y), orb2Radius, paint2);

    // 4. Orb 3: Central Ambient Core Pulse
    final orb3X = w * (0.50 + math.sin(angle * 1.8) * 0.14);
    final orb3Y = h * (0.62 + math.cos(angle * 1.2) * 0.10);
    final orb3Radius = w * 0.78;

    final paint3 = Paint()
      ..shader = RadialGradient(
        colors: [
          color3.withValues(alpha: isDark ? 0.58 : 0.24),
          color3.withValues(alpha: isDark ? 0.20 : 0.08),
          Colors.transparent,
        ],
        stops: const [0.0, 0.50, 1.0],
      ).createShader(Rect.fromCircle(center: Offset(orb3X, orb3Y), radius: orb3Radius));

    canvas.drawCircle(Offset(orb3X, orb3Y), orb3Radius, paint3);

    // 5. Orb 4: Upper Celestial Aura Arc
    final orb4X = w * (0.50 + math.cos(angle * 0.8) * 0.30);
    final orb4Y = h * (0.25 + math.sin(angle * 0.8) * 0.12);
    final orb4Radius = w * 0.70;

    final paint4 = Paint()
      ..shader = RadialGradient(
        colors: [
          color4.withValues(alpha: isDark ? 0.40 : 0.16),
          Colors.transparent,
        ],
        stops: const [0.0, 1.0],
      ).createShader(Rect.fromCircle(center: Offset(orb4X, orb4Y), radius: orb4Radius));

    canvas.drawCircle(Offset(orb4X, orb4Y), orb4Radius, paint4);

    // 6. Smooth Depth Vignette
    final vignettePaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          baseColor.withValues(alpha: isDark ? 0.40 : 0.15),
          Colors.transparent,
          baseColor.withValues(alpha: isDark ? 0.50 : 0.20),
        ],
        stops: const [0.0, 0.45, 1.0],
      ).createShader(Rect.fromLTWH(0, 0, w, h));

    canvas.drawRect(Rect.fromLTWH(0, 0, w, h), vignettePaint);
  }

  Color _cycleColor(double p, List<Color> colors) {
    final normalized = p % 1.0;
    final count = colors.length - 1;
    final rawIndex = normalized * count;
    final index = rawIndex.floor();
    final nextIndex = (index + 1) % colors.length;
    final t = rawIndex - index;
    // Smooth cosine interpolation curve for silky transitions
    final smoothT = (1.0 - math.cos(t * math.pi)) / 2.0;
    return Color.lerp(colors[index], colors[nextIndex], smoothT)!;
  }

  @override
  bool shouldRepaint(covariant _MovingCosmicMeshPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.isDark != isDark;
}

/// Paints the starry halftone dot matrix grid with soft vertical & radial fading
class _HalftoneDotsPainter extends CustomPainter {
  final bool isDark;
  final double animationProgress;

  _HalftoneDotsPainter({
    required this.isDark,
    required this.animationProgress,
  });

  @override
  void paint(Canvas canvas, Size size) {
    const double spacing = 11.0;
    final int cols = (size.width / spacing).ceil() + 1;
    final int rows = (size.height / spacing).ceil() + 1;

    final basePaint = Paint()..style = PaintingStyle.fill;
    final dotColor = isDark ? Colors.white : const Color(0xFF0F172A);

    for (int r = 0; r < rows; r++) {
      final y = r * spacing;
      // Progressive vertical factor (denser at bottom, atmospheric at top)
      final verticalFactor = (y / size.height).clamp(0.0, 1.0);
      if (verticalFactor < 0.22) continue; // Keep top spark area clean

      // Exponential cubic falloff
      final rowOpacity = math.pow((verticalFactor - 0.22) / 0.78, 2.2).toDouble();

      for (int c = 0; c < cols; c++) {
        final x = c * spacing;

        // Dual-frequency starry twinkle wave
        final wave1 = math.sin((x / 22.0) + (animationProgress * 2 * math.pi) + (y / 18.0));
        final wave2 = math.cos((x / 32.0) - (animationProgress * 2 * math.pi * 0.8) + (y / 26.0));
        final combinedWave = (wave1 * 0.6) + (wave2 * 0.4);

        final dotRadius = (0.75 + (verticalFactor * 1.35) + (combinedWave * 0.22)).clamp(0.4, 2.3);

        final opacity = (rowOpacity * (isDark ? 0.38 : 0.22) + (combinedWave * 0.05))
            .clamp(0.0, isDark ? 0.52 : 0.28);

        basePaint.color = dotColor.withValues(alpha: opacity);
        canvas.drawCircle(Offset(x, y), dotRadius, basePaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _HalftoneDotsPainter oldDelegate) =>
      oldDelegate.animationProgress != animationProgress ||
      oldDelegate.isDark != isDark;
}