import 'package:flutter/material.dart';
import '../../core/animations.dart';
import '../../core/sticker_tokens.dart';

/// Tactile, authentic Sticker Card container for Material 3 Expressive mode.
///
/// Features solid pastel fills, crisp ink/chalk stroke borders, zero-blur
/// hardware-accelerated cardboard drop shadows, and spring press physics.
class StickerCard extends StatelessWidget {
  final Widget child;
  final Color backgroundColor;
  final Color? borderColor;
  final double borderWidth;
  final double borderRadius;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry? margin;
  final VoidCallback? onTap;
  final double shadowOffset;
  final Color? shadowColor;
  final double pressedScale;
  final Widget? cornerBadge;
  final Alignment cornerBadgeAlignment;
  final double rotationAngle;
  final bool enable3DTilt;
  final bool clipContent;
  final List<Widget>? floatingDecorations;

  const StickerCard({
    super.key,
    required this.child,
    required this.backgroundColor,
    this.borderColor,
    this.borderWidth = StickerTokens.strokeWidth,
    this.borderRadius = StickerTokens.cardRadius,
    this.padding = const EdgeInsets.all(16.0),
    this.margin,
    this.onTap,
    this.shadowOffset = 3.2,
    this.shadowColor,
    this.pressedScale = 0.96,
    this.cornerBadge,
    this.cornerBadgeAlignment = Alignment.topRight,
    this.rotationAngle = 0.0,
    this.enable3DTilt = false,
    this.clipContent = false,
    this.floatingDecorations,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final effectiveBorderColor = borderColor ?? StickerTokens.inkOutline(isDark);

    Widget innerChild = Padding(
      padding: padding,
      child: child,
    );

    if (clipContent) {
      innerChild = ClipRRect(
        borderRadius: BorderRadius.circular(
          (borderRadius - borderWidth).clamp(0.0, double.infinity),
        ),
        child: innerChild,
      );
    }

    Widget cardBody = Container(
      margin: margin,
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(borderRadius),
        border: Border.all(
          color: effectiveBorderColor,
          width: borderWidth,
        ),
        boxShadow: StickerTokens.stickerShadow(
          isDark,
          offset: shadowOffset,
          customColor: shadowColor,
        ),
      ),
      child: innerChild,
    );

    if (cornerBadge != null || (floatingDecorations != null && floatingDecorations!.isNotEmpty)) {
      cardBody = Stack(
        clipBehavior: Clip.none,
        children: [
          cardBody,
          if (cornerBadge != null)
            Positioned(
              top: cornerBadgeAlignment == Alignment.topRight ||
                      cornerBadgeAlignment == Alignment.topLeft
                  ? -8
                  : null,
              bottom: cornerBadgeAlignment == Alignment.bottomRight ||
                      cornerBadgeAlignment == Alignment.bottomLeft
                  ? -8
                  : null,
              right: cornerBadgeAlignment == Alignment.topRight ||
                      cornerBadgeAlignment == Alignment.bottomRight
                  ? 10
                  : null,
              left: cornerBadgeAlignment == Alignment.topLeft ||
                      cornerBadgeAlignment == Alignment.bottomLeft
                  ? 10
                  : null,
              child: cornerBadge!,
            ),
          if (floatingDecorations != null) ...floatingDecorations!,
        ],
      );
    }

    if (onTap != null) {
      return ExpressiveInteractivePress(
        onTap: onTap,
        pressedScale: pressedScale,
        enable3DTilt: enable3DTilt,
        baseRotation: rotationAngle,
        child: cardBody,
      );
    }

    return cardBody;
  }
}
