import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

enum SpeechTailPosition { bottomLeft, bottomRight, left, bottomCenter, none }

/// Authentic Hand-Sketched Comic Speech Bubble with Pointer Tail and Hatch Lines.
class DoodleSpeechBubble extends StatelessWidget {
  final String text;
  final String? emoji;
  final Color? backgroundColor;
  final Color? textColor;
  final Color? borderColor;
  final SpeechTailPosition tailPosition;
  final bool hasHatchLines;
  final VoidCallback? onTap;

  const DoodleSpeechBubble({
    super.key,
    required this.text,
    this.emoji,
    this.backgroundColor,
    this.textColor,
    this.borderColor,
    this.tailPosition = SpeechTailPosition.bottomLeft,
    this.hasHatchLines = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = backgroundColor ??
        (isDark ? const Color(0xFF1E2D24) : const Color(0xFFD1FAE5));
    final border = borderColor ??
        (isDark ? const Color(0xFF34D399) : const Color(0xFF065F46));
    final fg = textColor ??
        (isDark ? const Color(0xFF6EE7B7) : const Color(0xFF065F46));
    final shadowColor = isDark ? Colors.black54 : const Color(0x3B065F46);

    Widget content = Padding(
      padding: EdgeInsets.fromLTRB(
        tailPosition == SpeechTailPosition.left ? 14 : 12,
        6,
        12,
        (tailPosition == SpeechTailPosition.bottomLeft ||
                tailPosition == SpeechTailPosition.bottomCenter ||
                tailPosition == SpeechTailPosition.bottomRight)
            ? 12
            : 6,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            text,
            style: GoogleFonts.poppins(
              fontSize: 11.0,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.3,
              color: fg,
            ),
          ),
          if (emoji != null) ...[
            const SizedBox(width: 5),
            Text(emoji!, style: const TextStyle(fontSize: 12)),
          ],
        ],
      ),
    );

    Widget bubble = CustomPaint(
      painter: ComicSpeechBubblePainter(
        backgroundColor: bg,
        outlineColor: border,
        outlineWidth: 1.8,
        shadowColor: shadowColor,
        shadowOffset: 2.2,
        tailPosition: tailPosition,
        hasHatchLines: hasHatchLines,
        hatchColor: border.withValues(alpha: 0.35),
      ),
      child: content,
    );

    if (onTap != null) {
      return GestureDetector(
        onTap: onTap,
        child: bubble,
      );
    }
    return bubble;
  }
}

class ComicSpeechBubblePainter extends CustomPainter {
  final Color backgroundColor;
  final Color outlineColor;
  final double outlineWidth;
  final Color shadowColor;
  final double shadowOffset;
  final SpeechTailPosition tailPosition;
  final bool hasHatchLines;
  final Color? hatchColor;

  const ComicSpeechBubblePainter({
    required this.backgroundColor,
    required this.outlineColor,
    required this.outlineWidth,
    required this.shadowColor,
    required this.shadowOffset,
    this.tailPosition = SpeechTailPosition.bottomLeft,
    this.hasHatchLines = false,
    this.hatchColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;

    final w = size.width;
    final tailH = (tailPosition == SpeechTailPosition.bottomLeft ||
            tailPosition == SpeechTailPosition.bottomCenter ||
            tailPosition == SpeechTailPosition.bottomRight)
        ? 6.5
        : 0.0;
    final h = size.height - tailH;
    final r = math.min(14.0, h * 0.45);

    // Optional hatched sketch lines behind the bubble
    if (hasHatchLines) {
      final hatchPaint = Paint()
        ..color = hatchColor ?? outlineColor.withValues(alpha: 0.35)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..strokeCap = StrokeCap.round;

      for (double x = -6; x < w + 8; x += 5.5) {
        canvas.drawLine(Offset(x, h + 4), Offset(x + 7, -3), hatchPaint);
      }
    }

    final path = Path();
    path.moveTo(r, 0);
    path.lineTo(w - r, 0);
    path.arcToPoint(Offset(w, r), radius: Radius.circular(r));

    if (tailPosition == SpeechTailPosition.left) {
      path.lineTo(w, h - r);
      path.arcToPoint(Offset(w - r, h), radius: Radius.circular(r));
      path.lineTo(r, h);
      path.arcToPoint(Offset(0, h - r), radius: Radius.circular(r));
      // Pointer tail on left side
      path.lineTo(0, h * 0.68);
      path.lineTo(-7.5, h * 0.48);
      path.lineTo(0, h * 0.32);
      path.lineTo(0, r);
      path.arcToPoint(Offset(r, 0), radius: Radius.circular(r));
    } else if (tailPosition == SpeechTailPosition.bottomLeft) {
      path.lineTo(w, h - r);
      path.arcToPoint(Offset(w - r, h), radius: Radius.circular(r));
      path.lineTo(r + 16, h);
      // Pointer tail pointing down-left
      path.lineTo(r + 2, h + tailH);
      path.lineTo(r + 7, h);
      path.lineTo(r, h);
      path.arcToPoint(Offset(0, h - r), radius: Radius.circular(r));
      path.lineTo(0, r);
      path.arcToPoint(Offset(r, 0), radius: Radius.circular(r));
    } else if (tailPosition == SpeechTailPosition.bottomCenter) {
      path.lineTo(w, h - r);
      path.arcToPoint(Offset(w - r, h), radius: Radius.circular(r));
      path.lineTo(w * 0.58, h);
      // Pointer tail pointing down
      path.lineTo(w * 0.48, h + tailH);
      path.lineTo(w * 0.42, h);
      path.lineTo(r, h);
      path.arcToPoint(Offset(0, h - r), radius: Radius.circular(r));
      path.lineTo(0, r);
      path.arcToPoint(Offset(r, 0), radius: Radius.circular(r));
    } else if (tailPosition == SpeechTailPosition.bottomRight) {
      path.lineTo(w, h - r);
      path.arcToPoint(Offset(w - r, h), radius: Radius.circular(r));
      path.lineTo(w - r - 7, h);
      // Pointer tail pointing down-right
      path.lineTo(w - r - 2, h + tailH);
      path.lineTo(w - r - 16, h);
      path.lineTo(r, h);
      path.arcToPoint(Offset(0, h - r), radius: Radius.circular(r));
      path.lineTo(0, r);
      path.arcToPoint(Offset(r, 0), radius: Radius.circular(r));
    } else {
      path.lineTo(w, h - r);
      path.arcToPoint(Offset(w - r, h), radius: Radius.circular(r));
      path.lineTo(r, h);
      path.arcToPoint(Offset(0, h - r), radius: Radius.circular(r));
      path.lineTo(0, r);
      path.arcToPoint(Offset(r, 0), radius: Radius.circular(r));
    }

    // 1. Tactile ambient depth blur shadow (physical lift off paper)
    final ambientPaint = Paint()
      ..color = shadowColor.withValues(alpha: 0.25)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.5);
    canvas.drawPath(path.shift(Offset(0.6, shadowOffset + 0.8)), ambientPaint);

    // 2. Zero-blur cardboard shadow
    final shadowPaint = Paint()
      ..color = shadowColor
      ..style = PaintingStyle.fill;
    canvas.drawPath(path.shift(Offset(1.2, shadowOffset)), shadowPaint);

    // 2. Solid fill
    final fillPaint = Paint()
      ..color = backgroundColor
      ..style = PaintingStyle.fill;
    canvas.drawPath(path, fillPaint);

    // 3. Crisp ink outline
    final strokePaint = Paint()
      ..color = outlineColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = outlineWidth
      ..strokeJoin = StrokeJoin.round
      ..isAntiAlias = true;
    canvas.drawPath(path, strokePaint);
  }

  @override
  bool shouldRepaint(covariant ComicSpeechBubblePainter old) => true;
}

/// Authentic Comic Jagged Starburst Stamp Badge (e.g. for "NEW" or "Sim" badges).
class JaggedStampBadge extends StatelessWidget {
  final String label;
  final Color? backgroundColor;
  final Color? textColor;
  final Color? borderColor;

  const JaggedStampBadge({
    super.key,
    required this.label,
    this.backgroundColor,
    this.textColor,
    this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = backgroundColor ??
        (isDark ? const Color(0xFF263820) : const Color(0xFFD9F99D));
    final border = borderColor ??
        (isDark ? const Color(0xFF84CC16) : const Color(0xFF3B6E0B));
    final fg = textColor ??
        (isDark ? const Color(0xFFBEF264) : const Color(0xFF26400A));

    return CustomPaint(
      painter: StarburstStampPainter(
        backgroundColor: bg,
        outlineColor: border,
        outlineWidth: 1.6,
        shadowColor: isDark ? Colors.black45 : const Color(0x3B000000),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        child: Text(
          label,
          style: GoogleFonts.poppins(
            fontSize: 9.5,
            fontWeight: FontWeight.w900,
            letterSpacing: 0.6,
            color: fg,
          ),
        ),
      ),
    );
  }
}

class StarburstStampPainter extends CustomPainter {
  final Color backgroundColor;
  final Color outlineColor;
  final double outlineWidth;
  final Color shadowColor;

  const StarburstStampPainter({
    required this.backgroundColor,
    required this.outlineColor,
    this.outlineWidth = 1.6,
    required this.shadowColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;
    final w = size.width;
    final h = size.height;
    final cx = w / 2;
    final cy = h / 2;

    const points = 12;
    final rxOuter = w / 2;
    final ryOuter = h / 2;
    final rxInner = rxOuter * 0.80;
    final ryInner = ryOuter * 0.80;

    final path = Path();
    for (int i = 0; i < points * 2; i++) {
      final angle = (i * math.pi / points) - (math.pi / 2);
      final rx = (i % 2 == 0) ? rxOuter : rxInner;
      final ry = (i % 2 == 0) ? ryOuter : ryInner;
      final x = cx + rx * math.cos(angle);
      final y = cy + ry * math.sin(angle);
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    path.close();

    // 1. Shadow
    canvas.drawPath(
      path.shift(const Offset(1.2, 2.0)),
      Paint()..color = shadowColor..style = PaintingStyle.fill,
    );
    // 2. Fill
    canvas.drawPath(
      path,
      Paint()..color = backgroundColor..style = PaintingStyle.fill,
    );
    // 3. Outline
    canvas.drawPath(
      path,
      Paint()
        ..color = outlineColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = outlineWidth
        ..strokeJoin = StrokeJoin.miter
        ..isAntiAlias = true,
    );
  }

  @override
  bool shouldRepaint(covariant StarburstStampPainter old) => true;
}
