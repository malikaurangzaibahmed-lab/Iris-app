import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import 'package:material_3_expressive/material_3_expressive.dart';

import '../../core/animations.dart';
import '../../core/glass.dart';
import '../../core/sticker_tokens.dart';
import '../../core/theme_signals.dart';
import '../../core/tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/ui_feedback.dart';

class IrisGlassSwitch extends StatefulWidget {
  final bool value;
  final ValueChanged<bool> onChanged;
  final Color? activeColor;

  const IrisGlassSwitch({
    required this.value,
    required this.onChanged,
    this.activeColor,
    super.key,
  });

  @override
  State<IrisGlassSwitch> createState() => _IrisGlassSwitchState();
}

class _IrisGlassSwitchState extends State<IrisGlassSwitch> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _thumbPosAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );
    _thumbPosAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOutCubic),
    );
    if (widget.value) {
      _controller.value = 1.0;
    }
  }

  @override
  void didUpdateWidget(covariant IrisGlassSwitch oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.value != oldWidget.value) {
      if (widget.value) {
        _controller.forward();
      } else {
        _controller.reverse();
      }
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, themeStyle, _) {
        final isM3 = themeStyle == IrisThemeStyle.materialYou;

        if (themeStyle == IrisThemeStyle.notebook) {
          final isDark = Theme.of(context).brightness == Brightness.dark;
          final borderCol = NotebookTokens.inkMuted(isDark).withValues(alpha: 0.4);
          final activeCol = widget.activeColor ?? NotebookTokens.redDoodle(isDark);
          final inactiveTrack = NotebookTokens.cardSurface(isDark);
          final activeTrack = isDark ? const Color(0xFF1E2E25) : const Color(0xFFF0ECE1);

          return GestureDetector(
            onTap: () {
              IrisHaptics.selectionClick();
              widget.onChanged(!widget.value);
            },
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                final val = _thumbPosAnim.value;
                final trackColor = Color.lerp(inactiveTrack, activeTrack, val)!;
                final thumbColor = Color.lerp(
                  NotebookTokens.inkMuted(isDark),
                  activeCol,
                  val,
                )!;

                return Container(
                  width: 48,
                  height: 26,
                  padding: const EdgeInsets.all(2.0),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    color: trackColor,
                    border: Border.all(color: borderCol, width: 1.2),
                  ),
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.lerp(Alignment.centerLeft, Alignment.centerRight, val)!,
                        child: Container(
                          width: 20,
                          height: 20,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4),
                            color: thumbColor,
                          ),
                          child: Center(
                            child: AnimatedOpacity(
                              duration: const Duration(milliseconds: 150),
                              opacity: val > 0.5 ? 1.0 : 0.0,
                              child: const Icon(
                                Icons.check_rounded,
                                size: 12,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        }

        if (themeStyle == IrisThemeStyle.line) {
          final isDark = Theme.of(context).brightness == Brightness.dark;
          final borderCol = LineTokens.railLine(isDark);
          final activeCol = widget.activeColor ?? LineTokens.subwayYellow;
          final inactiveTrack = LineTokens.cardSurface(isDark);
          final activeTrack = isDark ? const Color(0xFF1E242B) : const Color(0xFFE8E5DD);

          return GestureDetector(
            onTap: () {
              IrisHaptics.selectionClick();
              widget.onChanged(!widget.value);
            },
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                final val = _thumbPosAnim.value;
                final trackColor = Color.lerp(inactiveTrack, activeTrack, val)!;
                final thumbColor = Color.lerp(
                  LineTokens.inkMuted(isDark),
                  activeCol,
                  val,
                )!;

                return Container(
                  width: 48,
                  height: 26,
                  padding: const EdgeInsets.all(2.0),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    color: trackColor,
                    border: Border.all(color: borderCol, width: 1.5),
                  ),
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.lerp(Alignment.centerLeft, Alignment.centerRight, val)!,
                        child: Container(
                          width: 20,
                          height: 20,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(2),
                            color: thumbColor,
                          ),
                          child: Center(
                            child: AnimatedOpacity(
                              duration: const Duration(milliseconds: 150),
                              opacity: val > 0.5 ? 1.0 : 0.0,
                              child: const Icon(
                                Icons.check_rounded,
                                size: 12,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        }

        if (themeStyle == IrisThemeStyle.poster) {
          final isDark = Theme.of(context).brightness == Brightness.dark;
          final borderCol = PosterTokens.inkBorder(isDark);
          final activeCol = widget.activeColor ?? PosterTokens.orangeHero;
          final inactiveTrack = PosterTokens.cardSurface(isDark);
          final activeTrack = isDark ? const Color(0xFF261D16) : const Color(0xFFFFECE5);

          return GestureDetector(
            onTap: () {
              IrisHaptics.selectionClick();
              widget.onChanged(!widget.value);
            },
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                final val = _thumbPosAnim.value;
                final trackColor = Color.lerp(inactiveTrack, activeTrack, val)!;
                final thumbColor = Color.lerp(
                  isDark ? Colors.white30 : Colors.black26,
                  activeCol,
                  val,
                )!;

                return Container(
                  width: 50,
                  height: 28,
                  padding: const EdgeInsets.all(2.0),
                  decoration: BoxDecoration(
                    color: trackColor,
                    border: Border.all(color: borderCol, width: 2.2),
                    boxShadow: [
                      BoxShadow(color: borderCol, offset: const Offset(2, 2), blurRadius: 0),
                    ],
                  ),
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.lerp(Alignment.centerLeft, Alignment.centerRight, val)!,
                        child: Container(
                          width: 20,
                          height: 20,
                          color: thumbColor,
                          child: Center(
                            child: AnimatedOpacity(
                              duration: const Duration(milliseconds: 150),
                              opacity: val > 0.5 ? 1.0 : 0.0,
                              child: const Icon(
                                Icons.check_rounded,
                                size: 13,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        }

        if (themeStyle == IrisThemeStyle.editorialAcademic) {
          final isDark = Theme.of(context).brightness == Brightness.dark;
          final borderCol = EditorialTokens.cardBorder(isDark);
          final activeCol = widget.activeColor ?? EditorialTokens.accentUpcoming;
          final inactiveTrack = EditorialTokens.cardSurface(isDark);
          final activeTrack = isDark ? const Color(0xFF1E2833) : const Color(0xFFE8EEF5);

          return GestureDetector(
            onTap: () {
              IrisHaptics.selectionClick();
              widget.onChanged(!widget.value);
            },
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                final val = _thumbPosAnim.value;
                final trackColor = Color.lerp(inactiveTrack, activeTrack, val)!;
                final thumbColor = Color.lerp(
                  EditorialTokens.inkMuted(isDark),
                  activeCol,
                  val,
                )!;

                return Container(
                  width: 48,
                  height: 26,
                  padding: const EdgeInsets.all(2.0),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(13),
                    color: trackColor,
                    border: Border.all(color: borderCol, width: 1.2),
                  ),
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.lerp(Alignment.centerLeft, Alignment.centerRight, val)!,
                        child: Container(
                          width: 20,
                          height: 20,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: thumbColor,
                          ),
                          child: Center(
                            child: AnimatedOpacity(
                              duration: const Duration(milliseconds: 150),
                              opacity: val > 0.5 ? 1.0 : 0.0,
                              child: const Icon(
                                Icons.check_rounded,
                                size: 12,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        }

        if (themeStyle == IrisThemeStyle.almanac) {
          final isDark = Theme.of(context).brightness == Brightness.dark;
          final ruleColor = AlmanacTokens.inkRule(isDark);
          final activeCol = widget.activeColor ?? AlmanacTokens.accentTerracotta(isDark);
          final inactiveTrack = AlmanacTokens.canvas(isDark);
          final activeTrack = isDark ? const Color(0xFF261916) : const Color(0xFFF7EBE8);

          return GestureDetector(
            onTap: () {
              IrisHaptics.selectionClick();
              widget.onChanged(!widget.value);
            },
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                final val = _thumbPosAnim.value;
                final trackColor = Color.lerp(inactiveTrack, activeTrack, val)!;
                final thumbColor = Color.lerp(
                  AlmanacTokens.inkMuted(isDark),
                  activeCol,
                  val,
                )!;

                return Container(
                  width: 48,
                  height: 26,
                  padding: const EdgeInsets.all(2.0),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    color: trackColor,
                    border: Border.all(
                      color: ruleColor,
                      width: 1.0,
                    ),
                  ),
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.lerp(Alignment.centerLeft, Alignment.centerRight, val)!,
                        child: Container(
                          width: 20,
                          height: 20,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(2),
                            color: thumbColor,
                          ),
                          child: Center(
                            child: AnimatedOpacity(
                              duration: const Duration(milliseconds: 150),
                              opacity: val > 0.5 ? 1.0 : 0.0,
                              child: const Icon(
                                Icons.check_rounded,
                                size: 12,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        }

        if (isM3) {
          final isDark = Theme.of(context).brightness == Brightness.dark;
          final outline = StickerTokens.inkOutline(isDark);
          final activeCol = widget.activeColor ??
              (isDark ? const Color(0xFF10B981) : const Color(0xFF059669));
          final inactiveTrack = isDark ? const Color(0xFF222936) : const Color(0xFFEDE8DE);
          final activeTrack = isDark ? const Color(0xFF143828) : const Color(0xFFD1FAE5);

          return GestureDetector(
            onTap: () {
              IrisHaptics.selectionClick();
              widget.onChanged(!widget.value);
            },
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                final val = _thumbPosAnim.value;
                final trackColor = Color.lerp(inactiveTrack, activeTrack, val)!;
                final thumbColor = Color.lerp(
                  isDark ? const Color(0xFF94A3B8) : Colors.white,
                  activeCol,
                  val,
                )!;

                return Container(
                  width: 50,
                  height: 28,
                  padding: const EdgeInsets.all(2.5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    color: trackColor,
                    border: Border.all(
                      color: outline,
                      width: 1.6,
                    ),
                    boxShadow: StickerTokens.stickerShadow(isDark, offset: 1.8),
                  ),
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.lerp(Alignment.centerLeft, Alignment.centerRight, val)!,
                        child: Container(
                          width: 21,
                          height: 21,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: thumbColor,
                            border: Border.all(
                              color: outline,
                              width: 1.4,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: isDark ? Colors.black45 : const Color(0x3B2C221A),
                                offset: const Offset(0.8, 1.2),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Center(
                            child: AnimatedOpacity(
                              duration: const Duration(milliseconds: 150),
                              opacity: val > 0.5 ? 1.0 : 0.0,
                              child: const Icon(
                                Icons.check_rounded,
                                size: 12,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        }

        final isDark = Theme.of(context).brightness == Brightness.dark;
        final activeCol = widget.activeColor ?? IrisTokens.brand;

        return ValueListenableBuilder<double>(
          valueListenable: ThemeSignals.glassTransparency,
          builder: (context, transparency, _) {
            final isOpaque = transparency <= 0.08;
            final isMinimal = ThemeSignals.useMinimalTheme.value || isOpaque;

            if (!isMinimal) {
              // Authentic liquid_glass_widgets 1.14.2 GlassSwitch with 3D thumb jump & liquid refraction
              return lgw.GlassSwitch(
                value: widget.value,
                onChanged: (v) {
                  IrisHaptics.selectionClick();
                  widget.onChanged(v);
                },
                activeColor: activeCol,
                width: 52.0,
                height: 28.0,
                quality: IrisGlass.adaptiveQuality(context),
                settings: IrisGlass.widgetsSettings(
                  context,
                  blur: 14.0,
                  thickness: 14.0,
                  ambientStrength: 0.75,
                ),
              );
            }

            return GestureDetector(
              onTap: () {
                IrisHaptics.selectionClick();
                widget.onChanged(!widget.value);
              },
              child: AnimatedBuilder(
                animation: _controller,
                builder: (context, child) {
                  final val = _thumbPosAnim.value;
                  final jumpScale = 1.0 + 0.12 * math.sin(val * math.pi);

                  final inactiveTrackColor =
                      isDark ? const Color(0xFF1E293B) : const Color(0xFFCBD5E1);
                  final activeTrackColor = activeCol;

                  return Container(
                    width: 48,
                    height: 28,
                    padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(100),
                      color: Color.lerp(
                        inactiveTrackColor,
                        activeTrackColor,
                        val,
                      ),
                      border: Border.all(
                        color: Color.lerp(
                          isDark ? const Color(0xFF334155) : const Color(0xFF94A3B8),
                          activeCol,
                          val,
                        )!,
                        width: 1.0,
                      ),
                    ),
                    child: Stack(
                      children: [
                        Align(
                          alignment: Alignment.lerp(Alignment.centerLeft, Alignment.centerRight, val)!,
                          child: Transform.scale(
                            scale: jumpScale,
                            child: Container(
                              width: 20,
                              height: 20,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color.lerp(
                                  isDark ? Colors.white70 : const Color(0xFF64748B),
                                  Colors.white,
                                  val,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Color.lerp(
                                      Colors.black.withValues(alpha: 0.2),
                                      activeCol.withValues(alpha: 0.4),
                                      val,
                                    )!,
                                    blurRadius: 4,
                                    offset: const Offset(0, 1.5),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            );
          },
        );
      },
    ),);
  }
}

/// Adaptive Segmented Control: Liquid Glass in glass mode, authentic Google Pixel M3 Segmented Button in Material 3 mode
class IrisSegmentedControl extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onSegmentSelected;
  final List<String> segments;
  final double height;
  final TextStyle? selectedTextStyle;
  final TextStyle? unselectedTextStyle;
  final List<IconData>? icons;

  const IrisSegmentedControl({
    super.key,
    required this.selectedIndex,
    required this.onSegmentSelected,
    required this.segments,
    this.height = 40.0,
    this.selectedTextStyle,
    this.unselectedTextStyle,
    this.icons,
  });

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: ValueListenableBuilder<IrisThemeStyle>(
        valueListenable: ThemeSignals.themeStyle,
        builder: (context, style, _) {
          final isDark = Theme.of(context).brightness == Brightness.dark;

          if (style == IrisThemeStyle.notebook) {
            return Container(
              height: height,
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                color: NotebookTokens.cardSurface(isDark),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: NotebookTokens.inkMuted(isDark).withValues(alpha: 0.35),
                  width: 1.2,
                ),
              ),
              child: Row(
                children: List.generate(segments.length, (i) {
                  final isSel = selectedIndex == i;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () {
                        IrisHaptics.chipSelect();
                        onSegmentSelected(i);
                      },
                      child: Container(
                        height: double.infinity,
                        decoration: BoxDecoration(
                          color: isSel
                              ? NotebookTokens.stickyNote(isDark)
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(8),
                          border: isSel
                              ? Border.all(
                                  color: NotebookTokens.redDoodle(isDark).withValues(alpha: 0.6),
                                  width: 1.0,
                                )
                              : null,
                        ),
                        child: Center(
                          child: Text(
                            segments[i],
                            style: GoogleFonts.kalam(
                              fontSize: 12.5,
                              fontWeight: isSel ? FontWeight.w700 : FontWeight.w500,
                              color: isSel
                                  ? const Color(0xFF1A1F1C)
                                  : NotebookTokens.inkMuted(isDark),
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
            );
          }

          if (style == IrisThemeStyle.line) {
            return Container(
              height: height,
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                color: LineTokens.cardSurface(isDark),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(
                  color: LineTokens.railLine(isDark),
                  width: 1.5,
                ),
              ),
              child: Row(
                children: List.generate(segments.length, (i) {
                  final isSel = selectedIndex == i;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () {
                        IrisHaptics.chipSelect();
                        onSegmentSelected(i);
                      },
                      child: Container(
                        height: double.infinity,
                        decoration: BoxDecoration(
                          color: isSel ? LineTokens.subwayYellow : Colors.transparent,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Center(
                          child: Text(
                            segments[i].toUpperCase(),
                            style: GoogleFonts.spaceMono(
                              fontSize: 11,
                              fontWeight: isSel ? FontWeight.w900 : FontWeight.w600,
                              color: isSel ? Colors.black : LineTokens.inkMuted(isDark),
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
            );
          }

          if (style == IrisThemeStyle.poster) {
            return Container(
              height: height,
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                color: PosterTokens.cardSurface(isDark),
                border: Border.all(
                  color: PosterTokens.inkBorder(isDark),
                  width: 2.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: PosterTokens.inkBorder(isDark),
                    offset: const Offset(3, 3),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: Row(
                children: List.generate(segments.length, (i) {
                  final isSel = selectedIndex == i;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () {
                        IrisHaptics.chipSelect();
                        onSegmentSelected(i);
                      },
                      child: Container(
                        height: double.infinity,
                        color: isSel ? PosterTokens.orangeHero : Colors.transparent,
                        child: Center(
                          child: Text(
                            segments[i].toUpperCase(),
                            style: GoogleFonts.archivoBlack(
                              fontSize: 11,
                              color: isSel ? Colors.black : PosterTokens.inkHeading(isDark),
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
            );
          }

          if (style == IrisThemeStyle.almanac) {
            return Container(
              height: height,
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                color: AlmanacTokens.cardSurface(isDark),
                borderRadius: BorderRadius.circular(4),
                border: Border.all(
                  color: AlmanacTokens.inkRule(isDark),
                  width: 1.2,
                ),
              ),
              child: Row(
                children: List.generate(segments.length, (i) {
                  final isSel = selectedIndex == i;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () {
                        IrisHaptics.chipSelect();
                        onSegmentSelected(i);
                      },
                      child: Container(
                        height: double.infinity,
                        decoration: BoxDecoration(
                          color: isSel
                              ? AlmanacTokens.accentTerracotta(isDark)
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(2),
                        ),
                        child: Center(
                          child: Text(
                            segments[i],
                            style: GoogleFonts.playfairDisplay(
                              fontSize: 12,
                              fontWeight: isSel ? FontWeight.w700 : FontWeight.w500,
                              fontStyle: isSel ? FontStyle.normal : FontStyle.italic,
                              color: isSel ? Colors.white : AlmanacTokens.inkMuted(isDark),
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
            );
          }

          if (style == IrisThemeStyle.editorialAcademic) {
            return Container(
              height: height,
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                color: EditorialTokens.cardSurface(isDark),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: EditorialTokens.cardBorder(isDark),
                  width: 1.2,
                ),
              ),
              child: Row(
                children: List.generate(segments.length, (i) {
                  final isSel = selectedIndex == i;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () {
                        IrisHaptics.chipSelect();
                        onSegmentSelected(i);
                      },
                      child: Container(
                        height: double.infinity,
                        decoration: BoxDecoration(
                          color: isSel
                              ? EditorialTokens.accentUpcoming
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                          child: Text(
                            segments[i],
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 12,
                              fontWeight: isSel ? FontWeight.w800 : FontWeight.w600,
                              color: isSel ? Colors.white : EditorialTokens.inkMuted(isDark),
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
            );
          }

          if (style == IrisThemeStyle.fluidGlass) {
            return ValueListenableBuilder<double>(
              valueListenable: ThemeSignals.glassTransparency,
              builder: (context, transparency, _) {
                final isOpaque = transparency <= 0.08 || ThemeSignals.useMinimalTheme.value;
                return lgw.GlassSegmentedControl(
                  selectedIndex: selectedIndex,
                  onSegmentSelected: (idx) {
                    IrisHaptics.chipSelect();
                    onSegmentSelected(idx);
                  },
                  segments: segments,
                  height: height,
                  quality: isOpaque ? lgw.GlassQuality.minimal : lgw.GlassQuality.premium,
                  settings: IrisGlass.widgetsSettings(
                    context,
                    blur: 16.0,
                    thickness: 15.0,
                    ambientStrength: 0.75,
                  ),
                  selectedTextStyle: selectedTextStyle ??
                      TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                        color: isDark ? Colors.white : const Color(0xFF0F172A),
                      ),
                  unselectedTextStyle: unselectedTextStyle ??
                      TextStyle(
                        fontSize: 12.0,
                        fontWeight: FontWeight.w600,
                        color: isDark ? Colors.white70 : const Color(0xFF475569),
                      ),
                );
              },
            );
          }

          return M3ESegmentedButton<int>(
            segments: List.generate(segments.length, (i) {
              return M3ESegment<int>(
                value: i,
                label: segments[i],
                icon: icons != null && icons!.length > i ? Icon(icons![i]) : null,
              );
            }),
            selected: {selectedIndex},
            onSelectionChanged: (selectedSet) {
              if (selectedSet.isNotEmpty) {
                IrisHaptics.chipSelect();
                onSegmentSelected(selectedSet.first);
              }
            },
            density: segments.length >= 5
                ? M3ESegmentedButtonDensity.compact
                : M3ESegmentedButtonDensity.regular,
            multiSelect: false,
            showSelectedIcon: segments.length <= 3,
          );
        },
      ),
    );
  }
}



class IrisGlassMenu extends StatelessWidget {
  final lgw.GlassMenuAlignment menuAlignment;
  final Widget? child;
  final Widget Function(BuildContext, VoidCallback)? triggerBuilder;
  final List<Widget> Function(BuildContext)? itemBuilder;
  final List<Widget>? items;
  final bool autoAdjustToScreen;
  final EdgeInsets menuPadding;
  final double menuWidth;
  final double? menuHeight;
  final double menuBorderRadius;
  final double itemBorderRadius;
  final lgw.LiquidGlassSettings? settings;

  const IrisGlassMenu({
    super.key,
    this.menuAlignment = lgw.GlassMenuAlignment.bottomCenter,
    this.child,
    this.triggerBuilder,
    this.itemBuilder,
    this.items,
    this.autoAdjustToScreen = true,
    this.menuPadding = const EdgeInsets.all(12),
    this.menuWidth = 250.0,
    this.menuHeight,
    this.menuBorderRadius = 28.0,
    this.itemBorderRadius = 20.0,
    this.settings,
  }) : assert(child != null || triggerBuilder != null),
       assert(items != null || itemBuilder != null);

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: ValueListenableBuilder<IrisThemeStyle>(
        valueListenable: ThemeSignals.themeStyle,
        builder: (context, themeStyle, _) {
          final effectiveItems = items ?? (itemBuilder != null ? itemBuilder!(context) : <Widget>[]);

          if (themeStyle != IrisThemeStyle.fluidGlass) {
            return IrisExpressiveMenu(
              menuWidth: menuWidth,
              menuHeight: menuHeight,
              menuBorderRadius: menuBorderRadius,
              itemBorderRadius: itemBorderRadius,
              menuPadding: menuPadding,
              triggerBuilder: triggerBuilder,
              items: effectiveItems,
              child: child,
            );
          }

          return lgw.GlassMenu(
            menuAlignment: menuAlignment,
            autoAdjustToScreen: autoAdjustToScreen,
            enableContinuousSwipe: true,
            menuPadding: menuPadding,
            menuWidth: menuWidth,
            menuHeight: menuHeight,
            menuBorderRadius: menuBorderRadius,
            itemBorderRadius: itemBorderRadius,
            quality: IrisGlass.adaptiveQuality(context, isStaticHero: true),
            settings: settings ??
                IrisGlass.widgetsSettings(
                  context,
                  blur: 18.0,
                  thickness: 18.0,
                  ambientStrength: 0.78,
                ),
            items: effectiveItems,
            trigger: child,
            triggerBuilder: triggerBuilder,
          );
        },
      ),
    );
  }
}

/// Authentic Material 3 Expressive Animated Dropdown Menu with Android 15 Spring Motion.
class IrisExpressiveMenu extends StatefulWidget {
  final Widget? child;
  final Widget Function(BuildContext context, VoidCallback toggleMenu)? triggerBuilder;
  final List<Widget> items;
  final double menuWidth;
  final double? menuHeight;
  final double menuBorderRadius;
  final double itemBorderRadius;
  final EdgeInsets menuPadding;

  const IrisExpressiveMenu({
    super.key,
    this.child,
    this.triggerBuilder,
    required this.items,
    this.menuWidth = 250.0,
    this.menuHeight,
    this.menuBorderRadius = 28.0,
    this.itemBorderRadius = 20.0,
    this.menuPadding = const EdgeInsets.all(12),
  });

  @override
  State<IrisExpressiveMenu> createState() => _IrisExpressiveMenuState();
}

class _IrisExpressiveMenuState extends State<IrisExpressiveMenu>
    with SingleTickerProviderStateMixin {
  final GlobalKey _triggerKey = GlobalKey();
  OverlayEntry? _overlayEntry;
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;
  bool _isOpen = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 240),
      reverseDuration: const Duration(milliseconds: 180),
    );
    _scaleAnimation = Tween<double>(begin: 0.88, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeOutBack,
        reverseCurve: Curves.easeInCubic,
      ),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeOutCubic,
        reverseCurve: Curves.easeInCubic,
      ),
    );
  }

  @override
  void dispose() {
    _removeOverlayImmediate();
    _controller.dispose();
    super.dispose();
  }

  void _removeOverlayImmediate() {
    _overlayEntry?.remove();
    _overlayEntry = null;
    _isOpen = false;
  }

  void _toggleMenu() {
    if (_isOpen) {
      _closeMenu();
    } else {
      _openMenu();
    }
  }

  void _closeMenu() {
    if (!_isOpen || !mounted) return;
    setState(() => _isOpen = false);
    _controller.reverse().then((_) {
      _removeOverlayImmediate();
    });
  }

  void _openMenu() {
    if (_isOpen || !mounted) return;
    IrisHaptics.selectionClick();

    final RenderBox? box =
        _triggerKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null) return;

    final target = box.localToGlobal(Offset.zero);
    final size = box.size;
    final screen = MediaQuery.sizeOf(context);
    final viewPadding = MediaQuery.viewPaddingOf(context);

    final double computedWidth =
        widget.menuWidth.clamp(180.0, screen.width - 24.0);
    final double estimatedHeight = widget.menuHeight ??
        (widget.items.length * 48.0 + widget.menuPadding.vertical)
            .clamp(60.0, 360.0);

    final bool spaceBelow =
        (screen.height - viewPadding.bottom) - (target.dy + size.height + 6) >=
                estimatedHeight ||
            (target.dy < screen.height * 0.45);

    final double top = spaceBelow
        ? (target.dy + size.height + 6)
        : (target.dy - estimatedHeight - 6).clamp(
            viewPadding.top + 8,
            screen.height - estimatedHeight - viewPadding.bottom,
          );

    double left = target.dx;
    if (left + computedWidth > screen.width - 12) {
      left = screen.width - computedWidth - 12;
    }
    if (left < 12) left = 12;

    setState(() => _isOpen = true);

    _overlayEntry = OverlayEntry(
      builder: (ctx) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final cs = Theme.of(context).colorScheme;
        final style = ThemeSignals.themeStyle.value;

        Color menuBg = cs.surfaceContainerHigh;
        BorderRadius menuRadius = BorderRadius.circular(widget.menuBorderRadius);
        BoxBorder menuBorder = Border.all(
          color: cs.outlineVariant.withValues(alpha: isDark ? 0.45 : 0.65),
          width: 1.0,
        );
        List<BoxShadow>? menuShadow = [
          BoxShadow(
            color: cs.shadow.withValues(alpha: isDark ? 0.45 : 0.12),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
        ];

        if (style == IrisThemeStyle.notebook) {
          menuBg = NotebookTokens.cardSurface(isDark);
          menuRadius = BorderRadius.circular(12);
          menuBorder = Border.all(
            color: NotebookTokens.inkMuted(isDark).withValues(alpha: 0.35),
            width: 1.2,
          );
          menuShadow = [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ];
        } else if (style == IrisThemeStyle.line) {
          menuBg = LineTokens.cardSurface(isDark);
          menuRadius = BorderRadius.circular(6);
          menuBorder = Border.all(
            color: LineTokens.railLine(isDark),
            width: 1.5,
          );
          menuShadow = [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.50 : 0.10),
              blurRadius: 0,
              offset: const Offset(0, 4),
            ),
          ];
        } else if (style == IrisThemeStyle.poster) {
          menuBg = PosterTokens.cardSurface(isDark);
          menuRadius = BorderRadius.zero;
          menuBorder = Border.all(
            color: PosterTokens.inkBorder(isDark),
            width: 2.5,
          );
          menuShadow = [
            BoxShadow(
              color: PosterTokens.inkBorder(isDark),
              offset: const Offset(4, 4),
              blurRadius: 0,
            ),
          ];
        } else if (style == IrisThemeStyle.almanac) {
          menuBg = AlmanacTokens.cardSurface(isDark);
          menuRadius = BorderRadius.circular(4);
          menuBorder = Border.all(
            color: AlmanacTokens.inkRule(isDark),
            width: 1.2,
          );
          menuShadow = [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.30 : 0.06),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ];
        } else if (style == IrisThemeStyle.editorialAcademic) {
          menuBg = EditorialTokens.cardSurface(isDark);
          menuRadius = BorderRadius.circular(16);
          menuBorder = Border.all(
            color: EditorialTokens.cardBorder(isDark),
            width: 1.2,
          );
          menuShadow = [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ];
        }

        return Stack(
          children: [
            Positioned.fill(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: _closeMenu,
                child: const SizedBox.expand(),
              ),
            ),
            Positioned(
              left: left,
              top: top,
              child: RepaintBoundary(
                child: Material(
                  type: MaterialType.transparency,
                child: AnimatedBuilder(
                  animation: _controller,
                  builder: (context, child) {
                    return Transform.scale(
                      scale: _scaleAnimation.value,
                      alignment: spaceBelow
                          ? Alignment.topCenter
                          : Alignment.bottomCenter,
                      child: Opacity(
                        opacity: _fadeAnimation.value,
                        child: child,
                      ),
                    );
                  },
                  child: Container(
                    width: computedWidth,
                    constraints: BoxConstraints(
                      maxHeight: widget.menuHeight ?? 360.0,
                    ),
                    decoration: BoxDecoration(
                      color: menuBg,
                      borderRadius: menuRadius,
                      border: menuBorder,
                      boxShadow: menuShadow,
                    ),
                    child: ClipRRect(
                      borderRadius: menuRadius,
                      child: SingleChildScrollView(
                        padding: widget.menuPadding,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: widget.items
                              .map(
                                (e) => _buildMenuItem(
                                  context,
                                  e,
                                  cs,
                                  isDark,
                                  style,
                                ),
                              )
                              .toList(),
                        ),
                      ),
                    ),
                  ),
                ),
                ),
              ),
            ),
          ],
        );
      },
    );

    Overlay.of(context, rootOverlay: true).insert(_overlayEntry!);
    _controller.forward(from: 0.0);
  }

  Widget _buildMenuItem(
    BuildContext context,
    Widget e,
    ColorScheme cs,
    bool isDark,
    IrisThemeStyle style,
  ) {
    if (e is lgw.GlassMenuItem) {
      final isSelected = e.isSelected;
      Color itemBg = isSelected ? cs.secondaryContainer : Colors.transparent;
      Color itemTextColor = isSelected ? cs.onSecondaryContainer : (e.isDestructive ? cs.error : cs.onSurface);
      BorderRadius itemRadius = BorderRadius.circular(widget.itemBorderRadius);

      if (style == IrisThemeStyle.notebook) {
        itemBg = isSelected ? NotebookTokens.stickyNote(isDark) : Colors.transparent;
        itemTextColor = isSelected ? const Color(0xFF1A1F1C) : NotebookTokens.inkBody(isDark);
        itemRadius = BorderRadius.circular(8);
      } else if (style == IrisThemeStyle.line) {
        itemBg = isSelected ? LineTokens.subwayYellow : Colors.transparent;
        itemTextColor = isSelected ? Colors.black : LineTokens.inkHeading(isDark);
        itemRadius = BorderRadius.circular(4);
      } else if (style == IrisThemeStyle.poster) {
        itemBg = isSelected ? PosterTokens.orangeHero : Colors.transparent;
        itemTextColor = isSelected ? Colors.black : PosterTokens.inkHeading(isDark);
        itemRadius = BorderRadius.zero;
      } else if (style == IrisThemeStyle.almanac) {
        itemBg = isSelected ? AlmanacTokens.accentTerracotta(isDark) : Colors.transparent;
        itemTextColor = isSelected ? Colors.white : AlmanacTokens.inkHeading(isDark);
        itemRadius = BorderRadius.circular(2);
      } else if (style == IrisThemeStyle.editorialAcademic) {
        itemBg = isSelected ? EditorialTokens.accentUpcoming : Colors.transparent;
        itemTextColor = isSelected ? Colors.white : EditorialTokens.inkHeading(isDark);
        itemRadius = BorderRadius.circular(10);
      }

      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 2.0),
        child: Material(
          color: itemBg,
          borderRadius: itemRadius,
          child: InkWell(
            borderRadius: itemRadius,
            onTap: e.enabled
                ? () {
                    IrisHaptics.selectionClick();
                    _closeMenu();
                    e.onTap();
                  }
                : null,
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 11,
              ),
              child: Row(
                children: [
                  if (e.icon != null) ...[
                    IconTheme(
                      data: IconThemeData(
                        size: 18,
                        color: isSelected
                            ? itemTextColor
                            : (e.isDestructive
                                ? cs.error
                                : cs.onSurfaceVariant),
                      ),
                      child: e.icon!,
                    ),
                    const SizedBox(width: 12),
                  ],
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          e.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: isSelected
                                ? FontWeight.w800
                                : FontWeight.w600,
                            color: itemTextColor,
                          ),
                        ),
                        if (e.subtitle != null &&
                            e.subtitle!.isNotEmpty) ...[
                          const SizedBox(height: 2),
                          Text(
                            e.subtitle!,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w500,
                              color: isSelected
                                  ? cs.onSecondaryContainer.withValues(
                                      alpha: 0.8,
                                    )
                                  : cs.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  if (e.trailing != null) ...[
                    const SizedBox(width: 8),
                    e.trailing!,
                  ] else if (isSelected) ...[
                    const SizedBox(width: 8),
                    Icon(
                      Icons.check_circle_rounded,
                      size: 18,
                      color: cs.primary,
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      );
    }

    return e;
  }

  @override
  Widget build(BuildContext context) {
    return KeyedSubtree(
      key: _triggerKey,
      child: widget.triggerBuilder != null
          ? widget.triggerBuilder!(context, _toggleMenu)
          : GestureDetector(
              onTap: _toggleMenu,
              child: widget.child!,
            ),
    );
  }
}

/// Authentic Material 3 Expressive Dropdown Trigger Field.
/// Features:
/// - Tactile spring press scale compression
/// - Animated rotating chevron indicator (0° -> 180°)
/// - Theme-reactive Monet background & outline in Material You mode
/// - Frosted glass border styling in Liquid Glass mode
class IrisExpressiveDropdownTrigger extends StatefulWidget {
  final String displayText;
  final bool hasValue;
  final bool isDark;
  final VoidCallback onTap;
  final IconData? icon;
  final bool? isOpen;
  final double? borderRadius;

  const IrisExpressiveDropdownTrigger({
    super.key,
    required this.displayText,
    required this.hasValue,
    required this.isDark,
    required this.onTap,
    this.icon,
    this.isOpen,
    this.borderRadius,
  });

  @override
  State<IrisExpressiveDropdownTrigger> createState() =>
      _IrisExpressiveDropdownTriggerState();
}

class _IrisExpressiveDropdownTriggerState
    extends State<IrisExpressiveDropdownTrigger> {
  bool _internalOpen = false;
  bool get _effectiveOpen => widget.isOpen ?? _internalOpen;

  void _handleTap() {
    if (widget.isOpen == null) {
      setState(() => _internalOpen = !_internalOpen);
    }
    widget.onTap();
  }

  @override
  Widget build(BuildContext context) {
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;
    final double effectiveRadius = widget.borderRadius ?? (isM3 ? 18.0 : 24.0);

    return ValueListenableBuilder<double>(
      valueListenable: ThemeSignals.glassTransparency,
      builder: (context, transparency, _) {
        final isOpaque = transparency <= 0.08;

        final decoration = isM3
            ? BoxDecoration(
                color: widget.hasValue
                    ? cs.primaryContainer.withValues(
                        alpha: widget.isDark ? 0.35 : 0.25,
                      )
                    : cs.surfaceContainerHigh,
                borderRadius: BorderRadius.circular(effectiveRadius),
                border: Border.all(
                  color: widget.hasValue
                      ? cs.primary
                      : cs.outlineVariant.withValues(
                          alpha: widget.isDark ? 0.5 : 0.7,
                        ),
                  width: widget.hasValue ? 1.5 : 1.0,
                ),
              )
            : BoxDecoration(
                color: isOpaque
                    ? (widget.hasValue
                        ? (widget.isDark
                            ? const Color(0xFF1E2433)
                            : const Color(0xFFF1F5F9))
                        : (widget.isDark
                            ? const Color(0xFF161B26)
                            : Colors.white))
                    : (widget.hasValue
                        ? (widget.isDark
                            ? IrisTokens.brand.withValues(alpha: lerpDouble(0.35, 0.12, transparency)!)
                            : Colors.white.withValues(alpha: lerpDouble(0.95, 0.65, transparency)!))
                        : (widget.isDark
                            ? Colors.white.withValues(alpha: lerpDouble(0.18, 0.05, transparency)!)
                            : Colors.white.withValues(alpha: lerpDouble(0.92, 0.55, transparency)!))),
                borderRadius: BorderRadius.circular(effectiveRadius),
                border: Border.all(
                  color: isOpaque
                      ? (widget.hasValue
                          ? IrisTokens.brand
                          : (widget.isDark ? const Color(0xFF2E384D) : const Color(0xFFCBD5E1)))
                      : (widget.hasValue
                          ? (widget.isDark
                              ? IrisTokens.brand.withValues(alpha: 0.45)
                              : IrisTokens.brand.withValues(alpha: 0.35))
                          : (widget.isDark
                              ? Colors.white.withValues(alpha: 0.14)
                              : Colors.black.withValues(alpha: 0.08))),
                  width: widget.hasValue ? 1.4 : 1.0,
                ),
                boxShadow: [
                  if (!widget.isDark && !isOpaque)
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.04),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                ],
              );

        final textColor = widget.hasValue
            ? (isM3
                ? cs.onSurface
                : (widget.isDark ? Colors.white : Colors.black87))
            : (isM3
                ? cs.onSurfaceVariant.withValues(alpha: 0.7)
                : (widget.isDark ? Colors.white38 : Colors.black38));

        final chevronColor = widget.hasValue
            ? (isM3 ? cs.primary : IrisTokens.brand)
            : (isM3
                ? cs.onSurfaceVariant
                : (widget.isDark ? Colors.white54 : Colors.black45));

        return RepaintBoundary(
          child: ExpressiveInteractivePress(
            onTap: _handleTap,
            pressedScale: 0.97,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: decoration,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (widget.icon != null) ...[
                    Icon(widget.icon, size: 18, color: chevronColor),
                    const SizedBox(width: 10),
                  ],
                  Expanded(
                    child: Text(
                      widget.displayText,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 14.5,
                        fontWeight: FontWeight.w700,
                        color: textColor,
                      ),
                    ),
                  ),
                  AnimatedRotation(
                    turns: _effectiveOpen ? 0.5 : 0.0,
                    duration: const Duration(milliseconds: 260),
                    curve: Curves.easeOutBack,
                    child: Icon(
                      Icons.keyboard_arrow_down_rounded,
                      color: chevronColor,
                      size: 22,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Authentic Material 3 Expressive Squircle Icon Badge.
/// Renders a squircle shape with tonal fill, subtle outline, and optional tactile spring press.
class M3EIconBadge extends StatelessWidget {
  final IconData icon;
  final double size;
  final double iconSize;
  final double radius;
  final Color? color;
  final Color? backgroundColor;
  final Color? borderColor;
  final VoidCallback? onTap;
  final String? tooltip;
  final String? badgeText;

  const M3EIconBadge({
    super.key,
    required this.icon,
    this.size = 40.0,
    this.iconSize = 20.0,
    this.radius = 12.0,
    this.color,
    this.backgroundColor,
    this.borderColor,
    this.onTap,
    this.tooltip,
    this.badgeText,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final effectiveColor = color ?? cs.primary;
    final effectiveBg = backgroundColor ?? cs.secondaryContainer.withValues(alpha: 0.65);
    final effectiveBorder = borderColor ?? cs.outlineVariant.withValues(alpha: 0.5);

    Widget badge = Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          width: size,
          height: size,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: effectiveBg,
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: effectiveBorder, width: 1.0),
          ),
          child: Icon(
            icon,
            size: iconSize,
            color: effectiveColor,
          ),
        ),
        if (badgeText != null && badgeText!.isNotEmpty)
          Positioned(
            top: -4,
            right: -4,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
              decoration: BoxDecoration(
                color: cs.error,
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                badgeText!,
                style: TextStyle(
                  color: cs.onError,
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  height: 1.0,
                ),
              ),
            ),
          ),
      ],
    );

    if (tooltip != null) {
      badge = Tooltip(message: tooltip!, child: badge);
    }

    if (onTap != null) {
      return RepaintBoundary(
        child: ExpressiveSpringPress(
          onTap: onTap,
          child: badge,
        ),
      );
    }

    return RepaintBoundary(child: badge);
  }
}

/// Authentic Material 3 Expressive Filter Chip.
/// Features tonal container, spring press physics, icon, and dynamic selection state.
class M3EFilterChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  final IconData? icon;
  final IconData? selectedIcon;
  final Color? selectedColor;
  final Color? selectedTextColor;

  const M3EFilterChip({
    super.key,
    required this.label,
    required this.isSelected,
    required this.onTap,
    this.icon,
    this.selectedIcon = Icons.check_rounded,
    this.selectedColor,
    this.selectedTextColor,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final bg = isSelected
        ? (selectedColor ?? cs.secondaryContainer)
        : (isDark ? const Color(0xFF272A2F) : const Color(0xFFE6E8EE));
    final fg = isSelected
        ? (selectedTextColor ?? cs.onSecondaryContainer)
        : cs.onSurfaceVariant;
    final border = isSelected
        ? Colors.transparent
        : cs.outlineVariant.withValues(alpha: isDark ? 0.4 : 0.6);

    return RepaintBoundary(
      child: ExpressiveSpringPress(
        onTap: () {
        IrisHaptics.chipSelect();
        onTap();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: border, width: 1.0),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (isSelected && selectedIcon != null) ...[
              Icon(selectedIcon, size: 16, color: fg),
              const SizedBox(width: 6),
            ] else if (icon != null) ...[
              Icon(icon, size: 16, color: fg),
              const SizedBox(width: 6),
            ],
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                color: fg,
                letterSpacing: 0.1,
              ),
            ),
          ],
        ),
      ),
    ),);
  }
}

