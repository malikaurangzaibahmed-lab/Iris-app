import '../../core/theme_signals.dart';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/sticker_tokens.dart';

/// Tactile stationery items for the Material 3 Expressive scrapbook aesthetic:
/// - [PhysicalPaperclip]: Metallic paperclip that clasps over card/washi-tape rims
/// - [TactileThumbtack]: Brass/colored pushpin anchoring cards to the page
/// - [Floating3DOverhang]: Floating element with subtle harmonic z-float breathing
class PhysicalPaperclip extends StatelessWidget {
  final double width;
  final double height;
  final double angle;
  final bool isBrass;
  final bool isDark;

  const PhysicalPaperclip({
    super.key,
    this.width = 16.0,
    this.height = 38.0,
    this.angle = 0.08,
    this.isBrass = true,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    Widget clip = SizedBox(
      width: width,
      height: height,
      child: CustomPaint(
        painter: _PaperclipPainter(isBrass: isBrass, isDark: isDark),
      ),
    );

    if (angle != 0.0) {
      clip = Transform.rotate(
        angle: angle,
        child: clip,
      );
    }

    return clip;
  }
}

class _PaperclipPainter extends CustomPainter {
  final bool isBrass;
  final bool isDark;

  _PaperclipPainter({required this.isBrass, required this.isDark});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // Metallic gradients: Warm brass/gold or cool steel/chrome
    final wireColorStart = isBrass
        ? (isDark ? const Color(0xFFFDE68A) : const Color(0xFFFBBF24))
        : (isDark ? const Color(0xFFE2E8F0) : const Color(0xFF94A3B8));
    final wireColorEnd = isBrass
        ? (isDark ? const Color(0xFFB45309) : const Color(0xFFD97706))
        : (isDark ? const Color(0xFF64748B) : const Color(0xFF475569));

    final shadowPaint = Paint()
      ..color = isDark ? const Color(0x66000000) : const Color(0x3B2C221A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final wirePaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [wireColorStart, wireColorEnd, wireColorStart],
      ).createShader(Rect.fromLTWH(0, 0, w, h))
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final highlightPaint = Paint()
      ..color = Colors.white.withValues(alpha: isDark ? 0.45 : 0.70)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8
      ..strokeCap = StrokeCap.round;

    // Draw realistic paperclip wire path
    // Outer loop -> bottom curve -> inner loop -> center
    Path buildClipPath(double offsetX, double offsetY) {
      final p = Path();
      final l = w * 0.18 + offsetX;
      final r = w * 0.82 + offsetX;
      final midL = w * 0.38 + offsetX;
      final midR = w * 0.62 + offsetX;
      final t = h * 0.12 + offsetY;
      final b = h * 0.88 + offsetY;

      // Start inner end
      p.moveTo(midL, h * 0.60 + offsetY);
      p.lineTo(midL, t + (w * 0.24));
      // Top inner loop
      p.arcToPoint(
        Offset(midR, t + (w * 0.24)),
        radius: Radius.circular((midR - midL) / 2),
        clockwise: true,
      );
      // Down inner leg
      p.lineTo(midR, b - (w * 0.32));
      // Bottom outer loop
      p.arcToPoint(
        Offset(l, b - (w * 0.32)),
        radius: Radius.circular((midR - l) / 2),
        clockwise: true,
      );
      // Up outer leg
      p.lineTo(l, t + (w * 0.32));
      // Top outer loop
      p.arcToPoint(
        Offset(r, t + (w * 0.32)),
        radius: Radius.circular((r - l) / 2),
        clockwise: true,
      );
      // Down right leg
      p.lineTo(r, b - (w * 0.22));
      return p;
    }

    // 1. Cast shadow onto card/desk
    final shadowPath = buildClipPath(1.5, 2.0);
    canvas.drawPath(shadowPath, shadowPaint);

    // 2. Main paperclip body
    final mainPath = buildClipPath(0, 0);
    canvas.drawPath(mainPath, wirePaint);

    // 3. Specular highlight line
    final highlightPath = buildClipPath(-0.4, -0.4);
    canvas.drawPath(highlightPath, highlightPaint);
  }

  @override
  bool shouldRepaint(covariant _PaperclipPainter oldDelegate) =>
      oldDelegate.isBrass != isBrass || oldDelegate.isDark != isDark;
}

/// Tactile brass or colored pushpin holding scrapbook items in 3D
class TactileThumbtack extends StatelessWidget {
  final double size;
  final Color? color;
  final bool isDark;

  const TactileThumbtack({
    super.key,
    this.size = 18.0,
    this.color,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _ThumbtackPainter(
          pinColor: color ?? (isDark ? const Color(0xFFEF4444) : const Color(0xFFDC2626)),
          isDark: isDark,
        ),
      ),
    );
  }
}

class _ThumbtackPainter extends CustomPainter {
  final Color pinColor;
  final bool isDark;

  _ThumbtackPainter({required this.pinColor, required this.isDark});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final center = Offset(w * 0.5, h * 0.5);

    // Drop shadow
    final shadowPaint = Paint()
      ..color = isDark ? const Color(0x88000000) : const Color(0x402C221A)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.0);
    canvas.drawCircle(Offset(center.dx + 1.2, center.dy + 1.8), w * 0.38, shadowPaint);

    // Pin outer rim
    final rimPaint = Paint()
      ..color = pinColor.withValues(alpha: 0.85)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(center, w * 0.40, rimPaint);

    // Ink outline
    final strokePaint = Paint()
      ..color = StickerTokens.inkOutline(isDark)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3;
    canvas.drawCircle(center, w * 0.40, strokePaint);

    // Pin 3D dome (gradient highlight)
    final domePaint = Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.35, -0.35),
        radius: 0.65,
        colors: [Colors.white.withValues(alpha: 0.9), pinColor],
      ).createShader(Rect.fromCircle(center: center, radius: w * 0.30));
    canvas.drawCircle(center, w * 0.28, domePaint);
  }

  @override
  bool shouldRepaint(covariant _ThumbtackPainter oldDelegate) =>
      oldDelegate.pinColor != pinColor || oldDelegate.isDark != isDark;
}

/// Floating 3D Overhang Wrapper:
/// Breaks child elements out of card constraints with a gentle harmonic
/// vertical bobbing animation (sine float) and higher virtual z-elevation.
class Floating3DOverhang extends StatefulWidget {
  final Widget child;
  final double floatDistance;
  final Duration duration;
  final bool enableFloat;

  const Floating3DOverhang({
    super.key,
    required this.child,
    this.floatDistance = 2.4,
    this.duration = const Duration(milliseconds: 2400),
    this.enableFloat = true,
  });

  @override
  State<Floating3DOverhang> createState() => _Floating3DOverhangState();
}

class _Floating3DOverhangState extends State<Floating3DOverhang>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: widget.duration,
    );
    if (widget.enableFloat && !ThemeSignals.useMinimalTheme.value) {
      _controller.repeat(reverse: true);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.enableFloat) return widget.child;

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        // Smooth sine wave float
        final t = math.sin(_controller.value * math.pi);
        final dy = -widget.floatDistance * t;
        return Transform.translate(
          offset: Offset(0, dy),
          child: child,
        );
      },
      child: widget.child,
    );
  }
}
