import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/sticker_tokens.dart';
import '../../services/ui_feedback.dart';
import '../../core/animations.dart';

/// Torn washi-tape style filter tab / chip for Material 3 Expressive mode.
class WashiTapeChip extends StatelessWidget {
  final String label;
  final String? emoji;
  final bool isSelected;
  final VoidCallback onTap;
  final Color? activeColor;
  final Color? inactiveColor;
  final double rotationAngle;
  final Widget? trailingBadge;

  const WashiTapeChip({
    super.key,
    required this.label,
    this.emoji,
    required this.isSelected,
    required this.onTap,
    this.activeColor,
    this.inactiveColor,
    this.rotationAngle = 0.0,
    this.trailingBadge,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final outlineColor = StickerTokens.inkOutline(isDark);

    final effectiveActiveColor = activeColor ??
        (isDark ? const Color(0xFFD95B38) : const Color(0xFFFF7A59));
    final effectiveInactiveColor = inactiveColor ??
        (isDark ? const Color(0xFF262E3B) : const Color(0xFFF7F2E7));

    final bgColor = isSelected ? effectiveActiveColor : effectiveInactiveColor;

    return Transform.rotate(
      angle: rotationAngle * (math.pi / 180.0),
      child: ExpressiveInteractivePress(
        onTap: () {
          IrisHaptics.chipSelect();
          onTap();
        },
        pressedScale: 0.94,
        child: CustomPaint(
          painter: _TornWashiTapePainter(
            backgroundColor: bgColor,
            outlineColor: outlineColor,
            outlineWidth: isSelected ? 1.8 : 1.35,
            shadowColor: isDark ? Colors.black54 : const Color(0x3B2C221A),
            shadowOffset: isSelected ? 2.8 : 1.8,
            isDark: isDark,
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7.0),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (emoji != null && emoji!.isNotEmpty) ...[
                  Text(
                    emoji!,
                    style: const TextStyle(fontSize: 12.5),
                  ),
                  const SizedBox(width: 5),
                ],
                Flexible(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.poppins(
                      fontSize: 11.5,
                      fontWeight: isSelected ? FontWeight.w900 : FontWeight.w700,
                      letterSpacing: -0.2,
                      color: isSelected
                          ? (isDark ? Colors.white : const Color(0xFF1E1712))
                          : (isDark ? const Color(0xFFE2E8F0) : const Color(0xFF3B2F25)),
                    ),
                  ),
                ),
                if (trailingBadge != null) ...[
                  const SizedBox(width: 6),
                  trailingBadge!,
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TornWashiTapePainter extends CustomPainter {
  final Color backgroundColor;
  final Color outlineColor;
  final double outlineWidth;
  final Color shadowColor;
  final double shadowOffset;
  final bool isDark;

  const _TornWashiTapePainter({
    required this.backgroundColor,
    required this.outlineColor,
    required this.outlineWidth,
    required this.shadowColor,
    required this.shadowOffset,
    required this.isDark,
  });

  Path _createTornPath(Size size) {
    final w = size.width;
    final h = size.height;
    final path = Path();

    // 1. Top edge: subtle organic tape adhesion line
    path.moveTo(0, 0);
    path.lineTo(w, 0);

    // 2. Right edge: serrated hand-torn masking tape teeth (organic depths with micro-jags)
    const teeth = 6;
    final dy = h / teeth;
    const rightOffsets = [-3.0, 1.6, -2.4, 2.2, -1.8, 2.6];
    for (int i = 0; i < teeth; i++) {
      final yMid = (i + 0.5) * dy;
      final yEnd = (i + 1) * dy;
      final toothDepth = rightOffsets[i % rightOffsets.length];
      path.lineTo(w + toothDepth, yMid);
      path.lineTo(w, yEnd);
    }

    // 3. Bottom edge
    path.lineTo(0, h);

    // 4. Left edge: serrated hand-torn masking tape teeth (going upwards)
    const leftOffsets = [2.6, -1.8, 2.8, -1.4, 2.4, -2.2];
    for (int i = teeth - 1; i >= 0; i--) {
      final yMid = (i + 0.5) * dy;
      final yStart = i * dy;
      final toothDepth = leftOffsets[i % leftOffsets.length];
      path.lineTo(toothDepth, yMid);
      path.lineTo(0, yStart);
    }

    path.close();
    return path;
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;
    final path = _createTornPath(size);

    // 1. Physical Tape Lift Shadows:
    // Tape ends lift slightly off the paper (~0.5mm), creating a wider ambient shadow
    final ambientShadowPaint = Paint()
      ..color = shadowColor.withValues(alpha: isDark ? 0.32 : 0.16)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3.0);
    canvas.drawPath(path.shift(Offset(1.0, shadowOffset + 1.0)), ambientShadowPaint);

    // 2. Crisp cardboard contact cast shadow
    final castShadowPaint = Paint()
      ..color = shadowColor
      ..style = PaintingStyle.fill;
    canvas.drawPath(path.shift(Offset(1.4, shadowOffset)), castShadowPaint);

    // 3. Semi-translucent fibrous paper tape fill (authentic washi paper transparency)
    final fillPaint = Paint()
      ..color = backgroundColor.withValues(alpha: 0.93)
      ..style = PaintingStyle.fill;
    canvas.drawPath(path, fillPaint);

    // 4. Internal tactile rice paper grain & longitudinal fibers
    canvas.save();
    canvas.clipPath(path);

    // Diagonal paper fibers
    final fiberPaint = Paint()
      ..color = (isDark ? Colors.white : Colors.black).withValues(alpha: 0.04)
      ..strokeWidth = 0.75
      ..style = PaintingStyle.stroke;
    for (double x = -size.height; x < size.width + size.height; x += 12.0) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x + size.height * 0.65, size.height),
        fiberPaint,
      );
    }

    // Longitudinal rice-paper core lines
    final longitudinalPaint = Paint()
      ..color = (isDark ? Colors.white : Colors.black).withValues(alpha: 0.025)
      ..strokeWidth = 0.6
      ..style = PaintingStyle.stroke;
    canvas.drawLine(Offset(0, size.height * 0.35), Offset(size.width, size.height * 0.35), longitudinalPaint);
    canvas.drawLine(Offset(0, size.height * 0.70), Offset(size.width, size.height * 0.70), longitudinalPaint);

    // 5. Specular tape sheen highlight along top edge (ambient overhead reflection)
    final sheenPaint = Paint()
      ..color = Colors.white.withValues(alpha: isDark ? 0.20 : 0.40)
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke;
    canvas.drawLine(
      const Offset(2.0, 1.2),
      Offset(size.width - 2.0, 1.2),
      sheenPaint,
    );

    // 6. Frayed paper pulp fringe along the torn serrated ends (white exposed inner fibers)
    final pulpPaint = Paint()
      ..color = Colors.white.withValues(alpha: isDark ? 0.15 : 0.35)
      ..strokeWidth = 0.8
      ..style = PaintingStyle.stroke;
    canvas.drawPath(path, pulpPaint);

    canvas.restore();

    // 7. Crisp ink outline around serrated perimeter
    final strokePaint = Paint()
      ..color = outlineColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = outlineWidth
      ..strokeJoin = StrokeJoin.miter
      ..isAntiAlias = true;
    canvas.drawPath(path, strokePaint);
  }

  @override
  bool shouldRepaint(covariant _TornWashiTapePainter old) {
    return backgroundColor != old.backgroundColor ||
        outlineColor != old.outlineColor ||
        outlineWidth != old.outlineWidth ||
        shadowColor != old.shadowColor ||
        shadowOffset != old.shadowOffset ||
        isDark != old.isDark;
  }
}
