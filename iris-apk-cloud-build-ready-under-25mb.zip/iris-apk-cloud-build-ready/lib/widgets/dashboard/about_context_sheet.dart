import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import '../../core/tokens.dart';
import '../../core/glass.dart';
import '../../core/theme_signals.dart';
import '../iris_components.dart';
import '../../services/ui_feedback.dart';

/// Modal bottom sheet presenting quick settings, theme style toggle, and local cache controls.
class AboutContextSheet extends StatelessWidget {
  final bool isDark;

  const AboutContextSheet({
    required this.isDark,
    super.key,
  });

  static void show(BuildContext context, bool isDark) {
    IrisModalSheet.show(
      context: context,
      initialState: lgw.GlassSheetState.half,
      settings: IrisGlass.widgetsSettings(
        context,
        blur: 16.0,
        thickness: 15.0,
        ambientStrength: isDark ? 0.65 : 0.72,
        lightAngle: 1.5,
        glassColor: isDark
            ? Colors.black.withValues(alpha: 0.20)
            : Colors.white.withValues(alpha: 0.15),
      ),
      builder: (sheetContext) => AboutContextSheet(isDark: isDark),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: Container(
              width: 40,
              height: 5,
              decoration: BoxDecoration(
                color: isDark ? Colors.white30 : Colors.black12,
                borderRadius: BorderRadius.circular(99),
              ),
            ),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Icon(
                Icons.settings_rounded,
                color: isDark ? Colors.white : IrisTokens.purple,
                size: 26,
              ),
              const SizedBox(width: 10),
              Text(
                'Quick Settings Tuner',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  color: isDark ? Colors.white : Colors.black87,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          ValueListenableBuilder<IrisThemeStyle>(
            valueListenable: ThemeSignals.themeStyle,
            builder: (sheetCtx, style, child) {
              final isM3 = style == IrisThemeStyle.materialYou;
              return ContextActionTile(
                isDark: isDark,
                title: isM3 ? 'Design: Material You' : 'Design: Liquid Glass',
                subtitle: isM3
                    ? 'Google Pixel M3 (Active) · Tap for Liquid Glass'
                    : 'Liquid Glass (Active) · Tap for Google Pixel M3',
                icon: isM3
                    ? Icons.auto_awesome_rounded
                    : Icons.blur_on_rounded,
                color: isM3 ? const Color(0xFF8B5CF6) : IrisTokens.brand,
                onTap: () async {
                  Rect? originRect;
                  try {
                    final box = sheetCtx.findRenderObject() as RenderBox?;
                    if (box != null && box.hasSize) {
                      originRect = box.localToGlobal(Offset.zero) & box.size;
                    }
                  } catch (_) {}
                  Navigator.pop(context);
                  await ThemeSignals.toggleThemeStyle(
                    context: context,
                    originRect: originRect,
                  );
                  if (!context.mounted) return;
                  showIrisFrostedSnackBar(
                    context,
                    content: Text(
                      ThemeSignals.isMaterialYou
                          ? 'Google Pixel Material 3 activated'
                          : 'Liquid Glass activated',
                    ),
                    tint: ThemeSignals.isMaterialYou
                        ? const Color(0xFF8B5CF6)
                        : IrisTokens.brand,
                  );
                },
              );
            },
          ),
          const SizedBox(height: 12),
          ContextActionTile(
            isDark: isDark,
            title: 'Reset Offline Local Storage',
            subtitle: 'Clear local timetable caches & load seed',
            icon: Icons.restore_rounded,
            color: IrisTokens.warning,
            onTap: () async {
              Navigator.pop(context);
              final prefs = await SharedPreferences.getInstance();
              await prefs.remove('helpdesk_has_doc_draft');
              if (!context.mounted) return;
              showIrisFrostedSnackBar(
                context,
                content: const Text('Caches cleared successfully!'),
              );
            },
          ),
        ],
      ),
    );
  }
}

/// An interactive glass action tile for quick sheet actions.
class ContextActionTile extends StatelessWidget {
  final bool isDark;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const ContextActionTile({
    required this.isDark,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.onTap,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isDark
              ? Colors.white.withValues(alpha: 0.04)
              : Colors.black.withValues(alpha: 0.02),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: (isDark ? Colors.white : Colors.black).withValues(
              alpha: 0.05,
            ),
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: isDark ? Colors.white : Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: isDark ? Colors.white54 : Colors.black54,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.chevron_right_rounded,
              color: isDark ? Colors.white30 : Colors.black38,
            ),
          ],
        ),
      ),
    );
  }
}
