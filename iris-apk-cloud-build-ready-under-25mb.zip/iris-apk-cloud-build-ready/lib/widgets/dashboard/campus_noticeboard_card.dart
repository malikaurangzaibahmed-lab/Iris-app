import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../core/glass.dart';
import '../../core/theme_signals.dart';
import '../../services/remote_config_service.dart';
import '../../services/ui_feedback.dart';
import '../../services/helpdesk_campus_feed_service.dart';
import 'package:iris/screens/settings/announcements_screen.dart';
import '../glass_card.dart';
import '../iris_components.dart';
import 'package:iris/widgets/effects/glass_container_transform.dart';

/// Modal dialog showing full details of a campus notice.
class NoticeDetailsModal {
  static void show(
    BuildContext context,
    bool isDark, {
    required String title,
    required String detail,
    required String author,
    required String timeLabel,
  }) {
    IrisHaptics.selectionClick();
    IrisModalSheet.show(
      context: context,
      settings: IrisGlass.widgetsSettings(context, blur: 16.0, thickness: 15.0),
      builder: (sheetContext) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
              child: Container(
                width: 38,
                height: 4.5,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.20),
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
            ),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFF06B6D4).withValues(alpha: 0.16),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: const Text(
                    'OFFICIAL NOTICE',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF0284C7),
                    ),
                  ),
                ),
                const Spacer(),
                Text(
                  timeLabel,
                  style: TextStyle(
                    fontSize: 11,
                    color: isDark ? Colors.white54 : Colors.black54,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Text(
              title,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                color: isDark ? Colors.white : const Color(0xFF0F172A),
              ),
            ),
            if (author.isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(
                'Issued by: $author',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: isDark ? Colors.white60 : const Color(0xFF64748B),
                ),
              ),
            ],
            const SizedBox(height: 14),
            Text(
              detail.isNotEmpty ? detail : 'No further details provided.',
              style: TextStyle(
                fontSize: 13.5,
                height: 1.4,
                color: isDark ? Colors.white70 : const Color(0xFF334155),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

/// Floating campus broadcast banner with dismiss support.
class CampusAnnouncementBanner extends StatelessWidget {
  final Map<String, dynamic> announcement;
  final bool isDark;
  final String? dismissedAnnouncementText;
  final ValueChanged<String> onDismiss;

  const CampusAnnouncementBanner({
    required this.announcement,
    required this.isDark,
    required this.dismissedAnnouncementText,
    required this.onDismiss,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final message = announcement['message']?.toString() ?? '';

    if (message.isEmpty || dismissedAnnouncementText == message) {
      return const SizedBox.shrink();
    }

    final rawTime = announcement['updated_at'];
    DateTime? dateTime;
    if (rawTime is Timestamp) {
      dateTime = rawTime.toDate();
    } else if (rawTime is DateTime) {
      dateTime = rawTime;
    } else if (rawTime is String) {
      dateTime = DateTime.tryParse(rawTime);
    }
    final formattedTime = RemoteConfigService.formatTimestamp(dateTime);

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      child: Container(
        key: ValueKey(message),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(
                        0xFFF59E0B,
                      ).withValues(alpha: isDark ? 0.25 : 0.15),
                      blurRadius: 18,
                      spreadRadius: 1,
                    ),
                  ],
                ),
              ),
            ),
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: GlassSurface(
                settings: IrisGlass.settings(
                  context,
                  blur: 20,
                  ambientStrength: 0.85,
                  lightAngle: 0.15 * math.pi,
                  thickness: 18,
                  glassColor: isDark
                      ? const Color(0xFFF59E0B).withValues(alpha: 0.09)
                      : Colors.white.withValues(alpha: 0.92),
                ),
                radius: 20,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: const Color(0xFFF59E0B).withValues(alpha: 0.45),
                      width: 1.5,
                    ),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(
                            0xFFF59E0B,
                          ).withValues(alpha: 0.15),
                        ),
                        child: Icon(
                          Icons.campaign_rounded,
                          size: 20,
                          color: isDark
                              ? Colors.white
                              : const Color(0xFFD97706),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Wrap(
                              alignment: WrapAlignment.spaceBetween,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              spacing: 8,
                              runSpacing: 4,
                              children: [
                                Text(
                                  'CAMPUS BROADCAST',
                                  style: TextStyle(
                                    fontSize: 9.5,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 1.2,
                                    color: isDark
                                        ? Colors.amber[200]
                                        : const Color(0xFFB45309),
                                  ),
                                ),
                                Text(
                                  formattedTime.toUpperCase(),
                                  style: TextStyle(
                                    fontSize: 8.5,
                                    fontWeight: FontWeight.w700,
                                    color: isDark
                                        ? Colors.amber[200]!.withValues(
                                            alpha: 0.6,
                                          )
                                        : const Color(
                                            0xFFB45309,
                                          ).withValues(alpha: 0.7),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text(
                              message,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                height: 1.4,
                                color: isDark ? Colors.white : Colors.black87,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: () => onDismiss(message),
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: (isDark ? Colors.white : Colors.black)
                                .withValues(alpha: 0.06),
                          ),
                          child: Icon(
                            Icons.close_rounded,
                            size: 16,
                            color: isDark ? Colors.white70 : Colors.black54,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Rich noticeboard card showcasing live announcements and admin notices.
class CampusNoticeboardCard extends StatelessWidget {
  final Map<String, dynamic>? announcement;
  final List<Map<String, dynamic>> adminNotices;
  final bool isDark;
  final String? dismissedAnnouncementText;

  const CampusNoticeboardCard({
    required this.announcement,
    required this.adminNotices,
    required this.isDark,
    required this.dismissedAnnouncementText,
    super.key,
  });

  static String formatNoticeTimeAgo(DateTime? date) {
    if (date == null) return 'Recent';
    final diff = DateTime.now().difference(date);
    if (diff.inDays > 30) return '${diff.inDays ~/ 30}mo ago';
    if (diff.inDays > 7) return '${diff.inDays ~/ 7}w ago';
    if (diff.inDays > 0) return '${diff.inDays}d ago';
    if (diff.inHours > 0) return '${diff.inHours}h ago';
    if (diff.inMinutes > 0) return '${diff.inMinutes}m ago';
    return 'Just now';
  }

  @override
  Widget build(BuildContext context) {
    final liveMsg = announcement?['message']?.toString() ?? '';
    final hasLiveMsg =
        liveMsg.trim().isNotEmpty && liveMsg != dismissedAnnouncementText;

    DateTime? liveTime;
    if (hasLiveMsg) {
      final rawTime = announcement!['updated_at'];
      if (rawTime is Timestamp) {
        liveTime = rawTime.toDate();
      } else if (rawTime is DateTime) {
        liveTime = rawTime;
      } else if (rawTime is String) {
        liveTime = DateTime.tryParse(rawTime);
      }
    }

    // Parse admin notices from Cloud Firestore
    final List<CampusNotice> parsedAdminNotices = [];
    for (final m in adminNotices) {
      DateTime? dt;
      final raw = m['created_at'] ?? m['createdAt'];
      if (raw is Timestamp) {
        dt = raw.toDate();
      } else if (raw is DateTime) {
        dt = raw;
      } else if (raw is int) {
        dt = DateTime.fromMillisecondsSinceEpoch(raw);
      } else if (raw is String) {
        dt = DateTime.tryParse(raw);
      }
      final title = (m['title'] ?? '').toString().trim();
      final detail = (m['detail'] ?? m['message'] ?? m['body'] ?? '')
          .toString()
          .trim();
      final isDummy =
          title.isEmpty ||
          title == '.' ||
          title.toLowerCase() == 'dummy' ||
          title.toLowerCase() == 'test' ||
          detail == '.' ||
          detail.toLowerCase() == 'dummy';
      if (!isDummy) {
        parsedAdminNotices.add(
          CampusNotice(
            id: (m['id'] ?? '').toString(),
            title: title,
            detail: detail,
            createdBy: (m['author'] ?? m['createdBy'] ?? 'Campus Admin')
                .toString(),
            createdAt: dt ?? DateTime.now(),
          ),
        );
      }
    }

    final List<CampusNotice> notices = parsedAdminNotices;

    final hasAnyContent = hasLiveMsg || notices.isNotEmpty;
    if (!hasAnyContent) {
      return const SizedBox.shrink();
    }

    return GlassCard(
      borderRadius: 24,
      accentColor: const Color(0xFF06B6D4),
      backgroundColor: isDark
          ? Colors.white.withValues(alpha: 0.08)
          : Colors.white.withValues(alpha: 0.70),
      border: Border.all(
        color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.08),
        width: 1.0,
      ),
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Campus Noticeboard',
                style: TextStyle(
                  fontSize: 16.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.3,
                  color: isDark ? Colors.white : const Color(0xFF0F172A),
                ),
              ),
              if (notices.isNotEmpty)
                GestureDetector(
                  onTap: () {
                    IrisHaptics.selectionClick();
                    pushGlassContainerMorphRoute(
                      context,
                      page: const AnnouncementsScreen(),
                      accentColor: const Color(0xFF06B6D4),
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFF06B6D4).withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      '${notices.length} NOTICES',
                      style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF06B6D4),
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 14),
          if (hasLiveMsg) ...[
            GestureDetector(
              onTap: () {
                NoticeDetailsModal.show(
                  context,
                  isDark,
                  title: 'System Broadcast',
                  detail: liveMsg,
                  author: 'Admin',
                  timeLabel: RemoteConfigService.formatTimestamp(liveTime),
                );
              },
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 3.5,
                    height: 38,
                    decoration: BoxDecoration(
                      color: const Color(0xFF06B6D4),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          liveMsg,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w700,
                            color: isDark
                                ? Colors.white
                                : const Color(0xFF1E293B),
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'Admin · ${RemoteConfigService.formatTimestamp(liveTime)}',
                          style: TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w500,
                            color: isDark
                                ? Colors.white60
                                : const Color(0xFF64748B),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            if (notices.isNotEmpty) const SizedBox(height: 12),
          ],
          for (
            int i = 0;
            i < notices.take(hasLiveMsg ? 2 : 3).length;
            i++
          ) ...[
            if (i > 0) const SizedBox(height: 12),
            GestureDetector(
              onTap: () {
                final notice = notices[i];
                NoticeDetailsModal.show(
                  context,
                  isDark,
                  title: notice.title,
                  detail: notice.detail,
                  author: notice.createdBy,
                  timeLabel: formatNoticeTimeAgo(notice.createdAt),
                );
              },
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 3.5,
                    height: 38,
                    decoration: BoxDecoration(
                      color: const Color(0xFF06B6D4),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          notices[i].title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w700,
                            color: isDark
                                ? Colors.white
                                : const Color(0xFF1E293B),
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${notices[i].createdBy.isNotEmpty ? notices[i].createdBy : "Admin"} · ${formatNoticeTimeAgo(notices[i].createdAt)}',
                          style: TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w500,
                            color: isDark
                                ? Colors.white60
                                : const Color(0xFF64748B),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
          if (notices.length > (hasLiveMsg ? 2 : 3)) ...[
            const SizedBox(height: 14),
            GestureDetector(
              onTap: () {
                IrisHaptics.selectionClick();
                pushGlassContainerMorphRoute(
                  context,
                  page: const AnnouncementsScreen(),
                  accentColor: const Color(0xFF06B6D4),
                );
              },
              child: Container(
                padding: const EdgeInsets.symmetric(
                  vertical: 8,
                  horizontal: 12,
                ),
                decoration: BoxDecoration(
                  color: (isDark ? Colors.white : Colors.black).withValues(
                    alpha: 0.05,
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'View all ${notices.length} notices',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF06B6D4),
                      ),
                    ),
                    const SizedBox(width: 4),
                    const Icon(
                      Icons.arrow_forward_rounded,
                      size: 14,
                      color: Color(0xFF06B6D4),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
