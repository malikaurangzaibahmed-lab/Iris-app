import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import '../../core/models.dart';
import '../../core/omni_brain.dart';
import '../../core/sticker_tokens.dart';
import '../../core/theme_signals.dart';
import '../../core/animations.dart';
import '../../core/vital_theme.dart';
import '../../services/remote_config_service.dart';
import '../../services/ui_feedback.dart';
import '../cards/sticker_card.dart';
import '../controls/doodle_speech_bubble.dart';
import '../controls/washi_tape_chip.dart';
import '../controls/tactile_stationery.dart';
import '../effects/doodle_mascots.dart';
import 'package:iris/widgets/effects/glass_container_transform.dart';
import '../../widgets/iris_components.dart';
import 'package:iris/widgets/dashboard/live_class_hub_sheet.dart';
import 'package:iris/screens/academics/department_classes_screen.dart';
import 'package:iris/screens/settings/announcements_screen.dart';

/// Authentic Google Pixel / Material 3 Expressive Home Header.
/// Spacious, content-driven, pixel-perfect clone of the approved mockup.
/// 0% idle CPU, zero blur shaders, native typography, and 100% real timetable data.
class MaterialExpressiveHomeHeader extends StatelessWidget {
  final bool isDark;
  final DateTime now;
  final String displayName;
  final String greetingText;
  final String period;
  final TemporalInsight insight;
  final List<ClassSession> schedule;
  final List<ClassSession> filteredSchedule;
  final OmniBrain brain;
  final String batch;
  final UniversityMemory memory;
  final VoidCallback onTriggerBatchSelector;
  final ValueChanged<String>? onBatchChanged;
  final ValueChanged<String>? onRoleChanged;

  const MaterialExpressiveHomeHeader({
    required this.isDark,
    required this.now,
    required this.displayName,
    required this.greetingText,
    required this.period,
    required this.insight,
    required this.schedule,
    required this.filteredSchedule,
    required this.brain,
    required this.batch,
    required this.memory,
    required this.onTriggerBatchSelector,
    this.onBatchChanged,
    this.onRoleChanged,
    super.key,
  });

  static String getDegreeTitle(String batch) {
    final upper = batch.toUpperCase();
    if (upper.contains('BCS') || upper.contains('-CS-')) return 'BS Computer Science';
    if (upper.contains('BSE') || upper.contains('-SE-')) return 'BS Software Engineering';
    if (upper.contains('BAI') || upper.contains('-AI-')) return 'BS Artificial Intelligence';
    if (upper.contains('BDS') || upper.contains('-DS-')) return 'BS Data Science';
    if (upper.contains('BCY') || upper.contains('-CY-')) return 'BS Cyber Security';
    if (upper.contains('BEE') || upper.contains('-EE-')) return 'BS Electrical Engineering';
    if (upper.contains('BBA')) return 'BBA';
    return 'BS Computer Science';
  }

  static String getInitials(String? name) {
    if (name == null || name.trim().isEmpty) return 'ST';
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.length == 1) {
      if (parts[0].length >= 2) {
        return parts[0].substring(0, 2).toUpperCase();
      }
      return parts[0].toUpperCase();
    }
    final first = parts.first.isNotEmpty
        ? parts.first.substring(0, 1).toUpperCase()
        : '';
    final last = parts.last.isNotEmpty
        ? parts.last.substring(0, 1).toUpperCase()
        : '';
    return '$first$last';
  }

  static String _dayShort(int dayIndex) {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    if (dayIndex >= 1 && dayIndex <= 7) return days[dayIndex - 1];
    return 'Upcoming';
  }

  static String getSmartGreeting(int hour) {
    if (hour >= 5 && hour < 12) return 'Morning';
    if (hour >= 12 && hour < 17) return 'Afternoon';
    if (hour >= 17 && hour < 21) return 'Evening';
    return 'Night';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    // Real timetable data resolution
    final currentClass = brain.getCurrentClass(batch, now);
    final nextClass = brain.getNextClass(batch, now);
    final heroClass = currentClass ?? nextClass ?? (schedule.isNotEmpty ? schedule.first : null);

    final isLive = heroClass != null && heroClass.isLive(now);
    final isToday = heroClass != null && heroClass.dayIndex == now.weekday;
    int minutesUntil = 0;
    if (heroClass != null && !isLive && isToday) {
      final currentHourFraction = now.hour + (now.minute / 60.0);
      final diff = heroClass.safeStartVal - currentHourFraction;
      if (diff > 0) {
        minutesUntil = (diff * 60).round();
      }
    }

    final degreeTitle = getDegreeTitle(batch);
    final studentFirstName = displayName.split(RegExp(r'\s+')).first;
    final smartGreeting = getSmartGreeting(now.hour);

    final String badgeText = isLive
        ? 'LIVE NOW'
        : (heroClass != null
            ? (isToday ? 'UP NEXT' : 'NEXT CLASS')
            : 'TODAY');

    final String statusText = isLive
        ? 'Active Class'
        : (minutesUntil > 0 && minutesUntil <= 120
            ? 'Starts in $minutesUntil min'
            : (heroClass != null
                ? (isToday
                    ? 'At ${heroClass.startTime}'
                    : '${_dayShort(heroClass.dayIndex)} at ${heroClass.startTime}')
                : 'Free Day 🎉'));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        // 1. Google Pixel Expressive Top App Bar (Sticker Scrapbook Style)
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            // Row 1: Left [Avatar + Greeting & Name] ... Right [Speech Bubble + Bell]
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Squircle Monogram Avatar with Live Status Dot & Menu
                IrisGlassMenu(
                  autoAdjustToScreen: true,
                  menuPadding: const EdgeInsets.all(14),
                  menuWidth: 230,
                  menuBorderRadius: 24.0,
                  itemBorderRadius: 18.0,
                  triggerBuilder: (menuContext, toggleMenu) {
                    return ExpressiveInteractivePress(
                      onTap: toggleMenu,
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Container(
                            width: 52,
                            height: 52,
                            decoration: BoxDecoration(
                              color: StickerTokens.peach(isDark),
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(
                                color: StickerTokens.inkOutline(isDark),
                                width: 1.85,
                              ),
                              boxShadow: StickerTokens.stickerShadow(isDark, offset: 2.2),
                            ),
                            child: Center(
                              child: Text(
                                getInitials(displayName),
                                style: GoogleFonts.poppins(
                                  color: isDark ? Colors.white : const Color(0xFF2C221A),
                                  fontWeight: FontWeight.w900,
                                  fontSize: 18,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            right: -1,
                            bottom: -1,
                            child: Container(
                              width: 15,
                              height: 15,
                              decoration: BoxDecoration(
                                color: const Color(0xFF10B981),
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: isDark ? cs.surface : Colors.white,
                                  width: 2.5,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFF10B981).withValues(alpha: 0.5),
                                    blurRadius: 4,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                  items: [
                    lgw.GlassMenuItem(
                      title: 'Student Mode',
                      titleStyle: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 13.5,
                        color: cs.primary,
                      ),
                      isSelected: true,
                      icon: const Icon(Icons.school_rounded, size: 18),
                      onTap: () {},
                    ),
                    lgw.GlassMenuItem(
                      title: 'Faculty Mode',
                      titleStyle: TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 13.5,
                        color: isDark ? Colors.white70 : Colors.black87,
                      ),
                      isSelected: false,
                      icon: const Icon(Icons.badge_rounded, size: 18),
                      onTap: () {
                        onRoleChanged?.call('faculty');
                      },
                    ),
                    const lgw.GlassMenuDivider(),
                    lgw.GlassMenuItem(
                      title: 'Select Batch',
                      titleStyle: TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 13.5,
                        color: isDark ? Colors.white70 : Colors.black87,
                      ),
                      icon: const Icon(Icons.layers_rounded, size: 18),
                      onTap: () {
                        onTriggerBatchSelector();
                      },
                    ),
                    const lgw.GlassMenuDivider(),
                    lgw.GlassMenuItem(
                      title: 'Switch to Liquid Glass',
                      titleStyle: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 13.5,
                        color: VitalTokens.purple,
                      ),
                      icon: const Icon(
                        Icons.water_drop_rounded,
                        size: 18,
                        color: VitalTokens.purple,
                      ),
                      onTap: () {
                        ThemeSignals.switchThemeWithMorph(
                          context,
                          style: IrisThemeStyle.fluidGlass,
                        );
                      },
                    ),
                  ],
                ),
                const SizedBox(width: 12),
                // Greeting and Student Name with FittedBox to prevent any ellipses truncation
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Good $smartGreeting,',
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: isDark ? const Color(0xFFCBD5E1) : const Color(0xFF645345),
                        ),
                      ),
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: Alignment.centerLeft,
                        child: Text(
                          studentFirstName,
                          style: GoogleFonts.poppins(
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -0.5,
                            color: isDark ? Colors.white : const Color(0xFF2C221A),
                            height: 1.15,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                const Spacer(),
                ExpressiveInteractivePress(
                  onTap: () {
                    IrisHaptics.actionSoft();
                    pushGlassContainerMorphRoute(
                      context,
                      page: const AnnouncementsScreen(),
                      accentColor: cs.primary,
                    );
                  },
                  enable3DTilt: false,
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: StickerTokens.peach(isDark),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: StickerTokens.inkOutline(isDark),
                            width: 1.85,
                          ),
                          boxShadow: StickerTokens.stickerShadow(isDark, offset: 2.2),
                        ),
                        child: Center(
                          child: Icon(
                            Icons.notifications_none_rounded,
                            size: 21,
                            color: StickerTokens.inkOutline(isDark),
                          ),
                        ),
                      ),
                      ValueListenableBuilder<List<Map<String, dynamic>>>(
                        valueListenable: RemoteConfigService.liveNotices,
                        builder: (context, notices, _) {
                          return ValueListenableBuilder<Map<String, dynamic>?>(
                            valueListenable: RemoteConfigService.liveAnnouncement,
                            builder: (context, broadcast, _) {
                              final hasNotices = notices.isNotEmpty ||
                                  (broadcast != null && broadcast['enabled'] == true);
                              if (!hasNotices) return const SizedBox.shrink();
                              return Positioned(
                                top: 2,
                                right: 2,
                                child: Container(
                                  width: 9,
                                  height: 9,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFEF4444),
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: isDark ? cs.surface : Colors.white,
                                      width: 1.5,
                                    ),
                                  ),
                                ),
                              );
                            },
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            // Row 2: Washi-Tape Batch / Degree Ribbon spanning across on its own line!
            if (batch.isNotEmpty)
              WashiTapeChip(
                label: '$batch • $degreeTitle',
                emoji: '🎓',
                isSelected: false,
                onTap: () {
                  IrisHaptics.chipSelect();
                  pushGlassContainerMorphRoute(
                    context,
                    page: DepartmentClassesScreen(
                      memory: memory,
                      brain: brain,
                      currentBatch: batch,
                      showBatchShortcut: true,
                      showBackButton: true,
                      onBatchChanged: onBatchChanged,
                      onRoleChanged: onRoleChanged,
                    ),
                    accentColor: cs.primary,
                  );
                },
                trailingBadge: Icon(
                  Icons.arrow_forward_ios_rounded,
                  size: 9,
                  color: StickerTokens.inkOutline(isDark),
                ),
              ),
          ],
        ),
        const SizedBox(height: 14),

        // 2. Tactile Hero "Up Next" / "Live Session" Sticker Card (with physical 3D overhangs)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: StickerCard(
            backgroundColor: StickerTokens.butter(isDark),
            padding: const EdgeInsets.all(18),
            rotationAngle: 0.0,
            enable3DTilt: false,
            clipContent: false,
            floatingDecorations: [
              // 1. Physical brass paperclip clasping the top card rim in 3D
              Positioned(
                top: -14,
                left: 20,
                child: PhysicalPaperclip(
                  isDark: isDark,
                  angle: -0.10,
                  height: 38,
                  width: 16,
                ),
              ),
              // 2. Floating Doodle Speech Bubble popping OUT of the card top right
              Positioned(
                top: -24,
                right: 14,
                child: Floating3DOverhang(
                  floatDistance: 2.4,
                  child: DoodleSpeechBubble(
                    text: smartGreeting == 'Night'
                        ? 'Rest & recharge!'
                        : (isLive ? 'Live in session! ⚡' : 'Focus & flow!'),
                    emoji: smartGreeting == 'Night' ? '🌙' : (isLive ? '🔥' : '✨'),
                    tailPosition: SpeechTailPosition.bottomRight,
                  ),
                ),
              ),
            ],
          onTap: () {
            if (isLive || insight.isUrgent) {
              IrisHaptics.actionSoft();
              IrisModalSheet.show(
                context: context,
                initialState: lgw.GlassSheetState.half,
                builder: (sheetContext) => LiveClassHubSheet(
                  brain: brain,
                  memory: memory,
                  batch: batch,
                  sessions: schedule,
                ),
              );
            } else if (heroClass != null) {
              IrisHaptics.selectionClick();
              pushGlassContainerMorphRoute(
                context,
                page: DepartmentClassesScreen(
                  memory: memory,
                  brain: brain,
                  currentBatch: batch,
                  showBatchShortcut: true,
                  showBackButton: true,
                  onBatchChanged: onBatchChanged,
                  onRoleChanged: onRoleChanged,
                ),
                accentColor: cs.primary,
              );
            }
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              // Top Row: "UP NEXT" / "LIVE NOW" / "NEXT CLASS" Badge + Status Pill
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                    decoration: BoxDecoration(
                      color: isDark ? const Color(0xFF332B1E) : const Color(0xFFFFEDD5),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: StickerTokens.inkOutline(isDark),
                        width: 1.4,
                      ),
                    ),
                    child: Text(
                      badgeText,
                      style: GoogleFonts.poppins(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.8,
                        color: isDark ? const Color(0xFFFDBA74) : const Color(0xFFC2410C),
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: isLive
                          ? (isDark ? const Color(0xFF143022) : const Color(0xFFDCFCE7))
                          : (isDark ? const Color(0xFF28251C) : const Color(0xFFFEF3C7)),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: StickerTokens.inkOutline(isDark),
                        width: 1.4,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (isLive || (minutesUntil > 0 && minutesUntil <= 120)) ...[
                          Container(
                            width: 6,
                            height: 6,
                            decoration: const BoxDecoration(
                              color: Color(0xFF10B981),
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 5),
                        ],
                        Text(
                          statusText,
                          style: GoogleFonts.poppins(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            color: isDark ? Colors.white : const Color(0xFF2C221A),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // Middle: Subject Title & Mascot
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          heroClass != null
                              ? heroClass.subject
                              : (insight.headline.isNotEmpty
                                  ? insight.headline
                                  : 'No Classes Scheduled'),
                          style: GoogleFonts.poppins(
                            fontSize: 19.5,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -0.4,
                            color: isDark ? Colors.white : const Color(0xFF2C221A),
                            height: 1.2,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 10),
                        // Detail Stickers: Time, Room, Teacher
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: isDark ? const Color(0xFF1F2430) : Colors.white,
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: StickerTokens.inkOutline(isDark),
                                  width: 1.2,
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Text('🕒', style: TextStyle(fontSize: 10)),
                                  const SizedBox(width: 4),
                                  Text(
                                    heroClass != null
                                        ? (isToday
                                            ? '${heroClass.startTime} - ${heroClass.endTime}'
                                            : '${_dayShort(heroClass.dayIndex)} • ${heroClass.startTime} - ${heroClass.endTime}')
                                        : 'Free Day',
                                    style: GoogleFonts.poppins(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700,
                                      color: isDark ? Colors.white70 : const Color(0xFF3B2F25),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            if (heroClass != null) ...[
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: isDark ? const Color(0xFF1F2430) : Colors.white,
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: StickerTokens.inkOutline(isDark),
                                    width: 1.2,
                                  ),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Text('🚪', style: TextStyle(fontSize: 10)),
                                    const SizedBox(width: 4),
                                    Text(
                                      heroClass.subject.toLowerCase().contains('lab')
                                          ? 'Lab ${heroClass.room}'
                                          : 'Room ${heroClass.room}',
                                      style: GoogleFonts.poppins(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w700,
                                        color: isDark ? Colors.white70 : const Color(0xFF3B2F25),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              if (heroClass.teacher.isNotEmpty)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: isDark ? const Color(0xFF1F2430) : Colors.white,
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: StickerTokens.inkOutline(isDark),
                                      width: 1.2,
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const Text('👤', style: TextStyle(fontSize: 10)),
                                      const SizedBox(width: 4),
                                      Text(
                                        heroClass.teacher,
                                        style: GoogleFonts.poppins(
                                          fontSize: 11,
                                          fontWeight: FontWeight.w700,
                                          color: isDark ? Colors.white70 : const Color(0xFF3B2F25),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              if (heroClass.isCombinedLecture)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: isDark ? const Color(0xFF332014) : const Color(0xFFFFEDD5),
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: StickerTokens.inkOutline(isDark),
                                      width: 1.2,
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const Text('👥', style: TextStyle(fontSize: 10)),
                                      const SizedBox(width: 4),
                                      Text(
                                        heroClass.displayBatch,
                                        style: GoogleFonts.poppins(
                                          fontSize: 11,
                                          fontWeight: FontWeight.w800,
                                          color: isDark ? const Color(0xFFFDBA74) : const Color(0xFFC2410C),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                            ] else ...[
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: isDark ? const Color(0xFF1F2430) : Colors.white,
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: StickerTokens.inkOutline(isDark),
                                    width: 1.2,
                                  ),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(now.weekday >= 6 ? '🏖️' : '✨', style: const TextStyle(fontSize: 10)),
                                    const SizedBox(width: 4),
                                    Text(
                                      now.weekday >= 6 ? 'Weekend Chill' : 'All Clear Today',
                                      style: GoogleFonts.poppins(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w700,
                                        color: isDark ? Colors.white70 : const Color(0xFF3B2F25),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Floating3DOverhang(
                    floatDistance: 2.5,
                    duration: const Duration(milliseconds: 2800),
                    child: heroClass != null
                        ? StudentWritingMascot(isDark: isDark, size: 72)
                        : SleepingKittyMascot(isDark: isDark, size: 62),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ],
    );
  }
}
