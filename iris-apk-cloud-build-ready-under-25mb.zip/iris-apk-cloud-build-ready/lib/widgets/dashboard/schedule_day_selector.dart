import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/sticker_tokens.dart';
import '../../core/theme_signals.dart';
import '../../core/tokens.dart';
import '../../core/animations.dart';
import '../../services/ui_feedback.dart';

/// Compact, expressive pill day-switcher supporting both Material 3 Expressive and Liquid Glass modes.
class ScheduleDaySelector extends StatelessWidget {
  final bool isDark;
  final int? overrideDayIndex;
  final ValueChanged<int?> onDayChanged;

  const ScheduleDaySelector({
    required this.isDark,
    required this.overrideDayIndex,
    required this.onDayChanged,
    super.key,
  });

  static const List<Map<String, dynamic>> days = [
    {'name': 'Sun', 'index': 7},
    {'name': 'Mon', 'index': 1},
    {'name': 'Tue', 'index': 2},
    {'name': 'Wed', 'index': 3},
    {'name': 'Thu', 'index': 4},
    {'name': 'Fri', 'index': 5},
    {'name': 'Sat', 'index': 6},
  ];

  @override
  Widget build(BuildContext context) {
    final activeDay = overrideDayIndex ?? DateTime.now().weekday;
    final isM3 = ThemeSignals.isMaterialYou;

    // -------------------------------------------------------------------------
    // Material 3 Expressive: Authentic Scrapbook Torn Paper Washi Tabs with Stars
    // -------------------------------------------------------------------------
    if (isM3) {
      final outlineColor = StickerTokens.inkOutline(isDark);
      final shadowColor = isDark ? Colors.black54 : const Color(0x3B2C221A);
      const angles = [-1.2, 0.9, -0.6, 1.1, -0.8, 0.7, -1.0];

      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
        child: Row(
          children: List.generate(days.length, (i) {
            final day = days[i];
            final dayIndex = day['index'] as int;
            final isSelected = activeDay == dayIndex;
            final isCurrentDay = DateTime.now().weekday == dayIndex;
            final rot = angles[i % angles.length];

            final itemBg = isSelected
                ? (isDark ? const Color(0xFFC2410C) : const Color(0xFFFF8A65))
                : (isDark ? const Color(0xFF222936) : const Color(0xFFF7F2E7));

            final textColor = isSelected
                ? Colors.white
                : (isCurrentDay
                    ? (isDark ? const Color(0xFFFDBA74) : const Color(0xFFEA580C))
                    : (isDark ? const Color(0xFFCBD5E1) : const Color(0xFF3B2F25)));

            return Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 2.0),
                child: Transform.rotate(
                  angle: rot * (math.pi / 180.0),
                  child: ExpressiveSpringPress(
                    onTap: () {
                      IrisHaptics.selectionClick();
                      if (overrideDayIndex == dayIndex) {
                        onDayChanged(null);
                      } else {
                        onDayChanged(dayIndex);
                      }
                    },
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        TornPaperStrip(
                          backgroundColor: itemBg,
                          outlineColor: outlineColor,
                          outlineWidth: isSelected ? 1.8 : 1.3,
                          shadowColor: shadowColor,
                          shadowOffset: isSelected ? 2.4 : 1.5,
                          height: 38,
                          seed: i,
                          child: Text(
                            day['name'] as String,
                            style: GoogleFonts.poppins(
                              fontSize: 12.0,
                              fontWeight: isSelected ? FontWeight.w900 : FontWeight.w700,
                              color: textColor,
                            ),
                          ),
                        ),
                        if (isSelected) ...[
                          const Positioned(
                            top: -8,
                            right: -5,
                            child: ComicDoodleStar(
                              size: 14.0,
                              fillColor: Color(0xFFFFB74D),
                            ),
                          ),
                          const Positioned(
                            top: 13,
                            right: -6,
                            child: ComicDoodleStar(
                              size: 11.0,
                              fillColor: Color(0xFFFF8A65),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            );
          }),
        ),
      );
    }

    // -------------------------------------------------------------------------
    // Liquid Glass Mode: Frosted Pill Stadium Dock (100% UNTOUCHED)
    // -------------------------------------------------------------------------
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
      child: Container(
        height: 48,
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: isDark
              ? Colors.white.withValues(alpha: 0.08)
              : Colors.white.withValues(alpha: 0.70),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(
            color: (isDark ? Colors.white : Colors.black).withValues(
              alpha: isDark ? 0.10 : 0.06,
            ),
            width: 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.20 : 0.04),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: days.map((day) {
            final dayIndex = day['index'] as int;
            final isSelected = activeDay == dayIndex;
            final isCurrentDay = DateTime.now().weekday == dayIndex;

            final selectedBg = isDark
                ? Colors.white.withValues(alpha: 0.20)
                : Colors.white;
            final selectedText = isDark ? Colors.white : const Color(0xFF0F172A);
            final unselectedText = isCurrentDay
                ? IrisTokens.brand
                : (isDark ? Colors.white70 : const Color(0xFF64748B));

            return Expanded(
              child: ExpressiveSpringPress(
                onTap: () {
                  IrisHaptics.selectionClick();
                  if (overrideDayIndex == dayIndex) {
                    onDayChanged(null);
                  } else {
                    onDayChanged(dayIndex);
                  }
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  curve: Curves.easeOutCubic,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: isSelected ? selectedBg : Colors.transparent,
                    borderRadius: BorderRadius.circular(999),
                    boxShadow: isSelected
                        ? [
                            BoxShadow(
                              color: Colors.black.withValues(
                                alpha: isDark ? 0.35 : 0.08,
                              ),
                              blurRadius: 6,
                              offset: const Offset(0, 2),
                            ),
                          ]
                        : null,
                  ),
                  child: Center(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        day['name'] as String,
                        maxLines: 1,
                        style: TextStyle(
                          fontSize: 12.0,
                          fontWeight: isSelected
                              ? FontWeight.w900
                              : (isCurrentDay
                                  ? FontWeight.w800
                                  : FontWeight.w600),
                          color: isSelected ? selectedText : unselectedText,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

/// Authentic serrated torn paper washi strip with jagged deckle edges and cardboard shadow.
class TornPaperStrip extends StatelessWidget {
  final Widget child;
  final Color backgroundColor;
  final Color outlineColor;
  final double outlineWidth;
  final Color shadowColor;
  final double shadowOffset;
  final double height;
  final int seed;

  const TornPaperStrip({
    super.key,
    required this.child,
    required this.backgroundColor,
    required this.outlineColor,
    this.outlineWidth = 1.6,
    required this.shadowColor,
    this.shadowOffset = 2.4,
    this.height = 38.0,
    this.seed = 0,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return CustomPaint(
      painter: _TornPaperStripPainter(
        backgroundColor: backgroundColor,
        outlineColor: outlineColor,
        outlineWidth: outlineWidth,
        shadowColor: shadowColor,
        shadowOffset: shadowOffset,
        seed: seed,
        isDark: isDark,
      ),
      child: Container(
        height: height,
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: child,
      ),
    );
  }
}

class _TornPaperStripPainter extends CustomPainter {
  final Color backgroundColor;
  final Color outlineColor;
  final double outlineWidth;
  final Color shadowColor;
  final double shadowOffset;
  final int seed;
  final bool isDark;

  const _TornPaperStripPainter({
    required this.backgroundColor,
    required this.outlineColor,
    required this.outlineWidth,
    required this.shadowColor,
    required this.shadowOffset,
    required this.seed,
    this.isDark = false,
  });

  Path _createTornPath(Size size) {
    final w = size.width;
    final h = size.height;
    final path = Path();

    // 1. Start top-left
    path.moveTo(0, 0);

    // 2. Top edge: serrated hand-torn paper deckle teeth (4 teeth across ticket width)
    const topTeeth = 4;
    final dxTop = w / topTeeth;
    for (int i = 0; i < topTeeth; i++) {
      final xMid = (i + 0.5) * dxTop;
      final xEnd = (i + 1) * dxTop;
      final toothDepth = ((i + seed) % 2 == 0) ? -2.2 : 1.5;
      path.lineTo(xMid, toothDepth);
      path.lineTo(xEnd, 0);
    }

    // 3. Right edge: straight vertical edge
    path.lineTo(w, h);

    // 4. Bottom edge: serrated hand-torn paper deckle teeth going backwards
    const bottomTeeth = 4;
    final dxBottom = w / bottomTeeth;
    for (int i = 0; i < bottomTeeth; i++) {
      final xMid = w - (i + 0.5) * dxBottom;
      final xEnd = w - (i + 1) * dxBottom;
      final toothDepth = ((i + seed) % 2 == 0) ? h + 2.4 : h - 1.5;
      path.lineTo(xMid, toothDepth);
      path.lineTo(xEnd, h);
    }

    // 5. Left edge: straight back up to start
    path.lineTo(0, 0);
    path.close();
    return path;
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;
    final path = _createTornPath(size);

    // 1. Soft tactile ambient depth shadow
    final ambientPaint = Paint()
      ..color = shadowColor.withValues(alpha: isDark ? 0.28 : 0.16)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.8);
    canvas.drawPath(path.shift(Offset(0.8, shadowOffset + 1.0)), ambientPaint);

    // 2. Zero-blur cardboard contact drop shadow
    final shadowPaint = Paint()
      ..color = shadowColor
      ..style = PaintingStyle.fill;
    canvas.drawPath(path.shift(Offset(1.2, shadowOffset)), shadowPaint);

    // 3. Paper solid fill
    final fillPaint = Paint()
      ..color = backgroundColor
      ..style = PaintingStyle.fill;
    canvas.drawPath(path, fillPaint);

    // 4. Subtle vertical paper fiber texture
    canvas.save();
    canvas.clipPath(path);
    final fiberPaint = Paint()
      ..color = (isDark ? Colors.white : Colors.black).withValues(alpha: 0.04)
      ..strokeWidth = 0.75
      ..style = PaintingStyle.stroke;
    for (double x = 4; x < size.width; x += 5.5) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), fiberPaint);
    }

    // 5. Exposed paper pulp fringe (white exposed paper core along the torn deckle teeth)
    final pulpPaint = Paint()
      ..color = Colors.white.withValues(alpha: isDark ? 0.18 : 0.40)
      ..strokeWidth = 0.9
      ..style = PaintingStyle.stroke;
    canvas.drawPath(path, pulpPaint);
    canvas.restore();

    // 6. Crisp ink outline
    final strokePaint = Paint()
      ..color = outlineColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = outlineWidth
      ..strokeJoin = StrokeJoin.miter
      ..isAntiAlias = true;
    canvas.drawPath(path, strokePaint);
  }

  @override
  bool shouldRepaint(covariant _TornPaperStripPainter old) {
    return backgroundColor != old.backgroundColor ||
        outlineColor != old.outlineColor ||
        outlineWidth != old.outlineWidth ||
        shadowColor != old.shadowColor ||
        shadowOffset != old.shadowOffset ||
        seed != old.seed ||
        isDark != old.isDark;
  }
}

/// Hand-sketched 5-pointed comic star sticker with ink stroke and physical drop shadow.
class ComicDoodleStar extends StatelessWidget {
  final double size;
  final Color fillColor;
  final Color outlineColor;

  const ComicDoodleStar({
    super.key,
    this.size = 13.0,
    this.fillColor = const Color(0xFFFB923C),
    this.outlineColor = const Color(0xFF2C1810),
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(size, size),
      painter: _ComicStarPainter(fillColor: fillColor, outlineColor: outlineColor),
    );
  }
}

class _ComicStarPainter extends CustomPainter {
  final Color fillColor;
  final Color outlineColor;

  const _ComicStarPainter({required this.fillColor, required this.outlineColor});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final rOuter = size.width / 2;
    final rInner = rOuter * 0.45;
    const points = 5;

    final path = Path();
    for (int i = 0; i < points * 2; i++) {
      final angle = (i * math.pi / points) - (math.pi / 2);
      final r = (i % 2 == 0) ? rOuter : rInner;
      final x = cx + r * math.cos(angle);
      final y = cy + r * math.sin(angle);
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    path.close();

    // Physical sticker drop shadow
    canvas.drawPath(
      path.shift(const Offset(0.8, 1.2)),
      Paint()
        ..color = const Color(0x3B2C221A)
        ..style = PaintingStyle.fill,
    );

    canvas.drawPath(path, Paint()..color = fillColor..style = PaintingStyle.fill);
    canvas.drawPath(
      path,
      Paint()
        ..color = outlineColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.3
        ..strokeJoin = StrokeJoin.round
        ..isAntiAlias = true,
    );
  }

  @override
  bool shouldRepaint(covariant _ComicStarPainter old) => false;
}

/// Backward compatibility alias for the schedule day selector
typedef Concept2DaySwitcher = ScheduleDaySelector;
