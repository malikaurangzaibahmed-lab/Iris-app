import 'dart:math' as math;
import 'package:flutter/material.dart';

import '../../core/glass.dart';
import '../../core/theme_signals.dart';
import '../../core/tokens.dart';
import '../../services/app_update_service.dart';
import '../../services/remote_config_service.dart';
import '../../services/ui_feedback.dart';

class SystemUpdateBanner extends StatelessWidget {
  final Map<String, dynamic> update;

  const SystemUpdateBanner({
    required this.update,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final vName = update['version_name']?.toString() ?? '1.1.0';
    final notes = update['release_notes']?.toString() ?? '';
    final apkUrl = update['apk_url']?.toString() ?? '';

    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: IrisTokens.brand.withValues(
                      alpha: isDark ? 0.25 : 0.15,
                    ),
                    blurRadius: 16,
                    spreadRadius: 1,
                  ),
                ],
              ),
            ),
          ),
          ClipRRect(
            borderRadius: IrisTokens.cardRadius,
            child: GlassSurface(
              settings: IrisGlass.settings(
                context,
                blur: 20,
                ambientStrength: 0.8,
                lightAngle: 0.15 * math.pi,
                thickness: 18,
                glassColor: isDark
                    ? IrisTokens.brand.withValues(alpha: 0.12)
                    : Colors.white.withValues(alpha: 0.85),
              ),
              radius: 20,
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: IrisTokens.brand.withValues(alpha: 0.45),
                    width: 1.5,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: IrisTokens.brand.withValues(alpha: 0.15),
                          ),
                          child: Icon(
                            Icons.system_update_rounded,
                            size: 18,
                            color: isDark ? Colors.white : IrisTokens.brand,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'SYSTEM UPDATE AVAILABLE',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 1.2,
                                  color: isDark
                                      ? Colors.white70
                                      : IrisTokens.brand,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                'IRIS Enhanced v$vName',
                                style: IrisTextStyles.headline(context)
                                    .copyWith(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w900,
                                    ),
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          onPressed: () {
                            IrisHaptics.selectionClick();
                            RemoteConfigService.dismissAdminUpdateBanner(
                              vName,
                              apkUrl,
                            );
                          },
                          icon: Icon(
                            Icons.close_rounded,
                            size: 18,
                            color: (isDark ? Colors.white : Colors.black)
                                .withValues(alpha: 0.45),
                          ),
                          tooltip: 'Dismiss update',
                        ),
                      ],
                    ),
                    if (notes.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Text(
                        notes,
                        style: IrisTextStyles.caption(context).copyWith(
                          fontSize: 11.5,
                          color: isDark ? Colors.white60 : Colors.black54,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                    const SizedBox(height: 14),
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: IrisTokens.brand,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: IrisTokens.buttonRadius,
                        ),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 11,
                        ),
                        elevation: 0,
                      ),
                      onPressed: () {
                        IrisHaptics.actionHeavy();
                        RemoteConfigService.dismissAdminUpdateBanner(
                          vName,
                          apkUrl,
                        );
                        AppUpdateService.showUpdateDialog(
                          context,
                          updateInfo: update,
                        );
                      },
                      icon: const Icon(Icons.download_rounded, size: 16),
                      label: const Text(
                        'Install Update Now',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 12.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
