import 'package:flutter/material.dart';
import '../../core/tokens.dart';
import '../../core/animations.dart';
import '../../core/theme_signals.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../glass_card.dart';

/// Filter selection pill for department classes (Program, Semester, Section),
/// supporting Material 3 Expressive, Liquid Glass, and all Graphic themes.
class DepartmentFilterPill extends StatelessWidget {
  final String title;
  final String value;
  final VoidCallback onTap;
  final bool isDark;
  final bool isM3;
  final ColorScheme cs;

  const DepartmentFilterPill({
    required this.title,
    required this.value,
    required this.onTap,
    required this.isDark,
    required this.isM3,
    required this.cs,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final hasValue = value != 'None';

    if (isM3) {
      return ExpressiveInteractivePress(
        onTap: onTap,
        pressedScale: 0.97,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: hasValue
                ? cs.primaryContainer.withValues(alpha: isDark ? 0.35 : 0.25)
                : cs.surfaceContainerHigh,
            borderRadius: BorderRadius.circular(16.0),
            border: Border.all(
              width: hasValue ? 1.4 : 1.0,
              color: hasValue
                  ? cs.primary
                  : cs.outlineVariant.withValues(alpha: isDark ? 0.4 : 0.6),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: 9.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.8,
                  color: hasValue ? cs.primary : cs.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 4),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      value,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: hasValue
                            ? cs.onSurface
                            : cs.onSurfaceVariant.withValues(alpha: 0.7),
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Icon(
                    Icons.keyboard_arrow_down_rounded,
                    size: 18,
                    color: hasValue ? cs.primary : cs.onSurfaceVariant,
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    }

    final themeStyle = ThemeSignals.themeStyle.value;
    final headingColor = switch (themeStyle) {
      IrisThemeStyle.notebook => hasValue ? IrisTokens.brand : NotebookTokens.inkMuted(isDark),
      IrisThemeStyle.line => hasValue ? IrisTokens.brand : LineTokens.inkMuted(isDark),
      IrisThemeStyle.poster => hasValue ? IrisTokens.brand : PosterTokens.inkMuted(isDark),
      IrisThemeStyle.almanac => hasValue ? IrisTokens.brand : AlmanacTokens.inkMuted(isDark),
      IrisThemeStyle.editorialAcademic => hasValue ? IrisTokens.brand : EditorialTokens.inkMuted(isDark),
      _ => hasValue
          ? IrisTokens.brand
          : (isDark
              ? Colors.white.withValues(alpha: 0.45)
              : Colors.black.withValues(alpha: 0.45)),
    };

    final bodyColor = switch (themeStyle) {
      IrisThemeStyle.notebook => hasValue ? NotebookTokens.inkHeading(isDark) : NotebookTokens.inkMuted(isDark),
      IrisThemeStyle.line => hasValue ? LineTokens.inkHeading(isDark) : LineTokens.inkMuted(isDark),
      IrisThemeStyle.poster => hasValue ? PosterTokens.inkHeading(isDark) : PosterTokens.inkMuted(isDark),
      IrisThemeStyle.almanac => hasValue ? AlmanacTokens.inkHeading(isDark) : AlmanacTokens.inkMuted(isDark),
      IrisThemeStyle.editorialAcademic => hasValue ? EditorialTokens.inkHeading(isDark) : EditorialTokens.inkMuted(isDark),
      _ => hasValue
          ? (isDark ? Colors.white : Colors.black87)
          : (isDark ? Colors.white38 : Colors.black38),
    };

    return RepaintBoundary(
      child: GlassCard(
        onTap: onTap,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        borderRadius: 24.0,
        accentColor: hasValue ? IrisTokens.brand : null,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.6,
                color: headingColor,
              ),
            ),
            const SizedBox(height: 4),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    value,
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w800,
                      color: bodyColor,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Icon(
                  Icons.keyboard_arrow_down_rounded,
                  size: 16,
                  color: hasValue
                      ? IrisTokens.brand
                      : (isDark ? Colors.white54 : Colors.black54),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

