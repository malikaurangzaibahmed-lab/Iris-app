import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;

import '../../core/glass.dart';
import '../../core/tokens.dart';
import '../../services/docx_generator.dart';
import '../../services/ui_feedback.dart';
import '../iris_components.dart';

class DocumentConverterView extends StatefulWidget {
  final bool isDark;

  const DocumentConverterView({
    required this.isDark,
    super.key,
  });

  @override
  State<DocumentConverterView> createState() => _DocumentConverterViewState();
}

class _DocumentConverterViewState extends State<DocumentConverterView> {
  PlatformFile? _pickedFile;
  String _targetFormat = 'Word (.docx)';
  bool _isConverting = false;
  double _conversionProgress = 0.0;
  String _conversionStep = 'Idle';
  bool _conversionSuccess = false;

  Future<void> _pickFileForConverter() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'docx', 'jpg', 'jpeg', 'png', 'txt'],
      );
      if (result != null && result.files.isNotEmpty) {
        setState(() {
          _pickedFile = result.files.first;
          _conversionSuccess = false;
          final ext = _pickedFile!.extension?.toLowerCase();
          if (ext == 'pdf') {
            _targetFormat = 'Word (.docx)';
          } else {
            _targetFormat = 'PDF (.pdf)';
          }
        });
        IrisHaptics.chipSelect();
      }
    } catch (e) {
      debugPrint('File picker error: $e');
    }
  }

  Future<void> _runConversion() async {
    if (_pickedFile == null) return;
    setState(() {
      _isConverting = true;
      _conversionProgress = 0.1;
      _conversionStep = 'Reading file...';
      _conversionSuccess = false;
    });

    try {
      final inputPath = _pickedFile!.path;
      if (inputPath == null) throw 'File path is unavailable';

      final file = File(inputPath);
      if (!file.existsSync()) throw 'Input file does not exist';

      final ext = _pickedFile!.extension?.toLowerCase() ?? '';
      final dir = await getApplicationDocumentsDirectory();
      final baseName = _pickedFile!.name.split('.').first;
      final timestamp = DateTime.now().millisecondsSinceEpoch;

      setState(() {
        _conversionProgress = 0.4;
        _conversionStep = 'Converting format...';
      });

      String outPath = '';

      if (_targetFormat.contains('.pdf')) {
        outPath = '${dir.path}/${baseName}_converted_$timestamp.pdf';
        final pdfDoc = PdfDocument();
        
        if (ext == 'jpg' || ext == 'jpeg' || ext == 'png' || ext == 'webp' || ext == 'bmp') {
          final page = pdfDoc.pages.add();
          final imageBytes = await file.readAsBytes();
          final pdfImage = PdfBitmap(imageBytes);
          page.graphics.drawImage(pdfImage, Rect.fromLTWH(0, 0, page.getClientSize().width, page.getClientSize().height));
        } else if (ext == 'pdf') {
          final sourceBytes = await file.readAsBytes();
          final sourceDoc = PdfDocument(inputBytes: sourceBytes);
          for (int i = 0; i < sourceDoc.pages.count; i++) {
            final template = sourceDoc.pages[i].createTemplate();
            final newPage = pdfDoc.pages.add();
            newPage.graphics.drawPdfTemplate(template, Offset.zero);
          }
          sourceDoc.dispose();
        } else {
          String text = '';
          try {
            text = await file.readAsString();
          } catch (_) {
            text = 'Converted Document Content (${_pickedFile!.name})\nSize: ${_formatBytes(_pickedFile!.size)}';
          }
          final page = pdfDoc.pages.add();
          PdfTextElement(
            text: text,
            font: PdfStandardFont(PdfFontFamily.helvetica, 11),
          ).draw(
            page: page,
            bounds: Rect.fromLTWH(0, 0, page.getClientSize().width, page.getClientSize().height),
            format: PdfLayoutFormat(layoutType: PdfLayoutType.paginate),
          );
        }

        final bytes = await pdfDoc.save();
        pdfDoc.dispose();
        await File(outPath).writeAsBytes(bytes);

      } else if (_targetFormat.contains('.docx')) {
        outPath = '${dir.path}/${baseName}_converted_$timestamp.docx';
        String text = '';
        if (ext == 'pdf') {
          try {
            final sourceBytes = await file.readAsBytes();
            final sourceDoc = PdfDocument(inputBytes: sourceBytes);
            final extractor = PdfTextExtractor(sourceDoc);
            text = extractor.extractText();
            if (text.trim().isEmpty) {
              final buf = StringBuffer();
              for (int i = 0; i < sourceDoc.pages.count; i++) {
                final pageText = PdfTextExtractor(sourceDoc).extractText(startPageIndex: i);
                if (pageText.trim().isNotEmpty) {
                  buf.writeln('--- Page ${i + 1} ---');
                  buf.writeln(pageText);
                }
              }
              text = buf.toString();
            }
            sourceDoc.dispose();
          } catch (e) {
            debugPrint('Pdf text extraction error: $e');
          }
        }
        if (text.trim().isEmpty) {
          try {
            text = await file.readAsString();
          } catch (_) {
            text = '# Document: ${_pickedFile!.name}\n\nProcessed & converted from PDF source.\nFile Size: ${_formatBytes(_pickedFile!.size)}';
          }
        }
        await DocxGenerator.generateDocx(
          filePath: outPath,
          markdownBody: text,
        );

      } else if (_targetFormat.contains('.txt')) {
        outPath = '${dir.path}/${baseName}_converted_$timestamp.txt';
        String text = '';
        if (ext == 'pdf') {
          try {
            final sourceBytes = await file.readAsBytes();
            final sourceDoc = PdfDocument(inputBytes: sourceBytes);
            final extractor = PdfTextExtractor(sourceDoc);
            text = extractor.extractText();
            if (text.trim().isEmpty) {
              final buf = StringBuffer();
              for (int i = 0; i < sourceDoc.pages.count; i++) {
                final pageText = PdfTextExtractor(sourceDoc).extractText(startPageIndex: i);
                if (pageText.trim().isNotEmpty) {
                  buf.writeln('--- Page ${i + 1} ---');
                  buf.writeln(pageText);
                }
              }
              text = buf.toString();
            }
            sourceDoc.dispose();
          } catch (e) {
            debugPrint('Pdf text extraction error: $e');
          }
        }
        if (text.trim().isEmpty) {
          try {
            text = await file.readAsString();
          } catch (_) {
            text = 'Source Document: ${_pickedFile!.name}\nFormat: ${ext.toUpperCase()}\nSize: ${_formatBytes(_pickedFile!.size)}';
          }
        }
        await File(outPath).writeAsString(text);

      } else {
        outPath = '${dir.path}/${baseName}_converted_$timestamp.jpg';
        if (ext == 'jpg' || ext == 'jpeg' || ext == 'png' || ext == 'webp') {
          await file.copy(outPath);
        } else {
          await File(outPath).writeAsBytes(await file.readAsBytes());
        }
      }

      setState(() {
        _conversionProgress = 1.0;
        _conversionStep = 'Conversion completed!';
        _isConverting = false;
        _conversionSuccess = true;
      });

      IrisHaptics.actionHeavy();
      if (!mounted) return;
      showIrisFrostedSnackBar(context, content: const Text('File converted successfully!'));
      await OpenFilex.open(outPath);
    } catch (e) {
      setState(() {
        _isConverting = false;
        _conversionStep = 'Conversion failed';
        _conversionSuccess = false;
      });
      if (!mounted) return;
      showIrisFrostedSnackBar(context, content: Text('Conversion failed: $e'));
    }
  }

  String _formatBytes(int bytes) {
    if (bytes <= 0) return '0 B';
    final kb = bytes / 1024;
    if (kb < 1024) return '${kb.toStringAsFixed(1)} KB';
    final mb = kb / 1024;
    return '${mb.toStringAsFixed(1)} MB';
  }

  @override
  Widget build(BuildContext context) {
    final isDark = widget.isDark;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GestureDetector(
            onTap: _isConverting ? null : _pickFileForConverter,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 36, horizontal: 16),
              decoration: BoxDecoration(
                color: isDark ? Colors.white.withValues(alpha: 0.03) : Colors.black.withValues(alpha: 0.01),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: _pickedFile != null
                      ? IrisTokens.brand.withValues(alpha: 0.6)
                      : (isDark ? Colors.white10 : Colors.black12),
                  width: _pickedFile != null ? 1.5 : 1.0,
                ),
              ),
              child: Column(
                children: [
                  Icon(
                    _pickedFile != null ? Icons.insert_drive_file_rounded : Icons.cloud_upload_outlined,
                    size: 48,
                    color: _pickedFile != null ? IrisTokens.brand : (isDark ? Colors.white38 : Colors.black38),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    _pickedFile != null ? _pickedFile!.name : 'Tap to Upload File',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      color: isDark ? Colors.white : Colors.black87,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _pickedFile != null
                        ? _formatBytes(_pickedFile!.size)
                        : 'Supports PDF, Word, JPG, PNG, TXT',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: (isDark ? Colors.white38 : Colors.black45),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          if (_pickedFile != null) ...[
            Text(
              'CONVERT TO',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w900,
                color: (isDark ? Colors.white54 : Colors.black54),
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white.withValues(alpha: 0.90),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: (isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.08))),
                boxShadow: [
                  if (!isDark)
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.04),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                ],
              ),
              child: IrisGlassMenu(
                autoAdjustToScreen: true,
                menuPadding: const EdgeInsets.all(16),
                menuWidth: 280,
                menuHeight: 200.0,
                menuBorderRadius: 28.0,
                itemBorderRadius: 20.0,
                settings: IrisGlass.widgetsSettings(
                  context,
                  blur: 16.0,
                  ambientStrength: 0.7,
                  lightAngle: 0.15 * math.pi,
                  thickness: 18.0,
                ),
                triggerBuilder: (context, toggleMenu) {
                  return InkWell(
                    onTap: _isConverting
                        ? null
                        : () {
                            IrisHaptics.actionSoft();
                            toggleMenu();
                          },
                    borderRadius: BorderRadius.circular(24),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            _targetFormat,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: isDark ? Colors.white : Colors.black87,
                            ),
                          ),
                          Icon(
                            Icons.keyboard_arrow_down_rounded,
                            color: isDark ? Colors.white70 : Colors.black54,
                            size: 20,
                          ),
                        ],
                      ),
                    ),
                  );
                },
                items: <String>['PDF (.pdf)', 'Word (.docx)', 'Images (.jpg)', 'Text (.txt)'].map((String value) {
                  final isSelected = value == _targetFormat;
                  IconData iconData = Icons.description_rounded;
                  if (value.contains('PDF')) {
                    iconData = Icons.picture_as_pdf_rounded;
                  } else if (value.contains('Word')) {
                    iconData = Icons.article_rounded;
                  } else if (value.contains('Images')) {
                    iconData = Icons.image_rounded;
                  } else if (value.contains('Text')) {
                    iconData = Icons.text_snippet_rounded;
                  }

                  return lgw.GlassMenuItem(
                    title: value,
                    titleStyle: TextStyle(
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.w600,
                      fontSize: 14,
                      color: isSelected ? IrisTokens.brand : (isDark ? Colors.white.withValues(alpha: 0.9) : Colors.black87),
                    ),
                    isSelected: isSelected,
                    icon: Icon(
                      iconData,
                      size: 16,
                      color: isSelected ? IrisTokens.brand : (isDark ? Colors.white70 : Colors.black54),
                    ),
                    onTap: () {
                      IrisHaptics.chipSelect();
                      setState(() => _targetFormat = value);
                    },
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 24),

            if (_isConverting) ...[
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: _conversionProgress,
                      minHeight: 8,
                      color: IrisTokens.brand,
                      backgroundColor: isDark ? Colors.white10 : Colors.black12,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    _conversionStep,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: isDark ? Colors.white70 : Colors.black54,
                    ),
                  ),
                ],
              ),
            ] else if (_conversionSuccess) ...[
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: IrisTokens.success.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: IrisTokens.success.withValues(alpha: 0.2)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.check_circle_rounded, color: IrisTokens.success, size: 28),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Conversion Completed!',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                              color: isDark ? Colors.white : Colors.black87,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'Target format: $_targetFormat',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: isDark ? Colors.white54 : Colors.black54,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () {
                        showIrisFrostedSnackBar(context, content: const Text('Opening file...'));
                      },
                      icon: Icon(Icons.open_in_new_rounded, color: IrisTokens.success),
                    ),
                  ],
                ),
              ),
            ] else ...[
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _runConversion,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: IrisTokens.brand,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: const Text('Convert Document', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ],
        ],
      ),
    );
  }
}
