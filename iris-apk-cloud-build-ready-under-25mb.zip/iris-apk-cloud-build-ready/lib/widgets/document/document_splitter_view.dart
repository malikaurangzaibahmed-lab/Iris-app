import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';

import '../../core/tokens.dart';
import '../../services/ui_feedback.dart';

class DocumentSplitterView extends StatefulWidget {
  final bool isDark;

  const DocumentSplitterView({
    required this.isDark,
    super.key,
  });

  @override
  State<DocumentSplitterView> createState() => _DocumentSplitterViewState();
}

class _DocumentSplitterViewState extends State<DocumentSplitterView> {
  PlatformFile? _splitterFile;
  final TextEditingController _rangeController = TextEditingController(text: '1-3');
  bool _isSplitting = false;
  double _splitterProgress = 0.0;
  bool _splitterSuccess = false;

  @override
  void dispose() {
    _rangeController.dispose();
    super.dispose();
  }

  Future<void> _pickFileForSplitter() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
      );
      if (result != null && result.files.isNotEmpty) {
        setState(() {
          _splitterFile = result.files.first;
          _splitterSuccess = false;
        });
        IrisHaptics.chipSelect();
      }
    } catch (e) {
      debugPrint('File picker error: $e');
    }
  }

  Future<void> _runSplit() async {
    if (_splitterFile == null) return;
    setState(() {
      _isSplitting = true;
      _splitterProgress = 0.1;
      _splitterSuccess = false;
    });

    try {
      final inputPath = _splitterFile!.path;
      if (inputPath == null) throw 'File path is unavailable';
      
      final rangeText = _rangeController.text.trim();
      if (rangeText.isEmpty) throw 'Please specify page range (e.g. 1-3)';
      
      int startPage = 1;
      int endPage = 1;
      
      if (rangeText.contains('-')) {
        final parts = rangeText.split('-');
        startPage = int.parse(parts[0].trim());
        endPage = int.parse(parts[1].trim());
      } else {
        startPage = int.parse(rangeText);
        endPage = startPage;
      }
      
      if (startPage <= 0 || endPage < startPage) {
        throw 'Invalid page range specified';
      }
      
      setState(() {
        _splitterProgress = 0.4;
      });
      
      final sourceBytes = await File(inputPath).readAsBytes();
      final sourceDoc = PdfDocument(inputBytes: sourceBytes);
      final totalPages = sourceDoc.pages.count;
      
      if (startPage > totalPages || endPage > totalPages) {
        sourceDoc.dispose();
        throw 'Range exceeds total document pages ($totalPages)';
      }
      
      final destinationDoc = PdfDocument();
      
      for (int i = startPage; i <= endPage; i++) {
        final sourcePage = sourceDoc.pages[i - 1];
        final template = sourcePage.createTemplate();
        final destPage = destinationDoc.pages.add();
        destPage.graphics.drawPdfTemplate(template, Offset.zero);
        
        setState(() {
          _splitterProgress = 0.4 + (0.4 * (i - startPage + 1) / (endPage - startPage + 1));
        });
      }
      
      final List<int> bytes = await destinationDoc.save();
      destinationDoc.dispose();
      sourceDoc.dispose();
      
      final dir = await getApplicationDocumentsDirectory();
      final baseName = _splitterFile!.name.split('.').first;
      final outPath = '${dir.path}/${baseName}_split_${startPage}_to_${endPage}_${DateTime.now().millisecondsSinceEpoch}.pdf';
      final file = File(outPath);
      await file.writeAsBytes(bytes);
      
      setState(() {
        _splitterProgress = 1.0;
        _isSplitting = false;
        _splitterSuccess = true;
      });
      
      IrisHaptics.actionHeavy();
      if (!mounted) return;
      showIrisFrostedSnackBar(context, content: const Text('PDF pages split successfully!'));
      
      await OpenFilex.open(outPath);
    } catch (e) {
      setState(() {
        _isSplitting = false;
        _splitterSuccess = false;
      });
      if (!mounted) return;
      showIrisFrostedSnackBar(context, content: Text('Split failed: $e'));
    }
  }

  String _formatBytes(int bytes) {
    if (bytes <= 0) return '0 B';
    final kb = bytes / 1024;
    if (kb < 1024) return '${kb.toStringAsFixed(1)} KB';
    final mb = kb / 1024;
    return '${mb.toStringAsFixed(1)} MB';
  }

  @override
  Widget build(BuildContext context) {
    final isDark = widget.isDark;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GestureDetector(
            onTap: _isSplitting ? null : _pickFileForSplitter,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 36, horizontal: 16),
              decoration: BoxDecoration(
                color: isDark ? Colors.white.withValues(alpha: 0.03) : Colors.black.withValues(alpha: 0.01),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: _splitterFile != null
                      ? IrisTokens.purple.withValues(alpha: 0.6)
                      : (isDark ? Colors.white10 : Colors.black12),
                  width: _splitterFile != null ? 1.5 : 1.0,
                ),
              ),
              child: Column(
                children: [
                  Icon(
                    _splitterFile != null ? Icons.picture_as_pdf_rounded : Icons.upload_file_rounded,
                    size: 48,
                    color: _splitterFile != null ? IrisTokens.purple : (isDark ? Colors.white38 : Colors.black38),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    _splitterFile != null ? _splitterFile!.name : 'Select PDF File',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      color: isDark ? Colors.white : Colors.black87,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _splitterFile != null
                        ? _formatBytes(_splitterFile!.size)
                        : 'Choose a PDF to extract pages',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: (isDark ? Colors.white38 : Colors.black45),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          if (_splitterFile != null) ...[
            Text(
              'PAGE RANGE (E.G. 1-3 OR 5)',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w900,
                color: (isDark ? Colors.white54 : Colors.black54),
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white.withValues(alpha: 0.90),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: (isDark ? Colors.white10 : Colors.black.withValues(alpha: 0.08))),
                boxShadow: [
                  if (!isDark)
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.04),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                ],
              ),
              child: TextField(
                controller: _rangeController,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: isDark ? Colors.white : Colors.black87,
                ),
                decoration: InputDecoration(
                  hintText: 'e.g. 1-5 or 2',
                  hintStyle: TextStyle(
                    fontSize: 13,
                    color: isDark ? Colors.white38 : Colors.black38,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  prefixIcon: Icon(
                    Icons.format_list_numbered_rounded,
                    color: IrisTokens.purple,
                    size: 20,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),

            if (_isSplitting) ...[
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: _splitterProgress,
                      minHeight: 8,
                      color: IrisTokens.purple,
                      backgroundColor: isDark ? Colors.white10 : Colors.black12,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Extracting and rebuilding PDF pages...',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: isDark ? Colors.white70 : Colors.black54,
                    ),
                  ),
                ],
              ),
            ] else if (_splitterSuccess) ...[
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: IrisTokens.purple.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: IrisTokens.purple.withValues(alpha: 0.2)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.check_circle_rounded, color: IrisTokens.purple, size: 28),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'PDF Split Completed!',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                              color: isDark ? Colors.white : Colors.black87,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'Extracted Range: ${_rangeController.text}',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: isDark ? Colors.white54 : Colors.black54,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () {
                        showIrisFrostedSnackBar(context, content: const Text('Saved split document.'));
                      },
                      icon: Icon(Icons.download_rounded, color: IrisTokens.purple),
                    ),
                  ],
                ),
              ),
            ] else ...[
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _runSplit,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: IrisTokens.purple,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: const Text('Split PDF', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ],
        ],
      ),
    );
  }
}
