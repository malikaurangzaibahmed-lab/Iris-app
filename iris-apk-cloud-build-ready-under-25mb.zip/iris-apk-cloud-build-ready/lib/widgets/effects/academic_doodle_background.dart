import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/vital_theme.dart';
import '../../core/theme_signals.dart';

/// High-performance academic and student doodle wallpaper.
///
/// Draws an authentic, organically scattered WhatsApp-chat-style monochrome
/// wallpaper of educational vectors (graduation cap, open book, microscope,
/// beaker, compass, backpack, atom, laptop, idea bulb, pencil, study mug,
/// alarm clock, paper airplanes, paperclips, math symbols, sparkles, and stars)
/// scattered with organic non-linear offsets, playful dynamic rotations,
/// and scale variance at 3.5%–5.0% opacity.
///
/// Fully optimized with cached GPU display list rasterization for locked 120 FPS.
class AcademicDoodleBackground extends StatelessWidget {
  final bool isDark;
  final Color? baseColor;
  final Color? iconColor;
  final double? opacity;
  final Widget? child;

  const AcademicDoodleBackground({
    super.key,
    required this.isDark,
    this.baseColor,
    this.iconColor,
    this.opacity,
    this.child,
  });

  @override
  Widget build(BuildContext context) {
    final isM3 = ThemeSignals.isMaterialYou;
    final effectiveBase = baseColor ??
        (isDark ? VitalTokens.obsidian : VitalTokens.offWhite);

    final effectiveOpacity = opacity ??
        (isM3 ? (isDark ? 0.22 : 0.17) : (isDark ? 0.095 : 0.080));
    final effectiveStrokeColor = (iconColor ??
            (isDark
                ? (isM3 ? const Color(0xFF94A3B8) : Colors.white)
                : (isM3 ? const Color(0xFF5A4432) : const Color(0xFF0F172A))))
        .withValues(alpha: effectiveOpacity);

    return RepaintBoundary(
      child: Stack(
        fit: StackFit.expand,
        children: [
          // 1. Solid Base Surface Canvas
          ColoredBox(color: effectiveBase),

          // 2. Organically Scattered Academic Doodle Pattern (Cached raster on GPU)
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(
                painter: _ScatteredAcademicDoodlePainter(
                  strokeColor: effectiveStrokeColor,
                  isM3: isM3,
                ),
              ),
            ),
          ),

          // 3. Subtle Optical Edge Vignette (Liquid Glass mode only to keep M3 crisp)
          if (!isM3)
            Positioned.fill(
              child: IgnorePointer(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: Alignment.center,
                      radius: 1.35,
                      colors: [
                        Colors.transparent,
                        effectiveBase.withValues(alpha: 0.10),
                        effectiveBase.withValues(alpha: 0.28),
                      ],
                      stops: const [0.0, 0.75, 1.0],
                    ),
                  ),
                ),
              ),
            ),

          ?child,
        ],
      ),
    );
  }
}

/// CustomPainter rendering an organically scattered, seamlessly repeating
/// wallpaper of academic doodles with varied scales, positions, and rotations.
class _ScatteredAcademicDoodlePainter extends CustomPainter {
  final Color strokeColor;
  final bool isM3;

  const _ScatteredAcademicDoodlePainter({
    required this.strokeColor,
    this.isM3 = false,
  });

  // Master tile dimensions (width & height in dp)
  static const double tileW = 380.0;
  static const double tileH = 380.0;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;

    final paint = Paint()
      ..color = strokeColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = isM3 ? 1.85 : 1.55
      ..isAntiAlias = true
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final fillPaint = Paint()
      ..color = strokeColor.withValues(alpha: strokeColor.a * 0.40)
      ..style = PaintingStyle.fill;

    // Tile across the entire viewport seamlessly
    for (double x = 0; x < size.width + tileW; x += tileW) {
      for (double y = 0; y < size.height + tileH; y += tileH) {
        canvas.save();
        canvas.translate(x, y);
        _drawScatteredTile(canvas, paint, fillPaint);
        canvas.restore();
      }
    }
  }

  /// Renders an organically scattered cluster of 28 distinct academic items
  /// with varied rotations, scales, and non-linear coordinates.
  void _drawScatteredTile(Canvas canvas, Paint stroke, Paint fill) {
    // ----------------------------------------------------
    // Zone 1: Upper Quadrant (Scattered, non-linear)
    // ----------------------------------------------------
    _drawGradCap(canvas, stroke, const Offset(55, 48), 26, -0.24);
    _drawSparkle(canvas, stroke, const Offset(122, 28), 11, 0.35);
    _drawAtom(canvas, stroke, const Offset(178, 56), 25, 0.38);
    _drawMathPi(canvas, stroke, const Offset(238, 30), 14, -0.18);
    _drawCoffeeMug(canvas, stroke, const Offset(312, 58), 23, -0.16);
    _drawTinyPlus(canvas, stroke, const Offset(365, 35), 7);
    _drawPaperclip(canvas, stroke, const Offset(28, 92), 16, 0.75);

    // ----------------------------------------------------
    // Zone 2: Upper-Middle Quadrant
    // ----------------------------------------------------
    _drawPaperAirplane(canvas, stroke, const Offset(105, 108), 18, -0.42);
    _drawFlask(canvas, stroke, const Offset(164, 138), 24, -0.26);
    _drawTinyStar(canvas, stroke, const Offset(222, 102), 11, 0.25);
    _drawCompass(canvas, stroke, const Offset(272, 128), 24, 0.30);
    _drawMathSigma(canvas, stroke, const Offset(345, 115), 14, -0.12);
    _drawOpenBook(canvas, stroke, const Offset(48, 155), 25, 0.22);
    _drawTinyPlus(canvas, stroke, const Offset(118, 168), 7);

    // ----------------------------------------------------
    // Zone 3: Center & Lower-Middle Quadrant
    // ----------------------------------------------------
    _drawMicroscope(canvas, stroke, const Offset(95, 218), 27, -0.15);
    _drawIdeaLightBulb(canvas, stroke, const Offset(198, 205), 25, 0.28);
    _drawProtractor(canvas, stroke, const Offset(148, 252), 19, -0.22);
    _drawBackpack(canvas, stroke, const Offset(322, 202), 26, -0.20);
    _drawMathSqrt(canvas, stroke, const Offset(262, 216), 14, 0.16);
    _drawTinyStar(canvas, stroke, const Offset(362, 252), 11, -0.30);

    // ----------------------------------------------------
    // Zone 4: Lower Quadrant
    // ----------------------------------------------------
    _drawDiploma(canvas, stroke, const Offset(44, 292), 23, -0.45);
    _drawSparkle(canvas, stroke, const Offset(108, 312), 11, 0.40);
    _drawLaptop(canvas, stroke, const Offset(172, 298), 25, 0.16);
    _drawPaperAirplane(canvas, stroke, const Offset(245, 282), 17, 0.54);
    _drawLectureClock(canvas, stroke, const Offset(305, 295), 24, -0.22);
    _drawMathPercent(canvas, stroke, const Offset(32, 355), 13, -0.18);
    _drawTinyPlus(canvas, stroke, const Offset(362, 335), 7);

    // ----------------------------------------------------
    // Zone 5: Bottom Baseline (Offset & interleaved)
    // ----------------------------------------------------
    _drawPencilRuler(canvas, stroke, const Offset(92, 356), 24, 0.42);
    _drawDnaHelix(canvas, stroke, const Offset(152, 358), 24, -0.32);
    _drawCalculator(canvas, stroke, const Offset(224, 352), 22, -0.15);
    _drawReadingGlasses(canvas, stroke, const Offset(324, 350), 24, 0.20);
    _drawSparkle(canvas, stroke, const Offset(278, 362), 10, -0.25);
  }

  // ===========================================================================
  // Hand-Crafted Vector Doodles with Dynamic Rotations
  // ===========================================================================

  // 1. Graduation Mortarboard Cap
  void _drawGradCap(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    final capPath = Path()
      ..moveTo(0, -s * 0.55)
      ..lineTo(s * 0.95, -s * 0.1)
      ..lineTo(0, s * 0.35)
      ..lineTo(-s * 0.95, -s * 0.1)
      ..close();
    canvas.drawPath(capPath, paint);

    final skullPath = Path()
      ..moveTo(-s * 0.55, 0.0)
      ..cubicTo(-s * 0.55, s * 0.7, s * 0.55, s * 0.7, s * 0.55, 0.0);
    canvas.drawPath(skullPath, paint);

    final tasselPath = Path()
      ..moveTo(0, -s * 0.1)
      ..lineTo(s * 0.85, s * 0.45)
      ..lineTo(s * 0.85, s * 0.75);
    canvas.drawPath(tasselPath, paint);
    canvas.restore();
  }

  // 2. Open Textbook
  void _drawOpenBook(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    final path = Path()
      ..moveTo(0, -s * 0.3)
      ..cubicTo(-s * 0.4, -s * 0.7, -s * 0.9, -s * 0.4, -s * 0.9, s * 0.4)
      ..cubicTo(-s * 0.5, s * 0.2, -s * 0.2, s * 0.5, 0, s * 0.6)
      ..cubicTo(s * 0.2, s * 0.5, s * 0.5, s * 0.2, s * 0.9, s * 0.4)
      ..cubicTo(s * 0.9, -s * 0.4, s * 0.4, -s * 0.7, 0, -s * 0.3)
      ..close();
    canvas.drawPath(path, paint);

    canvas.drawLine(Offset(0, -s * 0.3), Offset(0, s * 0.6), paint);
    canvas.drawLine(Offset(-s * 0.65, -s * 0.05), Offset(-s * 0.2, 0), paint);
    canvas.drawLine(Offset(-s * 0.65, s * 0.2), Offset(-s * 0.2, s * 0.25), paint);
    canvas.drawLine(Offset(s * 0.2, 0), Offset(s * 0.65, -s * 0.05), paint);
    canvas.drawLine(Offset(s * 0.2, s * 0.25), Offset(s * 0.65, s * 0.2), paint);
    canvas.restore();
  }

  // 3. Laboratory Microscope
  void _drawMicroscope(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    canvas.drawLine(Offset(-s * 0.35, -s * 0.8), Offset(s * 0.1, -s * 0.15), paint);
    canvas.drawLine(Offset(s * 0.05, -s * 0.22), Offset(s * 0.25, 0.0), paint);
    canvas.drawLine(Offset(-s * 0.15, s * 0.15), Offset(s * 0.55, s * 0.15), paint);

    final armPath = Path()
      ..moveTo(0, -s * 0.35)
      ..cubicTo(-s * 0.7, -s * 0.1, -s * 0.6, s * 0.5, -s * 0.1, s * 0.65)
      ..lineTo(0.0, s * 0.75);
    canvas.drawPath(armPath, paint);
    canvas.drawLine(Offset(-s * 0.75, s * 0.75), Offset(s * 0.65, s * 0.75), paint);
    canvas.restore();
  }

  // 4. Atom Model
  void _drawAtom(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    canvas.drawCircle(Offset.zero, 2.0, paint);

    canvas.save();
    canvas.rotate(math.pi / 4);
    canvas.drawOval(
      Rect.fromCenter(center: Offset.zero, width: s * 1.8, height: s * 0.65),
      paint,
    );
    canvas.restore();

    canvas.save();
    canvas.rotate(-math.pi / 4);
    canvas.drawOval(
      Rect.fromCenter(center: Offset.zero, width: s * 1.8, height: s * 0.65),
      paint,
    );
    canvas.restore();
    canvas.restore();
  }

  // 5. Conical Erlenmeyer Flask
  void _drawFlask(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    final path = Path()
      ..moveTo(-s * 0.25, -s * 0.8)
      ..lineTo(s * 0.25, -s * 0.8)
      ..moveTo(-s * 0.2, -s * 0.8)
      ..lineTo(-s * 0.2, -s * 0.3)
      ..lineTo(-s * 0.8, s * 0.7)
      ..cubicTo(-s * 0.8, s * 0.85, -s * 0.65, s * 0.85, -s * 0.5, s * 0.85)
      ..lineTo(s * 0.5, s * 0.85)
      ..cubicTo(s * 0.65, s * 0.85, s * 0.8, s * 0.85, s * 0.8, s * 0.7)
      ..lineTo(s * 0.2, -s * 0.3)
      ..lineTo(s * 0.2, -s * 0.8);
    canvas.drawPath(path, paint);

    canvas.drawLine(Offset(-s * 0.55, s * 0.35), Offset(s * 0.55, s * 0.35), paint);
    canvas.drawCircle(Offset(-s * 0.2, s * 0.55), 1.2, paint);
    canvas.drawCircle(Offset(s * 0.15, s * 0.6), 1.5, paint);
    canvas.restore();
  }

  // 6. Student Backpack
  void _drawBackpack(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    final bodyRect = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(0, s * 0.1), width: s * 1.3, height: s * 1.5),
      const Radius.circular(8.0),
    );
    canvas.drawRRect(bodyRect, paint);

    final pouchRect = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(0, s * 0.38), width: s * 0.95, height: s * 0.7),
      const Radius.circular(4.0),
    );
    canvas.drawRRect(pouchRect, paint);

    final handlePath = Path()
      ..moveTo(-s * 0.3, -s * 0.65)
      ..cubicTo(-s * 0.3, -s * 0.95, s * 0.3, -s * 0.95, s * 0.3, -s * 0.65);
    canvas.drawPath(handlePath, paint);
    canvas.restore();
  }

  // 7. Drafting Compass
  void _drawCompass(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    canvas.drawCircle(Offset(0, -s * 0.65), 2.2, paint);
    canvas.drawLine(Offset(0, -s * 0.55), Offset(-s * 0.6, s * 0.75), paint);
    canvas.drawLine(Offset(0, -s * 0.55), Offset(s * 0.6, s * 0.75), paint);

    final arcPath = Path()
      ..moveTo(-s * 0.35, s * 0.15)
      ..cubicTo(-s * 0.1, s * 0.25, s * 0.1, s * 0.25, s * 0.35, s * 0.15);
    canvas.drawPath(arcPath, paint);
    canvas.restore();
  }

  // 8. Diploma Scroll with Ribbon
  void _drawDiploma(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    final rect = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset.zero, width: s * 1.5, height: s * 0.55),
      const Radius.circular(3.0),
    );
    canvas.drawRRect(rect, paint);

    canvas.drawLine(Offset(-s * 0.1, -s * 0.27), Offset(-s * 0.1, s * 0.27), paint);
    canvas.drawLine(Offset(s * 0.1, -s * 0.27), Offset(s * 0.1, s * 0.27), paint);

    final tailPath = Path()
      ..moveTo(0, s * 0.27)
      ..lineTo(-s * 0.2, s * 0.7)
      ..moveTo(0, s * 0.27)
      ..lineTo(s * 0.15, s * 0.75);
    canvas.drawPath(tailPath, paint);
    canvas.restore();
  }

  // 9. Laptop
  void _drawLaptop(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    final screen = RRect.fromRectAndRadius(
      Rect.fromLTWH(-s * 0.65, -s * 0.65, s * 1.3, s * 0.9),
      const Radius.circular(3.0),
    );
    canvas.drawRRect(screen, paint);

    final basePath = Path()
      ..moveTo(-s * 0.9, s * 0.4)
      ..lineTo(s * 0.9, s * 0.4)
      ..lineTo(s * 0.75, s * 0.6)
      ..lineTo(-s * 0.75, s * 0.6)
      ..close();
    canvas.drawPath(basePath, paint);
    canvas.restore();
  }

  // 10. Idea Lightbulb
  void _drawIdeaLightBulb(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    final bulbPath = Path()
      ..moveTo(-s * 0.25, s * 0.3)
      ..cubicTo(-s * 0.8, s * 0.1, -s * 0.7, -s * 0.8, 0, -s * 0.8)
      ..cubicTo(s * 0.7, -s * 0.8, s * 0.8, s * 0.1, s * 0.25, s * 0.3)
      ..lineTo(s * 0.25, s * 0.55)
      ..lineTo(-s * 0.25, s * 0.55)
      ..close();
    canvas.drawPath(bulbPath, paint);

    canvas.drawLine(Offset(-s * 0.2, s * 0.65), Offset(s * 0.2, s * 0.65), paint);
    canvas.drawLine(Offset(-s * 0.12, s * 0.77), Offset(s * 0.12, s * 0.77), paint);
    canvas.restore();
  }

  // 11. Pencil & Ruler
  void _drawPencilRuler(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    final triRuler = Path()
      ..moveTo(-s * 0.75, s * 0.7)
      ..lineTo(-s * 0.75, -s * 0.6)
      ..lineTo(s * 0.55, s * 0.7)
      ..close();
    canvas.drawPath(triRuler, paint);

    final innerTri = Path()
      ..moveTo(-s * 0.55, s * 0.52)
      ..lineTo(-s * 0.55, -s * 0.15)
      ..lineTo(s * 0.15, s * 0.52)
      ..close();
    canvas.drawPath(innerTri, paint);

    canvas.save();
    canvas.rotate(math.pi / 4);
    final pencilPath = Path()
      ..moveTo(-s * 0.12, -s * 0.75)
      ..lineTo(s * 0.12, -s * 0.75)
      ..lineTo(s * 0.12, s * 0.45)
      ..lineTo(0, s * 0.75)
      ..lineTo(-s * 0.12, s * 0.45)
      ..close();
    canvas.drawPath(pencilPath, paint);
    canvas.restore();
    canvas.restore();
  }

  // 12. Coffee Study Mug
  void _drawCoffeeMug(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    final mugRect = RRect.fromRectAndCorners(
      Rect.fromLTWH(-s * 0.55, -s * 0.25, s * 0.85, s * 0.95),
      bottomLeft: const Radius.circular(6.0),
      bottomRight: const Radius.circular(6.0),
    );
    canvas.drawRRect(mugRect, paint);

    final handlePath = Path()
      ..moveTo(s * 0.3, -s * 0.05)
      ..cubicTo(s * 0.75, -s * 0.05, s * 0.75, s * 0.5, s * 0.3, s * 0.5);
    canvas.drawPath(handlePath, paint);

    final steam1 = Path()
      ..moveTo(-s * 0.35, -s * 0.4)
      ..cubicTo(-s * 0.25, -s * 0.6, -s * 0.45, -s * 0.75, -s * 0.35, -s * 0.95);
    canvas.drawPath(steam1, paint);
    canvas.restore();
  }

  // 13. Alarm / Lecture Clock
  void _drawLectureClock(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    canvas.drawCircle(Offset(0, s * 0.1), s * 0.65, paint);
    canvas.drawLine(Offset(0, s * 0.1), Offset(0, -s * 0.25), paint);
    canvas.drawLine(Offset(0, s * 0.1), Offset(s * 0.25, s * 0.1), paint);

    canvas.drawArc(
      Rect.fromCircle(center: Offset(-s * 0.48, -s * 0.38), radius: s * 0.22),
      math.pi * 0.8,
      math.pi * 1.2,
      false,
      paint,
    );
    canvas.drawArc(
      Rect.fromCircle(center: Offset(s * 0.48, -s * 0.38), radius: s * 0.22),
      -math.pi * 0.2,
      math.pi * 1.2,
      false,
      paint,
    );

    canvas.drawLine(Offset(-s * 0.45, s * 0.65), Offset(-s * 0.6, s * 0.85), paint);
    canvas.drawLine(Offset(s * 0.45, s * 0.65), Offset(s * 0.6, s * 0.85), paint);
    canvas.restore();
  }

  // 14. DNA Double Helix
  void _drawDnaHelix(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    final p1 = Path()
      ..moveTo(-s * 0.3, -s * 0.8)
      ..cubicTo(s * 0.4, -s * 0.4, -s * 0.4, 0.0, s * 0.3, s * 0.4)
      ..cubicTo(-s * 0.4, s * 0.6, s * 0.2, s * 0.8, -s * 0.3, s * 0.9);
    canvas.drawPath(p1, paint);

    final p2 = Path()
      ..moveTo(s * 0.3, -s * 0.8)
      ..cubicTo(-s * 0.4, -s * 0.4, s * 0.4, 0.0, -s * 0.3, s * 0.4)
      ..cubicTo(s * 0.4, s * 0.6, -s * 0.2, s * 0.8, s * 0.3, s * 0.9);
    canvas.drawPath(p2, paint);

    canvas.drawLine(Offset(-s * 0.2, -s * 0.4), Offset(s * 0.2, -s * 0.4), paint);
    canvas.drawLine(Offset(-s * 0.2, 0.0), Offset(s * 0.2, 0.0), paint);
    canvas.drawLine(Offset(-s * 0.2, 0.4 * s), Offset(s * 0.2, 0.4 * s), paint);
    canvas.restore();
  }

  // 15. Calculator
  void _drawCalculator(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    final calcRect = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset.zero, width: s * 1.15, height: s * 1.55),
      const Radius.circular(5.0),
    );
    canvas.drawRRect(calcRect, paint);

    final screenRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(-s * 0.45, -s * 0.62, s * 0.9, s * 0.32),
      const Radius.circular(2.0),
    );
    canvas.drawRRect(screenRect, paint);

    for (int col = 0; col < 2; col++) {
      for (int row = 0; row < 3; row++) {
        final bx = -s * 0.3 + col * (s * 0.6);
        final by = -s * 0.12 + row * (s * 0.28);
        canvas.drawCircle(Offset(bx, by), 1.8, paint);
      }
    }
    canvas.restore();
  }

  // 16. Reading Glasses
  void _drawReadingGlasses(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(-s * 0.45, 0), width: s * 0.7, height: s * 0.6),
        const Radius.circular(5.0),
      ),
      paint,
    );

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(s * 0.45, 0), width: s * 0.7, height: s * 0.6),
        const Radius.circular(5.0),
      ),
      paint,
    );

    final bridge = Path()
      ..moveTo(-s * 0.1, -s * 0.05)
      ..cubicTo(-s * 0.05, -s * 0.2, s * 0.05, -s * 0.2, s * 0.1, -s * 0.05);
    canvas.drawPath(bridge, paint);

    canvas.drawLine(Offset(-s * 0.8, -s * 0.1), Offset(-s * 0.95, -s * 0.35), paint);
    canvas.drawLine(Offset(s * 0.8, -s * 0.1), Offset(s * 0.95, -s * 0.35), paint);
    canvas.restore();
  }

  // 17. Paper Airplane (The quintessential student doodle!)
  void _drawPaperAirplane(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    final planePath = Path()
      // Nose
      ..moveTo(0, -s * 0.9)
      // Right wing tip
      ..lineTo(s * 0.85, s * 0.85)
      // Center fold
      ..lineTo(0, s * 0.4)
      // Left wing tip
      ..lineTo(-s * 0.85, s * 0.85)
      ..close();
    canvas.drawPath(planePath, paint);

    // Spine crease
    canvas.drawLine(Offset(0, -s * 0.9), Offset(0, s * 0.85), paint);
    canvas.restore();
  }

  // 18. Paperclip
  void _drawPaperclip(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    final clipPath = Path()
      ..moveTo(-s * 0.25, s * 0.4)
      ..lineTo(-s * 0.25, -s * 0.5)
      ..arcToPoint(Offset(s * 0.25, -s * 0.5), radius: Radius.circular(s * 0.25))
      ..lineTo(s * 0.25, s * 0.6)
      ..arcToPoint(Offset(-s * 0.45, s * 0.6), radius: Radius.circular(s * 0.35))
      ..lineTo(-s * 0.45, -s * 0.65)
      ..arcToPoint(Offset(s * 0.45, -s * 0.65), radius: Radius.circular(s * 0.45))
      ..lineTo(s * 0.45, s * 0.4);
    canvas.drawPath(clipPath, paint);
    canvas.restore();
  }

  // 19. Geometry Protractor
  void _drawProtractor(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    // Semicircular outer arc
    canvas.drawArc(
      Rect.fromCircle(center: Offset(0, s * 0.25), radius: s * 0.75),
      math.pi,
      math.pi,
      false,
      paint,
    );
    // Baseline
    canvas.drawLine(Offset(-s * 0.75, s * 0.25), Offset(s * 0.75, s * 0.25), paint);

    // Inner window cutout
    canvas.drawArc(
      Rect.fromCircle(center: Offset(0, s * 0.25), radius: s * 0.38),
      math.pi,
      math.pi,
      false,
      paint,
    );
    canvas.drawLine(Offset(-s * 0.38, s * 0.25), Offset(s * 0.38, s * 0.25), paint);
    canvas.restore();
  }

  // 20. Sparkle (4-point sparkle star)
  void _drawSparkle(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    final sparkle = Path()
      ..moveTo(0, -s)
      ..cubicTo(s * 0.1, -s * 0.1, s * 0.1, -s * 0.1, s, 0)
      ..cubicTo(s * 0.1, s * 0.1, s * 0.1, s * 0.1, 0, s)
      ..cubicTo(-s * 0.1, s * 0.1, -s * 0.1, s * 0.1, -s, 0)
      ..cubicTo(-s * 0.1, -s * 0.1, -s * 0.1, -s * 0.1, 0, -s)
      ..close();
    canvas.drawPath(sparkle, paint);
    canvas.restore();
  }

  // 21. Tiny 5-point Star
  void _drawTinyStar(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final r = size * 0.5;
    final innerR = r * 0.42;

    final starPath = Path();
    for (int i = 0; i < 10; i++) {
      final rad = i.isEven ? r : innerR;
      final a = (i * math.pi / 5) - (math.pi / 2);
      final x = rad * math.cos(a);
      final y = rad * math.sin(a);
      if (i == 0) {
        starPath.moveTo(x, y);
      } else {
        starPath.lineTo(x, y);
      }
    }
    starPath.close();
    canvas.drawPath(starPath, paint);
    canvas.restore();
  }

  // 22. Math: Pi Symbol (π)
  void _drawMathPi(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    // Top horizontal bar with subtle serif
    canvas.drawLine(Offset(-s * 0.7, -s * 0.45), Offset(s * 0.7, -s * 0.45), paint);
    // Left stem
    canvas.drawLine(Offset(-s * 0.35, -s * 0.45), Offset(-s * 0.35, s * 0.55), paint);
    // Right stem with tail
    final rightStem = Path()
      ..moveTo(s * 0.35, -s * 0.45)
      ..lineTo(s * 0.35, s * 0.45)
      ..quadraticBezierTo(s * 0.4, s * 0.6, s * 0.65, s * 0.55);
    canvas.drawPath(rightStem, paint);
    canvas.restore();
  }

  // 23. Math: Sigma Summation (∑)
  void _drawMathSigma(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    final sigmaPath = Path()
      ..moveTo(s * 0.65, -s * 0.65)
      ..lineTo(-s * 0.5, -s * 0.65)
      ..lineTo(0.0, 0.0)
      ..lineTo(-s * 0.5, s * 0.65)
      ..lineTo(s * 0.65, s * 0.65);
    canvas.drawPath(sigmaPath, paint);
    canvas.restore();
  }

  // 24. Math: Square Root (√)
  void _drawMathSqrt(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    final sqrtPath = Path()
      ..moveTo(-s * 0.7, 0.0)
      ..lineTo(-s * 0.45, s * 0.1)
      ..lineTo(-s * 0.1, s * 0.65)
      ..lineTo(s * 0.25, -s * 0.65)
      ..lineTo(s * 0.75, -s * 0.65);
    canvas.drawPath(sqrtPath, paint);
    canvas.restore();
  }

  // 25. Math: Percentage (%)
  void _drawMathPercent(Canvas canvas, Paint paint, Offset center, double size, double angle) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (angle != 0) canvas.rotate(angle);
    final s = size * 0.5;

    canvas.drawLine(Offset(-s * 0.6, s * 0.6), Offset(s * 0.6, -s * 0.6), paint);
    canvas.drawCircle(Offset(-s * 0.35, -s * 0.35), 2.2, paint);
    canvas.drawCircle(Offset(s * 0.35, s * 0.35), 2.2, paint);
    canvas.restore();
  }

  // 26. Tiny plus (+) doodle
  void _drawTinyPlus(Canvas canvas, Paint paint, Offset center, double size) {
    final s = size * 0.5;
    canvas.drawLine(Offset(center.dx - s, center.dy), Offset(center.dx + s, center.dy), paint);
    canvas.drawLine(Offset(center.dx, center.dy - s), Offset(center.dx, center.dy + s), paint);
  }

  @override
  bool shouldRepaint(covariant _ScatteredAcademicDoodlePainter oldDelegate) =>
      strokeColor != oldDelegate.strokeColor || isM3 != oldDelegate.isM3;
}
