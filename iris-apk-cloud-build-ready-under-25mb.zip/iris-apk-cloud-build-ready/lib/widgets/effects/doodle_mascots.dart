import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Lightweight, GPU-cached vector doodle mascot painters.
/// 
/// Zero asset network dependency, zero image decoding overhead,
/// locked 120 FPS rasterization on Android devices.

// -----------------------------------------------------------------------------
// 1. Smiling Happy Calculator Mascot
// -----------------------------------------------------------------------------
class SmilingCalculatorMascot extends StatelessWidget {
  final double size;
  final bool isDark;

  const SmilingCalculatorMascot({super.key, this.size = 52.0, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _SmilingCalculatorPainter(isDark: isDark),
      ),
    );
  }
}

class _SmilingCalculatorPainter extends CustomPainter {
  final bool isDark;
  _SmilingCalculatorPainter({required this.isDark});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final strokeColor = isDark ? const Color(0xFFE2E8F0) : const Color(0xFF2C221A);

    final bodyPaint = Paint()
      ..color = isDark ? const Color(0xFF334155) : const Color(0xFFBAE6FD)
      ..style = PaintingStyle.fill;

    final strokePaint = Paint()
      ..color = strokeColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final screenPaint = Paint()
      ..color = isDark ? const Color(0xFF1E293B) : const Color(0xFFE0F2FE)
      ..style = PaintingStyle.fill;

    // Body squircle
    final bodyRRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(w * 0.12, h * 0.08, w * 0.76, h * 0.82),
      const Radius.circular(10),
    );
    canvas.drawRRect(bodyRRect, bodyPaint);
    canvas.drawRRect(bodyRRect, strokePaint);

    // Screen
    final screenRRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(w * 0.22, h * 0.18, w * 0.56, h * 0.22),
      const Radius.circular(5),
    );
    canvas.drawRRect(screenRRect, screenPaint);
    canvas.drawRRect(screenRRect, strokePaint);

    // Eyes in screen
    final eyePaint = Paint()..color = strokeColor..style = PaintingStyle.fill;
    canvas.drawCircle(Offset(w * 0.38, h * 0.28), 2.2, eyePaint);
    canvas.drawCircle(Offset(w * 0.62, h * 0.28), 2.2, eyePaint);

    // Smile in screen
    final smilePath = Path()
      ..moveTo(w * 0.44, h * 0.32)
      ..quadraticBezierTo(w * 0.50, h * 0.36, w * 0.56, h * 0.32);
    canvas.drawPath(smilePath, strokePaint);

    // Calculator buttons (3x2 grid)
    final btnPaint = Paint()
      ..color = isDark ? const Color(0xFF475569) : const Color(0xFFF8FAFC)
      ..style = PaintingStyle.fill;

    for (int row = 0; row < 2; row++) {
      for (int col = 0; col < 3; col++) {
        final bx = w * (0.24 + col * 0.18);
        final by = h * (0.48 + row * 0.18);
        final btnRRect = RRect.fromRectAndRadius(
          Rect.fromLTWH(bx, by, w * 0.14, h * 0.12),
          const Radius.circular(3),
        );
        canvas.drawRRect(btnRRect, btnPaint);
        canvas.drawRRect(btnRRect, strokePaint);
      }
    }

    // Little feet
    canvas.drawLine(Offset(w * 0.30, h * 0.90), Offset(w * 0.26, h * 0.98), strokePaint);
    canvas.drawLine(Offset(w * 0.70, h * 0.90), Offset(w * 0.74, h * 0.98), strokePaint);
  }

  @override
  bool shouldRepaint(covariant _SmilingCalculatorPainter oldDelegate) =>
      oldDelegate.isDark != isDark;
}

// -----------------------------------------------------------------------------
// 2. Cartoon Professors Mascot
// -----------------------------------------------------------------------------
class CartoonProfessorsMascot extends StatelessWidget {
  final double size;
  final bool isDark;

  const CartoonProfessorsMascot({super.key, this.size = 76.0, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size * 1.35,
      height: size,
      child: CustomPaint(
        painter: _CartoonProfessorsPainter(isDark: isDark),
      ),
    );
  }
}

class _CartoonProfessorsPainter extends CustomPainter {
  final bool isDark;
  _CartoonProfessorsPainter({required this.isDark});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final stroke = Paint()
      ..color = isDark ? const Color(0xFFE2E8F0) : const Color(0xFF2C221A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.55
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final skin = Paint()
      ..color = isDark ? const Color(0xFFD4A373) : const Color(0xFFFFDFC4)
      ..style = PaintingStyle.fill;

    final sweater = Paint()
      ..color = isDark ? const Color(0xFF334155) : const Color(0xFFD97706)
      ..style = PaintingStyle.fill;

    final suit = Paint()
      ..color = isDark ? const Color(0xFF1E293B) : const Color(0xFF0284C7)
      ..style = PaintingStyle.fill;

    // Left Professor (Elderly with sweater)
    final p1Head = Offset(w * 0.25, h * 0.40);
    canvas.drawCircle(p1Head, 13.5, skin);
    canvas.drawCircle(p1Head, 13.5, stroke);

    // Glasses
    canvas.drawCircle(Offset(p1Head.dx - 4.5, p1Head.dy - 1), 4.2, stroke);
    canvas.drawCircle(Offset(p1Head.dx + 4.5, p1Head.dy - 1), 4.2, stroke);
    canvas.drawLine(Offset(p1Head.dx - 0.3, p1Head.dy - 1), Offset(p1Head.dx + 0.3, p1Head.dy - 1), stroke);

    // Smile & Mustache
    final mPath = Path()
      ..moveTo(p1Head.dx - 5, p1Head.dy + 6)
      ..quadraticBezierTo(p1Head.dx, p1Head.dy + 4, p1Head.dx + 5, p1Head.dy + 6);
    canvas.drawPath(mPath, stroke);

    // Body sweater
    final p1Body = RRect.fromRectAndRadius(
      Rect.fromLTWH(w * 0.12, h * 0.60, w * 0.26, h * 0.38),
      const Radius.circular(8),
    );
    canvas.drawRRect(p1Body, sweater);
    canvas.drawRRect(p1Body, stroke);

    // Right Professor (With tie)
    final p2Head = Offset(w * 0.75, h * 0.42);
    canvas.drawCircle(p2Head, 13.5, skin);
    canvas.drawCircle(p2Head, 13.5, stroke);

    // Glasses
    canvas.drawCircle(Offset(p2Head.dx - 4.5, p2Head.dy - 1), 4.2, stroke);
    canvas.drawCircle(Offset(p2Head.dx + 4.5, p2Head.dy - 1), 4.2, stroke);
    canvas.drawLine(Offset(p2Head.dx - 0.3, p2Head.dy - 1), Offset(p2Head.dx + 0.3, p2Head.dy - 1), stroke);

    // Smile
    final smilePath = Path()
      ..moveTo(p2Head.dx - 4, p2Head.dy + 6)
      ..quadraticBezierTo(p2Head.dx, p2Head.dy + 9, p2Head.dx + 4, p2Head.dy + 6);
    canvas.drawPath(smilePath, stroke);

    // Suit
    final p2Body = RRect.fromRectAndRadius(
      Rect.fromLTWH(w * 0.62, h * 0.62, w * 0.26, h * 0.36),
      const Radius.circular(8),
    );
    canvas.drawRRect(p2Body, suit);
    canvas.drawRRect(p2Body, stroke);

    // Center Stacked Books
    final bookPaint = Paint()
      ..color = isDark ? const Color(0xFF475569) : const Color(0xFFF59E0B)
      ..style = PaintingStyle.fill;
    for (int i = 0; i < 3; i++) {
      final bRect = RRect.fromRectAndRadius(
        Rect.fromLTWH(w * 0.40, h * (0.64 + i * 0.11), w * 0.20, h * 0.09),
        const Radius.circular(3),
      );
      canvas.drawRRect(bRect, bookPaint);
      canvas.drawRRect(bRect, stroke);
    }
  }

  @override
  bool shouldRepaint(covariant _CartoonProfessorsPainter oldDelegate) =>
      oldDelegate.isDark != isDark;
}

// -----------------------------------------------------------------------------
// 3. Running Alarm Clock Mascot
// -----------------------------------------------------------------------------
class RunningAlarmClockMascot extends StatelessWidget {
  final double size;
  final bool isDark;

  const RunningAlarmClockMascot({super.key, this.size = 56.0, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _RunningAlarmClockPainter(isDark: isDark),
      ),
    );
  }
}

class _RunningAlarmClockPainter extends CustomPainter {
  final bool isDark;
  _RunningAlarmClockPainter({required this.isDark});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final stroke = Paint()
      ..color = isDark ? const Color(0xFFE2E8F0) : const Color(0xFF2C221A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final bodyFill = Paint()
      ..color = isDark ? const Color(0xFF334155) : const Color(0xFFFEF08A)
      ..style = PaintingStyle.fill;

    // Clock bell ears
    canvas.drawArc(
      Rect.fromCircle(center: Offset(w * 0.24, h * 0.22), radius: 8),
      math.pi * 0.9,
      math.pi * 1.2,
      false,
      stroke,
    );
    canvas.drawArc(
      Rect.fromCircle(center: Offset(w * 0.76, h * 0.22), radius: 8),
      math.pi * -0.1,
      math.pi * 1.2,
      false,
      stroke,
    );

    // Clock Face
    final center = Offset(w * 0.50, h * 0.52);
    canvas.drawCircle(center, w * 0.36, bodyFill);
    canvas.drawCircle(center, w * 0.36, stroke);

    // Clock Hands (shaking)
    canvas.drawLine(center, Offset(center.dx, center.dy - w * 0.22), stroke);
    canvas.drawLine(center, Offset(center.dx + w * 0.18, center.dy), stroke);

    // Sweat drops / vibration marks
    canvas.drawLine(Offset(w * 0.08, h * 0.40), Offset(w * 0.02, h * 0.38), stroke);
    canvas.drawLine(Offset(w * 0.08, h * 0.52), Offset(w * 0.02, h * 0.52), stroke);
    canvas.drawLine(Offset(w * 0.92, h * 0.40), Offset(w * 0.98, h * 0.38), stroke);
    canvas.drawLine(Offset(w * 0.92, h * 0.52), Offset(w * 0.98, h * 0.52), stroke);

    // Legs
    canvas.drawLine(Offset(w * 0.32, h * 0.86), Offset(w * 0.24, h * 0.98), stroke);
    canvas.drawLine(Offset(w * 0.68, h * 0.86), Offset(w * 0.76, h * 0.98), stroke);
  }

  @override
  bool shouldRepaint(covariant _RunningAlarmClockPainter oldDelegate) =>
      oldDelegate.isDark != isDark;
}

// -----------------------------------------------------------------------------
// 4. Sleeping Kitty in Coffee Cup Mascot
// -----------------------------------------------------------------------------
class SleepingKittyMascot extends StatelessWidget {
  final double size;
  final bool isDark;

  const SleepingKittyMascot({super.key, this.size = 56.0, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _SleepingKittyPainter(isDark: isDark),
      ),
    );
  }
}

class _SleepingKittyPainter extends CustomPainter {
  final bool isDark;
  _SleepingKittyPainter({required this.isDark});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final stroke = Paint()
      ..color = isDark ? const Color(0xFFE2E8F0) : const Color(0xFF2C221A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final cupFill = Paint()
      ..color = isDark ? const Color(0xFF334155) : const Color(0xFFFFEDD5)
      ..style = PaintingStyle.fill;

    final catFill = Paint()
      ..color = isDark ? const Color(0xFF475569) : const Color(0xFFF1F5F9)
      ..style = PaintingStyle.fill;

    // Cup Body
    final cupRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(w * 0.16, h * 0.44, w * 0.60, h * 0.50),
      const Radius.circular(12),
    );
    canvas.drawRRect(cupRect, cupFill);
    canvas.drawRRect(cupRect, stroke);

    // Cup Handle
    final handlePath = Path()
      ..moveTo(w * 0.76, h * 0.54)
      ..quadraticBezierTo(w * 0.96, h * 0.62, w * 0.76, h * 0.78);
    canvas.drawPath(handlePath, stroke);

    // Sleeping Cat Head peeking
    final catHead = Offset(w * 0.46, h * 0.38);
    canvas.drawCircle(catHead, 14, catFill);
    canvas.drawCircle(catHead, 14, stroke);

    // Cat Ears
    final leftEar = Path()
      ..moveTo(catHead.dx - 12, catHead.dy - 6)
      ..lineTo(catHead.dx - 14, catHead.dy - 17)
      ..lineTo(catHead.dx - 4, catHead.dy - 12);
    canvas.drawPath(leftEar, stroke);

    final rightEar = Path()
      ..moveTo(catHead.dx + 4, catHead.dy - 12)
      ..lineTo(catHead.dx + 14, catHead.dy - 17)
      ..lineTo(catHead.dx + 12, catHead.dy - 6);
    canvas.drawPath(rightEar, stroke);

    // Closed eyes (sleeping curves)
    final eye1 = Path()
      ..moveTo(catHead.dx - 8, catHead.dy - 1)
      ..quadraticBezierTo(catHead.dx - 5, catHead.dy + 2, catHead.dx - 2, catHead.dy - 1);
    canvas.drawPath(eye1, stroke);

    final eye2 = Path()
      ..moveTo(catHead.dx + 2, catHead.dy - 1)
      ..quadraticBezierTo(catHead.dx + 5, catHead.dy + 2, catHead.dx + 8, catHead.dy - 1);
    canvas.drawPath(eye2, stroke);

    // Little nose
    canvas.drawCircle(Offset(catHead.dx, catHead.dy + 3), 1.5, stroke);

    // Whiskers
    canvas.drawLine(Offset(catHead.dx - 11, catHead.dy + 2), Offset(catHead.dx - 17, catHead.dy + 1), stroke);
    canvas.drawLine(Offset(catHead.dx + 11, catHead.dy + 2), Offset(catHead.dx + 17, catHead.dy + 1), stroke);
  }

  @override
  bool shouldRepaint(covariant _SleepingKittyPainter oldDelegate) =>
      oldDelegate.isDark != isDark;
}

// -----------------------------------------------------------------------------
// 5. Student Writing with Giant Pencil Mascot
// -----------------------------------------------------------------------------
class StudentWritingMascot extends StatelessWidget {
  final double size;
  final bool isDark;

  const StudentWritingMascot({super.key, this.size = 64.0, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _StudentWritingPainter(isDark: isDark),
      ),
    );
  }
}

class _StudentWritingPainter extends CustomPainter {
  final bool isDark;
  _StudentWritingPainter({required this.isDark});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final stroke = Paint()
      ..color = isDark ? const Color(0xFFE2E8F0) : const Color(0xFF2C221A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final skin = Paint()
      ..color = isDark ? const Color(0xFFD4A373) : const Color(0xFFFFDFC4)
      ..style = PaintingStyle.fill;

    final clothes = Paint()
      ..color = isDark ? const Color(0xFF0284C7) : const Color(0xFF38BDF8)
      ..style = PaintingStyle.fill;

    // Stacked Books Platform
    final b1 = RRect.fromRectAndRadius(
      Rect.fromLTWH(w * 0.32, h * 0.74, w * 0.58, h * 0.12),
      const Radius.circular(4),
    );
    canvas.drawRRect(b1, clothes);
    canvas.drawRRect(b1, stroke);

    final b2 = RRect.fromRectAndRadius(
      Rect.fromLTWH(w * 0.38, h * 0.86, w * 0.52, h * 0.10),
      const Radius.circular(4),
    );
    canvas.drawRRect(b2, skin);
    canvas.drawRRect(b2, stroke);

    // Giant Diagonal Pencil
    canvas.save();
    canvas.translate(w * 0.40, h * 0.45);
    canvas.rotate(-0.62);

    final pencilBody = RRect.fromRectAndRadius(
      Rect.fromLTWH(-w * 0.10, -h * 0.36, w * 0.20, h * 0.65),
      const Radius.circular(3),
    );
    final pencilPaint = Paint()
      ..color = isDark ? const Color(0xFFD97706) : const Color(0xFFFBBF24)
      ..style = PaintingStyle.fill;
    canvas.drawRRect(pencilBody, pencilPaint);
    canvas.drawRRect(pencilBody, stroke);

    // Eraser on top
    final eraser = Paint()
      ..color = const Color(0xFFFB7185)
      ..style = PaintingStyle.fill;
    final eraserRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(-w * 0.10, -h * 0.44, w * 0.20, h * 0.08),
      const Radius.circular(3),
    );
    canvas.drawRRect(eraserRect, eraser);
    canvas.drawRRect(eraserRect, stroke);

    // Tip
    final tipPath = Path()
      ..moveTo(-w * 0.10, h * 0.29)
      ..lineTo(0, h * 0.42)
      ..lineTo(w * 0.10, h * 0.29)
      ..close();
    canvas.drawPath(tipPath, skin);
    canvas.drawPath(tipPath, stroke);
    canvas.restore();

    // Student sitting on book
    final head = Offset(w * 0.65, h * 0.36);
    canvas.drawCircle(head, 10, skin);
    canvas.drawCircle(head, 10, stroke);

    // Smile
    final smile = Path()
      ..moveTo(head.dx - 3, head.dy + 2)
      ..quadraticBezierTo(head.dx, head.dy + 5, head.dx + 3, head.dy + 2);
    canvas.drawPath(smile, stroke);
  }

  @override
  bool shouldRepaint(covariant _StudentWritingPainter oldDelegate) =>
      oldDelegate.isDark != isDark;
}

// -----------------------------------------------------------------------------
// 6. Isometric Campus Buildings Mascot
// -----------------------------------------------------------------------------
class CampusIsometricMascot extends StatelessWidget {
  final double size;
  final bool isDark;

  const CampusIsometricMascot({super.key, this.size = 110.0, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size * 1.35,
      height: size,
      child: CustomPaint(
        painter: _CampusIsometricPainter(isDark: isDark),
      ),
    );
  }
}

class _CampusIsometricPainter extends CustomPainter {
  final bool isDark;
  _CampusIsometricPainter({required this.isDark});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final stroke = Paint()
      ..color = isDark ? const Color(0xFFE2E8F0) : const Color(0xFF2C221A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final roofPaint = Paint()
      ..color = isDark ? const Color(0xFF991B1B) : const Color(0xFFE11D48)
      ..style = PaintingStyle.fill;

    final wallPaint = Paint()
      ..color = isDark ? const Color(0xFF334155) : const Color(0xFFFED7AA)
      ..style = PaintingStyle.fill;

    final treePaint = Paint()
      ..color = isDark ? const Color(0xFF166534) : const Color(0xFF22C55E)
      ..style = PaintingStyle.fill;

    // Building 1 (Center Left)
    final b1Wall = RRect.fromRectAndRadius(
      Rect.fromLTWH(w * 0.15, h * 0.40, w * 0.36, h * 0.45),
      const Radius.circular(4),
    );
    canvas.drawRRect(b1Wall, wallPaint);
    canvas.drawRRect(b1Wall, stroke);

    // Roof
    final r1 = Path()
      ..moveTo(w * 0.12, h * 0.40)
      ..lineTo(w * 0.33, h * 0.22)
      ..lineTo(w * 0.54, h * 0.40)
      ..close();
    canvas.drawPath(r1, roofPaint);
    canvas.drawPath(r1, stroke);

    // Windows
    for (int r = 0; r < 2; r++) {
      for (int c = 0; c < 2; c++) {
        final win = Rect.fromLTWH(w * (0.22 + c * 0.14), h * (0.48 + r * 0.16), w * 0.08, h * 0.09);
        canvas.drawRect(win, stroke);
      }
    }

    // Building 2 (Right Wing)
    final b2Wall = RRect.fromRectAndRadius(
      Rect.fromLTWH(w * 0.56, h * 0.48, w * 0.34, h * 0.40),
      const Radius.circular(4),
    );
    canvas.drawRRect(b2Wall, wallPaint);
    canvas.drawRRect(b2Wall, stroke);

    // Flat roof with parapet
    final r2 = Path()
      ..moveTo(w * 0.54, h * 0.48)
      ..lineTo(w * 0.73, h * 0.34)
      ..lineTo(w * 0.92, h * 0.48)
      ..close();
    canvas.drawPath(r2, roofPaint);
    canvas.drawPath(r2, stroke);

    // Trees
    canvas.drawCircle(Offset(w * 0.10, h * 0.72), 9, treePaint);
    canvas.drawCircle(Offset(w * 0.10, h * 0.72), 9, stroke);
    canvas.drawCircle(Offset(w * 0.52, h * 0.82), 8, treePaint);
    canvas.drawCircle(Offset(w * 0.52, h * 0.82), 8, stroke);
  }

  @override
  bool shouldRepaint(covariant _CampusIsometricPainter oldDelegate) =>
      oldDelegate.isDark != isDark;
}
