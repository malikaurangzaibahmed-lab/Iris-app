import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import '../../core/laminar_flow.dart';
import '../../core/tokens.dart';
import '../../core/theme_signals.dart';
import '../../core/glass.dart';
import '../../core/material_you_theme.dart';
import '../../services/ui_feedback.dart';

/// ============================================================================
/// 🫧 FLUID SQUIRCLE BORDER (ColorOS 17 G² Continuous Curvature)
/// ============================================================================
///
/// Traditional [RoundedRectangleBorder] uses circular arcs (G¹ continuity),
/// causing an abrupt curvature jump from 0 (straight line) to 1/r (arc).
/// [FluidSquircleBorder] constructs a true G² continuous super-ellipse boundary
/// with smooth, progressive curvature ramp-up (clothoid / super-ellipse profile),
/// eliminating all visual corner seams.
class FluidSquircleBorder extends OutlinedBorder {
  final double cornerRadius;
  final double smoothness; // 0.0 (circle) to 1.0 (ColorOS/iOS true squircle)

  const FluidSquircleBorder({
    this.cornerRadius = 24.0,
    this.smoothness = 0.82,
    super.side = BorderSide.none,
  });

  @override
  OutlinedBorder copyWith({BorderSide? side}) {
    return FluidSquircleBorder(
      cornerRadius: cornerRadius,
      smoothness: smoothness,
      side: side ?? this.side,
    );
  }

  @override
  ShapeBorder scale(double t) {
    return FluidSquircleBorder(
      cornerRadius: cornerRadius * t,
      smoothness: smoothness,
      side: side.scale(t),
    );
  }

  // High-performance static path cache to eliminate GC churn during 60-120 FPS animations
  static final Map<int, Path> _pathCache = {};
  static const int _maxCacheEntries = 128;

  @override
  Path getInnerPath(Rect rect, {TextDirection? textDirection}) {
    final innerRect = rect.deflate(side.width);
    return _getCachedSquirclePath(innerRect, math.max(0, cornerRadius - side.width));
  }

  @override
  Path getOuterPath(Rect rect, {TextDirection? textDirection}) {
    return _getCachedSquirclePath(rect, cornerRadius);
  }

  Path _getCachedSquirclePath(Rect rect, double r) {
    if (r <= 0.0) {
      return Path()..addRect(rect);
    }

    final key = Object.hash(
      rect.left.round(),
      rect.top.round(),
      rect.width.round(),
      rect.height.round(),
      r.round(),
      (smoothness * 100).round(),
    );

    final cached = _pathCache[key];
    if (cached != null) return cached;

    if (_pathCache.length >= _maxCacheEntries) {
      _pathCache.clear();
    }

    final path = _computeSquirclePath(rect, r);
    _pathCache[key] = path;
    return path;
  }

  Path _computeSquirclePath(Rect rect, double r) {
    final path = Path();
    if (rect.width <= 0.0 || rect.height <= 0.0) {
      return path;
    }
    final double maxR = math.min(rect.width, rect.height) / 2.0;
    if (r <= 0.0 || maxR <= 0.0) {
      return path..addRect(rect);
    }
    final double radius = math.min(r, maxR);
    final double s = smoothness.clamp(0.0, 1.0);

    // Super-ellipse blend parameters
    // Strict clamp ensures transition length l never exceeds maxR (half of rect width/height).
    // This mathematically guarantees control points never cross over or pinch into inverted star/concave shapes.
    final double l = math.min(radius * (1.0 + s * 0.20), maxR);
    final double c = l * (1.0 - (0.55228475 - s * 0.06)).clamp(0.0, 1.0);

    final left = rect.left;
    final top = rect.top;
    final right = rect.right;
    final bottom = rect.bottom;

    path.moveTo(left + l, top);

    // Top edge & Top-Right Corner
    if (right - l > left + l) {
      path.lineTo(right - l, top);
    }
    path.cubicTo(
      right - c, top,
      right, top + c,
      right, top + l,
    );

    // Right edge & Bottom-Right Corner
    if (bottom - l > top + l) {
      path.lineTo(right, bottom - l);
    }
    path.cubicTo(
      right, bottom - c,
      right - c, bottom,
      right - l, bottom,
    );

    // Bottom edge & Bottom-Left Corner
    if (right - l > left + l) {
      path.lineTo(left + l, bottom);
    }
    path.cubicTo(
      left + c, bottom,
      left, bottom - c,
      left, bottom - l,
    );

    // Left edge & Top-Left Corner
    if (bottom - l > top + l) {
      path.lineTo(left, top + l);
    }
    path.cubicTo(
      left, top + c,
      left + c, top,
      left + l, top,
    );

    path.close();
    return path;
  }

  @override
  void paint(Canvas canvas, Rect rect, {TextDirection? textDirection}) {
    if (side == BorderSide.none || side.width <= 0.0) return;
    final paint = side.toPaint();
    final path = getOuterPath(rect, textDirection: textDirection);
    canvas.drawPath(path, paint);
  }
}

/// ============================================================================
/// 🌊 VISCOELASTIC FLUID CONTAINER (Volume-Conserving Elastic Deformation)
/// ============================================================================
///
/// In ColorOS 17's fluid rendering, interactive surfaces behave like viscous
/// liquid. When pressed, flung, or bounced, the container stretches along the
/// primary axis and contracts transversally (Poisson ratio ν ≈ 0.45),
/// returning to baseline with high-inertia damped spring oscillation.
class FluidViscoelasticContainer extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final double cornerRadius;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final Color? backgroundColor;
  final Color? borderColor;
  final bool enableHaptics;

  const FluidViscoelasticContainer({
    super.key,
    required this.child,
    this.onTap,
    this.onLongPress,
    this.cornerRadius = 24.0,
    this.padding,
    this.margin,
    this.backgroundColor,
    this.borderColor,
    this.enableHaptics = true,
  });

  @override
  State<FluidViscoelasticContainer> createState() => _FluidViscoelasticContainerState();
}

class _FluidViscoelasticContainerState extends State<FluidViscoelasticContainer>
    with SingleTickerProviderStateMixin {
  late final LaminarParallelController _deformationController;

  @override
  void initState() {
    super.initState();
    _deformationController = LaminarParallelController(
      vsync: this,
      initialValue: 0.0,
      springConfig: LaminarSpringConfig.responsive,
    );
  }

  @override
  void dispose() {
    _deformationController.dispose();
    super.dispose();
  }

  void _handleTapDown(TapDownDetails details) {
    if (widget.enableHaptics) IrisHaptics.actionSoft();
    // Compress with initial velocity
    _deformationController.animateTo(1.0, initialVelocity: 4.0);
  }

  void _handleTapUp(TapUpDetails details) {
    // Release smoothly with velocity handoff
    _deformationController.animateTo(0.0, initialVelocity: -6.0);
    widget.onTap?.call();
  }

  void _handleTapCancel() {
    _deformationController.animateTo(0.0);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;

    final defaultBg = isM3
        ? MaterialYouTokens.surfaceContainer(
            isDark ? Brightness.dark : Brightness.light)
        : (isDark
            ? IrisTokens.surfaceDarkElevated.withValues(alpha: 0.85)
            : Colors.white.withValues(alpha: 0.90));

    final effectiveBg = widget.backgroundColor ?? defaultBg;
    final effectiveBorder = widget.borderColor ??
        (isDark
            ? Colors.white.withValues(alpha: 0.12)
            : Colors.black.withValues(alpha: 0.08));

    return Padding(
      padding: widget.margin ?? EdgeInsets.zero,
      child: GestureDetector(
        onTapDown: _handleTapDown,
        onTapUp: _handleTapUp,
        onTapCancel: _handleTapCancel,
        onLongPress: widget.onLongPress != null
            ? () {
                if (widget.enableHaptics) IrisHaptics.actionHeavy();
                widget.onLongPress!();
              }
            : null,
        behavior: HitTestBehavior.opaque,
        child: AnimatedBuilder(
          animation: _deformationController,
          builder: (context, child) {
            final t = _deformationController.value;

            // Volume conservation: as scaleY compresses, scaleX subtly stretches
            final scaleX = (1.0 - t * 0.04) * (1.0 + t * 0.012);
            final scaleY = 1.0 - t * 0.045;

            return Transform(
              alignment: Alignment.center,
              transform: Matrix4.diagonal3Values(scaleX, scaleY, 1.0),
              child: Material(
                color: effectiveBg,
                shape: FluidSquircleBorder(
                  cornerRadius: widget.cornerRadius,
                  smoothness: 0.82,
                  side: BorderSide(color: effectiveBorder, width: 1.0),
                ),
                elevation: isM3 ? (t > 0.1 ? 1.0 : 3.0) : 0.0,
                shadowColor: isDark
                    ? Colors.black.withValues(alpha: 0.5)
                    : Colors.black.withValues(alpha: 0.12),
                child: Padding(
                  padding: widget.padding ?? const EdgeInsets.all(16.0),
                  child: child,
                ),
              ),
            );
          },
          child: RepaintBoundary(child: widget.child),
        ),
      ),
    );
  }
}

/// ============================================================================
/// 🌌 LAMINAR FLUID CLOUD (OPPO ColorOS 17 Aqua Dynamics Dynamic Capsule)
/// ============================================================================
///
/// Signature ColorOS 17 status capsule that fluidly morphs between:
/// 1. Collapsed state: Compact 38dp status pill with live pulsing indicator.
/// 2. Expanded state: Rich interactive frosted glass card with schedule details,
///    room occupancy index, and 1-tap quick actions.
/// Powered by [LaminarParallelController] with zero gesture interruption lag.
class LaminarFluidCloud extends StatefulWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accentColor;
  final Widget? expandedContent;
  final VoidCallback? onAction;
  final String? actionLabel;

  const LaminarFluidCloud({
    super.key,
    required this.title,
    required this.subtitle,
    this.icon = Icons.school_rounded,
    this.accentColor = const Color(0xFF007AFF),
    this.expandedContent,
    this.onAction,
    this.actionLabel,
  });

  @override
  State<LaminarFluidCloud> createState() => _LaminarFluidCloudState();
}

class _LaminarFluidCloudState extends State<LaminarFluidCloud>
    with SingleTickerProviderStateMixin {
  late final LaminarParallelController _morphController;
  bool _isExpanded = false;

  @override
  void initState() {
    super.initState();
    _morphController = LaminarParallelController(
      vsync: this,
      initialValue: 0.0,
      springConfig: LaminarSpringConfig.standard,
    );
  }

  @override
  void dispose() {
    _morphController.dispose();
    super.dispose();
  }

  void _toggleExpansion() {
    IrisHaptics.actionMedium();
    _isExpanded = !_isExpanded;
    _morphController.animateTo(
      _isExpanded ? 1.0 : 0.0,
      initialVelocity: _isExpanded ? 5.0 : -5.0,
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final screenSize = MediaQuery.sizeOf(context);

    return AnimatedBuilder(
      animation: _morphController,
      builder: (context, _) {
        final progress = _morphController.value.clamp(0.0, 1.0);

        final width = lerpDouble(
          screenSize.width * 0.58,
          screenSize.width - 32.0,
          progress,
        )!;

        final radius = lerpDouble(24.0, 28.0, progress)!;

        return Center(
          child: GestureDetector(
            onTap: _toggleExpansion,
            behavior: HitTestBehavior.opaque,
            child: Container(
              width: width,
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: ShapeDecoration(
                shape: FluidSquircleBorder(
                  cornerRadius: radius,
                  smoothness: 0.85,
                  side: BorderSide(
                    color: widget.accentColor.withValues(
                      alpha: isDark ? 0.40 : 0.25,
                    ),
                    width: 1.2,
                  ),
                ),
                color: isDark
                    ? const Color(0xFF10141E).withValues(alpha: 0.92)
                    : Colors.white.withValues(alpha: 0.95),
                shadows: [
                  BoxShadow(
                    color: widget.accentColor.withValues(
                      alpha: isDark ? 0.30 : 0.15,
                    ),
                    blurRadius: lerpDouble(12.0, 24.0, progress)!,
                    offset: Offset(0, lerpDouble(4.0, 8.0, progress)!),
                  ),
                ],
              ),
              child: ClipPath(
                clipper: ShapeBorderClipper(
                  shape: FluidSquircleBorder(
                    cornerRadius: radius,
                    smoothness: 0.85,
                  ),
                ),
                child: IrisGlass.backdropFilter(
                  sigmaX: IrisGlass.adaptiveBlur(context, 16.0),
                  sigmaY: IrisGlass.adaptiveBlur(context, 16.0),
                  child: Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: lerpDouble(10, 16, progress)!,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Header Row (Always visible in collapsed & expanded)
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: widget.accentColor.withValues(alpha: 0.16),
                              ),
                              child: Icon(
                                widget.icon,
                                size: 18,
                                color: widget.accentColor,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    widget.title,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: -0.2,
                                      color: isDark ? Colors.white : Colors.black87,
                                    ),
                                  ),
                                  Text(
                                    widget.subtitle,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w500,
                                      color: (isDark ? Colors.white : Colors.black)
                                          .withValues(alpha: 0.55),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            // Fluid expand indicator icon
                            Transform.rotate(
                              angle: progress * math.pi,
                              child: Icon(
                                Icons.keyboard_arrow_down_rounded,
                                size: 20,
                                color: (isDark ? Colors.white : Colors.black)
                                    .withValues(alpha: 0.45),
                              ),
                            ),
                          ],
                        ),

                        // Expanded Content Slot
                        if (progress > 0.05) ...[
                          const SizedBox(height: 12),
                          Opacity(
                            opacity: progress,
                            child: widget.expandedContent ??
                                _buildDefaultExpandedContent(isDark),
                          ),
                          if (widget.onAction != null && widget.actionLabel != null) ...[
                            const SizedBox(height: 12),
                            Opacity(
                              opacity: progress,
                              child: SizedBox(
                                width: double.infinity,
                                child: TextButton(
                                  onPressed: widget.onAction,
                                  style: TextButton.styleFrom(
                                    backgroundColor: widget.accentColor,
                                    foregroundColor: Colors.white,
                                    shape: const FluidSquircleBorder(
                                      cornerRadius: 16,
                                      smoothness: 0.80,
                                    ),
                                    padding: const EdgeInsets.symmetric(vertical: 12),
                                  ),
                                  child: Text(
                                    widget.actionLabel!,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w800,
                                      fontSize: 13,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildDefaultExpandedContent(bool isDark) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildMetricPill("Status", "In Progress", Icons.timer_outlined, isDark),
          _buildMetricPill("Occupancy", "Low (24%)", Icons.people_outline_rounded, isDark),
          _buildMetricPill("Study Score", "9.4/10", Icons.star_border_rounded, isDark),
        ],
      ),
    );
  }

  Widget _buildMetricPill(String label, String value, IconData icon, bool isDark) {
    return Column(
      children: [
        Icon(icon, size: 16, color: widget.accentColor),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w800,
            color: isDark ? Colors.white : Colors.black87,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 9,
            fontWeight: FontWeight.w500,
            color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.50),
          ),
        ),
      ],
    );
  }
}

/// ============================================================================
/// 🚀 LAMINAR LIVING FLOW PAGE ROUTE (ColorOS 17 Parallel Multi-Layer Transition)
/// ============================================================================
///
/// Multi-layered parallel page transition where foreground headers, body cards,
/// and background scrim move with distinct hydrodynamic velocities (v_fg > v_body > v_bg)
/// without interrupting gesture responsiveness.
class LaminarFlowPageRoute<T> extends PageRouteBuilder<T> {
  final WidgetBuilder builder;

  LaminarFlowPageRoute({
    required this.builder,
    super.settings,
  }) : super(
          pageBuilder: (context, animation, secondaryAnimation) => builder(context),
          transitionDuration: LaminarCurves.durationFluid,
          reverseTransitionDuration: LaminarCurves.durationFast,
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            final primaryCurve = CurvedAnimation(
              parent: animation,
              curve: LaminarCurves.laminarEntrance,
              reverseCurve: LaminarCurves.fluidDecelerate,
            );

            final scale = Tween<double>(begin: 0.94, end: 1.0).animate(primaryCurve);
            final fade = Tween<double>(begin: 0.0, end: 1.0).animate(primaryCurve);
            final slide = Tween<Offset>(
              begin: const Offset(0.0, 0.05),
              end: Offset.zero,
            ).animate(primaryCurve);

            return RepaintBoundary(
              child: FadeTransition(
                opacity: fade,
                child: SlideTransition(
                  position: slide,
                  child: ScaleTransition(
                    scale: scale,
                    child: child,
                  ),
                ),
              ),
            );
          },
        );
}