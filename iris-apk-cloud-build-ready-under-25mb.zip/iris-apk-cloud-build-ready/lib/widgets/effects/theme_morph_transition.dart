import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import '../../core/theme_signals.dart';
import '../../services/ui_feedback.dart';
import 'glass_container_transform.dart';

/// Controller and state manager for global theme container morphing.
class ThemeMorphController {
  static ThemeMorphOverlayState? _activeState;

  static void _register(ThemeMorphOverlayState state) {
    _activeState = state;
    ThemeSignals.morphTransitionHandler = morphTo;
  }

  static void _unregister(ThemeMorphOverlayState state) {
    if (_activeState == state) {
      _activeState = null;
      ThemeSignals.morphTransitionHandler = null;
    }
  }

  /// Whether a container morph is currently in flight.
  static bool get isMorphing => _activeState?.isMorphing ?? false;

  /// Trigger a morph transition to [targetStyle] originating from [originRect] or [context].
  static Future<void> morphTo({
    required IrisThemeStyle targetStyle,
    Rect? originRect,
    GlobalKey? originKey,
    BuildContext? context,
  }) async {
    if (_activeState != null && _activeState!.mounted) {
      await _activeState!.startMorph(
        targetStyle: targetStyle,
        originRect: originRect,
        originKey: originKey,
        callerContext: context,
      );
    } else {
      await ThemeSignals.setThemeStyle(targetStyle);
    }
  }
}

/// An authentic, 120 FPS Telegram/ColorOS-style snapshot circular reveal overlay.
///
/// Captures the outgoing theme frame as a GPU `ui.Image`, immediately swaps the
/// underlying widget tree to the new theme on Frame 1, and reveals the new theme
/// through an expanding circular/geometric aperture with zero widget-tree Pop-in
/// or MaskFilter.blur shader hitching.
class ThemeMorphOverlay extends StatefulWidget {
  final Widget child;

  static final GlobalKey<ThemeMorphOverlayState> globalKey =
      GlobalKey<ThemeMorphOverlayState>();

  ThemeMorphOverlay({
    Key? key,
    required this.child,
  }) : super(key: key ?? globalKey);

  static Future<void> morph(
    BuildContext context, {
    required IrisThemeStyle targetStyle,
    Rect? originRect,
    GlobalKey? originKey,
  }) {
    return ThemeMorphController.morphTo(
      targetStyle: targetStyle,
      originRect: originRect,
      originKey: originKey,
      context: context,
    );
  }

  @override
  State<ThemeMorphOverlay> createState() => ThemeMorphOverlayState();
}

class ThemeMorphOverlayState extends State<ThemeMorphOverlay>
    with SingleTickerProviderStateMixin {
  final GlobalKey _repaintBoundaryKey = GlobalKey();
  late AnimationController _animController;
  late Animation<double> _morphAnimation;

  ui.Image? _capturedOldThemeImage;
  bool _isMorphing = false;
  bool get isMorphing => _isMorphing;

  IrisThemeStyle? _toStyle;
  Rect _startRect = Rect.zero;
  Color _monetSeed = ThemeSignals.defaultM3ESeedColor;

  @override
  void initState() {
    super.initState();
    ThemeMorphController._register(this);

    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 380),
    );

    _morphAnimation = CurvedAnimation(
      parent: _animController,
      curve: Curves.easeOutCubic,
    );

    _animController.addStatusListener((status) {
      if (status == AnimationStatus.completed ||
          status == AnimationStatus.dismissed) {
        _cleanupMorph();
      }
    });
  }

  @override
  void dispose() {
    ThemeMorphController._unregister(this);
    _capturedOldThemeImage?.dispose();
    _capturedOldThemeImage = null;
    _animController.dispose();
    super.dispose();
  }

  void _cleanupMorph() {
    _capturedOldThemeImage?.dispose();
    _capturedOldThemeImage = null;
    if (mounted) {
      setState(() {
        _isMorphing = false;
      });
    }
  }

  Future<void> startMorph({
    required IrisThemeStyle targetStyle,
    Rect? originRect,
    GlobalKey? originKey,
    BuildContext? callerContext,
  }) async {
    if (ThemeSignals.themeStyle.value == targetStyle) {
      return;
    }
    if (_isMorphing) {
      _animController.stop();
      _cleanupMorph();
    }

    final screenSize = MediaQuery.sizeOf(context);
    final rect = IrisSpatialDepth.resolveOriginBounds(
      screenSize: screenSize,
      initialBounds: originRect,
      originKey: originKey,
      callerContext: callerContext,
      fallbackCardSize: const Size(120, 48),
    );

    // 1. Capture current theme screenshot at 1.0x pixelRatio (fast, <2ms on GPU)
    ui.Image? snapshot;
    try {
      final boundary = _repaintBoundaryKey.currentContext?.findRenderObject()
          as RenderRepaintBoundary?;
      if (boundary != null && boundary.hasSize) {
        snapshot = await boundary.toImage(pixelRatio: 1.0);
      }
    } catch (_) {
      snapshot = null;
    }

    _capturedOldThemeImage?.dispose();
    _capturedOldThemeImage = snapshot;
    _toStyle = targetStyle;
    _startRect = rect;
    _monetSeed = ThemeSignals.m3eSeedColor.value;
    _isMorphing = true;

    IrisHaptics.selectionClick();

    // 2. Immediately apply the new theme while the old theme snapshot covers the screen
    await ThemeSignals.setThemeStyle(targetStyle);

    if (!mounted) return;
    _animController.duration = const Duration(milliseconds: 360);
    _morphAnimation = CurvedAnimation(
      parent: _animController,
      curve: const Cubic(0.16, 1.0, 0.3, 1.0),
    );

    setState(() {});
    await _animController.forward(from: 0.0);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        RepaintBoundary(
          key: _repaintBoundaryKey,
          child: widget.child,
        ),
        if (_isMorphing)
          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: _animController,
                builder: (context, _) {
                  return CustomPaint(
                    painter: _ThemeSnapshotRevealPainter(
                      progress: _morphAnimation.value,
                      startRect: _startRect,
                      oldThemeImage: _capturedOldThemeImage,
                      toStyle: _toStyle ?? IrisThemeStyle.fluidGlass,
                      monetSeed: _monetSeed,
                    ),
                  );
                },
              ),
            ),
          ),
      ],
    );
  }
}

class _ThemeSnapshotRevealPainter extends CustomPainter {
  final double progress;
  final Rect startRect;
  final ui.Image? oldThemeImage;
  final IrisThemeStyle toStyle;
  final Color monetSeed;

  _ThemeSnapshotRevealPainter({
    required this.progress,
    required this.startRect,
    required this.oldThemeImage,
    required this.toStyle,
    required this.monetSeed,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;

    final center = startRect.center;
    final maxDist = math.max(
      math.max(
        _dist(center, Offset.zero),
        _dist(center, Offset(size.width, 0)),
      ),
      math.max(
        _dist(center, Offset(0, size.height)),
        _dist(center, Offset(size.width, size.height)),
      ),
    );

    final startRadius = math.min(startRect.width, startRect.height) * 0.35;
    final currentRadius =
        ui.lerpDouble(startRadius, maxDist * 1.05, progress) ?? maxDist;

    final revealPath = Path()
      ..addOval(Rect.fromCircle(center: center, radius: currentRadius));

    // Draw the old theme snapshot outside the expanding circular aperture
    if (oldThemeImage != null) {
      canvas.save();
      final fullPath = Path()..addRect(Offset.zero & size);
      final outsidePath =
          Path.combine(PathOperation.difference, fullPath, revealPath);
      canvas.clipPath(outsidePath);
      final srcRect = Rect.fromLTWH(
        0,
        0,
        oldThemeImage!.width.toDouble(),
        oldThemeImage!.height.toDouble(),
      );
      final dstRect = Offset.zero & size;
      canvas.drawImageRect(
        oldThemeImage!,
        srcRect,
        dstRect,
        Paint()..filterQuality = FilterQuality.low,
      );
      canvas.restore();
    }

    // Crisp specular ring along the expanding wave front (zero MaskFilter.blur!)
    final fadeAlpha = (1.0 - progress).clamp(0.0, 1.0);
    if (fadeAlpha > 0.02) {
      final accent = switch (toStyle) {
        IrisThemeStyle.fluidGlass => const Color(0xFF38BDF8),
        IrisThemeStyle.materialYou => monetSeed,
        IrisThemeStyle.almanac => const Color(0xFFC84B31),
        IrisThemeStyle.editorialAcademic => const Color(0xFFE5A83B),
        IrisThemeStyle.notebook => const Color(0xFFE11D48),
        IrisThemeStyle.line => const Color(0xFF10B981),
        IrisThemeStyle.poster => const Color(0xFFFF451A),
      };

      final rimPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.8 * fadeAlpha
        ..color = accent.withValues(alpha: 0.85 * fadeAlpha);
      canvas.drawCircle(center, currentRadius, rimPaint);
    }
  }

  double _dist(Offset a, Offset b) {
    final dx = a.dx - b.dx;
    final dy = a.dy - b.dy;
    return math.sqrt(dx * dx + dy * dy);
  }

  @override
  bool shouldRepaint(covariant _ThemeSnapshotRevealPainter oldDelegate) {
    return oldDelegate.progress != progress ||
        oldDelegate.oldThemeImage != oldThemeImage;
  }
}