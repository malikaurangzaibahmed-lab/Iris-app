import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../core/tokens.dart';
import '../core/animations.dart';
import '../services/ui_feedback.dart';
import '../core/theme_signals.dart';
import '../core/glass.dart';
import '../core/editorial_theme_tokens.dart';
import '../core/almanac_theme_tokens.dart';
import '../core/notebook_theme_tokens.dart';
import '../core/line_theme_tokens.dart';
import '../core/poster_theme_tokens.dart';

class GlassCard extends StatelessWidget {
  final Widget child;
  final bool glow;
  final bool shimmer;
  final bool enableBlur;
  final bool enableShadow;
  final bool enableOverlay;
  final EdgeInsetsGeometry? padding;
  final double? borderRadius;
  final int elevation;
  final Color? accentColor;
  final Color? backgroundColor;
  final BoxBorder? border;
  final bool tilt;
  final bool animate;
  final VoidCallback? onTap;

  const GlassCard({
    required this.child,
    this.glow = false,
    this.shimmer = false,
    this.enableBlur = true,
    this.enableShadow = true,
    this.enableOverlay = false,
    this.padding,
    this.borderRadius,
    this.elevation = 2,
    this.accentColor,
    this.backgroundColor,
    this.tilt = false,
    this.animate = false,
    this.onTap,
    this.border,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final effectivePadding =
        padding ?? const EdgeInsets.all(IrisTokens.space24);
    final effectiveRadius = borderRadius ?? 32.0;
    final tintColor =
        accentColor ?? (isDark ? IrisTokens.brandDark : IrisTokens.brand);
    final tiltAngle = tilt ? 0.006 : 0.0;

    final disableAnimations = MediaQuery.maybeDisableAnimationsOf(context) ?? false;

    return ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, themeStyle, _) {
        final isM3 = themeStyle == IrisThemeStyle.materialYou;

        if (isM3) {
          final cs = Theme.of(context).colorScheme;
          final effectiveM3Radius = borderRadius ?? 28.0;

          // Authentic M3 Expressive tonal elevation mapping
          final Color m3Color;
          if (backgroundColor != null && backgroundColor != Colors.transparent && backgroundColor!.a >= 0.95) {
            m3Color = backgroundColor!;
          } else if (backgroundColor == Colors.transparent) {
            m3Color = Colors.transparent;
          } else {
            m3Color = switch (elevation) {
              0 => cs.surfaceContainerLowest,
              1 => cs.surfaceContainerLow,
              2 => cs.surfaceContainer,
              3 => cs.surfaceContainerHigh,
              _ => cs.surfaceContainerHighest,
            };
          }

          final shape = RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(effectiveM3Radius),
            side: border != null
                ? BorderSide(
                    color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.65),
                    width: 1.0,
                  )
                : (elevation == 0
                    ? BorderSide(
                        color: cs.outlineVariant.withValues(alpha: isDark ? 0.25 : 0.50),
                        width: 1.0,
                      )
                    : BorderSide.none),
          );

          final cardBoxShadow = (enableShadow && elevation > 0 && m3Color != Colors.transparent)
              ? [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.28 : 0.06),
                    blurRadius: elevation * 4.0 + 4.0,
                    offset: Offset(0, elevation * 1.5 + 1.0),
                  ),
                ]
              : null;

          Widget cardContent = Padding(
            padding: effectivePadding,
            child: child,
          );

          // Specular domain tint highlight if accentColor is provided and glow is enabled
          if (accentColor != null && glow && m3Color != Colors.transparent) {
            cardContent = Stack(
              children: [
                Positioned.fill(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(effectiveM3Radius),
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          accentColor!.withValues(alpha: isDark ? 0.10 : 0.06),
                          Colors.transparent,
                        ],
                        stops: const [0.0, 0.45],
                      ),
                    ),
                  ),
                ),
                cardContent,
              ],
            );
          }

          final materialCard = Container(
            decoration: cardBoxShadow != null
                ? BoxDecoration(
                    borderRadius: BorderRadius.circular(effectiveM3Radius),
                    boxShadow: cardBoxShadow,
                  )
                : null,
            child: Material(
              color: m3Color,
              shape: shape,
              clipBehavior: Clip.antiAlias,
              child: cardContent,
            ),
          );

          if (onTap != null) {
            return RepaintBoundary(
              child: ExpressiveInteractivePress(
                onTap: onTap,
                pressedScale: 0.985,
                child: materialCard,
              ),
            );
          }

          return RepaintBoundary(child: materialCard);
        }

        if (themeStyle == IrisThemeStyle.almanac) {
          final effectiveAlmanacRadius = borderRadius ?? 0.0;
          final Color almanacBg = backgroundColor ?? AlmanacTokens.cardSurface(isDark);
          final shape = RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(effectiveAlmanacRadius),
            side: border != null
                ? BorderSide(
                    color: AlmanacTokens.inkRule(isDark),
                    width: 1.0,
                  )
                : BorderSide(
                    color: AlmanacTokens.inkRuleSubtle(isDark),
                    width: 0.8,
                  ),
          );

          Widget cardContent = Padding(
            padding: effectivePadding,
            child: child,
          );

          final almanacCard = Container(
            decoration: BoxDecoration(
              color: almanacBg,
              borderRadius: BorderRadius.circular(effectiveAlmanacRadius),
            ),
            child: Material(
              color: almanacBg,
              shape: shape,
              clipBehavior: Clip.antiAlias,
              child: cardContent,
            ),
          );

          if (onTap != null) {
            return RepaintBoundary(
              child: ExpressiveInteractivePress(
                onTap: onTap,
                enable3DTilt: false,
                baseRotation: 0.0,
                pressedScale: 0.985,
                child: almanacCard,
              ),
            );
          }

          return RepaintBoundary(child: almanacCard);
        }

        if (themeStyle == IrisThemeStyle.editorialAcademic) {
          final effectiveEditorialRadius = borderRadius ?? 24.0;
          final Color editorialCardBg = backgroundColor ?? EditorialTokens.cardSurface(isDark);
          final shape = RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(effectiveEditorialRadius),
            side: border != null
                ? BorderSide(
                    color: EditorialTokens.cardBorder(isDark),
                    width: 1.0,
                  )
                : (elevation == 0
                    ? BorderSide(
                        color: EditorialTokens.cardBorder(isDark).withValues(alpha: 0.6),
                        width: 1.0,
                      )
                    : BorderSide.none),
          );

          final cardBoxShadow = (enableShadow && elevation > 0 && editorialCardBg != Colors.transparent)
              ? EditorialTokens.cardShadow(isDark, elevation: elevation.toDouble())
              : null;

          Widget cardContent = Padding(
            padding: effectivePadding,
            child: child,
          );

          if (accentColor != null && glow && editorialCardBg != Colors.transparent) {
            cardContent = Stack(
              children: [
                Positioned.fill(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(effectiveEditorialRadius),
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          accentColor!.withValues(alpha: isDark ? 0.08 : 0.05),
                          Colors.transparent,
                        ],
                        stops: const [0.0, 0.40],
                      ),
                    ),
                  ),
                ),
                cardContent,
              ],
            );
          }

          final editorialCard = Container(
            decoration: cardBoxShadow != null
                ? BoxDecoration(
                    borderRadius: BorderRadius.circular(effectiveEditorialRadius),
                    boxShadow: cardBoxShadow,
                  )
                : null,
            child: Material(
              color: editorialCardBg,
              shape: shape,
              clipBehavior: Clip.antiAlias,
              child: cardContent,
            ),
          );

          if (onTap != null) {
            return RepaintBoundary(
              child: ExpressiveInteractivePress(
                onTap: onTap,
                pressedScale: 0.985,
                child: editorialCard,
              ),
            );
          }

          return RepaintBoundary(child: editorialCard);
        }

        // =====================================================================
        // THEME 3: NOTEBOOK / STATIONERY (Paper Card with Washi Tape Overhang)
        // =====================================================================
        if (themeStyle == IrisThemeStyle.notebook) {
          final effectiveNotebookRadius = borderRadius ?? 6.0;
          final Color notebookCardBg = backgroundColor ?? NotebookTokens.cardSurface(isDark);
          final shape = RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(effectiveNotebookRadius),
            side: border != null
                ? BorderSide(
                    color: isDark ? const Color(0xFF2F453B) : const Color(0xFFE5E0D6),
                    width: 0.9,
                  )
                : BorderSide(
                    color: isDark ? const Color(0xFF2F453B) : const Color(0xFFE5E0D6),
                    width: 0.9,
                  ),
          );

          final cardShadow = (enableShadow && elevation > 0 && notebookCardBg != Colors.transparent)
              ? [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.30 : 0.08),
                    offset: const Offset(1, 4),
                    blurRadius: 7,
                  ),
                ]
              : null;

          Widget cardContent = Padding(
            padding: effectivePadding,
            child: child,
          );

          final notebookCard = Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                decoration: cardShadow != null
                    ? BoxDecoration(
                        borderRadius: BorderRadius.circular(effectiveNotebookRadius),
                        boxShadow: cardShadow,
                      )
                    : null,
                child: Material(
                  color: notebookCardBg,
                  shape: shape,
                  clipBehavior: Clip.antiAlias,
                  child: cardContent,
                ),
              ),
              if (elevation > 0)
                Positioned(
                  top: -8,
                  left: 16,
                  child: WashiTapeOverhang(
                    width: 38,
                    height: 14,
                    color: NotebookTokens.tapeYellow,
                    rotation: 0.03,
                  ),
                ),
            ],
          );

          if (onTap != null) {
            return RepaintBoundary(
              child: ExpressiveInteractivePress(
                onTap: onTap,
                pressedScale: 0.98,
                child: notebookCard,
              ),
            );
          }

          return RepaintBoundary(child: notebookCard);
        }

        // =====================================================================
        // THEME 4: LINE / SUBWAY TRANSIT (Clean Station Card with Rail Accent)
        // =====================================================================
        if (themeStyle == IrisThemeStyle.line) {
          final effectiveLineRadius = borderRadius ?? 12.0;
          final Color lineCardBg = backgroundColor ?? LineTokens.cardSurface(isDark);
          final shape = RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(effectiveLineRadius),
            side: border != null
                ? BorderSide(
                    color: LineTokens.subwayYellow,
                    width: 1.5,
                  )
                : BorderSide(
                    color: isDark ? const Color(0xFF28303C) : const Color(0xFFD6D1C4),
                    width: 1.2,
                  ),
          );

          final cardShadow = (enableShadow && elevation > 0 && lineCardBg != Colors.transparent)
              ? [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.06),
                    offset: const Offset(0, 3),
                    blurRadius: 6,
                  ),
                ]
              : null;

          Widget cardContent = Padding(
            padding: effectivePadding,
            child: child,
          );

          final lineCard = Container(
            decoration: cardShadow != null
                ? BoxDecoration(
                    borderRadius: BorderRadius.circular(effectiveLineRadius),
                    boxShadow: cardShadow,
                  )
                : null,
            child: Material(
              color: lineCardBg,
              shape: shape,
              clipBehavior: Clip.antiAlias,
              child: cardContent,
            ),
          );

          if (onTap != null) {
            return RepaintBoundary(
              child: ExpressiveInteractivePress(
                onTap: onTap,
                pressedScale: 0.98,
                child: lineCard,
              ),
            );
          }

          return RepaintBoundary(child: lineCard);
        }

        // =====================================================================
        // THEME 5: POSTER / SWISS BRUTALISM (Monolithic 3D Extruded Drop Block)
        // =====================================================================
        if (themeStyle == IrisThemeStyle.poster) {
          final Color posterCardBg = backgroundColor ?? PosterTokens.cardSurface(isDark);
          const shape = RoundedRectangleBorder(
            borderRadius: BorderRadius.zero,
            side: BorderSide(
              color: Colors.black,
              width: 2.2,
            ),
          );

          final cardShadow = (enableShadow && elevation > 0 && posterCardBg != Colors.transparent)
              ? PosterTokens.extrudedBlockShadow(
                  isDark,
                  offset: elevation > 1 ? 4.0 : 2.5,
                )
              : null;

          Widget cardContent = Padding(
            padding: effectivePadding,
            child: child,
          );

          final posterCard = Container(
            decoration: cardShadow != null
                ? BoxDecoration(
                    color: posterCardBg,
                    boxShadow: cardShadow,
                  )
                : null,
            child: Material(
              color: posterCardBg,
              shape: shape,
              clipBehavior: Clip.antiAlias,
              child: cardContent,
            ),
          );

          if (onTap != null) {
            return RepaintBoundary(
              child: ExpressiveInteractivePress(
                onTap: onTap,
                pressedScale: 0.98,
                child: posterCard,
              ),
            );
          }

          return RepaintBoundary(child: posterCard);
        }

        return ValueListenableBuilder<double>(
          valueListenable: ThemeSignals.glassTransparency,
          builder: (context, transparency, _) {
            return ValueListenableBuilder<bool>(
              valueListenable: ThemeSignals.useMinimalTheme,
              builder: (context, useMinimal, _) {
                final effectiveMinimal = useMinimal;
                final isOpaque = transparency <= 0.08;

                final Color baseSurfaceColor = backgroundColor ??
                    (isDark
                        ? Color.alphaBlend(
                            tintColor.withValues(alpha: glow ? 0.14 : 0.05),
                            const Color(0xFF1E293B),
                          )
                        : Colors.white);

                final double surfaceAlpha = effectiveMinimal
                    ? 1.0
                    : (isOpaque
                        ? 0.98
                        : ui.lerpDouble(0.96, isDark ? 0.64 : 0.80, transparency)!);

                final glassColor = baseSurfaceColor.withValues(alpha: surfaceAlpha);

                final reduceBlur = IrisMotion.reduceBlur || effectiveMinimal || disableAnimations || isOpaque;

                final shape = RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(effectiveRadius),
                  side: border is Border
                      ? (border as Border).top
                      : (effectiveMinimal || isOpaque
                          ? BorderSide(
                              color: isDark ? const Color(0xFF1E2433) : const Color(0xFFE2E8F0),
                              width: 1.0,
                            )
                          : BorderSide.none),
                );

                final double targetBlur = isOpaque
                    ? 0.0
                    : ui.lerpDouble(8.0, 22.0, transparency)!;

                final blurSigma = enableBlur
                    ? (reduceBlur ? 0.0 : targetBlur)
                    : 0.0;

                final settings = IrisGlass.settings(
                  context,
                  blur: blurSigma,
                  ambientStrength: effectiveMinimal || isOpaque
                      ? 0.0
                      : ui.lerpDouble(0.2, 0.95, transparency)!,
                  lightAngle: 1.5,
                  thickness: effectiveMinimal || isOpaque
                      ? 0.0
                      : ui.lerpDouble(4.0, 18.0, transparency)!,
                  glassColor: glassColor,
                );

            final cardBody = Container(
              decoration: ShapeDecoration(
                shape: shape,
                shadows: enableShadow && !effectiveMinimal
                    ? [
                        BoxShadow(
                          color: Colors.black.withValues(
                            alpha: isDark ? 0.38 : 0.06,
                          ),
                          offset: const Offset(0, 8),
                          blurRadius: 24,
                          spreadRadius: -4,
                        ),
                        if (glow)
                          BoxShadow(
                            color: tintColor.withValues(
                              alpha: isDark ? 0.22 : 0.14,
                            ),
                            blurRadius: 22,
                            spreadRadius: -4,
                          ),
                      ]
                    : null,
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(effectiveRadius),
                child: RepaintBoundary(
                  child: GlassSurface(
                    settings: settings,
                    radius: effectiveRadius,
                    applyInLayer: elevation >= 4,
                    borderSide: border is Border
                        ? (border as Border).top
                        : BorderSide(
                            color: glow && accentColor != null
                                ? tintColor.withValues(alpha: isDark ? 0.42 : 0.32)
                                : (isDark
                                    ? Colors.white.withValues(alpha: 0.14 + 0.08 * transparency)
                                    : Colors.white.withValues(alpha: 0.65 + 0.25 * transparency)),
                            width: glow ? 1.4 : 1.1,
                          ),
                    child: Stack(
                      children: [
                        Positioned.fill(
                          child: IgnorePointer(
                            child: DecoratedBox(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(effectiveRadius),
                                gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    (glow && accentColor != null
                                            ? tintColor
                                            : Colors.white)
                                        .withValues(
                                      alpha: glow
                                          ? (isDark ? 0.18 : 0.12)
                                          : (isDark ? 0.09 : 0.35),
                                    ),
                                    Colors.transparent,
                                  ],
                                  stops: const [0.0, 0.58],
                                ),
                              ),
                            ),
                          ),
                        ),
                        Material(
                          color: Colors.transparent,
                          child: InkWell(
                            onTap: onTap != null
                                ? () {
                                    IrisHaptics.actionSoft();
                                    onTap!();
                                  }
                                : null,
                            child: Padding(
                              padding: effectivePadding,
                              child: child,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );

        Widget result = cardBody;
        if (tilt) {
          result = Transform.rotate(angle: tiltAngle, child: result);
        }

        if (animate && !IrisMotion.reduceMotion && !effectiveMinimal) {
          result = TweenAnimationBuilder<double>(
            tween: Tween(begin: 0.0, end: 1.0),
            duration: IrisMotion.medium,
            curve: IrisMotion.entrance,
            builder: (context, animValue, child) =>
                Transform.scale(scale: 0.97 + (animValue * 0.03), child: child),
            child: result,
          );
        }

        return RepaintBoundary(child: result);
      },
    );
          },
        );
      },
    );
  }
}

