import 'package:flutter/material.dart';
import '../../core/tokens.dart';
import '../../core/models.dart';
import '../../core/omni_brain.dart';
import '../../core/glass.dart';
import '../../core/animations.dart';
import '../../core/theme_signals.dart';
import '../../services/ui_feedback.dart';
import 'package:iris/widgets/controls/iris_liquid_button.dart';
import '../glass_card.dart';

/// Interactive card component representing a suggested makeup lecture slot.
/// Supports both Material 3 Expressive and Liquid Glass design languages.
class MakeupSlotCard extends StatelessWidget {
  final MakeupSlotSuggestion suggestion;
  final bool isSelected;
  final bool isAdded;
  final ClassSession? regularConflict;
  final List<ClassSession> overlappingMakeups;
  final bool isDark;
  final bool isM3;
  final bool hasTeacher;
  final VoidCallback onTap;
  final VoidCallback onAction;

  const MakeupSlotCard({
    required this.suggestion,
    required this.isSelected,
    required this.isAdded,
    required this.regularConflict,
    required this.overlappingMakeups,
    required this.isDark,
    required this.isM3,
    required this.hasTeacher,
    required this.onTap,
    required this.onAction,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final isBlocked = regularConflict != null && !isAdded;
    final cs = Theme.of(context).colorScheme;

    final cardContent = Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (suggestion.slotName != null) ...[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.schedule_rounded,
                      size: 13,
                      color: IrisTokens.brand.withValues(alpha: 0.8),
                    ),
                    const SizedBox(width: 5),
                    Text(
                      suggestion.slotName!,
                      style: TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w800,
                        color: isDark ? Colors.white70 : Colors.black87,
                        letterSpacing: 0.2,
                      ),
                    ),
                  ],
                ),
                if (!isBlocked && !isAdded)
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFF10B981).withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                        color: const Color(0xFF10B981).withValues(alpha: 0.3),
                        width: 0.5,
                      ),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.auto_awesome,
                          size: 10,
                          color: Color(0xFF10B981),
                        ),
                        SizedBox(width: 4),
                        Text(
                          'Optimal Slot',
                          style: TextStyle(
                            fontSize: 9.5,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF10B981),
                            letterSpacing: 0.3,
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 8),
          ],
          // Day and Time
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [IrisTokens.brand, IrisTokens.brandLight],
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  suggestion.dayName,
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    letterSpacing: 0.3,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      suggestion.slotName != null
                          ? suggestion.slotName!.split(' (').first
                          : suggestion.timeRangeString(),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: IrisTokens.brand,
                        letterSpacing: 0.2,
                      ),
                    ),
                    Text(
                      suggestion.timeRangeString(),
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: isDark ? Colors.white70 : Colors.black87,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: IrisTokens.success.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color: IrisTokens.success.withValues(alpha: 0.3),
                  ),
                ),
                child: Text(
                  suggestion.durationHours >= 2.5
                      ? 'Lab (170m)'
                      : (suggestion.durationHours == 2.0
                          ? '2 hr Block'
                          : (suggestion.durationHours == 1.0
                              ? '1 hr Cut-off'
                              : '85 min Slot')),
                  style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: IrisTokens.success,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Container(
                width: 6,
                height: 6,
                decoration: const BoxDecoration(
                  color: Color(0xFF10B981),
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                'Teacher Free · Batch Free',
                style: TextStyle(
                  fontSize: 10.5,
                  fontWeight: FontWeight.w700,
                  color: const Color(0xFF10B981).withValues(alpha: 0.9),
                  letterSpacing: 0.2,
                ),
              ),
            ],
          ),
          if (isAdded) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 6,
              ),
              decoration: BoxDecoration(
                color: IrisTokens.success.withValues(alpha: 0.14),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: IrisTokens.success.withValues(alpha: 0.28),
                ),
              ),
              child: const Row(
                children: [
                  Icon(
                    Icons.check_circle_rounded,
                    color: IrisTokens.success,
                    size: 15,
                  ),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Already in your timeline',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: IrisTokens.success,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
          if (isBlocked) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 6,
              ),
              decoration: BoxDecoration(
                color: IrisTokens.error.withValues(alpha: 0.14),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: IrisTokens.error.withValues(alpha: 0.30),
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.warning_amber_rounded,
                    color: IrisTokens.error,
                    size: 15,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Conflicts with ${regularConflict!.subject} (${regularConflict!.startTime}-${regularConflict!.endTime})',
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: IrisTokens.error,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ] else if (!isAdded && overlappingMakeups.isNotEmpty) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 6,
              ),
              decoration: BoxDecoration(
                color: IrisTokens.brand.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: IrisTokens.brand.withValues(alpha: 0.28),
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.autorenew_rounded,
                    color: IrisTokens.brand,
                    size: 15,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Will replace ${overlappingMakeups.length} overlapping makeup slot${overlappingMakeups.length == 1 ? '' : 's'}',
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: IrisTokens.brand,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 8),
          Text(
            'Suggested free window',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: (isDark ? Colors.white : Colors.black).withValues(
                alpha: 0.55,
              ),
              letterSpacing: 0.2,
            ),
          ),
          const SizedBox(height: 12),

          // Available Rooms
          if (suggestion.availableRooms != null &&
              suggestion.availableRooms!.isNotEmpty) ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: IrisTokens.success.withValues(
                  alpha: isDark ? 0.12 : 0.08,
                ),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: IrisTokens.success.withValues(alpha: 0.25),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(
                        Icons.meeting_room_rounded,
                        size: 16,
                        color: IrisTokens.success,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Available Rooms (${suggestion.availableRooms!.length})',
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: IrisTokens.success,
                          letterSpacing: 0.3,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: suggestion.availableRooms!
                        .take(10) // Show max 10 rooms
                        .map(
                          (room) => Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: IrisTokens.success.withValues(
                                alpha: 0.15,
                              ),
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(
                                color: IrisTokens.success.withValues(
                                  alpha: 0.3,
                                ),
                              ),
                            ),
                            child: Text(
                              room,
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                color: isDark
                                    ? Colors.white
                                    : Colors.black87,
                              ),
                            ),
                          ),
                        )
                        .toList(),
                  ),
                  if (suggestion.availableRooms!.length > 10)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text(
                        '+${suggestion.availableRooms!.length - 10} more rooms',
                        style: TextStyle(
                          fontSize: 9,
                          fontWeight: FontWeight.w500,
                          color: IrisTokens.success.withValues(
                            alpha: 0.7,
                          ),
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ] else ...[
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.orange.withValues(
                  alpha: isDark ? 0.12 : 0.08,
                ),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: Colors.orange.withValues(alpha: 0.2),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.info_outline_rounded,
                    size: 16,
                    color: Colors.orange.withValues(alpha: 0.7),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'No rooms available during this slot',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        color: Colors.orange.withValues(alpha: 0.8),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: IrisLiquidButton(
              text: isBlocked
                  ? 'Conflicting Slot'
                  : (isAdded
                        ? 'Remove From Timeline'
                        : 'Add To Timeline'),
              icon: isBlocked
                  ? Icons.block_rounded
                  : (isAdded
                        ? Icons.remove_circle_outline_rounded
                        : Icons.add_circle_outline_rounded),
              onTap: (!hasTeacher || isBlocked) ? null : onAction,
              color: isBlocked
                  ? (isDark ? Colors.white24 : Colors.black26)
                  : (isAdded ? IrisTokens.error : IrisTokens.brand),
              isDark: isDark,
              height: 48,
              fontWeight: FontWeight.w700,
            ),
          ),
          if (!isAdded && !isBlocked) ...[
            const SizedBox(height: 8),
            Text(
              overlappingMakeups.isNotEmpty
                  ? 'This will replace overlapping makeup slots and keep restore history.'
                  : 'If this overlaps another makeup slot, the app replaces it intelligently.',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w500,
                color: (isDark ? Colors.white : Colors.black)
                    .withValues(alpha: 0.5),
              ),
            ),
          ],
        ],
      ),
    );

    if (isM3) {
      return ExpressiveInteractivePress(
        onTap: () {
          onTap();
          IrisHaptics.selectionClick();
        },
        child: Container(
          decoration: BoxDecoration(
            color: isSelected
                ? (isDark ? cs.surfaceContainerHigh : cs.surfaceContainerHighest)
                : (isDark ? cs.surfaceContainerLow : cs.surfaceContainer),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: isSelected
                  ? cs.primary
                  : cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.5),
              width: isSelected ? 2.0 : 1.0,
            ),
            boxShadow: [
              BoxShadow(
                color: isSelected
                    ? cs.primary.withValues(alpha: 0.20)
                    : Colors.black.withValues(alpha: isDark ? 0.16 : 0.04),
                blurRadius: isSelected ? 12 : 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: cardContent,
        ),
      );
    }
    final themeStyle = ThemeSignals.themeStyle.value;
    if (themeStyle != IrisThemeStyle.fluidGlass && !isM3) {
      return ExpressiveInteractivePress(
        onTap: () {
          onTap();
          IrisHaptics.selectionClick();
        },
        pressedScale: 0.98,
        child: GlassCard(
          borderRadius: 24,
          accentColor: isSelected ? IrisTokens.brand : null,
          elevation: isSelected ? 3 : 1,
          padding: EdgeInsets.zero,
          child: cardContent,
        ),
      );
    }

    return GestureDetector(
      onTap: () {
        onTap();
        IrisHaptics.selectionClick();
      },
      child: ClipRRect(
        borderRadius: BorderRadius.circular(32),
        child: GlassSurface(
          settings: IrisGlass.settings(
            context,
            blur: 24,
            ambientStrength: 0.4,
            lightAngle: 1.5,
            thickness: 12,
            glassColor: isDark
                ? Colors.white.withValues(alpha: 0.05)
                : Colors.white.withValues(alpha: 0.3),
          ),
          radius: 32,
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  IrisTokens.brand.withValues(
                    alpha: isSelected
                        ? (isDark ? 0.32 : 0.24)
                        : (isDark ? 0.14 : 0.08),
                  ),
                  IrisTokens.brandLight.withValues(
                    alpha: isSelected
                        ? (isDark ? 0.24 : 0.20)
                        : (isDark ? 0.10 : 0.06),
                  ),
                ],
              ),
              borderRadius: BorderRadius.circular(32),
              border: Border.all(
                color: isSelected
                    ? IrisTokens.brand.withValues(alpha: 0.6)
                    : IrisTokens.brand.withValues(alpha: 0.2),
                width: isSelected ? 2.0 : 1.0,
              ),
            ),
            child: cardContent,
          ),
        ),
      ),
    );
  }
}
