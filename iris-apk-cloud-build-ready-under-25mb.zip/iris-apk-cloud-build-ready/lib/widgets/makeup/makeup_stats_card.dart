import 'package:flutter/material.dart';
import '../../core/tokens.dart';
import '../../core/glass.dart';
import '../../core/theme_signals.dart';
import '../glass_card.dart';

/// Summary statistics card for makeup slot suggestions,
/// adaptively supporting both Material 3 Expressive and Liquid Glass themes.
class MakeupStatsCard extends StatelessWidget {
  final bool isDark;
  final bool isM3;
  final ColorScheme cs;
  final int slotCount;
  final double totalHours;
  final int withRoomsCount;

  const MakeupStatsCard({
    required this.isDark,
    required this.isM3,
    required this.cs,
    required this.slotCount,
    required this.totalHours,
    required this.withRoomsCount,
    super.key,
  });

  Widget _buildStatItem(
    IconData icon,
    String value,
    String label,
    bool isDark,
  ) {
    return Column(
      children: [
        Icon(icon, color: IrisTokens.brand, size: 20),
        const SizedBox(height: 6),
        Text(
          value,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w800,
            color: isDark ? Colors.white : Colors.black,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 10,
            color: (isDark ? Colors.white : Colors.black).withValues(
              alpha: 0.6,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    const purple = IrisTokens.purple;

    final statsContent = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              Icons.analytics_rounded,
              size: 16,
              color: isM3 ? cs.primary : purple.withValues(alpha: 0.9),
            ),
            const SizedBox(width: 8),
            Text(
              'Summary',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.6,
                color: isM3
                    ? cs.onSurfaceVariant
                    : (isDark ? Colors.white : Colors.black).withValues(alpha: 0.7),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildStatItem(
              Icons.event_available_rounded,
              slotCount.toString(),
              'Slots',
              isDark,
            ),
            Container(
              width: 1,
              height: 30,
              color: (isM3 ? cs.outlineVariant : purple).withValues(alpha: 0.2),
            ),
            _buildStatItem(
              Icons.access_time_rounded,
              '${totalHours.toStringAsFixed(1)}h',
              'Total',
              isDark,
            ),
            Container(
              width: 1,
              height: 30,
              color: (isM3 ? cs.outlineVariant : purple).withValues(alpha: 0.2),
            ),
            _buildStatItem(
              Icons.meeting_room_rounded,
              withRoomsCount.toString(),
              'With Rooms',
              isDark,
            ),
          ],
        ),
      ],
    );

    final themeStyle = ThemeSignals.themeStyle.value;
    if (themeStyle != IrisThemeStyle.fluidGlass && !isM3) {
      return GlassCard(
        borderRadius: 24,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        child: statsContent,
      );
    }

    return isM3
        ? Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 24,
              vertical: 24,
            ),
            decoration: BoxDecoration(
              color: isDark ? cs.surfaceContainerLow : cs.surfaceContainer,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color: cs.outlineVariant.withValues(
                  alpha: isDark ? 0.35 : 0.5,
                ),
                width: 1.0,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(
                    alpha: isDark ? 0.16 : 0.04,
                  ),
                  blurRadius: 10,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: statsContent,
          )
        : ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: GlassSurface(
              settings: IrisGlass.settings(
                context,
                blur: 24,
                ambientStrength: 0.5,
                lightAngle: 1.5,
                thickness: 16,
                glassColor: isDark
                    ? Colors.white.withValues(alpha: 0.05)
                    : Colors.white.withValues(alpha: 0.4),
              ),
              radius: 24,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 24,
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: isDark
                        ? Colors.white.withValues(alpha: 0.1)
                        : Colors.white.withValues(alpha: 0.8),
                    width: 1.2,
                  ),
                ),
                child: statsContent,
              ),
            ),
          );
  }
}
