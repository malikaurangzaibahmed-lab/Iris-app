import 'package:flutter/material.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../services/ui_feedback.dart';

/// Pixel-perfect Broadsheet 4-Tab Bottom Navigation Bar for Theme 4 Almanac.
/// Matches Almanac · Light.png & Almanac · Dark.png down to the exact block fills,
/// hairline dividers, uppercase tracked Space Mono typography, and tap haptics.
class AlmanacNavBar extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;

  const AlmanacNavBar({
    super.key,
    required this.selectedIndex,
    required this.onDestinationSelected,
  });

  static const List<String> _tabLabels = [
    'SCHEDULE',
    'PORTAL',
    'TOOLS',
    'SETTINGS',
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bottomInset = MediaQuery.viewPaddingOf(context).bottom;
    final ruleColor = AlmanacTokens.inkRule(isDark);

    return Container(
      decoration: BoxDecoration(
        color: AlmanacTokens.navBarBackground(isDark),
        border: Border(
          top: BorderSide(
            color: ruleColor,
            width: 1.0,
          ),
        ),
      ),
      padding: EdgeInsets.only(bottom: bottomInset),
      child: SizedBox(
        height: 56,
        child: Row(
          children: List.generate(_tabLabels.length, (index) {
            final isSelected = selectedIndex == index;
            final isLast = index == _tabLabels.length - 1;

            return Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {
                  if (selectedIndex != index) {
                    IrisHaptics.selectionClick();
                    onDestinationSelected(index);
                  }
                },
                child: Container(
                  height: double.infinity,
                  decoration: BoxDecoration(
                    color: isSelected
                        ? AlmanacTokens.navActivePill(isDark)
                        : Colors.transparent,
                    border: isLast
                        ? null
                        : Border(
                            right: BorderSide(
                              color: isDark
                                  ? ruleColor.withValues(alpha: 0.35)
                                  : ruleColor,
                              width: 1.0,
                            ),
                          ),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    _tabLabels[index],
                    style: AlmanacTokens.navLabel(
                      isActive: isSelected,
                      isDark: isDark,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}
