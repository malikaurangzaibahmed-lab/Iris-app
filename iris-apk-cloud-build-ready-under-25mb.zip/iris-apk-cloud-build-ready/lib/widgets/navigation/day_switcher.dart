import 'package:flutter/material.dart';

import '../../core/animations.dart';
import '../../core/theme_signals.dart';
import '../../core/tokens.dart';
import '../../core/vital_theme.dart';
import '../../services/ui_feedback.dart';
import '../glass_card.dart';
import 'package:iris/widgets/cards/vital_card.dart';

class DaySwitcher extends StatelessWidget {
  final int? selectedDayIndex;
  final ValueChanged<int?> onSelected;

  const DaySwitcher({
    required this.selectedDayIndex,
    required this.onSelected,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    const days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
    final today = DateTime.now().weekday; // 1=Mon
    final autoSelected = selectedDayIndex == null;
    if (ThemeSignals.isMaterialYou) {
      final cs = Theme.of(context).colorScheme;
      const m3Days = [
        {'name': 'M', 'index': 1},
        {'name': 'T', 'index': 2},
        {'name': 'W', 'index': 3},
        {'name': 'T', 'index': 4},
        {'name': 'F', 'index': 5},
        {'name': 'S', 'index': 6},
      ];
      final effectiveBg = isDark ? const Color(0xFF272A2F) : const Color(0xFFE6E8EE);

      return RepaintBoundary(
        child: Container(
        height: 48,
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: effectiveBg,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(
            color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.45),
            width: 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.20 : 0.04),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: ExpressiveSpringPress(
                onTap: () {
                  IrisHaptics.chipSelect();
                  onSelected(null);
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  curve: Curves.easeOutCubic,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: autoSelected ? cs.secondaryContainer : Colors.transparent,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.auto_awesome,
                        size: 13,
                        color: autoSelected ? cs.onSecondaryContainer : cs.onSurfaceVariant,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'Auto',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: autoSelected ? FontWeight.w800 : FontWeight.w600,
                          color: autoSelected ? cs.onSecondaryContainer : cs.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(width: 2),
            ...m3Days.map((d) {
              final dayIndex = d['index'] as int;
              final dayName = d['name'] as String;
              final isSelected = selectedDayIndex == dayIndex;
              final isCurrentDay = today == dayIndex;

              return Expanded(
                flex: 1,
                child: ExpressiveSpringPress(
                  onTap: () {
                    IrisHaptics.chipSelect();
                    onSelected(dayIndex);
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    curve: Curves.easeOutCubic,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: isSelected ? cs.secondaryContainer : Colors.transparent,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      dayName,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                        color: isSelected
                            ? cs.onSecondaryContainer
                            : (isCurrentDay ? cs.primary : cs.onSurfaceVariant),
                      ),
                    ),
                  ),
                ),
              );
            }),
          ],
        ),
      ),);
    }

    return RepaintBoundary(
      child: ValueListenableBuilder<bool>(
      valueListenable: ThemeSignals.useVitalTheme,
      builder: (context, useVital, _) {
        if (useVital && !ThemeSignals.isFluidGlass) {
          return SizedBox(
            width: double.infinity,
            child: VitalCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              backgroundColor: Colors.transparent,
              border: Border.all(color: Colors.transparent),
              child: SizedBox(
                width: double.infinity,
                height: 50,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  physics: const ButterScrollPhysics(),
                  children: [
                    const SizedBox(width: 6),
                    _buildAutoChip(context, autoSelected, isDark),
                    const SizedBox(width: 8),
                    ...List.generate(days.length, (index) {
                      final dayIndex = index + 1;
                      return _buildDayChip(context, dayIndex, days[index], selectedDayIndex == dayIndex, dayIndex == today, isDark);
                    }),
                  ],
                ),
              ),
            ),
          );
        }

        return SizedBox(
          width: double.infinity,
          child: GlassCard(
            padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 4),
            borderRadius: 28.0,
            enableOverlay: true,
            child: SizedBox(
              width: double.infinity,
              height: 50,
              child: ListView(
                scrollDirection: Axis.horizontal,
                physics: const ButterScrollPhysics(),
                children: [
                  const SizedBox(width: 6),
                  AnimatedSlide(
                    duration: IrisMotion.fast,
                    curve: IrisMotion.standard,
                    offset: autoSelected ? const Offset(0, -0.02) : Offset.zero,
                    child: AnimatedScale(
                      duration: IrisMotion.fast,
                      curve: IrisMotion.standard,
                      scale: autoSelected ? 1.025 : 1.0,
                      child: AnimatedContainer(
                        duration: IrisMotion.fast,
                        curve: IrisMotion.standard,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(999),
                          boxShadow: const [],
                        ),
                        child: ChoiceChip(
                          label: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.auto_awesome,
                                size: 13,
                                color: autoSelected
                                    ? IrisTokens.brand
                                    : isDark
                                    ? Colors.white.withValues(alpha: 0.5)
                                    : Colors.black.withValues(alpha: 0.4),
                              ),
                              const SizedBox(width: 4),
                              const Text(
                                'Auto',
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13,
                                ),
                              ),
                            ],
                          ),
                          selected: autoSelected,
                          onSelected: (_) {
                            IrisHaptics.chipSelect();
                            onSelected(null);
                          },
                          selectedColor: IrisTokens.brand.withValues(alpha: 0.20),
                          backgroundColor: isDark
                              ? Colors.white.withValues(alpha: 0.06)
                              : Colors.white.withValues(alpha: 0.88),
                          side: BorderSide(
                            color: autoSelected
                                ? IrisTokens.brand.withValues(alpha: 0.56)
                                : isDark
                                ? Colors.white.withValues(alpha: 0.12)
                                : Colors.black.withValues(alpha: 0.08),
                            width: autoSelected ? 1.4 : 1.0,
                          ),
                          labelStyle: TextStyle(
                            color: autoSelected
                                ? IrisTokens.brand
                                : isDark
                                ? Colors.white.withValues(alpha: 0.8)
                                : Colors.black.withValues(alpha: 0.65),
                          ),
                          elevation: autoSelected ? 0.6 : 0,
                          pressElevation: 1,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  ...List.generate(days.length, (index) {
                    final dayIndex = index + 1;
                    final isSelected = selectedDayIndex == dayIndex;
                    final isToday = dayIndex == today;
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: AnimatedSlide(
                        duration: IrisMotion.fast,
                        curve: IrisMotion.standard,
                        offset: isSelected ? const Offset(0, -0.02) : Offset.zero,
                        child: AnimatedScale(
                          duration: IrisMotion.fast,
                          curve: IrisMotion.standard,
                          scale: isSelected ? 1.03 : 1.0,
                          child: AnimatedContainer(
                            duration: IrisMotion.fast,
                            curve: IrisMotion.standard,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(999),
                              boxShadow: const [],
                            ),
                            child: ChoiceChip(
                              avatar: isToday && !isSelected
                                  ? Container(
                                      width: 6,
                                      height: 6,
                                      decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: IrisTokens.success,
                                      ),
                                    )
                                  : null,
                              label: Text(
                                days[index],
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13,
                                  letterSpacing: 0.3,
                                ),
                              ),
                              selected: isSelected,
                              onSelected: (_) {
                                IrisHaptics.chipSelect();
                                onSelected(dayIndex == today ? null : dayIndex);
                              },
                              selectedColor: IrisTokens.brand.withValues(alpha: 0.20),
                              backgroundColor: isDark
                                  ? Colors.white.withValues(alpha: 0.06)
                                  : Colors.white.withValues(alpha: 0.88),
                              side: BorderSide(
                                color: isSelected
                                    ? IrisTokens.brand.withValues(alpha: 0.56)
                                    : isToday
                                    ? IrisTokens.success.withValues(alpha: 0.28)
                                    : isDark
                                    ? Colors.white.withValues(alpha: 0.12)
                                    : Colors.black.withValues(alpha: 0.08),
                                width: isSelected ? 1.4 : 1.0,
                              ),
                              labelStyle: TextStyle(
                                color: isSelected
                                    ? IrisTokens.brand
                                    : isDark
                                    ? Colors.white.withValues(alpha: 0.8)
                                    : Colors.black.withValues(alpha: 0.65),
                              ),
                              elevation: isSelected ? 0.6 : 0,
                              pressElevation: 1,
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
                  const SizedBox(width: 6),
                ],
              ),
            ),
          ),
        );
      },
    ),);
  }

  Widget _buildAutoChip(BuildContext context, bool selected, bool isDark) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.auto_awesome, size: 14, color: selected ? Colors.white : (isDark ? Colors.white38 : Colors.black38)),
            const SizedBox(width: 4),
            const Text('Auto', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
          ],
        ),
        selected: selected,
        onSelected: (_) => onSelected(null),
        selectedColor: VitalTokens.blue,
        backgroundColor: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.black.withValues(alpha: 0.03),
        labelStyle: TextStyle(color: selected ? Colors.white : (isDark ? Colors.white70 : Colors.black87)),
        side: BorderSide.none,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(VitalTokens.radiusFull)),
      ),
    );
  }

  Widget _buildDayChip(BuildContext context, int index, String label, bool selected, bool isToday, bool isDark) {
    final color = isToday ? VitalTokens.green : VitalTokens.blue;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
        selected: selected,
        onSelected: (_) => onSelected(index),
        selectedColor: color,
        backgroundColor: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.black.withValues(alpha: 0.03),
        labelStyle: TextStyle(color: selected ? Colors.white : (isDark ? Colors.white70 : Colors.black87)),
        side: isToday && !selected ? BorderSide(color: color.withValues(alpha: 0.4), width: 1.5) : BorderSide.none,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(VitalTokens.radiusFull)),
      ),
    );
  }
}

