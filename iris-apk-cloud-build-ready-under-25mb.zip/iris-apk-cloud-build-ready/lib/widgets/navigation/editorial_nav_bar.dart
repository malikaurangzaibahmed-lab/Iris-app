import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/ui_feedback.dart';

/// Pixel-perfect Cozy Editorial Academic 4-Tab Bottom Navigation Bar.
/// Matches Light.png & Dark.png down to the floating rounded pill geometry,
/// warm golden amber active indicator, literary typography, and tactile haptics.
class EditorialNavBar extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;

  const EditorialNavBar({
    super.key,
    required this.selectedIndex,
    required this.onDestinationSelected,
  });

  static const List<({String label, IconData icon})> _tabs = [
    (label: 'Schedule', icon: Icons.calendar_today_rounded),
    (label: 'Portal', icon: Icons.public_rounded),
    (label: 'Tools', icon: Icons.grid_view_rounded),
    (label: 'Settings', icon: Icons.tune_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bottomInset = MediaQuery.viewPaddingOf(context).bottom;

    final Color barBg = isDark ? const Color(0xFF1E2235) : Colors.white;
    final Color activeColor = isDark ? const Color(0xFFF59E0B) : const Color(0xFFEFA335);
    final Color activeTextColor = const Color(0xFF1E1B18);
    final Color inactiveColor = isDark ? const Color(0xFF8E9BAE) : const Color(0xFF64748B);

    return SafeArea(
      top: false,
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 580),
          child: Padding(
            padding: EdgeInsets.fromLTRB(20, 0, 20, bottomInset > 0 ? 8 : 14),
            child: Container(
              height: 64,
              decoration: BoxDecoration(
                color: barBg,
                borderRadius: BorderRadius.circular(36),
                border: Border.all(
                  color: isDark ? const Color(0xFF283042) : const Color(0xFFE8E2D6),
                  width: 1.0,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.40 : 0.08),
                    offset: const Offset(0, 6),
                    blurRadius: 18,
                    spreadRadius: 0,
                  ),
                ],
              ),
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
              child: Row(
                children: List.generate(_tabs.length, (index) {
                  final tab = _tabs[index];
                  final isSelected = selectedIndex == index;

                  return Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () {
                        if (selectedIndex != index) {
                          IrisHaptics.selectionClick();
                          onDestinationSelected(index);
                        }
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 240),
                        curve: Curves.easeOutCubic,
                        decoration: BoxDecoration(
                          color: isSelected ? activeColor : Colors.transparent,
                          borderRadius: BorderRadius.circular(28),
                        ),
                        child: Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                tab.icon,
                                size: isSelected ? 20 : 18,
                                color: isSelected ? activeTextColor : inactiveColor,
                              ),
                              const SizedBox(height: 2),
                              Text(
                                tab.label,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 11,
                                  fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                                  color: isSelected ? activeTextColor : inactiveColor,
                                  letterSpacing: -0.2,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
