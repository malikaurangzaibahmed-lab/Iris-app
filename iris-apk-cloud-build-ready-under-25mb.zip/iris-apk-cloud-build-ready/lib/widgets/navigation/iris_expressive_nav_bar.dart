import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import '../../core/glass.dart';
import '../../core/sticker_tokens.dart';
import '../../core/theme_signals.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../../core/laminar_flow.dart';
import '../../services/ui_feedback.dart';

/// A destination item for [IrisExpressiveNavBar].
class ExpressiveNavDestination {
  final IconData icon;
  final IconData activeIcon;
  final String label;

  const ExpressiveNavDestination({
    required this.icon,
    required this.activeIcon,
    required this.label,
  });
}

/// Dynamic dual-theme Navigation Bar for IRIS.
///
/// Seamlessly adapts to the active theme style:
/// - **Material 3 Expressive (materialYou)**:
///   Authentic Android 15 Google Pixel navigation bar with full-width floating container,
///   solid Monet tonal surface (`surfaceContainer`), squircle selection pills
///   (`secondaryContainer`), typography labels, and pure 120 FPS flat rasterization.
/// - **Liquid Glass (fluidGlass)**:
///   Ultra-premium floating stadium capsule dock with frosted glass backdrop (16.0 blur),
///   specular rim reflections, and an animated sliding circular/capsule bubble indicator
///   with dynamic horizontal stretch physics (pure luminous white in dark mode, obsidian in light).
class IrisExpressiveNavBar extends StatefulWidget {
  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;
  final bool isFaculty;
  final bool isSearchActive;
  final ValueChanged<bool>? onSearchToggle;
  final TextEditingController? searchController;
  final FocusNode? searchFocusNode;
  final ValueChanged<String>? onSearchChanged;
  final String? searchHint;
  final VoidCallback? onOpenPaletteCustomizer;

  const IrisExpressiveNavBar({
    super.key,
    required this.selectedIndex,
    required this.onDestinationSelected,
    this.isFaculty = false,
    this.isSearchActive = false,
    this.onSearchToggle,
    this.searchController,
    this.searchFocusNode,
    this.onSearchChanged,
    this.searchHint,
    this.onOpenPaletteCustomizer,
  });

  @override
  State<IrisExpressiveNavBar> createState() => _IrisExpressiveNavBarState();
}

class _IrisExpressiveNavBarState extends State<IrisExpressiveNavBar>
    with SingleTickerProviderStateMixin {
  late final AnimationController _slideController;
  late Animation<double> _slideAnimation;
  int _lastIndex = 0;

  List<ExpressiveNavDestination> get _destinations {
    return const [
      ExpressiveNavDestination(
        icon: Icons.calendar_month_outlined,
        activeIcon: Icons.calendar_month_rounded,
        label: 'Schedule',
      ),
      ExpressiveNavDestination(
        icon: Icons.language_outlined,
        activeIcon: Icons.language_rounded,
        label: 'Portal',
      ),
      ExpressiveNavDestination(
        icon: Icons.widgets_outlined,
        activeIcon: Icons.widgets_rounded,
        label: 'Tools',
      ),
      ExpressiveNavDestination(
        icon: Icons.tune_outlined,
        activeIcon: Icons.tune_rounded,
        label: 'Settings',
      ),
    ];
  }

  @override
  void initState() {
    super.initState();
    _lastIndex = widget.selectedIndex.clamp(0, 3);
    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _slideAnimation = Tween<double>(
      begin: _lastIndex.toDouble(),
      end: _lastIndex.toDouble(),
    ).animate(
      CurvedAnimation(
        parent: _slideController,
        curve: Curves.fastOutSlowIn,
      ),
    );
  }

  @override
  void didUpdateWidget(covariant IrisExpressiveNavBar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.selectedIndex != widget.selectedIndex) {
      _lastIndex = oldWidget.selectedIndex.clamp(0, 3);
      final targetIndex = widget.selectedIndex.clamp(0, 3);
      _slideAnimation = Tween<double>(
        begin: _lastIndex.toDouble(),
        end: targetIndex.toDouble(),
      ).animate(
        CurvedAnimation(
          parent: _slideController,
          curve: LaminarCurves.laminarEntrance,
        ),
      );
      _slideController.forward(from: 0.0);
    }
  }

  @override
  void dispose() {
    _slideController.dispose();
    super.dispose();
  }

  void _handleTap(int index) {
    if (widget.selectedIndex != index) {
      IrisHaptics.selectionClick();
      widget.onDestinationSelected(index);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final screenWidth = MediaQuery.sizeOf(context).width;
    final bottomPadding = MediaQuery.viewPaddingOf(context).bottom;

    return RepaintBoundary(
      child: ValueListenableBuilder<IrisThemeStyle>(
        valueListenable: ThemeSignals.themeStyle,
        builder: (context, themeStyle, _) {
          final isM3 = themeStyle == IrisThemeStyle.materialYou;

          return AnimatedSwitcher(
            duration: const Duration(milliseconds: 250),
            switchInCurve: Curves.easeOutCubic,
            switchOutCurve: Curves.easeInCubic,
            child: isM3
                ? KeyedSubtree(
                    key: const ValueKey('navbar_theme_m3e'),
                    child: _buildMaterialExpressiveNavBar(
                      context,
                      cs,
                      isDark,
                      bottomPadding,
                    ),
                  )
                : KeyedSubtree(
                    key: ValueKey('navbar_theme_${themeStyle.name}'),
                    child: _buildLiquidGlassNavBar(
                      context,
                      cs,
                      isDark,
                      bottomPadding,
                      screenWidth,
                      themeStyle: themeStyle,
                    ),
                  ),
          );
        },
      ),
    );
  }

  // =========================================================================
  // 1. MATERIAL 3 EXPRESSIVE NAVBAR (Android 15 Google Pixel Style)
  // =========================================================================

  Widget _buildMaterialExpressiveNavBar(
    BuildContext context,
    ColorScheme cs,
    bool isDark,
    double bottomPadding,
  ) {
    final destinations = _destinations;
    final canSearch = widget.selectedIndex == 0 || widget.selectedIndex == 2;

    return SafeArea(
      top: false,
      bottom: false,
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          14,
          0,
          14,
          bottomPadding > 0 ? bottomPadding + 4 : 12,
        ),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 240),
          curve: Curves.fastOutSlowIn,
          height: 72,
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF1E2430) : const Color(0xFFFFFBF0),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(
              color: StickerTokens.inkOutline(isDark),
              width: 1.8,
            ),
            boxShadow: StickerTokens.stickerShadow(isDark, offset: 3.0),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(28),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 260),
              switchInCurve: Curves.easeOutCubic,
              switchOutCurve: Curves.easeInCubic,
              transitionBuilder: (child, animation) {
                return FadeTransition(
                  opacity: animation,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, 0.08),
                      end: Offset.zero,
                    ).animate(animation),
                    child: child,
                  ),
                );
              },
              child: widget.isSearchActive
                  ? KeyedSubtree(
                      key: const ValueKey('m3_search_bar'),
                      child: _buildM3ActiveSearchBar(cs, isDark),
                    )
                  : KeyedSubtree(
                      key: const ValueKey('m3_navigation_row'),
                      child: _buildM3NavigationRow(
                        cs,
                        isDark,
                        destinations,
                        canSearch,
                      ),
                    ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildM3NavigationRow(
    ColorScheme cs,
    bool isDark,
    List<ExpressiveNavDestination> destinations,
    bool canSearch,
  ) {
    return MediaQuery.withClampedTextScaling(
      maxScaleFactor: 1.12,
      child: Row(
        children: List.generate(destinations.length, (index) {
          final dest = destinations[index];
          final isSelected = widget.selectedIndex == index;

          return Expanded(
            child: InkWell(
              onTap: () => _handleTap(index),
              onLongPress: () {
                if (index == 0 || index == 2) {
                  IrisHaptics.actionSoft();
                  widget.onSearchToggle?.call(true);
                } else if (index == 3) {
                  IrisHaptics.actionSoft();
                  widget.onOpenPaletteCustomizer?.call();
                }
              },
              borderRadius: BorderRadius.circular(22),
              splashColor: cs.primary.withValues(alpha: 0.1),
              highlightColor: cs.primary.withValues(alpha: 0.05),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Active Squircle Pill Indicator
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 260),
                    curve: LaminarCurves.viscoelasticBounce,
                    width: isSelected ? 58 : 40,
                    height: 30,
                    decoration: BoxDecoration(
                      color: isSelected
                          ? (isDark ? const Color(0xFFC2410C) : const Color(0xFFFF8A65))
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(15),
                      border: isSelected
                          ? Border.all(
                              color: StickerTokens.inkOutline(isDark),
                              width: 1.4,
                            )
                          : null,
                      boxShadow: isSelected
                          ? [
                              BoxShadow(
                                color: isDark ? Colors.black45 : const Color(0x3B2C221A),
                                offset: const Offset(1, 1.8),
                                blurRadius: 0,
                              ),
                            ]
                          : null,
                    ),
                    child: Center(
                      child: AnimatedScale(
                        duration: const Duration(milliseconds: 220),
                        curve: Curves.easeOutBack,
                        scale: isSelected ? 1.12 : 1.0,
                        child: Icon(
                          isSelected ? dest.activeIcon : dest.icon,
                          size: 21,
                          color: isSelected
                              ? Colors.white
                              : (isDark ? const Color(0xFFCBD5E1) : const Color(0xFF3B2F25)),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 3),
                  // Label
                  AnimatedDefaultTextStyle(
                    duration: const Duration(milliseconds: 200),
                    style: GoogleFonts.poppins(
                      fontSize: isSelected ? 11.5 : 11,
                      fontWeight: isSelected ? FontWeight.w900 : FontWeight.w600,
                      color: isSelected
                          ? (isDark ? Colors.white : const Color(0xFF2C1810))
                          : (isDark ? const Color(0xFF94A3B8) : const Color(0xFF645345)),
                      letterSpacing: isSelected ? 0.2 : 0.1,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    child: Text(dest.label),
                  ),
                ],
              ),
            ),
          );
        }),
    ),
  );
}

  Widget _buildM3ActiveSearchBar(ColorScheme cs, bool isDark) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: cs.primaryContainer,
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.search_rounded,
              color: cs.onPrimaryContainer,
              size: 20,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: widget.searchController,
              focusNode: widget.searchFocusNode,
              autofocus: true,
              style: TextStyle(
                color: cs.onSurface,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
              decoration: InputDecoration(
                hintText: widget.searchHint ?? 'Search...',
                hintStyle: TextStyle(
                  color: cs.onSurfaceVariant.withValues(alpha: 0.65),
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 8),
              ),
              onChanged: widget.onSearchChanged,
            ),
          ),
          if (widget.searchController != null &&
              widget.searchController!.text.isNotEmpty)
            IconButton(
              icon: Icon(Icons.clear_rounded, size: 18, color: cs.onSurfaceVariant),
              visualDensity: VisualDensity.compact,
              constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
              onPressed: () {
                IrisHaptics.actionSoft();
                widget.searchController?.clear();
                widget.onSearchChanged?.call('');
                setState(() {});
              },
            ),
          IconButton.filledTonal(
            icon: const Icon(Icons.close_rounded, size: 18),
            style: IconButton.styleFrom(
              backgroundColor: cs.surfaceContainerHighest,
              foregroundColor: cs.onSurfaceVariant,
              visualDensity: VisualDensity.compact,
            ),
            onPressed: () {
              IrisHaptics.actionSoft();
              widget.onSearchToggle?.call(false);
            },
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // 2. LIQUID GLASS NAVBAR (Floating Capsule Dock with Sliding Bubble)
  // =========================================================================

  Widget _buildLiquidGlassNavBar(
    BuildContext context,
    ColorScheme cs,
    bool isDark,
    double bottomPadding,
    double screenWidth, {
    IrisThemeStyle themeStyle = IrisThemeStyle.fluidGlass,
  }) {
    final double dockWidth = widget.isSearchActive
        ? (screenWidth - 32.0).clamp(280.0, 520.0)
        : math.min(screenWidth - 32.0, 276.0);
    const double dockHeight = 58.0;
    const double dockRadius = 29.0;

    return Align(
      alignment: Alignment.bottomCenter,
      child: SafeArea(
        top: false,
        left: false,
        right: false,
        bottom: true,
        minimum: EdgeInsets.only(
          bottom: bottomPadding > 0 ? 8 : 16,
        ),
        child: ValueListenableBuilder<double>(
          valueListenable: ThemeSignals.glassTransparency,
          builder: (context, transparency, _) {
            final isOpaque = transparency <= 0.08;
            final double navBlur = themeStyle == IrisThemeStyle.fluidGlass
                ? (isOpaque ? 0.0 : lerpDouble(6.0, 22.0, transparency)!)
                : 0.0;

            Color dockColor;
            Border dockBorder;
            List<BoxShadow> dockShadow;

            switch (themeStyle) {
              case IrisThemeStyle.notebook:
                dockColor = NotebookTokens.navBarBackground(isDark);
                dockBorder = Border.all(
                  color: NotebookTokens.navBarBorder(isDark),
                  width: 1.6,
                );
                dockShadow = [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ];
                break;
              case IrisThemeStyle.line:
                dockColor = LineTokens.navBarBackground(isDark);
                dockBorder = Border.all(
                  color: LineTokens.railLine(isDark),
                  width: 2.0,
                );
                dockShadow = [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ];
                break;
              case IrisThemeStyle.poster:
                dockColor = PosterTokens.navBarBackground(isDark);
                dockBorder = Border.all(
                  color: PosterTokens.inkBorder(isDark),
                  width: 2.4,
                );
                dockShadow = [
                  BoxShadow(
                    color: PosterTokens.inkBorder(isDark),
                    offset: const Offset(2, 3),
                    blurRadius: 0,
                  ),
                ];
                break;
              case IrisThemeStyle.almanac:
                dockColor = AlmanacTokens.navBarBackground(isDark);
                dockBorder = Border.all(
                  color: AlmanacTokens.inkRule(isDark),
                  width: 1.4,
                );
                dockShadow = [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ];
                break;
              case IrisThemeStyle.editorialAcademic:
                dockColor = EditorialTokens.cardSurface(isDark);
                dockBorder = Border.all(
                  color: EditorialTokens.cardBorder(isDark),
                  width: 1.4,
                );
                dockShadow = [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ];
                break;
              case IrisThemeStyle.fluidGlass:
              case IrisThemeStyle.materialYou:
                dockColor = isDark
                    ? const Color(0xFF101216).withValues(
                        alpha: isOpaque ? 0.98 : lerpDouble(0.98, 0.58, transparency)!,
                      )
                    : Colors.white.withValues(
                        alpha: isOpaque ? 0.98 : lerpDouble(0.98, 0.62, transparency)!,
                      );
                dockBorder = Border.all(
                  color: isDark
                      ? Colors.white.withValues(alpha: isOpaque ? 0.12 : 0.16)
                      : (isOpaque ? Colors.black.withValues(alpha: 0.08) : Colors.white.withValues(alpha: 0.90)),
                  width: 1.2,
                );
                dockShadow = [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.45 : 0.10),
                    blurRadius: 24,
                    offset: const Offset(0, 8),
                  ),
                ];
                break;
            }

            final innerSwitcher = AnimatedSwitcher(
              duration: const Duration(milliseconds: 240),
              switchInCurve: Curves.easeOutCubic,
              switchOutCurve: Curves.easeInCubic,
              child: widget.isSearchActive
                  ? KeyedSubtree(
                      key: const ValueKey('glass_search_active'),
                      child: _buildGlassActiveSearchBar(isDark),
                    )
                  : KeyedSubtree(
                      key: const ValueKey('glass_tabs_active'),
                      child: _buildGlassTabsRow(isDark, dockWidth, themeStyle: themeStyle),
                    ),
            );

            if (themeStyle == IrisThemeStyle.fluidGlass && !isOpaque) {
              return lgw.GlassBackdropGroup(
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 260),
                  curve: Curves.fastOutSlowIn,
                  width: dockWidth,
                  height: dockHeight,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(dockRadius),
                    boxShadow: dockShadow,
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(dockRadius),
                    child: GlassSurface(
                      settings: IrisGlass.settings(
                        context,
                        blur: navBlur,
                        thickness: 20.0,
                        ambientStrength: 0.82,
                        lightAngle: 0.15 * math.pi,
                        glassColor: dockColor,
                        specularSharpness: lgw.GlassSpecularSharpness.sharp,
                      ),
                      radius: dockRadius,
                      applyInLayer: true,
                      quality: lgw.GlassQuality.premium,
                      borderSide: dockBorder.top,
                      child: innerSwitcher,
                    ),
                  ),
                ),
              );
            }

            return AnimatedContainer(
              duration: const Duration(milliseconds: 260),
              curve: Curves.fastOutSlowIn,
              width: dockWidth,
              height: dockHeight,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(dockRadius),
                child: IrisGlass.backdropFilter(
                  sigmaX: navBlur,
                  sigmaY: navBlur,
                  child: Container(
                    decoration: BoxDecoration(
                      color: dockColor,
                      borderRadius: BorderRadius.circular(dockRadius),
                      border: dockBorder,
                      boxShadow: dockShadow,
                    ),
                    child: innerSwitcher,
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildGlassTabsRow(
    bool isDark,
    double dockWidth, {
    IrisThemeStyle themeStyle = IrisThemeStyle.fluidGlass,
  }) {
    final destinations = _destinations;
    const double horizontalPadding = 6.0;
    const double thumbBaseSize = 46.0;

    Color thumbColor;
    Border? thumbBorder;
    List<BoxShadow> thumbShadow;
    Color activeIconColor;
    Color inactiveIconColor;

    switch (themeStyle) {
      case IrisThemeStyle.notebook:
        thumbColor = NotebookTokens.navActivePill(isDark);
        thumbBorder = Border.all(
          color: NotebookTokens.marginRule(isDark),
          width: 1.2,
        );
        thumbShadow = [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.12),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ];
        activeIconColor = NotebookTokens.navActiveText(isDark);
        inactiveIconColor = NotebookTokens.navInactiveText(isDark);
        break;
      case IrisThemeStyle.line:
        thumbColor = LineTokens.navActivePill(isDark);
        thumbBorder = null;
        thumbShadow = [
          BoxShadow(
            color: LineTokens.railLine(isDark).withValues(alpha: 0.35),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ];
        activeIconColor = LineTokens.navActiveText(isDark);
        inactiveIconColor = LineTokens.navInactiveText(isDark);
        break;
      case IrisThemeStyle.poster:
        thumbColor = PosterTokens.navActiveBlock(isDark);
        thumbBorder = Border.all(
          color: PosterTokens.inkBorder(isDark),
          width: 1.8,
        );
        thumbShadow = [
          BoxShadow(
            color: PosterTokens.inkBorder(isDark),
            offset: const Offset(1.5, 2),
            blurRadius: 0,
          ),
        ];
        activeIconColor = PosterTokens.navActiveText(isDark);
        inactiveIconColor = PosterTokens.navInactiveText(isDark);
        break;
      case IrisThemeStyle.almanac:
        thumbColor = AlmanacTokens.navActivePill(isDark);
        thumbBorder = Border.all(
          color: AlmanacTokens.inkRule(isDark),
          width: 1.0,
        );
        thumbShadow = [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.30 : 0.10),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ];
        activeIconColor = AlmanacTokens.navActiveText(isDark);
        inactiveIconColor = AlmanacTokens.navInactiveText(isDark);
        break;
      case IrisThemeStyle.editorialAcademic:
        thumbColor = isDark ? const Color(0xFF6366F1) : const Color(0xFF4F46E5);
        thumbBorder = null;
        thumbShadow = [
          BoxShadow(
            color: const Color(0xFF6366F1).withValues(alpha: 0.35),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ];
        activeIconColor = Colors.white;
        inactiveIconColor = EditorialTokens.inkMuted(isDark);
        break;
      case IrisThemeStyle.fluidGlass:
      case IrisThemeStyle.materialYou:
        thumbColor = isDark ? Colors.white : const Color(0xFF14161C);
        thumbBorder = themeStyle == IrisThemeStyle.fluidGlass
            ? Border.all(
                color: isDark
                    ? Colors.white.withValues(alpha: 0.92)
                    : const Color(0xFF38BDF8).withValues(alpha: 0.45),
                width: 1.2,
              )
            : null;
        thumbShadow = [
          BoxShadow(
            color: (isDark ? Colors.white : Colors.black).withValues(
              alpha: isDark ? 0.32 : 0.22,
            ),
            blurRadius: 14,
            offset: const Offset(0, 3),
          ),
        ];
        activeIconColor = isDark ? const Color(0xFF0F1115) : Colors.white;
        inactiveIconColor = isDark
            ? Colors.white.withValues(alpha: 0.55)
            : Colors.black.withValues(alpha: 0.45);
        break;
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final double actualAvailableWidth = constraints.maxWidth - (horizontalPadding * 2);
        final double slotWidth = actualAvailableWidth / destinations.length;

        return AnimatedBuilder(
          animation: _slideController,
          builder: (context, _) {
            final currentPos = _slideAnimation.value;
            final progress = _slideController.value;
            // Horizontal stretch physics during transit
            final stretch = math.sin(progress * math.pi) * (themeStyle == IrisThemeStyle.fluidGlass ? 11.0 : 8.0);
            final currentThumbWidth = thumbBaseSize + stretch;
            final thumbLeft = horizontalPadding +
                (currentPos * slotWidth) +
                ((slotWidth - currentThumbWidth) / 2);

            return Stack(
              alignment: Alignment.centerLeft,
              children: [
                // 1. Sliding Bubble Indicator
                Positioned(
                  left: thumbLeft,
                  top: (58.0 - thumbBaseSize) / 2,
                  width: currentThumbWidth,
                  height: thumbBaseSize,
                  child: Container(
                    decoration: BoxDecoration(
                      color: thumbColor,
                      borderRadius: BorderRadius.circular(thumbBaseSize / 2),
                      border: thumbBorder,
                      boxShadow: thumbShadow,
                    ),
                  ),
                ),

                // 2. Interactive Destination Tab Icons
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: horizontalPadding,
                  ),
                  child: Row(
                    children: List.generate(destinations.length, (index) {
                      final dest = destinations[index];
                      final isSelected = widget.selectedIndex == index;

                      return Expanded(
                        child: SizedBox(
                          height: 58.0,
                          child: GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onTap: () => _handleTap(index),
                            onLongPress: () {
                              if (index == 0 || index == 2) {
                                // Quick search activation on Schedule or Tools
                                IrisHaptics.actionSoft();
                                widget.onSearchToggle?.call(true);
                              } else if (index == 3) {
                                // Quick customizer on Settings
                                IrisHaptics.actionSoft();
                                widget.onOpenPaletteCustomizer?.call();
                              }
                            },
                            child: Center(
                              child: AnimatedScale(
                                duration: const Duration(milliseconds: 200),
                                curve: Curves.easeOutBack,
                                scale: isSelected ? 1.08 : 1.0,
                                child: Icon(
                                  isSelected ? dest.activeIcon : dest.icon,
                                  size: 22,
                                  color: isSelected
                                      ? activeIconColor
                                      : inactiveIconColor,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    }),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildGlassActiveSearchBar(bool isDark) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: isDark
                  ? Colors.white.withValues(alpha: 0.15)
                  : Colors.black.withValues(alpha: 0.08),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.search_rounded,
              color: isDark ? Colors.white : Colors.black87,
              size: 20,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: widget.searchController,
              focusNode: widget.searchFocusNode,
              autofocus: true,
              style: TextStyle(
                color: isDark ? Colors.white : Colors.black,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
              decoration: InputDecoration(
                hintText: widget.searchHint ?? 'Search...',
                hintStyle: TextStyle(
                  color: isDark ? Colors.white38 : Colors.black38,
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 8),
              ),
              onChanged: widget.onSearchChanged,
            ),
          ),
          if (widget.searchController != null &&
              widget.searchController!.text.isNotEmpty)
            IconButton(
              icon: Icon(
                Icons.clear_rounded,
                size: 18,
                color: isDark ? Colors.white70 : Colors.black54,
              ),
              visualDensity: VisualDensity.compact,
              constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
              padding: EdgeInsets.zero,
              onPressed: () {
                IrisHaptics.actionSoft();
                widget.searchController?.clear();
                widget.onSearchChanged?.call('');
                setState(() {});
              },
            ),
          IconButton.filledTonal(
            icon: const Icon(Icons.close_rounded, size: 18),
            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
            padding: EdgeInsets.zero,
            style: IconButton.styleFrom(
              backgroundColor: isDark
                  ? Colors.white.withValues(alpha: 0.12)
                  : Colors.black.withValues(alpha: 0.08),
              foregroundColor: isDark ? Colors.white : Colors.black87,
              visualDensity: VisualDensity.compact,
            ),
            onPressed: () {
              IrisHaptics.actionSoft();
              widget.onSearchToggle?.call(false);
            },
          ),
        ],
      ),
    );
  }
}

/// Animated tab stack that smoothly transitions between navigation tabs with
/// authentic Android 15 Material 3 Expressive motion (shared-axis slide, zoom-fade)
/// while strictly preserving state (WebViews, scroll offsets, form fields).
class IrisExpressiveTabStack extends StatefulWidget {
  final int index;
  final int slideDirection;
  final List<Widget> children;

  const IrisExpressiveTabStack({
    super.key,
    required this.index,
    this.slideDirection = 1,
    required this.children,
  });

  @override
  State<IrisExpressiveTabStack> createState() => _IrisExpressiveTabStackState();
}

class _IrisExpressiveTabStackState extends State<IrisExpressiveTabStack>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _animation;
  late Animation<Offset> _inSlideAnimation;
  late Animation<double> _inFadeAnimation;
  late Animation<Offset> _outSlideAnimation;
  late Animation<double> _outFadeAnimation;

  int _lastIndex = 0;
  int _direction = 1;

  @override
  void initState() {
    super.initState();
    _lastIndex = widget.index;
    _direction = widget.slideDirection;
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 240),
    );
    _animation = CurvedAnimation(
      parent: _controller,
      curve: Curves.fastOutSlowIn,
    );
    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        if (mounted) setState(() {});
      }
    });
    _updateAnimations();
    _controller.value = 1.0;
  }

  void _updateAnimations() {
    _inSlideAnimation = Tween<Offset>(
      begin: Offset(0.035 * _direction, 0.0),
      end: Offset.zero,
    ).animate(_animation);
    _inFadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(_animation);

    _outSlideAnimation = Tween<Offset>(
      begin: Offset.zero,
      end: Offset(-0.02 * _direction, 0.0),
    ).animate(_animation);
    _outFadeAnimation = Tween<double>(
      begin: 1.0,
      end: 0.0,
    ).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.55, curve: Curves.easeOut),
      ),
    );
  }

  @override
  void didUpdateWidget(covariant IrisExpressiveTabStack oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.index != oldWidget.index) {
      _lastIndex = oldWidget.index;
      _direction = widget.slideDirection;
      _updateAnimations();
      _controller.forward(from: 0.0);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isAnimating = _controller.isAnimating;

    return Stack(
      fit: StackFit.expand,
      children: List.generate(widget.children.length, (i) {
        final isCurrent = i == widget.index;
        final isLast = i == _lastIndex && isAnimating;

        if (!isCurrent && !isLast) {
          return Offstage(
            offstage: true,
            child: TickerMode(
              enabled: false,
              child: RepaintBoundary(child: widget.children[i]),
            ),
          );
        }

        if (isLast) {
          return IgnorePointer(
            child: SlideTransition(
              position: _outSlideAnimation,
              child: FadeTransition(
                opacity: _outFadeAnimation,
                child: TickerMode(
                  enabled: false,
                  child: RepaintBoundary(child: widget.children[i]),
                ),
              ),
            ),
          );
        }

        // Current active tab: if not animating, render directly with zero matrix overhead
        if (!isAnimating) {
          return TickerMode(
            enabled: true,
            child: RepaintBoundary(child: widget.children[i]),
          );
        }

        return SlideTransition(
          position: _inSlideAnimation,
          child: FadeTransition(
            opacity: _inFadeAnimation,
            child: TickerMode(
              enabled: true,
              child: RepaintBoundary(child: widget.children[i]),
            ),
          ),
        );
      }),
    );
  }
}