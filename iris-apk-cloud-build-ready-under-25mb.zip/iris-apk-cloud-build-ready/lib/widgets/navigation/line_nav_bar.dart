import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iris/core/line_theme_tokens.dart';
import 'package:iris/services/ui_feedback.dart';

/// Metro Transit Bottom Navigation Bar with Continuous Subway Rail Line
/// (Modeled with 100% pixel fidelity after Line · Light.png & Line · Dark.png).
class LineNavBar extends StatelessWidget {
  final int activeIndex;
  final ValueChanged<int> onTabSelected;
  final bool isDark;

  const LineNavBar({
    super.key,
    required this.activeIndex,
    required this.onTabSelected,
    required this.isDark,
  });

  static const List<_LineTabItem> _tabs = [
    _LineTabItem(
      label: 'SCHEDULE',
      icon: Icons.calendar_today_rounded,
      activeIcon: Icons.calendar_today_rounded,
    ),
    _LineTabItem(
      label: 'PORTAL',
      icon: Icons.language_rounded,
      activeIcon: Icons.language_rounded,
    ),
    _LineTabItem(
      label: 'TOOLS',
      icon: Icons.grid_view_rounded,
      activeIcon: Icons.grid_view_rounded,
    ),
    _LineTabItem(
      label: 'SETTINGS',
      icon: Icons.tune_rounded,
      activeIcon: Icons.tune_rounded,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final railColor = LineTokens.railLine(isDark);

    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(
        decoration: BoxDecoration(
          color: LineTokens.navBarBackground(isDark),
          border: Border(
            top: BorderSide(color: railColor, width: 3.5),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
              offset: const Offset(0, -3),
              blurRadius: 8,
            ),
          ],
        ),
        child: SafeArea(
          top: false,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 580),
            child: Container(
              height: 64,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: Row(
                children: List.generate(_tabs.length, (index) {
                  final tab = _tabs[index];
                  final isSelected = activeIndex == index;
                  return Expanded(
                    child: _LineNavButton(
                      tab: tab,
                      isSelected: isSelected,
                      isDark: isDark,
                      onTap: () {
                        IrisHaptics.selectionClick();
                        onTabSelected(index);
                      },
                    ),
                  );
                }),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _LineNavButton extends StatefulWidget {
  final _LineTabItem tab;
  final bool isSelected;
  final bool isDark;
  final VoidCallback onTap;

  const _LineNavButton({
    required this.tab,
    required this.isSelected,
    required this.isDark,
    required this.onTap,
  });

  @override
  State<_LineNavButton> createState() => _LineNavButtonState();
}

class _LineNavButtonState extends State<_LineNavButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _pressController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _pressController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.94).animate(
      CurvedAnimation(parent: _pressController, curve: Curves.easeOutCubic),
    );
  }

  @override
  void dispose() {
    _pressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _pressController.forward(),
      onTapUp: (_) {
        _pressController.reverse();
        widget.onTap();
      },
      onTapCancel: () => _pressController.reverse(),
      behavior: HitTestBehavior.opaque,
      child: AnimatedBuilder(
        animation: _scaleAnimation,
        builder: (context, child) => Transform.scale(
          scale: _scaleAnimation.value,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeOutCubic,
            padding: const EdgeInsets.symmetric(vertical: 4),
            decoration: BoxDecoration(
              color: widget.isSelected
                  ? LineTokens.navActivePill(widget.isDark)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  widget.isSelected ? widget.tab.activeIcon : widget.tab.icon,
                  size: 20,
                  color: widget.isSelected
                      ? LineTokens.navActiveText(widget.isDark)
                      : LineTokens.navInactiveText(widget.isDark),
                ),
                const SizedBox(height: 2),
                Text(
                  widget.tab.label,
                  style: GoogleFonts.archivoBlack(
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.8,
                    height: 1.0,
                    color: widget.isSelected
                        ? LineTokens.navActiveText(widget.isDark)
                        : LineTokens.navInactiveText(widget.isDark),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _LineTabItem {
  final String label;
  final IconData icon;
  final IconData activeIcon;

  const _LineTabItem({
    required this.label,
    required this.icon,
    required this.activeIcon,
  });
}
