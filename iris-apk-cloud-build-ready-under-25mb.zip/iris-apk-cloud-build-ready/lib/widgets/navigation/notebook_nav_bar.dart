import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iris/core/notebook_theme_tokens.dart';
import 'package:iris/services/ui_feedback.dart';

/// Authentic hand-drawn student notebook bottom navigation bar
/// (Modeled after Notebook · Light.png & Notebook · Dark.png).
/// Features a stitched dashed border, tactile yellow sticky tab active indicator,
/// and handwritten script labels with authentic spring haptic response.
class NotebookNavBar extends StatelessWidget {
  final int activeIndex;
  final ValueChanged<int> onTabSelected;
  final bool isDark;

  const NotebookNavBar({
    super.key,
    required this.activeIndex,
    required this.onTabSelected,
    required this.isDark,
  });

  static const List<_NotebookTabItem> _tabs = [
    _NotebookTabItem(
      label: 'Schedule',
      icon: Icons.calendar_today_rounded,
      activeIcon: Icons.calendar_today_rounded,
    ),
    _NotebookTabItem(
      label: 'Portal',
      icon: Icons.language_rounded,
      activeIcon: Icons.language_rounded,
    ),
    _NotebookTabItem(
      label: 'Tools',
      icon: Icons.grid_view_rounded,
      activeIcon: Icons.grid_view_rounded,
    ),
    _NotebookTabItem(
      label: 'Settings',
      icon: Icons.tune_rounded,
      activeIcon: Icons.tune_rounded,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.only(bottom: 18, left: 20, right: 20),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: CustomPaint(
              painter: _DashedStitchBorderPainter(
                color: NotebookTokens.navBarBorder(isDark),
                backgroundColor: NotebookTokens.navBarBackground(isDark),
                borderRadius: 28.0,
              ),
              child: Container(
                height: 66,
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: Row(
                  children: List.generate(_tabs.length, (index) {
                    final tab = _tabs[index];
                    final isSelected = activeIndex == index;
                    return Expanded(
                      child: _NotebookNavButton(
                        tab: tab,
                        isSelected: isSelected,
                        isDark: isDark,
                        onTap: () {
                          IrisHaptics.selectionClick();
                          onTabSelected(index);
                        },
                      ),
                    );
                  }),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _NotebookNavButton extends StatefulWidget {
  final _NotebookTabItem tab;
  final bool isSelected;
  final bool isDark;
  final VoidCallback onTap;

  const _NotebookNavButton({
    required this.tab,
    required this.isSelected,
    required this.isDark,
    required this.onTap,
  });

  @override
  State<_NotebookNavButton> createState() => _NotebookNavButtonState();
}

class _NotebookNavButtonState extends State<_NotebookNavButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _pressController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _pressController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.94).animate(
      CurvedAnimation(parent: _pressController, curve: Curves.easeOutCubic),
    );
  }

  @override
  void dispose() {
    _pressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _pressController.forward(),
      onTapUp: (_) {
        _pressController.reverse();
        widget.onTap();
      },
      onTapCancel: () => _pressController.reverse(),
      behavior: HitTestBehavior.opaque,
      child: AnimatedBuilder(
        animation: _scaleAnimation,
        builder: (context, child) => Transform.scale(
          scale: _scaleAnimation.value,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOutBack,
            padding: const EdgeInsets.symmetric(vertical: 2),
            decoration: BoxDecoration(
              color: widget.isSelected
                  ? NotebookTokens.stickyYellowLight
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(16),
              boxShadow: widget.isSelected
                  ? [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.12),
                        offset: const Offset(0, 2),
                        blurRadius: 4,
                      ),
                    ]
                  : null,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  widget.isSelected ? widget.tab.activeIcon : widget.tab.icon,
                  size: 20,
                  color: widget.isSelected
                      ? NotebookTokens.navActiveText(widget.isDark)
                      : NotebookTokens.navInactiveText(widget.isDark),
                ),
                const SizedBox(height: 2),
                Text(
                  widget.tab.label,
                  style: GoogleFonts.kalam(
                    fontSize: 12,
                    fontWeight: widget.isSelected ? FontWeight.w700 : FontWeight.w600,
                    height: 1.0,
                    color: widget.isSelected
                        ? NotebookTokens.navActiveText(widget.isDark)
                        : NotebookTokens.navInactiveText(widget.isDark),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _NotebookTabItem {
  final String label;
  final IconData icon;
  final IconData activeIcon;

  const _NotebookTabItem({
    required this.label,
    required this.icon,
    required this.activeIcon,
  });
}

/// Paints a dashed sewing stitch border with soft pill background.
class _DashedStitchBorderPainter extends CustomPainter {
  final Color color;
  final Color backgroundColor;
  final double borderRadius;

  _DashedStitchBorderPainter({
    required this.color,
    required this.backgroundColor,
    required this.borderRadius,
  });

  @override
  void paint(Canvas canvas, Size size) {
    // 1. Fill pill background
    final bgPaint = Paint()
      ..color = backgroundColor
      ..style = PaintingStyle.fill;
    final rrect = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Radius.circular(borderRadius),
    );
    canvas.drawRRect(rrect, bgPaint);

    // 2. Subtle drop shadow
    final shadowPaint = Paint()
      ..color = Colors.black.withValues(alpha: 0.08)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
    canvas.save();
    canvas.translate(0, 3);
    canvas.drawRRect(rrect, shadowPaint);
    canvas.restore();

    // Redraw bg over shadow
    canvas.drawRRect(rrect, bgPaint);

    // 3. Draw dashed stitch border
    final stitchPaint = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;

    final path = Path()..addRRect(rrect.deflate(1.5));
    final metrics = path.computeMetrics();
    const dashWidth = 5.0;
    const dashSpace = 4.0;

    for (final metric in metrics) {
      double distance = 0.0;
      while (distance < metric.length) {
        final length = (distance + dashWidth < metric.length)
            ? dashWidth
            : metric.length - distance;
        final extractPath = metric.extractPath(distance, distance + length);
        canvas.drawPath(extractPath, stitchPaint);
        distance += dashWidth + dashSpace;
      }
    }
  }

  @override
  bool shouldRepaint(covariant _DashedStitchBorderPainter oldDelegate) {
    return oldDelegate.color != color ||
        oldDelegate.backgroundColor != backgroundColor ||
        oldDelegate.borderRadius != borderRadius;
  }
}
