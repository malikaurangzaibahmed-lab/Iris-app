import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iris/core/poster_theme_tokens.dart';
import 'package:iris/services/ui_feedback.dart';

/// Authentic Swiss Brutalist Bottom Navigation Bar
/// (Modeled with 100% pixel fidelity after Poster · Light.png & Poster · Dark.png).
/// Features a heavy-bordered monolithic segmented dock, international orange active block,
/// and tactile 3D extruded drop-shadow.
class PosterNavBar extends StatelessWidget {
  final int activeIndex;
  final ValueChanged<int> onTabSelected;
  final bool isDark;

  const PosterNavBar({
    super.key,
    required this.activeIndex,
    required this.onTabSelected,
    required this.isDark,
  });

  static const List<String> _tabLabels = [
    'SCHEDULE',
    'PORTAL',
    'TOOLS',
    'SETTINGS',
  ];

  @override
  Widget build(BuildContext context) {
    final borderColor = PosterTokens.inkBorder(isDark);

    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(
        decoration: BoxDecoration(
          color: PosterTokens.navBarBackground(isDark),
          border: Border(
            top: BorderSide(color: borderColor, width: 2.5),
          ),
          boxShadow: [
            BoxShadow(
              color: isDark ? Colors.black : Colors.black.withValues(alpha: 0.15),
              offset: const Offset(0, -3),
              blurRadius: 0,
            ),
          ],
        ),
        child: SafeArea(
          top: false,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 580),
            child: SizedBox(
              height: 62,
              child: Row(
                children: List.generate(_tabLabels.length, (index) {
                  final label = _tabLabels[index];
                  final isSelected = activeIndex == index;
                  final isLast = index == _tabLabels.length - 1;

                  return Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border(
                          right: isLast
                              ? BorderSide.none
                              : BorderSide(color: borderColor, width: 2.0),
                        ),
                      ),
                      child: _PosterNavButton(
                        label: label,
                        isSelected: isSelected,
                        isDark: isDark,
                        onTap: () {
                          IrisHaptics.selectionClick();
                          onTabSelected(index);
                        },
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _PosterNavButton extends StatefulWidget {
  final String label;
  final bool isSelected;
  final bool isDark;
  final VoidCallback onTap;

  const _PosterNavButton({
    required this.label,
    required this.isSelected,
    required this.isDark,
    required this.onTap,
  });

  @override
  State<_PosterNavButton> createState() => _PosterNavButtonState();
}

class _PosterNavButtonState extends State<_PosterNavButton> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    final bgColor = widget.isSelected
        ? PosterTokens.orangeHero
        : (widget.isDark ? const Color(0xFF101419) : const Color(0xFFEBE8E1));

    final textColor = widget.isSelected
        ? Colors.black
        : (widget.isDark ? Colors.white : Colors.black);

    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) {
        setState(() => _isPressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _isPressed = false),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        color: _isPressed
            ? (widget.isSelected ? const Color(0xFFE03810) : bgColor.withValues(alpha: 0.8))
            : bgColor,
        child: Center(
          child: Text(
            widget.label,
            style: GoogleFonts.archivoBlack(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.6,
              color: textColor,
            ),
          ),
        ),
      ),
    );
  }
}
