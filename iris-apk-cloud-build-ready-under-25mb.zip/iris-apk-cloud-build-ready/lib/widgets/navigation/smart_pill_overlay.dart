import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/glass.dart';
import '../../core/theme_signals.dart';
import '../../core/material_you_theme.dart';
import '../../services/system_broadcast_service.dart';
import '../../core/tokens.dart';
import '../../core/animations.dart';
import '../../core/laminar_flow.dart';

/// A global wrapper widget that listens to the SystemBroadcastService.
/// Wrap this around your MaterialApp's home route, or your dashboard Scaffold,
/// and it will automatically pop the "Smart Pill" whenever an announcement drops or deep sync runs.
class SmartPillOverlay extends StatefulWidget {
  final Widget child; // The main screen content

  const SmartPillOverlay({super.key, required this.child});

  @override
  State<SmartPillOverlay> createState() => _SmartPillOverlayState();
}

class _SmartPillOverlayState extends State<SmartPillOverlay>
    with TickerProviderStateMixin {
  late StreamSubscription _sub;
  String _title = "";
  String _body = "";
  bool _isUrgent = false;
  bool _isVisible = false;
  bool _isPersistent = false;
  Timer? _hideTimer;
  VoidCallback? _onTap;
  IconData? _customIcon;

  late AnimationController _animController;
  late Animation<double> _scaleAnim;
  late Animation<double> _fadeAnim;
  late AnimationController _liquidController;
  late AnimationController _shimmerController;
  Offset _targetTilt = Offset.zero;
  double _dragY = 0.0;
  bool _isDragging = false;

  @override
  void initState() {
    super.initState();
    // Glassmorphic Spring Animation with ColorOS 17 Laminar Living Flow Curves
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 460),
    );
    _scaleAnim = Tween<double>(begin: 0.82, end: 1.0).animate(
      CurvedAnimation(parent: _animController, curve: LaminarCurves.viscoelasticBounce),
    );
    _fadeAnim = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _animController, curve: LaminarCurves.laminarEntrance));

    _liquidController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    );

    _shimmerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    );

    // Listen to the Unified Broadcast Stream
    _sub = SystemBroadcastService().stream.listen((payload) {
      if (payload['dismiss'] == true) {
        _hide();
      } else {
        final durationMs = payload['durationMs'] as int?;
        final onTap = payload['onTap'] as VoidCallback?;
        final icon = payload['icon'] as IconData?;
        _show(
          payload['title'] ?? '',
          payload['body'] ?? '',
          payload['isUrgent'] == true,
          isPersistent: payload['isPersistent'] == true,
          duration: durationMs != null
              ? Duration(milliseconds: durationMs)
              : null,
          onTap: onTap,
          icon: icon,
        );
      }
    });
  }

  @override
  void dispose() {
    _sub.cancel();
    _hideTimer?.cancel();
    _animController.dispose();
    _liquidController.dispose();
    _shimmerController.dispose();
    super.dispose();
  }

  void _show(
    String title,
    String body,
    bool isUrgent, {
    bool isPersistent = false,
    Duration? duration,
    VoidCallback? onTap,
    IconData? icon,
  }) {
    setState(() {
      _title = title;
      _body = body;
      _isUrgent = isUrgent;
      _isPersistent = isPersistent;
      _isVisible = true;
      _onTap = onTap;
      _customIcon = icon;
    });

    // Fire the animation
    _animController.forward(from: 0.0);
    if (ThemeSignals.isFluidGlass) {
      if (!_liquidController.isAnimating) _liquidController.repeat();
      if (!_shimmerController.isAnimating) _shimmerController.repeat();
    }

    _hideTimer?.cancel();
    if (!isPersistent) {
      final hold = duration ?? const Duration(seconds: 4);
      _hideTimer = Timer(hold, () {
        _hide();
      });
    }
  }

  void _hide() {
    _liquidController.stop();
    _shimmerController.stop();
    _animController.reverse().then((_) {
      if (mounted) {
        setState(() {
          _isVisible = false;
          _dragY = 0.0;
          _targetTilt = Offset.zero;
          _isDragging = false;
          _onTap = null;
          _customIcon = null;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Stack(
      children: [
        // The background app
        widget.child,

        // The Smart Pill Override
        if (_isVisible)
          Positioned(
            top:
                MediaQuery.paddingOf(context).top +
                10, // Notch-aware floating offset
            left: 16,
            right: 16,
            child: AnimatedBuilder(
              animation: _animController,
              builder: (context, child) {
                return Opacity(
                  opacity: _fadeAnim.value,
                  child: Transform.scale(scale: _scaleAnim.value, child: child),
                );
              },
              child: GestureDetector(
                onTap: () {
                  if (_onTap != null) {
                    final callback = _onTap!;
                    _hide();
                    callback();
                  }
                },
                onPanStart: (details) {
                  setState(() {
                    _isDragging = true;
                  });
                },
                onPanUpdate: (details) {
                  setState(() {
                    _dragY += details.delta.dy;
                    final nextY = (_targetTilt.dx + details.delta.dx * 0.0018)
                        .clamp(-0.12, 0.12);
                    final nextX = (_targetTilt.dy - details.delta.dy * 0.0018)
                        .clamp(-0.12, 0.12);
                    _targetTilt = Offset(nextY, nextX);
                  });
                },
                onPanEnd: (details) {
                  setState(() {
                    _isDragging = false;
                  });
                  // Swipe up to dismiss: if visual drag offset is high and upward, or velocity is upward
                  if (_dragY < -60 ||
                      details.velocity.pixelsPerSecond.dy < -200) {
                    _hide();
                  }
                  setState(() {
                    _dragY = 0.0;
                    _targetTilt = Offset.zero;
                  });
                },
                child: TweenAnimationBuilder<double>(
                  tween: Tween<double>(begin: 0.0, end: _dragY),
                  duration: _isDragging
                      ? Duration.zero
                      : const Duration(milliseconds: 450),
                  curve: IrisMotion.spring,
                  builder: (context, dragVal, child) {
                    // Compute visual offset with logarithmic damping (only damp down dragging)
                    final visualY = dragVal > 0
                        ? 45.0 * math.log(1.0 + dragVal / 45.0)
                        : dragVal;
                    final stretch = dragVal > 0
                        ? (visualY / 220.0).clamp(0.0, 0.16)
                        : 0.0;
                    return Transform.translate(
                      offset: Offset(0, visualY),
                      child: Transform.scale(
                        scaleX: 1.0 - stretch,
                        scaleY: 1.0 + stretch * 1.5,
                        alignment: Alignment.topCenter,
                        child: child,
                      ),
                    );
                  },
                  child: TweenAnimationBuilder<Offset>(
                    tween: Tween<Offset>(begin: Offset.zero, end: _targetTilt),
                    duration: _isDragging
                        ? Duration.zero
                        : const Duration(milliseconds: 320),
                    curve: IrisMotion.spring,
                    builder: (context, tilt, child) {
                      return Transform(
                        transform: Matrix4.identity()
                          ..setEntry(3, 2, 0.002) // Perspective factor
                          ..rotateX(tilt.dy)
                          ..rotateY(tilt.dx),
                        alignment: Alignment.center,
                        child: child,
                      );
                    },
                    child: ValueListenableBuilder<IrisThemeStyle>(
                      valueListenable: ThemeSignals.themeStyle,
                      builder: (context, style, _) {
                        final brightness = isDark
                            ? Brightness.dark
                            : Brightness.light;
                        final isMaterialYou =
                            style == IrisThemeStyle.materialYou;

                        if (style == IrisThemeStyle.almanac) {
                          final bg = _isUrgent
                              ? (isDark ? const Color(0xFF451A14) : const Color(0xFFFEE2E2))
                              : (isDark ? const Color(0xFF1E1B16) : const Color(0xFFF6F1E7));
                          final fg = isDark ? const Color(0xFFF4EFE6) : const Color(0xFF14110D);
                          final rule = isDark ? const Color(0xFFD6CEC2) : const Color(0xFF14110D);
                          return Material(
                            color: Colors.transparent,
                            elevation: 0,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              decoration: BoxDecoration(
                                color: bg,
                                border: Border.all(color: rule, width: 1.8),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withValues(alpha: isDark ? 0.5 : 0.18),
                                    blurRadius: 12,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(6),
                                    decoration: BoxDecoration(
                                      border: Border.all(color: rule, width: 1.2),
                                    ),
                                    child: Icon(_getSmartIcon(), color: fg, size: 18),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          'GAZETTE BULLETIN // ${_title.toUpperCase()}',
                                          style: GoogleFonts.spaceMono(
                                            fontSize: 9.5,
                                            fontWeight: FontWeight.w700,
                                            letterSpacing: 1.2,
                                            color: fg.withValues(alpha: 0.78),
                                          ),
                                        ),
                                        if (_body.trim().isNotEmpty) ...[
                                          const SizedBox(height: 2),
                                          Text(
                                            _body,
                                            style: GoogleFonts.playfairDisplay(
                                              fontSize: 13.5,
                                              fontWeight: FontWeight.w800,
                                              color: fg,
                                            ),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }

                        if (style == IrisThemeStyle.editorialAcademic) {
                          final bg = isDark ? const Color(0xFFF3EFE6) : const Color(0xFF1B2A4A);
                          final fg = isDark ? const Color(0xFF181613) : const Color(0xFFFDFBF7);
                          final accent = isDark ? const Color(0xFFC25E4C) : const Color(0xFFF2D0A9);
                          return Material(
                            color: Colors.transparent,
                            elevation: 0,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
                              decoration: BoxDecoration(
                                color: bg,
                                borderRadius: BorderRadius.circular(18),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withValues(alpha: 0.25),
                                    blurRadius: 18,
                                    offset: const Offset(0, 6),
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Icon(_getSmartIcon(), color: accent, size: 22),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          _title.toUpperCase(),
                                          style: GoogleFonts.plusJakartaSans(
                                            fontSize: 9.5,
                                            fontWeight: FontWeight.w800,
                                            letterSpacing: 1.5,
                                            color: accent,
                                          ),
                                        ),
                                        if (_body.trim().isNotEmpty) ...[
                                          const SizedBox(height: 2),
                                          Text(
                                            _body,
                                            style: GoogleFonts.fraunces(
                                              fontSize: 13.5,
                                              fontWeight: FontWeight.w700,
                                              color: fg,
                                            ),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }

                        if (style == IrisThemeStyle.notebook) {
                          final bg = isDark ? const Color(0xFF332D1A) : const Color(0xFFFEF08A);
                          final ink = isDark ? const Color(0xFFFef08a) : const Color(0xFF1E293B);
                          return Material(
                            color: Colors.transparent,
                            elevation: 0,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              decoration: BoxDecoration(
                                color: bg,
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(color: ink.withValues(alpha: 0.45), width: 1.5),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Color(0x33000000),
                                    offset: Offset(3, 4),
                                    blurRadius: 0,
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Icon(_getSmartIcon(), color: ink, size: 22),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          _title,
                                          style: GoogleFonts.kalam(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w700,
                                            color: ink,
                                          ),
                                        ),
                                        if (_body.trim().isNotEmpty)
                                          Text(
                                            _body,
                                            style: GoogleFonts.patrickHand(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w600,
                                              color: ink.withValues(alpha: 0.9),
                                            ),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }

                        if (style == IrisThemeStyle.line) {
                          final bg = isDark ? const Color(0xFF0A0F1A) : const Color(0xFF0F172A);
                          final rail = _isUrgent ? const Color(0xFFEF4444) : const Color(0xFF10B981);
                          return Material(
                            color: Colors.transparent,
                            elevation: 0,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              decoration: BoxDecoration(
                                color: bg,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: rail, width: 2.2),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withValues(alpha: 0.35),
                                    blurRadius: 16,
                                    offset: const Offset(0, 6),
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 12,
                                    height: 12,
                                    decoration: BoxDecoration(
                                      color: rail,
                                      shape: BoxShape.circle,
                                      border: Border.all(color: Colors.white, width: 2.5),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          'LINE DISPATCH • ${_title.toUpperCase()}',
                                          style: GoogleFonts.spaceMono(
                                            fontSize: 9.5,
                                            fontWeight: FontWeight.w700,
                                            letterSpacing: 1.1,
                                            color: rail,
                                          ),
                                        ),
                                        if (_body.trim().isNotEmpty) ...[
                                          const SizedBox(height: 2),
                                          Text(
                                            _body,
                                            style: GoogleFonts.plusJakartaSans(
                                              fontSize: 13,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.white,
                                            ),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }

                        if (style == IrisThemeStyle.poster) {
                          final borderCol = isDark ? Colors.white : Colors.black;
                          return Material(
                            color: Colors.transparent,
                            elevation: 0,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFF451A),
                                border: Border.all(color: borderCol, width: 3.0),
                                boxShadow: [
                                  BoxShadow(
                                    color: borderCol,
                                    offset: const Offset(5, 5),
                                    blurRadius: 0,
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(6),
                                    decoration: BoxDecoration(
                                      color: Colors.black,
                                      border: Border.all(color: Colors.white, width: 1.5),
                                    ),
                                    child: Icon(_getSmartIcon(), color: Colors.white, size: 18),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          _title.toUpperCase(),
                                          style: GoogleFonts.spaceMono(
                                            fontSize: 10,
                                            fontWeight: FontWeight.w700,
                                            letterSpacing: 1.4,
                                            color: Colors.white.withValues(alpha: 0.9),
                                          ),
                                        ),
                                        if (_body.trim().isNotEmpty) ...[
                                          const SizedBox(height: 2),
                                          Text(
                                            _body.toUpperCase(),
                                            style: GoogleFonts.archivoBlack(
                                              fontSize: 13,
                                              color: Colors.white,
                                            ),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }

                        if (isMaterialYou) {
                          final cardColor = _isUrgent
                              ? (isDark
                                    ? const Color(0xFF601410)
                                    : const Color(0xFFF9DEDC))
                              : MaterialYouTokens.surfaceContainerHighest(
                                  brightness,
                                );
                          final onCardColor = _isUrgent
                              ? (isDark
                                    ? const Color(0xFFFFB4AB)
                                    : const Color(0xFF410002))
                              : MaterialYouTokens.onSurface(brightness);
                          final iconBg = _isUrgent
                              ? (isDark
                                    ? const Color(0xFF8C1D18)
                                    : const Color(0xFFF2B8B5))
                              : MaterialYouTokens.secondaryContainer(
                                  brightness,
                                );
                          final iconColor = _isUrgent
                              ? (isDark
                                    ? const Color(0xFFFFDAD6)
                                    : const Color(0xFF601410))
                              : MaterialYouTokens.onSecondaryContainer(
                                  brightness,
                                );

                          return Material(
                            color: Colors.transparent,
                            elevation: 0,
                            child: Container(
                              decoration: ShapeDecoration(
                                color: cardColor,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(24),
                                  side: BorderSide(
                                    color: MaterialYouTokens.outlineVariant(
                                      brightness,
                                    ).withValues(alpha: isDark ? 0.45 : 0.65),
                                    width: 1.0,
                                  ),
                                ),
                                shadows: [
                                  BoxShadow(
                                    color: Colors.black.withValues(
                                      alpha: isDark ? 0.45 : 0.15,
                                    ),
                                    blurRadius: 20,
                                    offset: const Offset(0, 6),
                                  ),
                                ],
                              ),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 18,
                                vertical: 12,
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: iconBg,
                                    ),
                                    child:
                                        _title.toLowerCase().contains("sync") &&
                                            _isPersistent
                                        ? SizedBox(
                                            width: 22,
                                            height: 22,
                                            child: CircularProgressIndicator(
                                              strokeWidth: 2.5,
                                              valueColor:
                                                  AlwaysStoppedAnimation<Color>(
                                                    iconColor,
                                                  ),
                                            ),
                                          )
                                        : Icon(
                                            _getSmartIcon(),
                                            color: iconColor,
                                            size: 22,
                                          ),
                                  ),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          _title.toUpperCase(),
                                          style: TextStyle(
                                            fontWeight: FontWeight.w800,
                                            color: onCardColor.withValues(
                                              alpha: 0.85,
                                            ),
                                            fontSize: 10,
                                            letterSpacing: 1.2,
                                          ),
                                        ),
                                        if (_body.trim().isNotEmpty) ...[
                                          const SizedBox(height: 2),
                                          Text(
                                            _body,
                                            style: TextStyle(
                                              color: onCardColor,
                                              fontSize: 13,
                                              fontWeight: FontWeight.w600,
                                            ),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ],
                                    ),
                                  ),
                                  if (_onTap != null) ...[
                                    const SizedBox(width: 8),
                                    Icon(
                                      Icons.chevron_right_rounded,
                                      color: onCardColor.withValues(alpha: 0.6),
                                      size: 20,
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          );
                        }

                        final glassColor = _isUrgent
                            ? (isDark
                                ? const Color(0xFF601410).withValues(alpha: 0.94)
                                : const Color(0xFFF9DEDC).withValues(alpha: 0.96))
                            : (isDark
                                ? const Color(0xFF141923).withValues(alpha: 0.94)
                                : Colors.white.withValues(alpha: 0.96));

                        return Material(
                          color: Colors.transparent,
                          elevation: 0,
                          child: GlassSurface(
                            settings: IrisGlass.settings(
                              context,
                              blur: 18.0,
                              ambientStrength: 0.78,
                              lightAngle: 0.15 * math.pi,
                              glassColor: glassColor,
                              thickness: 16.0,
                            ),
                            radius: 24,
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(24),
                                border: Border.all(
                                  color: isDark
                                      ? Colors.white.withValues(alpha: 0.16)
                                      : Colors.black.withValues(alpha: 0.10),
                                  width: 1.0,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withValues(alpha: isDark ? 0.45 : 0.12),
                                    blurRadius: 24,
                                    offset: const Offset(0, 8),
                                  ),
                                ],
                              ),
                              child: Stack(
                                children: [
                                  // Liquid Blobs Background
                                  Positioned.fill(
                                    child: AnimatedBuilder(
                                      animation: _liquidController,
                                      builder: (context, _) {
                                        return CustomPaint(
                                          painter: _SmartPillLiquidPainter(
                                            progress: _liquidController.value,
                                            color: _isUrgent
                                                ? IrisTokens.warning.withValues(
                                                    alpha: 0.10,
                                                  )
                                                : IrisTokens.brand.withValues(
                                                    alpha: 0.08,
                                                  ),
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                  // Diagonal Shimmer Sweep Effect
                                  Positioned.fill(
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(24),
                                      child: AnimatedBuilder(
                                        animation: _shimmerController,
                                        builder: (context, child) {
                                          final slideVal =
                                              _shimmerController.value;
                                          return FractionallySizedBox(
                                            widthFactor: 1.5,
                                            heightFactor: 1.0,
                                            child: Transform.translate(
                                              offset: Offset(
                                                (slideVal * 2.0 - 1.0) * 420.0,
                                                0,
                                              ),
                                              child: Transform.rotate(
                                                angle: -0.4,
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    gradient: LinearGradient(
                                                      colors: [
                                                        Colors.transparent,
                                                        Colors.white.withValues(
                                                          alpha: 0.0,
                                                        ),
                                                        Colors.white.withValues(
                                                          alpha: 0.14,
                                                        ),
                                                        Colors.white.withValues(
                                                          alpha: 0.0,
                                                        ),
                                                        Colors.transparent,
                                                      ],
                                                      stops: const [
                                                        0.0,
                                                        0.4,
                                                        0.5,
                                                        0.6,
                                                        1.0,
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 20,
                                      vertical: 16,
                                    ),
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [
                                          (isDark ? Colors.white : Colors.black)
                                              .withValues(alpha: 0.05),
                                          Colors.transparent,
                                        ],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                      ),
                                      borderRadius: BorderRadius.circular(24),
                                      border: Border.all(
                                        color:
                                            (isDark
                                                    ? Colors.white
                                                    : Colors.black)
                                                .withValues(alpha: 0.15),
                                        width: 1.0, // Contour glow thin border
                                      ),
                                    ),
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.all(8),
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color:
                                                (isDark
                                                        ? Colors.white
                                                        : Colors.black)
                                                    .withValues(alpha: 0.08),
                                          ),
                                          child:
                                              _title.toLowerCase().contains(
                                                    "sync",
                                                  ) &&
                                                  _isPersistent
                                              ? SizedBox(
                                                  width: 28,
                                                  height: 28,
                                                  child: CircularProgressIndicator(
                                                    strokeWidth: 2,
                                                    valueColor:
                                                        AlwaysStoppedAnimation<
                                                          Color
                                                        >(
                                                          isDark
                                                              ? Colors.white
                                                              : Colors.black,
                                                        ),
                                                  ),
                                                )
                                              : Icon(
                                                  _getSmartIcon(),
                                                  color: isDark
                                                      ? Colors.white
                                                      : Colors.black87,
                                                  size: 28,
                                                ),
                                        ),
                                        const SizedBox(width: 14),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Text(
                                                _title.toUpperCase(),
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w900,
                                                  color: (isDark
                                                      ? Colors.white
                                                      : Colors.black87),
                                                  fontSize: 10,
                                                  letterSpacing: 1.5,
                                                ),
                                              ),
                                              if (_body.trim().isNotEmpty) ...[
                                                const SizedBox(height: 2),
                                                Text(
                                                  _body,
                                                  style: TextStyle(
                                                    color:
                                                        (isDark
                                                                ? Colors.white
                                                                : Colors.black87)
                                                            .withValues(
                                                              alpha: 0.85,
                                                            ),
                                                    fontSize: 13,
                                                    fontWeight: FontWeight.w600,
                                                  ),
                                                  maxLines: 2,
                                                  overflow: TextOverflow.ellipsis,
                                                ),
                                              ],
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  if (_onTap != null) ...[
                                    const SizedBox(width: 8),
                                    Icon(
                                      Icons.chevron_right_rounded,
                                      color: (isDark ? Colors.white : Colors.black87)
                                          .withValues(alpha: 0.6),
                                      size: 20,
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  IconData _getSmartIcon() {
    if (_customIcon != null) return _customIcon!;
    final t = _title.toLowerCase();
    if (t.contains("widget") || t.contains("pin")) {
      return Icons.widgets_rounded;
    }
    if (t.contains("auth") || t.contains("login") || t.contains("identity")) {
      return Icons.fingerprint_rounded;
    }
    if (t.contains("room") || t.contains("locate") || t.contains("find")) {
      return Icons.location_on_rounded;
    }
    if (t.contains("class") || t.contains("timetable") || t.contains("session")) {
      return Icons.auto_awesome_rounded;
    }
    if (t.contains("update") || t.contains("sync")) {
      return Icons.sync_rounded;
    }
    return _isUrgent ? Icons.warning_rounded : Icons.campaign_rounded;
  }
}

class _SmartPillLiquidPainter extends CustomPainter {
  final double progress;
  final Color color;

  _SmartPillLiquidPainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12);

    final center = Offset(size.width * 0.5, size.height * 0.5);
    final radius = size.width * 0.2;

    for (int i = 0; i < 3; i++) {
      final angle = (progress * 2 * 3.14) + (i * 2.0);
      final x = center.dx + 40 * math.sin(angle) * 0.2; // Fixed: using math.sin
      final y = center.dy + 15 * math.cos(angle) * 0.2; // Fixed: using math.cos

      canvas.drawCircle(Offset(x, y), radius + (i * 5), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _SmartPillLiquidPainter oldDelegate) => true;
}