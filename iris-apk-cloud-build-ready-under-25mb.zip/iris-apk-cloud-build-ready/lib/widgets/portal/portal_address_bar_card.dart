import 'package:flutter/material.dart';
import '../../core/tokens.dart';
import 'portal_bento_controls.dart';

/// Bento card containing the portal address bar, security badge, and inline editor.
class PortalAddressBarCard extends StatelessWidget {
  final bool isDark;
  final Color panelText;
  final Color panelMuted;
  final String addressLabelSafe;
  final bool isOffline;
  final bool isEditingAddress;
  final TextEditingController addressController;
  final VoidCallback onOpenAddressBar;
  final ValueChanged<String> onSubmitAddressBar;

  const PortalAddressBarCard({
    required this.isDark,
    required this.panelText,
    required this.panelMuted,
    required this.addressLabelSafe,
    required this.isOffline,
    required this.isEditingAddress,
    required this.addressController,
    required this.onOpenAddressBar,
    required this.onSubmitAddressBar,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return PortalBentoCard(
      isDark: isDark,
      child: Row(
        children: [
          Icon(
            addressLabelSafe.startsWith('https://')
                ? Icons.lock_outline_rounded
                : Icons.public_rounded,
            size: 15,
            color: isOffline ? const Color(0xFFEF4444) : IrisTokens.success,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: isEditingAddress
                ? TextField(
                    controller: addressController,
                    autofocus: true,
                    keyboardType: TextInputType.url,
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                      color: panelText,
                    ),
                    decoration: InputDecoration(
                      isDense: true,
                      border: InputBorder.none,
                      hintText: 'https://example.com',
                      hintStyle: TextStyle(
                        color: panelMuted.withValues(alpha: 0.5),
                      ),
                    ),
                    textInputAction: TextInputAction.go,
                    onSubmitted: onSubmitAddressBar,
                  )
                : InkWell(
                    onTap: onOpenAddressBar,
                    borderRadius: BorderRadius.circular(4),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: Text(
                        addressLabelSafe,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: panelText.withValues(alpha: 0.9),
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ),
                  ),
          ),
          const SizedBox(width: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
            decoration: BoxDecoration(
              color: (isOffline ? const Color(0xFFEF4444) : IrisTokens.success)
                  .withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(
                color:
                    (isOffline ? const Color(0xFFEF4444) : IrisTokens.success)
                        .withValues(alpha: 0.24),
                width: 0.8,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 5,
                  height: 5,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isOffline
                        ? const Color(0xFFEF4444)
                        : IrisTokens.success,
                  ),
                ),
                const SizedBox(width: 4),
                Text(
                  isOffline ? 'OFFLINE' : 'SECURE',
                  style: TextStyle(
                    fontSize: 8.5,
                    fontWeight: FontWeight.w800,
                    color: isOffline
                        ? const Color(0xFFEF4444)
                        : IrisTokens.success,
                    letterSpacing: 0.5,
                    decoration: TextDecoration.none,
                  ),
                ),
              ],
            ),
          ),
          if (!isEditingAddress) ...[
            const SizedBox(width: 8),
            GestureDetector(
              onTap: onOpenAddressBar,
              child: Icon(Icons.edit_rounded, size: 15, color: panelMuted),
            ),
          ],
        ],
      ),
    );
  }
}
