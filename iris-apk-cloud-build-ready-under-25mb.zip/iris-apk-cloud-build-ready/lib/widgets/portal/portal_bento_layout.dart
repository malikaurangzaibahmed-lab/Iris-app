import 'package:flutter/material.dart';
import '../../core/tokens.dart';
import '../../core/animations.dart';
import 'portal_bento_controls.dart';

/// Bento grid layout presenting quick portal navigation, storage, and session actions.
class PortalBentoLayout extends StatelessWidget {
  final bool isDark;
  final Color panelText;
  final Color panelMuted;
  final Color accent;
  final bool canGoBack;
  final bool canGoForward;
  final VoidCallback onGoBack;
  final VoidCallback onGoForward;
  final VoidCallback onRefresh;
  final VoidCallback onOpenExternal;
  final bool showBackButton;
  final VoidCallback onExitPortal;
  final int downloadsCount;
  final bool hasFileUpload;
  final VoidCallback onTriggerUpload;
  final VoidCallback onOpenDownloads;
  final bool hasSavedLogin;
  final bool hasLoginForm;
  final VoidCallback onAutofill;
  final VoidCallback onPrintDocument;
  final VoidCallback onClearLogin;
  final VoidCallback onClearSession;

  const PortalBentoLayout({
    required this.isDark,
    required this.panelText,
    required this.panelMuted,
    required this.accent,
    required this.canGoBack,
    required this.canGoForward,
    required this.onGoBack,
    required this.onGoForward,
    required this.onRefresh,
    required this.onOpenExternal,
    required this.showBackButton,
    required this.onExitPortal,
    required this.downloadsCount,
    required this.hasFileUpload,
    required this.onTriggerUpload,
    required this.onOpenDownloads,
    required this.hasSavedLogin,
    required this.hasLoginForm,
    required this.onAutofill,
    required this.onPrintDocument,
    required this.onClearLogin,
    required this.onClearSession,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final navigationCard = PortalBentoCard(
      isDark: isDark,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Icon(Icons.explore_rounded, size: 14, color: panelMuted),
              const SizedBox(width: 6),
              Text(
                'NAVIGATION DECK',
                style: TextStyle(
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  color: panelMuted,
                  letterSpacing: 0.8,
                  decoration: TextDecoration.none,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              PortalBentoNavCircle(
                isDark: isDark,
                icon: Icons.arrow_back_rounded,
                tooltip: 'Back',
                enabled: canGoBack,
                onTap: onGoBack,
              ),
              PortalBentoNavCircle(
                isDark: isDark,
                icon: Icons.arrow_forward_rounded,
                tooltip: 'Forward',
                enabled: canGoForward,
                onTap: onGoForward,
              ),
              PortalBentoNavCircle(
                isDark: isDark,
                icon: Icons.refresh_rounded,
                tooltip: 'Refresh',
                enabled: true,
                onTap: onRefresh,
              ),
              PortalBentoNavCircle(
                isDark: isDark,
                icon: Icons.open_in_new_rounded,
                tooltip: 'Open Browser',
                enabled: true,
                onTap: onOpenExternal,
              ),
            ],
          ),
          if (showBackButton) ...[
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Expanded(
                  child: PortalBentoActionBtn(
                    isDark: isDark,
                    icon: Icons.exit_to_app_rounded,
                    label: 'Exit Portal',
                    primary: true,
                    onTap: onExitPortal,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );

    final hasDownloads = downloadsCount > 0;
    final storageCard = PortalBentoCard(
      isDark: isDark,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.folder_open_rounded, size: 14, color: panelMuted),
                  const SizedBox(width: 6),
                  Text(
                    'STORAGE & SYSTEM',
                    style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      color: panelMuted,
                      letterSpacing: 0.8,
                      decoration: TextDecoration.none,
                    ),
                  ),
                ],
              ),
              if (hasDownloads)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: IrisTokens.brand.withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    '$downloadsCount Files',
                    style: TextStyle(
                      fontSize: 8.5,
                      fontWeight: FontWeight.w800,
                      color: IrisTokens.brand,
                      decoration: TextDecoration.none,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              if (hasFileUpload) ...[
                Expanded(
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: onTriggerUpload,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          vertical: 8,
                          horizontal: 10,
                        ),
                        decoration: BoxDecoration(
                          color: IrisTokens.brand.withValues(alpha: 0.08),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: IrisTokens.brand.withValues(alpha: 0.28),
                            width: 0.85,
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.cloud_upload_rounded,
                              size: 14,
                              color: IrisTokens.brand,
                            ),
                            const SizedBox(width: 6),
                            const Expanded(
                              child: Text(
                                'Upload File',
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  decoration: TextDecoration.none,
                                ),
                              ),
                            ),
                            Icon(
                              Icons.chevron_right_rounded,
                              size: 14,
                              color: IrisTokens.brand,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
              ],
              Expanded(
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: onOpenDownloads,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        vertical: 8,
                        horizontal: 10,
                      ),
                      decoration: BoxDecoration(
                        color: (isDark ? Colors.white : Colors.black)
                            .withValues(alpha: 0.04),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: (isDark ? Colors.white : Colors.black)
                              .withValues(alpha: 0.10),
                          width: 0.85,
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.download_for_offline_rounded,
                            size: 14,
                            color: panelMuted,
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              hasDownloads ? 'Open Downloads' : 'No Downloads',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: panelText.withValues(alpha: 0.96),
                                decoration: TextDecoration.none,
                              ),
                            ),
                          ),
                          Icon(
                            Icons.chevron_right_rounded,
                            size: 14,
                            color: panelMuted,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );

    final sessionToolsCard = PortalBentoCard(
      isDark: isDark,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Icon(Icons.tune_rounded, size: 14, color: panelMuted),
              const SizedBox(width: 6),
              Text(
                'QUICK ACTIONS',
                style: TextStyle(
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  color: panelMuted,
                  letterSpacing: 0.8,
                  decoration: TextDecoration.none,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (hasSavedLogin || hasLoginForm) ...[
            Row(
              children: [
                Expanded(
                  child: PortalBentoActionBtn(
                    isDark: isDark,
                    icon: hasSavedLogin
                        ? Icons.vpn_key_rounded
                        : Icons.badge_rounded,
                    label: hasSavedLogin
                        ? 'Autofill Credentials'
                        : 'Fill Student ID',
                    primary: true,
                    onTap: onAutofill,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
          ],
          Row(
            children: [
              Expanded(
                child: PortalBentoActionBtn(
                  isDark: isDark,
                  icon: Icons.print_rounded,
                  label: 'Print Page',
                  onTap: onPrintDocument,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: PortalBentoActionBtn(
                  isDark: isDark,
                  icon: Icons.key_off_rounded,
                  label: 'Clear Login',
                  onTap: onClearLogin,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: PortalBentoActionBtn(
                  isDark: isDark,
                  icon: Icons.delete_sweep_rounded,
                  label: 'Clear Data',
                  onTap: onClearSession,
                ),
              ),
            ],
          ),
        ],
      ),
    );

    return SingleChildScrollView(
      physics: const ButterScrollPhysics(
        parent: AlwaysScrollableScrollPhysics(),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          navigationCard,
          const SizedBox(height: 8),
          storageCard,
          const SizedBox(height: 8),
          sessionToolsCard,
        ],
      ),
    );
  }
}
