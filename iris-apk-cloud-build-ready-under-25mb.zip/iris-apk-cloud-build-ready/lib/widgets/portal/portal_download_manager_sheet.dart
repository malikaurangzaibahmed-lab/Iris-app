import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';

import '../../core/theme_signals.dart';
import '../../core/glass.dart';
import '../../models/portal_models.dart';

class PortalDownloadManagerSheet extends StatelessWidget {
  final List<DownloadRecord> downloads;
  final List<String> uploads;
  final Directory downloadDir;
  final bool isDark;
  final Future<void> Function(String path) onOpenFilePath;
  final Future<void> Function(String path) onCopyPath;
  final Future<void> Function(String path) onOpenFolderPath;
  final Future<void> Function() onOpenSystemDownloads;
  final Future<void> Function() onRefresh;
  final Future<void> Function() onCleanMissing;
  final Future<void> Function() onClearHistory;
  final Future<void> Function(String url) onRetryDownload;

  const PortalDownloadManagerSheet({
    required this.downloads,
    required this.uploads,
    required this.downloadDir,
    required this.isDark,
    required this.onOpenFilePath,
    required this.onCopyPath,
    required this.onOpenFolderPath,
    required this.onOpenSystemDownloads,
    required this.onRefresh,
    required this.onCleanMissing,
    required this.onClearHistory,
    required this.onRetryDownload,
    super.key,
  });

  static String displayFileName(String path) {
    final parts = path.split(RegExp(r'[\\/]'));
    return parts.isEmpty ? path : parts.last;
  }

  Widget _buildTransferList(
    BuildContext context,
    List<String> items, {
    required bool uploadsMode,
    required Color accent,
  }) {
    if (items.isEmpty) {
      return Center(
        child: Text(
          uploadsMode ? 'No uploads yet' : 'No downloads yet',
          style: TextStyle(
            fontWeight: FontWeight.w700,
            color: (isDark ? Colors.white : Colors.black).withValues(
              alpha: 0.58,
            ),
          ),
        ),
      );
    }

    return ListView.separated(
      physics: ScrollConfiguration.of(context).getScrollPhysics(context),
      cacheExtent: 450.0,
      itemCount: items.length,
      separatorBuilder: (_, _) => const SizedBox(height: 8),
      itemBuilder: (_, i) {
        final item = items[i];
        return Container(
          decoration: BoxDecoration(
            color: (isDark ? Colors.white : Colors.black).withValues(
              alpha: 0.06,
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: (isDark ? Colors.white : Colors.black).withValues(
                alpha: 0.10,
              ),
            ),
          ),
          child: ListTile(
            dense: true,
            leading: Icon(
              uploadsMode
                  ? Icons.upload_file_rounded
                  : Icons.download_done_rounded,
              color: accent,
            ),
            title: Text(
              displayFileName(item),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            subtitle: Text(
              item,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            onTap: () async => onOpenFilePath(item),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  tooltip: 'Open',
                  icon: const Icon(Icons.open_in_new_rounded, size: 18),
                  onPressed: () async => onOpenFilePath(item),
                ),
                IconButton(
                  tooltip: 'Copy path',
                  icon: const Icon(Icons.content_copy_rounded, size: 18),
                  onPressed: () async => onCopyPath(item),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildDownloadList(
    BuildContext context,
    List<DownloadRecord> items, {
    required Color accent,
  }) {
    if (items.isEmpty) {
      return Center(
        child: Text(
          'No downloads yet',
          style: TextStyle(
            fontWeight: FontWeight.w700,
            color: (isDark ? Colors.white : Colors.black).withValues(
              alpha: 0.58,
            ),
          ),
        ),
      );
    }

    return ListView.separated(
      physics: ScrollConfiguration.of(context).getScrollPhysics(context),
      cacheExtent: 450.0,
      itemCount: items.length,
      separatorBuilder: (_, _) => const SizedBox(height: 8),
      itemBuilder: (_, i) {
        final item = items[i];
        return Container(
          decoration: BoxDecoration(
            color: (isDark ? Colors.white : Colors.black).withValues(
              alpha: 0.06,
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: (isDark ? Colors.white : Colors.black).withValues(
                alpha: 0.10,
              ),
            ),
          ),
          child: ListTile(
            dense: true,
            leading: Icon(Icons.download_done_rounded, color: accent),
            title: Text(
              item.filename,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            subtitle: Text(
              '${item.displaySource} · ${item.prettySavedAt} · ${item.statusLabel}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            onTap: () async {
              if (item.isPending && item.backend == 'system') {
                await onOpenSystemDownloads();
                return;
              }
              await onOpenFilePath(item.filePath);
            },
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (item.sourceUrl.isNotEmpty)
                  IconButton(
                    tooltip: 'Retry download',
                    icon: const Icon(Icons.refresh_rounded, size: 18),
                    onPressed: () async => onRetryDownload(item.sourceUrl),
                  ),
                IconButton(
                  tooltip: item.isPending ? 'System downloads' : 'Open',
                  icon: Icon(
                    item.isPending
                        ? Icons.download_rounded
                        : Icons.open_in_new_rounded,
                    size: 18,
                  ),
                  onPressed: () async {
                    if (item.isPending && item.backend == 'system') {
                      await onOpenSystemDownloads();
                      return;
                    }
                    await onOpenFilePath(item.filePath);
                  },
                ),
                IconButton(
                  tooltip: 'Copy path',
                  icon: const Icon(Icons.content_copy_rounded, size: 18),
                  onPressed: () async => onCopyPath(item.filePath),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFFFE7A2C);
    final isM3 = ThemeSignals.isMaterialYou;

    Widget sheetBody = Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
      decoration: BoxDecoration(
        color: isM3
            ? Theme.of(context).colorScheme.surfaceContainerHigh
            : (isDark ? const Color(0xFF111827) : Colors.white).withValues(
                alpha: 0.88,
              ),
        borderRadius: BorderRadius.circular(24),
        border: isM3
            ? null
            : Border.all(
                color: (isDark ? Colors.white : Colors.black).withValues(
                  alpha: 0.12,
                ),
              ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 42,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.withValues(alpha: 0.45),
                borderRadius: BorderRadius.circular(999),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Download Manager',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  '${downloads.length} downloads',
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            downloadDir.path,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              FilledButton.tonalIcon(
                onPressed:
                    downloads.isEmpty || downloads.first.sourceUrl.isEmpty
                        ? null
                        : () async => onRetryDownload(downloads.first.sourceUrl),
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Retry Latest'),
              ),
              FilledButton.tonalIcon(
                onPressed: () async => onOpenFolderPath(downloadDir.path),
                icon: const Icon(Icons.folder_open_rounded),
                label: const Text('Folder'),
              ),
              FilledButton.tonalIcon(
                onPressed: () async => onOpenSystemDownloads(),
                icon: const Icon(Icons.download_rounded),
                label: const Text('System'),
              ),
              TextButton.icon(
                onPressed: () async => onRefresh(),
                icon: const Icon(Icons.sync_rounded),
                label: const Text('Refresh'),
              ),
              FilledButton.tonalIcon(
                onPressed: downloads.isEmpty
                    ? null
                    : () async => onOpenFilePath(downloads.first.filePath),
                icon: const Icon(Icons.file_open_rounded),
                label: const Text('Latest'),
              ),
              TextButton.icon(
                onPressed: () async => onCleanMissing(),
                icon: const Icon(Icons.cleaning_services_rounded),
                label: const Text('Clean Missing'),
              ),
              TextButton.icon(
                onPressed: () async => onCopyPath(downloadDir.path),
                icon: const Icon(Icons.content_copy_rounded),
                label: const Text('Copy Path'),
              ),
              TextButton.icon(
                onPressed: () async => onClearHistory(),
                icon: const Icon(Icons.delete_sweep_rounded),
                label: const Text('Clear'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          TabBar(
            indicator: BoxDecoration(
              color: accent.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(999),
            ),
            labelColor: accent,
            unselectedLabelColor: (isDark ? Colors.white : Colors.black)
                .withValues(alpha: 0.6),
            tabs: const [
              Tab(text: 'Downloads'),
              Tab(text: 'Uploads'),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: TabBarView(
              children: [
                _buildDownloadList(context, downloads, accent: accent),
                _buildTransferList(context, uploads, uploadsMode: true, accent: accent),
              ],
            ),
          ),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Close'),
            ),
          ),
        ],
      ),
    );

    if (ThemeSignals.isFluidGlass) {
      sheetBody = ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: GlassSurface(
          settings: IrisGlass.settings(context, blur: 16.0, thickness: 14.0),
          radius: 24,
          child: sheetBody,
        ),
      );
    }

    return DefaultTabController(
      length: 2,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
          child: sheetBody,
        ),
      ),
    );
  }
}
