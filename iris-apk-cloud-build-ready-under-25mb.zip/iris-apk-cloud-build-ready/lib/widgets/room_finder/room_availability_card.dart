import 'dart:math' as math;
import 'package:flutter/material.dart';

import '../../core/animations.dart';
import '../../core/format_guard.dart';
import '../../core/models.dart';
import '../../core/theme_signals.dart';
import '../../core/tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../services/room_persistence_service.dart';
import '../glass_card.dart';

Color _getHeadingColor(IrisThemeStyle style, bool isDark, ColorScheme cs) {
  switch (style) {
    case IrisThemeStyle.notebook:
      return NotebookTokens.inkHeading(isDark);
    case IrisThemeStyle.line:
      return LineTokens.inkHeading(isDark);
    case IrisThemeStyle.poster:
      return PosterTokens.inkHeading(isDark);
    case IrisThemeStyle.almanac:
      return AlmanacTokens.inkHeading(isDark);
    case IrisThemeStyle.editorialAcademic:
      return EditorialTokens.inkHeading(isDark);
    case IrisThemeStyle.materialYou:
      return cs.onSurface;
    case IrisThemeStyle.fluidGlass:
      return isDark ? Colors.white : Colors.black;
  }
}

Color _getMutedColor(IrisThemeStyle style, bool isDark, ColorScheme cs) {
  switch (style) {
    case IrisThemeStyle.notebook:
      return NotebookTokens.inkMuted(isDark);
    case IrisThemeStyle.line:
      return LineTokens.inkMuted(isDark);
    case IrisThemeStyle.poster:
      return PosterTokens.inkMuted(isDark);
    case IrisThemeStyle.almanac:
      return AlmanacTokens.inkMuted(isDark);
    case IrisThemeStyle.editorialAcademic:
      return EditorialTokens.inkMuted(isDark);
    case IrisThemeStyle.materialYou:
      return cs.onSurfaceVariant;
    case IrisThemeStyle.fluidGlass:
      return (isDark ? Colors.white : Colors.black).withValues(alpha: 0.55);
  }
}

Color _getBodyColor(IrisThemeStyle style, bool isDark, ColorScheme cs) {
  switch (style) {
    case IrisThemeStyle.notebook:
      return NotebookTokens.inkBody(isDark);
    case IrisThemeStyle.line:
      return LineTokens.inkBody(isDark);
    case IrisThemeStyle.poster:
      return PosterTokens.inkBody(isDark);
    case IrisThemeStyle.almanac:
      return AlmanacTokens.inkBody(isDark);
    case IrisThemeStyle.editorialAcademic:
      return EditorialTokens.inkBody(isDark);
    case IrisThemeStyle.materialYou:
      return cs.onSurface;
    case IrisThemeStyle.fluidGlass:
      return isDark ? Colors.white70 : Colors.black87;
  }
}

class OccupancyDonutPainter extends CustomPainter {
  final double percent;
  final Color color;
  final bool isDark;

  const OccupancyDonutPainter({
    required this.percent,
    required this.color,
    required this.isDark,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = math.min(size.width, size.height) / 2 - 7;

    final bgPaint = Paint()
      ..color = (isDark ? Colors.white : Colors.black).withValues(alpha: 0.08)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 8;

    final progressPaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 8;

    canvas.drawCircle(center, radius, bgPaint);
    if (percent > 0) {
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        -math.pi / 2,
        2 * math.pi * percent.clamp(0.0, 1.0),
        false,
        progressPaint,
      );
    }

    final percentVal = (percent * 100).toInt();
    final textPainter = TextPainter(
      text: TextSpan(
        children: [
          TextSpan(
            text: '$percentVal%\n',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w900,
              height: 1.1,
              color: isDark ? Colors.white : Colors.black,
            ),
          ),
          TextSpan(
            text: 'FREE',
            style: TextStyle(
              fontSize: 8.5,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.8,
              color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.45),
            ),
          ),
        ],
      ),
      textAlign: TextAlign.center,
      textDirection: TextDirection.ltr,
    )..layout();

    textPainter.paint(
      canvas,
      Offset(
        center.dx - textPainter.width / 2,
        center.dy - textPainter.height / 2,
      ),
    );
  }

  @override
  bool shouldRepaint(covariant OccupancyDonutPainter oldDelegate) =>
      oldDelegate.percent != percent ||
      oldDelegate.color != color ||
      oldDelegate.isDark != isDark;
}

class RoomAvailabilityCard extends StatelessWidget {
  final RoomAvailability availability;
  final bool isDark;
  final List<ClassSession> allSessions;
  final int targetDay;
  final List<TimeSlot> dynamicSlots;
  final VoidCallback onTap;

  const RoomAvailabilityCard({
    required this.availability,
    required this.isDark,
    required this.allSessions,
    required this.targetDay,
    required this.dynamicSlots,
    required this.onTap,
    super.key,
  });

  Widget _buildOccupancyTimeline(String roomId, bool isDark) {
    final cachedSlots = availability.slotOccupancy;
    if (cachedSlots != null &&
        cachedSlots.length == dynamicSlots.length &&
        dynamicSlots.isNotEmpty) {
      return Row(
        children: List.generate(dynamicSlots.length, (slotIndex) {
          final isOccupied = cachedSlots[slotIndex];
          return Expanded(
            child: Container(
              height: 7,
              margin: const EdgeInsets.symmetric(horizontal: 2.5),
              decoration: BoxDecoration(
                color: isOccupied
                    ? const Color(0xFFEF4444).withValues(alpha: 0.85)
                    : const Color(0xFF10B981).withValues(alpha: 0.85),
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          );
        }),
      );
    }

    if (dynamicSlots.isEmpty) return const SizedBox.shrink();

    final cleanRoomId = FormatGuard.sanitizeRoom(roomId);
    return Row(
      children: List.generate(dynamicSlots.length, (slotIndex) {
        final startHour = dynamicSlots[slotIndex].start;
        final endHour = dynamicSlots[slotIndex].end;
        final slotMiddle = startHour + (endHour - startHour) / 2;

        final isOccupied = allSessions.any((s) =>
            FormatGuard.sanitizeRoom(s.room) == cleanRoomId &&
            s.dayIndex == targetDay &&
            s.safeStartVal <= slotMiddle &&
            slotMiddle < s.actualEndVal);

        return Expanded(
          child: Container(
            height: 7,
            margin: const EdgeInsets.symmetric(horizontal: 2.5),
            decoration: BoxDecoration(
              color: isOccupied
                  ? const Color(0xFFEF4444).withValues(alpha: 0.85)
                  : const Color(0xFF10B981).withValues(alpha: 0.85),
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    final statusColor =
        availability.isAvailable ? const Color(0xFF10B981) : const Color(0xFFEF4444);
    final locationText = availability.formattedLocation ??
        RoomPersistenceService.parseRoomCode(availability.roomId)
            .formattedLocation;
    final isLab = availability.roomId.toLowerCase().contains('lab') ||
        availability.amenities.any((a) => a.toLowerCase().contains('lab'));
    final style = ThemeSignals.themeStyle.value;
    final isM3 = style == IrisThemeStyle.materialYou;
    final cs = Theme.of(context).colorScheme;

    final titleColor = _getHeadingColor(style, isDark, cs);
    final mutedColor = _getMutedColor(style, isDark, cs);
    final bodyColor = _getBodyColor(style, isDark, cs);

    final Color bannerBgColor;
    if (isM3) {
      bannerBgColor = cs.surfaceContainerHighest.withValues(alpha: 0.45);
    } else {
      switch (style) {
        case IrisThemeStyle.notebook:
          bannerBgColor = NotebookTokens.gridLine(isDark).withValues(alpha: 0.12);
          break;
        case IrisThemeStyle.line:
          bannerBgColor = LineTokens.railLine(isDark).withValues(alpha: 0.16);
          break;
        case IrisThemeStyle.poster:
          bannerBgColor = PosterTokens.inkBorder(isDark).withValues(alpha: 0.10);
          break;
        case IrisThemeStyle.almanac:
          bannerBgColor = AlmanacTokens.inkRuleSubtle(isDark).withValues(alpha: 0.15);
          break;
        case IrisThemeStyle.editorialAcademic:
          bannerBgColor = EditorialTokens.cardBorder(isDark).withValues(alpha: 0.14);
          break;
        case IrisThemeStyle.fluidGlass:
        case IrisThemeStyle.materialYou:
          bannerBgColor = (isDark ? Colors.white : Colors.black).withValues(alpha: 0.04);
          break;
      }
    }

    final roomCardChild = Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: isM3 ? cs.secondaryContainer : statusColor.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(18),
                  border: isM3 ? null : Border.all(
                    color: statusColor.withValues(alpha: 0.3),
                    width: 1.5,
                  ),
                ),
                child: Center(
                  child: Icon(
                    isLab ? Icons.computer_rounded : Icons.meeting_room_rounded,
                    color: isM3 ? cs.onSecondaryContainer : statusColor,
                    size: 24,
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          availability.roomId,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -0.5,
                            color: titleColor,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: isM3 ? cs.surfaceContainerHighest : (isDark ? Colors.white : Colors.black).withValues(alpha: 0.07),
                            borderRadius: BorderRadius.circular(isM3 ? 999 : 6),
                          ),
                          child: Text(
                            isLab ? 'LAB' : 'ROOM',
                            style: TextStyle(
                              fontSize: 9.5,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.5,
                              color: mutedColor,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(
                          Icons.location_on_rounded,
                          size: 13,
                          color: isM3 ? cs.primary : IrisTokens.brand,
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            locationText,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: mutedColor,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: isM3
                          ? (availability.isAvailable ? cs.primaryContainer : cs.errorContainer)
                          : statusColor.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(isM3 ? 999 : 10),
                      border: isM3 ? null : Border.all(
                        color: statusColor.withValues(alpha: 0.3),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                            color: isM3
                                ? (availability.isAvailable ? cs.onPrimaryContainer : cs.onErrorContainer)
                                : statusColor,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 5),
                        Text(
                          availability.isAvailable ? 'VACANT' : 'OCCUPIED',
                          style: TextStyle(
                            color: isM3
                                ? (availability.isAvailable ? cs.onPrimaryContainer : cs.onErrorContainer)
                                : statusColor,
                            fontSize: 10.5,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    availability.isAvailable
                        ? (availability.minulesFreeUntilNextSession != null
                            ? 'Next ${availability.minulesFreeUntilNextSession}m'
                            : 'Until EOD')
                        : 'Till ${FormatGuard.formatDecimalTime(availability.occupiedUntil ?? 0)}',
                    style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w700,
                      color: isM3 ? cs.onSurfaceVariant : statusColor.withValues(alpha: 0.9),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "TIMELINE",
                    style: TextStyle(
                      fontSize: 9.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.8,
                      color: mutedColor,
                    ),
                  ),
                  Text(
                    dynamicSlots.isNotEmpty
                        ? "${TimeSlot.formatTime(dynamicSlots.first.start)} - ${TimeSlot.formatTime(dynamicSlots.last.end)}"
                        : "8:30 AM - 4:20 PM",
                    style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      color: mutedColor,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              _buildOccupancyTimeline(availability.roomId, isDark),
            ],
          ),
        ),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
          decoration: BoxDecoration(
            color: bannerBgColor,
            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(24)),
          ),
          child: Row(
            children: [
              Icon(
                availability.nextSessionSubject != null
                    ? Icons.schedule_rounded
                    : (availability.isAvailable ? Icons.check_circle_outline_rounded : Icons.info_outline_rounded),
                size: 13,
                color: mutedColor,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  availability.nextSessionSubject != null
                      ? 'Next: ${availability.nextSessionSubject} at ${FormatGuard.formatDecimalTime(availability.nextSessionAt ?? 0)}'
                      : (availability.isAvailable
                          ? 'Free for remainder of academic day'
                          : 'Occupied: ${availability.occupiedBy ?? 'Lecture in session'}'),
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w600,
                    color: bodyColor,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              if (availability.amenities.isNotEmpty)
                Text(
                  availability.amenities.take(2).join(' · '),
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: mutedColor,
                  ),
                ),
            ],
          ),
        ),
      ],
    );

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: isM3
          ? ExpressiveInteractivePress(
              onTap: onTap,
              child: Container(
                decoration: BoxDecoration(
                  color: isDark ? cs.surfaceContainer : cs.surfaceContainerLow,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.5),
                    width: 1.0,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: isDark ? 0.14 : 0.03),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: roomCardChild,
              ),
            )
          : GlassCard(
              onTap: onTap,
              padding: EdgeInsets.zero,
              borderRadius: 26,
              child: roomCardChild,
            ),
    );
  }
}

class RoomFilterChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final bool isLive;
  final ValueChanged<bool> onSelected;

  const RoomFilterChip({
    required this.label,
    required this.isSelected,
    this.isLive = false,
    required this.onSelected,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return RepaintBoundary(
      child: ChoiceChip(
        label: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              style: TextStyle(
                fontWeight: isSelected ? FontWeight.w900 : FontWeight.w600,
                fontSize: 13,
                color: isSelected
                    ? Colors.white
                    : (isDark ? Colors.white70 : Colors.black87),
              ),
            ),
            if (isLive) ...[
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                decoration: BoxDecoration(
                  color: isSelected
                      ? Colors.white.withValues(alpha: 0.25)
                      : IrisTokens.brand.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  'LIVE',
                  style: TextStyle(
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    color: isSelected ? Colors.white : IrisTokens.brand,
                  ),
                ),
              ),
            ],
          ],
        ),
        selected: isSelected,
        onSelected: onSelected,
        selectedColor: IrisTokens.brand,
        backgroundColor: isDark
            ? Colors.white.withValues(alpha: 0.05)
            : Colors.white.withValues(alpha: 0.85),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
        ),
        side: BorderSide(
          color: isSelected
              ? IrisTokens.brandLight.withValues(alpha: 0.3)
              : (isDark
                  ? Colors.white.withValues(alpha: 0.10)
                  : Colors.black.withValues(alpha: 0.08)),
          width: 1.0,
        ),
        showCheckmark: false,
      ),
    );
  }
}
