import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/tokens.dart';
import '../../core/models.dart';
import '../../core/format_guard.dart';
import '../../core/theme_signals.dart';
import '../../core/glass.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../services/room_persistence_service.dart';
import '../../services/ui_feedback.dart';

/// Helper to produce polymorphic 7-theme bottom sheet decorations.
BoxDecoration getThemedSheetDecoration(
  IrisThemeStyle style,
  bool isDark,
  ColorScheme cs,
) {
  switch (style) {
    case IrisThemeStyle.materialYou:
      return BoxDecoration(
        color: cs.surfaceContainerHigh,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        border: Border(
          top: BorderSide(
            color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.45),
            width: 1.0,
          ),
        ),
      );
    case IrisThemeStyle.notebook:
      return BoxDecoration(
        color: NotebookTokens.cardSurface(isDark),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(
          top: BorderSide(
            color: NotebookTokens.marginRule(isDark),
            width: 2.5,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.4 : 0.08),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
      );
    case IrisThemeStyle.line:
      return BoxDecoration(
        color: LineTokens.cardSurface(isDark),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
        border: Border(
          top: BorderSide(
            color: LineTokens.railLine(isDark),
            width: 2.5,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.45 : 0.08),
            blurRadius: 12,
            offset: const Offset(0, -3),
          ),
        ],
      );
    case IrisThemeStyle.poster:
      return BoxDecoration(
        color: PosterTokens.cardSurface(isDark),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
        border: Border(
          top: BorderSide(
            color: PosterTokens.inkBorder(isDark),
            width: 3.5,
          ),
          left: BorderSide(
            color: PosterTokens.inkBorder(isDark),
            width: 3.0,
          ),
          right: BorderSide(
            color: PosterTokens.inkBorder(isDark),
            width: 3.0,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: PosterTokens.inkBorder(isDark),
            offset: const Offset(0, -4),
            blurRadius: 0,
          ),
        ],
      );
    case IrisThemeStyle.almanac:
      return BoxDecoration(
        color: AlmanacTokens.cardSurface(isDark),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        border: Border(
          top: BorderSide(
            color: AlmanacTokens.inkRule(isDark),
            width: 2.2,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
            blurRadius: 14,
            offset: const Offset(0, -3),
          ),
        ],
      );
    case IrisThemeStyle.editorialAcademic:
      return BoxDecoration(
        color: EditorialTokens.cardSurface(isDark),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        border: Border(
          top: BorderSide(
            color: EditorialTokens.cardBorder(isDark),
            width: 1.2,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.06),
            blurRadius: 20,
            offset: const Offset(0, -4),
          ),
        ],
      );
    case IrisThemeStyle.fluidGlass:
      return BoxDecoration(
        color: (isDark ? const Color(0xFF0F172A) : Colors.white)
            .withValues(alpha: isDark ? 0.90 : 0.94),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        border: Border(
          top: BorderSide(
            color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.15),
            width: 1.5,
          ),
        ),
      );
  }
}

/// Helper for inner surface/container decoration inside themed bottom sheets.
BoxDecoration getThemedInnerContainerDecoration(
  IrisThemeStyle style,
  bool isDark,
  ColorScheme cs, {
  BorderRadius? borderRadius,
}) {
  final radius = borderRadius ?? BorderRadius.circular(16);
  switch (style) {
    case IrisThemeStyle.materialYou:
      return BoxDecoration(
        color: cs.surfaceContainer,
        borderRadius: radius,
        border: Border.all(
          color: cs.outlineVariant.withValues(alpha: isDark ? 0.25 : 0.40),
          width: 1.0,
        ),
      );
    case IrisThemeStyle.notebook:
      return BoxDecoration(
        color: isDark ? const Color(0xFF1B2520) : const Color(0xFFF4EEDB),
        borderRadius: radius,
        border: Border.all(
          color: NotebookTokens.gridLine(isDark),
          width: 1.0,
        ),
      );
    case IrisThemeStyle.line:
      return BoxDecoration(
        color: LineTokens.canvas(isDark),
        borderRadius: radius,
        border: Border.all(
          color: LineTokens.railLine(isDark),
          width: 1.5,
        ),
      );
    case IrisThemeStyle.poster:
      return BoxDecoration(
        color: PosterTokens.canvas(isDark),
        borderRadius: radius,
        border: Border.all(
          color: PosterTokens.inkBorder(isDark),
          width: 2.0,
        ),
      );
    case IrisThemeStyle.almanac:
      return BoxDecoration(
        color: AlmanacTokens.canvas(isDark),
        borderRadius: radius,
        border: Border.all(
          color: AlmanacTokens.inkRuleSubtle(isDark),
          width: 1.0,
        ),
      );
    case IrisThemeStyle.editorialAcademic:
      return BoxDecoration(
        color: EditorialTokens.canvas(isDark),
        borderRadius: radius,
        border: Border.all(
          color: EditorialTokens.cardBorder(isDark),
          width: 1.0,
        ),
      );
    case IrisThemeStyle.fluidGlass:
      return BoxDecoration(
        color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.04),
        borderRadius: radius,
        border: Border.all(
          color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.06),
          width: 1.0,
        ),
      );
  }
}

/// Helper for heading text color in themed sheets.
Color getThemedHeadingColor(IrisThemeStyle style, bool isDark, ColorScheme cs) {
  switch (style) {
    case IrisThemeStyle.notebook:
      return NotebookTokens.inkHeading(isDark);
    case IrisThemeStyle.line:
      return LineTokens.inkHeading(isDark);
    case IrisThemeStyle.poster:
      return PosterTokens.inkHeading(isDark);
    case IrisThemeStyle.almanac:
      return AlmanacTokens.inkHeading(isDark);
    case IrisThemeStyle.editorialAcademic:
      return EditorialTokens.inkHeading(isDark);
    case IrisThemeStyle.materialYou:
      return cs.onSurface;
    case IrisThemeStyle.fluidGlass:
      return isDark ? Colors.white : Colors.black;
  }
}

/// Helper for body text color in themed sheets.
Color getThemedBodyColor(IrisThemeStyle style, bool isDark, ColorScheme cs) {
  switch (style) {
    case IrisThemeStyle.notebook:
      return NotebookTokens.inkBody(isDark);
    case IrisThemeStyle.line:
      return LineTokens.inkBody(isDark);
    case IrisThemeStyle.poster:
      return PosterTokens.inkBody(isDark);
    case IrisThemeStyle.almanac:
      return AlmanacTokens.inkBody(isDark);
    case IrisThemeStyle.editorialAcademic:
      return EditorialTokens.inkBody(isDark);
    case IrisThemeStyle.materialYou:
      return cs.onSurface;
    case IrisThemeStyle.fluidGlass:
      return isDark ? Colors.white70 : Colors.black87;
  }
}

/// Helper for muted/caption text color in themed sheets.
Color getThemedMutedColor(IrisThemeStyle style, bool isDark, ColorScheme cs) {
  switch (style) {
    case IrisThemeStyle.notebook:
      return NotebookTokens.inkMuted(isDark);
    case IrisThemeStyle.line:
      return LineTokens.inkMuted(isDark);
    case IrisThemeStyle.poster:
      return PosterTokens.inkMuted(isDark);
    case IrisThemeStyle.almanac:
      return AlmanacTokens.inkMuted(isDark);
    case IrisThemeStyle.editorialAcademic:
      return EditorialTokens.inkMuted(isDark);
    case IrisThemeStyle.materialYou:
      return cs.onSurfaceVariant;
    case IrisThemeStyle.fluidGlass:
      return (isDark ? Colors.white : Colors.black).withValues(alpha: 0.55);
  }
}

/// Modal bottom sheet presenting granular multi-floor details of a campus building.
class BuildingDetailSheet extends StatelessWidget {
  final CampusBuilding building;
  final bool isDark;

  const BuildingDetailSheet({
    required this.building,
    required this.isDark,
    super.key,
  });

  static void show(
    BuildContext context,
    CampusBuilding b,
    bool isDark,
  ) {
    IrisHaptics.actionSoft();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => BuildingDetailSheet(building: b, isDark: isDark),
    );
  }

  @override
  Widget build(BuildContext context) {
    final b = building;
    final effectiveIsDark = isDark || Theme.of(context).brightness == Brightness.dark;
    final cs = Theme.of(context).colorScheme;
    final style = ThemeSignals.themeStyle.value;

    Widget sheetBody = Container(
      decoration: getThemedSheetDecoration(style, effectiveIsDark, cs),
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 5,
              decoration: BoxDecoration(
                color: getThemedMutedColor(style, effectiveIsDark, cs)
                    .withValues(alpha: 0.35),
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            b.name,
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w900,
              letterSpacing: -1,
              color: getThemedHeadingColor(style, effectiveIsDark, cs),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(
                Icons.location_on_rounded,
                size: 16,
                color: IrisTokens.brand,
              ),
              const SizedBox(width: 6),
              Text(
                '${b.latitude}, ${b.longitude}',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: getThemedMutedColor(style, effectiveIsDark, cs),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Expanded(
            child: ListView.builder(
              physics: const BouncingScrollPhysics(),
              itemCount: b.floors.length,
              itemBuilder: (ctx, fIndex) {
                final floor = b.floors[fIndex];
                return Container(
                  margin: const EdgeInsets.only(bottom: 16),
                  padding: const EdgeInsets.all(16),
                  decoration: getThemedInnerContainerDecoration(
                    style,
                    effectiveIsDark,
                    cs,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Floor ${floor.level}',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          color: getThemedHeadingColor(style, effectiveIsDark, cs),
                        ),
                      ),
                      const SizedBox(height: 12),
                      ...floor.rooms.map(
                        (r) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: IrisTokens.brand
                                      .withValues(alpha: 0.1),
                                  borderRadius:
                                      BorderRadius.circular(8),
                                ),
                                child: Text(
                                  r.code,
                                  style: const TextStyle(
                                    color: IrisTokens.brand,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      r.name,
                                      style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14,
                                        color: getThemedHeadingColor(
                                          style,
                                          effectiveIsDark,
                                          cs,
                                        ),
                                      ),
                                    ),
                                    if (r.attendant != null)
                                      Text(
                                        'Incharge: ${r.attendant} • ${r.mobile ?? ""}',
                                        style: TextStyle(
                                          fontSize: 11,
                                          fontWeight: FontWeight.w500,
                                          color: getThemedMutedColor(
                                            style,
                                            effectiveIsDark,
                                            cs,
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              if (r.type == 'lab')
                                const Icon(
                                  Icons.computer_rounded,
                                  size: 14,
                                  color: IrisTokens.purple,
                                )
                              else if (r.type == 'office')
                                const Icon(
                                  Icons.person_rounded,
                                  size: 14,
                                  color: IrisTokens.warning,
                                ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );

    if (style == IrisThemeStyle.fluidGlass) {
      sheetBody = ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: GlassSurface(
          settings: IrisGlass.settings(context, blur: 18.0, thickness: 16.0),
          radius: 28,
          child: sheetBody,
        ),
      );
    }

    return SizedBox(
      height: MediaQuery.sizeOf(context).height * 0.85,
      child: sheetBody,
    );
  }
}

/// Modal bottom sheet displaying detailed occupancy, schedule, and incharge contact info for a room.
class RoomDetailSheet extends StatelessWidget {
  final RoomAvailability availability;
  final List<ClassSession> roomSessions;
  final int targetDay;
  final String dayName;
  final bool isDark;

  const RoomDetailSheet({
    required this.availability,
    required this.roomSessions,
    required this.targetDay,
    required this.dayName,
    required this.isDark,
    super.key,
  });

  static void show(
    BuildContext context, {
    required RoomAvailability availability,
    required List<ClassSession> roomSessions,
    required int targetDay,
    required String dayName,
    required bool isDark,
  }) {
    IrisHaptics.actionSoft();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => RoomDetailSheet(
        availability: availability,
        roomSessions: roomSessions,
        targetDay: targetDay,
        dayName: dayName,
        isDark: isDark,
      ),
    );
  }

  Widget _buildMetricTile({
    required IconData icon,
    required String label,
    required String value,
    required bool isDark,
    required IrisThemeStyle style,
    required ColorScheme cs,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: getThemedInnerContainerDecoration(
        style,
        isDark,
        cs,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16, color: IrisTokens.brand),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: getThemedMutedColor(style, isDark, cs),
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: getThemedHeadingColor(style, isDark, cs),
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final statusColor =
        availability.isAvailable ? IrisTokens.success : IrisTokens.error;
    final roomDetails =
        RoomPersistenceService.parseRoomCode(availability.roomId);
    final locationText =
        availability.formattedLocation ?? roomDetails.formattedLocation;
    final effectiveIsDark = isDark || Theme.of(context).brightness == Brightness.dark;
    final cs = Theme.of(context).colorScheme;
    final style = ThemeSignals.themeStyle.value;

    Widget sheetBody = Container(
      decoration: getThemedSheetDecoration(style, effectiveIsDark, cs),
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 5,
              decoration: BoxDecoration(
                color: getThemedMutedColor(style, effectiveIsDark, cs)
                    .withValues(alpha: 0.35),
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          const SizedBox(height: 20),

          // Header row: Room ID + Status Chip
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      availability.roomId,
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.5,
                        color: getThemedHeadingColor(style, effectiveIsDark, cs),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(
                          Icons.business_rounded,
                          size: 14,
                          color: getThemedMutedColor(style, effectiveIsDark, cs),
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            locationText,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: getThemedMutedColor(style, effectiveIsDark, cs),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: statusColor.withValues(alpha: 0.25),
                    width: 1.2,
                  ),
                ),
                child: Text(
                  availability.isAvailable ? 'VACANT' : 'OCCUPIED',
                  style: TextStyle(
                    color: statusColor,
                    fontWeight: FontWeight.w900,
                    fontSize: 12,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          // Key Stats Grid
          Row(
            children: [
              Expanded(
                child: _buildMetricTile(
                  icon: Icons.group_rounded,
                  label: 'Capacity',
                  value: '${availability.capacity} Seats',
                  isDark: effectiveIsDark,
                  style: style,
                  cs: cs,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildMetricTile(
                  icon: Icons.timer_outlined,
                  label: availability.isAvailable
                      ? 'Free For'
                      : 'Occupied Until',
                  value: availability.isAvailable
                      ? (availability.minulesFreeUntilNextSession != null
                          ? '${availability.minulesFreeUntilNextSession}m'
                          : 'End of Day')
                      : FormatGuard.formatDecimalTime(
                          availability.occupiedUntil ?? 0,
                        ),
                  isDark: effectiveIsDark,
                  style: style,
                  cs: cs,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildMetricTile(
                  icon: Icons.bolt_rounded,
                  label: 'Study Score',
                  value: '${availability.studyScore.toInt()}%',
                  isDark: effectiveIsDark,
                  style: style,
                  cs: cs,
                ),
              ),
            ],
          ),

          if (roomDetails.attendant != null) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: getThemedInnerContainerDecoration(
                style,
                effectiveIsDark,
                cs,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: IrisTokens.brand.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.person_outline_rounded,
                      size: 20,
                      color: IrisTokens.brand,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Lab Incharge: ${roomDetails.attendant}',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            color: getThemedHeadingColor(style, effectiveIsDark, cs),
                          ),
                        ),
                        if (roomDetails.mobile != null) ...[
                          const SizedBox(height: 2),
                          Text(
                            'Contact: ${roomDetails.mobile}',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: getThemedMutedColor(style, effectiveIsDark, cs),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  if (roomDetails.mobile != null)
                    IconButton(
                      icon: const Icon(Icons.copy_rounded, size: 18),
                      onPressed: () {
                        Clipboard.setData(ClipboardData(text: roomDetails.mobile!));
                        IrisHaptics.actionSoft();
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'Copied ${roomDetails.attendant}\'s phone to clipboard',
                            ),
                            duration: const Duration(seconds: 2),
                            behavior: SnackBarBehavior.floating,
                          ),
                        );
                      },
                    ),
                ],
              ),
            ),
          ],

          const SizedBox(height: 20),

          // Amenities Tags
          if (availability.amenities.isNotEmpty) ...[
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: availability.amenities.map((am) {
                return Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: getThemedInnerContainerDecoration(
                    style,
                    effectiveIsDark,
                    cs,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    am,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: getThemedBodyColor(style, effectiveIsDark, cs),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
          ],

          // Schedule Title
          Text(
            '$dayName Schedule (${roomSessions.length} Classes)',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.0,
              color: getThemedMutedColor(style, effectiveIsDark, cs),
            ),
          ),
          const SizedBox(height: 12),

          // Schedule List
          Expanded(
            child: roomSessions.isEmpty
                ? Center(
                    child: Text(
                      'No classes scheduled today.\nPerfect quiet space for studying!',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: getThemedMutedColor(style, effectiveIsDark, cs),
                      ),
                    ),
                  )
                : ListView.builder(
                    physics: const BouncingScrollPhysics(),
                    itemCount: roomSessions.length,
                    itemBuilder: (ctx, idx) {
                      final s = roomSessions[idx];
                      final now = DateTime.now();
                      final curH = now.hour + (now.minute / 60.0);
                      final isOngoing = targetDay == now.weekday &&
                          s.safeStartVal <= curH &&
                          curH < s.actualEndVal;

                      return Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(12),
                        decoration: isOngoing
                            ? BoxDecoration(
                                color: IrisTokens.brand.withValues(alpha: 0.12),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: IrisTokens.brand.withValues(alpha: 0.35),
                                  width: 1.5,
                                ),
                              )
                            : getThemedInnerContainerDecoration(
                                style,
                                effectiveIsDark,
                                cs,
                                borderRadius: BorderRadius.circular(16),
                              ),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: (effectiveIsDark
                                        ? Colors.white
                                        : Colors.black)
                                    .withValues(alpha: 0.06),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                '${s.startTime} - ${s.endTime}',
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w800,
                                  color: getThemedHeadingColor(style, effectiveIsDark, cs),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    s.subject,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w800,
                                      fontSize: 13,
                                      color: getThemedHeadingColor(style, effectiveIsDark, cs),
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    '${s.teacher} • ${s.batchKey.batch}',
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: getThemedMutedColor(style, effectiveIsDark, cs),
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                            if (isOngoing)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: IrisTokens.brand,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Text(
                                  'NOW',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w900,
                                    fontSize: 10,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      );
                    },
                  ),
          ),

          const SizedBox(height: 16),

          // Quick Action: Copy Room Code
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () {
                Clipboard.setData(
                  ClipboardData(text: availability.roomId),
                );
                IrisHaptics.refreshSuccess();
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      'Copied room "${availability.roomId}" to clipboard',
                    ),
                    duration: const Duration(seconds: 2),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: IrisTokens.brand,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 0,
              ),
              icon: const Icon(Icons.copy_rounded, size: 18),
              label: const Text(
                'Copy Room Code',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 14,
                ),
              ),
            ),
          ),
        ],
      ),
    );

    if (style == IrisThemeStyle.fluidGlass) {
      sheetBody = ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: GlassSurface(
          settings: IrisGlass.settings(context, blur: 18.0, thickness: 16.0),
          radius: 28,
          child: sheetBody,
        ),
      );
    }

    return SizedBox(
      height: MediaQuery.sizeOf(context).height * 0.85,
      child: sheetBody,
    );
  }
}
