import 'sports_gala_view.dart';
import 'package:flutter/material.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/models.dart';
import '../../core/omni_brain.dart';
import '../../services/remote_config_service.dart';
import '../../services/ui_feedback.dart';
import '../iris_components.dart';
import 'package:iris/widgets/effects/glass_container_transform.dart';
import 'package:iris/screens/settings/announcements_screen.dart';

/// Pixel-perfect Classical Broadsheet Timetable View for Theme 4 Almanac.
/// Faithfully reproduces Almanac · Light.png and Almanac · Dark.png down to the
/// exact double rules, Scotch Roman typography, terracotta accents,
/// 3-column broadside table, and real-time live timetable synchronization.
class AlmanacScheduleView extends StatelessWidget {
  final OmniBrain brain;
  final String batch;
  final int activeDayIndex;
  final ValueChanged<int> onDaySelected;
  final VoidCallback onRefresh;
  final VoidCallback onOpenBatchSelector;
  final List<String> pendingChanges;
  final VoidCallback? onDismissChanges;
  final bool isFaculty;
  final String? teacherName;

  const AlmanacScheduleView({
    super.key,
    required this.brain,
    required this.batch,
    required this.activeDayIndex,
    required this.onDaySelected,
    required this.onRefresh,
    required this.onOpenBatchSelector,
    this.pendingChanges = const [],
    this.onDismissChanges,
    this.isFaculty = false,
    this.teacherName,
  });

  static const List<String> _weekdaysFull = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday',
  ];

  static const List<String> _weekdaysShort = [
    'Mon',
    'Tue',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun',
  ];

  static const List<String> _monthsShort = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final now = DateTime.now();

    // 1. Calculate active date corresponding to activeDayIndex (1 = Monday ... 7 = Sunday)
    final int currentWeekday = now.weekday; // 1 = Mon ... 7 = Sun
    final int dayDifference = activeDayIndex - currentWeekday;
    final DateTime activeDate = now.add(Duration(days: dayDifference));
    final String activeIdentity = isFaculty ? (teacherName ?? batch) : batch;

    // 2. Fetch real schedule sessions for the selected day
    final List<ClassSession> sessions = isFaculty
        ? brain.getMergedDayScheduleForTeacher(activeIdentity, activeDayIndex)
        : brain.getMergedDaySchedule(batch, activeDayIndex);

    // 3. Compute real current/next class and countdown
    final double currentTime = now.hour + (now.minute / 60.0);
    final ClassSession? currentClass = isFaculty
        ? brain.getCurrentClassForTeacher(activeIdentity, now)
        : brain.getCurrentClass(batch, now);
    final ClassSession? nextClass = isFaculty
        ? brain.getNextClassForTeacher(activeIdentity, now)
        : brain.getNextClass(batch, now);

    // Countdown formatting
    final String countdownDisplay;
    final String narrativeSentence;
    final String currentPartner = isFaculty
        ? (currentClass?.displayBatch ?? '')
        : (currentClass?.teacher ?? '');
    final String nextPartner = isFaculty
        ? (nextClass?.displayBatch ?? '')
        : (nextClass?.teacher ?? '');

    if (activeDayIndex == currentWeekday) {
      if (currentClass != null && currentClass.isLive(now)) {
        final double endVal = currentClass.actualEndVal;
        final int minutesLeft = ((endVal - currentTime) * 60).clamp(0, 300).round();
        final int hours = minutesLeft ~/ 60;
        final int mins = minutesLeft % 60;
        countdownDisplay = hours > 0 ? '${hours}h ${mins}m' : '${mins}m';
        narrativeSentence =
            'of active lecture in progress, then ${currentClass.subject} with $currentPartner in ${currentClass.room}.';
      } else if (nextClass != null && nextClass.dayIndex == now.weekday && nextClass.safeStartVal > currentTime) {
        final double startVal = nextClass.safeStartVal;
        final int minutesLeft = ((startVal - currentTime) * 60).clamp(0, 1440).round();
        final int hours = minutesLeft ~/ 60;
        final int mins = minutesLeft % 60;
        countdownDisplay = hours > 0 ? '${hours}h ${mins}m' : '${mins}m';
        if (minutesLeft <= 5) {
          narrativeSentence =
              '★ URGENT: Lecture begins in $minutesLeft mins! Proceed immediately to Room ${nextClass.room} for ${nextClass.subject} with $nextPartner.';
        } else if (sessions.any((s) => s.actualEndVal <= currentTime)) {
          narrativeSentence =
              'of interval break, then ${nextClass.subject} with $nextPartner in ${nextClass.room}.';
        } else {
          narrativeSentence =
              'of nothing scheduled, then ${nextClass.subject} with $nextPartner in ${nextClass.room}.';
        }
      } else if (nextClass != null && nextClass.dayIndex != now.weekday) {
        var daysAhead = (nextClass.dayIndex - now.weekday + 7) % 7;
        if (daysAhead == 0) daysAhead = 7;
        final totalMins = ((24.0 - currentTime) * 60 +
                (daysAhead - 1) * 24 * 60 +
                nextClass.safeStartVal * 60)
            .round();
        final hoursUntil = totalMins ~/ 60;
        final dayTarget = daysAhead == 1
            ? 'tomorrow'
            : _weekdaysFull[(nextClass.dayIndex - 1).clamp(0, 6)];
        countdownDisplay = 'in ${hoursUntil}h';
        narrativeSentence =
            'of all scheduled lectures completed for today. Next lecture $dayTarget at ${nextClass.startTime} with $nextPartner in ${nextClass.room}.';
      } else if (sessions.isNotEmpty && currentTime >= sessions.last.actualEndVal) {
        countdownDisplay = 'All clear';
        narrativeSentence =
            'of all scheduled lectures completed for today. Enjoy your evening!';
      } else if (sessions.isEmpty) {
        countdownDisplay = 'All clear';
        narrativeSentence = 'of no classes scheduled for today. Enjoy your day off!';
      } else {
        final firstSession = sessions.first;
        final firstPartner = isFaculty ? firstSession.displayBatch : firstSession.teacher;
        countdownDisplay = firstSession.startTime;
        narrativeSentence =
            'of nothing scheduled until ${firstSession.subject} with $firstPartner in ${firstSession.room}.';
      }
    } else {
      if (sessions.isEmpty) {
        countdownDisplay = 'Free day';
        narrativeSentence = 'of no classes scheduled for this day in the academic registry.';
      } else {
        countdownDisplay = sessions.first.startTime;
        narrativeSentence =
            'first session starts at ${sessions.first.startTime} with ${sessions.first.subject} in ${sessions.first.room}.';
      }
    }

    // 4. Header date strings (zero dependencies)
    final String dayName = _weekdaysFull[(activeDate.weekday - 1).clamp(0, 6)];
    final String spelledOutDate = AlmanacTokens.formatSpelledOutDate(activeDate);
    final String shortDay = _weekdaysShort[(now.weekday - 1).clamp(0, 6)];
    final String shortMonth = _monthsShort[(now.month - 1).clamp(0, 11)];
    final String dayPad = now.day.toString().padLeft(2, '0');
    final String topDateHeader = '$shortDay $dayPad $shortMonth ${now.year}'.toUpperCase();

    // 5. Next time line
    final String nextTimeStr = nextClass != null
        ? (nextClass.dayIndex == now.weekday
            ? nextClass.startTime
            : '${_weekdaysShort[(nextClass.dayIndex - 1).clamp(0, 6)]} ${nextClass.startTime}')
        : (sessions.isNotEmpty ? sessions.first.startTime : '--:--');
    final String nowTimeStr =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';

    return Container(
      color: AlmanacTokens.canvas(isDark),
      child: SafeArea(
        bottom: false,
        child: IrisRefreshIndicator(
          onRefresh: () async => onRefresh(),
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(
              parent: BouncingScrollPhysics(),
            ),
            padding: const EdgeInsets.fromLTRB(22, 14, 22, 110),
        children: [
          // 1. Top Header Row: IRIS · BATCH (left) and DATE (right)
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 8,
            runSpacing: 6,
            children: [
              GestureDetector(
                onTap: onOpenBatchSelector,
                behavior: HitTestBehavior.opaque,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'IRIS · $activeIdentity',
                      style: AlmanacTokens.monoHeader(isDark, fontSize: 11),
                    ),
                    const SizedBox(width: 4),
                    Icon(
                      Icons.arrow_drop_down_rounded,
                      size: 16,
                      color: AlmanacTokens.inkMuted(isDark),
                    ),
                  ],
                ),
              ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  GestureDetector(
                    onTap: () {
                      IrisHaptics.actionMedium();
                      pushGlassContainerMorphRoute(
                        context,
                        page: const AnnouncementsScreen(),
                        accentColor: AlmanacTokens.accentTerracotta(isDark),
                      );
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                      decoration: BoxDecoration(
                        color: AlmanacTokens.cardSurface(isDark),
                        border: Border.all(
                          color: AlmanacTokens.inkRule(isDark),
                          width: 0.8,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.newspaper_rounded,
                            size: 13,
                            color: AlmanacTokens.accentTerracotta(isDark),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'CHRONICLE',
                            style: AlmanacTokens.monoHeader(
                              isDark,
                              fontSize: 9.5,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.8,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    topDateHeader,
                    style: AlmanacTokens.monoHeader(isDark, fontSize: 11),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 10),

          // 2. Double Horizontal Hairline Rule
          _buildDoubleRule(isDark),
          const SizedBox(height: 12),

          // 2A. Live Emergency Announcement / Campus Gazette Bulletin
          ValueListenableBuilder<Map<String, dynamic>?>(
            valueListenable: RemoteConfigService.liveAnnouncement,
            builder: (context, announcement, _) {
              if (announcement == null) return const SizedBox.shrink();
              final msg = announcement['message']?.toString() ?? '';
              if (msg.trim().isEmpty) return const SizedBox.shrink();

              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AlmanacTokens.cardSurface(isDark),
                    border: Border.all(
                      color: AlmanacTokens.accentTerracotta(isDark),
                      width: 1.0,
                    ),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.campaign_rounded,
                        size: 18,
                        color: AlmanacTokens.accentTerracotta(isDark),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '★ SPECIAL GAZETTE BULLETIN',
                              style: AlmanacTokens.monoHeader(
                                isDark,
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 1.0,
                                color: AlmanacTokens.accentTerracotta(isDark),
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              msg,
                              style: AlmanacTokens.serifHeadline(
                                isDark,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),

          // 2B. System Update Dispatch (if new APK is available)
          ValueListenableBuilder<Map<String, dynamic>?>(
            valueListenable: RemoteConfigService.latestApkUpdate,
            builder: (context, updateInfo, _) {
              if (updateInfo == null) return const SizedBox.shrink();
              final ver = updateInfo['version'] ?? updateInfo['latest_version'] ?? 'New';
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: AlmanacTokens.cardSurface(isDark),
                    border: Border.all(
                      color: AlmanacTokens.inkRule(isDark),
                      width: 1.0,
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.system_update_rounded,
                        size: 16,
                        color: AlmanacTokens.accentTerracotta(isDark),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'SYSTEM DISPATCH: Version $ver is available',
                          style: AlmanacTokens.monoHeader(
                            isDark,
                            fontSize: 10.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),

          // 2B-Mode. Sports Week / Ramadan Dispatch
          ValueListenableBuilder<String>(
            valueListenable: RemoteConfigService.activeAcademicPeriod,
            builder: (context, activePeriod, _) {
              if (activePeriod == 'sports_week') {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 14),
                  child: StudentsWeekInfoCard(isFaculty: isFaculty),
                );
              }
              if (activePeriod == 'ramadan') {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: AlmanacTokens.cardSurface(isDark),
                      border: Border.all(
                        color: AlmanacTokens.inkRule(isDark),
                        width: 1.0,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.nights_stay_rounded,
                          size: 15,
                          color: AlmanacTokens.accentTerracotta(isDark),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'RAMADAN SCHEDULE ACTIVE · 1-HOUR COMPRESSED SLOTS (08:30 – 13:30)',
                            style: AlmanacTokens.monoHeader(
                              isDark,
                              fontSize: 10.0,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }
              return const SizedBox.shrink();
            },
          ),

          // 2C. Timetable Revision Bulletin (if revisions are published)
          if (pendingChanges.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AlmanacTokens.cardSurface(isDark),
                  border: Border.all(
                    color: AlmanacTokens.accentTerracotta(isDark),
                    width: 1.0,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.history_edu_rounded,
                          size: 16,
                          color: AlmanacTokens.accentTerracotta(isDark),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            '★ TIMETABLE REVISION BULLETIN',
                            style: AlmanacTokens.monoHeader(
                              isDark,
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              color: AlmanacTokens.accentTerracotta(isDark),
                              letterSpacing: 0.8,
                            ),
                          ),
                        ),
                        if (onDismissChanges != null)
                          GestureDetector(
                            onTap: onDismissChanges,
                            child: Icon(
                              Icons.close_rounded,
                              size: 16,
                              color: AlmanacTokens.inkMuted(isDark),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    ...pendingChanges.map(
                      (change) => Padding(
                        padding: const EdgeInsets.only(top: 3),
                        child: Text(
                          '• $change',
                          style: AlmanacTokens.monoHeader(
                            isDark,
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],

          // 3. Primary Headline (Day Name & Spelled-out Ordinal Date)
          Text(
            dayName,
            style: AlmanacTokens.heroDayTitle(isDark),
          ),
          const SizedBox(height: 2),
          Text(
            spelledOutDate,
            style: AlmanacTokens.heroDateSubtitle(isDark),
          ),
          const SizedBox(height: 20),

          // 4. Week Day Carousel (S 18 ... S 24 with Terracotta Active Ring)
          _buildDayCarousel(context, isDark, now),
          const SizedBox(height: 18),

          // 5. Single Hairline Divider Rule
          Container(
            height: 0.8,
            color: AlmanacTokens.inkRuleSubtle(isDark),
          ),
          const SizedBox(height: 18),

          // 6. Countdown / Next Session Meta Line
          Text(
            'NEXT · $nextTimeStr · NOW $nowTimeStr',
            style: AlmanacTokens.monoHeader(isDark, fontSize: 11),
          ),
          const SizedBox(height: 6),

          // 7. Giant Countdown Numbers
          Text(
            countdownDisplay,
            style: AlmanacTokens.countdownNumbers(isDark),
          ),
          const SizedBox(height: 8),

          // 8. Editorial Narrative Sentence
          Text(
            narrativeSentence,
            style: AlmanacTokens.countdownNarrative(isDark),
          ),
          const SizedBox(height: 24),

          // 9. Timetable Section Headers (TIME · TODAY'S TIMETABLE · ROOM)
          Row(
            children: [
              SizedBox(
                width: 75,
                child: Text(
                  'TIME',
                  style: AlmanacTokens.monoHeader(isDark, fontSize: 10.5),
                ),
              ),
              Expanded(
                child: Text(
                  "TODAY'S TIMETABLE",
                  textAlign: TextAlign.center,
                  style: AlmanacTokens.monoHeader(isDark, fontSize: 10.5),
                ),
              ),
              SizedBox(
                width: 85,
                child: Text(
                  'ROOM',
                  textAlign: TextAlign.right,
                  style: AlmanacTokens.monoHeader(isDark, fontSize: 10.5),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // Thin divider line under table headers
          Container(
            height: 0.8,
            color: AlmanacTokens.inkRuleSubtle(isDark),
          ),

          // 10. Timetable Rows (Real Live Classes)
          if (sessions.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 24),
              child: Center(
                child: Text(
                  '[No classes scheduled for $dayName]',
                  style: AlmanacTokens.countdownNarrative(isDark),
                ),
              ),
            )
          else
            ...sessions.map((session) => _buildClassRow(context, session, isDark, now)),

          const SizedBox(height: 8),

          // 11. Closing Double Rule for Timetable
          _buildDoubleRule(isDark),
          const SizedBox(height: 20),

          // 12. Footer Real Sync Timestamp
          ValueListenableBuilder<DateTime?>(
            valueListenable: RemoteConfigService.lastTimetableUpdateTime,
            builder: (context, lastSync, _) {
              final syncTime = lastSync ?? RemoteConfigService.lastConfigUpdateTime.value;
              final hour12 = now.hour % 12 == 0 ? 12 : now.hour % 12;
              final ampm = now.hour >= 12 ? 'PM' : 'AM';
              final minPad = now.minute.toString().padLeft(2, '0');
              final syncTimeStr = syncTime != null
                  ? RemoteConfigService.formatTimestamp(syncTime)
                  : '$shortMonth ${now.day}, $hour12:$minPad $ampm';

              return Text(
                'Timetable synced $syncTimeStr',
                style: AlmanacTokens.monoHeader(
                  isDark,
                  fontSize: 11,
                  letterSpacing: 0.8,
                ),
              );
            },
          ),
        ],
      ),
    ),
  ),
);
}

  // ---------------------------------------------------------------------------
  // Double Hairline Rule (Broadside Signature)
  // ---------------------------------------------------------------------------
  Widget _buildDoubleRule(bool isDark) {
    final color = AlmanacTokens.inkRule(isDark);
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(height: 1.5, color: color),
        const SizedBox(height: 3.5),
        Container(height: 0.8, color: color),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // 7-Day Carousel (Matching S 18 ... S 24 in Almanac Mockup)
  // ---------------------------------------------------------------------------
  Widget _buildDayCarousel(BuildContext context, bool isDark, DateTime now) {
    // Current week Sunday-through-Saturday or Mon-through-Sun matching mockup
    // In Almanac mockup: S 18, M 19, T 20, W 21, T 22, F 23, S 24
    // 19 was Monday, 18 was Sunday! So it starts on Sunday!
    final int currentWeekday = now.weekday; // 1 = Mon ... 7 = Sun
    // Days since last Sunday:
    final int daysSinceSunday = currentWeekday % 7;
    final DateTime weekSunday = now.subtract(Duration(days: daysSinceSunday));

    const List<String> dayLetters = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    // Corresponding weekday indices: Sun = 7, Mon = 1, Tue = 2, Wed = 3, Thu = 4, Fri = 5, Sat = 6
    const List<int> weekdayIndices = [7, 1, 2, 3, 4, 5, 6];

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: List.generate(7, (i) {
        final DateTime dayDate = weekSunday.add(Duration(days: i));
        final int dayWeekday = weekdayIndices[i];
        final bool isSelected = activeDayIndex == dayWeekday;
        final String dayLetter = dayLetters[i];
        final String dayNumber = dayDate.day.toString();

        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            if (activeDayIndex != dayWeekday) {
              IrisHaptics.selectionClick();
              onDaySelected(dayWeekday);
            }
          },
          child: SizedBox(
            width: 44,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (isSelected)
                  Container(
                    width: 40,
                    height: 48,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: AlmanacTokens.accentTerracotta(isDark),
                        width: 1.5,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          dayLetter,
                          style: AlmanacTokens.monoHeader(
                            isDark,
                            fontSize: 10.5,
                            fontWeight: FontWeight.w700,
                            color: AlmanacTokens.inkHeading(isDark),
                          ),
                        ),
                        Text(
                          dayNumber,
                          style: AlmanacTokens.monoMeta(
                            isDark,
                            fontSize: 14.5,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  )
                else
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          dayLetter,
                          style: AlmanacTokens.monoHeader(
                            isDark,
                            fontSize: 10.5,
                            fontWeight: FontWeight.w600,
                            color: AlmanacTokens.inkMuted(isDark),
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          dayNumber,
                          style: AlmanacTokens.monoMeta(
                            isDark,
                            fontSize: 14.5,
                            fontWeight: FontWeight.w700,
                            color: AlmanacTokens.inkHeading(isDark),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        );
      }),
    );
  }

  // ---------------------------------------------------------------------------
  // Real Class Row (Exact 3-Column Newspaper Table)
  // ---------------------------------------------------------------------------
  Widget _buildClassRow(
    BuildContext context,
    ClassSession session,
    bool isDark,
    DateTime now,
  ) {
    final bool isLive = session.isLive(now);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Column 1: Time (Start Time / End Time)
              SizedBox(
                width: 75,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      session.startTime,
                      style: AlmanacTokens.monoMeta(
                        isDark,
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: isLive
                            ? AlmanacTokens.accentTerracotta(isDark)
                            : AlmanacTokens.inkHeading(isDark),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      session.endTime,
                      style: AlmanacTokens.monoHeader(
                        isDark,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),

              // Column 2: Subject Title
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Text(
                    session.subject,
                    style: AlmanacTokens.subjectTitle(isDark),
                  ),
                ),
              ),

              // Column 3: Room Code + Instructor
              SizedBox(
                width: 85,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      session.room,
                      textAlign: TextAlign.right,
                      style: AlmanacTokens.monoMeta(
                        isDark,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: isLive
                            ? AlmanacTokens.accentTerracotta(isDark)
                            : AlmanacTokens.inkHeading(isDark),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      isFaculty ? session.batchKey.batch : session.teacher,
                      textAlign: TextAlign.right,
                      style: AlmanacTokens.monoHeader(
                        isDark,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        // Hairline Divider between rows
        Container(
          height: 0.6,
          color: AlmanacTokens.inkRuleSubtle(isDark),
        ),
      ],
    );
  }
}
