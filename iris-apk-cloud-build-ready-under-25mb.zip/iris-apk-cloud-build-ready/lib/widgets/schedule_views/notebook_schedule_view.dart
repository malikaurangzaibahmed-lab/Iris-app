import 'sports_gala_view.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iris/core/models.dart';
import 'package:iris/core/notebook_theme_tokens.dart';
import 'package:iris/core/omni_brain.dart';
import 'package:iris/services/remote_config_service.dart';
import 'package:iris/services/ui_feedback.dart';
import 'package:iris/widgets/iris_components.dart';
import 'package:iris/widgets/effects/glass_container_transform.dart';
import 'package:iris/screens/settings/announcements_screen.dart';

/// Authentic Student Bullet Journal & Notebook Schedule View
/// (Modeled with 100% pixel fidelity after Notebook · Light.png & Notebook · Dark.png).
/// Features spatial 3D metallic spiral rings, washi tape overhangs breaking card bounds,
/// curled paper corners, fluorescent highlighter marks, and hand-drawn doodles.
class NotebookScheduleView extends StatelessWidget {
  final OmniBrain brain;
  final String batch;
  final int activeDayIndex; // 1=Mon ... 7=Sun
  final ValueChanged<int> onDaySelected;
  final Future<void> Function() onRefresh;
  final VoidCallback onOpenBatchSelector;
  final ScrollController? scrollController;
  final List<String> pendingChanges;
  final VoidCallback? onDismissChanges;
  final String? userName;
  final bool isFaculty;
  final String? teacherName;

  const NotebookScheduleView({
    super.key,
    required this.brain,
    required this.batch,
    required this.activeDayIndex,
    required this.onDaySelected,
    required this.onRefresh,
    required this.onOpenBatchSelector,
    this.scrollController,
    this.pendingChanges = const [],
    this.onDismissChanges,
    this.userName,
    this.isFaculty = false,
    this.teacherName,
  });

  static const List<String> _months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];
  static const List<String> _weekdays = [
    'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final topPadding = MediaQuery.paddingOf(context).top;
    final now = DateTime.now();
    final todayWeekday = now.weekday; // 1=Mon ... 7=Sun
    final isViewingToday = activeDayIndex == todayWeekday;
    final String activeIdentity = isFaculty ? (teacherName ?? batch) : batch;

    final currentClass = isViewingToday
        ? (isFaculty ? brain.getCurrentClassForTeacher(activeIdentity, now) : brain.getCurrentClass(batch, now))
        : null;
    final nextClass = isViewingToday
        ? (isFaculty ? brain.getNextClassForTeacher(activeIdentity, now) : brain.getNextClass(batch, now))
        : null;
    final rawSessions = isFaculty
        ? brain.getMergedDayScheduleForTeacher(activeIdentity, activeDayIndex)
        : brain.getMergedDaySchedule(batch, activeDayIndex);
    final sortedSessions = List<ClassSession>.from(rawSessions)
      ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));

    final isLive = currentClass != null;
    final targetClass = currentClass ?? nextClass ?? (sortedSessions.isNotEmpty ? sortedSessions.first : null);

    return Container(
      color: NotebookTokens.canvas(isDark),
      child: CustomPaint(
        painter: NotebookGraphPaperPainter(
          isDark: isDark,
          gridSize: 22.0,
          marginX: 42.0,
        ),
        child: IrisRefreshIndicator(
          onRefresh: onRefresh,
          color: NotebookTokens.redDoodle(isDark),
          backgroundColor: isDark ? const Color(0xFF23302A) : Colors.white,
          child: CustomScrollView(
            controller: scrollController,
            physics: const AlwaysScrollableScrollPhysics(
              parent: BouncingScrollPhysics(),
            ),
            slivers: [
              // 1. Spatial 3D Metallic Spiral Rings at Pad Top
              SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.only(top: topPadding + 14, left: 14, right: 14),
                  child: NotebookSpiralRings(
                    ringCount: 12,
                    isDark: isDark,
                  ),
                ),
              ),

              // 2. Notebook Masthead & Header
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(48, 12, 20, 10),
                  child: _buildNotebookHeader(context, isDark, isViewingToday, now),
                ),
              ),

              // 3. 7-Day Calendar Strip with Hand-Drawn Circle
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(44, 4, 16, 18),
                  child: _build7DayStrip(context, isDark, now),
                ),
              ),

              // 3B. Sports Week / Ramadan Sticky Note
              ValueListenableBuilder<String>(
                valueListenable: RemoteConfigService.activeAcademicPeriod,
                builder: (context, activePeriod, _) {
                  if (activePeriod == 'sports_week') {
                    return SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(24, 0, 12, 14),
                        child: StudentsWeekInfoCard(isFaculty: isFaculty),
                      ),
                    );
                  }
                  return const SliverToBoxAdapter(child: SizedBox.shrink());
                },
              ),

              // 4. Hero Yellow Sticky Note (Breaks Bounds with 3D Tape & Curled Corner)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(28, 10, 20, 22),
                  child: _buildHeroStickyNote(
                    context,
                    isDark: isDark,
                    targetClass: targetClass,
                    isLive: isLive,
                    isViewingToday: isViewingToday,
                    now: now,
                  ),
                ),
              ),

              // 5. Section Header ("today's cards" + live sync time) - Only shown if cards exist
              if (sortedSessions.isNotEmpty) ...[
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(48, 4, 20, 12),
                    child: Wrap(
                      alignment: WrapAlignment.spaceBetween,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      spacing: 8,
                      runSpacing: 4,
                      children: [
                        Text(
                          isViewingToday ? "today's cards" : "schedule cards",
                          style: NotebookTokens.boldScript(
                            isDark,
                            fontSize: 22,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        ValueListenableBuilder<DateTime?>(
                          valueListenable: RemoteConfigService.lastTimetableUpdateTime,
                          builder: (context, lastSync, _) {
                            final syncTime = lastSync ?? RemoteConfigService.lastConfigUpdateTime.value ?? now;
                            final h12 = syncTime.hour % 12 == 0 ? 12 : syncTime.hour % 12;
                            final ampm = syncTime.hour >= 12 ? 'pm' : 'am';
                            final mPad = syncTime.minute.toString().padLeft(2, '0');
                            final monthStr = _months[syncTime.month - 1];
                            return Text(
                              'synced $monthStr ${syncTime.day}, $h12:$mPad $ampm',
                              style: GoogleFonts.patrickHand(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: NotebookTokens.inkMuted(isDark),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),

                // 6. Lecture Cards (Crisp Paper Slips with Yellow Tape Overhangs)
                SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      final session = sortedSessions[index];
                      final isSessionLive = isLive && currentClass.id == session.id;
                      return Padding(
                        padding: const EdgeInsets.fromLTRB(36, 6, 20, 14),
                        child: _buildClassPaperCard(
                          context,
                          isDark: isDark,
                          session: session,
                          isLive: isSessionLive,
                        ),
                      );
                    },
                    childCount: sortedSessions.length,
                  ),
                ),
              ],


              const SliverToBoxAdapter(
                child: SizedBox(height: 120),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 1. Notebook Masthead & Header
  // ---------------------------------------------------------------------------
  Widget _buildNotebookHeader(BuildContext context, bool isDark, bool isViewingToday, DateTime now) {
    final activeDate = _getDateForSelectedDay(now);
    final dateStr = '${_weekdays[activeDate.weekday - 1]}, ${activeDate.day} ${_months[activeDate.month - 1]}';
    final allBatches = brain.memory.allBatches;
    final batchCode = isFaculty
        ? (teacherName?.trim().isNotEmpty == true ? teacherName!.trim() : 'Faculty')
        : (batch.trim().isNotEmpty
            ? batch.trim()
            : (allBatches.isNotEmpty ? allBatches.first : 'COMSATS'));
    final studentName = (userName != null && userName!.trim().isNotEmpty)
        ? userName!.trim()
        : (isFaculty && teacherName?.trim().isNotEmpty == true
              ? teacherName!.trim()
              : 'Student');
    final greeting = _getGreetingText(now, isViewingToday);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          alignment: WrapAlignment.spaceBetween,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 8,
          runSpacing: 6,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  dateStr,
                  style: NotebookTokens.headerDate(isDark),
                ),
                const SizedBox(height: 2),
                CustomPaint(
                  size: const Size(120, 10),
                  painter: HandDrawnSquiggleUnderlinePainter(
                    color: NotebookTokens.redDoodle(isDark),
                    strokeWidth: 2.2,
                  ),
                ),
              ],
            ),

            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Stamped Batch Box Trigger
                GestureDetector(
                  onTap: () {
                    IrisHaptics.actionSoft();
                    onOpenBatchSelector();
                  },
                  child: Transform.rotate(
                    angle: -0.04,
                    child: CustomPaint(
                      painter: HandDrawnBatchBoxPainter(
                        color: NotebookTokens.redDoodle(isDark),
                        strokeWidth: 1.8,
                      ),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        child: Text(
                          batchCode,
                          style: GoogleFonts.kalam(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.6,
                            color: NotebookTokens.redDoodle(isDark),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),

                // Pushpin Notices Trigger
                GestureDetector(
                  onTap: () {
                    IrisHaptics.actionMedium();
                    pushGlassContainerMorphRoute(
                      context,
                      page: const AnnouncementsScreen(),
                      accentColor: NotebookTokens.redDoodle(isDark),
                    );
                  },
                  child: Transform.rotate(
                    angle: 0.04,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: isDark ? const Color(0xFF2E3832) : const Color(0xFFFFFBEB),
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(
                          color: NotebookTokens.redDoodle(isDark).withValues(alpha: 0.6),
                          width: 1.2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: isDark ? 0.3 : 0.08),
                            offset: const Offset(1, 2),
                            blurRadius: 3,
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.push_pin_rounded,
                            size: 13,
                            color: NotebookTokens.redDoodle(isDark),
                          ),
                          const SizedBox(width: 3),
                          Text(
                            'notices',
                            style: GoogleFonts.caveat(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: NotebookTokens.inkHeading(isDark),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          isViewingToday
              ? '$greeting, $studentName'
              : '$greeting ${_weekdays[activeDate.weekday - 1].toLowerCase()}',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: NotebookTokens.cursiveGreeting(isDark),
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // 2. 7-Day Calendar Strip with Hand-Drawn Circle
  // ---------------------------------------------------------------------------
  Widget _build7DayStrip(BuildContext context, bool isDark, DateTime now) {
    const daysInitials = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    final weekStart = now.subtract(Duration(days: now.weekday % 7));
    final currentSelectedStripIndex = activeDayIndex % 7; // 7 -> 0 (Sun), 1 -> 1 (Mon) ...

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: List.generate(7, (index) {
        final dayDate = weekStart.add(Duration(days: index));
        final isSelected = currentSelectedStripIndex == index;

        return GestureDetector(
          onTap: () {
            IrisHaptics.selectionClick();
            final targetDay = index == 0 ? 7 : index;
            onDaySelected(targetDay);
          },
          behavior: HitTestBehavior.opaque,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                daysInitials[index],
                style: GoogleFonts.caveat(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  fontStyle: FontStyle.italic,
                  color: NotebookTokens.inkMuted(isDark),
                ),
              ),
              const SizedBox(height: 2),
              SizedBox(
                width: 34,
                height: 34,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    if (isSelected)
                      CustomPaint(
                        size: const Size(34, 34),
                        painter: HandDrawnDayCirclePainter(
                          color: NotebookTokens.redDoodle(isDark),
                          strokeWidth: 2.0,
                        ),
                      ),
                    Text(
                      '${dayDate.day}',
                      style: GoogleFonts.kalam(
                        fontSize: 17,
                        fontWeight: isSelected ? FontWeight.w700 : FontWeight.w600,
                        color: isSelected
                            ? NotebookTokens.inkHeading(isDark)
                            : NotebookTokens.inkBody(isDark),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      }),
    );
  }

  // ---------------------------------------------------------------------------
  // 3. Hero Yellow Sticky Note (Breaks Bounds with 3D Tape & Curled Corner)
  // ---------------------------------------------------------------------------
  Widget _buildHeroStickyNote(
    BuildContext context, {
    required bool isDark,
    required ClassSession? targetClass,
    required bool isLive,
    required bool isViewingToday,
    required DateTime now,
  }) {
    if (targetClass == null) {
      return _buildEmptyStateStickyNote(isDark);
    }

    final bool isFutureDayClass = isViewingToday && targetClass.dayIndex != now.weekday;
    final contextHeadline = isViewingToday
        ? (isLive
            ? 'ongoing lecture'
            : (isFutureDayClass
                ? 'next up · ${(targetClass.dayIndex - now.weekday + 7) % 7 == 1 ? "tomorrow" : _weekdays[targetClass.dayIndex - 1].toLowerCase()}'
                : (now.hour < 9 ? 'next up · early morning' : 'next up on schedule')))
        : 'upcoming lecture';

    final studyTip = isViewingToday
        ? (isLive
            ? 'in session now'
            : (isFutureDayClass
                ? (now.hour >= 21 ? 'rest well tonight!' : 'free. review notes!')
                : (now.hour < 6 ? 'sleep first!' : (now.hour < 9 ? 'morning coffee!' : 'ready your books'))))
        : 'ready your notes';

    final countdownStr = _computeCountdown(targetClass, isLive: isLive, now: now);

    final displayLabel = isViewingToday
        ? (isLive ? 'ends in ' : 'in ')
        : 'starts at ';

    final displayValue = isViewingToday ? countdownStr : targetClass.startTime;

    return Stack(
      clipBehavior: Clip.none,
      children: [
        // 1. The Yellow Sticky Note Body
        Container(
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(22, 22, 22, 20),
          decoration: BoxDecoration(
            color: NotebookTokens.stickyNote(isDark),
            borderRadius: BorderRadius.circular(4),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.14),
                offset: const Offset(2, 6),
                blurRadius: 10,
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Headline
              Text(
                contextHeadline,
                style: GoogleFonts.caveat(
                  fontSize: 17,
                  fontStyle: FontStyle.italic,
                  fontWeight: FontWeight.w700,
                  color: const Color(0xFF6B5826),
                ),
              ),
              const SizedBox(height: 6),

              // Subject Title
              Text(
                targetClass.subject,
                style: GoogleFonts.kalam(
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -0.3,
                  height: 1.15,
                  color: const Color(0xFF1C1917),
                ),
              ),
              const SizedBox(height: 8),

              // Time, Room & Instructor
              Text(
                '${targetClass.startTime} – ${targetClass.endTime} · room ${targetClass.room} · ${isFaculty ? targetClass.displayBatch : targetClass.teacher}',
                style: GoogleFonts.caveat(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: const Color(0xFF4A3E1B),
                ),
              ),
              const SizedBox(height: 16),

              // Countdown Digits with Fluorescent Pink Highlighter
              Wrap(
                alignment: WrapAlignment.spaceBetween,
                crossAxisAlignment: WrapCrossAlignment.end,
                spacing: 8,
                runSpacing: 4,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        displayLabel,
                        style: GoogleFonts.caveat(
                          fontSize: 22,
                          fontStyle: FontStyle.italic,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xFF1C1917),
                        ),
                      ),
                      HighlighterSwash(
                        color: NotebookTokens.highlighterPink,
                        child: Text(
                          displayValue,
                          style: GoogleFonts.kalam(
                            fontSize: 32,
                            fontWeight: FontWeight.w700,
                            height: 1.0,
                            letterSpacing: -0.5,
                            color: const Color(0xFF1C1917),
                          ),
                        ),
                      ),
                    ],
                  ),

                  // Handwritten Contextual Note
                  Text(
                    studyTip,
                    style: GoogleFonts.caveat(
                      fontSize: 18,
                      fontStyle: FontStyle.italic,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF2C2510),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),

        // 2. 3D Curled Paper Corner (Bottom-Right)
        Positioned(
          bottom: 0,
          right: 0,
          child: CurledPaperCorner(
            size: 24,
            isDark: isDark,
            paperColor: NotebookTokens.stickyNote(isDark),
          ),
        ),

        // 3. Washi Tape Overhang (Breaks out of the top bounds by 14dp!)
        Positioned(
          top: -12,
          left: 0,
          right: 0,
          child: Center(
            child: WashiTapeOverhang(
              width: 84,
              height: 22,
              color: NotebookTokens.tapeFrosted,
              rotation: -0.02,
            ),
          ),
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // 4. Lecture Cards (Crisp Paper Slips with Yellow Tape Overhangs)
  // ---------------------------------------------------------------------------
  Widget _buildClassPaperCard(
    BuildContext context, {
    required bool isDark,
    required ClassSession session,
    required bool isLive,
  }) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        // Crisp White Paper Slip
        Container(
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF23302A) : Colors.white,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(
              color: isDark ? const Color(0xFF2F453B) : const Color(0xFFE5E0D6),
              width: 0.8,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: isDark ? 0.28 : 0.08),
                offset: const Offset(1, 4),
                blurRadius: 7,
              ),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Start Time in Red Doodle Script
              SizedBox(
                width: 68,
                child: Text(
                  session.startTime,
                  style: GoogleFonts.kalam(
                    fontSize: 21,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.2,
                    color: NotebookTokens.redDoodle(isDark),
                  ),
                ),
              ),

              const SizedBox(width: 10),

              // Subject & Details
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      session.subject,
                      style: GoogleFonts.kalam(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        letterSpacing: -0.2,
                        height: 1.15,
                        color: NotebookTokens.inkHeading(isDark),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${session.room} · ${isFaculty ? (session.displayBatch.isNotEmpty ? session.displayBatch : "Class") : session.teacher}',
                      style: GoogleFonts.caveat(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: NotebookTokens.inkMuted(isDark),
                      ),
                    ),
                    if (isFaculty && session.isCombinedLecture) ...[
                      const SizedBox(height: 3),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                        decoration: BoxDecoration(
                          color: NotebookTokens.redDoodle(isDark).withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(3),
                          border: Border.all(
                            color: NotebookTokens.redDoodle(isDark).withValues(alpha: 0.4),
                            width: 0.8,
                          ),
                        ),
                        child: Text(
                          'combined section',
                          style: GoogleFonts.caveat(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: NotebookTokens.redDoodle(isDark),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),

              if (isLive) ...[
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                  decoration: BoxDecoration(
                    color: const Color(0xFF10B981).withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: const Color(0xFF10B981), width: 1.0),
                  ),
                  child: Text(
                    'LIVE',
                    style: GoogleFonts.kalam(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF10B981),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),

        // Yellow Washi Tape Overhang (Stuck on top-left edge breaking card boundary!)
        Positioned(
          top: -10,
          left: 18,
          child: WashiTapeOverhang(
            width: 48,
            height: 18,
            color: NotebookTokens.tapeYellow,
            rotation: 0.04,
          ),
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // Empty State Sticky Note
  // ---------------------------------------------------------------------------
  Widget _buildEmptyStateStickyNote(bool isDark) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: NotebookTokens.stickyNote(isDark),
        borderRadius: BorderRadius.circular(4),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.3 : 0.1),
            offset: const Offset(2, 4),
            blurRadius: 8,
          ),
        ],
      ),
      child: Column(
        children: [
          const Icon(
            Icons.spa_rounded,
            size: 36,
            color: Color(0xFF5A4820),
          ),
          const SizedBox(height: 8),
          Text(
            'All clear! No cards today',
            style: GoogleFonts.kalam(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: const Color(0xFF1C1917),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Time to relax, review notes, or explore the library.',
            textAlign: TextAlign.center,
            style: GoogleFonts.caveat(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: const Color(0xFF4A3E1B),
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------
  DateTime _getDateForSelectedDay(DateTime now) {
    final currentDay = now.weekday; // 1=Mon ... 7=Sun
    final diff = activeDayIndex - currentDay;
    return now.add(Duration(days: diff));
  }

  String _getGreetingText(DateTime now, bool isViewingToday) {
    if (!isViewingToday) return 'notes for';
    final hour = now.hour;
    if (hour < 5 || hour >= 21) return 'good night';
    if (hour < 12) return 'good morning';
    if (hour < 17) return 'good afternoon';
    return 'good evening';
  }

  String _computeCountdown(ClassSession session, {required bool isLive, required DateTime now}) {
    final currentHour = now.hour + (now.minute / 60.0);
    if (isLive) {
      final diff = session.actualEndVal - currentHour;
      if (diff <= 0) return '0m';
      final totalMins = (diff * 60).round();
      final h = totalMins ~/ 60;
      final m = totalMins % 60;
      return h > 0 ? '${h}h ${m}m' : '${m}m';
    }

    if (session.dayIndex == now.weekday && session.safeStartVal > currentHour) {
      final diff = session.safeStartVal - currentHour;
      final totalMins = (diff * 60).round();
      final h = totalMins ~/ 60;
      final m = totalMins % 60;
      return h > 0 ? '${h}h ${m}m' : '${m}m';
    }

    if (session.dayIndex != now.weekday) {
      var daysAhead = (session.dayIndex - now.weekday + 7) % 7;
      if (daysAhead == 0) daysAhead = 7;
      final totalMins = ((24.0 - currentHour) * 60 +
              (daysAhead - 1) * 24 * 60 +
              session.safeStartVal * 60)
          .round();
      final h = totalMins ~/ 60;
      final m = totalMins % 60;
      if (h >= 24) {
        return '${daysAhead}d ${h % 24}h';
      }
      return h > 0 ? '${h}h ${m}m' : '${m}m';
    }

    return '0m';
  }
}
