import 'dart:ui';
import 'package:flutter/material.dart';
import '../../services/ui_feedback.dart';
import '../../core/theme_signals.dart';
import '../../core/glass.dart';
import 'package:material_3_expressive/material_3_expressive.dart';
import 'package:iris/widgets/navigation/iris_expressive_header.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';

/// Delegate for the Huge Collapsing Sticky Notice Card during Vacation Mode.
/// Smoothly compresses from a grand 340dp vertical card into a sleek 88dp sticky header.
class VacationStickyHeaderDelegate extends SliverPersistentHeaderDelegate {
  final String batch;
  final int daysLeft;
  final String targetSemester;
  final VoidCallback? onNoticeTap;

  VacationStickyHeaderDelegate({
    required this.batch,
    this.daysLeft = 42,
    this.targetSemester = 'Next Semester',
    this.onNoticeTap,
  });

  @override
  double get minExtent => 88.0;

  @override
  double get maxExtent => ThemeSignals.isMaterialYou ? 190.0 : 340.0;

  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final topPadding = MediaQuery.of(context).padding.top;

    // Progress from 0.0 (fully expanded) to 1.0 (fully collapsed)
    final progress = (shrinkOffset / (maxExtent - minExtent)).clamp(0.0, 1.0);
    final expandedOpacity = (1.0 - (progress * 1.8)).clamp(0.0, 1.0);
    final collapsedOpacity = ((progress - 0.5) * 2.0).clamp(0.0, 1.0);

    return Container(
      height: (maxExtent - shrinkOffset).clamp(minExtent, maxExtent),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF0C050D) : const Color(0xFFFFF1F2),
        boxShadow: progress > 0.8
            ? [
                BoxShadow(
                  color: Colors.black.withValues(alpha: isDark ? 0.4 : 0.08),
                  blurRadius: 16,
                  offset: const Offset(0, 4),
                )
              ]
            : null,
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          // 1. Full Expansive Notice Card (Visible when expanded)
          if (expandedOpacity > 0.01)
            Opacity(
              opacity: expandedOpacity,
              child: Padding(
                padding: EdgeInsets.fromLTRB(
                  16 * (1.0 - progress),
                  topPadding + 8,
                  16 * (1.0 - progress),
                  12,
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(
                    lerpDouble(28.0, 16.0, progress) ?? 24.0,
                  ),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      if (ThemeSignals.isMaterialYou) ...[
                        // Authentic M3E Re-imagined Vacation Canvas
                        Positioned.fill(
                          child: IrisExpressiveHeaderCanvas(
                            domain: ExpressiveHeaderDomain.vacation,
                            accentColor: const Color(0xFFF43F5E),
                            borderRadius: lerpDouble(28.0, 16.0, progress) ?? 24.0,
                            child: const SizedBox.expand(),
                          ),
                        ),
                      ] else ...[
                        // Liquid Glass Theme: Vacation Artwork Image
                        Image.asset(
                          'assets/headers/header_vacation_mode.jpg',
                          fit: BoxFit.cover,
                          cacheWidth: 1080,
                          alignment: Alignment.center,
                          errorBuilder: (context, error, stackTrace) => Container(
                            decoration: const BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Color(0xFFF43F5E), Color(0xFFFB923C)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                            ),
                          ),
                        ),

                        // Gentle Sunset Vignette Gradient
                        Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.black.withValues(alpha: 0.1),
                                Colors.black.withValues(alpha: 0.7),
                              ],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                          ),
                        ),
                      ],

                      // Glowing Top Rim Border
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(
                            lerpDouble(28.0, 16.0, progress) ?? 24.0,
                          ),
                          border: Border.all(
                            color: const Color(0xFFF43F5E).withValues(alpha: isDark ? 0.40 : 0.30),
                            width: 1.2,
                          ),
                        ),
                      ),

                      // Card Top Badge
                      Positioned(
                        top: 14,
                        left: 16,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF43F5E).withValues(alpha: isDark ? 0.20 : 0.14),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: const Color(0xFFF43F5E).withValues(alpha: isDark ? 0.40 : 0.35),
                              width: 1,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                '🏖️ VACATION NOTICE',
                                style: TextStyle(
                                  color: isDark ? const Color(0xFFFDA4AF) : const Color(0xFFE11D48),
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.8,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      // Floating Frosted Glass Countdown Box in Center-Bottom
                      Positioned(
                        left: 18,
                        right: 18,
                        bottom: 16,
                        child: ValueListenableBuilder<IrisThemeStyle>(
                          valueListenable: ThemeSignals.themeStyle,
                          builder: (context, themeStyle, _) {
                            final isM3 = themeStyle == IrisThemeStyle.materialYou;
                            final content = Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    daysLeft > 1
                                        ? '$daysLeft DAYS'
                                        : (daysLeft == 1
                                            ? '1 DAY'
                                            : (daysLeft == 0
                                                ? 'RESUMES TODAY!'
                                                : (daysLeft < 0 && daysLeft != -1
                                                    ? 'SEMESTER ACTIVE'
                                                    : 'RECESS ACTIVE'))),
                                    style: TextStyle(
                                      fontSize: daysLeft == 0 || daysLeft < 0 || daysLeft == -1 ? 24 : 32,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 1.2,
                                      height: 1.05,
                                      color: isDark
                                          ? const Color(0xFFFFF1F2)
                                          : const Color(0xFF9F1239),
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    daysLeft >= 0
                                        ? 'Until $targetSemester Resumes'
                                        : 'Campus in Recess • Enjoy Your Break',
                                    style: TextStyle(
                                      fontSize: 12.5,
                                      fontWeight: FontWeight.w600,
                                      color: isDark
                                          ? Colors.white.withValues(alpha: 0.85)
                                          : const Color(0xFF4C0519),
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 3.5,
                                    ),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFF43F5E).withValues(
                                        alpha: isDark ? 0.25 : 0.15,
                                      ),
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                        color: const Color(0xFFF43F5E)
                                            .withValues(alpha: 0.4),
                                      ),
                                    ),
                                    child: Text(
                                      '$batch • Academic Break Active',
                                      style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w700,
                                        color: isDark
                                            ? const Color(0xFFFDA4AF)
                                            : const Color(0xFFE11D48),
                                      ),
                                    ),
                                  ),
                                ],
                              );

                            if (isM3) {
                              return M3ECard(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 20,
                                  vertical: 16,
                                ),
                                borderRadius: BorderRadius.circular(22),
                                color: Theme.of(context).colorScheme.surfaceContainer,
                                variant: M3ECardVariant.elevated,
                                child: content,
                              );
                            }

                            if (themeStyle == IrisThemeStyle.almanac) {
                              return Container(
                                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                                decoration: BoxDecoration(
                                  color: AlmanacTokens.cardSurface(isDark),
                                  border: Border.all(color: AlmanacTokens.inkRule(isDark), width: 1.5),
                                ),
                                child: content,
                              );
                            }

                            if (themeStyle == IrisThemeStyle.editorialAcademic) {
                              return Container(
                                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                                decoration: BoxDecoration(
                                  color: EditorialTokens.cardSurface(isDark),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: EditorialTokens.cardBorder(isDark), width: 1.5),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
                                      blurRadius: 8,
                                      offset: const Offset(0, 3),
                                    ),
                                  ],
                                ),
                                child: content,
                              );
                            }

                            if (themeStyle == IrisThemeStyle.notebook) {
                              return Container(
                                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                                decoration: BoxDecoration(
                                  color: NotebookTokens.cardSurface(isDark),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: NotebookTokens.gridLine(isDark), width: 1.8),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
                                      blurRadius: 6,
                                      offset: const Offset(2, 3),
                                    ),
                                  ],
                                ),
                                child: content,
                              );
                            }

                            if (themeStyle == IrisThemeStyle.line) {
                              return Container(
                                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                                decoration: BoxDecoration(
                                  color: LineTokens.cardSurface(isDark),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: LineTokens.railLine(isDark), width: 1.8),
                                ),
                                child: content,
                              );
                            }

                            if (themeStyle == IrisThemeStyle.poster) {
                              final borderColor = PosterTokens.inkBorder(isDark);
                              return Container(
                                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                                decoration: BoxDecoration(
                                  color: isDark ? const Color(0xFF161C24) : Colors.white,
                                  border: Border.all(color: borderColor, width: 2.2),
                                  boxShadow: PosterTokens.extrudedBlockShadow(isDark, offset: 4.0),
                                ),
                                child: content,
                              );
                            }

                            return ClipRRect(
                              borderRadius: BorderRadius.circular(22),
                              child: GlassSurface(
                                settings: IrisGlass.settings(
                                  context,
                                  blur: 18.0,
                                  thickness: 16.0,
                                  ambientStrength: 0.78,
                                  glassColor: isDark
                                      ? Colors.black.withValues(alpha: 0.45)
                                      : Colors.white.withValues(alpha: 0.70),
                                ),
                                radius: 22,
                                borderSide: BorderSide(
                                  color: isDark
                                      ? const Color(0xFFFB7185).withValues(alpha: 0.45)
                                      : Colors.white.withValues(alpha: 0.9),
                                  width: 1.2,
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 20,
                                    vertical: 16,
                                  ),
                                  child: content,
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

          // 2. Compact Sticky Top Header Bar (Visible when scrolled)
          if (collapsedOpacity > 0.01)
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              height: minExtent,
              child: Opacity(
                opacity: collapsedOpacity,
                child: ClipRRect(
                  borderRadius: const BorderRadius.vertical(
                    bottom: Radius.circular(20),
                  ),
                  child: IrisGlass.backdropFilter(
                    sigmaX: IrisGlass.adaptiveBlur(context, 16.0),
                    sigmaY: IrisGlass.adaptiveBlur(context, 16.0),
                    child: Container(
                      padding: EdgeInsets.only(
                        top: topPadding + 4,
                        left: 16,
                        right: 16,
                        bottom: 8,
                      ),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: isDark
                              ? [
                                  const Color(0xFFE11D48).withValues(alpha: 0.92),
                                  const Color(0xFF9F1239).withValues(alpha: 0.95),
                                ]
                              : [
                                  const Color(0xFFFB7185),
                                  const Color(0xFFF43F5E),
                                ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: const BorderRadius.vertical(
                          bottom: Radius.circular(20),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFF43F5E).withValues(alpha: 0.3),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.2),
                              shape: BoxShape.circle,
                            ),
                            child: const Text('🌴', style: TextStyle(fontSize: 16)),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  daysLeft > 1
                                      ? 'Break • $daysLeft Days Left'
                                      : (daysLeft == 1
                                          ? 'Break • 1 Day Left'
                                          : (daysLeft == 0
                                              ? 'Break • Resumes Today!'
                                              : (daysLeft < 0 && daysLeft != -1
                                                  ? 'Semester Active'
                                                  : 'Semester Break'))),
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: -0.2,
                                  ),
                                ),
                                Text(
                                  '$batch • $targetSemester',
                                  style: TextStyle(
                                    color: Colors.white.withValues(alpha: 0.85),
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              IrisHaptics.chipSelect();
                              onNoticeTap?.call();
                            },
                            borderRadius: BorderRadius.circular(12),
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.22),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: Colors.white.withValues(alpha: 0.35),
                                ),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.calendar_today_rounded,
                                      size: 13, color: Colors.white),
                                  SizedBox(width: 5),
                                  Text(
                                    'Schedule',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  bool shouldRebuild(covariant VacationStickyHeaderDelegate oldDelegate) {
    return oldDelegate.batch != batch ||
        oldDelegate.daysLeft != daysLeft ||
        oldDelegate.targetSemester != targetSemester;
  }
}