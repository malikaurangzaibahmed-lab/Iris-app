import 'package:flutter/material.dart';
import '../../core/animations.dart';

/// Interactive onboarding role selection card (Student vs Faculty).
/// Features animated squircle icons, feature chips, mini ticket previews, and tactile buttons.
class CreativeRoleCard extends StatelessWidget {
  final Key? cardKey;
  final String roleId;
  final String title;
  final String badge;
  final String tagline;
  final IconData icon;
  final Color accentColor;
  final List<Color> gradientColors;
  final String previewTitle;
  final String previewRoom;
  final List<String> chips;
  final String buttonLabel;
  final bool isDark;
  final bool isM3;
  final ColorScheme cs;
  final bool isSelected;
  final VoidCallback onTap;

  const CreativeRoleCard({
    this.cardKey,
    required this.roleId,
    required this.title,
    required this.badge,
    required this.tagline,
    required this.icon,
    required this.accentColor,
    required this.gradientColors,
    required this.previewTitle,
    required this.previewRoom,
    required this.chips,
    required this.buttonLabel,
    required this.isDark,
    required this.isM3,
    required this.cs,
    required this.isSelected,
    required this.onTap,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return ExpressiveInteractivePress(
      onTap: onTap,
      pressedScale: 0.97,
      child: AnimatedContainer(
        key: cardKey,
        duration: const Duration(milliseconds: 220),
        curve: Curves.fastOutSlowIn,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: BoxDecoration(
          color: isSelected
              ? accentColor.withValues(alpha: isDark ? 0.16 : 0.08)
              : (isM3
                  ? (isDark ? cs.surfaceContainerHigh : cs.surfaceContainerLow)
                  : (isDark ? const Color(0xFF0E1424) : Colors.white)),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected
                ? accentColor
                : accentColor.withValues(alpha: isDark ? 0.45 : 0.35),
            width: isSelected ? 1.8 : 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: accentColor.withValues(
                alpha: isDark
                    ? (isSelected ? 0.26 : 0.10)
                    : (isSelected ? 0.16 : 0.05),
              ),
              blurRadius: isSelected ? 14 : 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top Row: Avatar Squircle + Badge + Tagline
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Squircle Avatar
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: gradientColors,
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: gradientColors.first.withValues(alpha: 0.28),
                        blurRadius: 7,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Center(
                    child: Icon(
                      icon,
                      color: Colors.white,
                      size: 21,
                    ),
                  ),
                ),
                const SizedBox(width: 10),

                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            title,
                            style: TextStyle(
                              fontSize: 14.5,
                              fontWeight: FontWeight.w900,
                              letterSpacing: -0.3,
                              color: isM3
                                  ? cs.onSurface
                                  : (isDark ? Colors.white : const Color(0xFF0F172A)),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 5.5,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: accentColor.withValues(
                                alpha: isDark ? 0.20 : 0.12,
                              ),
                              borderRadius: BorderRadius.circular(5),
                            ),
                            child: Text(
                              badge,
                              style: TextStyle(
                                fontSize: 8.5,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.5,
                                color: accentColor,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        tagline,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w500,
                          color: isM3
                              ? cs.onSurfaceVariant
                              : (isDark ? Colors.white70 : Colors.black87),
                        ),
                      ),
                    ],
                  ),
                ),

                // Selection Checkmark Circle
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(
                    color: isSelected ? accentColor : Colors.transparent,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: isSelected
                          ? accentColor
                          : (isDark ? Colors.white24 : Colors.black26),
                      width: 1.8,
                    ),
                  ),
                  child: isSelected
                      ? const Icon(
                          Icons.check_rounded,
                          size: 14,
                          color: Colors.white,
                        )
                      : null,
                ),
              ],
            ),
            const SizedBox(height: 8),

            // Feature Highlights Chips (Single Compact Row)
            Row(
              children: chips.map((chip) {
                return Expanded(
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    padding: const EdgeInsets.symmetric(vertical: 3.5),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: isDark
                          ? Colors.white.withValues(alpha: 0.05)
                          : Colors.black.withValues(alpha: 0.035),
                      borderRadius: BorderRadius.circular(7),
                      border: Border.all(
                        color: (isDark ? Colors.white : Colors.black).withValues(
                          alpha: 0.07,
                        ),
                        width: 0.8,
                      ),
                    ),
                    child: Text(
                      chip,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 9.5,
                        fontWeight: FontWeight.w700,
                        color: isM3
                            ? cs.onSurfaceVariant
                            : (isDark ? Colors.white70 : Colors.black87),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 8),

            // Mini Preview Ticket
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
              decoration: BoxDecoration(
                color: isDark
                    ? Colors.white.withValues(alpha: 0.04)
                    : Colors.black.withValues(alpha: 0.025),
                borderRadius: BorderRadius.circular(9),
                border: Border.all(
                  color: (isDark ? Colors.white : Colors.black).withValues(
                    alpha: 0.06,
                  ),
                  width: 0.8,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 5.5,
                    height: 5.5,
                    decoration: BoxDecoration(
                      color: accentColor,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      '$previewTitle • $previewRoom',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w700,
                        color: isDark ? Colors.white70 : const Color(0xFF334155),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 9),

            // Tactile Action Pill Button
            Container(
              width: double.infinity,
              height: 35,
              decoration: BoxDecoration(
                color: isDark
                    ? (roleId == 'student'
                        ? const Color(0xFFCCFBF1)
                        : const Color(0xFFE0E7FF))
                    : accentColor,
                borderRadius: BorderRadius.circular(18),
                boxShadow: [
                  BoxShadow(
                    color: (isDark ? Colors.black : accentColor).withValues(
                      alpha: 0.08,
                    ),
                    blurRadius: 5,
                    offset: const Offset(0, 1.5),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    buttonLabel,
                    style: TextStyle(
                      fontSize: 10.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.6,
                      color: isDark ? const Color(0xFF0F172A) : Colors.white,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Icon(
                    Icons.arrow_forward_rounded,
                    size: 13,
                    color: isDark ? const Color(0xFF0F172A) : Colors.white,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
