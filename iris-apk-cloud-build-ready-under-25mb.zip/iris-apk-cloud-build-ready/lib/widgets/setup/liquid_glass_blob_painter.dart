import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';

/// Dynamic Chromatic Aurora Blob Painter for Liquid Glass Theme Showcase Card.
class LiquidGlassCardBlobPainter extends CustomPainter {
  final Animation<double>? animation;

  LiquidGlassCardBlobPainter({this.animation}) : super(repaint: animation);

  @override
  void paint(Canvas canvas, Size size) {
    final t = (animation?.value ?? 0.0) * 2 * math.pi;

    // Rich cosmic dark background base
    final bgPaint = Paint()..color = const Color(0xFF090D1A);
    canvas.drawRect(Offset.zero & size, bgPaint);

    // Dynamic Blob 1: Vibrant Cyan Aurora (Top Left)
    final b1Offset = Offset(
      size.width * 0.18 + math.sin(t) * 12,
      size.height * 0.30 + math.cos(t) * 8,
    );
    final b1Paint = Paint()
      ..shader = ui.Gradient.radial(
        b1Offset,
        size.width * 0.52,
        [
          const Color(0xFF00F2FE).withValues(alpha: 0.70),
          const Color(0xFF00C6FF).withValues(alpha: 0.30),
          Colors.transparent,
        ],
        [0.0, 0.45, 1.0],
      );
    canvas.drawCircle(b1Offset, size.width * 0.52, b1Paint);

    // Dynamic Blob 2: Deep Iris Violet (Bottom Right)
    final b2Offset = Offset(
      size.width * 0.82 - math.cos(t * 0.8) * 14,
      size.height * 0.70 + math.sin(t * 0.8) * 10,
    );
    final b2Paint = Paint()
      ..shader = ui.Gradient.radial(
        b2Offset,
        size.width * 0.58,
        [
          const Color(0xFF8B5CF6).withValues(alpha: 0.72),
          const Color(0xFF6D28D9).withValues(alpha: 0.32),
          Colors.transparent,
        ],
        [0.0, 0.50, 1.0],
      );
    canvas.drawCircle(b2Offset, size.width * 0.58, b2Paint);

    // Dynamic Blob 3: Neon Indigo/Blue (Top Right)
    final b3Offset = Offset(
      size.width * 0.65 + math.sin(t * 1.2) * 10,
      size.height * 0.18 - math.cos(t * 1.2) * 8,
    );
    final b3Paint = Paint()
      ..shader = ui.Gradient.radial(
        b3Offset,
        size.width * 0.45,
        [
          const Color(0xFF3B82F6).withValues(alpha: 0.58),
          const Color(0xFF1D4ED8).withValues(alpha: 0.22),
          Colors.transparent,
        ],
        [0.0, 0.50, 1.0],
      );
    canvas.drawCircle(b3Offset, size.width * 0.45, b3Paint);

    // Dynamic Blob 4: Radiant Pink / Amber (Bottom Left)
    final b4Offset = Offset(
      size.width * 0.28 - math.sin(t * 0.7) * 10,
      size.height * 0.85 + math.cos(t * 0.7) * 6,
    );
    final b4Paint = Paint()
      ..shader = ui.Gradient.radial(
        b4Offset,
        size.width * 0.40,
        [
          const Color(0xFFEC4899).withValues(alpha: 0.50),
          const Color(0xFFF59E0B).withValues(alpha: 0.22),
          Colors.transparent,
        ],
        [0.0, 0.45, 1.0],
      );
    canvas.drawCircle(b4Offset, size.width * 0.40, b4Paint);
  }

  @override
  bool shouldRepaint(covariant LiquidGlassCardBlobPainter oldDelegate) => true;
}
