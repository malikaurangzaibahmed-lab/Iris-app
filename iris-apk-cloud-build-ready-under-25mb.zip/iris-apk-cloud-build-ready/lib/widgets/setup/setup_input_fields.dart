import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import '../../core/tokens.dart';
import '../../core/glass.dart';
import '../../services/ui_feedback.dart';
import '../iris_components.dart';
import 'package:iris/widgets/controls/glowing_input_wrapper.dart';

/// Setup input field for the student's full name.
class SetupStudentNameInputField extends StatelessWidget {
  final String name;
  final ValueChanged<String> onChanged;

  const SetupStudentNameInputField({
    required this.name,
    required this.onChanged,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.person_rounded, size: 14, color: IrisTokens.brand),
            const SizedBox(width: 6),
            Text(
              'YOUR FULL NAME',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.8,
                color: IrisTokens.brand,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        IrisGlowingInputWrapper(
          borderRadius: 16.0,
          child: TextFormField(
            initialValue: name,
            onChanged: onChanged,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
            decoration: InputDecoration(
              hintText: 'e.g. Ali',
              hintStyle: TextStyle(
                color: (isDark ? Colors.white : Colors.black).withValues(
                  alpha: 0.4,
                ),
              ),
              border: InputBorder.none,
            ),
          ),
        ),
      ],
    );
  }
}

/// Setup glass menu dropdown selector for batch, program, semester, and section.
class SetupGlassMenuDropdownSelector extends StatelessWidget {
  final String label;
  final String? selectedValue;
  final List<String> items;
  final IconData icon;
  final String? placeholder;
  final ValueChanged<String> onSelected;
  final String Function(String item)? itemLabelBuilder;

  const SetupGlassMenuDropdownSelector({
    required this.label,
    required this.selectedValue,
    required this.items,
    required this.icon,
    this.placeholder,
    required this.onSelected,
    this.itemLabelBuilder,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, size: 14, color: IrisTokens.brand),
            const SizedBox(width: 6),
            Text(
              label,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.8,
                color: IrisTokens.brand,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        items.isEmpty
            ? Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 14,
                ),
                decoration: BoxDecoration(
                  color: (isDark ? Colors.white : Colors.black).withValues(
                    alpha: 0.04,
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: (isDark ? Colors.white : Colors.black).withValues(
                      alpha: 0.08,
                    ),
                  ),
                ),
                child: Text(
                  placeholder ?? 'No options available',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: (isDark ? Colors.white : Colors.black).withValues(
                      alpha: 0.4,
                    ),
                  ),
                ),
              )
            : IrisGlassMenu(
                autoAdjustToScreen: true,
                menuPadding: const EdgeInsets.all(16),
                menuWidth: MediaQuery.sizeOf(context).width - 48,
                menuHeight: math.min(items.length * 52.0 + 16.0, 320.0),
                menuBorderRadius: 28.0,
                itemBorderRadius: 20.0,
                settings: IrisGlass.widgetsSettings(
                  context,
                  blur: 16.0,
                  ambientStrength: 0.7,
                  lightAngle: 0.15 * math.pi,
                  thickness: 18.0,
                ),
                triggerBuilder: (context, toggleMenu) {
                  final displayText = selectedValue != null
                      ? (itemLabelBuilder != null
                            ? itemLabelBuilder!(selectedValue!)
                            : selectedValue!)
                      : 'Select $label';
                  final hasValue = selectedValue != null;
                  return IrisExpressiveDropdownTrigger(
                    displayText: displayText,
                    hasValue: hasValue,
                    isDark: isDark,
                    onTap: toggleMenu,
                  );
                },
                items: items.map((val) {
                  final itemTitle = itemLabelBuilder != null
                      ? itemLabelBuilder!(val)
                      : val;
                  final isSelected = val == selectedValue;
                  return lgw.GlassMenuItem(
                    title: itemTitle,
                    titleStyle: TextStyle(
                      fontWeight: isSelected
                          ? FontWeight.bold
                          : FontWeight.w600,
                      fontSize: 14,
                      color: isSelected
                          ? IrisTokens.brand
                          : (isDark
                                ? Colors.white.withValues(alpha: 0.9)
                                : Colors.black87),
                    ),
                    isSelected: isSelected,
                    icon: Icon(
                      icon,
                      size: 18,
                      color: isSelected
                          ? IrisTokens.brand
                          : (isDark ? Colors.white70 : Colors.black54),
                    ),
                    onTap: () {
                      IrisHaptics.selectionClick();
                      onSelected(val);
                    },
                  );
                }).toList(),
              ),
      ],
    );
  }
}

/// Setup roll number input field (3 digits).
class SetupRollNumberInputField extends StatelessWidget {
  final String rollNo;
  final ValueChanged<String> onChanged;

  const SetupRollNumberInputField({
    required this.rollNo,
    required this.onChanged,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.badge_rounded, size: 14, color: IrisTokens.brand),
            const SizedBox(width: 6),
            Text(
              'ROLL NUMBER (3 DIGITS)',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.8,
                color: IrisTokens.brand,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        IrisGlowingInputWrapper(
          borderRadius: 16.0,
          child: TextFormField(
            initialValue: rollNo,
            onChanged: onChanged,
            keyboardType: TextInputType.number,
            maxLength: 3,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(3),
            ],
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.5,
            ),
            decoration: InputDecoration(
              counterText: '',
              hintText: 'e.g. 042',
              hintStyle: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                letterSpacing: 0,
                color: (isDark ? Colors.white : Colors.black).withValues(
                  alpha: 0.4,
                ),
              ),
              border: InputBorder.none,
            ),
          ),
        ),
      ],
    );
  }
}
