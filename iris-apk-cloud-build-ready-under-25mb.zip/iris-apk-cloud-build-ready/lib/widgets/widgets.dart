// ==========================================
// 🚢 DOCKS & NAVIGATION SHEETS
// ==========================================
export 'navigation/dashboard_dock.dart' hide NavActiveHalo, BouncyNavButton;
export 'navigation/iris_expressive_nav_bar.dart';
export 'navigation/almanac_nav_bar.dart';
export 'navigation/editorial_nav_bar.dart';
export 'navigation/notebook_nav_bar.dart';
export 'navigation/line_nav_bar.dart';
export 'navigation/poster_nav_bar.dart';
export 'navigation/iris_expressive_header.dart';
export 'navigation/liquid_glass_sticky_header.dart';
export 'navigation/smart_pill_overlay.dart';
export 'navigation/day_switcher.dart';

// ==========================================
// 🎮 CONTROLS & INPUTS
// ==========================================
export 'controls/batch_selector.dart';
export 'controls/m3e_color_selector.dart';
export 'controls/glowing_input_wrapper.dart';
export 'controls/spring_button.dart';
export 'controls/iris_liquid_button.dart';
export 'controls/iris_expressive_controls.dart';
export 'controls/tactile_stationery.dart';

// ==========================================
// 🧊 GLASS & MORPHING TRANSFORMATIONS
// ==========================================
export 'glass_card.dart';
export 'effects/glass_container_transform.dart';
export 'effects/native_liquid_glass.dart';

// ==========================================
// 🎴 CARDS & VITAL COMPONENTS
// ==========================================
export 'cards/developer_card.dart';
export 'cards/vital_card.dart';
export 'cards/class_card.dart';
export 'cards/sticker_card.dart';
export 'cards/contextual_timeline_card.dart';
export 'controls/washi_tape_chip.dart';
export 'controls/doodle_speech_bubble.dart';
export 'effects/doodle_mascots.dart';
export 'iris_components.dart';
export 'smart_widgets.dart';

// ==========================================
// ✨ EFFECTS & AURA
// ==========================================
export 'effects/academic_doodle_background.dart';
export 'effects/fluid_rendering.dart';
export 'effects/nature_particles.dart';
export 'effects/neural_aura.dart';
export 'effects/smooth_scroll.dart';
export 'effects/theme_morph_transition.dart';

// ==========================================
// 📅 SCHEDULE VIEWS & CALENDARS
// ==========================================
export 'schedule_views/exam_schedule_view.dart';
export 'schedule_views/exam_sticky_header.dart';
export 'schedule_views/sports_gala_view.dart';
export 'schedule_views/sports_week_sticky_header.dart';
export 'schedule_views/vacation_schedule_view.dart';
export 'schedule_views/vacation_sticky_header.dart';
export 'schedule_views/almanac_schedule_view.dart';
export 'schedule_views/editorial_schedule_view.dart';
export 'schedule_views/notebook_schedule_view.dart';
export 'schedule_views/line_schedule_view.dart';
export 'schedule_views/poster_schedule_view.dart';

// ==========================================
// 👨‍🏫 FACULTY & DASHBOARD MODULES
// ==========================================
export 'faculty/faculty_mode_views.dart';
export 'dashboard/dashboard_widgets.dart';
export 'dashboard/live_class_hub_sheet.dart';

// ==========================================
// 🧩 MODULAR FEATURE WIDGETS
// ==========================================
export 'room_finder/room_finder_widgets.dart';
export 'document/document_converter_view.dart';
export 'document/document_splitter_view.dart';
export 'portal/portal_widgets.dart';
export 'makeup/makeup_widgets.dart';
export 'setup/setup_widgets.dart';
export 'department_classes/department_classes_widgets.dart';
