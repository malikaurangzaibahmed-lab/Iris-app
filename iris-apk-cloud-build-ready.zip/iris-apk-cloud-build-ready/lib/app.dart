import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shorebird_code_push/shorebird_code_push.dart';

import 'core/glass.dart';
import 'core/material_you_theme.dart';
import 'core/minimal_theme.dart';
import 'core/models.dart';
import 'core/theme.dart';
import 'core/theme_signals.dart';
import 'core/tokens.dart';
import 'core/university_memory.dart';
import 'core/vital_theme.dart';
import 'screens/app_root.dart';
import 'services/ui_feedback.dart';
import 'services/widget_service.dart';
import 'widgets/glass_card.dart';
import 'widgets/iris_components.dart';
import 'package:iris/widgets/navigation/smart_pill_overlay.dart';
import 'package:iris/widgets/effects/smooth_scroll.dart';
import 'package:iris/widgets/effects/theme_morph_transition.dart';
import 'package:iris/widgets/effects/glass_container_transform.dart';

class IrisApp extends StatefulWidget {
  final String initialThemeMode;
  final bool initialUseMinimal;
  final bool initialUseVital;

  const IrisApp({
    this.initialThemeMode = 'system',
    this.initialUseMinimal = false,
    this.initialUseVital = false,
    super.key,
  });

  @override
  State<IrisApp> createState() => _IrisAppBootState();
}

final globalScaffoldMessengerKey = GlobalKey<ScaffoldMessengerState>();

class _IrisAppBootState extends State<IrisApp> {
  late final Future<UniversityMemory> _memoryFuture;
  final _shorebirdUpdater = ShorebirdUpdater();

  @override
  void initState() {
    super.initState();
    _memoryFuture = UniversityMemoryLoader.loadFromAssets();
    _checkShorebirdPatch();
  }

  Future<void> _checkShorebirdPatch() async {
    try {
      if (!_shorebirdUpdater.isAvailable) return;
      final status = await _shorebirdUpdater.checkForUpdate();
      if (status == UpdateStatus.outdated) {
        await _shorebirdUpdater.update();
        _promptForRestartWhenReady();
      }
    } catch (e) {
      debugPrint('Shorebird patch check: $e');
    }
  }

  void _promptForRestartWhenReady() {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      int retries = 0;
      while (retries < 15) {
        final context = globalScaffoldMessengerKey.currentContext;
        if (context != null && context.mounted) {
          _showUpdateDialog(context);
          break;
        }
        await Future.delayed(const Duration(milliseconds: 400));
        retries++;
      }
    });
  }

  void _showUpdateDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: true,
      barrierColor: Colors.black.withValues(alpha: 0.65),
      builder: (ctx) {
        final isDark = Theme.of(ctx).brightness == Brightness.dark;
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
          child: Dialog(
            backgroundColor: Colors.transparent,
            elevation: 0,
            insetPadding: const EdgeInsets.symmetric(
              horizontal: 20,
              vertical: 24,
            ),
            child: Container(
              constraints: const BoxConstraints(maxWidth: 380),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(32),
                boxShadow: [
                  BoxShadow(
                    color: IrisTokens.brand.withValues(
                      alpha: isDark ? 0.25 : 0.15,
                    ),
                    blurRadius: 40,
                    spreadRadius: 2,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(32),
                child: GlassSurface(
                  settings: IrisGlass.settings(
                    context,
                    blur: 16.0,
                    ambientStrength: 0.85,
                    lightAngle: 0.15 * math.pi,
                    thickness: 22.0,
                    glassColor: IrisGlass.adaptiveGlassColor(
                      context,
                      darkAlpha: 0.90,
                      lightAlpha: 0.95,
                    ),
                  ),
                  radius: 32,
                  child: Container(
                    padding: const EdgeInsets.all(28),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(32),
                      border: Border.all(
                        color: IrisTokens.brand.withValues(
                          alpha: isDark ? 0.45 : 0.35,
                        ),
                        width: 1.5,
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [IrisTokens.brand, IrisTokens.purple],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: IrisTokens.brand.withValues(alpha: 0.45),
                                blurRadius: 24,
                                offset: const Offset(0, 6),
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.system_update_rounded,
                            color: Colors.white,
                            size: 36,
                          ),
                        ),
                        const SizedBox(height: 20),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: IrisTokens.brand.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(999),
                            border: Border.all(
                              color: IrisTokens.brand.withValues(alpha: 0.3),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 7,
                                height: 7,
                                decoration: const BoxDecoration(
                                  color: Color(0xFF10B981),
                                  shape: BoxShape.circle,
                                ),
                              ),
                              const SizedBox(width: 6),
                              const Text(
                                'OVER-THE-AIR PATCH READY',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.2,
                                  color: IrisTokens.brand,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                        Text(
                          'Update Installed!',
                          style: IrisTextStyles.headline(context).copyWith(
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -0.5,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'A fresh update with visual enhancements and performance speedups is ready to apply.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 13.5,
                            height: 1.45,
                            fontWeight: FontWeight.w500,
                            color: (isDark ? Colors.white : Colors.black)
                                .withValues(alpha: 0.65),
                          ),
                        ),
                        const SizedBox(height: 26),
                        Column(
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton(
                                onPressed: () {
                                  IrisHaptics.actionHeavy();
                                  SystemNavigator.pop();
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: IrisTokens.brand,
                                  foregroundColor: Colors.white,
                                  elevation: 6,
                                  shadowColor: IrisTokens.brand.withValues(
                                    alpha: 0.4,
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 16,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(18),
                                  ),
                                ),
                                child: const Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.restart_alt_rounded,
                                      size: 20,
                                      color: Colors.white,
                                    ),
                                    SizedBox(width: 8),
                                    Text(
                                      'RESTART APP NOW',
                                      style: TextStyle(
                                        fontSize: 13.5,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 0.8,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(height: 10),
                            SizedBox(
                              width: double.infinity,
                              child: TextButton(
                                onPressed: () => Navigator.pop(ctx),
                                style: TextButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 13,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(18),
                                  ),
                                ),
                                child: Text(
                                  'Dismiss & Restart Later',
                                  style: TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w700,
                                    color:
                                        (isDark ? Colors.white : Colors.black)
                                            .withValues(alpha: 0.45),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<UniversityMemory>(
      future: _memoryFuture,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          return _IrisApp(
            memory: snapshot.data!,
            initialThemeMode: widget.initialThemeMode,
          );
        }
        return MaterialApp(
          scaffoldMessengerKey: globalScaffoldMessengerKey,
          debugShowCheckedModeBanner: false,
          theme: IrisTheme.light(),
          darkTheme: IrisTheme.dark(),
          scrollBehavior: const SmoothScrollBehavior(),
          home: const _StartupSplash(),
        );
      },
    );
  }
}

class _StartupSplash extends StatelessWidget {
  const _StartupSplash();

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isDark
                ? [IrisTokens.surfaceDark, const Color(0xFF0D0F17)]
                : [const Color(0xFFF8F7FC), const Color(0xFFF0F3FF)],
          ),
        ),
        child: Center(
          child: GlassCard(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: IrisTokens.brandGradient),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: const Icon(
                    Icons.auto_awesome_rounded,
                    color: Colors.white,
                    size: 30,
                  ),
                ),
                const SizedBox(height: 18),
                Text(
                  'IRIS',
                  style: IrisTextStyles.display(
                    context,
                  ).copyWith(fontSize: 26, letterSpacing: 1.2),
                ),
                const SizedBox(height: 8),
                Text(
                  'Loading schedule and preferences...',
                  style: IrisTextStyles.metaInfo(context),
                ),
                const SizedBox(height: 16),
                IrisComponents.loadingSpinner(size: 24, strokeWidth: 2.4),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _IrisApp extends StatefulWidget {
  const _IrisApp({required this.memory, required this.initialThemeMode});

  final UniversityMemory memory;
  final String initialThemeMode;

  @override
  State<_IrisApp> createState() => _IrisAppState();
}

class _IrisAppState extends State<_IrisApp> {
  late ThemeMode _themeMode = _themeModeFromString(widget.initialThemeMode);

  @override
  void initState() {
    super.initState();
    _loadThemeMode();
  }

  bool _isDarkForMode(ThemeMode mode) {
    if (mode == ThemeMode.dark) return true;
    if (mode == ThemeMode.light) return false;
    return WidgetsBinding.instance.platformDispatcher.platformBrightness ==
        Brightness.dark;
  }

  Future<void> _loadThemeMode() async {
    final prefs = await SharedPreferences.getInstance();
    final savedMode = prefs.getString('theme_mode') ?? 'system';
    final useMinimal = prefs.getBool('use_minimal_ui') ?? false;
    final useVital = prefs.getBool('use_vital_theme') ?? false;
    ThemeSignals.useMinimalTheme.value = useMinimal;
    ThemeSignals.useVitalTheme.value = useVital;
    final resolvedMode = _themeModeFromString(savedMode);
    WidgetService.syncThemeMode(_isDarkForMode(resolvedMode));
    if (!mounted) {
      return;
    }
    setState(() {
      _themeMode = resolvedMode;
    });
  }

  ThemeMode _themeModeFromString(String mode) {
    switch (mode) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  String _themeModeToString(ThemeMode mode) {
    switch (mode) {
      case ThemeMode.light:
        return 'light';
      case ThemeMode.dark:
        return 'dark';
      case ThemeMode.system:
        return 'system';
    }
  }

  Future<void> _setThemeMode(String mode) async {
    final nextMode = _themeModeFromString(mode);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('theme_mode', _themeModeToString(nextMode));
    WidgetService.syncThemeMode(_isDarkForMode(nextMode));
    if (!mounted) {
      return;
    }
    setState(() {
      _themeMode = nextMode;
    });
  }

  Future<void> _toggleTheme() async {
    final nextMode = _themeMode == ThemeMode.dark
        ? ThemeMode.light
        : ThemeMode.dark;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('theme_mode', _themeModeToString(nextMode));
    WidgetService.syncThemeMode(_isDarkForMode(nextMode));
    if (!mounted) {
      return;
    }
    setState(() {
      _themeMode = nextMode;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<IrisThemeStyle>(
      valueListenable: ThemeSignals.themeStyle,
      builder: (context, currentStyle, _) {
        final isM3 = currentStyle == IrisThemeStyle.materialYou;

        return ValueListenableBuilder<Color>(
          valueListenable: ThemeSignals.m3eSeedColor,
          builder: (context, seedColor, _) {
            return ValueListenableBuilder<bool>(
              valueListenable: ThemeSignals.useVitalTheme,
              builder: (context, useVital, _) {
                return ValueListenableBuilder<bool>(
                  valueListenable: ThemeSignals.useMinimalTheme,
                  builder: (context, useMinimal, _) {
                    return ValueListenableBuilder<double>(
                      valueListenable: ThemeSignals.glassTransparency,
                      builder: (context, transparency, child) {
                        final theme = IrisTheme.buildForStyle(
                          style: currentStyle,
                          brightness: Brightness.light,
                          seedColor: seedColor,
                          useMinimal: useMinimal,
                          useVital: useVital,
                        );

                        final darkTheme = IrisTheme.buildForStyle(
                          style: currentStyle,
                          brightness: Brightness.dark,
                          seedColor: seedColor,
                          useMinimal: useMinimal,
                          useVital: useVital,
                        );

                        return MaterialApp(
                          scaffoldMessengerKey: globalScaffoldMessengerKey,
                          debugShowCheckedModeBanner: false,
                          themeMode: _themeMode,
                          theme: theme,
                          darkTheme: darkTheme,
                          scrollBehavior: const SmoothScrollBehavior(),
                          builder: (context, child) => Listener(
                            behavior: HitTestBehavior.translucent,
                            onPointerDown: (event) {
                              IrisSpatialDepth.recordTap(event.position);
                            },
                            child: Material(
                              type: MaterialType.transparency,
                              child: ThemeMorphOverlay(
                                child: SmartPillOverlay(child: child!),
                              ),
                            ),
                          ),
                          home: AppRoot(
                            memory: widget.memory,
                            onToggleTheme: _toggleTheme,
                            onSetThemeMode: _setThemeMode,
                            currentThemeMode: _themeModeToString(_themeMode),
                          ),
                        );
                      },
                    );
                  },
                );
              },
            );
          },
        );
      },
    );
  }
}
