import 'models.dart';
import 'format_guard.dart';
import 'repeater_planner_engine.dart';
import 'package:flutter/material.dart';
import 'dart:math' as math;
import '../services/remote_config_service.dart';
import '../services/helpdesk_faculty_service.dart';

// ============ LECTURE DURATION HELPER ============
/// Helper function to detect 1-hour lecture subjects (e.g. Lab theories, seminars)
bool isOneHourLecture(String subject) {
  return subject.toLowerCase().contains('(1 hr)') ||
         subject.toLowerCase().contains('(1hr)') ||
         subject.toLowerCase().contains('1 hr)');
}

double _getActualEndTime(ClassSession session) {
  return session.actualEndVal;
}

class TemporalInsight {
  final String headline;
  final String subline;
  final bool isLive;
  final String? timeInfo; // E.g., "45 mins left", "Starting in 5 mins"
  final String? teacherInfo; // E.g., "Dr. Ahmed Khan"
  final bool isUrgent; // True if class starts within 5 mins
  final String? subject;
  final String? room;
  final String? startTime;

  const TemporalInsight({
    required this.headline,
    required this.subline,
    required this.isLive,
    this.timeInfo,
    this.teacherInfo,
    this.isUrgent = false,
    this.subject,
    this.room,
    this.startTime,
  });
}

/// A single schedule entry for the teacher locator
class TeacherScheduleEntry {
  final int dayIndex;
  final String startTime;
  final String endTime;
  final String subject;
  final String room;
  final String batch;
  final bool isLive;
  final bool isUpcoming; // today but hasn't started
  final DateTime? specificDate;

  const TeacherScheduleEntry({
    required this.dayIndex,
    required this.startTime,
    required this.endTime,
    required this.subject,
    required this.room,
    required this.batch,
    this.isLive = false,
    this.isUpcoming = false,
    this.specificDate,
  });

  static const List<String> dayNames = [
    'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'
  ];

  String get dayName => dayIndex >= 1 && dayIndex <= 7 ? dayNames[dayIndex - 1] : 'Day $dayIndex';
}

/// Rich result from the teacher locator
class TeacherLocatorResult {
  final String teacherName;
  final String status; // 'live', 'today', 'scheduled', 'not_found'
  final String statusText;
  final TeacherScheduleEntry? liveSession;
  final List<TeacherScheduleEntry> todaySessions;
  final Map<int, List<TeacherScheduleEntry>> weeklySchedule; // dayIndex -> sessions
  final List<String> allRooms;
  final List<String> allSubjects;

  const TeacherLocatorResult({
    required this.teacherName,
    required this.status,
    required this.statusText,
    this.liveSession,
    this.todaySessions = const [],
    this.weeklySchedule = const {},
    this.allRooms = const [],
    this.allSubjects = const [],
  });
}

/// Represents a free time slot
class FreeSlot {
  final int dayIndex;
  final double startTime;
  final double endTime;

  FreeSlot({
    required this.dayIndex,
    required this.startTime,
    required this.endTime,
  });

  String get dayName {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    return dayIndex >= 1 && dayIndex <= 7 ? days[dayIndex - 1] : 'Day $dayIndex';
  }

  String timeRangeString(BuildContext? context) {
    final startHour = startTime.toInt();
    final startMin = ((startTime - startHour) * 60).toInt();
    final endHour = endTime.toInt();
    final endMin = ((endTime - endHour) * 60).toInt();
    return '${startHour.toString().padLeft(2, '0')}:${startMin.toString().padLeft(2, '0')} - ${endHour.toString().padLeft(2, '0')}:${endMin.toString().padLeft(2, '0')}';
  }
}

/// Makeup class suggestion with available rooms
class MakeupSlotSuggestion {
  final int dayIndex;
  final double startTime;
  final double endTime;
  final double durationHours;
  final String? slotName;
  final List<String>? availableRooms;

  MakeupSlotSuggestion({
    required this.dayIndex,
    required this.startTime,
    required this.endTime,
    required this.durationHours,
    this.slotName,
    this.availableRooms,
  });

  String get dayName {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    return dayIndex >= 1 && dayIndex <= 7 ? days[dayIndex - 1] : 'Day $dayIndex';
  }

  String timeRangeString() {
    return '${_format12Hour(startTime)} - ${_format12Hour(endTime)}';
  }

  String _format12Hour(double time) {
    final hour24 = time.floor().clamp(0, 23);
    final min = ((time - time.floor()) * 60).round().clamp(0, 59);
    final hour12 = hour24 == 0 ? 12 : (hour24 > 12 ? hour24 - 12 : hour24);
    final period = hour24 >= 12 ? 'PM' : 'AM';
    return '$hour12:${min.toString().padLeft(2, '0')} $period';
  }
}

class BatchVitalMetrics {
  final double dayProgress;
  final int completedClasses;
  final int totalClassesToday;
  final int remainingClasses;
  final double attendanceHealth;

  const BatchVitalMetrics({
    required this.dayProgress,
    required this.completedClasses,
    required this.totalClassesToday,
    required this.remainingClasses,
    required this.attendanceHealth,
  });
}

class OmniBrain {
  final UniversityMemory memory;

  OmniBrain(this.memory);

  static int minuteTimestamp(DateTime now) => now.millisecondsSinceEpoch ~/ 60000;

  final Map<String, List<ClassSession>> _teacherScheduleCache = {};
  final Map<String, String> _teacherDepartmentCache = {};
  final Map<String, TeacherLocatorResult> _teacherLocatorCache = {};
  Map<String, Set<String>>? _teacherRoomsMap;
  Map<String, String>? _teacherPrimaryDeptMap;
  String? _cachedActivePeriod;

  // Minute-resolution temporal caches (O(1) frame lookup)
  final Map<String, ({int minute, ClassSession? session})> _currentClassCache = {};
  final Map<String, ({int minute, ClassSession? session})> _nextClassCache = {};
  final Map<String, ({int minute, ClassSession? session})> _currentTeacherClassCache = {};
  final Map<String, ({int minute, ClassSession? session})> _nextTeacherClassCache = {};
  final Map<String, ({int minute, BatchVitalMetrics metrics})> _vitalMetricsCache = {};
  final Map<String, ({int minute, TemporalInsight insight})> _temporalInsightCache = {};
  final Map<String, ({int minute, TemporalInsight insight})> _examTemporalInsightCache = {};
  final Map<String, ({int minute, TemporalInsight insight})> _teacherTemporalInsightCache = {};
  ({int minute, List<String> rooms})? _emptyRoomsCache;

  // Day-resolution and pre-merged caches
  final Map<String, Map<int, List<ClassSession>>> _batchDayScheduleCache = {};
  final Map<String, Map<int, List<ClassSession>>> _mergedDayScheduleCache = {};
  final Map<String, ({int minute, List<ClassSession> schedule})> _suggestedScheduleCache = {};

  final Map<String, Map<int, List<ClassSession>>> _teacherDayScheduleCache = {};
  final Map<String, Map<int, List<ClassSession>>> _teacherMergedDayScheduleCache = {};
  final Map<String, Map<int, double>> _teacherDayHoursCache = {};
  final Map<String, ({int minute, List<ClassSession> schedule})> _teacherSuggestedScheduleCache = {};

  // Free slots & operating hours caches
  final Map<String, List<FreeSlot>> _freeSlotsBatchCache = {};
  final Map<String, List<FreeSlot>> _freeSlotsTeacherCache = {};
  Map<int, (double, double)>? _cachedOperatingHours;

  void clearFacultyCaches() {
    _teacherScheduleCache.clear();
    _teacherDepartmentCache.clear();
    _teacherLocatorCache.clear();
    _teacherRoomsMap = null;
    _teacherPrimaryDeptMap = null;
    _currentTeacherClassCache.clear();
    _nextTeacherClassCache.clear();
    _teacherTemporalInsightCache.clear();
    _teacherDayScheduleCache.clear();
    _teacherMergedDayScheduleCache.clear();
    _teacherDayHoursCache.clear();
    _teacherSuggestedScheduleCache.clear();
    _freeSlotsTeacherCache.clear();
  }

  void invalidateBatchCaches(String batch) {
    _currentClassCache.remove(batch);
    _nextClassCache.remove(batch);
    _vitalMetricsCache.remove(batch);
    _temporalInsightCache.remove(batch);
    _examTemporalInsightCache.removeWhere((k, _) => k.startsWith('$batch|'));
    _batchDayScheduleCache.remove(batch);
    _mergedDayScheduleCache.removeWhere((k, _) => k.startsWith('$batch|'));
    _suggestedScheduleCache.removeWhere((k, _) => k.startsWith('$batch|'));
    _freeSlotsBatchCache.remove(batch);
  }

  void clearAllCaches() {
    clearFacultyCaches();
    _currentClassCache.clear();
    _nextClassCache.clear();
    _vitalMetricsCache.clear();
    _temporalInsightCache.clear();
    _examTemporalInsightCache.clear();
    _emptyRoomsCache = null;
    _batchDayScheduleCache.clear();
    _mergedDayScheduleCache.clear();
    _suggestedScheduleCache.clear();
    _freeSlotsBatchCache.clear();
    _cachedOperatingHours = null;
    RepeaterPlannerEngine.clearCaches();
  }

  void _ensureCachesValid() {
    final currentPeriod = RemoteConfigService.activeAcademicPeriod.value;
    if (_cachedActivePeriod != currentPeriod) {
      _cachedActivePeriod = currentPeriod;
      clearAllCaches();
    }
  }

  /// Fast single-pass aggregation of all teaching rooms per teacher (O(S) instead of O(T*S))
  Map<String, Set<String>> getTeacherRoomsMap({String? overridePeriod}) {
    _ensureCachesValid();
    if (_teacherRoomsMap != null && overridePeriod == null) return _teacherRoomsMap!;
    final map = <String, Set<String>>{};
    for (final s in memory.activeSessions(overridePeriod: overridePeriod)) {
      if (s.room.trim().isEmpty) continue;
      final raw = s.teacher.trim().toLowerCase();
      if (raw.isEmpty || raw == 'unknown' || raw == 'na' || raw == 'staff') continue;
      map.putIfAbsent(raw, () => <String>{}).add(s.room);
      final stripped = HelpdeskFacultyService.stripDepartmentPrefix(s.teacher).trim().toLowerCase();
      if (stripped.isNotEmpty && stripped != raw) {
        map.putIfAbsent(stripped, () => <String>{}).add(s.room);
      }
    }
    if (overridePeriod == null) {
      _teacherRoomsMap = map;
    }
    return map;
  }

  /// Fast single-pass determination of primary department per teacher (O(S) instead of O(T*S))
  Map<String, String> getTeacherDepartmentsMap({String? overridePeriod}) {
    _ensureCachesValid();
    if (_teacherPrimaryDeptMap != null && overridePeriod == null) return _teacherPrimaryDeptMap!;
    final deptCounts = <String, Map<String, int>>{};
    for (final s in memory.activeSessions(overridePeriod: overridePeriod)) {
      final raw = s.teacher.trim().toLowerCase();
      if (raw.isEmpty || raw == 'unknown' || raw == 'na' || raw == 'staff') continue;
      final stripped = HelpdeskFacultyService.stripDepartmentPrefix(s.teacher).trim().toLowerCase();

      var dept = HelpdeskFacultyService.departmentNameFromCode(s.batchKey.department.trim());
      if (dept == 'Academic Faculty') {
        dept = HelpdeskFacultyService.departmentNameFromCode(s.batchKey.program.trim());
      }
      if (dept != 'Academic Faculty') {
        if (raw.isNotEmpty) {
          deptCounts.putIfAbsent(raw, () => <String, int>{})[dept] =
              (deptCounts[raw]![dept] ?? 0) + 1;
        }
        if (stripped.isNotEmpty && stripped != raw) {
          deptCounts.putIfAbsent(stripped, () => <String, int>{})[dept] =
              (deptCounts[stripped]![dept] ?? 0) + 1;
        }
      }
    }
    final result = <String, String>{};
    for (final entry in deptCounts.entries) {
      final sorted = entry.value.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
      if (sorted.isNotEmpty) {
        result[entry.key] = sorted.first.key;
      }
    }
    if (overridePeriod == null) {
      _teacherPrimaryDeptMap = result;
    }
    return result;
  }

  String? repeaterActiveBatch;
  List<ClassSession>? customRepeaterSessions;

  Future<void> reloadRepeaterSessions(String? currentBatch) async {
    repeaterActiveBatch = currentBatch;
    if (await RepeaterScheduleStorage.isRepeaterActive()) {
      customRepeaterSessions = await RepeaterScheduleStorage.loadSavedSessions(memory);
    } else {
      customRepeaterSessions = null;
    }
    if (currentBatch != null) {
      invalidateBatchCaches(currentBatch);
    } else {
      clearAllCaches();
    }
  }

  List<ClassSession> scheduleFor(String batch, {String? overridePeriod}) {
    final period = overridePeriod ?? RemoteConfigService.activeAcademicPeriod.value;
    final isExam = period == 'midterms' || period == 'finals';
    if (!isExam &&
        customRepeaterSessions != null &&
        customRepeaterSessions!.isNotEmpty &&
        repeaterActiveBatch != null &&
        batch.trim().toUpperCase() == repeaterActiveBatch!.trim().toUpperCase()) {
      return customRepeaterSessions!;
    }
    return memory.byBatch(overridePeriod: overridePeriod)[batch] ?? [];
  }

  List<ClassSession> scheduleForTeacher(
    String teacherName, {
    String? overridePeriod,
    String? department,
  }) {
    final cleanQuery = HelpdeskFacultyService.stripDepartmentPrefix(teacherName).trim();
    if (cleanQuery.isEmpty) return const [];

    _ensureCachesValid();
    final cacheKey = '${cleanQuery.toLowerCase()}_${overridePeriod ?? ""}';
    final cached = _teacherScheduleCache[cacheKey];
    if (cached != null) return cached;

    final name = cleanQuery.toLowerCase();
    final index = memory.byTeacher(overridePeriod: overridePeriod);

    final matchedSessions = <ClassSession>[];
    final seenSlots = <String>{};

    void addSessions(List<ClassSession> list) {
      for (final s in list) {
        final slotKey = s.id.isNotEmpty
            ? s.id
            : '${s.dayIndex}_${s.startTime}_${s.endTime}_${s.subject}_${s.batchKey.batch}_${s.room}';
        if (seenSlots.add(slotKey)) {
          matchedSessions.add(s);
        }
      }
    }

    final queryHonorific = HelpdeskFacultyService.extractHonorificCategory(cleanQuery);

    // 1. Direct exact key match (cleaned or raw)
    final direct = index[name] ?? index[teacherName.trim().toLowerCase()];
    if (direct != null && direct.isNotEmpty) {
      addSessions(direct);
    }

    // 2. Scan index for compatible name variants (e.g. "Prof. Dr. Abrar Hussain" vs "Dr. Abrar Hussain" vs "Abrar Hussain")
    for (final entry in index.entries) {
      final entryHonorific = HelpdeskFacultyService.extractHonorificCategory(entry.key);
      if (HelpdeskFacultyService.areHonorificsConflicting(queryHonorific, entryHonorific)) {
        continue;
      }
      final isMatch = _matchesTeacher(entry.key, cleanQuery) ||
          HelpdeskFacultyService.calculateSimilarity(entry.key, cleanQuery) >= 0.65;
      if (isMatch) {
        addSessions(entry.value);
      }
    }

    matchedSessions.sort((a, b) {
      final dayCmp = a.dayIndex.compareTo(b.dayIndex);
      if (dayCmp != 0) return dayCmp;
      return a.safeStartVal.compareTo(b.safeStartVal);
    });

    _teacherScheduleCache[cacheKey] = matchedSessions;
    return matchedSessions;
  }

  /// Merges concurrent sessions sharing the same time slot, subject, and room (e.g. combined sections)
  List<ClassSession> mergeConcurrentSessions(List<ClassSession> schedule) {
    if (schedule.isEmpty) return [];

    final result = <ClassSession>[];
    for (final session in schedule) {
      final existingIndex = result.indexWhere((r) =>
          r.dayIndex == session.dayIndex &&
          (r.safeStartVal - session.safeStartVal).abs() < 0.05 &&
          (r.actualEndVal - session.actualEndVal).abs() < 0.05 &&
          r.subject.trim().toLowerCase() == session.subject.trim().toLowerCase() &&
          FormatGuard.sanitizeRoom(r.room) == FormatGuard.sanitizeRoom(session.room));

      if (existingIndex >= 0) {
        final existing = result[existingIndex];
        final existingBatches = existing.combinedBatches ?? [existing.batchKey.batch];
        final newBatch = session.batchKey.batch;
        final mergedBatches = List<String>.from(existingBatches);
        if (!mergedBatches.contains(newBatch)) {
          mergedBatches.add(newBatch);
        }
        result[existingIndex] = ClassSession(
          id: existing.id,
          batchKey: BatchKey.parse(mergedBatches.join(' + ')),
          dayIndex: existing.dayIndex,
          startTime: existing.startTime,
          endTime: existing.endTime,
          subject: existing.subject,
          teacher: existing.teacher,
          room: existing.room,
          isBreak: existing.isBreak,
          specificDate: existing.specificDate,
          combinedBatches: mergedBatches,
          startVal: existing.safeStartVal,
          endVal: existing.safeEndVal,
          actualEndVal: existing.actualEndVal,
        );
      } else {
        final batches = session.combinedBatches ?? [session.batchKey.batch];
        result.add(ClassSession(
          id: session.id,
          batchKey: session.batchKey,
          dayIndex: session.dayIndex,
          startTime: session.startTime,
          endTime: session.endTime,
          subject: session.subject,
          teacher: session.teacher,
          room: session.room,
          isBreak: session.isBreak,
          specificDate: session.specificDate,
          combinedBatches: batches,
          startVal: session.safeStartVal,
          endVal: session.safeEndVal,
          actualEndVal: session.actualEndVal,
        ));
      }
    }
    return result;
  }

  // Get merged lecture sessions (consecutive slots of same lecture)
  List<ClassSession> getMergedConsecutiveSessions(List<ClassSession> schedule) {
    if (schedule.isEmpty) return [];
    
    final concurrentMerged = mergeConcurrentSessions(schedule);
    final sorted = List<ClassSession>.from(concurrentMerged)
      ..sort((a, b) {
        final dayCmp = a.dayIndex.compareTo(b.dayIndex);
        if (dayCmp != 0) return dayCmp;
        return a.safeStartVal.compareTo(b.safeStartVal);
      });
    
    final merged = <ClassSession>[];
    ClassSession? current;
    
    for (final session in sorted) {
      if (current == null) {
        current = session;
        continue;
      }
      
      // Check if this session is consecutive with current
      if (current.isConsecutiveWith(session)) {
        final combined = <String>{
          ...?current.combinedBatches,
          if (current.combinedBatches == null) current.batchKey.batch,
          ...?session.combinedBatches,
          if (session.combinedBatches == null) session.batchKey.batch,
        }.toList();
        // Merge: create new session with extended end time
        current = ClassSession(
          id: current.id,
          batchKey: BatchKey.parse(combined.join(' + ')),
          dayIndex: current.dayIndex,
          startTime: current.startTime,
          endTime: session.endTime, // Extend to this session's end
          subject: current.subject,
          teacher: current.teacher,
          room: current.room,
          isBreak: current.isBreak,
          specificDate: current.specificDate,
          combinedBatches: combined.length > 1 ? combined : null,
          startVal: current.safeStartVal,
          endVal: session.safeEndVal,
          actualEndVal: session.actualEndVal,
        );
      } else {
        merged.add(current);
        current = session;
      }
    }
    
    if (current != null) {
      merged.add(current);
    }
    
    return merged;
  }

  BatchVitalMetrics getVitalMetrics(String batch, DateTime now) {
    _ensureCachesValid();
    final mKey = minuteTimestamp(now);
    final cached = _vitalMetricsCache[batch];
    if (cached != null && cached.minute == mKey) {
      return cached.metrics;
    }

    final result = _computeVitalMetrics(batch, now);
    _vitalMetricsCache[batch] = (minute: mKey, metrics: result);
    return result;
  }

  BatchVitalMetrics _computeVitalMetrics(String batch, DateTime now) {
    final schedule = scheduleFor(batch);
    final today = schedule.where((s) => s.dayIndex == now.weekday).toList();
    final currentT = now.hour + (now.minute / 60.0);

    if (today.isEmpty) {
      return const BatchVitalMetrics(
        dayProgress: 0.0,
        completedClasses: 0,
        totalClassesToday: 0,
        remainingClasses: 0,
        attendanceHealth: 1.0,
      );
    }

    final mergedToday = getMergedConsecutiveSessions(today);
    final completed = mergedToday.where((s) => _getActualEndTime(s) <= currentT).length;
    final total = mergedToday.length;
    final remaining = mergedToday.where((s) => s.safeStartVal > currentT).length;
    
    // Day progress based on completed classes vs total
    final dayProgress = total > 0 ? completed / total : 0.0;
    
    // Simulated attendance health for now (ideally from a service)
    final attendanceHealth = 0.85 + (math.Random(now.day).nextDouble() * 0.12);

    return BatchVitalMetrics(
      dayProgress: dayProgress,
      completedClasses: completed,
      totalClassesToday: total,
      remainingClasses: remaining,
      attendanceHealth: attendanceHealth,
    );
  }

  // Find all consecutive sessions for a given session
  ClassSession getMergedSession(ClassSession session, List<ClassSession> allSessions) {
    final sameDaySessions = allSessions
        .where((s) => s.dayIndex == session.dayIndex && s.isSameLectureAs(session))
        .toList()
      ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));
    
    if (sameDaySessions.isEmpty) return session;
    
    final blocks = <List<ClassSession>>[];
    var currentBlock = <ClassSession>[];
    
    for (final s in sameDaySessions) {
      if (currentBlock.isEmpty) {
        currentBlock.add(s);
      } else {
        final last = currentBlock.last;
        if ((s.safeStartVal - last.actualEndVal).abs() < 0.01) {
          currentBlock.add(s);
        } else {
          blocks.add(currentBlock);
          currentBlock = [s];
        }
      }
    }
    if (currentBlock.isNotEmpty) {
      blocks.add(currentBlock);
    }
    
    for (final block in blocks) {
      final containsSession = block.any((s) => s.id == session.id || 
          (s.safeStartVal == session.safeStartVal && s.safeEndVal == session.safeEndVal));
      if (containsSession) {
        final combined = <String>{
          for (final s in block) ...?s.combinedBatches,
          for (final s in block) s.batchKey.batch,
        }.toList();
        return ClassSession(
          id: block.first.id,
          batchKey: BatchKey.parse(combined.join(' + ')),
          dayIndex: block.first.dayIndex,
          startTime: block.first.startTime,
          endTime: block.last.endTime,
          subject: block.first.subject,
          teacher: block.first.teacher,
          room: block.first.room,
          isBreak: block.first.isBreak,
          specificDate: block.first.specificDate,
          combinedBatches: combined.length > 1 ? combined : null,
          startVal: block.first.safeStartVal,
          endVal: block.last.safeEndVal,
          actualEndVal: block.last.actualEndVal,
        );
      }
    }
    
    return session;
  }

  ClassSession? getCurrentClass(String batch, DateTime now) {
    _ensureCachesValid();
    final mKey = minuteTimestamp(now);
    final cached = _currentClassCache[batch];
    if (cached != null && cached.minute == mKey) {
      return cached.session;
    }

    final result = _computeCurrentClass(batch, now);
    _currentClassCache[batch] = (minute: mKey, session: result);
    return result;
  }

  ClassSession? _computeCurrentClass(String batch, DateTime now) {
    final currentT = now.hour + (now.minute / 60.0);
    final schedule = scheduleFor(batch);
    
    for (final s in schedule) {
      if (s.specificDate != null) {
        final isSameDate = s.specificDate!.year == now.year &&
            s.specificDate!.month == now.month &&
            s.specificDate!.day == now.day;
        if (!isSameDate) continue;
      }
      final actualEnd = _getActualEndTime(s);
      if (s.dayIndex == now.weekday && currentT >= s.safeStartVal && currentT < actualEnd) {
        // Return merged session to handle consecutive slots
        return getMergedSession(s, schedule);
      }
    }
    return null;
  }

  ClassSession? getNextClass(String batch, DateTime now) {
    _ensureCachesValid();
    final mKey = minuteTimestamp(now);
    final cached = _nextClassCache[batch];
    if (cached != null && cached.minute == mKey) {
      return cached.session;
    }

    final result = _computeNextClass(batch, now);
    _nextClassCache[batch] = (minute: mKey, session: result);
    return result;
  }

  ClassSession? _computeNextClass(String batch, DateTime now) {
    final currentT = now.hour + (now.minute / 60.0);
    final schedule = scheduleFor(batch);

    final today = schedule
        .where((s) {
          if (s.specificDate != null) {
            final isSameDate = s.specificDate!.year == now.year &&
                s.specificDate!.month == now.month &&
                s.specificDate!.day == now.day;
            if (!isSameDate) return false;
          }
          return s.dayIndex == now.weekday && s.safeStartVal > currentT;
        })
        .toList()
      ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));

    if (today.isNotEmpty) {
      // Return merged session to handle consecutive slots
      return getMergedSession(today.first, schedule);
    }

    for (int daysAhead = 1; daysAhead <= 6; daysAhead++) {
      final nextDay = ((now.weekday + daysAhead - 1) % 7) + 1;
      final targetDate = now.add(Duration(days: daysAhead));
      final candidates = schedule.where((s) {
        if (s.specificDate != null) {
          final isSameDate = s.specificDate!.year == targetDate.year &&
              s.specificDate!.month == targetDate.month &&
              s.specificDate!.day == targetDate.day;
          if (!isSameDate) return false;
        }
        return s.dayIndex == nextDay;
      }).toList()
        ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));
      if (candidates.isNotEmpty) {
        // Return merged session to handle consecutive slots
        return getMergedSession(candidates.first, schedule);
      }
    }

    return null;
  }

  ClassSession? getCurrentClassForTeacher(String teacherName, DateTime now) {
    _ensureCachesValid();
    final cleanT = HelpdeskFacultyService.stripDepartmentPrefix(teacherName).trim().toLowerCase();
    final mKey = minuteTimestamp(now);
    final cached = _currentTeacherClassCache[cleanT];
    if (cached != null && cached.minute == mKey) {
      return cached.session;
    }

    final result = _computeCurrentClassForTeacher(cleanT, now);
    _currentTeacherClassCache[cleanT] = (minute: mKey, session: result);
    return result;
  }

  ClassSession? _computeCurrentClassForTeacher(String teacherName, DateTime now) {
    final currentT = now.hour + (now.minute / 60.0);
    final schedule = scheduleForTeacher(teacherName);

    for (final s in schedule) {
      if (s.specificDate != null) {
        final isSameDate = s.specificDate!.year == now.year &&
            s.specificDate!.month == now.month &&
            s.specificDate!.day == now.day;
        if (!isSameDate) continue;
      }
      final actualEnd = _getActualEndTime(s);
      if (s.dayIndex == now.weekday && currentT >= s.safeStartVal && currentT < actualEnd) {
        return getMergedSession(s, schedule);
      }
    }
    return null;
  }

  ClassSession? getNextClassForTeacher(String teacherName, DateTime now) {
    _ensureCachesValid();
    final cleanT = HelpdeskFacultyService.stripDepartmentPrefix(teacherName).trim().toLowerCase();
    final mKey = minuteTimestamp(now);
    final cached = _nextTeacherClassCache[cleanT];
    if (cached != null && cached.minute == mKey) {
      return cached.session;
    }

    final result = _computeNextClassForTeacher(cleanT, now);
    _nextTeacherClassCache[cleanT] = (minute: mKey, session: result);
    return result;
  }

  ClassSession? _computeNextClassForTeacher(String teacherName, DateTime now) {
    final currentT = now.hour + (now.minute / 60.0);
    final schedule = scheduleForTeacher(teacherName);

    final today = schedule
        .where((s) {
          if (s.specificDate != null) {
            final isSameDate = s.specificDate!.year == now.year &&
                s.specificDate!.month == now.month &&
                s.specificDate!.day == now.day;
            if (!isSameDate) return false;
          }
          return s.dayIndex == now.weekday && s.safeStartVal > currentT;
        })
        .toList()
      ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));

    if (today.isNotEmpty) {
      return getMergedSession(today.first, schedule);
    }

    for (int daysAhead = 1; daysAhead <= 6; daysAhead++) {
      final nextDay = ((now.weekday + daysAhead - 1) % 7) + 1;
      final targetDate = now.add(Duration(days: daysAhead));
      final candidates = schedule.where((s) {
        if (s.specificDate != null) {
          final isSameDate = s.specificDate!.year == targetDate.year &&
              s.specificDate!.month == targetDate.month &&
              s.specificDate!.day == targetDate.day;
          if (!isSameDate) return false;
        }
        return s.dayIndex == nextDay;
      }).toList()
        ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));
      if (candidates.isNotEmpty) {
        return getMergedSession(candidates.first, schedule);
      }
    }

    return null;
  }

  List<String> findEmptyRooms(DateTime now) {
    _ensureCachesValid();
    final mKey = minuteTimestamp(now);
    if (_emptyRoomsCache != null && _emptyRoomsCache!.minute == mKey) {
      return _emptyRoomsCache!.rooms;
    }

    final result = _computeEmptyRooms(now);
    _emptyRoomsCache = (minute: mKey, rooms: result);
    return result;
  }

  List<String> _computeEmptyRooms(DateTime now) {
    final allRoomsList = memory.allRooms();
    final occupied = <String>{};
    final currentT = now.hour + (now.minute / 60.0);
    for (final session in memory.activeSessions()) {
      if (session.specificDate != null) {
        final isSameDate = session.specificDate!.year == now.year &&
            session.specificDate!.month == now.month &&
            session.specificDate!.day == now.day;
        if (!isSameDate) continue;
      }
      if (session.dayIndex == now.weekday && currentT >= session.safeStartVal && currentT < _getActualEndTime(session)) {
        occupied.add(session.room);
      }
    }

    final available = allRoomsList.where((r) => !occupied.contains(r)).toList()..sort();
    return available;
  }

  /// Find empty rooms for a specific time slot (used for makeup scheduling)
  List<String> findEmptyRoomsForSlot(int dayIndex, double startTime, double endTime) {
    final allRoomsList = memory.allRooms();
    final occupied = <String>{};
    for (final session in memory.activeSessions()) {
      if (session.dayIndex == dayIndex) {
        if (session.safeStartVal < (endTime - 0.03) && session.safeEndVal > (startTime + 0.03)) {
          occupied.add(session.room);
        }
      }
    }

    final available = allRoomsList.where((r) => !occupied.contains(r)).toList()..sort();
    return available;
  }

  /// Get all unique teacher names from the registry
  List<String> allTeachers() {
    return memory.allTeachers();
  }

  /// Infers the teaching department for a teacher based on their active timetable class sections
  String departmentForTeacher(String teacher) {
    _ensureCachesValid();
    final cacheKey = teacher.trim().toLowerCase();
    final cached = _teacherDepartmentCache[cacheKey];
    if (cached != null) return cached;

    // Fast-path: Check single-pass pre-indexed map
    final deptsMap = getTeacherDepartmentsMap();
    final stripped = HelpdeskFacultyService.stripDepartmentPrefix(teacher).trim().toLowerCase();
    final direct = deptsMap[cacheKey] ?? deptsMap[stripped];
    if (direct != null && direct.isNotEmpty && direct != 'Academic Faculty') {
      _teacherDepartmentCache[cacheKey] = direct;
      return direct;
    }

    final schedule = scheduleForTeacher(teacher);
    final deptCounts = <String, int>{};
    for (final s in schedule) {
      final deptCode = s.batchKey.department.trim();
      final mapped = HelpdeskFacultyService.departmentNameFromCode(deptCode);
      if (mapped != 'Academic Faculty') {
        deptCounts[mapped] = (deptCounts[mapped] ?? 0) + 1;
      } else {
        final prog = s.batchKey.program.trim();
        final mappedProg = HelpdeskFacultyService.departmentNameFromCode(prog);
        if (mappedProg != 'Academic Faculty') {
          deptCounts[mappedProg] = (deptCounts[mappedProg] ?? 0) + 1;
        } else {
          final batch = s.batchKey.batch.trim();
          final tokens = batch.split(RegExp(r'[-_\s]+'));
          for (final t in tokens) {
            final code = t.replaceAll(RegExp(r'\d+'), '').toLowerCase();
            final m = HelpdeskFacultyService.departmentNameFromCode(code);
            if (m != 'Academic Faculty') {
              deptCounts[m] = (deptCounts[m] ?? 0) + 1;
              break;
            }
          }
        }
      }
    }
    String result = 'Academic Faculty';
    if (deptCounts.isNotEmpty) {
      final sorted = deptCounts.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
      result = sorted.first.key;
    }
    _teacherDepartmentCache[cacheKey] = result;
    return result;
  }

  /// Smart fuzzy-ish search: matches exact, normalized, or subset tokens with title protection
  bool _matchesTeacher(String teacherName, String search) {
    final cleanT = HelpdeskFacultyService.stripDepartmentPrefix(teacherName).trim();
    final cleanS = HelpdeskFacultyService.stripDepartmentPrefix(search).trim();
    if (cleanT.isEmpty || cleanS.isEmpty) return false;
    final h1 = HelpdeskFacultyService.extractHonorificCategory(cleanT);
    final h2 = HelpdeskFacultyService.extractHonorificCategory(cleanS);
    if (HelpdeskFacultyService.areHonorificsConflicting(h1, h2)) return false; // Strictly forbid conflicting titles (Dr vs Mr vs Engr)

    final name = cleanT.toLowerCase().replaceAll('.', ' ').trim();
    final cleanSearch = cleanS.toLowerCase().replaceAll('.', ' ').trim();
    if (name == cleanSearch) return true;
    if (HelpdeskFacultyService.isNameMatch(cleanT, cleanS, threshold: 0.65)) {
      return true;
    }
    final tokensT = HelpdeskFacultyService.extractCoreTokens(cleanT);
    final tokensS = HelpdeskFacultyService.extractCoreTokens(cleanS);
    if (tokensT.isNotEmpty && tokensS.isNotEmpty) {
      final sT = tokensT.toSet();
      final sS = tokensS.toSet();
      if (sT.containsAll(sS) || sS.containsAll(sT)) {
        return true;
      }
    }
    return false;
  }

  /// Locate a teacher with full weekly schedule and smart status
  TeacherLocatorResult locateTeacher(
    String query,
    DateTime now, {
    String? department,
  }) {
    _ensureCachesValid();
    final cleanQuery = HelpdeskFacultyService.stripDepartmentPrefix(query).trim();
    if (cleanQuery.isEmpty) {
      return const TeacherLocatorResult(
        teacherName: '',
        status: 'empty',
        statusText: 'Enter a teacher name',
      );
    }

    final weekday = now.weekday;
    final minuteBucket = now.minute;
    final hourBucket = now.hour;
    final cacheKey = '${cleanQuery.toLowerCase()}_${department ?? ""}_${weekday}_${hourBucket}_$minuteBucket';
    final cached = _teacherLocatorCache[cacheKey];
    if (cached != null) return cached;

    final currentT = now.hour + (now.minute / 60.0);
    final matchedSessions = scheduleForTeacher(cleanQuery, department: department);

    if (matchedSessions.isEmpty) {
      final notFound = TeacherLocatorResult(
        teacherName: query,
        status: 'not_found',
        statusText: 'No match found in registry',
      );
      _teacherLocatorCache[cacheKey] = notFound;
      return notFound;
    }

    String resolvedName = cleanQuery;
    final nameFreq = <String, int>{};
    for (final s in matchedSessions) {
      final formatted = FormatGuard.formatTeacherName(s.teacher);
      nameFreq[formatted] = (nameFreq[formatted] ?? 0) + 1;
    }
    if (nameFreq.isNotEmpty) {
      resolvedName = nameFreq.entries
          .reduce((a, b) => a.value >= b.value ? a : b)
          .key;
    }

    // Build weekly schedule
    final weeklySchedule = <int, List<TeacherScheduleEntry>>{};
    final allRooms = <String>{};
    final allSubjects = <String>{};
    TeacherScheduleEntry? liveSession;
    final todaySessions = <TeacherScheduleEntry>[];

    for (final session in matchedSessions) {
      allRooms.add(session.room);
      allSubjects.add(session.subject);

      final isDateValid = session.specificDate == null ||
          (session.specificDate!.year == now.year &&
              session.specificDate!.month == now.month &&
              session.specificDate!.day == now.day);

      final isLive = isDateValid &&
          session.dayIndex == weekday &&
          currentT >= session.safeStartVal &&
          currentT < _getActualEndTime(session);
      final isUpcoming = isDateValid &&
          session.dayIndex == weekday &&
          session.safeStartVal > currentT;

      final entry = TeacherScheduleEntry(
        dayIndex: session.dayIndex,
        startTime: session.startTime,
        endTime: session.endTime,
        subject: session.subject,
        room: session.room,
        batch: session.batchKey.batch,
        isLive: isLive,
        isUpcoming: isUpcoming,
        specificDate: session.specificDate,
      );

      weeklySchedule.putIfAbsent(session.dayIndex, () => []).add(entry);

      if (isLive) liveSession = entry;
      if (session.dayIndex == weekday && isDateValid) todaySessions.add(entry);
    }

    // Sort each day's sessions by start time
    for (final entries in weeklySchedule.values) {
      entries.sort((a, b) => FormatGuard.toDecimalTime(a.startTime).compareTo(FormatGuard.toDecimalTime(b.startTime)));
    }
    todaySessions.sort((a, b) => FormatGuard.toDecimalTime(a.startTime).compareTo(FormatGuard.toDecimalTime(b.startTime)));

    // Determine status
    String status;
    String statusText;

    if (liveSession != null) {
      status = 'live';
      statusText = 'Live now in ${liveSession.room} — ${liveSession.subject}';
    } else if (todaySessions.any((s) => s.isUpcoming)) {
      status = 'today';
      final next = todaySessions.firstWhere((s) => s.isUpcoming);
      statusText = 'Next at ${next.startTime} in ${next.room} — ${next.subject}';
    } else if (todaySessions.isNotEmpty) {
      status = 'today';
      statusText = 'Done for today (${todaySessions.length} classes completed)';
    } else {
      // Find next day they teach
      status = 'scheduled';
      int? nextDay;
      for (int offset = 1; offset <= 7; offset++) {
        final day = ((weekday - 1 + offset) % 7) + 1;
        if (weeklySchedule.containsKey(day)) {
          nextDay = day;
          break;
        }
      }
      if (nextDay != null) {
        final nextEntries = weeklySchedule[nextDay]!;
        statusText = 'Next on ${TeacherScheduleEntry.dayNames[nextDay - 1]} at ${nextEntries.first.startTime}';
      } else {
        statusText = 'Schedule available';
      }
    }

    final result = TeacherLocatorResult(
      teacherName: resolvedName,
      status: status,
      statusText: statusText,
      liveSession: liveSession,
      todaySessions: todaySessions,
      weeklySchedule: weeklySchedule,
      allRooms: allRooms.toList()..sort(),
      allSubjects: allSubjects.toList()..sort(),
    );
    _teacherLocatorCache[cacheKey] = result;
    return result;
  }

  TemporalInsight buildTemporalInsight(String batch, DateTime now) {
    _ensureCachesValid();
    final mKey = minuteTimestamp(now);
    final cached = _temporalInsightCache[batch];
    if (cached != null && cached.minute == mKey) {
      return cached.insight;
    }

    final result = _computeTemporalInsight(batch, now);
    _temporalInsightCache[batch] = (minute: mKey, insight: result);
    return result;
  }

  TemporalInsight _computeTemporalInsight(String batch, DateTime now) {
    final current = getCurrentClass(batch, now);
    final next = getNextClass(batch, now);
    final currentT = now.hour + (now.minute / 60.0);
    final schedule = scheduleFor(batch);
    final today = schedule
        .where((s) {
          if (s.specificDate != null) {
            final isSameDate = s.specificDate!.year == now.year &&
                s.specificDate!.month == now.month &&
                s.specificDate!.day == now.day;
            if (!isSameDate) return false;
          }
          return s.dayIndex == now.weekday;
        })
        .toList()
      ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));

    final period = RemoteConfigService.activeAcademicPeriod.value;
    final isExam = period == 'midterms' || period == 'finals';

    if (current != null) {
      final actualEndTime = _getActualEndTime(current);
      final minutesLeft = ((actualEndTime - currentT) * 60).round();
      final timeLeft = minutesLeft > 60 
          ? '${(minutesLeft / 60).floor()}h ${minutesLeft % 60}m left'
          : '$minutesLeft mins left';
      
      final headlineText = isExam
          ? (period == 'midterms' ? 'Live Midterm' : 'Live Final Exam')
          : (period == 'sports_week' ? 'Gala Event Live' : 'Live Now');
      
      final roomPrefix = isExam ? 'Hall: ' : '';
      
      return TemporalInsight(
        headline: headlineText,
        subline: '${current.subject} · $roomPrefix${current.room}',
        timeInfo: timeLeft,
        teacherInfo: current.teacher,
        isLive: true,
        isUrgent: false,
        subject: current.subject,
        room: current.room,
        startTime: current.startTime,
      );
    }

    if (today.isNotEmpty) {
      final previous = today.lastWhere(
        (s) => _getActualEndTime(s) <= currentT,
        orElse: () => today.first,
      );
      final upcoming = today.firstWhere(
        (s) => s.safeStartVal > currentT,
        orElse: () => today.first,
      );
      if (_getActualEndTime(previous) <= currentT && upcoming.safeStartVal > currentT) {
        // Get merged version of upcoming class for accurate time display
        final mergedUpcoming = getMergedSession(upcoming, schedule);
        
        // Break time calculations
        final breakMinutes = ((mergedUpcoming.safeStartVal - currentT) * 60).round();
        final breakDuration = breakMinutes > 60 
            ? '${(breakMinutes / 60).floor()}h ${breakMinutes % 60}m break'
            : '$breakMinutes min break';
        
        return TemporalInsight(
          headline: 'Break',
          subline: '${mergedUpcoming.subject} at ${mergedUpcoming.startTime} · ${mergedUpcoming.room}',
          timeInfo: breakDuration,
          teacherInfo: mergedUpcoming.teacher,
          isLive: false,
          subject: mergedUpcoming.subject,
          room: mergedUpcoming.room,
          startTime: mergedUpcoming.startTime,
        );
      }
    }

    if (next != null) {
      var dayDiff = (next.dayIndex - now.weekday + 7) % 7;
      if (dayDiff == 0 && next.safeStartVal <= currentT) {
        dayDiff = 7;
      }
      final earlyMorning = now.hour < 8 && dayDiff == 0;
      final String label = earlyMorning
          ? 'Early Morning'
          : (dayDiff == 0
              ? 'Next Up'
              : (dayDiff == 1 ? 'Tomorrow' : 'Next ${_weekdayShortName(next.dayIndex)}'));
      
      // Check if starting soon (within 5 minutes for today's classes)
      final isStartingSoon = dayDiff == 0 && currentT >= (next.safeStartVal - 0.084);
      
      String timeInfo = '';
      if (dayDiff == 0) {
        // Same day class
        final nextMinutes = ((next.safeStartVal - currentT) * 60).round();
        if (nextMinutes > 0) {
          timeInfo = nextMinutes > 60 
              ? 'in ${(nextMinutes / 60).floor()}h ${nextMinutes % 60}m'
              : 'in $nextMinutes mins';
        } else {
          timeInfo = 'starting now';
        }
      } else {
        // Next day or multi-day gap countdown
        final totalMinutes = ((24.0 - currentT) * 60 +
                (dayDiff - 1) * 24 * 60 +
                next.safeStartVal * 60)
            .round();
        
        final hours = totalMinutes ~/ 60;
        final mins = totalMinutes % 60;
        
        if (hours >= 24) {
          final days = hours ~/ 24;
          final remainingHours = hours % 24;
          timeInfo = remainingHours > 0 
              ? 'in ${days}d ${remainingHours}h'
              : 'in ${days}d';
        } else if (hours > 0) {
          timeInfo = mins > 0 
              ? 'in ${hours}h ${mins}m'
              : 'in ${hours}h';
        } else {
          timeInfo = 'in ${mins}m';
        }
      }
      
      return TemporalInsight(
        headline: label,
        subline: '${next.subject} at ${next.startTime} · ${next.room}',
        timeInfo: timeInfo,
        teacherInfo: next.teacher,
        isLive: false,
        isUrgent: isStartingSoon,
        subject: next.subject,
        room: next.room,
        startTime: next.startTime,
      );
    }

    return const TemporalInsight(
      headline: 'No Classes',
      subline: 'Enjoy the free time',
      isLive: false,
      subject: 'No Classes',
      room: '',
      startTime: '',
    );
  }

  static String _weekdayShortName(int index) {
    const names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    if (index >= 1 && index <= 7) return names[index - 1];
    return 'Day';
  }

  /// Builds intelligent temporal insight for exam periods (midterms / finals)
  TemporalInsight buildExamTemporalInsight(String batch, DateTime now, String period) {
    _ensureCachesValid();
    final mKey = minuteTimestamp(now);
    final cacheKey = '$batch|$period';
    final cached = _examTemporalInsightCache[cacheKey];
    if (cached != null && cached.minute == mKey) {
      return cached.insight;
    }

    final result = _computeExamTemporalInsight(batch, now, period);
    _examTemporalInsightCache[cacheKey] = (minute: mKey, insight: result);
    return result;
  }

  TemporalInsight _computeExamTemporalInsight(String batch, DateTime now, String period) {
    final rawExams = period == 'midterms'
        ? RemoteConfigService.midtermExams.value
        : RemoteConfigService.finalExams.value;

    final matchedExams = rawExams.where((exam) {
      final examBatchRaw = (exam['batch'] ?? '').toString();
      return BatchKey.isBatchMatch(batch, examBatchRaw);
    }).toList();

    final examLabel = period == 'midterms' ? 'Midterm Exam' : 'Final Exam';

    if (matchedExams.isEmpty) {
      return TemporalInsight(
        headline: '$examLabel Period',
        subline: 'Check Date Sheet Noticeboard',
        timeInfo: 'EXAMS IN SESSION',
        isLive: false,
        subject: '$examLabel Schedule',
        room: 'Examination Center',
        startTime: '',
      );
    }

    // Deduplicate and parse exams
    final List<Map<String, dynamic>> parsedList = [];
    for (final e in matchedExams) {
      final subject = (e['subject'] ?? '').toString().trim();
      final dateStr = (e['date'] ?? '').toString().trim();
      final timeStr = (e['time'] ?? '').toString().trim();
      final room = (e['room'] ?? '').toString().trim();
      if (subject.isEmpty) continue;

      final parsedDt = FormatGuard.parseDate(dateStr);

      parsedList.add({
        'subject': subject,
        'date': dateStr,
        'time': timeStr,
        'room': room.isNotEmpty ? room : 'Exam Hall',
        'dateTime': parsedDt,
      });
    }

    if (parsedList.isEmpty) {
      return TemporalInsight(
        headline: '$examLabel Period',
        subline: 'Check Date Sheet Noticeboard',
        timeInfo: 'EXAMS IN SESSION',
        isLive: false,
        subject: '$examLabel Schedule',
        room: 'Examination Center',
        startTime: '',
      );
    }

    // Sort chronologically by date and time
    parsedList.sort((a, b) {
      final dtA = (a['dateTime'] as DateTime?) ?? DateTime(3000);
      final dtB = (b['dateTime'] as DateTime?) ?? DateTime(3000);
      if (dtA != dtB) return dtA.compareTo(dtB);
      final tA = (a['time'] ?? '').toString();
      final tB = (b['time'] ?? '').toString();
      return tA.compareTo(tB);
    });

    final todayMidnight = DateTime(now.year, now.month, now.day);

    // Find the next upcoming or today's exam
    Map<String, dynamic>? targetExam;
    for (final exam in parsedList) {
      final dt = exam['dateTime'] as DateTime?;
      if (dt != null) {
        final examDay = DateTime(dt.year, dt.month, dt.day);
        if (!examDay.isBefore(todayMidnight)) {
          targetExam = exam;
          break;
        }
      } else {
        targetExam = exam;
        break;
      }
    }

    // If all exams are in the past
    if (targetExam == null) {
      return TemporalInsight(
        headline: 'All Exams Finished',
        subline: 'Great job! Enjoy your semester break 🎉',
        timeInfo: 'COMPLETED',
        isLive: false,
        subject: '$examLabel Period Concluded',
        room: 'Campus in Recess',
        startTime: '',
      );
    }

    final subject = targetExam['subject'] as String;
    final room = targetExam['room'] as String;
    final timeStr = targetExam['time'] as String;
    final dateStr = targetExam['date'] as String;
    final parsedDt = targetExam['dateTime'] as DateTime?;

    String countdownText = 'UPCOMING';
    if (parsedDt != null) {
      final isToday = parsedDt.year == now.year && parsedDt.month == now.month && parsedDt.day == now.day;
      if (isToday) {
        countdownText = timeStr.isNotEmpty ? 'TODAY • $timeStr' : 'TODAY';
      } else {
        const monthNames = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        final monthStr = monthNames[parsedDt.month];
        countdownText = timeStr.isNotEmpty ? '$monthStr ${parsedDt.day} • $timeStr' : '$monthStr ${parsedDt.day}';
      }
    } else if (dateStr.isNotEmpty && timeStr.isNotEmpty) {
      countdownText = '$dateStr • $timeStr';
    } else if (dateStr.isNotEmpty) {
      countdownText = dateStr;
    } else if (timeStr.isNotEmpty) {
      countdownText = 'AT $timeStr';
    }

    return TemporalInsight(
      headline: 'Next $examLabel',
      subline: 'Venue: $room',
      timeInfo: countdownText,
      isLive: false,
      subject: subject,
      room: room,
      startTime: timeStr,
    );
  }

  /// Builds intelligent temporal insight for Vacation / Semester Break mode
  TemporalInsight buildVacationTemporalInsight(String batch, DateTime now) {
    int daysLeft = -1;
    final vacMap = RemoteConfigService.vacationSchedule.value;
    if (vacMap != null) {
      final rStr = vacMap['resumption_date']?.toString();
      if (rStr != null && rStr.isNotEmpty) {
        final dt = DateTime.tryParse(rStr);
        if (dt != null) {
          daysLeft = DateTime(dt.year, dt.month, dt.day)
              .difference(DateTime(now.year, now.month, now.day))
              .inDays;
        }
      }
    }

    String countdownText;
    if (daysLeft > 1) {
      countdownText = '$daysLeft DAYS LEFT';
    } else if (daysLeft == 1) {
      countdownText = '1 DAY LEFT';
    } else if (daysLeft == 0) {
      countdownText = 'RESUMES TODAY';
    } else if (daysLeft < 0 && daysLeft != -1) {
      countdownText = 'CLASSES RESUMED';
    } else {
      countdownText = 'RECESS';
    }

    return TemporalInsight(
      headline: 'Vacation Mode',
      subline: 'Campus in Recess • Lectures Suspended',
      timeInfo: countdownText,
      isLive: false,
      subject: 'Semester Break',
      room: 'Campus in Recess',
      startTime: '',
    );
  }

  TemporalInsight buildTeacherTemporalInsight(String teacherName, DateTime now) {
    _ensureCachesValid();
    final cleanT = HelpdeskFacultyService.stripDepartmentPrefix(teacherName).trim().toLowerCase();
    final mKey = minuteTimestamp(now);
    final cached = _teacherTemporalInsightCache[cleanT];
    if (cached != null && cached.minute == mKey) {
      return cached.insight;
    }

    final result = _computeTeacherTemporalInsight(cleanT, now);
    _teacherTemporalInsightCache[cleanT] = (minute: mKey, insight: result);
    return result;
  }

  TemporalInsight _computeTeacherTemporalInsight(String teacherName, DateTime now) {
    final current = getCurrentClassForTeacher(teacherName, now);
    final next = getNextClassForTeacher(teacherName, now);
    final currentT = now.hour + (now.minute / 60.0);
    final schedule = scheduleForTeacher(teacherName);
    final today = schedule
        .where((s) {
          if (s.specificDate != null) {
            final isSameDate = s.specificDate!.year == now.year &&
                s.specificDate!.month == now.month &&
                s.specificDate!.day == now.day;
            if (!isSameDate) return false;
          }
          return s.dayIndex == now.weekday;
        })
        .toList()
      ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));

    final period = RemoteConfigService.activeAcademicPeriod.value;
    final isExam = period == 'midterms' || period == 'finals';

    if (current != null) {
      final actualEndTime = _getActualEndTime(current);
      final minutesLeft = ((actualEndTime - currentT) * 60).round();
      final timeLeft = minutesLeft > 60
          ? '${(minutesLeft / 60).floor()}h ${minutesLeft % 60}m left'
          : '$minutesLeft mins left';

      final headlineText = isExam
          ? 'Invigilating Now'
          : (period == 'sports_week' ? 'Gala Event Duty' : 'Teaching Now');
      final roomPrefix = isExam ? 'Supervision Hall: ' : '';

      return TemporalInsight(
        headline: headlineText,
        subline: '${current.subject} · $roomPrefix${current.room}',
        timeInfo: timeLeft,
        teacherInfo: teacherName,
        isLive: true,
        isUrgent: false,
      );
    }

    if (today.isNotEmpty) {
      final hasCompletedClass = today.any((s) => _getActualEndTime(s) <= currentT);
      final upcoming = today.firstWhere(
        (s) => s.safeStartVal > currentT,
        orElse: () => today.first,
      );
      if (hasCompletedClass && upcoming.safeStartVal > currentT) {
        final mergedUpcoming = getMergedSession(upcoming, schedule);
        final breakMinutes = ((mergedUpcoming.safeStartVal - currentT) * 60).round();
        final breakDuration = breakMinutes > 60
            ? '${(breakMinutes / 60).floor()}h ${breakMinutes % 60}m break'
            : '$breakMinutes min break';

        return TemporalInsight(
          headline: 'Break',
          subline: '${mergedUpcoming.subject} at ${mergedUpcoming.startTime} · ${mergedUpcoming.room}',
          timeInfo: breakDuration,
          teacherInfo: teacherName,
          isLive: false,
        );
      }
    }

    if (next != null) {
      final dayDiff = (next.dayIndex - now.weekday) % 7;
      final label = dayDiff == 0 ? 'Next Up' : 'Next Day';
      final isStartingSoon = dayDiff == 0 &&
          now.hour + (now.minute / 60.0) >= (next.safeStartVal - 0.084);

      String timeInfo = '';
      if (dayDiff == 0) {
        final nextMinutes = ((next.safeStartVal - now.hour - (now.minute / 60.0)) * 60).round();
        if (nextMinutes > 0) {
          timeInfo = nextMinutes > 60
              ? 'in ${(nextMinutes / 60).floor()}h ${nextMinutes % 60}m'
              : 'in $nextMinutes mins';
        }
      } else if (dayDiff > 0) {
        final daysUntil = dayDiff == 1 ? 1 : dayDiff;
        final hoursUntilMidnight = 24 - now.hour;
        final minutesUntilMidnight = 60 - now.minute;
        final totalMinutesUntilMidnight = (hoursUntilMidnight * 60) + minutesUntilMidnight - 60;
        final classStartMinutes = (next.safeStartVal * 60).round();
        final totalMinutes = totalMinutesUntilMidnight + classStartMinutes + ((daysUntil - 1) * 24 * 60);
        final hours = totalMinutes ~/ 60;
        final mins = totalMinutes % 60;
        if (hours > 24) {
          final days = hours ~/ 24;
          final remainingHours = hours % 24;
          timeInfo = remainingHours > 0
              ? 'in ${days}d ${remainingHours}h'
              : 'in ${days}d';
        } else if (hours > 0) {
          timeInfo = mins > 0 ? 'in ${hours}h ${mins}m' : 'in ${hours}h';
        } else {
          timeInfo = 'in ${mins}m';
        }
      }

      return TemporalInsight(
        headline: label,
        subline: '${next.subject} at ${next.startTime} · ${next.room}',
        timeInfo: timeInfo,
        teacherInfo: teacherName,
        isLive: false,
        isUrgent: isStartingSoon,
      );
    }

    return TemporalInsight(
      headline: 'No Classes',
      subline: 'No schedule for $teacherName',
      isLive: false,
    );
  }

  /// Get actual operating hours from timetable (earliest start and latest end)
  /// Returns a map of dayIndex -> (minTime, maxTime)
  Map<int, (double, double)> _getOperatingHours() {
    if (_cachedOperatingHours != null) return _cachedOperatingHours!;
    final operatingHours = <int, (double, double)>{};
    
    for (final session in memory.activeSessions()) {
      final day = session.dayIndex;
      final start = session.safeStartVal;
      final end = session.safeEndVal;
      
      if (operatingHours.containsKey(day)) {
        final current = operatingHours[day]!;
        operatingHours[day] = (
          start < current.$1 ? start : current.$1,  // min
          end > current.$2 ? end : current.$2,      // max
        );
      } else {
        operatingHours[day] = (start, end);
      }
    }
    _cachedOperatingHours = operatingHours;
    return operatingHours;
  }

  /// Merges overlapping and consecutive busy intervals into disjoint blocks
  List<(double, double)> _mergeIntervals(List<(double, double)> intervals) {
    if (intervals.isEmpty) return const [];
    final sorted = List<(double, double)>.from(intervals)
      ..sort((a, b) => a.$1.compareTo(b.$1));
    final merged = <(double, double)>[sorted.first];
    for (int i = 1; i < sorted.length; i++) {
      final cur = sorted[i];
      final last = merged.last;
      if (cur.$1 <= last.$2) {
        merged[merged.length - 1] = (last.$1, math.max(last.$2, cur.$2));
      } else {
        merged.add(cur);
      }
    }
    return merged;
  }

  /// Calculates mathematically exact, conflict-free free intervals for a given session list
  List<FreeSlot> _computeFreeSlotsForSessions(List<ClassSession> schedule) {
    if (schedule.isEmpty) return const [];

    final freeSlots = <FreeSlot>[];
    final daySlots = <int, List<ClassSession>>{};
    final operatingHours = _getOperatingHours();

    for (final session in schedule) {
      daySlots.putIfAbsent(session.dayIndex, () => []).add(session);
    }

    for (int dayIndex = 1; dayIndex <= 7; dayIndex++) {
      if (!operatingHours.containsKey(dayIndex)) continue;

      final (dayStart, dayEnd) = operatingHours[dayIndex]!;
      final daySessions = daySlots[dayIndex] ?? const [];

      if (daySessions.isEmpty) {
        freeSlots.add(FreeSlot(
          dayIndex: dayIndex,
          startTime: dayStart,
          endTime: dayEnd,
        ));
        continue;
      }

      final busyIntervals = daySessions
          .map((s) => (s.safeStartVal, s.safeEndVal))
          .toList();
      final mergedBusy = _mergeIntervals(busyIntervals);

      double current = dayStart;
      for (final busy in mergedBusy) {
        final bStart = math.max(dayStart, busy.$1);
        final bEnd = math.min(dayEnd, busy.$2);
        if (bStart > current) {
          freeSlots.add(FreeSlot(
            dayIndex: dayIndex,
            startTime: current,
            endTime: bStart,
          ));
        }
        if (bEnd > current) {
          current = bEnd;
        }
      }

      if (current < dayEnd) {
        freeSlots.add(FreeSlot(
          dayIndex: dayIndex,
          startTime: current,
          endTime: dayEnd,
        ));
      }
    }

    return freeSlots;
  }

  /// Find free slots for a batch across a week (O(1) memoized)
  /// Returns list of {day, start_time, end_time} when the batch has no classes
  List<FreeSlot> findFreeSlotsForBatch(String batch) {
    _ensureCachesValid();
    final cached = _freeSlotsBatchCache[batch];
    if (cached != null) return cached;

    final schedule = scheduleFor(batch);
    final result = _computeFreeSlotsForSessions(schedule);
    _freeSlotsBatchCache[batch] = result;
    return result;
  }

  /// Find free slots for a teacher across a week (O(1) memoized)
  List<FreeSlot> findFreeSlotsForTeacher(String teacherName) {
    _ensureCachesValid();
    final cleanT = HelpdeskFacultyService.stripDepartmentPrefix(teacherName).trim().toLowerCase();
    final cached = _freeSlotsTeacherCache[cleanT];
    if (cached != null) return cached;

    final schedule = scheduleForTeacher(teacherName);
    final result = _computeFreeSlotsForSessions(schedule);
    _freeSlotsTeacherCache[cleanT] = result;
    return result;
  }

  /// Fast memoized day schedule for batch (O(1) lookup after initial calculation)
  List<ClassSession> getMergedDaySchedule(String batch, int dayIndex, {String? overridePeriod}) {
    _ensureCachesValid();
    final periodKey = overridePeriod ?? 'default';
    final cacheKey = '$batch|$periodKey';

    var dayMap = _mergedDayScheduleCache[cacheKey];
    if (dayMap == null) {
      dayMap = {};
      _mergedDayScheduleCache[cacheKey] = dayMap;
    }

    final cachedDay = dayMap[dayIndex];
    if (cachedDay != null) return cachedDay;

    final all = scheduleFor(batch, overridePeriod: overridePeriod);
    final daySessions = all.where((s) => s.dayIndex == dayIndex).toList()
      ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));
    final merged = getMergedConsecutiveSessions(daySessions);
    dayMap[dayIndex] = merged;
    return merged;
  }

  /// Fast memoized suggested schedule for batch (O(1) lookup during frame render)
  List<ClassSession> getSuggestedSchedule(String batch, DateTime now, {String? overridePeriod}) {
    _ensureCachesValid();
    final mKey = minuteTimestamp(now);
    final periodKey = overridePeriod ?? 'default';
    final cacheKey = '$batch|$periodKey';

    final cached = _suggestedScheduleCache[cacheKey];
    if (cached != null && cached.minute == mKey) {
      return cached.schedule;
    }

    final todaySchedule = getMergedDaySchedule(batch, now.weekday, overridePeriod: overridePeriod);
    final List<ClassSession> result = todaySchedule.isNotEmpty
        ? todaySchedule
        : _nextDaySuggestedSchedule(batch, now.weekday, overridePeriod: overridePeriod);

    _suggestedScheduleCache[cacheKey] = (minute: mKey, schedule: result);
    return result;
  }

  List<ClassSession> _nextDaySuggestedSchedule(String batch, int todayIndex, {String? overridePeriod}) {
    for (int offset = 1; offset <= 6; offset++) {
      final nextDay = ((todayIndex + offset - 1) % 7) + 1;
      final daySchedule = getMergedDaySchedule(batch, nextDay, overridePeriod: overridePeriod);
      if (daySchedule.isNotEmpty) return daySchedule;
    }
    return const [];
  }

  /// Fast memoized day schedule for teacher (O(1) lookup after initial calculation)
  List<ClassSession> getMergedDayScheduleForTeacher(
    String teacherName,
    int dayIndex, {
    String? overridePeriod,
    String? department,
  }) {
    _ensureCachesValid();
    final cleanT = HelpdeskFacultyService.stripDepartmentPrefix(teacherName).trim().toLowerCase();
    final cacheKey = '$cleanT|${overridePeriod ?? ""}';

    var dayMap = _teacherMergedDayScheduleCache[cacheKey];
    if (dayMap == null) {
      dayMap = {};
      _teacherMergedDayScheduleCache[cacheKey] = dayMap;
    }

    final cachedDay = dayMap[dayIndex];
    if (cachedDay != null) return cachedDay;

    final all = scheduleForTeacher(teacherName, overridePeriod: overridePeriod, department: department);
    final daySessions = all.where((s) => s.dayIndex == dayIndex).toList()
      ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));
    final merged = getMergedConsecutiveSessions(daySessions);
    dayMap[dayIndex] = merged;
    return merged;
  }

  /// Fast memoized suggested schedule for teacher (O(1) lookup during frame render)
  List<ClassSession> getSuggestedScheduleForTeacher(
    String teacherName,
    DateTime now, {
    String? overridePeriod,
    String? department,
  }) {
    _ensureCachesValid();
    final cleanT = HelpdeskFacultyService.stripDepartmentPrefix(teacherName).trim().toLowerCase();
    final mKey = minuteTimestamp(now);
    final cacheKey = '$cleanT|${overridePeriod ?? ""}';

    final cached = _teacherSuggestedScheduleCache[cacheKey];
    if (cached != null && cached.minute == mKey) {
      return cached.schedule;
    }

    final todaySchedule = getMergedDayScheduleForTeacher(
      teacherName,
      now.weekday,
      overridePeriod: overridePeriod,
      department: department,
    );

    final List<ClassSession> result = todaySchedule.isNotEmpty
        ? todaySchedule
        : _nextDaySuggestedScheduleForTeacher(
            teacherName,
            now.weekday,
            overridePeriod: overridePeriod,
            department: department,
          );

    _teacherSuggestedScheduleCache[cacheKey] = (minute: mKey, schedule: result);
    return result;
  }

  List<ClassSession> _nextDaySuggestedScheduleForTeacher(
    String teacherName,
    int todayIndex, {
    String? overridePeriod,
    String? department,
  }) {
    for (int offset = 1; offset <= 6; offset++) {
      final nextDay = ((todayIndex + offset - 1) % 7) + 1;
      final daySchedule = getMergedDayScheduleForTeacher(
        teacherName,
        nextDay,
        overridePeriod: overridePeriod,
        department: department,
      );
      if (daySchedule.isNotEmpty) return daySchedule;
    }
    return const [];
  }

  /// Fast memoized weekly hours per day for teacher (O(1) lookup in day selector tabs)
  Map<int, double> getWeeklyDayHoursForTeacher(
    String teacherName, {
    String? overridePeriod,
    String? department,
  }) {
    _ensureCachesValid();
    final cleanT = HelpdeskFacultyService.stripDepartmentPrefix(teacherName).trim().toLowerCase();
    final cacheKey = '$cleanT|${overridePeriod ?? ""}|${department ?? ""}';
    final cached = _teacherDayHoursCache[cacheKey];
    if (cached != null) return cached;

    final hoursMap = <int, double>{};
    for (int d = 1; d <= 7; d++) {
      final sessions = getMergedDayScheduleForTeacher(
        teacherName,
        d,
        overridePeriod: overridePeriod,
        department: department,
      );
      double total = 0.0;
      for (final s in sessions) {
        total += (s.safeEndVal - s.safeStartVal).abs();
      }
      hoursMap[d] = total;
    }

    _teacherDayHoursCache[cacheKey] = hoursMap;
    return hoursMap;
  }

  static const List<({String name, double startTime, double endTime, double durationHours})> _officialStandardSlots = [
    // Standard 85-minute university lecture slots (CS/SE/EE/BBA/Civil standard grid)
    (name: 'Slot 1 (08:30 - 09:55 AM)', startTime: 8.5, endTime: 9.9167, durationHours: 1.417),
    (name: 'Slot 2 (09:55 - 11:20 AM)', startTime: 9.9167, endTime: 11.3333, durationHours: 1.417),
    (name: 'Slot 3 (11:20 AM - 12:45 PM)', startTime: 11.3333, endTime: 12.75, durationHours: 1.417),
    (name: 'Slot 4 (01:40 - 03:05 PM)', startTime: 13.6667, endTime: 15.0833, durationHours: 1.417),
    (name: 'Slot 5 (03:05 - 04:30 PM)', startTime: 15.0833, endTime: 16.5, durationHours: 1.417),
    
    // Official 1-Hour cut-off lecture slots (strictly aligned with official slot starts)
    (name: 'Slot 1 Cut-off (08:30 - 09:30 AM)', startTime: 8.5, endTime: 9.5, durationHours: 1.0),
    (name: 'Slot 2 Cut-off (09:55 - 10:55 AM)', startTime: 9.9167, endTime: 10.9167, durationHours: 1.0),
    (name: 'Slot 3 Cut-off (11:20 AM - 12:20 PM)', startTime: 11.3333, endTime: 12.3333, durationHours: 1.0),
    (name: 'Slot 4 Cut-off (01:40 - 02:40 PM)', startTime: 13.6667, endTime: 14.6667, durationHours: 1.0),
    (name: 'Slot 5 Cut-off (03:05 - 04:05 PM)', startTime: 15.0833, endTime: 16.0833, durationHours: 1.0),

    // Official Double Lab Slots (170-minute practical lab sessions)
    (name: 'Morning Lab (08:30 - 11:20 AM)', startTime: 8.5, endTime: 11.3333, durationHours: 2.833),
    (name: 'Midday Lab (09:55 AM - 12:45 PM)', startTime: 9.9167, endTime: 12.75, durationHours: 2.833),
    (name: 'Afternoon Lab (01:40 - 04:30 PM)', startTime: 13.6667, endTime: 16.5, durationHours: 2.833),

    // Friday 2-Hour block (before Jummah prayer)
    (name: 'Friday Slot 3 (11:20 AM - 01:20 PM)', startTime: 11.3333, endTime: 13.3333, durationHours: 2.0),
  ];

  static const List<({String name, double startTime, double endTime, double durationHours})> _ramadanAcademicSlots = [
    (name: 'Ramadan Slot 1 (08:30 - 09:30 AM)', startTime: 8.5, endTime: 9.5, durationHours: 1.0),
    (name: 'Ramadan Slot 2 (09:30 - 10:30 AM)', startTime: 9.5, endTime: 10.5, durationHours: 1.0),
    (name: 'Ramadan Slot 3 (10:30 - 11:30 AM)', startTime: 10.5, endTime: 11.5, durationHours: 1.0),
    (name: 'Ramadan Slot 4 (11:30 AM - 12:30 PM)', startTime: 11.5, endTime: 12.5, durationHours: 1.0),
    (name: 'Ramadan Slot 5 (12:30 - 01:30 PM)', startTime: 12.5, endTime: 13.5, durationHours: 1.0),
    (name: 'Ramadan Slot 6 (01:30 - 02:30 PM)', startTime: 13.5, endTime: 14.5, durationHours: 1.0),
  ];

  /// Find authentic, standard university makeup slots where BOTH batch and teacher are free,
  /// with verified available physical rooms on campus.
  List<MakeupSlotSuggestion> findMakeupSlots(String batch, String teacherName) {
    final batchSessions = scheduleFor(batch);
    final teacherSessions = scheduleForTeacher(teacherName);

    if (batchSessions.isEmpty && teacherSessions.isEmpty) return [];

    final suggestions = <MakeupSlotSuggestion>[];
    final isRamadan = RemoteConfigService.activeAcademicPeriod.value == 'ramadan';
    final candidateSlots = isRamadan ? _ramadanAcademicSlots : _officialStandardSlots;

    for (int dayIndex = 1; dayIndex <= 5; dayIndex++) {
      final dayBatchSessions = batchSessions.where((s) => s.dayIndex == dayIndex).toList();
      final dayTeacherSessions = teacherSessions.where((s) => s.dayIndex == dayIndex).toList();

      for (final slot in candidateSlots) {
        // Skip Friday-specific slots on Mon-Thu
        if (slot.name.startsWith('Friday') && dayIndex != 5) continue;
        final slotStart = slot.startTime;
        final slotEnd = slot.endTime;

        // 1. Strict Batch Conflict check (with 2-minute margin of tolerance)
        final batchHasConflict = dayBatchSessions.any((s) =>
            s.safeStartVal < (slotEnd - 0.03) && s.safeEndVal > (slotStart + 0.03));
        if (batchHasConflict) continue;

        // 2. Strict Teacher Conflict check (with 2-minute margin)
        final teacherHasConflict = dayTeacherSessions.any((s) =>
            s.safeStartVal < (slotEnd - 0.03) && s.safeEndVal > (slotStart + 0.03));
        if (teacherHasConflict) continue;

        // 3. Physical Room Availability Check
        final availableRooms = findEmptyRoomsForSlot(dayIndex, slotStart, slotEnd);
        if (availableRooms.isEmpty) continue;

        suggestions.add(MakeupSlotSuggestion(
          dayIndex: dayIndex,
          startTime: slotStart,
          endTime: slotEnd,
          durationHours: slot.durationHours,
          slotName: slot.name,
          availableRooms: availableRooms,
        ));
      }
    }

    return suggestions;
  }

  GpaPlannerResult calculateRequiredSemesterGpa({
    required double currentCgpa,
    required double targetCgpa,
    required int completedCredits,
    required int semesterCredits,
  }) {
    if (semesterCredits <= 0) {
      return const GpaPlannerResult(
        requiredSemesterGpa: 0.0,
        maxPossibleCgpa: 0.0,
        difficulty: 'moderate',
        message: 'No active courses detected to perform calculation.',
      );
    }

    final totalCredits = completedCredits + semesterCredits;
    final requiredGpa = ((targetCgpa * totalCredits) - (currentCgpa * completedCredits)) / semesterCredits;
    final maxCgpa = ((currentCgpa * completedCredits) + (4.0 * semesterCredits)) / totalCredits;

    if (requiredGpa <= 2.0) {
      return GpaPlannerResult(
        requiredSemesterGpa: requiredGpa.clamp(0.0, 4.0),
        maxPossibleCgpa: maxCgpa,
        difficulty: 'easy',
        message: 'Comfortable target! You need an average GPA of ${requiredGpa.clamp(0.0, 4.0).toStringAsFixed(2)} to hit your target.',
      );
    } else if (requiredGpa > 4.00) {
      return GpaPlannerResult(
        requiredSemesterGpa: requiredGpa,
        maxPossibleCgpa: maxCgpa,
        difficulty: 'impossible',
        message: 'Target out of reach this semester. The highest CGPA you can achieve is ${maxCgpa.toStringAsFixed(2)} (with a perfect 4.00 GPA).',
      );
    } else {
      final difficulty = requiredGpa > 3.5 ? 'challenging' : 'moderate';
      final status = requiredGpa > 3.5 ? 'Challenging' : 'Achievable';
      return GpaPlannerResult(
        requiredSemesterGpa: requiredGpa,
        maxPossibleCgpa: maxCgpa,
        difficulty: difficulty,
        message: '$status target! You need a GPA of ${requiredGpa.toStringAsFixed(2)} in your current courses.',
      );
    }
  }
}

class GpaPlannerResult {
  final double requiredSemesterGpa;
  final double maxPossibleCgpa;
  final String difficulty; // 'easy', 'moderate', 'challenging', 'impossible'
  final String message;

  const GpaPlannerResult({
    required this.requiredSemesterGpa,
    required this.maxPossibleCgpa,
    required this.difficulty,
    required this.message,
  });
}
