import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Design tokens, brutalist 3D extruded drop-block shadows, and monolithic typography
/// for the Poster / Swiss Brutalism Theme (Modeled after Poster · Light.png & Poster · Dark.png).
class PosterTokens {
  // --- Canvas & Surfaces ---
  static Color canvas(bool isDark) =>
      isDark ? const Color(0xFF0A0C0E) : const Color(0xFFEBE8E1);

  static Color cardSurface(bool isDark) =>
      isDark ? const Color(0xFF14181E) : Colors.white;

  // --- Signature International Orange Hero Accent ---
  static const Color orangeHero = Color(0xFFFF451A);

  // --- High-Contrast Borders & Rules ---
  static Color inkBorder(bool isDark) =>
      isDark ? const Color(0xFFF4F6F8) : const Color(0xFF000000);

  static Color inkBorderSubtle(bool isDark) =>
      isDark ? const Color(0xFF384252) : const Color(0xFF9E9B95);

  // --- Typography Inks ---
  static Color inkHeading(bool isDark) =>
      isDark ? const Color(0xFFFFFFFF) : const Color(0xFF000000);

  static Color inkBody(bool isDark) =>
      isDark ? const Color(0xFFD1D5DB) : const Color(0xFF111111);

  static Color inkMuted(bool isDark) =>
      isDark ? const Color(0xFF8D9CAE) : const Color(0xFF555555);

  // --- Bottom Navigation Colors ---
  static Color navBarBackground(bool isDark) =>
      isDark ? const Color(0xFF0A0C0E) : const Color(0xFFEBE8E1);

  static Color navActiveBlock(bool isDark) => orangeHero;

  static Color navActiveText(bool isDark) => Colors.black;

  static Color navInactiveText(bool isDark) =>
      isDark ? const Color(0xFFE5E7EB) : const Color(0xFF000000);

  // --- Monolithic Swiss Typography ---
  static TextStyle heroMonolithicClock(bool isDark) {
    return GoogleFonts.archivoBlack(
      fontSize: 110,
      fontWeight: FontWeight.w900,
      letterSpacing: -5.0,
      height: 0.88,
      color: Colors.black,
    );
  }

  static TextStyle heroOrangeTag(bool isDark) {
    return GoogleFonts.spaceMono(
      fontSize: 12,
      fontWeight: FontWeight.w700,
      letterSpacing: 1.2,
      color: Colors.black,
    );
  }

  static TextStyle heroOrangeTitle(bool isDark) {
    return GoogleFonts.archivoBlack(
      fontSize: 24,
      fontWeight: FontWeight.w900,
      letterSpacing: -0.6,
      height: 1.05,
      color: Colors.black,
    );
  }

  static TextStyle classIndexNumber(bool isDark) {
    return GoogleFonts.archivoBlack(
      fontSize: 56,
      fontWeight: FontWeight.w900,
      letterSpacing: -2.0,
      height: 0.95,
      color: inkHeading(isDark),
    );
  }

  static TextStyle classTitle(bool isDark) {
    return GoogleFonts.archivoBlack(
      fontSize: 17,
      fontWeight: FontWeight.w900,
      letterSpacing: -0.4,
      height: 1.1,
      color: inkHeading(isDark),
    );
  }

  // --- Brutalist 3D Extruded Block Shadow ---
  static List<BoxShadow> extrudedBlockShadow(
    bool isDark, {
    double offset = 5.0,
    Color? color,
  }) {
    return [
      BoxShadow(
        offset: Offset(offset, offset),
        color: color ?? (isDark ? Colors.black : const Color(0xFF000000)),
        blurRadius: 0, // Hard 3D crisp edge
        spreadRadius: 0,
      ),
    ];
  }
}
