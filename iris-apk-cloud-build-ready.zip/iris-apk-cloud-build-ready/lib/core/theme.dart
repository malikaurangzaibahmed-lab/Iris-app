import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'tokens.dart';
import 'theme_signals.dart';
import 'almanac_theme_tokens.dart';
import 'editorial_theme_tokens.dart';
import 'notebook_theme_tokens.dart';
import 'line_theme_tokens.dart';
import 'poster_theme_tokens.dart';
import 'material_you_theme.dart';
import 'minimal_theme.dart';
import 'vital_theme.dart';

class IrisTheme {
  /// Builds an authentic, signature ThemeData for any of the 7 IRIS themes!
  /// Ensures that every screen, dialog, chip, button, and text widget across
  /// the entire application automatically inherits the active theme's exact
  /// canvas, surface, color scheme, border geometry, and Google Fonts typography.
  static ThemeData buildForStyle({
    required IrisThemeStyle style,
    required Brightness brightness,
    Color seedColor = const Color(0xFF0061A4),
    bool useMinimal = false,
    bool useVital = false,
  }) {
    final isDark = brightness == Brightness.dark;

    switch (style) {
      case IrisThemeStyle.materialYou:
        return MaterialYouTheme.buildTheme(
          brightness: brightness,
          seedColor: seedColor,
        );

      case IrisThemeStyle.almanac:
        final canvas = AlmanacTokens.canvas(isDark);
        final surface = AlmanacTokens.cardSurface(isDark);
        final primary = AlmanacTokens.accentTerracotta(isDark);
        final inkHeading = AlmanacTokens.inkHeading(isDark);
        final inkBody = AlmanacTokens.inkBody(isDark);
        final inkRule = AlmanacTokens.inkRule(isDark);
        final baseText = ThemeData(brightness: brightness).textTheme;
        return ThemeData(
          useMaterial3: true,
          brightness: brightness,
          scaffoldBackgroundColor: canvas,
          colorScheme: ColorScheme.fromSeed(
            seedColor: primary,
            brightness: brightness,
            primary: primary,
            onPrimary: Colors.white,
            secondary: const Color(0xFF4A6B5B),
            surface: surface,
            onSurface: inkHeading,
            onSurfaceVariant: AlmanacTokens.inkMuted(isDark),
            outline: inkRule,
            outlineVariant: AlmanacTokens.inkRuleSubtle(isDark),
          ),
          fontFamily: GoogleFonts.playfairDisplay().fontFamily,
          textTheme: GoogleFonts.playfairDisplayTextTheme(baseText).apply(
            bodyColor: inkBody,
            displayColor: inkHeading,
          ),
          dividerTheme: DividerThemeData(color: inkRule, thickness: 1.0),
          cardTheme: CardThemeData(
            elevation: 0,
            color: surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.zero,
              side: BorderSide(color: inkRule, width: 1.0),
            ),
          ),
          appBarTheme: AppBarTheme(
            elevation: 0,
            scrolledUnderElevation: 0,
            backgroundColor: canvas,
            foregroundColor: inkHeading,
            titleTextStyle: AlmanacTokens.serifHeadline(isDark, fontSize: 19),
          ),
        );

      case IrisThemeStyle.editorialAcademic:
        final canvas = EditorialTokens.canvas(isDark);
        final surface = EditorialTokens.cardSurface(isDark);
        final primary = EditorialTokens.accentUpcoming;
        final inkHeading = EditorialTokens.inkHeading(isDark);
        final inkBody = EditorialTokens.inkBody(isDark);
        final border = EditorialTokens.cardBorder(isDark);
        final baseText = ThemeData(brightness: brightness).textTheme;
        return ThemeData(
          useMaterial3: true,
          brightness: brightness,
          scaffoldBackgroundColor: canvas,
          colorScheme: ColorScheme.fromSeed(
            seedColor: primary,
            brightness: brightness,
            primary: primary,
            onPrimary: const Color(0xFF1E1B18),
            secondary: EditorialTokens.accentLab,
            tertiary: EditorialTokens.accentLive,
            surface: surface,
            onSurface: inkHeading,
            onSurfaceVariant: EditorialTokens.inkMuted(isDark),
            outline: border,
            outlineVariant: border.withValues(alpha: 0.65),
          ),
          fontFamily: GoogleFonts.plusJakartaSans().fontFamily,
          textTheme: GoogleFonts.plusJakartaSansTextTheme(baseText).apply(
            bodyColor: inkBody,
            displayColor: inkHeading,
          ),
          dividerTheme: DividerThemeData(color: border, thickness: 1.0),
          cardTheme: CardThemeData(
            elevation: 0,
            color: surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(22),
              side: BorderSide(color: border, width: 1.0),
            ),
          ),
          appBarTheme: AppBarTheme(
            elevation: 0,
            scrolledUnderElevation: 0,
            backgroundColor: canvas,
            foregroundColor: inkHeading,
            titleTextStyle: EditorialTokens.headingSerif(isDark, fontSize: 19),
          ),
        );

      case IrisThemeStyle.notebook:
        final canvas = NotebookTokens.canvas(isDark);
        final surface = NotebookTokens.cardSurface(isDark);
        final primary = NotebookTokens.redDoodle(isDark);
        final inkHeading = NotebookTokens.inkHeading(isDark);
        final inkBody = NotebookTokens.inkBody(isDark);
        final gridBorder = NotebookTokens.gridLine(isDark);
        final baseText = ThemeData(brightness: brightness).textTheme;
        return ThemeData(
          useMaterial3: true,
          brightness: brightness,
          scaffoldBackgroundColor: canvas,
          colorScheme: ColorScheme.fromSeed(
            seedColor: primary,
            brightness: brightness,
            primary: primary,
            onPrimary: Colors.white,
            secondary: const Color(0xFF2563EB),
            tertiary: NotebookTokens.stickyNote(isDark),
            surface: surface,
            onSurface: inkHeading,
            onSurfaceVariant: NotebookTokens.inkMuted(isDark),
            outline: gridBorder,
            outlineVariant: gridBorder,
          ),
          fontFamily: GoogleFonts.patrickHand().fontFamily,
          textTheme: GoogleFonts.patrickHandTextTheme(baseText).apply(
            bodyColor: inkBody,
            displayColor: inkHeading,
          ),
          dividerTheme: DividerThemeData(color: gridBorder, thickness: 1.0),
          cardTheme: CardThemeData(
            elevation: 0,
            color: surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
              side: BorderSide(color: gridBorder, width: 1.1),
            ),
          ),
          appBarTheme: AppBarTheme(
            elevation: 0,
            scrolledUnderElevation: 0,
            backgroundColor: canvas,
            foregroundColor: inkHeading,
            titleTextStyle: NotebookTokens.boldScript(isDark, fontSize: 20),
          ),
        );

      case IrisThemeStyle.line:
        final canvas = LineTokens.canvas(isDark);
        final surface = LineTokens.cardSurface(isDark);
        final primary = LineTokens.railLine(isDark);
        final inkHeading = LineTokens.inkHeading(isDark);
        final inkBody = LineTokens.inkBody(isDark);
        final baseText = ThemeData(brightness: brightness).textTheme;
        return ThemeData(
          useMaterial3: true,
          brightness: brightness,
          scaffoldBackgroundColor: canvas,
          colorScheme: ColorScheme.fromSeed(
            seedColor: primary,
            brightness: brightness,
            primary: primary,
            onPrimary: isDark ? Colors.black : Colors.white,
            secondary: LineTokens.subwayCobalt,
            tertiary: LineTokens.subwayGreen,
            surface: surface,
            onSurface: inkHeading,
            onSurfaceVariant: LineTokens.inkMuted(isDark),
            outline: primary,
            outlineVariant: isDark ? const Color(0xFF28303C) : const Color(0xFFD6D1C4),
          ),
          fontFamily: GoogleFonts.plusJakartaSans().fontFamily,
          textTheme: GoogleFonts.plusJakartaSansTextTheme(baseText).apply(
            bodyColor: inkBody,
            displayColor: inkHeading,
          ),
          dividerTheme: DividerThemeData(color: primary.withValues(alpha: 0.35), thickness: 1.2),
          cardTheme: CardThemeData(
            elevation: 0,
            color: surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: primary, width: 1.4),
            ),
          ),
          appBarTheme: AppBarTheme(
            elevation: 0,
            scrolledUnderElevation: 0,
            backgroundColor: canvas,
            foregroundColor: inkHeading,
            titleTextStyle: LineTokens.stationName(isDark).copyWith(fontSize: 18),
          ),
        );

      case IrisThemeStyle.poster:
        final canvas = PosterTokens.canvas(isDark);
        final surface = PosterTokens.cardSurface(isDark);
        const primary = PosterTokens.orangeHero;
        final inkHeading = PosterTokens.inkHeading(isDark);
        final inkBody = PosterTokens.inkBody(isDark);
        final inkBorder = PosterTokens.inkBorder(isDark);
        final baseText = ThemeData(brightness: brightness).textTheme;
        return ThemeData(
          useMaterial3: true,
          brightness: brightness,
          scaffoldBackgroundColor: canvas,
          colorScheme: ColorScheme.fromSeed(
            seedColor: primary,
            brightness: brightness,
            primary: primary,
            onPrimary: Colors.black,
            secondary: inkHeading,
            surface: surface,
            onSurface: inkHeading,
            onSurfaceVariant: PosterTokens.inkMuted(isDark),
            outline: inkBorder,
            outlineVariant: PosterTokens.inkBorderSubtle(isDark),
          ),
          fontFamily: GoogleFonts.spaceMono().fontFamily,
          textTheme: GoogleFonts.spaceMonoTextTheme(baseText).apply(
            bodyColor: inkBody,
            displayColor: inkHeading,
          ),
          dividerTheme: DividerThemeData(color: inkBorder, thickness: 2.0),
          cardTheme: CardThemeData(
            elevation: 0,
            color: surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.zero,
              side: BorderSide(color: inkBorder, width: 2.2),
            ),
          ),
          appBarTheme: AppBarTheme(
            elevation: 0,
            scrolledUnderElevation: 0,
            backgroundColor: canvas,
            foregroundColor: inkHeading,
            titleTextStyle: PosterTokens.classTitle(isDark).copyWith(fontSize: 18),
          ),
        );

      case IrisThemeStyle.fluidGlass:
        if (useMinimal) {
          return buildMinimalTheme(brightness: brightness);
        }
        if (useVital) {
          return buildVitalTheme(brightness: brightness);
        }
        return _base(brightness);
    }
  }

  static ThemeData _base(Brightness brightness) {
    final isDark = brightness == Brightness.dark;
    final primaryColor = IrisTokens.brand;
    final baseTextTheme = ThemeData(brightness: brightness).textTheme;

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryColor,
        brightness: brightness,
        surface: isDark ? IrisTokens.surfaceDark : IrisTokens.surfaceLight,
      ),
      scaffoldBackgroundColor: isDark ? IrisTokens.surfaceDark : IrisTokens.surfaceLight,
      fontFamily: IrisTokens.fontFamily,
      textTheme: GoogleFonts.interTextTheme(baseTextTheme),
      pageTransitionsTheme: IrisTokens.pageTransitions,
      visualDensity: VisualDensity.adaptivePlatformDensity,
      cardTheme: CardThemeData(
        elevation: 0,
        shape: const ContinuousRectangleBorder(
          borderRadius: IrisTokens.cardRadius,
        ),
        color: isDark ? IrisTokens.surfaceDarkElevated : IrisTokens.surfaceLightElevated,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          elevation: 0,
          backgroundColor: primaryColor,
          foregroundColor: Colors.white,
          minimumSize: const Size(88, 48),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          textStyle: const TextStyle(
            fontWeight: FontWeight.w600,
            letterSpacing: 0.2,
          ),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          elevation: 0,
          backgroundColor: primaryColor,
          foregroundColor: Colors.white,
          minimumSize: const Size(88, 48),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(88, 48),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
        ),
      ),
      appBarTheme: AppBarTheme(
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        backgroundColor: Colors.transparent,
        foregroundColor: isDark ? Colors.white : Colors.black,
        titleTextStyle: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.5,
          color: isDark ? Colors.white : Colors.black,
        ),
      ),
    );
  }

  static ThemeData light() => _base(Brightness.light);
  static ThemeData dark() => _base(Brightness.dark);
}
