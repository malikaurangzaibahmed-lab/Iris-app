import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import '../../core/glass.dart';
import '../../core/theme_signals.dart';
import '../../core/tokens.dart';
import '../../core/models.dart';
import '../../core/omni_brain.dart';
import '../../widgets/iris_components.dart';
import 'package:iris/widgets/controls/glowing_input_wrapper.dart';
import 'package:iris/widgets/navigation/dashboard_dock.dart';
import '../../core/animations.dart';
import '../../services/ui_feedback.dart';
import '../../core/vital_theme.dart'; // For ObsidianPulse
import '../tools_screen.dart';
import '../portal_screen.dart';
import 'package:iris/screens/faculty/teacher_locator_screen.dart';
import 'package:iris/screens/settings/about_screen.dart';
import '../../services/remote_config_service.dart';
import 'package:iris/widgets/controls/iris_liquid_button.dart';
import 'package:iris/widgets/navigation/liquid_glass_sticky_header.dart';
import '../../widgets/department_classes/department_classes_widgets.dart';
import '../../widgets/glass_card.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';

class DepartmentClassesScreen extends StatefulWidget {
  final UniversityMemory memory;
  final String currentBatch;
  final String? teacherName;
  final OmniBrain? brain;
  final ValueChanged<String>? onRoleChanged;
  final ValueChanged<String>? onBatchChanged;
  final bool showDock;
  final bool showBackButton;
  final bool showBatchShortcut;
  final Future<void> Function(ClassSession session)? onAddMakeupClass;
  final Future<void> Function(ClassSession session)? onRemoveMakeupClass;

  const DepartmentClassesScreen({
    required this.memory,
    required this.currentBatch,
    this.teacherName,
    this.brain,
    this.onRoleChanged,
    this.onBatchChanged,
    this.showDock = false,
    this.showBackButton = true,
    this.showBatchShortcut = false,
    this.onAddMakeupClass,
    this.onRemoveMakeupClass,
    super.key,
  });

  @override
  State<DepartmentClassesScreen> createState() =>
      _DepartmentClassesScreenState();
}

class _DepartmentClassesScreenState extends State<DepartmentClassesScreen> {
  String? selectedProgram;
  int? selectedSemester;
  String? selectedSection;
  int? selectedDay;
  bool _showExamSchedule = false;
  final ScrollController _scrollController = ScrollController();
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  List<String> _teacherBatches = [];
  bool get _isFacultyMode =>
      widget.teacherName != null && widget.teacherName!.trim().isNotEmpty;

  static final RegExp _batchRegex = RegExp(r'^(FA|SP)\d{2}$');
  List<String>? _cachedValidPrograms;

  List<String> _getValidPrograms() {
    if (_cachedValidPrograms != null) return _cachedValidPrograms!;
    _cachedValidPrograms = widget.memory
        .programs()
        .where((p) => !_batchRegex.hasMatch(p))
        .toList();
    return _cachedValidPrograms!;
  }

  List<ClassSession> _cachedSelectionSessions = const [];
  String? _lastSessionSelectionKey;

  List<ClassSession> _computeSelectionSessions() {
    if (selectedProgram == null || selectedSemester == null || selectedSection == null) {
      return const [];
    }
    final key = '$selectedProgram-$selectedSemester$selectedSection|$_showExamSchedule';
    if (_lastSessionSelectionKey == key) {
      return _cachedSelectionSessions;
    }
    _lastSessionSelectionKey = key;
    final batchSessions = widget.memory
        .activeSessions(overridePeriod: _showExamSchedule ? null : 'classes')
        .where((s) =>
            s.batchKey.program == selectedProgram &&
            s.batchKey.semester == selectedSemester &&
            s.batchKey.section == selectedSection)
        .toList();
    _cachedSelectionSessions = batchSessions;
    return batchSessions;
  }

  List<ClassSession> _cachedDisplayedSessions = const [];
  String? _lastDisplayedKey;

  List<ClassSession> _getDisplayedSessions(List<ClassSession> allSessions) {
    final key = '${_lastSessionSelectionKey}_${selectedDay}_$_searchQuery';
    if (_lastDisplayedKey == key) {
      return _cachedDisplayedSessions;
    }
    _lastDisplayedKey = key;
    var list = allSessions;
    if (selectedDay != null) {
      list = allSessions.where((s) => s.dayIndex == selectedDay).toList();
    }
    if (_searchQuery.isNotEmpty) {
      final q = _searchQuery.toLowerCase();
      list = list.where((s) {
        final subject = s.subject.toLowerCase();
        final teacher = s.teacher.toLowerCase();
        final room = s.room.toLowerCase();
        final batch = s.batchKey.batch.toLowerCase();
        return subject.contains(q) ||
            teacher.contains(q) ||
            room.contains(q) ||
            batch.contains(q);
      }).toList();
    }
    final sorted = List<ClassSession>.from(list)
      ..sort((a, b) => a.dayIndex.compareTo(b.dayIndex));
    _cachedDisplayedSessions = sorted;
    return sorted;
  }

  @override
  void initState() {
    super.initState();
    if (_isFacultyMode) {
      final cleanT = widget.teacherName!.trim().toLowerCase();
      final batches = <String>{};
      for (final s in widget.memory.sessions) {
        if (s.teacher.trim().toLowerCase() == cleanT ||
            s.teacher.trim().toLowerCase().contains(cleanT)) {
          final b = s.batchKey.batch.trim();
          if (b.isNotEmpty) batches.add(b);
        }
      }
      _teacherBatches = batches.toList()..sort();
    }
    if ((widget.showBatchShortcut || _isFacultyMode) && widget.currentBatch.isNotEmpty) {
      _jumpToBatch(widget.currentBatch, showToast: false);
    } else if (_isFacultyMode && _teacherBatches.isNotEmpty) {
      _jumpToBatch(_teacherBatches.first, showToast: false);
    } else {
      // Filter out batch-like programs and select the first valid one
      final validPrograms = _getValidPrograms();
      if (validPrograms.isNotEmpty) {
        selectedProgram = validPrograms.first;
        final semesters = widget.memory.semesters(selectedProgram!);
        if (semesters.isNotEmpty) {
          selectedSemester = semesters.first;
          final sections = widget.memory.sections(
            selectedProgram!,
            selectedSemester!,
          );
          if (sections.isNotEmpty) {
            selectedSection = sections.first;
          }
        }
      }
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _jumpToBatch(String batch, {bool showToast = true}) {
    final key = BatchKey.parse(batch);
    final prog = key.program.toUpperCase();
    final sem = key.semester > 0 ? key.semester : key.dynamicSemester;
    final sec = key.section.toUpperCase();

    final validPrograms = _getValidPrograms();

    final matchedProgram = validPrograms.firstWhere(
      (p) =>
          p.toUpperCase() == prog ||
          p.toUpperCase().contains(prog) ||
          prog.contains(p.toUpperCase()),
      orElse: () => validPrograms.isNotEmpty ? validPrograms.first : '',
    );

    if (matchedProgram.isNotEmpty) {
      setState(() {
        selectedProgram = matchedProgram;
        final sems = widget.memory.semesters(matchedProgram);
        if (sems.contains(sem)) {
          selectedSemester = sem;
        } else if (sems.isNotEmpty) {
          selectedSemester = sems.first;
        }
        if (selectedSemester != null) {
          final secs = widget.memory.sections(
            matchedProgram,
            selectedSemester!,
          );
          if (sec.isNotEmpty && secs.contains(sec)) {
            selectedSection = sec;
          } else if (secs.isNotEmpty) {
            selectedSection = secs.first;
          }
        }
      });
      if (showToast) {
        IrisHaptics.actionMedium();
        showIrisFrostedSnackBar(
          context,
          dedupeKey: 'jump_to_batch',
          content: Text('Switched to $batch'),
        );
      }
    }
  }

  void _showTeacherBatchesSheet() {
    IrisHaptics.selectionClick();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    IrisModalSheet.show(
      context: context,
      builder: (ctx) {
        final currentBatchString = (selectedProgram != null &&
                selectedSemester != null &&
                selectedSection != null)
            ? '$selectedProgram-$selectedSemester$selectedSection'
            : null;
        return TeacherBatchesSheet(
          isDark: isDark,
          teacherBatches: _teacherBatches,
          currentBatchString: currentBatchString,
          onSelectBatch: _jumpToBatch,
        );
      },
    );
  }

  void _jumpToMyBatch() {
    if (_isFacultyMode && _teacherBatches.isNotEmpty) {
      if (_teacherBatches.length > 1) {
        _showTeacherBatchesSheet();
      } else {
        _jumpToBatch(_teacherBatches.first);
      }
      return;
    }
    final rawBatch = widget.currentBatch.trim();
    if (rawBatch.isEmpty) return;

    final key = BatchKey.parse(rawBatch);
    final prog = key.program.toUpperCase();
    final sem = key.semester > 0 ? key.semester : key.dynamicSemester;
    final sec = key.section.toUpperCase();

    final validPrograms = _getValidPrograms();

    final matchedProgram = validPrograms.firstWhere(
      (p) =>
          p.toUpperCase() == prog ||
          p.toUpperCase().contains(prog) ||
          prog.contains(p.toUpperCase()),
      orElse: () => validPrograms.isNotEmpty ? validPrograms.first : '',
    );

    if (matchedProgram.isNotEmpty) {
      setState(() {
        selectedProgram = matchedProgram;
        final sems = widget.memory.semesters(matchedProgram);
        if (sems.contains(sem)) {
          selectedSemester = sem;
        } else if (sems.isNotEmpty) {
          selectedSemester = sems.first;
        }
        if (selectedSemester != null) {
          final secs = widget.memory.sections(
            matchedProgram,
            selectedSemester!,
          );
          if (sec.isNotEmpty && secs.contains(sec)) {
            selectedSection = sec;
          } else if (secs.isNotEmpty) {
            selectedSection = secs.first;
          }
        }
      });
      IrisHaptics.actionMedium();
      showIrisFrostedSnackBar(
        context,
        dedupeKey: 'jump_to_my_batch',
        content: Text('Switched to My Batch ($rawBatch)'),
      );
    }
  }

  Future<void> _shareCurrentTimetableText(
    BuildContext context,
    List<ClassSession> sessions,
  ) async {
    IrisHaptics.actionMedium();
    final batchStr =
        (selectedProgram != null &&
            selectedSemester != null &&
            selectedSection != null)
        ? '$selectedProgram-$selectedSemester$selectedSection'
        : 'Department Schedule';

    final buffer = StringBuffer();
    buffer.writeln('📅 COMSATS University - Class Schedule');
    buffer.writeln('👥 Batch / Program: $batchStr');
    buffer.writeln('━━━━━━━━━━━━━━━━━━━━');

    if (sessions.isEmpty) {
      buffer.writeln('🎉 No scheduled classes listed.');
    } else {
      for (final s in sessions) {
        final timeStr = s.endTime.isNotEmpty
            ? '${s.startTime} - ${s.endTime}'
            : s.startTime;
        buffer.writeln('• $timeStr | ${s.subject}');
        final loc = s.room.isNotEmpty ? '📍 ${s.room}' : '';
        final prof = s.teacher.isNotEmpty ? '👤 ${s.teacher}' : '';
        if (loc.isNotEmpty || prof.isNotEmpty) {
          buffer.writeln(
            '  $loc ${loc.isNotEmpty && prof.isNotEmpty ? '| ' : ''}$prof',
          );
        }
      }
    }

    buffer.writeln('━━━━━━━━━━━━━━━━━━━━');
    buffer.writeln('📱 Shared via IRIS Campus Operating System');

    final text = buffer.toString();
    await Clipboard.setData(ClipboardData(text: text));

    try {
      final encoded = Uri.encodeComponent(text);
      final whatsappUri = Uri.parse('whatsapp://send?text=$encoded');
      if (await canLaunchUrl(whatsappUri)) {
        await launchUrl(whatsappUri);
      } else {
        if (context.mounted) {
          showIrisFrostedSnackBar(
            context,
            content: const Text(
              'Schedule copied to clipboard! Ready to paste & share.',
            ),
          );
        }
      }
    } catch (_) {
      if (context.mounted) {
        showIrisFrostedSnackBar(
          context,
          content: const Text(
            'Schedule copied to clipboard! Ready to paste & share.',
          ),
        );
      }
    }
  }


  Widget _buildGlassInputPill({
    required String title,
    required String value,
    required VoidCallback onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    return DepartmentFilterPill(
      title: title,
      value: value,
      onTap: onTap,
      isDark: isDark,
      isM3: isM3,
      cs: cs,
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final validPrograms = _getValidPrograms();

    // Compute the options based on current selections
    final semesters = selectedProgram != null
        ? widget.memory.semesters(selectedProgram!)
        : const <int>[];
    final sections = (selectedProgram != null && selectedSemester != null)
        ? widget.memory.sections(selectedProgram!, selectedSemester!)
        : const <String>[];

    final allSessions = _computeSelectionSessions();
    final displayedSessions = _getDisplayedSessions(allSessions);

    final today = DateTime.now().weekday;
    final dayNames = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday',
    ];
    final smartDays = [1, 2, 3, 4, 5];

    final isM3 = ThemeSignals.isMaterialYou;
    final isFluidGlass = ThemeSignals.isFluidGlass;
    final useStandardHeader = !isFluidGlass;

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: (useStandardHeader && widget.showBackButton)
          ? irisFrostedAppBar(
              title: 'Department Classes',
              isDark: isDark,
              leading: AppBackButton(isDark: isDark),
            )
          : null,
      body: Stack(
        children: [
          ObsidianPulse(isDark: isDark),
          SafeArea(
            top: useStandardHeader,
            child: Align(
              alignment: Alignment.topCenter,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 860),
                child: NotificationListener<ScrollNotification>(
                  onNotification: (notification) {
                    if (notification is ScrollUpdateNotification) {
                      final delta = notification.scrollDelta?.abs() ?? 0.0;
                      final fast = delta > 16.0;
                      if (IrisGlass.isFastScrolling.value != fast) {
                        IrisGlass.isFastScrolling.value = fast;
                      }
                    } else if (notification is ScrollEndNotification) {
                      if (IrisGlass.isFastScrolling.value) {
                        IrisGlass.isFastScrolling.value = false;
                      }
                    }
                    return false;
                  },
                  child: CustomScrollView(
                    controller: _scrollController,
                    physics: ScrollConfiguration.of(context).getScrollPhysics(context),
                    cacheExtent: 450.0,
                  slivers: [
                    if (isFluidGlass)
                      ValueListenableBuilder<String>(
                        valueListenable: RemoteConfigService.activeAcademicPeriod,
                        builder: (context, period, _) {
                          return SliverPersistentHeader(
                            pinned: true,
                            delegate: AcademicsLiquidGlassStickyHeaderDelegate(
                              topPadding: MediaQuery.paddingOf(context).top,
                              isDark: isDark,
                              period: period,
                              canPop: widget.showBackButton,
                              onBack: () => Navigator.of(context).maybePop(),
                              onJumpToMyBatch: _jumpToMyBatch,
                              onShare: () => _shareCurrentTimetableText(
                                context,
                                displayedSessions,
                              ),
                              hasBatch: (widget.showBatchShortcut || _isFacultyMode) &&
                                  (_isFacultyMode
                                      ? _teacherBatches.isNotEmpty
                                      : widget.currentBatch.isNotEmpty),
                              isFaculty: _isFacultyMode,
                              batchText: _isFacultyMode && _teacherBatches.length > 1
                                  ? 'Batches'
                                  : 'My Batch',
                            ),
                          );
                        },
                      ),
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (useStandardHeader) ...[
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: IrisTokens.brandGradient,
                                      ),
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                  child: const Icon(
                                    Icons.domain_rounded,
                                    color: Colors.white,
                                    size: 24,
                                  ),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Expanded(
                                            child: FittedBox(
                                              fit: BoxFit.scaleDown,
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                'Department Classes',
                                                maxLines: 1,
                                                style: TextStyle(
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.w800,
                                                  color: isDark
                                                      ? Colors.white
                                                      : Colors.black,
                                                ),
                                              ),
                                            ),
                                          ),
                                          if ((widget.showBatchShortcut || _isFacultyMode) &&
                                              (_isFacultyMode
                                                  ? _teacherBatches.isNotEmpty
                                                  : widget.currentBatch.isNotEmpty)) ...[
                                            const SizedBox(width: 6),
                                            IrisLiquidButton(
                                              text: _isFacultyMode && _teacherBatches.length > 1
                                                  ? 'Batches'
                                                  : 'My Batch',
                                              icon: Icons.bolt_rounded,
                                              onTap: _jumpToMyBatch,
                                              height: 28,
                                              fontSize: 10.5,
                                              iconSize: 13,
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 8,
                                                  ),
                                              color: IrisTokens.brand,
                                              isDark: isDark,
                                              borderSide: BorderSide(
                                                color: IrisTokens.brand
                                                    .withValues(alpha: 0.32),
                                                width: 0.9,
                                              ),
                                            ),
                                            const SizedBox(width: 8),
                                            IrisLiquidButton(
                                              text: 'Share',
                                              icon: Icons.share_rounded,
                                              onTap: () =>
                                                  _shareCurrentTimetableText(
                                                    context,
                                                    displayedSessions,
                                                  ),
                                              height: 28,
                                              fontSize: 10.5,
                                              iconSize: 13,
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 10,
                                                  ),
                                              color: IrisTokens.brand,
                                              isDark: isDark,
                                              borderSide: BorderSide(
                                                color: IrisTokens.brand
                                                    .withValues(alpha: 0.3),
                                                width: 1.0,
                                              ),
                                            ),
                                          ],
                                        ],
                                      ),
                                      const SizedBox(height: 4),
                                      ValueListenableBuilder<String>(
                                        valueListenable: RemoteConfigService
                                            .activeAcademicPeriod,
                                        builder: (context, period, _) {
                                          String subText =
                                              'Browse classes for any program or semester.';
                                          if (period == 'ramadan') {
                                            subText =
                                                '🌙 RAMADAN ACTIVE: Compressed Ramadan lecture timings in effect.';
                                          } else if (period == 'midterms') {
                                            subText =
                                                '📝 MIDTERMS ACTIVE: Showing exam paper datesheets & halls.';
                                          } else if (period == 'finals') {
                                            subText =
                                                '🎓 FINALS ACTIVE: Showing final datesheets, halls & invigilators.';
                                          } else if (period == 'sports_week') {
                                            subText =
                                                '🏆 GALA ACTIVE: Showing sports week classes.';
                                          }
                                          return Text(
                                            subText,
                                            style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: period == 'classes'
                                                  ? FontWeight.w500
                                                  : FontWeight.w700,
                                              color: period == 'classes'
                                                  ? (isDark
                                                            ? Colors.white
                                                            : Colors.black)
                                                        .withValues(alpha: 0.6)
                                                  : (period == 'ramadan' ||
                                                            period ==
                                                                'sports_week'
                                                        ? const Color(
                                                            0xFF10B981,
                                                          )
                                                        : (period == 'midterms'
                                                              ? const Color(
                                                                  0xFFF59E0B,
                                                                )
                                                              : const Color(
                                                                  0xFF8B5CF6,
                                                                ))),
                                            ),
                                          );
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ] else
                            const SizedBox(height: 8),
                          ValueListenableBuilder<String>(
                              valueListenable:
                                  RemoteConfigService.activeAcademicPeriod,
                              builder: (context, period, _) {
                                if (period != 'midterms' &&
                                    period != 'finals') {
                                  return const SizedBox.shrink();
                                }
                                final isMid = period == 'midterms';
                                final examTitle = isMid
                                    ? 'Midterms Matrix'
                                    : 'Finals Matrix';

                                return Padding(
                                  padding: const EdgeInsets.only(top: 10),
                                  child: IrisSegmentedControl(
                                    selectedIndex: _showExamSchedule ? 1 : 0,
                                    height: 38,
                                    onSegmentSelected: (index) {
                                      IrisHaptics.chipSelect();
                                      setState(
                                        () => _showExamSchedule = index == 1,
                                      );
                                    },
                                    segments: ['Class Timetable', examTitle],
                                    selectedTextStyle: const TextStyle(
                                      fontSize: 11.5,
                                      fontWeight: FontWeight.w800,
                                    ),
                                    unselectedTextStyle: const TextStyle(
                                      fontSize: 11.5,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                );
                              },
                            ),
                            if (_isFacultyMode && _teacherBatches.isNotEmpty) ...[
                              const SizedBox(height: 10),
                              SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                physics: const BouncingScrollPhysics(),
                                child: Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                                      decoration: BoxDecoration(
                                        color: IrisTokens.brand.withValues(alpha: isDark ? 0.20 : 0.12),
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          const Icon(Icons.school_rounded, size: 13, color: IrisTokens.brand),
                                          const SizedBox(width: 4),
                                          Text(
                                            'My Batches:',
                                            style: TextStyle(
                                              fontSize: 11,
                                              fontWeight: FontWeight.w800,
                                              color: isDark ? Colors.white : Colors.black,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    ..._teacherBatches.map((batch) {
                                      final isSelected = (selectedProgram != null &&
                                              selectedSemester != null &&
                                              selectedSection != null) &&
                                          '$selectedProgram-$selectedSemester$selectedSection' == batch;
                                      return Padding(
                                        padding: const EdgeInsets.only(right: 6),
                                        child: ExpressiveInteractivePress(
                                          onTap: () => _jumpToBatch(batch),
                                          child: Container(
                                            height: 28,
                                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                            decoration: BoxDecoration(
                                              color: isSelected
                                                  ? IrisTokens.brand
                                                  : (isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.05)),
                                              borderRadius: BorderRadius.circular(8),
                                              border: Border.all(
                                                color: isSelected
                                                    ? IrisTokens.brand
                                                    : (isDark ? Colors.white12 : Colors.black12),
                                              ),
                                            ),
                                            alignment: Alignment.center,
                                            child: Text(
                                              batch,
                                              style: TextStyle(
                                                fontSize: 11.5,
                                                fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                                                color: isSelected
                                                    ? Colors.white
                                                    : (isDark ? Colors.white : Colors.black87),
                                              ),
                                            ),
                                          ),
                                        ),
                                      );
                                    }),
                                  ],
                                ),
                              ),
                            ],
                            const SizedBox(height: 12),
                            // Smart Search Bar
                            IrisGlowingInputWrapper(
                              borderRadius: 14.0,
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.search_rounded,
                                    size: 16,
                                    color:
                                        (isDark ? Colors.white : Colors.black)
                                            .withValues(alpha: 0.45),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: TextField(
                                      controller: _searchController,
                                      onChanged: (val) => setState(
                                        () => _searchQuery = val.trim(),
                                      ),
                                      style: TextStyle(
                                        fontSize: 12.5,
                                        fontWeight: FontWeight.w600,
                                        color: isDark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                      decoration: InputDecoration(
                                        isDense: true,
                                        hintText:
                                            'Search course, teacher, room, or batch...',
                                        hintStyle: TextStyle(
                                          fontSize: 11.5,
                                          fontWeight: FontWeight.w500,
                                          color:
                                              (isDark
                                                      ? Colors.white
                                                      : Colors.black)
                                                  .withValues(alpha: 0.38),
                                        ),
                                        border: InputBorder.none,
                                      ),
                                    ),
                                  ),
                                  if (_searchQuery.isNotEmpty)
                                    GestureDetector(
                                      onTap: () {
                                        _searchController.clear();
                                        setState(() => _searchQuery = '');
                                      },
                                      child: Icon(
                                        Icons.close_rounded,
                                        size: 16,
                                        color:
                                            (isDark
                                                    ? Colors.white
                                                    : Colors.black)
                                                .withValues(alpha: 0.5),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 14),

                            // Dropdowns Selector Card
                            GlassCard(
                              padding: const EdgeInsets.all(16),
                              borderRadius: 24,
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                        Column(
                                          children: [
                                            SizedBox(
                                              width: double.infinity,
                                              child: IrisGlassMenu(
                                                autoAdjustToScreen: true,
                                                menuPadding:
                                                    const EdgeInsets.all(16),
                                                menuWidth:
                                                    MediaQuery.sizeOf(
                                                      context,
                                                    ).width -
                                                    64.0,
                                                menuHeight: math.min(
                                                  validPrograms.length * 48.0 +
                                                      16.0,
                                                  320.0,
                                                ),
                                                menuBorderRadius: 28.0,
                                                itemBorderRadius: 20.0,
                                                settings:
                                                    IrisGlass.widgetsSettings(
                                                      context,
                                                      blur: 16.0,
                                                      ambientStrength: 0.7,
                                                      lightAngle:
                                                          0.15 * math.pi,
                                                      thickness: 18.0,
                                                    ),
                                                triggerBuilder:
                                                    (context, toggleMenu) {
                                                      return _buildGlassInputPill(
                                                        title: 'PROGRAM',
                                                        value:
                                                            selectedProgram ??
                                                            'None',
                                                        onTap: toggleMenu,
                                                      );
                                                    },
                                                items: validPrograms.map((p) {
                                                  final isSelected =
                                                      p == selectedProgram;
                                                  final dept =
                                                      BatchKey.resolveDepartment(
                                                        p,
                                                      );
                                                  final label =
                                                      dept.isNotEmpty &&
                                                          dept != 'Unknown'
                                                      ? '$p • $dept'
                                                      : p;
                                                  return lgw.GlassMenuItem(
                                                    title: label,
                                                    titleStyle: TextStyle(
                                                      fontWeight: isSelected
                                                          ? FontWeight.bold
                                                          : FontWeight.w600,
                                                      fontSize: 14,
                                                      color: isSelected
                                                          ? IrisTokens.brand
                                                          : (isDark
                                                                ? Colors.white
                                                                      .withValues(
                                                                        alpha:
                                                                            0.9,
                                                                      )
                                                                : Colors
                                                                      .black87),
                                                    ),
                                                    isSelected: isSelected,
                                                    icon: Icon(
                                                      Icons.school_rounded,
                                                      size: 16,
                                                      color: isSelected
                                                          ? IrisTokens.brand
                                                          : (isDark
                                                                ? Colors.white70
                                                                : Colors
                                                                      .black54),
                                                    ),
                                                    onTap: () {
                                                      IrisHaptics.chipSelect();
                                                      setState(() {
                                                        selectedProgram = p;
                                                        final newSemesters =
                                                            widget.memory
                                                                .semesters(p);
                                                        if (newSemesters
                                                            .isNotEmpty) {
                                                          selectedSemester =
                                                              newSemesters
                                                                  .first;
                                                          final newSections = widget
                                                              .memory
                                                              .sections(
                                                                p,
                                                                selectedSemester!,
                                                              );
                                                          if (newSections
                                                              .isNotEmpty) {
                                                            selectedSection =
                                                                newSections
                                                                    .first;
                                                          } else {
                                                            selectedSection =
                                                                null;
                                                          }
                                                        } else {
                                                          selectedSemester =
                                                              null;
                                                          selectedSection =
                                                              null;
                                                        }
                                                      });
                                                    },
                                                  );
                                                }).toList(),
                                              ),
                                            ),
                                            const SizedBox(height: 12),
                                            Row(
                                              children: [
                                                Expanded(
                                                  child: IrisGlassMenu(
                                                    autoAdjustToScreen: true,
                                                    menuPadding:
                                                        const EdgeInsets.all(
                                                          16,
                                                        ),
                                                    menuWidth: math.min(
                                                      MediaQuery.sizeOf(
                                                            context,
                                                          ).width -
                                                          32,
                                                      175.0,
                                                    ),
                                                    menuHeight: math.min(
                                                      semesters.length * 48.0 +
                                                          16.0,
                                                      260.0,
                                                    ),
                                                    menuBorderRadius: 28.0,
                                                    itemBorderRadius: 20.0,
                                                    settings:
                                                        IrisGlass.widgetsSettings(
                                                          context,
                                                          blur: 16.0,
                                                          ambientStrength: 0.7,
                                                          lightAngle:
                                                              0.15 * math.pi,
                                                          thickness: 18.0,
                                                        ),
                                                    triggerBuilder: (context, toggleMenu) {
                                                      return _buildGlassInputPill(
                                                        title: 'SEMESTER',
                                                        value:
                                                            selectedSemester !=
                                                                null
                                                            ? 'Sem $selectedSemester'
                                                            : 'None',
                                                        onTap: toggleMenu,
                                                      );
                                                    },
                                                    items: semesters.map((s) {
                                                      final isSelected =
                                                          s == selectedSemester;
                                                      return lgw.GlassMenuItem(
                                                        title: 'Semester $s',
                                                        titleStyle: TextStyle(
                                                          fontWeight: isSelected
                                                              ? FontWeight.bold
                                                              : FontWeight.w600,
                                                          fontSize: 14,
                                                          color: isSelected
                                                              ? IrisTokens.brand
                                                              : (isDark
                                                                    ? Colors
                                                                          .white
                                                                          .withValues(
                                                                            alpha:
                                                                                0.9,
                                                                          )
                                                                    : Colors
                                                                          .black87),
                                                        ),
                                                        isSelected: isSelected,
                                                        icon: Icon(
                                                          Icons
                                                              .auto_stories_rounded,
                                                          size: 16,
                                                          color: isSelected
                                                              ? IrisTokens.brand
                                                              : (isDark
                                                                    ? Colors
                                                                          .white70
                                                                    : Colors
                                                                          .black54),
                                                        ),
                                                        onTap: () {
                                                          IrisHaptics.chipSelect();
                                                          setState(() {
                                                            selectedSemester =
                                                                s;
                                                            if (selectedProgram !=
                                                                null) {
                                                              final newSections =
                                                                  widget.memory
                                                                      .sections(
                                                                        selectedProgram!,
                                                                        s,
                                                                      );
                                                              if (newSections
                                                                  .isNotEmpty) {
                                                                selectedSection =
                                                                    newSections
                                                                        .first;
                                                              } else {
                                                                selectedSection =
                                                                    null;
                                                              }
                                                            }
                                                          });
                                                        },
                                                      );
                                                    }).toList(),
                                                  ),
                                                ),
                                                const SizedBox(width: 12),
                                                Expanded(
                                                  child: IrisGlassMenu(
                                                    autoAdjustToScreen: true,
                                                    menuPadding:
                                                        const EdgeInsets.all(
                                                          16,
                                                        ),
                                                    menuWidth: math.min(
                                                      MediaQuery.sizeOf(
                                                            context,
                                                          ).width -
                                                          32,
                                                      175.0,
                                                    ),
                                                    menuHeight: math.min(
                                                      sections.length * 48.0 +
                                                          16.0,
                                                      260.0,
                                                    ),
                                                    menuBorderRadius: 28.0,
                                                    itemBorderRadius: 20.0,
                                                    settings:
                                                        IrisGlass.widgetsSettings(
                                                          context,
                                                          blur: 16.0,
                                                          ambientStrength: 0.7,
                                                          lightAngle:
                                                              0.15 * math.pi,
                                                          thickness: 18.0,
                                                        ),
                                                    triggerBuilder:
                                                        (context, toggleMenu) {
                                                          return _buildGlassInputPill(
                                                            title: 'SECTION',
                                                            value:
                                                                selectedSection !=
                                                                    null
                                                                ? 'Sec $selectedSection'
                                                                : 'None',
                                                            onTap: toggleMenu,
                                                          );
                                                        },
                                                    items: sections.map((sec) {
                                                      final isSelected =
                                                          sec ==
                                                          selectedSection;
                                                      return lgw.GlassMenuItem(
                                                        title: 'Section $sec',
                                                        titleStyle: TextStyle(
                                                          fontWeight: isSelected
                                                              ? FontWeight.bold
                                                              : FontWeight.w600,
                                                          fontSize: 14,
                                                          color: isSelected
                                                              ? IrisTokens.brand
                                                              : (isDark
                                                                    ? Colors
                                                                          .white
                                                                          .withValues(
                                                                            alpha:
                                                                                0.9,
                                                                          )
                                                                    : Colors
                                                                          .black87),
                                                        ),
                                                        isSelected: isSelected,
                                                        icon: Icon(
                                                          Icons.group_rounded,
                                                          size: 16,
                                                          color: isSelected
                                                              ? IrisTokens.brand
                                                              : (isDark
                                                                    ? Colors
                                                                          .white70
                                                                    : Colors
                                                                          .black54),
                                                        ),
                                                        onTap: () {
                                                          IrisHaptics.chipSelect();
                                                          setState(() {
                                                            selectedSection =
                                                                sec;
                                                          });
                                                        },
                                                      );
                                                    }).toList(),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                        if (allSessions.isNotEmpty) ...[
                                          const SizedBox(height: 14),
                                          const Divider(height: 1),
                                          const SizedBox(height: 10),
                                          SingleChildScrollView(
                                            scrollDirection: Axis.horizontal,
                                            child: Row(
                                              children: smartDays
                                                  .map(
                                                    (day) => Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                            right: 8,
                                                          ),
                                                      child: _buildFilterChip(
                                                        label: day == today
                                                            ? 'Today'
                                                            : dayNames[day - 1],
                                                        selected:
                                                            selectedDay == day,
                                                        color: day == today
                                                            ? IrisTokens.success
                                                            : IrisTokens
                                                                  .warning,
                                                        isDark: isDark,
                                                        onSelected: (selected) {
                                                          setState(() {
                                                            selectedDay =
                                                                selected
                                                                ? day
                                                                : null;
                                                          });
                                                        },
                                                      ),
                                                    ),
                                                  )
                                                  .toList(),
                                            ),
                                          ),
                                        ],
                                      ],
                                    ),
                                  ),
                            const SizedBox(height: 16),
                            Padding(
                              padding: const EdgeInsets.only(left: 4),
                              child: Text(
                                '${displayedSessions.length} classes found',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: (isDark ? Colors.white : Colors.black)
                                      .withValues(alpha: 0.4),
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                          ],
                        ),
                      ),
                    ),

                    // Classes list
                    if (displayedSessions.isNotEmpty)
                      SliverPadding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 20, 118),
                        sliver: SliverList(
                          delegate: SliverChildBuilderDelegate(
                            (context, index) {
                              final session = displayedSessions[index];
                              final isInMySchedule =
                                  widget.currentBatch == session.batchKey.batch;
                              final isLive = session.isLive(DateTime.now());
                              final programAccent = _accentForProgram(
                                session.batchKey.program,
                              );

                              final isM3 = ThemeSignals.isMaterialYou;
                              final cs = Theme.of(context).colorScheme;

                              final cardContent = Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              // Time column
                                              Container(
                                                width: 54,
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                      vertical: 6,
                                                    ),
                                                decoration: BoxDecoration(
                                                  color: isLive
                                                      ? IrisTokens.success
                                                            .withValues(
                                                              alpha: isDark
                                                                  ? 0.15
                                                                  : 0.1,
                                                            )
                                                      : IrisTokens.brand
                                                            .withValues(
                                                              alpha: isDark
                                                                  ? 0.1
                                                                  : 0.06,
                                                            ),
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                ),
                                                child: Column(
                                                  children: [
                                                    Text(
                                                      session.startTime,
                                                      style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        color: isLive
                                                            ? IrisTokens.success
                                                            : IrisTokens.brand,
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 1,
                                                      height: 6,
                                                      color:
                                                          (isDark
                                                                  ? Colors.white
                                                                  : Colors
                                                                        .black)
                                                              .withValues(
                                                                alpha: 0.1,
                                                              ),
                                                    ),
                                                    Text(
                                                      session.endTime,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        color:
                                                            (isDark
                                                                    ? Colors
                                                                          .white
                                                                    : Colors
                                                                          .black)
                                                                .withValues(
                                                                  alpha: 0.4,
                                                                ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              const SizedBox(width: 14),
                                              // Details
                                              Expanded(
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Row(
                                                      children: [
                                                        if (isLive) ...[
                                                          Container(
                                                            width: 7,
                                                            height: 7,
                                                            decoration:
                                                                const BoxDecoration(
                                                                  color: IrisTokens
                                                                      .success,
                                                                  shape: BoxShape
                                                                      .circle,
                                                                ),
                                                          ),
                                                          const SizedBox(
                                                            width: 6,
                                                          ),
                                                        ],
                                                        Expanded(
                                                          child: Text(
                                                            session.subject,
                                                            style: TextStyle(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                              fontSize: 14,
                                                              color: isLive
                                                                  ? IrisTokens
                                                                        .success
                                                                  : (isDark
                                                                        ? programAccent.withValues(
                                                                            alpha:
                                                                                0.95,
                                                                          )
                                                                        : programAccent.withValues(
                                                                            alpha:
                                                                                0.90,
                                                                          )),
                                                            ),
                                                            maxLines: 2,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                          ),
                                                        ),
                                                        if (isInMySchedule)
                                                          Container(
                                                            padding:
                                                                const EdgeInsets.symmetric(
                                                                  horizontal: 8,
                                                                  vertical: 3,
                                                                ),
                                                            decoration: BoxDecoration(
                                                              color: programAccent
                                                                  .withValues(
                                                                    alpha: 0.12,
                                                                  ),
                                                              borderRadius:
                                                                  BorderRadius.circular(
                                                                    8,
                                                                  ),
                                                              border: Border.all(
                                                                color: programAccent
                                                                    .withValues(
                                                                      alpha:
                                                                          0.2,
                                                                    ),
                                                              ),
                                                            ),
                                                            child: Text(
                                                              'MY CLASS',
                                                              style: TextStyle(
                                                                fontSize: 9,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w800,
                                                                color:
                                                                    programAccent,
                                                                letterSpacing:
                                                                    0.5,
                                                              ),
                                                            ),
                                                          ),
                                                      ],
                                                    ),
                                                    const SizedBox(height: 6),
                                                    Wrap(
                                                      spacing: 8,
                                                      runSpacing: 6,
                                                      children: [
                                                        _buildMetaChip(
                                                          icon: Icons
                                                              .person_outline_rounded,
                                                          text: session.teacher,
                                                          color:
                                                              IrisTokens.brand,
                                                          isDark: isDark,
                                                        ),
                                                        _buildMetaChip(
                                                          icon: Icons
                                                              .room_rounded,
                                                          text: session.room,
                                                          color: IrisTokens
                                                              .success,
                                                          isDark: isDark,
                                                        ),
                                                      ],
                                                    ),
                                                    const SizedBox(height: 4),
                                                    Container(
                                                      padding:
                                                          const EdgeInsets.symmetric(
                                                            horizontal: 10,
                                                            vertical: 4,
                                                          ),
                                                      decoration: BoxDecoration(
                                                        color: IrisTokens.purple
                                                            .withValues(
                                                              alpha: isDark
                                                                  ? 0.14
                                                                  : 0.10,
                                                            ),
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                              999,
                                                            ),
                                                        border: Border.all(
                                                          color: IrisTokens
                                                              .purple
                                                              .withValues(
                                                                alpha: 0.25,
                                                              ),
                                                        ),
                                                      ),
                                                      child: Text(
                                                        session.batchKey.batch,
                                                        style: const TextStyle(
                                                          fontSize: 10,
                                                          color:
                                                              IrisTokens.purple,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          letterSpacing: 0.3,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          );

                              final cardBody = GlassCard(
                                padding: const EdgeInsets.all(12),
                                borderRadius: 16,
                                accentColor: isLive ? (isM3 ? cs.primary : IrisTokens.success) : null,
                                child: cardContent,
                              );

                              return StaggeredListItem(
                                index: index,
                                child: Padding(
                                  padding: const EdgeInsets.only(bottom: 10),
                                  child: GestureDetector(
                                    onTap: () {
                                      IrisHaptics.actionSoft();
                                    },
                                    child: cardBody,
                                  ),
                                ),
                              );
                            },
                            childCount: displayedSessions.length,
                            addRepaintBoundaries: true,
                          ),
                        ),
                      ),

                    // Empty state
                    if (displayedSessions.isEmpty && selectedProgram != null)
                      SliverToBoxAdapter(
                        child: Padding(
                          padding: const EdgeInsets.all(40),
                          child: GlassCard(
                            borderRadius: 24,
                            padding: const EdgeInsets.symmetric(
                              vertical: 24,
                              horizontal: 16,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.search_off_rounded,
                                  size: 48,
                                  color: (isDark ? Colors.white : Colors.black)
                                      .withValues(alpha: 0.25),
                                ),
                                const SizedBox(height: 16),
                                Text(
                                  'No classes found',
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                    color: (isDark
                                            ? Colors.white
                                            : Colors.black)
                                        .withValues(alpha: 0.5),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'Try adjusting the filters',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: (isDark
                                            ? Colors.white
                                            : Colors.black)
                                        .withValues(alpha: 0.3),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
          if (widget.showDock)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: SafeArea(
                top: false,
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 580),
                    child: DashboardDock(
                      scrollController: _scrollController,
                      selectedIndex: 3,
                      onTeacher: widget.brain != null
                          ? () => pushIconLaunchRoute(
                              context,
                              page: TeacherLocatorScreen(
                                brain: widget.brain!,
                                onRoleChanged: widget.onRoleChanged,
                                onBatchChanged: widget.onBatchChanged,
                                memory: widget.memory,
                                currentBatch: widget.currentBatch,
                              ),
                            )
                          : () {},
                      onPortal: () => pushIconLaunchRoute(
                        context,
                        page: const PortalScreen(
                          url: 'https://swl-sis.comsats.edu.pk/',
                          title: 'COMSATS Student Portal',
                          sessionScope: 'student',
                        ),
                      ),
                      onClasses: () {},
                      onTools: widget.brain != null
                          ? () => pushIconLaunchRoute(
                              context,
                              page: ToolsScreen(
                                memory: widget.memory,
                                batch: widget.currentBatch,
                                brain: widget.brain!,
                                onRoleChanged: widget.onRoleChanged,
                                onBatchChanged: widget.onBatchChanged,
                                onAddMakeupClass: widget.onAddMakeupClass,
                                onRemoveMakeupClass: widget.onRemoveMakeupClass,
                              ),
                            )
                          : () {
                              showIrisFrostedSnackBar(
                                context,
                                dedupeKey: 'tools_unavailable_session',
                                content: const Text(
                                  'Tools view is unavailable for this session.',
                                ),
                              );
                            },
                      onAbout: () => pushIconLaunchRoute(
                        context,
                        page: AboutScreen(
                          memory: widget.memory,
                          onRoleChanged: widget.onRoleChanged,
                          onBatchChanged: widget.onBatchChanged,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Color _accentForProgram(String program) {
    final key = program.toLowerCase();
    if (key.contains('cs') || key.contains('computer')) return IrisTokens.brand;
    if (key.contains('se') || key.contains('software')) return IrisTokens.blue;
    if (key.contains('it') || key.contains('information')) {
      return const Color(0xFF06B6D4);
    }
    if (key.contains('ee') || key.contains('electrical')) {
      return IrisTokens.warning;
    }
    if (key.contains('ai') || key.contains('ml')) return IrisTokens.purple;
    if (key.contains('mech') || key.contains('mechanical')) {
      return IrisTokens.error;
    }
    return IrisTokens.success;
  }

  Widget _buildFilterChip({
    required String label,
    required bool selected,
    required Color color,
    required bool isDark,
    required ValueChanged<bool> onSelected,
  }) {
    final themeStyle = ThemeSignals.themeStyle.value;

    if (themeStyle == IrisThemeStyle.materialYou) {
      final cs = Theme.of(context).colorScheme;
      return ExpressiveInteractivePress(
        onTap: () => onSelected(!selected),
        pressedScale: 0.94,
        child: AnimatedContainer(
          duration: IrisMotion.fast,
          curve: IrisMotion.standard,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          margin: const EdgeInsets.symmetric(vertical: 2),
          decoration: BoxDecoration(
            color: selected ? cs.primary : cs.surfaceContainerHigh,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected
                  ? cs.primary
                  : cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.6),
              width: selected ? 1.4 : 1.0,
            ),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
              color: selected ? cs.onPrimary : cs.onSurfaceVariant,
            ),
          ),
        ),
      );
    }

    if (themeStyle == IrisThemeStyle.notebook) {
      return ExpressiveInteractivePress(
        onTap: () => onSelected(!selected),
        pressedScale: 0.94,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          margin: const EdgeInsets.symmetric(vertical: 2),
          decoration: BoxDecoration(
            color: selected ? color : NotebookTokens.cardSurface(isDark),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(
              color: selected ? color : NotebookTokens.gridLine(isDark),
              width: selected ? 1.5 : 1.0,
            ),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
              color: selected ? Colors.white : NotebookTokens.inkBody(isDark),
            ),
          ),
        ),
      );
    }

    if (themeStyle == IrisThemeStyle.line) {
      return ExpressiveInteractivePress(
        onTap: () => onSelected(!selected),
        pressedScale: 0.94,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          margin: const EdgeInsets.symmetric(vertical: 2),
          decoration: BoxDecoration(
            color: selected ? color : LineTokens.cardSurface(isDark),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? color : LineTokens.railLine(isDark),
              width: selected ? 1.4 : 1.0,
            ),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
              color: selected ? Colors.white : LineTokens.inkBody(isDark),
            ),
          ),
        ),
      );
    }

    if (themeStyle == IrisThemeStyle.poster) {
      return ExpressiveInteractivePress(
        onTap: () => onSelected(!selected),
        pressedScale: 0.94,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          margin: const EdgeInsets.symmetric(vertical: 2),
          decoration: BoxDecoration(
            color: selected
                ? color
                : (isDark ? const Color(0xFF1C1917) : const Color(0xFFF5F5F4)),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: selected ? color : PosterTokens.inkBorder(isDark),
              width: selected ? 1.8 : 1.2,
            ),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w800,
              color: selected ? Colors.white : PosterTokens.inkBody(isDark),
            ),
          ),
        ),
      );
    }

    if (themeStyle == IrisThemeStyle.almanac) {
      return ExpressiveInteractivePress(
        onTap: () => onSelected(!selected),
        pressedScale: 0.94,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          margin: const EdgeInsets.symmetric(vertical: 2),
          decoration: BoxDecoration(
            color: selected ? color : AlmanacTokens.canvas(isDark),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: selected ? color : AlmanacTokens.inkRuleSubtle(isDark),
              width: 1.0,
            ),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
              color: selected ? Colors.white : AlmanacTokens.inkBody(isDark),
            ),
          ),
        ),
      );
    }

    if (themeStyle == IrisThemeStyle.editorialAcademic) {
      return ExpressiveInteractivePress(
        onTap: () => onSelected(!selected),
        pressedScale: 0.94,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          margin: const EdgeInsets.symmetric(vertical: 2),
          decoration: BoxDecoration(
            color: selected ? color : EditorialTokens.cardSurface(isDark),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: selected ? color : EditorialTokens.cardBorder(isDark),
              width: 1.0,
            ),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
              color: selected ? Colors.white : EditorialTokens.inkBody(isDark),
            ),
          ),
        ),
      );
    }

    // Default: Fluid Glass
    return GestureDetector(
      onTap: () => onSelected(!selected),
      child: AnimatedContainer(
        duration: IrisMotion.fast,
        curve: IrisMotion.standard,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        margin: const EdgeInsets.symmetric(vertical: 2),
        constraints: const BoxConstraints(minHeight: 36),
        decoration: ShapeDecoration(
          color: selected
              ? color
              : isDark
              ? Colors.white.withValues(alpha: 0.10)
              : Colors.white.withValues(alpha: 0.70),
          shape: lgw.LiquidRoundedSuperellipse(
            borderRadius: 22,
            side: BorderSide(
              color: selected
                  ? color.withValues(alpha: 0.8)
                  : isDark
                  ? Colors.white.withValues(alpha: 0.14)
                  : Colors.black.withValues(alpha: 0.06),
            ),
          ),
          shadows: selected
              ? [
                  BoxShadow(
                    color: color.withValues(alpha: 0.14),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                    spreadRadius: -6,
                  ),
                ]
              : [],
        ),
        child: Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: 13,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
            color: selected
                ? Colors.white
                : (isDark
                      ? Colors.white.withValues(alpha: 0.7)
                      : Colors.black.withValues(alpha: 0.6)),
          ),
        ),
      ),
    );
  }

  Widget _buildMetaChip({
    required IconData icon,
    required String text,
    required Color color,
    required bool isDark,
  }) {
    final style = ThemeSignals.themeStyle.value;
    final textColor = switch (style) {
      IrisThemeStyle.notebook => NotebookTokens.inkBody(isDark),
      IrisThemeStyle.line => LineTokens.inkBody(isDark),
      IrisThemeStyle.poster => PosterTokens.inkBody(isDark),
      IrisThemeStyle.almanac => AlmanacTokens.inkBody(isDark),
      IrisThemeStyle.editorialAcademic => EditorialTokens.inkBody(isDark),
      _ => (isDark ? Colors.white : Colors.black).withValues(alpha: 0.75),
    };

    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 160),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: ShapeDecoration(
          color: color.withValues(alpha: isDark ? 0.12 : 0.08),
          shape: lgw.LiquidRoundedSuperellipse(
            borderRadius: 20,
            side: BorderSide(
              color: color.withValues(alpha: isDark ? 0.35 : 0.25),
            ),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 12, color: color),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                text,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: textColor,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }
}