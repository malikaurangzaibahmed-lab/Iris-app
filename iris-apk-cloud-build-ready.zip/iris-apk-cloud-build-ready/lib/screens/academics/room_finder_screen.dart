import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/tokens.dart';
import '../../core/animations.dart';
import '../../core/university_memory.dart';
import '../../core/vital_theme.dart';
import '../../services/room_occupancy_service.dart';
import '../../services/room_persistence_service.dart';
import '../../services/analytics_manager.dart';
import '../../services/ui_feedback.dart';
import '../../core/models.dart';
import '../../core/format_guard.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/iris_components.dart';
import 'package:iris/widgets/controls/glowing_input_wrapper.dart';
import '../../services/remote_config_service.dart';
import '../../core/theme_signals.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';

import '../../widgets/room_finder/room_finder_widgets.dart';
export '../../widgets/room_finder/room_finder_widgets.dart';
class RoomFinderScreen extends StatefulWidget {
  final UniversityMemory? memory;
  const RoomFinderScreen({this.memory, super.key});

  @override
  State<RoomFinderScreen> createState() => _RoomFinderScreenState();
}

class _RoomFinderScreenState extends State<RoomFinderScreen> {
  final RoomOccupancyService _service = RoomOccupancyService();
  final RoomPersistenceService _persistence = RoomPersistenceService();
  late UniversityMemory _activeMemory;
  bool _isLoadingMemory = false;
  
  int _currentTabIndex = 0; // 0: Live Vacancies, 1: Explore Campus
  
  // Live Vacancies State
  final TextEditingController _searchController = TextEditingController();
  String _query = '';
  double? _targetHour;
  int? _targetDay;
  int? _targetSlot;
  String _filterBuilding = 'All';
  List<TimeSlot> _dynamicSlots = [];
  
  final List<String> _days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  List<RoomAvailability> _allAvailability = [];
  List<RoomAvailability> _filteredRooms = [];
  RoomRecommendation _recommendation = RoomRecommendation(
    recommended: null,
    reason: '',
    alternatives: [],
  );
  List<String> _buildings = ['All'];
  String _filterStatus = 'All'; // 'All', 'Vacant', 'Occupied', 'Labs'
  String? _userBatch;

  // Explore Campus State
  List<CampusBuilding> _campusDirectory = [];
  bool _isLoadingDirectory = true;

  @override
  void initState() {
    super.initState();
    AnalyticsManager().trackScreenView('RoomFinderScreen');
    _activeMemory = widget.memory ?? UniversityMemory();
    RemoteConfigService.activeAcademicPeriod.addListener(_onPeriodChanged);
    _initService();
  }

  @override
  void dispose() {
    RemoteConfigService.activeAcademicPeriod.removeListener(_onPeriodChanged);
    _searchController.dispose();
    super.dispose();
  }

  void _onPeriodChanged() {
    if (!mounted) return;
    _service.clearSessionCache();
    _recomputeAvailability();
  }

  Future<void> _initService() async {
    if (_activeMemory.sessions.isEmpty) {
      setState(() => _isLoadingMemory = true);
      try {
        _activeMemory = await UniversityMemoryLoader.loadFromAssets();
      } catch (e) {
        debugPrint('⚠️ Error loading university memory: $e');
      }
      if (mounted) setState(() => _isLoadingMemory = false);
    }

    try {
      final prefs = await SharedPreferences.getInstance();
      _userBatch = prefs.getString('user_batch')?.trim();
    } catch (_) {}

    // Load Live Vacancies data
    final storedRooms = await _persistence.loadRooms();
    final Map<String, Room> roomMap = {for (var r in storedRooms) r.id: r};
    
    final sessionsRooms = _activeMemory.activeSessions().map((s) => s.room).toSet();
    bool newlyAdded = false;

    for (final r in sessionsRooms) {
      if (r == 'TBD' || r.trim().isEmpty) continue;
      final cleanRoom = FormatGuard.sanitizeRoom(r);
      if (!roomMap.containsKey(cleanRoom) && !roomMap.containsKey(r)) {
        final newRoom = _persistence.generateDefaultRoom(cleanRoom);
        roomMap[cleanRoom] = newRoom;
        newlyAdded = true;
      }
    }

    if (newlyAdded) {
      await _persistence.saveRooms(roomMap.values.toList());
    }

    for (final room in roomMap.values) {
      _service.registerRoomModel(room);
    }
    
    // Load Campus Directory data
    final dir = await _persistence.loadCampusDirectory();
    if (mounted) {
      setState(() {
        _campusDirectory = dir;
        _isLoadingDirectory = false;
      });
    }

    _recomputeAvailability();
  }

  void _recomputeAvailability() {
    if (!mounted) return;
    final now = DateTime.now();
    final day = _targetDay ?? now.weekday;
    final allSessions = _activeMemory.activeSessions();
    final activePeriod = RemoteConfigService.activeAcademicPeriod.value;

    _dynamicSlots = RoomOccupancyService.extractDynamicSlots(
      allSessions,
      day,
      period: activePeriod,
    );

    if (_targetSlot != null && _targetSlot! < _dynamicSlots.length) {
      final slot = _dynamicSlots[_targetSlot!];
      _allAvailability = _service.getRoomAvailabilityForSlotRange(
        allSessions,
        slot.start,
        slot.end,
        day,
      );
      _recommendation = RoomRecommendation(
        recommended: null,
        reason: '',
        alternatives: [],
      );
    } else if (_targetHour != null) {
      _allAvailability = _service.getRoomAvailabilityAt(
        allSessions,
        _targetHour!,
        day,
      );
      _recommendation = RoomRecommendation(
        recommended: null,
        reason: '',
        alternatives: [],
      );
    } else {
      final hour = now.hour + (now.minute / 60.0);
      _allAvailability = _service.getRoomAvailabilityAt(allSessions, hour, day);

      final userSchedule = (_userBatch != null && _userBatch!.isNotEmpty)
          ? (_activeMemory.byBatch()[_userBatch] ?? <ClassSession>[])
          : <ClassSession>[];

      _recommendation = _service.getSmartRecommendation(
        allSessions, 
        userSchedule,
        80,
      );
    }

    final baseBuildings = _allAvailability
        .map((e) => e.building)
        .where((b) => b != 'Other' && b != 'Academic Block' && b.isNotEmpty)
        .toSet()
        .toList()
      ..sort();
    
    _buildings = ['All', ...baseBuildings];
    _applyFilters();
  }

  void _applyFilters() {
    final q = _query.toLowerCase().trim();
    setState(() {
      _filteredRooms = _allAvailability.where((a) {
        final matchesQuery = q.isEmpty ||
            a.roomId.toLowerCase().contains(q) || 
            a.building.toLowerCase().contains(q) ||
            (a.formattedLocation != null && a.formattedLocation!.toLowerCase().contains(q)) ||
            (a.occupiedBy != null && a.occupiedBy!.toLowerCase().contains(q)) ||
            (a.occupiedByTeacher != null && a.occupiedByTeacher!.toLowerCase().contains(q));
        final matchesBuilding = _filterBuilding == 'All' || a.building == _filterBuilding;
        final isLab = a.roomId.toLowerCase().contains('lab') || a.amenities.any((am) => am.toLowerCase().contains('lab'));
        final matchesStatus = _filterStatus == 'All' ||
            (_filterStatus == 'Vacant' && a.isAvailable) ||
            (_filterStatus == 'Occupied' && !a.isAvailable) ||
            (_filterStatus == 'Labs' && isLab) ||
            (_filterStatus == 'Quiet' &&
                a.isAvailable &&
                (a.minulesFreeUntilNextSession == null ||
                    a.minulesFreeUntilNextSession! >= 90));
        return matchesQuery && matchesBuilding && matchesStatus;
      }).toList();
    });
  }

  void _resetFilters() {
    setState(() {
      _query = '';
      _searchController.clear();
      _filterBuilding = 'All';
      _filterStatus = 'All';
      _targetSlot = null;
      _targetHour = null;
      _targetDay = null;
    });
    IrisHaptics.actionSoft();
    _recomputeAvailability();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final topInset = MediaQuery.paddingOf(context).top + kToolbarHeight + 16;

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: irisFrostedAppBar(title: 'Room Finder', isDark: isDark),
      body: Stack(
        children: [
          ObsidianPulse(isDark: isDark),
          if (_isLoadingMemory)
            Center(child: IrisComponents.loadingSpinner(size: 32))
          else
            Align(
              alignment: Alignment.topCenter,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 880),
                child: CustomScrollView(
                  physics: const ButterScrollPhysics(
                    parent: AlwaysScrollableScrollPhysics(),
                  ),
                  cacheExtent: 450.0,
                  slivers: [
                    SliverPadding(
                      padding: EdgeInsets.fromLTRB(16, topInset, 16, 0),
                      sliver: SliverList(
                        delegate: SliverChildListDelegate([
                          _buildSegmentedControl(isDark),
                          const SizedBox(height: 24),
                        ]),
                      ),
                    ),
                    if (_currentTabIndex == 0) ..._buildLiveVacancies(isDark)
                    else ..._buildExploreCampus(isDark),
                    const SliverPadding(padding: EdgeInsets.only(bottom: 120)),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSegmentedControl(bool isDark) {
    return Center(
      child: IrisSegmentedControl(
        selectedIndex: _currentTabIndex,
        onSegmentSelected: (index) {
          IrisHaptics.chipSelect();
          setState(() => _currentTabIndex = index);
        },
        segments: const [
          'Live Space Radar',
          'Explore Campus',
        ],
      ),
    );
  }

  List<Widget> _buildLiveVacancies(bool isDark) {
    final totalRoomsCount = _allAvailability.length;
    final availableRoomsCount =
        _allAvailability.where((a) => a.isAvailable).length;
    final freeLabsCount = _allAvailability.where((a) =>
        a.isAvailable &&
        (a.roomId.toLowerCase().contains('lab') ||
            a.amenities.any((am) => am.toLowerCase().contains('lab')))).length;
    final freeHallsCount = (availableRoomsCount - freeLabsCount).clamp(0, totalRoomsCount);
    final double vacancyPercent = totalRoomsCount > 0
        ? (availableRoomsCount / totalRoomsCount)
        : 0.0;
    final cachedActiveSessions = _activeMemory.activeSessions();
    final effectiveTargetDay = _targetDay ?? DateTime.now().weekday;

    return [
      SliverPadding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        sliver: SliverList(
          delegate: SliverChildListDelegate([
            _buildOccupancyConsoleCard(
              free: availableRoomsCount,
              total: totalRoomsCount,
              freeHalls: freeHallsCount,
              freeLabs: freeLabsCount,
              percent: vacancyPercent,
              isDark: isDark,
            ),
            const SizedBox(height: 18),
            _buildTimeTravelerDeck(isDark),
            const SizedBox(height: 18),
            _buildBentoQuickFilterBar(isDark),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildSectionHeader('SPACES RADAR (${_filteredRooms.length})', isDark),
                if (_query.isNotEmpty ||
                    _filterBuilding != 'All' ||
                    _filterStatus != 'All' ||
                    _targetSlot != null ||
                    _targetHour != null ||
                    _targetDay != null)
                  GestureDetector(
                    onTap: _resetFilters,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: IrisTokens.brand.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.refresh_rounded, size: 13, color: IrisTokens.brand),
                          SizedBox(width: 4),
                          Text(
                            'Reset Filters',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: IrisTokens.brand,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 14),
          ]),
        ),
      ),
      if (_filteredRooms.isEmpty)
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: _buildEmptyState(isDark),
          ),
        )
      else
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          sliver: SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                final a = _filteredRooms[index];
                return RepaintBoundary(
                  child: RoomAvailabilityCard(
                    availability: a,
                    isDark: isDark,
                    allSessions: cachedActiveSessions,
                    targetDay: effectiveTargetDay,
                    dynamicSlots: _dynamicSlots,
                    onTap: () {
                      _showRoomDetailModal(context, a, isDark);
                    },
                  ),
                );
              },
              childCount: _filteredRooms.length,
            ),
          ),
        ),
    ];
  }

  Widget _buildTimeTravelerDeck(bool isDark) {
    final now = DateTime.now();
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    final deckContent = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
          _buildSearchDeck(isDark),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildSectionHeader('SELECT TARGET DAY', isDark),
              if (_targetDay != null && _targetDay != now.weekday)
                GestureDetector(
                  onTap: () {
                    IrisHaptics.chipSelect();
                    setState(() {
                      _targetDay = null;
                    });
                    _recomputeAvailability();
                  },
                  child: const Text(
                    'Jump to Today',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: IrisTokens.brand,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 10),
          _buildDaySelector(isDark),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildSectionHeader('UNIVERSITY LECTURE SLOTS', isDark),
              if (_targetSlot != null)
                GestureDetector(
                  onTap: () {
                    IrisHaptics.chipSelect();
                    setState(() {
                      _targetSlot = null;
                      _targetHour = null;
                    });
                    _recomputeAvailability();
                  },
                  child: const Text(
                    'Clear Slot',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: IrisTokens.brand,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 10),
          _buildDynamicSlotsRow(isDark),
        ],
      );

    if (isM3) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isDark ? cs.surfaceContainer : cs.surfaceContainerLow,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.5),
            width: 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.16 : 0.04),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: deckContent,
      );
    }

    return GlassCard(
      padding: const EdgeInsets.all(16),
      borderRadius: 24,
      child: deckContent,
    );
  }

  Widget _buildBentoQuickFilterBar(bool isDark) {
    final quickFilterPills = [
      {'label': '⚡ Free Now', 'value': 'Vacant'},
      {'label': '🧪 Labs Only', 'value': 'Labs'},
      {'label': '🤫 Quiet Study', 'value': 'Quiet'},
      {'label': '🏢 All Spaces', 'value': 'All'},
      {'label': '🔴 Occupied', 'value': 'Occupied'},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader('QUICK SPACE FILTERS', isDark),
        const SizedBox(height: 10),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          child: Row(
            children: quickFilterPills.map((filter) {
              final isSelected = _filterStatus == filter['value'];
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(
                    filter['label']!,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 12.5,
                      color: isSelected
                          ? Colors.white
                          : (isDark ? Colors.white70 : Colors.black87),
                    ),
                  ),
                  selected: isSelected,
                  onSelected: (selected) {
                    if (selected) {
                      IrisHaptics.chipSelect();
                      setState(() {
                        _filterStatus = filter['value']!;
                      });
                      _applyFilters();
                    }
                  },
                  selectedColor: IrisTokens.brand,
                  backgroundColor: isDark
                      ? Colors.white.withValues(alpha: 0.05)
                      : Colors.black.withValues(alpha: 0.03),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  side: BorderSide(
                    color: isSelected
                        ? IrisTokens.brandLight.withValues(alpha: 0.3)
                        : (isDark
                            ? Colors.white.withValues(alpha: 0.08)
                            : Colors.black.withValues(alpha: 0.08)),
                    width: 1.2,
                  ),
                  showCheckmark: false,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                ),
              );
            }).toList(),
          ),
        ),
        if (_buildings.length > 1) ...[
          const SizedBox(height: 16),
          _buildSectionHeader('BUILDING BLOCKS', isDark),
          const SizedBox(height: 10),
          _buildHorizontalPillRow(
            items: _buildings,
            selectedValue: _filterBuilding,
            onSelected: (val) {
              setState(() {
                _filterBuilding = val;
              });
              _applyFilters();
            },
            isDark: isDark,
          ),
        ],
      ],
    );
  }

  Widget _buildDaySelector(bool isDark) {
    final currentDay = _targetDay ?? DateTime.now().weekday;
    final todayWeekday = DateTime.now().weekday;

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      physics: const BouncingScrollPhysics(),
      child: Row(
        children: List.generate(_days.length, (index) {
          final dayNum = index + 1;
          final isSelected = dayNum == currentDay;
          final isToday = dayNum == todayWeekday;
          final dayLabel = _days[index];

          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ChoiceChip(
              label: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    dayLabel,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 13,
                      color: isSelected
                          ? Colors.white
                          : (isDark ? Colors.white70 : Colors.black87),
                    ),
                  ),
                  if (isToday) ...[
                    const SizedBox(width: 4),
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: isSelected ? Colors.white : IrisTokens.brand,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ],
                ],
              ),
              selected: isSelected,
              onSelected: (selected) {
                if (selected) {
                  IrisHaptics.chipSelect();
                  _targetDay = dayNum;
                  _recomputeAvailability();
                }
              },
              selectedColor: IrisTokens.brand,
              backgroundColor: isDark
                  ? Colors.white.withValues(alpha: 0.05)
                  : Colors.black.withValues(alpha: 0.03),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              side: BorderSide(
                color: isSelected
                    ? IrisTokens.brandLight.withValues(alpha: 0.3)
                    : (isDark
                        ? Colors.white.withValues(alpha: 0.08)
                        : Colors.black.withValues(alpha: 0.08)),
                width: 1.2,
              ),
              showCheckmark: false,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildDynamicSlotsRow(bool isDark) {
    if (_dynamicSlots.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Text(
          'No scheduled slots on this day',
          style: TextStyle(
            fontSize: 12,
            color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.4),
          ),
        ),
      );
    }

    final now = DateTime.now();
    final currentHour = now.hour + (now.minute / 60.0);
    final isToday = (_targetDay ?? now.weekday) == now.weekday;

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      physics: const BouncingScrollPhysics(),
      child: Row(
        children: List.generate(_dynamicSlots.length, (index) {
          final slot = _dynamicSlots[index];
          final isSelected = _targetSlot == index;
          final isLiveNow = isToday &&
              slot.start <= currentHour &&
              currentHour < slot.end;

          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: RoomFilterChip(
              label: slot.formatLabel(index),
              isSelected: isSelected,
              isLive: isLiveNow,
              onSelected: (s) {
                IrisHaptics.chipSelect();
                if (s) {
                  _targetSlot = index;
                  _targetHour = slot.start;
                } else {
                  _targetSlot = null;
                  _targetHour = null;
                }
                _recomputeAvailability();
              },
            ),
          );
        }),
      ),
    );
  }

  List<Widget> _buildExploreCampus(bool isDark) {
    if (_isLoadingDirectory) {
      return [
        SliverFillRemaining(
          child: Center(child: IrisComponents.loadingSpinner(size: 32)),
        )
      ];
    }
    if (_campusDirectory.isEmpty) {
      return [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              children: [
                Icon(
                  Icons.location_off_rounded,
                  size: 64,
                  color: (isDark ? Colors.white : Colors.black)
                      .withValues(alpha: 0.2),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Campus Directory Offline',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 8),
                Text(
                  'Could not load campus data.',
                  style: TextStyle(
                    color: (isDark ? Colors.white : Colors.black)
                        .withValues(alpha: 0.5),
                  ),
                ),
              ],
            ),
          ),
        )
      ];
    }

    return [
      SliverPadding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        sliver: SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Text(
              'CAMPUS ARCHITECTURAL BLOCKS',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.2,
                color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.45),
              ),
            ),
          ),
        ),
      ),
      SliverPadding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        sliver: SliverLayoutBuilder(
          builder: (context, constraints) {
            final screenWidth = constraints.crossAxisExtent;
            final crossCount = screenWidth >= 800 ? 4 : (screenWidth >= 520 ? 3 : 2);
            final childRatio = screenWidth >= 800 ? 1.05 : (screenWidth >= 520 ? 0.98 : 0.92);
            return SliverGrid(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: crossCount,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: childRatio,
              ),
              delegate: SliverChildBuilderDelegate(
            (context, index) {
              final b = _campusDirectory[index];
              final cleanName = b.name.toLowerCase().replaceAll('block', '').trim();
              final freeRoomsInBuilding = _allAvailability.where((a) {
                final bName = a.building.toLowerCase();
                return (bName.contains(cleanName) || a.roomId.toLowerCase().startsWith(cleanName)) && a.isAvailable;
              }).length;

              final style = ThemeSignals.themeStyle.value;
              final isM3 = style == IrisThemeStyle.materialYou;
              final cs = Theme.of(context).colorScheme;

              final Color titleColor;
              final Color subtitleColor;
              final Color cardBg;
              final double cardRadius;
              switch (style) {
                case IrisThemeStyle.notebook:
                  titleColor = NotebookTokens.inkHeading(isDark);
                  subtitleColor = NotebookTokens.inkMuted(isDark);
                  cardBg = NotebookTokens.cardSurface(isDark);
                  cardRadius = 6.0;
                  break;
                case IrisThemeStyle.line:
                  titleColor = LineTokens.inkHeading(isDark);
                  subtitleColor = LineTokens.inkMuted(isDark);
                  cardBg = LineTokens.cardSurface(isDark);
                  cardRadius = 12.0;
                  break;
                case IrisThemeStyle.poster:
                  titleColor = PosterTokens.inkHeading(isDark);
                  subtitleColor = PosterTokens.inkMuted(isDark);
                  cardBg = PosterTokens.cardSurface(isDark);
                  cardRadius = 0.0;
                  break;
                case IrisThemeStyle.almanac:
                  titleColor = AlmanacTokens.inkHeading(isDark);
                  subtitleColor = AlmanacTokens.inkMuted(isDark);
                  cardBg = AlmanacTokens.cardSurface(isDark);
                  cardRadius = 0.0;
                  break;
                case IrisThemeStyle.editorialAcademic:
                  titleColor = EditorialTokens.inkHeading(isDark);
                  subtitleColor = EditorialTokens.inkMuted(isDark);
                  cardBg = EditorialTokens.cardSurface(isDark);
                  cardRadius = 20.0;
                  break;
                case IrisThemeStyle.materialYou:
                  titleColor = cs.onSurface;
                  subtitleColor = cs.onSurfaceVariant;
                  cardBg = isDark ? cs.surfaceContainer : cs.surfaceContainerLow;
                  cardRadius = 24.0;
                  break;
                case IrisThemeStyle.fluidGlass:
                  titleColor = isDark ? Colors.white : Colors.black;
                  subtitleColor = (isDark ? Colors.white : Colors.black).withValues(alpha: 0.5);
                  cardBg = isDark ? const Color(0xFF131722) : Colors.white;
                  cardRadius = 24.0;
                  break;
              }

              final buildingCardContent = Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: isM3 ? cs.secondaryContainer : IrisTokens.brand.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Icon(
                          _getIconForBuildingType(b.type),
                          color: isM3 ? cs.onSecondaryContainer : IrisTokens.brand,
                          size: 24,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: (freeRoomsInBuilding > 0
                              ? (isM3 ? cs.primaryContainer : const Color(0xFF10B981).withValues(alpha: 0.12))
                              : (isM3 ? cs.surfaceContainerHighest : Colors.grey.withValues(alpha: 0.12))),
                          borderRadius: BorderRadius.circular(isM3 ? 999 : 8),
                        ),
                        child: Text(
                          freeRoomsInBuilding > 0 ? '$freeRoomsInBuilding free' : 'Full',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            color: freeRoomsInBuilding > 0
                                ? (isM3 ? cs.onPrimaryContainer : const Color(0xFF10B981))
                                : (isM3 ? cs.onSurfaceVariant : Colors.grey),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  Text(
                    b.name,
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 16,
                      letterSpacing: -0.4,
                      color: titleColor,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${b.floors.length} Floors · ${b.departments.length} Depts',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: subtitleColor,
                    ),
                  ),
                ],
              );

              if (isM3) {
                return InkWell(
                  onTap: () {
                    _showBuildingDetailModal(context, b, isDark);
                  },
                  borderRadius: BorderRadius.circular(24),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: isDark ? cs.surfaceContainer : cs.surfaceContainerLow,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(
                        color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.5),
                        width: 1.0,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: isDark ? 0.14 : 0.03),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: buildingCardContent,
                  ),
                );
              }

              return GlassCard(
                onTap: () {
                  _showBuildingDetailModal(context, b, isDark);
                },
                backgroundColor: cardBg,
                borderRadius: cardRadius,
                padding: const EdgeInsets.all(16),
                child: buildingCardContent,
              );
            },
            childCount: _campusDirectory.length,
          ),
        );
      },
    ),
  ),
];
  }

  IconData _getIconForBuildingType(String type) {
    switch (type.toLowerCase()) {
      case 'academic':
        return Icons.menu_book_rounded;
      case 'administrative':
        return Icons.business_center_rounded;
      case 'library':
        return Icons.local_library_rounded;
      case 'cafeteria':
        return Icons.restaurant_rounded;
      case 'hostel':
        return Icons.hotel_rounded;
      case 'sports':
        return Icons.sports_basketball_rounded;
      default:
        return Icons.domain_rounded;
    }
  }

  void _showBuildingDetailModal(
    BuildContext context,
    CampusBuilding b,
    bool isDark,
  ) {
    BuildingDetailSheet.show(context, b, isDark);
  }

  void _showRoomDetailModal(
    BuildContext context,
    RoomAvailability availability,
    bool isDark,
  ) {
    final targetDay = _targetDay ?? DateTime.now().weekday;
    final dayName = _days[targetDay - 1];
    final roomSessions = _service.getRoomSchedule(
      _activeMemory.activeSessions(),
      availability.roomId,
      targetDay,
    );
    RoomDetailSheet.show(
      context,
      availability: availability,
      roomSessions: roomSessions,
      targetDay: targetDay,
      dayName: dayName,
      isDark: isDark,
    );
  }

  Widget _buildOccupancyConsoleCard({
    required int free,
    required int total,
    required int freeHalls,
    required int freeLabs,
    required double percent,
    required bool isDark,
  }) {
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    final consoleContent = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(
                            color: Color(0xFF10B981),
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'CAMPUS SPACE RADAR',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.5,
                            color: (isDark ? Colors.white : Colors.black)
                                .withValues(alpha: 0.45),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Text(
                      '$free Rooms Vacant',
                      style: const TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.6,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Out of $total registered slots on campus',
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                        color: (isDark ? Colors.white : Colors.black)
                            .withValues(alpha: 0.5),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 14),
              SizedBox(
                width: 84,
                height: 84,
                child: RepaintBoundary(
                  child: CustomPaint(
                    painter: OccupancyDonutPainter(
                      percent: percent,
                      color: percent >= 0.5
                          ? const Color(0xFF10B981)
                          : (percent >= 0.25
                              ? const Color(0xFFF59E0B)
                              : const Color(0xFFEF4444)),
                      isDark: isDark,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.04),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.06),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Row(
                  children: [
                    const Icon(Icons.school_rounded, size: 16, color: IrisTokens.brand),
                    const SizedBox(width: 6),
                    Text(
                      'Halls: ',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.5),
                      ),
                    ),
                    Text(
                      '$freeHalls free',
                      style: const TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF10B981),
                      ),
                    ),
                  ],
                ),
                Container(
                  width: 1,
                  height: 16,
                  color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.1),
                ),
                Row(
                  children: [
                    const Icon(Icons.computer_rounded, size: 16, color: IrisTokens.purple),
                    const SizedBox(width: 6),
                    Text(
                      'Labs: ',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.5),
                      ),
                    ),
                    Text(
                      '$freeLabs free',
                      style: const TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF10B981),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (_recommendation.recommended != null && _targetHour == null && _targetSlot == null) ...[
            const SizedBox(height: 14),
            InkWell(
              onTap: () {
                _showRoomDetailModal(context, _recommendation.recommended!, isDark);
              },
              borderRadius: BorderRadius.circular(16),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: IrisTokens.brand.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: IrisTokens.brand.withValues(alpha: 0.25),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: IrisTokens.brand,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(
                        Icons.auto_awesome_rounded,
                        size: 14,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'SMART PICK: ${_recommendation.recommended!.roomId}',
                            style: const TextStyle(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w900,
                              color: IrisTokens.brand,
                              letterSpacing: 0.5,
                            ),
                          ),
                          Text(
                            _recommendation.reason,
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.6),
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    const Icon(
                      Icons.arrow_forward_ios_rounded,
                      size: 12,
                      color: IrisTokens.brand,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      );

    if (isM3) {
      return Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: isDark ? cs.surfaceContainer : cs.surfaceContainerLow,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(
            color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.5),
            width: 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.16 : 0.04),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: consoleContent,
      );
    }

    return GlassCard(
      padding: const EdgeInsets.all(22),
      borderRadius: 28,
      child: consoleContent,
    );
  }

  Widget _buildSearchDeck(bool isDark) {
    return Row(
      children: [
        Expanded(
          child: IrisGlowingInputWrapper(
            borderRadius: 20,
            child: GlassCard(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              borderRadius: 20,
              child: TextField(
                controller: _searchController,
                onChanged: (v) {
                  _query = v;
                  _applyFilters();
                },
                style: const TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                ),
                decoration: InputDecoration(
                  hintText: 'Search room, lab, or block...',
                  prefixIcon:
                      const Icon(Icons.search_rounded, color: IrisTokens.brand),
                  suffixIcon: _query.isNotEmpty
                      ? IconButton(
                          icon: const Icon(Icons.clear_rounded, size: 18),
                          onPressed: () {
                            _searchController.clear();
                            _query = '';
                            _applyFilters();
                          },
                        )
                      : null,
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  hintStyle: TextStyle(
                    color: (isDark ? Colors.white : Colors.black)
                        .withValues(alpha: 0.35),
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        _buildTimePicker(context, isDark),
      ],
    );
  }

  Widget _buildHorizontalPillRow({
    required List<String> items,
    required String selectedValue,
    required ValueChanged<String> onSelected,
    required bool isDark,
  }) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      physics: const BouncingScrollPhysics(),
      child: Row(
        children: items.map((item) {
          final isSelected = item == selectedValue;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ChoiceChip(
              label: Text(
                item,
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 13,
                  color: isSelected
                      ? Colors.white
                      : (isDark ? Colors.white70 : Colors.black87),
                ),
              ),
              selected: isSelected,
              onSelected: (selected) {
                if (selected) {
                  IrisHaptics.chipSelect();
                  onSelected(item);
                }
              },
              selectedColor: IrisTokens.brand,
              backgroundColor: isDark
                  ? Colors.white.withValues(alpha: 0.05)
                  : Colors.black.withValues(alpha: 0.03),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              side: BorderSide(
                color: isSelected
                    ? IrisTokens.brandLight.withValues(alpha: 0.3)
                    : (isDark
                        ? Colors.white.withValues(alpha: 0.08)
                        : Colors.black.withValues(alpha: 0.08)),
                width: 1.2,
              ),
              showCheckmark: false,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildTimePicker(BuildContext context, bool isDark) {
    final active = _targetHour != null;
    return Container(
      decoration: BoxDecoration(
        color: active
            ? IrisTokens.brand.withValues(alpha: 0.16)
            : (isDark
                ? Colors.white.withValues(alpha: 0.04)
                : Colors.black.withValues(alpha: 0.03)),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: active
              ? IrisTokens.brand.withValues(alpha: 0.4)
              : (isDark ? Colors.white10 : Colors.black12),
          width: 1.2,
        ),
      ),
      child: IconButton(
        onPressed: () async {
          final time = await showTimePicker(
            context: context,
            initialTime: TimeOfDay.now(),
          );
          if (time != null) {
            IrisHaptics.actionSoft();
            setState(() {
              _targetHour = time.hour + time.minute / 60.0;
              _targetSlot = null;
            });
            _recomputeAvailability();
            AnalyticsManager().trackEvent('room_pick_time', properties: {
              'hour': time.hour,
              'minute': time.minute,
            });
          }
        },
        icon: Icon(
          active ? Icons.history_toggle_off_rounded : Icons.access_time_rounded,
          color: active
              ? IrisTokens.brand
              : (isDark ? Colors.white70 : Colors.black87),
        ),
      ),
    );
  }



  Widget _buildSectionHeader(String title, bool isDark) {
    return Text(
      title,
      style: TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w900,
        letterSpacing: 1.5,
        color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.4),
      ),
    );
  }

  Widget _buildEmptyState(bool isDark) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 48),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.search_off_rounded,
            size: 64,
            color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.2),
          ),
          const SizedBox(height: 16),
          const Text(
            'No Vacant Rooms Found',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 8),
          Text(
            'Try altering day or building filter configurations.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color:
                  (isDark ? Colors.white : Colors.black).withValues(alpha: 0.5),
            ),
          ),
          const SizedBox(height: 16),
          TextButton.icon(
            onPressed: _resetFilters,
            icon: const Icon(Icons.refresh_rounded, size: 16),
            label: const Text('Reset All Filters'),
          ),
        ],
      ),
    );
  }
}

