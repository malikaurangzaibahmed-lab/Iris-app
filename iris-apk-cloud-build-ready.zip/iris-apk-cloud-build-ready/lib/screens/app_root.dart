import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:home_widget/home_widget.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/app_signals.dart';
import '../core/models.dart';
import '../core/omni_brain.dart';
import '../core/tokens.dart';
import '../services/system_broadcast_service.dart';
import '../services/ui_feedback.dart';
import '../widgets/iris_components.dart';
import 'dashboard_screen.dart';
import 'package:iris/screens/faculty/faculty_dashboard_screen.dart';
import 'package:iris/screens/onboarding/onboarding_wizard_screen.dart';
import 'package:iris/screens/settings/tutorial_screen.dart';

class AppRoot extends StatefulWidget {
  final UniversityMemory memory;
  final VoidCallback onToggleTheme;
  final Future<void> Function(String mode) onSetThemeMode;
  final String currentThemeMode;

  const AppRoot({
    super.key,
    required this.memory,
    required this.onToggleTheme,
    required this.onSetThemeMode,
    required this.currentThemeMode,
  });

  @override
  State<AppRoot> createState() => _AppRootState();
}

class _AppRootState extends State<AppRoot> {
  late final OmniBrain _brain;
  String? _selectedBatch;
  String? _userRole;
  String? _userName;
  bool? _tutorialCompleted;
  late VoidCallback _roleListener;

  @override
  void initState() {
    super.initState();
    _brain = OmniBrain(widget.memory);
    _roleListener = () {
      final role = AppSignals.roleNotifier.value;
      if (role != null) {
        _saveUserRole(role);
        AppSignals.roleNotifier.value = null;
      }
    };
    AppSignals.roleNotifier.addListener(_roleListener);
    _loadStartupPreferences();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _requestForegroundNotificationPermission();
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _precacheCoreAtmospheres();
      Future.delayed(const Duration(milliseconds: 900), () async {
        if (mounted) {
          final prefs = await SharedPreferences.getInstance();
          final daroodEnabled = prefs.getBool('darood_pak_reminder_enabled') ?? true;
          if (daroodEnabled) {
            IrisHaptics.actionSoft();
            _showDaroodePakDialog();
          }
        }
      });
    });
  }

  void _precacheCoreAtmospheres() {
    if (!mounted) return;
    const assets = [
      'assets/headers/header_classes_day.jpg',
      'assets/headers/header_classes_night.jpg',
      'assets/headers/header_sports_gala.jpg',
      'assets/headers/header_ramadan_mode.jpg',
      'assets/headers/header_faculty_hub.jpg',
      'assets/headers/header_academics_hub.jpg',
      'assets/headers/header_finals_week.jpg',
      'assets/headers/header_iris_hub.jpg',
      'assets/headers/header_midterms_mode.jpg',
      'assets/headers/header_room_finder.jpg',
      'assets/headers/header_vacation_mode.jpg',
    ];
    for (final asset in assets) {
      precacheImage(AssetImage(asset), context).catchError((_) {});
    }
  }

  @override
  void dispose() {
    AppSignals.roleNotifier.removeListener(_roleListener);
    super.dispose();
  }

  Future<void> _loadStartupPreferences() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      // Streamlined first-boot flow: launch directly into the interactive OnboardingWizard
      // instead of blocking new users behind a redundant 5-page TutorialScreen first.
      if (!prefs.containsKey('tutorial_completed')) {
        await prefs.setBool('tutorial_completed', true);
      }
      final tutorial = prefs.getBool('tutorial_completed') ?? true;
      final role = prefs.getString('user_role');
      var batch = prefs.getString('user_batch') ??
          prefs.getString('student_batch') ??
          prefs.getString('selected_batch');
      if (batch != null &&
          (batch.contains('{') ||
              batch.contains('\n') ||
              batch.contains('courses') ||
              batch.contains('CIIT/') ||
              batch.length > 25)) {
        batch = prefs.getString('promoted_from_batch') ??
            (_brain.memory.allBatches.isNotEmpty ? _brain.memory.allBatches.first : '');
        if (batch.isNotEmpty) {
          await prefs.setString('user_batch', batch);
          await prefs.setString('student_batch', batch);
          await prefs.setString('selected_batch', batch);
        }
      }

      String? userName;
      if (role == 'faculty') {
        userName =
            prefs.getString('faculty_user_name') ??
            prefs.getString('faculty_teacher');
      } else {
        userName = prefs.getString('student_user_name');
      }

      if (role != 'faculty' && batch != null && batch.isNotEmpty) {
        await _brain.reloadRepeaterSessions(batch);
      }

      if (!mounted) return;
      setState(() {
        _tutorialCompleted = tutorial;
        _userRole = role;
        _selectedBatch = batch;
        _userName = userName;
      });

      final isFirstSetup = prefs.getBool('widget_prompt_shown') != true;
      final isStudentOnboarded =
          role == 'student' && batch != null && userName != null;
      final isFacultyOnboarded = role == 'faculty' && userName != null;
      final isOnboarded = isStudentOnboarded || isFacultyOnboarded;

      if (isFirstSetup && isOnboarded) {
        Future.delayed(const Duration(milliseconds: 6500), () {
          if (mounted) {
            _showWidgetSetupPrompt();
          }
        });
      }
    } catch (e) {
      debugPrint('⚠️ Error loading startup preferences: $e');
    }
  }

  Future<void> _completeTutorial() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('tutorial_completed', true);
    setState(() {
      _tutorialCompleted = true;
    });
  }

  void _showDaroodePakDialog() {
    final now = DateTime.now();
    final hour = now.hour;
    final isFriday = now.weekday == DateTime.friday;
    final greeting = isFriday
        ? 'Jummah Mubarak — Send Darood upon the Prophet ﷺ'
        : (hour >= 5 && hour < 12
              ? 'Start your morning with blessings · Darood e Pak'
              : hour >= 12 && hour < 17
              ? 'Afternoon reminder for Darood e Pak'
              : hour >= 17 && hour < 21
              ? 'Evening blessings upon the Prophet ﷺ'
              : 'Night reminder — Send Darood e Pak');

    SystemBroadcastService().triggerLocalOverride(
      'Darood e Pak 🕌',
      greeting,
      isUrgent: false,
      duration: const Duration(seconds: 5),
    );
  }

  Future<void> _requestForegroundNotificationPermission() async {
    if (!Platform.isAndroid) {
      return;
    }

    final permission =
        await FlutterForegroundTask.checkNotificationPermission();
    if (permission != NotificationPermission.granted) {
      await FlutterForegroundTask.requestNotificationPermission();
    }

    try {
      if (!await FlutterForegroundTask.isIgnoringBatteryOptimizations) {
        await FlutterForegroundTask.requestIgnoreBatteryOptimization();
      }
    } catch (e) {
      debugPrint('Battery optimization ignore error: $e');
    }
  }

  Future<void> _saveBatch(String batch) async {
    final prefs = await SharedPreferences.getInstance();
    final trimmed = batch.trim();
    await prefs.setString('user_batch', trimmed);
    await prefs.setString('student_batch', trimmed);
    await prefs.setString('selected_batch', trimmed);

    await _brain.reloadRepeaterSessions(trimmed);

    final isFirstSetup = prefs.getBool('widget_prompt_shown') != true;
    setState(() => _selectedBatch = trimmed);

    if (isFirstSetup && mounted) {
      await Future.delayed(const Duration(milliseconds: 500));
      if (mounted) {
        await _showWidgetSetupPrompt();
      }
    }
  }

  Future<void> _showWidgetSetupPrompt() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('widget_prompt_shown', true);
    if (!mounted) return;

    IrisHaptics.actionSoft();

    SystemBroadcastService().triggerLocalOverride(
      'Home Screen Widget 📱',
      'Tap to add the Live Class Tracker to your home screen',
      icon: Icons.widgets_rounded,
      duration: const Duration(seconds: 8),
      onTap: () {
        if (!mounted) return;
        _showWidgetSetupSheet();
      },
    );
  }

  void _showWidgetSetupSheet() {
    IrisModalSheet.show(
      context: context,
      builder: (sheetContext) {
        final isDark = Theme.of(sheetContext).brightness == Brightness.dark;
        return Padding(
          padding: const EdgeInsets.fromLTRB(24, 16, 24, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  decoration: BoxDecoration(
                    color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [IrisTokens.blue, IrisTokens.brand],
                  ),
                  borderRadius: BorderRadius.circular(IrisTokens.radius20),
                  boxShadow: [
                    BoxShadow(
                      color: IrisTokens.brand.withValues(alpha: 0.3),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.widgets_rounded,
                  size: 36,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'IRIS Class Tracker Widget',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: isDark ? Colors.white : Colors.black,
                  letterSpacing: 0.3,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 6),
              Text(
                'Keep your live lecture status and next class visible right on your Android home screen.',
                style: TextStyle(
                  fontSize: 13,
                  color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.65),
                  height: 1.4,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.04),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.08),
                  ),
                ),
                child: Column(
                  children: [
                    _buildStep(isDark, '1', 'Long-press any empty space on your home screen'),
                    const SizedBox(height: 10),
                    _buildStep(isDark, '2', 'Tap "Widgets" in the popup menu'),
                    const SizedBox(height: 10),
                    _buildStep(isDark, '3', 'Scroll or search for "IRIS"'),
                    const SizedBox(height: 10),
                    _buildStep(isDark, '4', 'Drag "Class Tracker" onto your screen'),
                  ],
                ),
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.of(sheetContext).pop(),
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      child: Text(
                        'Got It',
                        style: TextStyle(
                          color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.6),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: ElevatedButton.icon(
                      onPressed: () async {
                        Navigator.of(sheetContext).pop();
                        try {
                          await HomeWidget.requestPinWidget(
                            name: 'ClassTrackerWidget',
                            androidName: 'ClassTrackerWidget',
                          );
                        } catch (e) {
                          debugPrint('requestPinWidget error: $e');
                        }
                      },
                      icon: const Icon(Icons.push_pin_rounded, size: 18),
                      label: const Text('Pin to Home'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: IrisTokens.brand,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                        elevation: 0,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStep(bool isDark, String number, String text) {
    return Row(
      children: [
        Container(
          width: 26,
          height: 26,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                IrisTokens.error.withValues(alpha: 0.8),
                IrisTokens.error,
              ],
            ),
            border: Border.all(
              color: IrisTokens.error.withValues(alpha: 0.4),
              width: 0.5,
            ),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: IrisTokens.error.withValues(alpha: 0.3),
                offset: const Offset(0, 2),
                blurRadius: 8,
                spreadRadius: -2,
              ),
            ],
          ),
          child: Center(
            child: Text(
              number,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w500,
              color: (isDark ? Colors.white : Colors.black).withValues(
                alpha: 0.7,
              ),
              height: 1.3,
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _saveUserRole(String role) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_role', role);

    if (await FlutterForegroundTask.isRunningService) {
      await FlutterForegroundTask.stopService();
      await Future.delayed(const Duration(milliseconds: 300));
    }

    String? newUserName;
    if (role == 'faculty') {
      newUserName =
          prefs.getString('faculty_user_name') ??
          prefs.getString('faculty_teacher');
      if (newUserName == null || newUserName.isEmpty) {
        final all = _brain.allTeachers();
        if (all.isNotEmpty) {
          newUserName = all.first;
          await prefs.setString('faculty_user_name', newUserName);
          await prefs.setString('faculty_teacher', newUserName);
        }
      }
    } else {
      newUserName =
          prefs.getString('student_user_name') ??
          prefs.getString('student_name');
    }

    setState(() {
      _userRole = role;
      if (newUserName != null && newUserName.isNotEmpty) {
        _userName = newUserName;
      }
    });
  }

  Future<void> _completeOnboarding(
    String role,
    String name,
    String value,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_role', role);
    if (role == 'faculty') {
      await prefs.setString('faculty_user_name', name);
      await prefs.setString('faculty_teacher', value);

      if (await FlutterForegroundTask.isRunningService) {
        await FlutterForegroundTask.stopService();
        await Future.delayed(const Duration(milliseconds: 300));
      }

      setState(() {
        _userRole = role;
        _userName = name;
      });
    } else {
      await prefs.setString('student_user_name', name);
      final trimmedBatch = value.trim();
      await prefs.setString('user_batch', trimmedBatch);
      await prefs.setString('student_batch', trimmedBatch);
      await prefs.setString('selected_batch', trimmedBatch);

      await _brain.reloadRepeaterSessions(trimmedBatch);

      final isFirstSetup = prefs.getBool('widget_prompt_shown') != true;

      setState(() {
        _userRole = role;
        _userName = name;
        _selectedBatch = trimmedBatch;
      });

      if (isFirstSetup && mounted) {
        await Future.delayed(const Duration(milliseconds: 500));
        if (mounted) {
          await _showWidgetSetupPrompt();
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_tutorialCompleted == null) {
      return Scaffold(body: Center(child: IrisComponents.loadingSpinner(size: 32)));
    }

    if (_tutorialCompleted == false) {
      return TutorialScreen(onComplete: _completeTutorial);
    }

    final isStudentOnboarded =
        _userRole == 'student' && _selectedBatch != null && _userName != null;
    final isFacultyOnboarded = _userRole == 'faculty' && _userName != null;
    final isOnboarded = isStudentOnboarded || isFacultyOnboarded;

    if (!isOnboarded) {
      return OnboardingWizard(
        memory: widget.memory,
        onComplete: _completeOnboarding,
        onSetThemeMode: widget.onSetThemeMode,
        currentThemeMode: widget.currentThemeMode,
      );
    }

    final Widget roleView = _userRole == 'faculty'
        ? KeyedSubtree(
            key: const ValueKey('faculty_dashboard_role'),
            child: FacultyDashboard(
              brain: _brain,
              teacherName: _userName ?? '',
              onToggleTheme: widget.onToggleTheme,
              onSetThemeMode: widget.onSetThemeMode,
              currentThemeMode: widget.currentThemeMode,
              onRoleChanged: _saveUserRole,
              onBatchChanged: _saveBatch,
              onTeacherChanged: (name) => setState(() => _userName = name),
            ),
          )
        : KeyedSubtree(
            key: const ValueKey('student_dashboard_role'),
            child: Dashboard(
              memory: widget.memory,
              brain: _brain,
              batch: _selectedBatch!,
              onToggleTheme: widget.onToggleTheme,
              onSetThemeMode: widget.onSetThemeMode,
              currentThemeMode: widget.currentThemeMode,
              userName: _userName,
              onUserNameChanged: (name) => setState(() => _userName = name),
              onRoleChanged: _saveUserRole,
              onChangeBatch: () => setState(() => _selectedBatch = null),
              onBatchChanged: _saveBatch,
            ),
          );

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 260),
      switchInCurve: Curves.easeOutCubic,
      switchOutCurve: Curves.easeInCubic,
      transitionBuilder: (child, animation) {
        return FadeTransition(
          opacity: animation,
          child: RepaintBoundary(child: child),
        );
      },
      child: roleView,
    );
  }
}
