import 'package:flutter/material.dart';
import '../../core/tokens.dart';
import '../../core/vital_theme.dart';
import '../../core/omni_brain.dart';
import '../../core/theme_signals.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/iris_components.dart';
import '../../services/ui_feedback.dart';
import '../../services/helpdesk_faculty_service.dart';

String resolveFacultyImageUrl(String raw) {
  final image = raw.trim();
  if (image.isEmpty) return '';
  if (image.startsWith('http://') || image.startsWith('https://')) {
    return image;
  }
  const backendBase = 'https://cui-helpdesk-backend.onrender.com';
  if (image.startsWith('/')) return '$backendBase$image';
  return '$backendBase/$image';
}

class FacultyDetailScreen extends StatefulWidget {
  final FacultyProfile profile;
  final OmniBrain? brain;
  final VoidCallback onLaunchEmail;
  final VoidCallback onLaunchPhone;
  final bool isSelectionMode;
  final ValueChanged<String>? onTeacherSelected;

  const FacultyDetailScreen({
    super.key,
    required this.profile,
    required this.brain,
    required this.onLaunchEmail,
    required this.onLaunchPhone,
    this.isSelectionMode = false,
    this.onTeacherSelected,
  });

  @override
  State<FacultyDetailScreen> createState() => _FacultyDetailScreenState();
}

class _FacultyDetailScreenState extends State<FacultyDetailScreen> {
  int _selectedDay = DateTime.now().weekday; // 1: Mon .. 5: Fri
  int _viewSegmentIndex = 0; // 0 = Daily Timeline, 1 = Weekly Matrix

  @override
  void initState() {
    super.initState();
    if (_selectedDay < 1 || _selectedDay > 5) {
      _selectedDay = 1;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;
    final textPrimary = isM3 ? cs.onSurface : (isDark ? Colors.white : Colors.black87);
    final textSecondary = isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white : Colors.black).withValues(alpha: 0.6);
    final item = widget.profile;

    final TeacherLocatorResult? result = widget.brain?.locateTeacher(
      item.name,
      DateTime.now(),
      department: item.department,
    );

    final daySessions = result != null
        ? (result.weeklySchedule[_selectedDay] ?? [])
        : <TeacherScheduleEntry>[];

    final days = [
      {'idx': 1, 'name': 'Mon', 'fullName': 'Monday'},
      {'idx': 2, 'name': 'Tue', 'fullName': 'Tuesday'},
      {'idx': 3, 'name': 'Wed', 'fullName': 'Wednesday'},
      {'idx': 4, 'name': 'Thu', 'fullName': 'Thursday'},
      {'idx': 5, 'name': 'Fri', 'fullName': 'Friday'},
    ];

    int totalWeeklySessions = 0;
    if (result != null) {
      for (final list in result.weeklySchedule.values) {
        totalWeeklySessions += list.length;
      }
    }

    Widget buildHeroCardContent() {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              IrisComponents.facultyMonogramBadge(
                name: item.name,
                department: item.department,
                size: 72,
                isDark: isDark,
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.name,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: textPrimary,
                        letterSpacing: -0.2,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      item.department.isEmpty ? 'Academic Faculty' : item.department,
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                        color: textSecondary,
                      ),
                    ),
                    if (item.designation.trim().isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                        decoration: BoxDecoration(
                          color: isM3
                              ? cs.secondaryContainer
                              : IrisTokens.brand.withValues(alpha: isDark ? 0.18 : 0.09),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(
                            color: isM3
                                ? cs.secondaryContainer
                                : IrisTokens.brand.withValues(alpha: isDark ? 0.35 : 0.22),
                            width: 0.6,
                          ),
                        ),
                        child: Text(
                          item.designation.trim(),
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: isM3
                                ? cs.onSecondaryContainer
                                : (isDark ? IrisTokens.brandLight : IrisTokens.brand),
                          ),
                        ),
                      ),
                    ],
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Icon(
                          Icons.location_on_rounded,
                          size: 13,
                          color: isM3 ? cs.primary : IrisTokens.purple,
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            item.location.isEmpty ? 'COMSATS Campus' : item.location,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: textSecondary,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          // Quick Contact Action Bar
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: widget.onLaunchEmail,
                  icon: const Icon(Icons.mail_outline_rounded, size: 16),
                  label: const Text('Email Faculty'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: isM3 ? cs.primary : IrisTokens.brand,
                    side: BorderSide(
                      color: isM3 ? cs.primary.withValues(alpha: 0.35) : IrisTokens.brand.withValues(alpha: 0.35),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: widget.onLaunchPhone,
                  icon: const Icon(Icons.phone_outlined, size: 16),
                  label: const Text('Call Office'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: isM3 ? cs.tertiary : IrisTokens.success,
                    side: BorderSide(
                      color: isM3 ? cs.tertiary.withValues(alpha: 0.35) : IrisTokens.success.withValues(alpha: 0.35),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                ),
              ),
            ],
          ),
          if (widget.isSelectionMode && widget.onTeacherSelected != null) ...[
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: () {
                IrisHaptics.actionMedium();
                widget.onTeacherSelected!(item.name);
                Navigator.of(context).pop();
              },
              icon: const Icon(Icons.check_circle_rounded, size: 18),
              label: Text('Select ${item.name} as Active Profile'),
              style: ElevatedButton.styleFrom(
                backgroundColor: isM3 ? cs.primary : IrisTokens.brand,
                foregroundColor: isM3 ? cs.onPrimary : Colors.white,
                minimumSize: const Size.fromHeight(42),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 0,
              ),
            ),
          ],
          if (result != null && result.liveSession != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isM3
                    ? cs.primaryContainer
                    : IrisTokens.success.withValues(alpha: isDark ? 0.15 : 0.08),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: isM3
                      ? cs.primary.withValues(alpha: 0.4)
                      : IrisTokens.success.withValues(alpha: 0.4),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: isM3 ? cs.primary : IrisTokens.success,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'LIVE IN SESSION NOW',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            color: isM3 ? cs.onPrimaryContainer : IrisTokens.success,
                            letterSpacing: 0.6,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${result.liveSession!.subject} • Room ${result.liveSession!.room} (${result.liveSession!.batch})',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: isM3 ? cs.onPrimaryContainer : textPrimary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      );
    }

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        fit: StackFit.expand,
        children: [
          ObsidianPulse(isDark: isDark),
          SafeArea(
            child: Column(
          children: [
            // Top Navigation Bar
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () {
                      IrisHaptics.actionMedium();
                      Navigator.of(context).pop();
                    },
                    icon: Icon(
                      Icons.arrow_back_ios_new_rounded,
                      color: textPrimary,
                      size: 20,
                    ),
                    style: IconButton.styleFrom(
                      backgroundColor: isM3
                          ? cs.surfaceContainerHigh
                          : (isDark
                              ? Colors.white.withValues(alpha: 0.08)
                              : Colors.black.withValues(alpha: 0.05)),
                      padding: const EdgeInsets.all(10),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Faculty Profile & Schedule',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                            color: textPrimary,
                          ),
                        ),
                        Text(
                          item.department.isEmpty ? 'COMSATS Faculty Member' : item.department,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            color: textSecondary,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Hero Card (Monet container in M3 / Specular Glass in Liquid)
                    isM3
                        ? Container(
                            padding: const EdgeInsets.all(18),
                            decoration: BoxDecoration(
                              color: isDark ? cs.surfaceContainerLow : cs.surfaceContainer,
                              borderRadius: BorderRadius.circular(24),
                              border: Border.all(
                                color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.5),
                                width: 1.0,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: isDark ? 0.18 : 0.05),
                                  blurRadius: 10,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: buildHeroCardContent(),
                          )
                        : GlassCard(
                            child: buildHeroCardContent(),
                          ),
                    const SizedBox(height: 16),

                    // View Segmented Control (IrisSegmentedControl)
                    IrisSegmentedControl(
                      selectedIndex: _viewSegmentIndex,
                      onSegmentSelected: (index) {
                        IrisHaptics.selectionClick();
                        setState(() => _viewSegmentIndex = index);
                      },
                      segments: [
                        'Daily Timeline',
                        'Week Matrix ($totalWeeklySessions)',
                      ],
                    ),

                    const SizedBox(height: 16),

                    if (_viewSegmentIndex == 0) ...[
                      // Day Choice Chips (Mon - Fri)
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        physics: const BouncingScrollPhysics(),
                        child: Row(
                          children: days.map((d) {
                            final idx = d['idx'] as int;
                            final name = d['name'] as String;
                            final count = result?.weeklySchedule[idx]?.length ?? 0;
                            final isSelected = _selectedDay == idx;
                            return Padding(
                              padding: const EdgeInsets.only(right: 8),
                              child: ChoiceChip(
                                label: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(name),
                                    const SizedBox(width: 5),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 6,
                                        vertical: 1.5,
                                      ),
                                      decoration: BoxDecoration(
                                        color: isSelected
                                            ? Colors.white.withValues(alpha: 0.25)
                                            : (isDark ? Colors.white12 : Colors.black12),
                                        borderRadius: BorderRadius.circular(99),
                                      ),
                                      child: Text(
                                        '$count',
                                        style: TextStyle(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w900,
                                          color: isSelected ? Colors.white : textSecondary,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                selected: isSelected,
                                onSelected: (_) {
                                  IrisHaptics.chipSelect();
                                  setState(() => _selectedDay = idx);
                                },
                                selectedColor: IrisTokens.brand,
                                backgroundColor: isDark
                                    ? Colors.white.withValues(alpha: 0.05)
                                    : Colors.black.withValues(alpha: 0.03),
                                labelStyle: TextStyle(
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w800,
                                  color: isSelected ? Colors.white : textPrimary,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                  side: BorderSide(
                                    color: isSelected
                                        ? IrisTokens.brand
                                        : (isDark ? Colors.white10 : Colors.black12),
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ),

                      const SizedBox(height: 14),                      // Day Schedule Cards
                      if (daySessions.isEmpty)
                        isM3
                            ? Container(
                                padding: const EdgeInsets.symmetric(vertical: 24),
                                decoration: BoxDecoration(
                                  color: isDark ? cs.surfaceContainerLow : cs.surfaceContainer,
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                    color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.5),
                                    width: 1.0,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: isDark ? 0.18 : 0.05),
                                      blurRadius: 8,
                                      offset: const Offset(0, 2),
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: Column(
                                    children: [
                                      Icon(
                                        Icons.event_available_rounded,
                                        size: 40,
                                        color: textSecondary.withValues(alpha: 0.35),
                                      ),
                                      const SizedBox(height: 10),
                                      Text(
                                        'No lectures scheduled for this day.',
                                        style: TextStyle(
                                          fontSize: 13.5,
                                          fontWeight: FontWeight.w600,
                                          color: textSecondary,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            : GlassCard(
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 24),
                                  child: Center(
                                    child: Column(
                                      children: [
                                        Icon(
                                          Icons.event_available_rounded,
                                          size: 40,
                                          color: textSecondary.withValues(alpha: 0.35),
                                        ),
                                        const SizedBox(height: 10),
                                        Text(
                                          'No lectures scheduled for this day.',
                                          style: TextStyle(
                                            fontSize: 13.5,
                                            fontWeight: FontWeight.w600,
                                            color: textSecondary,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              )
                      else
                        ...daySessions.map((s) {
                          final isLive = s.isLive;
                          final cardContent = Row(
                            children: [
                              Container(
                                width: 4.5,
                                height: 44,
                                decoration: BoxDecoration(
                                  color: isLive ? IrisTokens.success : IrisTokens.brand,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      s.subject,
                                      style: TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.w800,
                                        color: textPrimary,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.schedule_rounded,
                                          size: 13,
                                          color: isLive ? IrisTokens.success : IrisTokens.brand,
                                        ),
                                        const SizedBox(width: 4),
                                        Text(
                                          '${s.startTime} - ${s.endTime}',
                                          style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w700,
                                            color: isLive ? IrisTokens.success : IrisTokens.brand,
                                          ),
                                        ),
                                        const SizedBox(width: 12),
                                        Icon(
                                          Icons.meeting_room_rounded,
                                          size: 13,
                                          color: textSecondary,
                                        ),
                                        const SizedBox(width: 4),
                                        Text(
                                          s.room,
                                          style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                            color: textSecondary,
                                          ),
                                        ),
                                        const SizedBox(width: 10),
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                          decoration: BoxDecoration(
                                            color: isM3
                                                ? cs.surfaceContainerHigh
                                                : (isDark ? Colors.white : Colors.black).withValues(alpha: 0.06),
                                            borderRadius: BorderRadius.circular(6),
                                          ),
                                          child: Text(
                                            s.batch,
                                            style: TextStyle(
                                              fontSize: 10.5,
                                              fontWeight: FontWeight.w700,
                                              color: textSecondary,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              if (isLive)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                  decoration: BoxDecoration(
                                    color: IrisTokens.success,
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: const Text(
                                    'LIVE',
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                      letterSpacing: 0.6,
                                    ),
                                  ),
                                ),
                            ],
                          );

                          return Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: isM3
                                ? Container(
                                    padding: const EdgeInsets.all(14),
                                    decoration: BoxDecoration(
                                      color: isDark ? cs.surfaceContainerLow : cs.surfaceContainer,
                                      borderRadius: BorderRadius.circular(18),
                                      border: Border.all(
                                        color: isLive
                                            ? IrisTokens.success.withValues(alpha: 0.4)
                                            : cs.outlineVariant.withValues(alpha: isDark ? 0.3 : 0.45),
                                        width: 1.0,
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black.withValues(alpha: isDark ? 0.16 : 0.04),
                                          blurRadius: 6,
                                          offset: const Offset(0, 2),
                                        ),
                                      ],
                                    ),
                                    child: cardContent,
                                  )
                                : GlassCard(child: cardContent),
                          );
                        }),
                    ] else ...[
                      // Full Week Matrix Bento View
                      ...days.map((d) {
                        final dayIdx = d['idx'] as int;
                        final dayFullName = d['fullName'] as String;
                        final sessions = result?.weeklySchedule[dayIdx] ?? [];

                        final matrixCardContent = Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  dayFullName.toUpperCase(),
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.1,
                                    color: isM3 ? cs.primary : IrisTokens.brand,
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: (isM3 ? cs.primary : IrisTokens.brand).withValues(alpha: 0.12),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    '${sessions.length} Lecture${sessions.length == 1 ? '' : 's'}',
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w800,
                                      color: isM3 ? cs.primary : IrisTokens.brand,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            if (sessions.isEmpty)
                              Text(
                                'No classes scheduled',
                                style: TextStyle(
                                  fontSize: 12.5,
                                  fontStyle: FontStyle.italic,
                                  color: textSecondary.withValues(alpha: 0.6),
                                ),
                              )
                            else
                              ...sessions.map((s) {
                                return Container(
                                  margin: const EdgeInsets.only(bottom: 8),
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: s.isLive
                                        ? IrisTokens.success.withValues(alpha: 0.12)
                                        : (isM3
                                            ? cs.surfaceContainerHigh
                                            : (isDark ? Colors.black26 : Colors.white)),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                      color: s.isLive
                                          ? IrisTokens.success.withValues(alpha: 0.35)
                                          : (isM3
                                              ? cs.outlineVariant.withValues(alpha: isDark ? 0.3 : 0.4)
                                              : (isDark
                                                  ? Colors.white.withValues(alpha: 0.06)
                                                  : Colors.black.withValues(alpha: 0.05))),
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              s.subject,
                                              style: TextStyle(
                                                fontSize: 13.5,
                                                fontWeight: FontWeight.w700,
                                                color: textPrimary,
                                              ),
                                            ),
                                            const SizedBox(height: 2),
                                            Text(
                                              '${s.startTime} - ${s.endTime}  •  ${s.room}  •  ${s.batch}',
                                              style: TextStyle(
                                                fontSize: 11.5,
                                                color: textSecondary,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      if (s.isLive)
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                          decoration: BoxDecoration(
                                            color: IrisTokens.success,
                                            borderRadius: BorderRadius.circular(6),
                                          ),
                                          child: const Text(
                                            'LIVE',
                                            style: TextStyle(
                                              fontSize: 9,
                                              fontWeight: FontWeight.w900,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                );
                              }),
                          ],
                        );

                        return Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: isM3
                              ? Container(
                                  padding: const EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                    color: isDark ? cs.surfaceContainerLow : cs.surfaceContainer,
                                    borderRadius: BorderRadius.circular(20),
                                    border: Border.all(
                                      color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.5),
                                      width: 1.0,
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withValues(alpha: isDark ? 0.16 : 0.04),
                                        blurRadius: 8,
                                        offset: const Offset(0, 2),
                                      ),
                                    ],
                                  ),
                                  child: matrixCardContent,
                                )
                              : GlassCard(child: matrixCardContent),
                        );
                      }),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
        ],
      ),
    );
  }
}
