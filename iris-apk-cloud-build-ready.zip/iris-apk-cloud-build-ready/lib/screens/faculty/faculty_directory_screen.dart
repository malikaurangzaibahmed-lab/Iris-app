import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/tokens.dart';
import '../../core/models.dart';
import '../../core/omni_brain.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/iris_components.dart';
import 'package:iris/widgets/controls/glowing_input_wrapper.dart';
import '../../core/vital_theme.dart';
import '../../core/animations.dart';
import '../../services/ui_feedback.dart';
import '../../services/helpdesk_faculty_service.dart';
import '../../services/remote_config_service.dart';
import 'package:iris/widgets/effects/glass_container_transform.dart';
import 'package:iris/widgets/controls/iris_liquid_button.dart';
import '../../core/theme_signals.dart';

import 'faculty_detail_screen.dart';
export 'faculty_detail_screen.dart';

class FacultyDirectoryScreen extends StatefulWidget {
  final OmniBrain? brain;
  final ValueChanged<String>? onTeacherSelected;
  final ValueChanged<String>? onRoleChanged;
  final ValueChanged<String>? onBatchChanged;
  final UniversityMemory? memory;
  final String? currentBatch;
  final String? initialTeacherQuery;
  final bool isSelectionMode;

  const FacultyDirectoryScreen({
    this.brain,
    this.onTeacherSelected,
    this.onRoleChanged,
    this.onBatchChanged,
    this.memory,
    this.currentBatch,
    this.initialTeacherQuery,
    this.isSelectionMode = false,
    super.key,
  });

  @override
  State<FacultyDirectoryScreen> createState() => _FacultyDirectoryScreenState();
}

class _FacultyDirectoryScreenState extends State<FacultyDirectoryScreen> {
  final HelpdeskFacultyService _service = HelpdeskFacultyService();
  late final TextEditingController _searchController;
  Timer? _searchDebounce;

  List<FacultyProfile> _all = const [];
  List<FacultyProfile> _filtered = const [];
  final Map<String, TeacherLocatorResult> _teacherInsightCache = {};
  final Map<String, String> _profileSearchIndex = {};
  final Map<String, String> _profileBlockIndex = {};
  bool _loading = true;
  String _error = '';
  String _query = '';
  String _selectedDepartment = 'All';
  String _selectedBlock = 'All';
  HelpdeskFacultySource _source = HelpdeskFacultySource.none;
  final ScrollController _scrollController = ScrollController();

  late final VoidCallback _remoteConfigListener;

  @override
  void initState() {
    super.initState();
    _searchController = TextEditingController(text: widget.initialTeacherQuery ?? '');
    _query = widget.initialTeacherQuery ?? '';

    // Fast-path: Instantly render if pure timetable profiles are already in memory
    if (HelpdeskFacultyService.hasCachedPureTimetableProfiles) {
      final cached = HelpdeskFacultyService.cachedPureTimetableProfiles;
      _all = cached;
      _filtered = cached;
      _loading = false;
      _buildSearchAndBlockIndices(cached);
      _applyFilter();
    }

    _remoteConfigListener = () {
      if (mounted) {
        setState(() {
          _teacherInsightCache.clear();
        });
      }
    };

    RemoteConfigService.activeAcademicPeriod.addListener(_remoteConfigListener);
    RemoteConfigService.lastTimetableUpdateTime.addListener(_remoteConfigListener);

    if (_all.isEmpty) {
      _loadFaculty();
    }
  }

  void _buildSearchAndBlockIndices(List<FacultyProfile> list) {
    _profileSearchIndex.clear();
    _profileBlockIndex.clear();
    for (final item in list) {
      final normalizedName = HelpdeskFacultyService.normalizeFacultyName(item.name);
      final aliasStr = item.aliases.join(' ').toLowerCase();
      final block = _blockFromLocation(item.location);
      _profileBlockIndex[item.id] = block;
      _profileSearchIndex[item.id] =
          '${item.name} $normalizedName $aliasStr ${item.designation} ${item.department} ${item.location} $block ${item.email} ${item.contact}'
              .toLowerCase();
    }
  }

  @override
  void dispose() {
    RemoteConfigService.activeAcademicPeriod.removeListener(_remoteConfigListener);
    RemoteConfigService.lastTimetableUpdateTime.removeListener(_remoteConfigListener);
    _searchDebounce?.cancel();
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _loadFaculty() async {
    // Instant Frame-0 Render: If timetable teachers are in memory, build and display immediately
    if (_all.isEmpty) {
      final timetableTeachers = widget.brain != null
          ? widget.brain!.allTeachers()
          : (widget.memory != null ? widget.memory!.allTeachers() : const <String>[]);
      final roomsMap = widget.brain?.getTeacherRoomsMap();
      final deptsMap = widget.brain?.getTeacherDepartmentsMap();

      if (timetableTeachers.isNotEmpty) {
        try {
          final instantList = HelpdeskFacultyService.buildPureTimetableProfiles(
            timetableTeachers: timetableTeachers,
            departmentLookup: deptsMap != null
                ? (teacher) {
                    final key = teacher.trim().toLowerCase();
                    final stripped = HelpdeskFacultyService.stripDepartmentPrefix(teacher).trim().toLowerCase();
                    return deptsMap[key] ?? deptsMap[stripped] ?? widget.brain?.departmentForTeacher(teacher);
                  }
                : widget.brain?.departmentForTeacher,
            roomsLookup: roomsMap != null
                ? (teacher) {
                    final key = teacher.trim().toLowerCase();
                    final stripped = HelpdeskFacultyService.stripDepartmentPrefix(teacher).trim().toLowerCase();
                    final set = roomsMap[key] ?? roomsMap[stripped];
                    return set?.toList() ?? const [];
                  }
                : null,
          );
          if (instantList.isNotEmpty) {
            _all = instantList;
            _filtered = instantList;
            _loading = false;
            _buildSearchAndBlockIndices(instantList);
            _applyFilter();
            setState(() {});
          }
        } catch (_) {}
      }

      if (_all.isEmpty) {
        setState(() {
          _loading = true;
          _error = '';
        });
      }
    }

    final payload = await _service.fetchLiveFirstWithFallbackPayload();
    if (!mounted) return;

    // Authentic Pure Timetable Roster (100% active teaching faculty, zero photos, zero staff clutter)
    final timetableTeachers = widget.brain != null
        ? widget.brain!.allTeachers()
        : (widget.memory != null ? widget.memory!.allTeachers() : const <String>[]);

    final roomsMap = widget.brain?.getTeacherRoomsMap();
    final deptsMap = widget.brain?.getTeacherDepartmentsMap();

    List<FacultyProfile> facultyList = [];
    if (timetableTeachers.isNotEmpty) {
      try {
        facultyList = HelpdeskFacultyService.buildPureTimetableProfiles(
          timetableTeachers: timetableTeachers,
          departmentLookup: deptsMap != null
              ? (teacher) {
                  final key = teacher.trim().toLowerCase();
                  final stripped = HelpdeskFacultyService.stripDepartmentPrefix(teacher).trim().toLowerCase();
                  return deptsMap[key] ?? deptsMap[stripped] ?? widget.brain?.departmentForTeacher(teacher);
                }
              : widget.brain?.departmentForTeacher,
          roomsLookup: roomsMap != null
              ? (teacher) {
                  final key = teacher.trim().toLowerCase();
                  final stripped = HelpdeskFacultyService.stripDepartmentPrefix(teacher).trim().toLowerCase();
                  final set = roomsMap[key] ?? roomsMap[stripped];
                  return set?.toList() ?? const [];
                }
              : (widget.brain != null
                  ? (teacher) => widget.brain!.locateTeacher(teacher, DateTime.now()).allRooms
                  : null),
          enrichmentProfiles: payload.items,
        );
      } catch (_) {
        facultyList = [];
      }
    }

    if (facultyList.isEmpty && payload.items.isNotEmpty) {
      // Safe fallback if timetable has not yet loaded
      facultyList = List<FacultyProfile>.from(payload.items);
    }

    if (facultyList.isEmpty) {
      setState(() {
        _all = const [];
        _filtered = const [];
        _loading = false;
        _error = 'Unable to load faculty directory right now.';
        _source = HelpdeskFacultySource.none;
      });
      return;
    }
    facultyList.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));

    _buildSearchAndBlockIndices(facultyList);

    setState(() {
      _all = facultyList;
      _loading = false;
      _source = payload.source;
    });
    _applyFilter();
  }

  String _sourceLabel(HelpdeskFacultySource source) {
    return 'TIMETABLE';
  }


  String _blockFromLocation(String location) {
    final value = location.trim();
    if (value.isEmpty) return 'Unknown';
    final upper = value.toUpperCase();
    if (upper.contains('A BLOCK') || upper.startsWith('A')) return 'A Block';
    if (upper.contains('B BLOCK') || upper.startsWith('B')) return 'B Block';
    if (upper.contains('C BLOCK') || upper.startsWith('C')) return 'C Block';
    if (upper.contains('D BLOCK') || upper.startsWith('D')) return 'D Block';
    if (upper.contains('E BLOCK') || upper.startsWith('E')) return 'E Block';
    if (upper.contains('WORKSHOP')) return 'Workshop Block';
    return value;
  }

  List<String> get _departments {
    final items = _all
        .map((e) => e.department.trim())
        .where((e) => e.isNotEmpty)
        .toSet()
        .toList()
      ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    return ['All', ...items];
  }

  List<String> get _blocks {
    final items = _all
        .map((e) => _profileBlockIndex[e.id] ?? _blockFromLocation(e.location))
        .where((e) => e.isNotEmpty)
        .toSet()
        .toList()
      ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    return ['All', ...items];
  }

  void _applyFilter() {
    final q = _query.toLowerCase().trim();
    final qTokens = q
        .split(RegExp(r'\s+'))
        .where((t) => t.isNotEmpty)
        .map((t) => t.replaceAll('.', ''))
        .toList();

    final selectedDeptLower = _selectedDepartment.toLowerCase();
    final selectedBlockLower = _selectedBlock.toLowerCase();

    final result = _all.where((item) {
      if (_selectedDepartment != 'All' &&
          item.department.toLowerCase() != selectedDeptLower) {
        return false;
      }
      final block = _profileBlockIndex[item.id] ?? _blockFromLocation(item.location);
      if (_selectedBlock != 'All' &&
          block.toLowerCase() != selectedBlockLower) {
        return false;
      }

      if (qTokens.isEmpty) return true;

      final searchIndex = _profileSearchIndex[item.id] ??
          '${item.name} ${item.department} ${item.location}'.toLowerCase();

      for (final token in qTokens) {
        if (!searchIndex.contains(token)) return false;
      }
      return true;
    }).toList();

    setState(() {
      _filtered = result;
    });
  }

  TeacherLocatorResult? _teacherInsight(String teacherName, {String? department}) {
    final brain = widget.brain;
    if (brain == null) return null;
    final cacheKey = '${teacherName}_${department ?? ""}';
    return _teacherInsightCache.putIfAbsent(
      cacheKey,
      () => brain.locateTeacher(teacherName, DateTime.now(), department: department),
    );
  }

  void _openTeacherLocator(FacultyProfile item, {Rect? initialBounds, GlobalKey? originKey}) {
    pushGlassContainerMorphRoute(
      context,
      originKey: originKey,
      initialBounds: initialBounds,
      page: FacultyDetailScreen(
        profile: item,
        brain: widget.brain,
        isSelectionMode: widget.isSelectionMode,
        onTeacherSelected: widget.onTeacherSelected,
        onLaunchEmail: () => _launchEmail(item.email),
        onLaunchPhone: () => _launchPhone(item.contact),
      ),
    );
  }

  Future<void> _launchPhone(String phone) async {
    final normalized = phone.trim();
    if (normalized.isEmpty || normalized.toLowerCase() == 'not available') {
      showIrisFrostedSnackBar(
        context,
        dedupeKey: 'faculty_phone_unavailable',
        content: const Text('Phone number unavailable for this faculty member.'),
      );
      return;
    }
    final uri = Uri.parse('tel:$normalized');
    if (await canLaunchUrl(uri)) {
      IrisHaptics.selectionClick();
      await launchUrl(uri);
      return;
    }
    if (!mounted) return;
    showIrisFrostedSnackBar(
      context,
      dedupeKey: 'faculty_phone_launch_failed',
      content: const Text('Unable to open dialer on this device.'),
    );
  }

  Future<void> _launchEmail(String email) async {
    final normalized = email.trim();
    if (normalized.isEmpty || normalized.toLowerCase() == 'not available') {
      showIrisFrostedSnackBar(
        context,
        dedupeKey: 'faculty_email_unavailable',
        content: const Text('Email unavailable for this faculty member.'),
      );
      return;
    }
    final uri = Uri.parse('mailto:$normalized');
    if (await canLaunchUrl(uri)) {
      IrisHaptics.selectionClick();
      await launchUrl(uri);
      return;
    }
    if (!mounted) return;
    showIrisFrostedSnackBar(
      context,
      dedupeKey: 'faculty_email_launch_failed',
      content: const Text('Unable to open email client on this device.'),
    );
  }

  Widget _buildFilterStrip({
    required String title,
    required List<String> options,
    required String selected,
    required ValueChanged<String> onChanged,
    required bool isDark,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(
            title,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.0,
              color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.42),
            ),
          ),
        ),
        SizedBox(
          height: 36,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: options.length,
            separatorBuilder: (_, _) => const SizedBox(width: 8),
            itemBuilder: (_, i) {
              final value = options[i];
              final active = selected == value;
              final isM3 = ThemeSignals.isMaterialYou;
              final cs = Theme.of(context).colorScheme;

              final chipContent = AnimatedContainer(
                duration: IrisMotion.fast,
                curve: IrisMotion.standard,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: isM3
                      ? (active ? cs.secondaryContainer : cs.surfaceContainerHigh)
                      : (active
                          ? IrisTokens.brand.withValues(alpha: isDark ? 0.24 : 0.14)
                          : (isDark
                              ? Colors.white.withValues(alpha: 0.08)
                              : Colors.black.withValues(alpha: 0.04))),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(
                    color: isM3
                        ? (active
                            ? cs.secondaryContainer
                            : cs.outlineVariant.withValues(alpha: isDark ? 0.3 : 0.5))
                        : (active
                            ? IrisTokens.brand.withValues(alpha: 0.40)
                            : (isDark
                                ? Colors.white.withValues(alpha: 0.14)
                                : Colors.black.withValues(alpha: 0.10))),
                    width: 1.0,
                  ),
                  boxShadow: isM3 && active
                      ? [
                          BoxShadow(
                            color: cs.secondaryContainer.withValues(alpha: 0.25),
                            blurRadius: 6,
                            offset: const Offset(0, 2),
                          ),
                        ]
                      : null,
                ),
                child: Text(
                  value,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: active ? FontWeight.w800 : FontWeight.w600,
                    color: isM3
                        ? (active ? cs.onSecondaryContainer : cs.onSurfaceVariant)
                        : (active
                            ? IrisTokens.brand
                            : (isDark
                                ? Colors.white.withValues(alpha: 0.82)
                                : Colors.black.withValues(alpha: 0.75))),
                  ),
                ),
              );

              if (isM3) {
                return ExpressiveInteractivePress(
                  onTap: () {
                    IrisHaptics.chipSelect();
                    onChanged(value);
                  },
                  child: chipContent,
                );
              }

              return InkWell(
                borderRadius: BorderRadius.circular(999),
                onTap: () {
                  IrisHaptics.chipSelect();
                  onChanged(value);
                },
                child: chipContent,
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildFacultyTile(FacultyProfile item, bool isDark) {
    final insight = _teacherInsight(item.name, department: item.department);
    final status = insight?.status ?? 'unknown';
    final statusText = insight?.statusText ?? '';

    Color statusColor() {
      switch (status) {
        case 'live':
          return IrisTokens.success;
        case 'today':
          return IrisTokens.brand;
        case 'weekly':
        case 'upcoming':
          return IrisTokens.warning;
        default:
          return IrisTokens.purple;
      }
    }

    final smartColor = statusColor();

    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    Widget buildTileContent(BuildContext tileContext) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              IrisComponents.facultyMonogramBadge(
                name: item.name,
                department: item.department,
                size: 52,
                isDark: isDark,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.name,
                      style: TextStyle(
                        fontSize: 15.5,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.2,
                        color: isM3 ? cs.onSurface : null,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            item.department.isEmpty ? 'Academic Faculty' : item.department,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: isM3
                                  ? cs.onSurfaceVariant
                                  : (isDark ? Colors.white : Colors.black).withValues(alpha: 0.58),
                            ),
                          ),
                        ),
                        if (item.designation.trim().isNotEmpty) ...[
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1.5),
                            decoration: BoxDecoration(
                              color: isM3
                                  ? cs.secondaryContainer
                                  : IrisTokens.brand.withValues(alpha: isDark ? 0.16 : 0.08),
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(
                                color: isM3
                                    ? cs.secondaryContainer
                                    : IrisTokens.brand.withValues(alpha: isDark ? 0.3 : 0.2),
                                width: 0.6,
                              ),
                            ),
                            child: Text(
                              item.designation.trim(),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                                color: isM3
                                    ? cs.onSecondaryContainer
                                    : (isDark ? IrisTokens.brandLight : IrisTokens.brand),
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Icon(
                          Icons.meeting_room_rounded,
                          size: 13,
                          color: isM3 ? cs.primary : IrisTokens.purple.withValues(alpha: 0.85),
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            item.location.isEmpty ? 'COMSATS Campus' : item.location,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w600,
                              color: isM3
                                  ? cs.onSurfaceVariant
                                  : (isDark ? Colors.white : Colors.black).withValues(alpha: 0.55),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: smartColor.withValues(alpha: isDark ? 0.12 : 0.07),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: smartColor.withValues(alpha: isDark ? 0.24 : 0.16),
                width: 0.8,
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 7,
                  height: 7,
                  decoration: BoxDecoration(
                    color: smartColor,
                    shape: BoxShape.circle,
                    boxShadow: status == 'live' ? [
                      BoxShadow(
                        color: smartColor.withValues(alpha: 0.6),
                        blurRadius: 4,
                        spreadRadius: 1,
                      ),
                    ] : null,
                  ),
                ),
                const SizedBox(width: 7),
                Text(
                  status == 'live'
                      ? 'LIVE NOW'
                      : status == 'today'
                          ? 'TODAY'
                          : status == 'weekly' || status == 'upcoming'
                              ? 'UPCOMING'
                              : 'TIMETABLE',
                  style: TextStyle(
                    fontSize: 9.5,
                    fontWeight: FontWeight.w800,
                    color: smartColor,
                    letterSpacing: 0.6,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    statusText.isEmpty ? 'Tap to view weekly schedule' : statusText,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: isM3
                          ? cs.onSurfaceVariant
                          : (isDark ? Colors.white : Colors.black).withValues(alpha: 0.65),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    final box = tileContext.findRenderObject() as RenderBox?;
                    final rect = (box != null && box.hasSize)
                        ? box.localToGlobal(Offset.zero) & box.size
                        : null;
                    _openTeacherLocator(item, initialBounds: rect);
                  },
                  icon: Icon(
                    widget.isSelectionMode
                        ? Icons.visibility_rounded
                        : Icons.calendar_month_rounded,
                    size: 16,
                  ),
                  label: Text(widget.isSelectionMode ? 'Peek' : 'Schedule'),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(
                      color: isM3 ? cs.primary.withValues(alpha: 0.35) : IrisTokens.brand.withValues(alpha: 0.28),
                    ),
                    foregroundColor: isM3 ? cs.primary : IrisTokens.brand,
                    padding: const EdgeInsets.symmetric(vertical: 9),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: widget.isSelectionMode
                    ? ElevatedButton.icon(
                        onPressed: () {
                          IrisHaptics.actionMedium();
                          if (widget.onTeacherSelected != null) {
                            widget.onTeacherSelected!(item.name);
                          }
                          Navigator.maybePop(context);
                        },
                        icon: const Icon(Icons.check_rounded, size: 16),
                        label: const Text('Select'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: isM3 ? cs.primary : IrisTokens.brand,
                          foregroundColor: isM3 ? cs.onPrimary : Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 9),
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      )
                    : (item.email.isNotEmpty
                        ? OutlinedButton.icon(
                            onPressed: () => _launchEmail(item.email),
                            icon: const Icon(Icons.mail_outline_rounded, size: 16),
                            label: const Text('Email'),
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(
                                color: isM3 ? cs.tertiary.withValues(alpha: 0.35) : IrisTokens.purple.withValues(alpha: 0.28),
                              ),
                              foregroundColor: isM3 ? cs.tertiary : IrisTokens.purple,
                              padding: const EdgeInsets.symmetric(vertical: 9),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          )
                        : OutlinedButton.icon(
                            onPressed: () {
                              final box = tileContext.findRenderObject() as RenderBox?;
                              final rect = (box != null && box.hasSize)
                                  ? box.localToGlobal(Offset.zero) & box.size
                                  : null;
                              _openTeacherLocator(item, initialBounds: rect);
                            },
                            icon: const Icon(Icons.near_me_rounded, size: 16),
                            label: const Text('Locate'),
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(
                                color: IrisTokens.success.withValues(alpha: 0.28),
                              ),
                              foregroundColor: IrisTokens.success,
                              padding: const EdgeInsets.symmetric(vertical: 9),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          )),
              ),
            ],
          ),
        ],
      );
    }

    if (isM3) {
      return RepaintBoundary(
        child: Builder(
          builder: (tileContext) => ExpressiveInteractivePress(
            onTap: () {
              final box = tileContext.findRenderObject() as RenderBox?;
              final rect = (box != null && box.hasSize)
                  ? box.localToGlobal(Offset.zero) & box.size
                  : null;
              _openTeacherLocator(item, initialBounds: rect);
            },
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: isDark ? cs.surfaceContainerLow : cs.surfaceContainer,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.45),
                  width: 1.0,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.20 : 0.05),
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: buildTileContent(tileContext),
            ),
          ),
        ),
      );
    }

    return RepaintBoundary(
      child: Builder(
        builder: (tileContext) => InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () {
            final box = tileContext.findRenderObject() as RenderBox?;
            final rect = (box != null && box.hasSize)
                ? box.localToGlobal(Offset.zero) & box.size
                : null;
            _openTeacherLocator(item, initialBounds: rect);
          },
          child: GlassCard(
            enableOverlay: false,
            child: buildTileContent(tileContext),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: irisFrostedAppBar(
        title: 'Faculty Directory',
        isDark: isDark,
        leading: AppBackButton(isDark: isDark),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          ObsidianPulse(isDark: isDark),
          SafeArea(
            child: Column(
              children: [
                Expanded(
                  child: Align(
                    alignment: Alignment.topCenter,
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 860),
                      child: RefreshIndicator(
                        onRefresh: _loadFaculty,
                        child: CustomScrollView(
                          controller: _scrollController,
                          cacheExtent: 450.0,
                          physics: const ButterScrollPhysics(
                            parent: AlwaysScrollableScrollPhysics(),
                          ),
                          slivers: [
                        SliverPadding(
                          padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                          sliver: SliverToBoxAdapter(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                GlassCard(
                                  borderRadius: 24,
                                  padding: const EdgeInsets.all(16),
                                  child: Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(12),
                                        decoration: BoxDecoration(
                                          gradient: const LinearGradient(
                                            colors: [IrisTokens.brand, IrisTokens.purple],
                                          ),
                                          borderRadius: BorderRadius.circular(14),
                                        ),
                                        child: const Icon(
                                          Icons.badge_rounded,
                                          color: Colors.white,
                                          size: 22,
                                        ),
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            const Text(
                                              'Faculty Directory',
                                              style: TextStyle(
                                                fontSize: 22,
                                                fontWeight: FontWeight.w900,
                                                letterSpacing: -0.3,
                                              ),
                                            ),
                                            Text(
                                              'Live faculty directory with room locator',
                                              style: TextStyle(
                                                fontSize: 12,
                                                fontWeight: FontWeight.w600,
                                                color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.55),
                                              ),
                                            ),
                                            const SizedBox(height: 6),
                                            Container(
                                              padding: const EdgeInsets.symmetric(
                                                horizontal: 8,
                                                vertical: 4,
                                              ),
                                              decoration: BoxDecoration(
                                                color: IrisTokens.brand.withValues(alpha: 0.14),
                                                borderRadius: BorderRadius.circular(999),
                                                border: Border.all(
                                                  color: IrisTokens.brand.withValues(alpha: 0.24),
                                                ),
                                              ),
                                              child: Text(
                                                _sourceLabel(_source),
                                                style: TextStyle(
                                                  fontSize: 10,
                                                  fontWeight: FontWeight.w800,
                                                  letterSpacing: 0.7,
                                                  color: IrisTokens.brand.withValues(alpha: 0.9),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 16),
                                IrisGlowingInputWrapper(
                                  borderRadius: 24,
                                  child: TextField(
                                    controller: _searchController,
                                    onChanged: (value) {
                                      _query = value;
                                      _searchDebounce?.cancel();
                                      _searchDebounce = Timer(
                                        const Duration(milliseconds: 120),
                                        () {
                                          if (!mounted) return;
                                          _applyFilter();
                                        },
                                      );
                                    },
                                    style: const TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600,
                                    ),
                                    decoration: InputDecoration(
                                      hintText: 'Search faculty by name, dept, location...',
                                      hintStyle: TextStyle(
                                        color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.45),
                                      ),
                                      prefixIcon: const Icon(Icons.search_rounded),
                                      suffixIcon: _searchController.text.trim().isEmpty
                                          ? null
                                          : IconButton(
                                              onPressed: () {
                                                IrisHaptics.actionSoft();
                                                _searchController.clear();
                                                _query = '';
                                                _applyFilter();
                                              },
                                              icon: const Icon(Icons.clear_rounded),
                                            ),
                                      border: InputBorder.none,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 12),
                                _buildFilterStrip(
                                  title: 'DEPARTMENT',
                                  options: _departments,
                                  selected: _selectedDepartment,
                                  onChanged: (value) {
                                    setState(() => _selectedDepartment = value);
                                    _applyFilter();
                                  },
                                  isDark: isDark,
                                ),
                                const SizedBox(height: 10),
                                _buildFilterStrip(
                                  title: 'BLOCK',
                                  options: _blocks,
                                  selected: _selectedBlock,
                                  onChanged: (value) {
                                    setState(() => _selectedBlock = value);
                                    _applyFilter();
                                  },
                                  isDark: isDark,
                                ),
                                const SizedBox(height: 12),
                                if (_loading)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 24),
                                    child: Center(child: IrisComponents.loadingSpinner(size: 32)),
                                  )
                                else if (_error.isNotEmpty)
                                  GlassCard(
                                    enableOverlay: false,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'Directory unavailable',
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w800,
                                          ),
                                        ),
                                        const SizedBox(height: 8),
                                        Text(
                                          _error,
                                          style: TextStyle(
                                            fontSize: 13,
                                            color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.65),
                                          ),
                                        ),
                                        const SizedBox(height: 10),
                                        Align(
                                          alignment: Alignment.centerLeft,
                                          child: IrisLiquidButton(
                                            text: 'Try again',
                                            icon: Icons.refresh_rounded,
                                            onTap: _loadFaculty,
                                            color: IrisTokens.brand,
                                            isDark: isDark,
                                            height: 44,
                                            padding: const EdgeInsets.symmetric(horizontal: 16),
                                          ),
                                        ),
                                      ],
                                    ),
                                  )
                                else
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 8),
                                    child: Text(
                                      '${_filtered.length} result${_filtered.length == 1 ? '' : 's'}',
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w700,
                                        color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.48),
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                        if (!_loading && _error.isEmpty)
                          SliverPadding(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 28),
                            sliver: SliverList.builder(
                              itemCount: _filtered.length,
                              itemBuilder: (context, index) {
                                final item = _filtered[index];
                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 10),
                                  child: _buildFacultyTile(item, isDark),
                                );
                              },
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
          ),
        ],
      ),
    );
  }
}
