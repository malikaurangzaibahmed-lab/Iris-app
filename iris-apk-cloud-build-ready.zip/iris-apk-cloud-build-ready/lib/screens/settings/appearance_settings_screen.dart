import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/vital_theme.dart';
import '../../core/theme_signals.dart';
import '../../core/animations.dart';
import '../../widgets/effects/glass_container_transform.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../../services/ui_feedback.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/controls/m3e_color_selector.dart';
import '../../screens/settings/theme_selector_screen.dart';

/// Commercial Phone-grade Appearance & Visual Architecture Settings Sub-Screen.
/// Offers full, direct interactive control over all 7 IRIS Design Themes,
/// Display Modes (System / Light / Dark), and Monet Dynamic Accent Palettes.
class AppearanceSettingsScreen extends StatefulWidget {
  final String? currentThemeMode;
  final Future<void> Function(String)? onSetThemeMode;

  const AppearanceSettingsScreen({
    super.key,
    this.currentThemeMode,
    this.onSetThemeMode,
  });

  @override
  State<AppearanceSettingsScreen> createState() => _AppearanceSettingsScreenState();
}

class _AppearanceSettingsScreenState extends State<AppearanceSettingsScreen> {
  late String _currentMode;

  @override
  void initState() {
    super.initState();
    _currentMode = widget.currentThemeMode ?? 'system';
    _loadStoredThemeMode();
  }

  Future<void> _loadStoredThemeMode() async {
    final prefs = await SharedPreferences.getInstance();
    final stored = prefs.getString('app_theme_mode');
    if (stored != null && mounted) {
      setState(() => _currentMode = stored);
    }
  }

  void _setMode(String mode) async {
    IrisHaptics.chipSelect();
    setState(() => _currentMode = mode);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('app_theme_mode', mode);
    widget.onSetThemeMode?.call(mode);
  }

  void _selectTheme(IrisThemeStyle style) {
    if (ThemeSignals.themeStyle.value == style) return;
    IrisHaptics.selectionClick();
    ThemeSignals.switchThemeWithMorph(context, style: style);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorial;
    final isNotebook = ThemeSignals.isNotebook;
    final isLine = ThemeSignals.isLine;
    final isPoster = ThemeSignals.isPoster;
    final cs = Theme.of(context).colorScheme;

    // Theme-adaptive AppBar Title Style
    final TextStyle appBarTitleStyle;
    if (isAlmanac) {
      appBarTitleStyle = AlmanacTokens.serifHeadline(isDark, fontSize: 18, fontWeight: FontWeight.w800);
    } else if (isEditorial) {
      appBarTitleStyle = EditorialTokens.headingSerif(isDark, fontSize: 18, fontWeight: FontWeight.w900);
    } else if (isNotebook) {
      appBarTitleStyle = NotebookTokens.boldScript(isDark, fontSize: 19);
    } else if (isLine) {
      appBarTitleStyle = LineTokens.stationName(isDark).copyWith(fontSize: 17, fontWeight: FontWeight.w900);
    } else if (isPoster) {
      appBarTitleStyle = PosterTokens.classTitle(isDark).copyWith(fontSize: 17, fontWeight: FontWeight.w900);
    } else if (isM3) {
      appBarTitleStyle = TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: cs.onSurface);
    } else {
      appBarTitleStyle = TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w900,
        color: isDark ? Colors.white : const Color(0xFF0F172A),
      );
    }

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: ExpressiveInteractivePress(
          pressedScale: 0.90,
          onTap: () => Navigator.of(context).pop(),
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: isM3
                  ? cs.surfaceContainer
                  : (isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.06)),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.arrow_back_rounded,
              size: 20,
              color: isDark ? Colors.white : const Color(0xFF0F172A),
            ),
          ),
        ),
        title: Text(
          'Appearance & Themes',
          style: appBarTitleStyle,
        ),
      ),
      body: Stack(
        children: [
          ObsidianPulse(isDark: isDark),
          SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 720),
                child: ListView(
                  physics: const ButterScrollPhysics(
                    parent: AlwaysScrollableScrollPhysics(),
                  ),
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
                  children: [
                    // 1. Display Mode Segmented Control
                    _buildSectionHeader('Display Mode'),
                    const SizedBox(height: 10),
                    GlassCard(
                      borderRadius: 22,
                      elevation: 2,
                      padding: const EdgeInsets.all(6),
                      child: Row(
                        children: [
                          Expanded(
                            child: _buildModePill(
                              mode: 'system',
                              label: 'System',
                              icon: Icons.brightness_auto_rounded,
                              active: _currentMode == 'system',
                            ),
                          ),
                          Expanded(
                            child: _buildModePill(
                              mode: 'light',
                              label: 'Light',
                              icon: Icons.light_mode_rounded,
                              active: _currentMode == 'light',
                            ),
                          ),
                          Expanded(
                            child: _buildModePill(
                              mode: 'dark',
                              label: 'Dark',
                              icon: Icons.dark_mode_rounded,
                              active: _currentMode == 'dark',
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // 2. All 7 Design Engines Showcase
                    _buildSectionHeader('Visual Design Engines (7 Bespoke Themes)'),
                    const SizedBox(height: 6),
                    Padding(
                      padding: const EdgeInsets.only(left: 6, bottom: 10),
                      child: Text(
                        'Instant live morphing across all 7 aesthetic architectures',
                        style: TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w500,
                          color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                        ),
                      ),
                    ),

                    ValueListenableBuilder<IrisThemeStyle>(
                      valueListenable: ThemeSignals.themeStyle,
                      builder: (context, currentStyle, _) {
                        return Column(
                          children: [
                            // Tier 1: Flagship Modern Engines (Material 3 & Liquid Glass)
                            Row(
                              children: [
                                Expanded(
                                  child: _buildThemeCard(
                                    style: IrisThemeStyle.materialYou,
                                    title: 'Material 3',
                                    subtitle: 'Google Pixel',
                                    badge: '120 FPS LOCKED',
                                    desc: 'Monet tonal containers, squircle pills, 120 FPS flat raster.',
                                    icon: Icons.auto_awesome_rounded,
                                    accentColor: const Color(0xFF0061A4),
                                    isSelected: currentStyle == IrisThemeStyle.materialYou,
                                    isDark: isDark,
                                    cs: cs,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: _buildThemeCard(
                                    style: IrisThemeStyle.fluidGlass,
                                    title: 'Liquid Glass',
                                    subtitle: 'Signature Optics',
                                    badge: 'REFRACTION & OPTICS',
                                    desc: 'Frosted backdrops, specular rims, Lissajous organic shaders.',
                                    icon: Icons.water_drop_rounded,
                                    accentColor: VitalTokens.purple,
                                    isSelected: currentStyle == IrisThemeStyle.fluidGlass,
                                    isDark: isDark,
                                    cs: cs,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),

                            // Tier 2: Literary & Editorial Suite (Almanac & Editorial Academic)
                            Row(
                              children: [
                                Expanded(
                                  child: _buildThemeCard(
                                    style: IrisThemeStyle.almanac,
                                    title: 'Almanac',
                                    subtitle: 'Classical Newsprint',
                                    badge: 'BROADSIDE PRINT',
                                    desc: 'Scotch Roman serif, double rules, terracotta broadside table.',
                                    icon: Icons.newspaper_rounded,
                                    accentColor: const Color(0xFFC84B31),
                                    isSelected: currentStyle == IrisThemeStyle.almanac,
                                    isDark: isDark,
                                    cs: cs,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: _buildThemeCard(
                                    style: IrisThemeStyle.editorialAcademic,
                                    title: 'Editorial',
                                    subtitle: 'Literary Study',
                                    badge: 'COZY SERIF',
                                    desc: 'Warm ivory & parchment, Fraunces serif, academic cozy study.',
                                    icon: Icons.auto_stories_rounded,
                                    accentColor: const Color(0xFFE5A83B),
                                    isSelected: currentStyle == IrisThemeStyle.editorialAcademic,
                                    isDark: isDark,
                                    cs: cs,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),

                            // Tier 3: Physical & Graphic Design (Student Notebook & Line Transit)
                            Row(
                              children: [
                                Expanded(
                                  child: _buildThemeCard(
                                    style: IrisThemeStyle.notebook,
                                    title: 'Notebook',
                                    subtitle: 'Bullet Journal',
                                    badge: 'HAND-DRAWN DOODLE',
                                    desc: 'Graph paper grid, red margin rule, washi tape, kalam script.',
                                    icon: Icons.edit_note_rounded,
                                    accentColor: const Color(0xFFE11D48),
                                    isSelected: currentStyle == IrisThemeStyle.notebook,
                                    isDark: isDark,
                                    cs: cs,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: _buildThemeCard(
                                    style: IrisThemeStyle.line,
                                    title: 'Line Transit',
                                    subtitle: 'Subway Wayfinding',
                                    badge: 'METRO RAIL',
                                    desc: 'Transit subway track lines, station LED badges, terminal codes.',
                                    icon: Icons.alt_route_rounded,
                                    accentColor: LineTokens.railLine(isDark),
                                    isSelected: currentStyle == IrisThemeStyle.line,
                                    isDark: isDark,
                                    cs: cs,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),

                            // Tier 4: Swiss Brutalism (Poster Monolith)
                            _buildThemeCard(
                              style: IrisThemeStyle.poster,
                              title: 'Poster Swiss',
                              subtitle: 'Swiss Brutalism',
                              badge: 'SWISS MONOLITH',
                              desc: 'International orange, bold monolithic type, ink borders & 3D drop-block shadow.',
                              icon: Icons.crop_portrait_rounded,
                              accentColor: PosterTokens.orangeHero,
                              isSelected: currentStyle == IrisThemeStyle.poster,
                              isDark: isDark,
                              cs: cs,
                              isFullWidth: true,
                            ),
                          ],
                        );
                      },
                    ),
                    const SizedBox(height: 24),

                    // 3. Interactive Preview Stage Launcher
                    _buildSectionHeader('Live Interactive Morph Stage'),
                    const SizedBox(height: 10),
                    GlassCard(
                      borderRadius: 22,
                      elevation: 2,
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: (isM3 ? cs.primary : VitalTokens.purple).withValues(alpha: 0.16),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: Icon(
                                  Icons.preview_rounded,
                                  color: isM3 ? cs.primary : VitalTokens.purple,
                                  size: 22,
                                ),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Fullscreen Morphing Studio',
                                      style: TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.w900,
                                        color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      'Test live class session card physics, Monet seeds & glass refraction',
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: isM3 ? cs.primary : VitalTokens.purple,
                                foregroundColor: isM3 ? cs.onPrimary : Colors.white,
                                padding: const EdgeInsets.symmetric(vertical: 13),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                                elevation: 0,
                              ),
                              onPressed: () {
                                IrisHaptics.actionMedium();
                                pushGlassContainerMorphRoute(
                                  context,
                                  page: const IrisThemeSelectorScreen(),
                                );
                              },
                              icon: const Icon(Icons.open_in_full_rounded, size: 18),
                              label: const Text(
                                'Launch Fullscreen Preview Stage',
                                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // 4. Color Palette Customizer Tile
                    _buildSectionHeader('Color Dynamics'),
                    const SizedBox(height: 10),
                    GlassCard(
                      borderRadius: 22,
                      elevation: 2,
                      padding: EdgeInsets.zero,
                      child: InkWell(
                        onTap: () {
                          IrisHaptics.actionSoft();
                          showM3EColorSelectorSheet(context);
                        },
                        borderRadius: BorderRadius.circular(22),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(9),
                                decoration: BoxDecoration(
                                  color: Colors.pinkAccent.withValues(alpha: isDark ? 0.20 : 0.12),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: const Icon(Icons.colorize_rounded, color: Colors.pinkAccent, size: 18),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'M3 Monet Accent Palette',
                                      style: TextStyle(
                                        fontSize: 13.5,
                                        fontWeight: FontWeight.w800,
                                        color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      'Select dynamic seed color for buttons, badges & highlights',
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Icon(
                                Icons.chevron_right_rounded,
                                size: 20,
                                color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white30 : Colors.black26),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String label) {
    final isAlmanac = ThemeSignals.isAlmanac;
    final isEditorial = ThemeSignals.isEditorial;
    final isNotebook = ThemeSignals.isNotebook;
    final isLine = ThemeSignals.isLine;
    final isPoster = ThemeSignals.isPoster;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    if (isAlmanac) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Row(
          children: [
            Text(
              '§ ${label.toUpperCase()}',
              style: AlmanacTokens.monoHeader(
                isDark,
                fontSize: 10.5,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.2,
                color: AlmanacTokens.accentTerracotta(isDark),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Container(
                height: 0.8,
                color: AlmanacTokens.inkRuleSubtle(isDark),
              ),
            ),
          ],
        ),
      );
    }

    if (isEditorial) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Row(
          children: [
            Text(
              label.toUpperCase(),
              style: EditorialTokens.monoLabel(
                isDark,
                fontSize: 10.5,
              ).copyWith(letterSpacing: 1.2, fontWeight: FontWeight.w800),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Container(
                height: 0.8,
                color: EditorialTokens.cardBorder(isDark),
              ),
            ),
          ],
        ),
      );
    }

    if (isLine) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Text(
          '[THEME // ${label.toUpperCase()}]',
          style: LineTokens.stationMeta(isDark).copyWith(
            fontSize: 10.5,
            fontWeight: FontWeight.w800,
            color: LineTokens.railLine(isDark),
          ),
        ),
      );
    }

    if (isNotebook) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Text(
          '• $label',
          style: NotebookTokens.boldScript(
            isDark,
            fontSize: 14,
          ).copyWith(color: NotebookTokens.redDoodle(isDark)),
        ),
      );
    }

    if (isPoster) {
      return Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 2),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: PosterTokens.orangeHero,
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text(
            label.toUpperCase(),
            style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w900,
              color: Colors.black,
              letterSpacing: 0.8,
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(left: 6),
      child: Text(
        label.toUpperCase(),
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.1,
          color: isM3 ? cs.primary : (isDark ? Colors.white60 : const Color(0xFF64748B)),
        ),
      ),
    );
  }

  Widget _buildModePill({
    required String mode,
    required String label,
    required IconData icon,
    required bool active,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    return GestureDetector(
      onTap: () => _setMode(mode),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.fastOutSlowIn,
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: active
              ? (isM3 ? cs.surfaceContainerHighest : (isDark ? const Color(0xFF334155) : Colors.white))
              : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          boxShadow: active
              ? [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.08),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 16,
              color: active
                  ? (isM3 ? cs.primary : VitalTokens.blue)
                  : (isDark ? Colors.white54 : Colors.black54),
            ),
            const SizedBox(width: 7),
            Text(
              label,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: active ? FontWeight.w900 : FontWeight.w600,
                color: active
                    ? (isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)))
                    : (isDark ? Colors.white54 : Colors.black54),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildThemeCard({
    required IrisThemeStyle style,
    required String title,
    required String subtitle,
    required String badge,
    required String desc,
    required IconData icon,
    required Color accentColor,
    required bool isSelected,
    required bool isDark,
    required ColorScheme cs,
    bool isFullWidth = false,
  }) {
    final isM3 = ThemeSignals.isMaterialYou;

    return ExpressiveInteractivePress(
      onTap: () => _selectTheme(style),
      pressedScale: 0.94,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 240),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: isSelected
              ? (isM3
                  ? cs.primaryContainer.withValues(alpha: isDark ? 0.35 : 0.6)
                  : accentColor.withValues(alpha: isDark ? 0.20 : 0.12))
              : (isM3
                  ? cs.surfaceContainer
                  : (isDark ? Colors.white.withValues(alpha: 0.04) : Colors.black.withValues(alpha: 0.03))),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected
                ? (isM3 ? cs.primary : accentColor)
                : (isM3
                    ? cs.outlineVariant.withValues(alpha: isDark ? 0.3 : 0.5)
                    : (isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.07))),
            width: isSelected ? 2.0 : 1.0,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: accentColor.withValues(alpha: isDark ? 0.25 : 0.15),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ]
              : null,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? (isM3 ? cs.primary : accentColor)
                        : (isDark ? Colors.white12 : Colors.black12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    icon,
                    size: 16,
                    color: isSelected ? Colors.white : (isDark ? Colors.white70 : Colors.black54),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: accentColor.withValues(alpha: 0.14),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      badge,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 8.5,
                        fontWeight: FontWeight.w900,
                        color: accentColor,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 4),
                if (isSelected)
                  Icon(
                    Icons.check_circle_rounded,
                    size: 18,
                    color: isM3 ? cs.primary : accentColor,
                  ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              title,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w900,
                color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
              ),
            ),
            const SizedBox(height: 2),
            Text(
              subtitle,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: accentColor,
                letterSpacing: 0.2,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              desc,
              maxLines: isFullWidth ? 2 : 3,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 10.5,
                height: 1.3,
                fontWeight: FontWeight.w500,
                color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
