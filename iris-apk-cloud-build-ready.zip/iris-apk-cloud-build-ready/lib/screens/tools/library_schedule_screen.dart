import 'package:flutter/material.dart';
import '../../core/animations.dart';
import '../../core/vital_theme.dart';
import '../../services/helpdesk_schedule_data_service.dart';
import '../../services/helpdesk_uni_info_service.dart';
import '../../services/ui_feedback.dart';
import '../../widgets/effects/glass_container_transform.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/iris_components.dart';
import 'resource_hero_card.dart';
import 'uni_info_screen.dart';

class LibraryScheduleScreen extends StatefulWidget {
  const LibraryScheduleScreen({super.key});

  @override
  State<LibraryScheduleScreen> createState() => _LibraryScheduleScreenState();
}

class _LibraryScheduleScreenState extends State<LibraryScheduleScreen> {
  final HelpdeskScheduleDataService _scheduleService =
      HelpdeskScheduleDataService();
  final HelpdeskUniInfoService _uniInfoService = HelpdeskUniInfoService();

  Map<String, dynamic> _libraryData = const {};
  int _bookCount = 346;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadLibraryHub();
  }

  Future<void> _loadLibraryHub() async {
    final payload = await _scheduleService.fetchSchedulePayload();
    final uniInfo = await _uniInfoService.fetchUniInfo();
    if (mounted) {
      setState(() {
        _libraryData = payload.librarySchedule;
        if (uniInfo.books.isNotEmpty) {
          _bookCount = uniInfo.books.length;
        }
        _loading = false;
      });
    }
  }

  ({
    String statusLabel,
    String detail,
    Color color,
    double progress,
    String crowdLabel,
  }) _evaluateLiveStatus(DateTime now) {
    final weekday = now.weekday;
    final hourVal = now.hour + (now.minute / 60.0);

    if (weekday == DateTime.saturday || weekday == DateTime.sunday) {
      return (
        statusLabel: 'CLOSED FOR WEEKEND',
        detail: 'Reopens Monday at 08:30 AM',
        color: const Color(0xFFEF4444),
        progress: 0.0,
        crowdLabel: 'Offline',
      );
    }

    if (hourVal < 8.5) {
      final mins = ((8.5 - hourVal) * 60).round();
      return (
        statusLabel: 'OPENS SOON',
        detail: 'Doors open at 08:30 AM (in $mins min)',
        color: const Color(0xFFF59E0B),
        progress: 0.0,
        crowdLabel: 'Quiet',
      );
    }

    if (hourVal >= 16.5) {
      return (
        statusLabel: 'CLOSED FOR TODAY',
        detail: 'Closed at 04:30 PM • Reopens 08:30 AM',
        color: const Color(0xFFEF4444),
        progress: 1.0,
        crowdLabel: 'Offline',
      );
    }

    // Friday Jummah / Prayer Break (12:30 PM - 02:00 PM on Friday, 01:00 PM - 02:00 PM Mon-Thu)
    final isBreak = weekday == DateTime.friday
        ? (hourVal >= 12.5 && hourVal < 14.0)
        : (hourVal >= 13.0 && hourVal < 14.0);

    final dayProgress = ((hourVal - 8.5) / 8.0).clamp(0.0, 1.0);

    if (isBreak) {
      return (
        statusLabel: weekday == DateTime.friday
            ? 'JUMMAH PRAYER BREAK'
            : 'PRAYER & LUNCH BREAK',
        detail: 'Circulation desk resumes at 02:00 PM',
        color: const Color(0xFFF59E0B),
        progress: dayProgress,
        crowdLabel: 'Low Occupancy',
      );
    }

    final isPeak = hourVal >= 10.5 && hourVal <= 13.5;
    final minsLeft = ((16.5 - hourVal) * 60).round();
    final hrsLeft = minsLeft ~/ 60;
    final remMins = minsLeft % 60;

    return (
      statusLabel: 'OPEN NOW • ACTIVE',
      detail:
          'Closes at 04:30 PM (${hrsLeft > 0 ? "${hrsLeft}h ${remMins}m" : "${remMins}m"} remaining)',
      color: const Color(0xFF10B981),
      progress: dayProgress,
      crowdLabel: isPeak ? 'Peak Study Hours (75% Full)' : 'Moderate Occupancy (40% Full)',
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final onSurface = Theme.of(context).colorScheme.onSurface;
    final topInset = MediaQuery.paddingOf(context).top + kToolbarHeight + 12;
    final now = DateTime.now();
    final live = _evaluateLiveStatus(now);

    final rawTimings = _libraryData['timings'] is List
        ? (_libraryData['timings'] as List)
        : const [
            {
              'days': 'Monday – Thursday',
              'hours': '08:30 AM – 04:30 PM',
              'breakTime': '01:00 PM – 02:00 PM',
            },
            {
              'days': 'Friday',
              'hours': '08:30 AM – 04:30 PM',
              'breakTime': '12:30 PM – 02:00 PM (Jummah Break)',
            },
            {
              'days': 'Saturday – Sunday',
              'hours': 'Closed',
              'breakTime': 'Weekend Off',
            },
          ];

    final rawRules = _libraryData['rules'] is List
        ? (_libraryData['rules'] as List).map((e) => e.toString()).toList()
        : const [
            'Bring your University Student/Faculty ID card for entry and book borrowing.',
            'Maintain strict silence in Reading Halls and Individual Study Carrels.',
            'Up to 3 books may be borrowed for 14 days by undergraduate students.',
            'Digital HEC IEEE / SpringerLink / ACM portals are accessible on campus Wi-Fi.',
          ];

    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: irisFrostedAppBar(title: 'Central Library Hub', isDark: isDark),
      body: Stack(
        children: [
          ObsidianPulse(isDark: isDark),
          if (_loading)
            Center(child: IrisComponents.loadingSpinner(size: 28))
          else
            ListView(
              physics: const ButterScrollPhysics(
                parent: AlwaysScrollableScrollPhysics(),
              ),
              padding: EdgeInsets.fromLTRB(16, topInset, 16, 48),
              children: [
                ResourceHeroCard(
                  title: 'Central Library & Study Hub',
                  subtitle:
                      'Live occupancy, reading zones & $_bookCount-book catalog',
                  icon: Icons.local_library_rounded,
                  accent: const Color(0xFF6366F1),
                  isDark: isDark,
                ),
                const SizedBox(height: 16),

                // 1. Live Library Status & Crowd Meter Card
                GlassCard(
                  borderRadius: 24,
                  accentColor: live.color,
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 10,
                            height: 10,
                            decoration: BoxDecoration(
                              color: live.color,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: live.color.withValues(alpha: 0.5),
                                  blurRadius: 8,
                                  spreadRadius: 1,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            live.statusLabel,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 0.6,
                              color: live.color,
                            ),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 9,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFF6366F1)
                                  .withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              live.crowdLabel,
                              style: const TextStyle(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFF6366F1),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        live.detail,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: onSurface,
                        ),
                      ),
                      const SizedBox(height: 12),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(999),
                        child: LinearProgressIndicator(
                          value: live.progress,
                          minHeight: 7,
                          backgroundColor: onSurface.withValues(alpha: 0.10),
                          valueColor: AlwaysStoppedAnimation<Color>(live.color),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            '08:30 AM Open',
                            style: TextStyle(
                              fontSize: 10.5,
                              fontWeight: FontWeight.w600,
                              color: onSurface.withValues(alpha: 0.55),
                            ),
                          ),
                          Text(
                            '01:00 PM Break',
                            style: TextStyle(
                              fontSize: 10.5,
                              fontWeight: FontWeight.w600,
                              color: onSurface.withValues(alpha: 0.55),
                            ),
                          ),
                          Text(
                            '04:30 PM Close',
                            style: TextStyle(
                              fontSize: 10.5,
                              fontWeight: FontWeight.w600,
                              color: onSurface.withValues(alpha: 0.55),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 14),

                // 2. Direct Catalog Launcher Card (346 Books)
                GlassCard(
                  borderRadius: 22,
                  accentColor: const Color(0xFFF59E0B),
                  padding: const EdgeInsets.all(16),
                  onTap: () {
                    IrisHaptics.actionMedium();
                    pushGlassContainerMorphRoute(
                      context,
                      page: const UniInfoScreen(initialTabIndex: 3),
                      accentColor: const Color(0xFFF59E0B),
                    );
                  },
                  child: Row(
                    children: [
                      Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                          color: const Color(0xFFF59E0B).withValues(alpha: 0.16),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Icon(
                          Icons.menu_book_rounded,
                          color: Color(0xFFF59E0B),
                          size: 24,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Browse $_bookCount Recommended Books',
                              style: TextStyle(
                                fontSize: 14.5,
                                fontWeight: FontWeight.w800,
                                color: onSurface,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              'Search CS, SE, AI, Mathematics & General Literature catalog',
                              style: TextStyle(
                                fontSize: 12,
                                color: onSurface.withValues(alpha: 0.65),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Icon(
                        Icons.arrow_forward_ios_rounded,
                        size: 15,
                        color: Color(0xFFF59E0B),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),
                Text(
                  'Study Zones & Facilities',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: onSurface.withValues(alpha: 0.92),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: _buildZoneCard(
                        isDark: isDark,
                        icon: Icons.chair_alt_rounded,
                        title: 'Silent Reading Hall',
                        subtitle: 'Ground Floor • 120 Seats',
                        accent: const Color(0xFF6366F1),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _buildZoneCard(
                        isDark: isDark,
                        icon: Icons.computer_rounded,
                        title: 'HEC Digital Lab',
                        subtitle: 'IEEE & Springer Access',
                        accent: const Color(0xFF06B6D4),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: _buildZoneCard(
                        isDark: isDark,
                        icon: Icons.groups_2_rounded,
                        title: 'Discussion Pods',
                        subtitle: 'FYP & Group Study',
                        accent: const Color(0xFF10B981),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _buildZoneCard(
                        isDark: isDark,
                        icon: Icons.collections_bookmark_rounded,
                        title: 'Reference Archive',
                        subtitle: 'Theses & Journals',
                        accent: const Color(0xFFEC4899),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 20),
                Text(
                  'Operating Schedule',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: onSurface.withValues(alpha: 0.92),
                  ),
                ),
                const SizedBox(height: 10),
                ...rawTimings.map((slot) {
                  final map = slot is Map ? slot : const {};
                  final days = (map['days'] ?? map['day'] ?? '').toString();
                  final hours = (map['hours'] ?? map['open'] ?? '').toString();
                  final breakTime =
                      (map['breakTime'] ?? map['peak'] ?? '').toString();
                  final isClosed = hours.toLowerCase().contains('closed');

                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: GlassCard(
                      padding: const EdgeInsets.all(14),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  days,
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w800,
                                    color: onSurface,
                                  ),
                                ),
                                if (breakTime.isNotEmpty) ...[
                                  const SizedBox(height: 3),
                                  Text(
                                    'Break: $breakTime',
                                    style: TextStyle(
                                      fontSize: 11.5,
                                      color: onSurface.withValues(alpha: 0.60),
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 5,
                            ),
                            decoration: BoxDecoration(
                              color: isClosed
                                  ? const Color(0xFFEF4444)
                                      .withValues(alpha: 0.15)
                                  : const Color(0xFF10B981)
                                      .withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              hours,
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                                color: isClosed
                                    ? const Color(0xFFEF4444)
                                    : const Color(0xFF10B981),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }),

                const SizedBox(height: 16),
                Text(
                  'Borrowing & Study Guidelines',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: onSurface.withValues(alpha: 0.92),
                  ),
                ),
                const SizedBox(height: 10),
                GlassCard(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: rawRules.map((rule) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Padding(
                              padding: EdgeInsets.only(top: 2),
                              child: Icon(
                                Icons.check_circle_rounded,
                                size: 16,
                                color: Color(0xFF6366F1),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                rule,
                                style: TextStyle(
                                  fontSize: 12.5,
                                  height: 1.4,
                                  fontWeight: FontWeight.w500,
                                  color: onSurface.withValues(alpha: 0.82),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }

  Widget _buildZoneCard({
    required bool isDark,
    required IconData icon,
    required String title,
    required String subtitle,
    required Color accent,
  }) {
    final onSurface = Theme.of(context).colorScheme.onSurface;
    return GlassCard(
      borderRadius: 18,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: accent.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 18, color: accent),
          ),
          const SizedBox(height: 10),
          Text(
            title,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: onSurface,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            subtitle,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              color: onSurface.withValues(alpha: 0.62),
            ),
          ),
        ],
      ),
    );
  }
}
