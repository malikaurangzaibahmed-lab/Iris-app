import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../core/animations.dart';
import '../core/format_guard.dart';
import '../core/models.dart';
import '../core/omni_brain.dart';
import '../core/almanac_theme_tokens.dart';
import '../core/editorial_theme_tokens.dart';
import '../core/notebook_theme_tokens.dart';
import '../core/line_theme_tokens.dart';
import '../core/poster_theme_tokens.dart';
import '../core/sticker_tokens.dart';
import '../core/theme_signals.dart';
import '../core/vital_theme.dart';
import '../services/ui_feedback.dart';
import '../widgets/glass_card.dart';
import 'package:iris/widgets/cards/sticker_card.dart';
import 'package:iris/widgets/controls/doodle_speech_bubble.dart';
import 'package:iris/widgets/controls/washi_tape_chip.dart';
import 'package:iris/widgets/effects/doodle_mascots.dart';
import 'package:iris/widgets/effects/glass_container_transform.dart';
import 'package:iris/widgets/navigation/liquid_glass_sticky_header.dart';
import 'package:iris/screens/student/cgpa_calculator_screen.dart';
import 'package:iris/screens/academics/department_classes_screen.dart';
import 'package:iris/screens/tools/document_workspace_screen.dart';
import 'package:iris/screens/faculty/faculty_directory_screen.dart';
import 'package:iris/screens/academics/makeup_lecture_scheduler_screen.dart';
import 'package:iris/screens/student/repeater_course_planner_screen.dart';
import 'package:iris/screens/academics/room_finder_screen.dart';
import 'tools/semester_schedule_screen.dart';
import 'tools/library_schedule_screen.dart';
import 'tools/transport_schedule_screen.dart';
import 'tools/uni_info_screen.dart';

/// Professional, commercial-grade Academic Tools & Resources Screen.
/// Seamlessly supports Material 3 Expressive (Google Pixel style) and Liquid Glass engines.
class ToolsScreen extends StatefulWidget {
  final UniversityMemory memory;
  final String batch;
  final OmniBrain brain;
  final ValueChanged<String>? onRoleChanged;
  final ValueChanged<String>? onBatchChanged;
  final Future<void> Function(ClassSession session)? onAddMakeupClass;
  final Future<void> Function(ClassSession session)? onRemoveMakeupClass;
  final ScrollController? scrollController;
  final String searchQuery;

  const ToolsScreen({
    super.key,
    required this.memory,
    required this.batch,
    required this.brain,
    this.onRoleChanged,
    this.onBatchChanged,
    this.onAddMakeupClass,
    this.onRemoveMakeupClass,
    this.scrollController,
    this.searchQuery = '',
  });

  @override
  State<ToolsScreen> createState() => ToolsScreenState();
}

class ToolsScreenState extends State<ToolsScreen> {
  String _activeCategory = 'All';
  late String _searchQuery;
  late final TextEditingController _searchController;
  final FocusNode _searchFocusNode = FocusNode();

  static const List<String> _categories = [
    'All',
    'Academics',
    'Campus & Rooms',
    'Daily Utilities',
  ];

  static const List<_ToolItem> _universalTools = [
    _ToolItem(
      id: 'find_rooms',
      title: 'Room Finder',
      subtitle: 'Circular vacancy dial & quiet study scores',
      icon: Icons.meeting_room_rounded,
      color: Color(0xFF14B8A6),
      category: 'Campus & Rooms',
      description: 'Locate vacant lecture halls, labs, and study spaces across campus in real time.',
      badge: 'Live Gauge',
    ),
    _ToolItem(
      id: 'faculty_directory',
      title: 'Faculty Directory & Locator',
      subtitle: '215+ instructors, live status & office hours',
      icon: Icons.person_search_rounded,
      color: Color(0xFF8B5CF6),
      category: 'Campus & Rooms',
      description: 'Search all faculty profiles, live teaching availability, and 1-tap call/email actions.',
      badge: '215+ Active',
    ),
    _ToolItem(
      id: 'cgpa_calculator',
      title: 'CGPA Calculator',
      subtitle: 'Semester forecast & cumulative CGPA simulator',
      icon: Icons.calculate_rounded,
      color: Color(0xFF10B981),
      category: 'Academics',
      description: 'Compute GPA, credit hours, and cumulative degree projections with dynamic grading.',
      badge: 'Simulator',
    ),
    _ToolItem(
      id: 'browse_classes',
      title: 'Department Timetables',
      subtitle: 'Browse all program & intake schedules',
      icon: Icons.school_rounded,
      color: Color(0xFF0284C7),
      category: 'Academics',
      description: 'Lookup any class schedule across Computer Science, Software Engineering, EE, and Management.',
      badge: 'Campus-Wide',
    ),
    _ToolItem(
      id: 'makeup_scheduler',
      title: 'Makeup Lecture Planner',
      subtitle: 'Conflict-free mutual free-slot engine',
      icon: Icons.event_repeat_rounded,
      color: Color(0xFFF59E0B),
      category: 'Academics',
      description: 'Automatically discover matching free intervals between student batches and faculty instructors.',
      badge: 'Smart AI',
    ),
    _ToolItem(
      id: 'doc_workspace',
      title: 'Document Workspace',
      subtitle: 'Official COMSATS cover page & docx studio',
      icon: Icons.edit_document,
      color: Color(0xFFF43F5E),
      category: 'Academics',
      description: 'Generate standardized assignment cover pages, draft coursework, and export native Word documents.',
      badge: 'Docx Studio',
    ),
    _ToolItem(
      id: 'repeater_planner',
      title: 'Repeater & Clash Planner',
      subtitle: 'Multi-batch course clash solver',
      icon: Icons.alt_route_rounded,
      color: Color(0xFF7C3AED),
      category: 'Academics',
      description: 'Pick improvement or repeater subjects from other sections without lecture overlaps.',
      badge: 'Clash Solver',
    ),
    _ToolItem(
      id: 'semester_schedule',
      title: 'Semester Schedule',
      subtitle: 'Academic calendar, exams & milestones',
      icon: Icons.event_note_rounded,
      color: Color(0xFF84CC16),
      category: 'Daily Utilities',
      description: 'Official academic roadmap: add/drop deadlines, midterms, finals, and semester resumption dates.',
      badge: 'Calendar',
    ),
    _ToolItem(
      id: 'transport_schedule',
      title: 'Transport Schedule',
      subtitle: 'Campus bus departures & driver directory',
      icon: Icons.directions_bus_rounded,
      color: Color(0xFF06B6D4),
      category: 'Daily Utilities',
      description: 'Live shuttle timings, route stops matrix, and university transport driver contacts.',
      badge: 'Bus Shuttle',
    ),
    _ToolItem(
      id: 'library_schedule',
      title: 'Library Hours & Rules',
      subtitle: 'Opening hours, quiet zones & book borrowing',
      icon: Icons.local_library_rounded,
      color: Color(0xFF6366F1),
      category: 'Daily Utilities',
      description: 'Central library operating hours, peak quiet periods, borrowing quotas, and digital catalog.',
      badge: 'Quiet Study',
    ),
    _ToolItem(
      id: 'uni_info',
      title: 'University Directory',
      subtitle: 'Administration & student helpdesk contacts',
      icon: Icons.info_outline_rounded,
      color: Color(0xFF3B82F6),
      category: 'Daily Utilities',
      description: 'Official campus directory, departmental administration, emergency desks, and lab directories.',
      badge: 'Directory',
    ),
  ];

  int? _cachedVacantCount;
  DateTime? _lastVacantCheckTime;

  @override
  void initState() {
    super.initState();
    _searchQuery = widget.searchQuery;
    _searchController = TextEditingController(text: widget.searchQuery);
  }

  @override
  void didUpdateWidget(covariant ToolsScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.searchQuery != oldWidget.searchQuery) {
      setState(() {
        _searchQuery = widget.searchQuery;
        _searchController.text = widget.searchQuery;
      });
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  int _getLiveVacantRoomsCount() {
    final now = DateTime.now();
    if (_cachedVacantCount != null &&
        _lastVacantCheckTime != null &&
        now.difference(_lastVacantCheckTime!).inSeconds < 45) {
      return _cachedVacantCount!;
    }
    try {
      final currentHour = now.hour + (now.minute / 60.0);
      final dayIndex = now.weekday;
      final sessions = widget.memory.activeSessions();
      if (sessions.isEmpty) {
        _cachedVacantCount = 14;
        _lastVacantCheckTime = now;
        return 14;
      }
      final occupiedRooms = <String>{};
      final totalRooms = <String>{};
      for (final s in sessions) {
        final r = FormatGuard.sanitizeRoom(s.room);
        if (r.isNotEmpty && r != 'TBD') {
          totalRooms.add(r);
          if (s.dayIndex == dayIndex &&
              s.safeStartVal <= currentHour &&
              currentHour < s.actualEndVal) {
            occupiedRooms.add(r);
          }
        }
      }
      final vacant = totalRooms.length - occupiedRooms.length;
      final count = vacant > 0 ? vacant : 12;
      _cachedVacantCount = count;
      _lastVacantCheckTime = now;
      return count;
    } catch (_) {
      return _cachedVacantCount ?? 14;
    }
  }

  Future<void> _handleToolTap(
    BuildContext context,
    String id, {
    Widget? originWidget,
    Widget? originIcon,
    GlobalKey? originKey,
    Rect? initialBounds,
    double originRadius = 32.0,
  }) async {
    IrisHaptics.actionMedium();

    Widget? iconToUse = originIcon;
    if (iconToUse == null) {
      _ToolItem? matched;
      try {
        matched = _universalTools.firstWhere((t) => t.id == id);
      } catch (_) {}
      if (matched != null) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        iconToUse = Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            color: matched.color.withValues(alpha: isDark ? 0.28 : 0.16),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: matched.color.withValues(alpha: isDark ? 0.45 : 0.30),
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: matched.color.withValues(alpha: isDark ? 0.32 : 0.18),
                blurRadius: 18,
                spreadRadius: 1,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Center(
            child: Icon(matched.icon, color: matched.color, size: 28),
          ),
        );
      }
    }

    switch (id) {
      case 'cgpa_calculator':
        await pushGlassContainerMorphRoute(
          context,
          originWidget: originWidget,
          originIcon: iconToUse,
          originKey: originKey,
          initialBounds: initialBounds,
          originRadius: originRadius,
          page: const CgpaCalculatorScreen(),
          accentColor: const Color(0xFF10B981),
        );
        return;
      case 'faculty_directory':
        await pushGlassContainerMorphRoute(
          context,
          originWidget: originWidget,
          originIcon: iconToUse,
          originKey: originKey,
          initialBounds: initialBounds,
          originRadius: originRadius,
          page: FacultyDirectoryScreen(
            brain: widget.brain,
            onRoleChanged: widget.onRoleChanged,
            memory: widget.memory,
            currentBatch: widget.batch,
          ),
          accentColor: const Color(0xFF8B5CF6),
        );
        return;
      case 'browse_classes':
        await pushGlassContainerMorphRoute(
          context,
          originWidget: originWidget,
          originIcon: iconToUse,
          originKey: originKey,
          initialBounds: initialBounds,
          originRadius: originRadius,
          page: DepartmentClassesScreen(
            memory: widget.memory,
            currentBatch: widget.batch,
            brain: widget.brain,
            onRoleChanged: widget.onRoleChanged,
            showBatchShortcut: false,
            showDock: false,
            showBackButton: true,
          ),
          accentColor: const Color(0xFF0284C7),
        );
        return;
      case 'makeup_scheduler':
        await pushGlassContainerMorphRoute(
          context,
          originWidget: originWidget,
          originIcon: iconToUse,
          originKey: originKey,
          initialBounds: initialBounds,
          originRadius: originRadius,
          page: MakeupLectureScheduler(
            memory: widget.memory,
            brain: widget.brain,
            batch: widget.batch,
            onAddMakeupClass: widget.onAddMakeupClass ?? (_) async {},
            onRemoveMakeupClass: widget.onRemoveMakeupClass,
            onRoleChanged: widget.onRoleChanged,
            showDock: false,
            showBackButton: true,
          ),
          accentColor: const Color(0xFFF59E0B),
        );
        return;
      case 'repeater_planner':
        await pushGlassContainerMorphRoute(
          context,
          originWidget: originWidget,
          originIcon: iconToUse,
          originKey: originKey,
          initialBounds: initialBounds,
          originRadius: originRadius,
          page: RepeaterCoursePlannerScreen(
            memory: widget.memory,
            brain: widget.brain,
            initialBatch: widget.batch,
            onScheduleActivated: () {
              if (mounted) setState(() {});
            },
          ),
          accentColor: const Color(0xFF7C3AED),
        );
        return;
      case 'find_rooms':
        await pushGlassContainerMorphRoute(
          context,
          originWidget: originWidget,
          originIcon: iconToUse,
          originKey: originKey,
          initialBounds: initialBounds,
          originRadius: originRadius,
          page: RoomFinderScreen(memory: widget.memory),
          accentColor: const Color(0xFF14B8A6),
        );
        return;
      case 'doc_workspace':
        await pushGlassContainerMorphRoute(
          context,
          originWidget: originWidget,
          originIcon: iconToUse,
          originKey: originKey,
          initialBounds: initialBounds,
          originRadius: originRadius,
          page: const DocumentWorkspaceScreen(),
          accentColor: const Color(0xFFF43F5E),
        );
        return;
      case 'transport_schedule':
        await pushGlassContainerMorphRoute(
          context,
          originWidget: originWidget,
          originIcon: iconToUse,
          originKey: originKey,
          initialBounds: initialBounds,
          originRadius: originRadius,
          page: const TransportScheduleScreen(),
          accentColor: const Color(0xFF06B6D4),
        );
        return;
      case 'library_schedule':
        await pushGlassContainerMorphRoute(
          context,
          originWidget: originWidget,
          originIcon: iconToUse,
          originKey: originKey,
          initialBounds: initialBounds,
          originRadius: originRadius,
          page: const LibraryScheduleScreen(),
          accentColor: const Color(0xFF6366F1),
        );
        return;
      case 'semester_schedule':
        await pushGlassContainerMorphRoute(
          context,
          originWidget: originWidget,
          originIcon: iconToUse,
          originKey: originKey,
          initialBounds: initialBounds,
          originRadius: originRadius,
          page: SemesterScheduleScreen(batch: widget.batch),
          accentColor: const Color(0xFF84CC16),
        );
        return;
      case 'uni_info':
        await pushGlassContainerMorphRoute(
          context,
          originWidget: originWidget,
          originIcon: iconToUse,
          originKey: originKey,
          initialBounds: initialBounds,
          originRadius: originRadius,
          page: const UniInfoScreen(),
          accentColor: const Color(0xFF3B82F6),
        );
        return;
      default:
        return;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final now = DateTime.now();
    final currentClass = widget.brain.getCurrentClass(widget.batch, now);
    final nextClass = widget.brain.getNextClass(widget.batch, now);
    final vacantCount = _getLiveVacantRoomsCount();

    final isSearching = _searchQuery.trim().isNotEmpty;
    final isCategoryFiltered = _activeCategory != 'All';

    List<_ToolItem> displayTools = _universalTools;
    if (isCategoryFiltered) {
      displayTools = displayTools.where((t) => t.category == _activeCategory).toList();
    }
    if (isSearching) {
      final q = _searchQuery.trim().toLowerCase();
      displayTools = displayTools.where((t) {
        return t.title.toLowerCase().contains(q) ||
            t.subtitle.toLowerCase().contains(q) ||
            t.description.toLowerCase().contains(q);
      }).toList();
    }

    // -------------------------------------------------------------------------
    // Theme 1: Almanac (Broadside Newspaper Classifieds & Directory)
    // -------------------------------------------------------------------------
    if (ThemeSignals.isAlmanac) {
      return _buildAlmanacClassifiedsView(
        context,
        isDark: isDark,
        vacantCount: vacantCount,
        displayTools: displayTools,
        isSearching: isSearching,
        isCategoryFiltered: isCategoryFiltered,
      );
    }

    // -------------------------------------------------------------------------
    // Theme 2: Editorial Academic (Oxford Literary Study & Catalogue)
    // -------------------------------------------------------------------------
    if (ThemeSignals.isEditorialAcademic) {
      return _buildEditorialClassifiedsView(
        context,
        isDark: isDark,
        vacantCount: vacantCount,
        displayTools: displayTools,
        isSearching: isSearching,
        isCategoryFiltered: isCategoryFiltered,
      );
    }

    // -------------------------------------------------------------------------
    // Theme 3: Notebook / Stationery (Pin-Up Corkboard Journal)
    // -------------------------------------------------------------------------
    if (ThemeSignals.isNotebook) {
      return _buildNotebookClassifiedsView(
        context,
        isDark: isDark,
        vacantCount: vacantCount,
        displayTools: displayTools,
        isSearching: isSearching,
        isCategoryFiltered: isCategoryFiltered,
      );
    }

    // -------------------------------------------------------------------------
    // Theme 4: Line / Subway Transit (Metro Interchange & Map Directory)
    // -------------------------------------------------------------------------
    if (ThemeSignals.isLine) {
      return _buildLineClassifiedsView(
        context,
        isDark: isDark,
        vacantCount: vacantCount,
        displayTools: displayTools,
        isSearching: isSearching,
        isCategoryFiltered: isCategoryFiltered,
      );
    }

    // -------------------------------------------------------------------------
    // Theme 5: Poster / Swiss Brutalism (Monolithic Grotesque Directory)
    // -------------------------------------------------------------------------
    if (ThemeSignals.isPoster) {
      return _buildPosterClassifiedsView(
        context,
        isDark: isDark,
        vacantCount: vacantCount,
        displayTools: displayTools,
        isSearching: isSearching,
        isCategoryFiltered: isCategoryFiltered,
      );
    }

    // -------------------------------------------------------------------------
    // Material 3 Expressive (Comic Scrapbook & Sticker Journal Mode)
    // -------------------------------------------------------------------------
    if (ThemeSignals.isMaterialYou) {
      return _buildExpressiveStickerView(
        context,
        isDark: isDark,
        vacantCount: vacantCount,
        displayTools: displayTools,
        isSearching: isSearching,
        isCategoryFiltered: isCategoryFiltered,
      );
    }

    // -------------------------------------------------------------------------
    // Liquid Glass Mode (100% UNTOUCHED Preservation Contract)
    // -------------------------------------------------------------------------
    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 840),
        child: CustomScrollView(
          controller: widget.scrollController,
          physics: const ButterScrollPhysics(
            parent: AlwaysScrollableScrollPhysics(),
          ),
          cacheExtent: 450.0,
          slivers: [
            // 1. Sleek Sticky Collapsing Header
            SliverPersistentHeader(
              pinned: true,
              delegate: ToolsLiquidGlassStickyHeaderDelegate(
                topPadding: MediaQuery.paddingOf(context).top,
                vacantCount: vacantCount,
                isDark: isDark,
                canPop: Navigator.of(context).canPop(),
                onBack: () => Navigator.pop(context),
              ),
            ),

            // 2. Smart Campus Radar Hero Cockpit Card (Shown when not actively searching)
            if (!isSearching && _activeCategory == 'All') ...[
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 6, 20, 16),
                  child: _buildCampusRadarCockpit(
                    context,
                    isDark: isDark,
                    current: currentClass,
                    next: nextClass,
                    vacantCount: vacantCount,
                  ),
                ),
              ),
            ],

            // 3. Search Bar Capsule
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: _buildSearchCapsule(context, isDark),
              ),
            ),

            // 4. Symmetrical Category Pills
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 14, 20, 16),
                child: _buildCategoryPills(isDark),
              ),
            ),

            // 5. Tool Grid / Search Results View
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              sliver: (isSearching || isCategoryFiltered)
                  ? _buildFilteredGridView(context, isDark, displayTools)
                  : _buildBentoGridView(context, isDark, vacantCount),
            ),

            const SliverToBoxAdapter(
              child: SizedBox(height: 120),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------


  // ---------------------------------------------------------------------------
  // 2. Smart Campus Radar Hero Cockpit Card
  // ---------------------------------------------------------------------------
  Widget _buildCampusRadarCockpit(
    BuildContext context, {
    required bool isDark,
    required ClassSession? current,
    required ClassSession? next,
    required int vacantCount,
  }) {
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;
    final now = DateTime.now();

    final isLive = current != null;
    final isUpcoming = !isLive && next != null && next.dayIndex == now.weekday;

    int minutesToNext = 0;
    if (isUpcoming) {
      final currentHour = now.hour + (now.minute / 60.0);
      final diff = next.safeStartVal - currentHour;
      if (diff > 0) minutesToNext = (diff * 60).round();
    }

    double progressPercent = 0.0;
    int remainingMins = 0;
    if (isLive) {
      final startMin = current.safeStartVal * 60;
      final endMin = current.actualEndVal * 60;
      final nowMin = now.hour * 60 + now.minute;
      final duration = endMin - startMin;
      if (duration > 0) {
        final elapsed = (nowMin - startMin).clamp(0, duration);
        progressPercent = (elapsed / duration).clamp(0.0, 1.0);
        remainingMins = (endMin - nowMin).clamp(0, 300).round();
      }
    }

    final headline = isLive
        ? current.subject
        : (isUpcoming ? next.subject : 'Campus Study Window');

    final statusTag = isLive
        ? 'IN SESSION'
        : (isUpcoming ? 'UP NEXT IN $minutesToNext MINS' : 'FREE INTERVAL');

    final statusColor = isLive
        ? const Color(0xFF10B981)
        : (isUpcoming ? const Color(0xFFF59E0B) : const Color(0xFF8B5CF6));

    final subline = isLive
        ? 'Room ${current.room} • Instructor: ${current.teacher}'
        : (isUpcoming
            ? 'Room ${next.room} • Starts at ${next.startTime}'
            : '$vacantCount study spaces & lecture halls vacant across campus');

    return GlassCard(
      borderRadius: 32,
      elevation: 3,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: isDark ? 0.22 : 0.12),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: statusColor.withValues(alpha: 0.4),
                    width: 1.0,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 7,
                      height: 7,
                      decoration: BoxDecoration(
                        color: statusColor,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 7),
                    Text(
                      statusTag,
                      style: TextStyle(
                        fontSize: 9.5,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.8,
                        color: statusColor,
                      ),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              Builder(
                builder: (btnCtx) {
                  final vacantButton = Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: const Color(0xFF14B8A6).withValues(alpha: isDark ? 0.2 : 0.12),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: const Color(0xFF14B8A6).withValues(alpha: 0.35),
                        width: 1.0,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.meeting_room_rounded,
                          size: 13,
                          color: Color(0xFF14B8A6),
                        ),
                        const SizedBox(width: 5),
                        Text(
                          '$vacantCount Vacant',
                          style: const TextStyle(
                            fontSize: 10.5,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF14B8A6),
                          ),
                        ),
                      ],
                    ),
                  );

                  return ExpressiveInteractivePress(
                    onTap: () {
                      Rect? rect;
                      try {
                        final box = btnCtx.findRenderObject() as RenderBox?;
                        if (box != null && box.hasSize) {
                          rect = box.localToGlobal(Offset.zero) & box.size;
                        }
                      } catch (_) {}

                      final vacantIcon = Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: const Color(0xFF14B8A6).withValues(alpha: isDark ? 0.28 : 0.16),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: const Color(0xFF14B8A6).withValues(alpha: isDark ? 0.45 : 0.30),
                            width: 1.2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF14B8A6).withValues(alpha: isDark ? 0.30 : 0.16),
                              blurRadius: 16,
                              spreadRadius: 1,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: const Center(
                          child: Icon(
                            Icons.meeting_room_rounded,
                            size: 24,
                            color: Color(0xFF14B8A6),
                          ),
                        ),
                      );

                      _handleToolTap(
                        context,
                        'find_rooms',
                        initialBounds: rect,
                        originIcon: vacantIcon,
                        originRadius: 28.0,
                      );
                    },
                    pressedScale: 0.92,
                    child: vacantButton,
                  );
                },
              ),
            ],
          ),
          const SizedBox(height: 12),

          Text(
            headline,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.4,
              color: isM3 ? cs.onSurface : (isDark ? Colors.white : const Color(0xFF0F172A)),
            ),
          ),
          const SizedBox(height: 3),
          Text(
            subline,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white60 : Colors.black54),
            ),
          ),
          if (isLive) ...[
            const SizedBox(height: 14),
            ClipRRect(
              borderRadius: BorderRadius.circular(999),
              child: TweenAnimationBuilder<double>(
                duration: const Duration(milliseconds: 900),
                curve: Curves.easeOutCubic,
                tween: Tween<double>(begin: 0.0, end: progressPercent),
                builder: (context, val, _) {
                  return LinearProgressIndicator(
                    value: val,
                    minHeight: 5,
                    backgroundColor: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.08),
                    valueColor: AlwaysStoppedAnimation<Color>(statusColor),
                  );
                },
              ),
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Text(
                  '${(progressPercent * 100).toInt()}% elapsed',
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w700,
                    color: isDark ? Colors.white54 : Colors.black54,
                  ),
                ),
                const Spacer(),
                Text(
                  '$remainingMins mins remaining',
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w800,
                    color: statusColor,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 3. Search Capsule & Categories
  // ---------------------------------------------------------------------------
  Widget _buildSearchCapsule(BuildContext context, bool isDark) {
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    return Container(
      decoration: BoxDecoration(
        color: isM3
            ? cs.surfaceContainer
            : (isDark ? Colors.white.withValues(alpha: 0.05) : Colors.black.withValues(alpha: 0.04)),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: isM3
              ? cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.5)
              : (isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.07)),
          width: 1.0,
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
      child: Row(
        children: [
          Icon(
            Icons.search_rounded,
            size: 20,
            color: isM3 ? cs.primary : (isDark ? Colors.white54 : Colors.black54),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              controller: _searchController,
              focusNode: _searchFocusNode,
              onChanged: (val) {
                setState(() => _searchQuery = val);
              },
              style: TextStyle(
                fontSize: 13.5,
                fontWeight: FontWeight.w600,
                color: isM3 ? cs.onSurface : (isDark ? Colors.white : Colors.black87),
              ),
              decoration: InputDecoration(
                hintText: 'Search tools, rooms, calculators & schedules...',
                hintStyle: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w500,
                  color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white38 : Colors.black38),
                ),
                border: InputBorder.none,
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 11),
              ),
            ),
          ),
          if (_searchQuery.isNotEmpty)
            GestureDetector(
              onTap: () {
                _searchController.clear();
                setState(() => _searchQuery = '');
              },
              child: Padding(
                padding: const EdgeInsets.all(4),
                child: Icon(
                  Icons.close_rounded,
                  size: 16,
                  color: isM3 ? cs.onSurfaceVariant : (isDark ? Colors.white54 : Colors.black54),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildCategoryPills(bool isDark) {
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      physics: const BouncingScrollPhysics(),
      child: Row(
        children: _categories.map((cat) {
          final isSelected = _activeCategory == cat;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ExpressiveInteractivePress(
              onTap: () {
                IrisHaptics.chipSelect();
                setState(() => _activeCategory = cat);
              },
              pressedScale: 0.94,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: isSelected
                      ? (isM3 ? cs.primary : VitalTokens.blue)
                      : (isM3
                          ? cs.surfaceContainer
                          : (isDark ? Colors.white.withValues(alpha: 0.04) : Colors.black.withValues(alpha: 0.03))),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: isSelected
                        ? (isM3 ? cs.primary : VitalTokens.blue)
                        : (isM3
                            ? cs.outlineVariant.withValues(alpha: isDark ? 0.3 : 0.5)
                            : (isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.07))),
                    width: isSelected ? 1.5 : 1.0,
                  ),
                  boxShadow: isSelected
                      ? [
                          BoxShadow(
                            color: (isM3 ? cs.primary : VitalTokens.blue).withValues(alpha: 0.25),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ]
                      : null,
                ),
                child: Text(
                  cat,
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: isSelected ? FontWeight.w900 : FontWeight.w600,
                    color: isSelected
                        ? Colors.white
                        : (isM3 ? cs.onSurface : (isDark ? Colors.white70 : Colors.black87)),
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 4. Bento Grid (Flagship Company-Level Proportional Design)
  // ---------------------------------------------------------------------------
  SliverList _buildBentoGridView(BuildContext context, bool isDark, int vacantCount) {
    return SliverList(
      delegate: SliverChildListDelegate([
        // Row 1: Primary Campus Spaces (Room Finder & Faculty Directory)
        Row(
          children: [
            Expanded(
              child: _buildBentoCard(
                context,
                isDark: isDark,
                tool: _universalTools.firstWhere((t) => t.id == 'find_rooms'),
                customBadge: '$vacantCount Free Now',
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildBentoCard(
                context,
                isDark: isDark,
                tool: _universalTools.firstWhere((t) => t.id == 'faculty_directory'),
                customBadge: '215+ Roster',
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // Row 2: Academic Accelerators (CGPA Simulator & Browse Classes)
        Row(
          children: [
            Expanded(
              child: _buildBentoCard(
                context,
                isDark: isDark,
                tool: _universalTools.firstWhere((t) => t.id == 'cgpa_calculator'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildBentoCard(
                context,
                isDark: isDark,
                tool: _universalTools.firstWhere((t) => t.id == 'browse_classes'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // Row 3: Planning & Coursework Studio (Makeup Scheduler & Document Workspace)
        Row(
          children: [
            Expanded(
              child: _buildBentoCard(
                context,
                isDark: isDark,
                tool: _universalTools.firstWhere((t) => t.id == 'makeup_scheduler'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildBentoCard(
                context,
                isDark: isDark,
                tool: _universalTools.firstWhere((t) => t.id == 'doc_workspace'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // Row 4: Advanced Academics (Repeater Planner & Semester Calendar)
        Row(
          children: [
            Expanded(
              child: _buildBentoCard(
                context,
                isDark: isDark,
                tool: _universalTools.firstWhere((t) => t.id == 'repeater_planner'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildBentoCard(
                context,
                isDark: isDark,
                tool: _universalTools.firstWhere((t) => t.id == 'semester_schedule'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // Row 5: Daily Campus Utilities (Transport, Library, Uni Info)
        Row(
          children: [
            Expanded(
              child: _buildBentoCard(
                context,
                isDark: isDark,
                tool: _universalTools.firstWhere((t) => t.id == 'transport_schedule'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildBentoCard(
                context,
                isDark: isDark,
                tool: _universalTools.firstWhere((t) => t.id == 'library_schedule'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // Full-width University Helpdesk & Info card
        _buildBentoCard(
          context,
          isDark: isDark,
          tool: _universalTools.firstWhere((t) => t.id == 'uni_info'),
          isFullWidth: true,
        ),
      ]),
    );
  }

  Widget _buildBentoCard(
    BuildContext context, {
    required bool isDark,
    required _ToolItem tool,
    String? customBadge,
    bool isFullWidth = false,
  }) {
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;
    final badgeText = customBadge ?? tool.badge;

    final cardContent = GlassCard(
      borderRadius: 32,
      elevation: 2,
      padding: const EdgeInsets.all(16),
      accentColor: tool.color,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: tool.color.withValues(alpha: isDark ? 0.22 : 0.12),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: tool.color.withValues(alpha: isDark ? 0.35 : 0.25),
                    width: 1.0,
                  ),
                ),
                child: Icon(tool.icon, color: tool.color, size: 20),
              ),
              const Spacer(),
              if (badgeText != null && badgeText.isNotEmpty)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3.5),
                  decoration: BoxDecoration(
                    color: tool.color.withValues(alpha: isDark ? 0.18 : 0.10),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: tool.color.withValues(alpha: 0.3),
                      width: 1.0,
                    ),
                  ),
                  child: Text(
                    badgeText,
                    style: TextStyle(
                      fontSize: 9.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.4,
                      color: tool.color,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 14),

          Text(
            tool.title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 14.5,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.3,
              color: isM3
                  ? cs.onSurface
                  : (isDark ? Colors.white : const Color(0xFF0F172A)),
            ),
          ),
          const SizedBox(height: 3),
          Text(
            tool.subtitle,
            maxLines: isFullWidth ? 1 : 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 11,
              height: 1.35,
              fontWeight: FontWeight.w500,
              color: isM3
                  ? cs.onSurfaceVariant
                  : (isDark ? Colors.white54 : Colors.black54),
            ),
          ),
        ],
      ),
    );

    return Builder(
      builder: (cardCtx) {
        return ExpressiveInteractivePress(
          onTap: () {
            Rect? rect;
            try {
              final box = cardCtx.findRenderObject() as RenderBox?;
              if (box != null && box.hasSize) {
                rect = box.localToGlobal(Offset.zero) & box.size;
              }
            } catch (_) {}

            final cardIcon = Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                color: tool.color.withValues(alpha: isDark ? 0.28 : 0.16),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: tool.color.withValues(alpha: isDark ? 0.45 : 0.30),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: tool.color.withValues(alpha: isDark ? 0.32 : 0.18),
                    blurRadius: 18,
                    spreadRadius: 1,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Center(
                child: Icon(tool.icon, color: tool.color, size: 28),
              ),
            );

            _handleToolTap(
              context,
              tool.id,
              initialBounds: rect,
              originIcon: cardIcon,
              originRadius: 32.0,
            );
          },
          pressedScale: 0.95,
          child: cardContent,
        );
      },
    );
  }

  // ---------------------------------------------------------------------------
  // 5. Filtered / Search Grid View (Liquid Glass Mode)
  // ---------------------------------------------------------------------------
  SliverList _buildFilteredGridView(
    BuildContext context,
    bool isDark,
    List<_ToolItem> tools,
  ) {
    if (tools.isEmpty) {
      return SliverList(
        delegate: SliverChildListDelegate([
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 40),
            child: Center(
              child: Column(
                children: [
                  Icon(
                    Icons.search_off_rounded,
                    size: 48,
                    color: isDark ? Colors.white24 : Colors.black26,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'No tools found for "$_searchQuery"',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: isDark ? Colors.white60 : Colors.black54,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ]),
      );
    }

    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context, index) {
          final tool = tools[index];
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _buildBentoCard(
              context,
              isDark: isDark,
              tool: tool,
              isFullWidth: true,
            ),
          );
        },
        childCount: tools.length,
      ),
    );
  }

  // ===========================================================================
  // THEME 1: ALMANAC BROADSIDE CLASSIFIEDS & ACADEMIC DIRECTORY
  // ===========================================================================
  Widget _buildAlmanacClassifiedsView(
    BuildContext context, {
    required bool isDark,
    required int vacantCount,
    required List<_ToolItem> displayTools,
    required bool isSearching,
    required bool isCategoryFiltered,
  }) {
    final topPadding = MediaQuery.paddingOf(context).top;
    final canPop = Navigator.of(context).canPop();
    final isTablet = MediaQuery.sizeOf(context).width >= 600;

    return Container(
      color: AlmanacTokens.canvas(isDark),
      child: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 840),
          child: CustomScrollView(
            controller: widget.scrollController,
            physics: const AlwaysScrollableScrollPhysics(
              parent: BouncingScrollPhysics(),
            ),
            cacheExtent: 500.0,
            slivers: [
              // 1. Broadsheet Masthead Header
              SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(22, topPadding + 14, 22, 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (canPop) ...[
                                GestureDetector(
                                  onTap: () {
                                    IrisHaptics.actionSoft();
                                    Navigator.pop(context);
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.all(6),
                                    margin: const EdgeInsets.only(right: 10),
                                    decoration: BoxDecoration(
                                      color: AlmanacTokens.cardSurface(isDark),
                                      border: Border.all(
                                        color: AlmanacTokens.inkRule(isDark),
                                        width: 1.0,
                                      ),
                                    ),
                                    child: Icon(
                                      Icons.arrow_back_rounded,
                                      size: 16,
                                      color: AlmanacTokens.inkHeading(isDark),
                                    ),
                                  ),
                                ),
                              ],
                              Text(
                                'IRIS · DIRECTORY',
                                style: AlmanacTokens.monoHeader(isDark, fontSize: 11),
                              ),
                            ],
                          ),
                          Text(
                            'SPECIAL EDITION · $vacantCount HALLS OPEN',
                            style: AlmanacTokens.monoHeader(
                              isDark,
                              fontSize: 10.5,
                              color: AlmanacTokens.accentTerracotta(isDark),
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),

                      // Double Hairline Rule
                      _buildAlmanacDoubleRule(isDark),
                      const SizedBox(height: 14),

                      // Main Title
                      Text(
                        'Academic Classifieds',
                        style: AlmanacTokens.serifHeadline(
                          isDark,
                          fontSize: 26,
                          fontWeight: FontWeight.w700,
                          letterSpacing: -0.5,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Official university registry, facility gauges, and computational resources.',
                        style: AlmanacTokens.countdownNarrative(isDark),
                      ),
                      const SizedBox(height: 18),

                      // Real-time Vacancy / Study Alert (when not actively searching)
                      if (!isSearching) ...[
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          decoration: BoxDecoration(
                            color: AlmanacTokens.cardSurface(isDark),
                            border: Border.all(
                              color: AlmanacTokens.accentTerracotta(isDark),
                              width: 1.0,
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.meeting_room_outlined,
                                size: 18,
                                color: AlmanacTokens.accentTerracotta(isDark),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  '★ CAMPUS RADAR: $vacantCount lecture halls & quiet spaces currently available.',
                                  style: AlmanacTokens.monoHeader(
                                    isDark,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: AlmanacTokens.accentTerracotta(isDark),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                      ],

                      // Search Input Box (Broadside Style)
                      Container(
                        height: 48,
                        decoration: BoxDecoration(
                          color: AlmanacTokens.cardSurface(isDark),
                          border: Border.all(
                            color: AlmanacTokens.inkRule(isDark),
                            width: 1.0,
                          ),
                        ),
                        child: Row(
                          children: [
                            const SizedBox(width: 14),
                            Icon(
                              Icons.search_rounded,
                              size: 18,
                              color: AlmanacTokens.inkMuted(isDark),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: TextField(
                                controller: _searchController,
                                focusNode: _searchFocusNode,
                                onChanged: (val) {
                                  setState(() => _searchQuery = val);
                                },
                                style: AlmanacTokens.monoHeader(
                                  isDark,
                                  fontSize: 13,
                                  color: AlmanacTokens.inkHeading(isDark),
                                ),
                                decoration: InputDecoration(
                                  isDense: true,
                                  border: InputBorder.none,
                                  hintText: 'SEARCH DIRECTORY, ROOMS, TOOLS...',
                                  hintStyle: AlmanacTokens.monoHeader(
                                    isDark,
                                    fontSize: 11.5,
                                    color: AlmanacTokens.inkMuted(isDark),
                                  ),
                                ),
                              ),
                            ),
                            if (_searchQuery.isNotEmpty) ...[
                              GestureDetector(
                                onTap: () {
                                  _searchController.clear();
                                  setState(() => _searchQuery = '');
                                },
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 12),
                                  child: Icon(
                                    Icons.close_rounded,
                                    size: 16,
                                    color: AlmanacTokens.inkMuted(isDark),
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),

                      // Symmetrical Broadsheet Category Pills
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        physics: const BouncingScrollPhysics(),
                        child: Row(
                          children: _categories.map((cat) {
                            final isSelected = _activeCategory == cat;
                            return GestureDetector(
                              onTap: () {
                                IrisHaptics.chipSelect();
                                setState(() => _activeCategory = cat);
                              },
                              child: Container(
                                margin: const EdgeInsets.only(right: 8),
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                                decoration: BoxDecoration(
                                  color: isSelected
                                      ? (isDark ? const Color(0xFFEAE6DF) : const Color(0xFF111111))
                                      : AlmanacTokens.cardSurface(isDark),
                                  border: Border.all(
                                    color: isSelected
                                        ? (isDark ? const Color(0xFFEAE6DF) : const Color(0xFF111111))
                                        : AlmanacTokens.inkRuleSubtle(isDark),
                                    width: 1.0,
                                  ),
                                ),
                                child: Text(
                                  cat.toUpperCase(),
                                  style: AlmanacTokens.monoHeader(
                                    isDark,
                                    fontSize: 10.5,
                                    fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                                    letterSpacing: 0.8,
                                    color: isSelected
                                        ? (isDark ? Colors.black : Colors.white)
                                        : AlmanacTokens.inkMuted(isDark),
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                      const SizedBox(height: 14),

                      // Hairline Divider
                      Container(
                        height: 0.8,
                        color: AlmanacTokens.inkRuleSubtle(isDark),
                      ),
                    ],
                  ),
                ),
              ),

              // 2. Classifieds Tool Grid
              if (displayTools.isEmpty) ...[
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(40),
                    child: Center(
                      child: Text(
                        '[ No tools found matching "$_searchQuery" ]',
                        style: AlmanacTokens.countdownNarrative(isDark),
                      ),
                    ),
                  ),
                ),
              ] else ...[
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 22),
                  sliver: SliverGrid(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: isTablet ? 2 : 1,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      mainAxisExtent: 130,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (context, index) {
                        final tool = displayTools[index];
                        return _buildAlmanacToolCard(context, tool, isDark);
                      },
                      childCount: displayTools.length,
                    ),
                  ),
                ),
              ],

              const SliverToBoxAdapter(
                child: SizedBox(height: 120),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAlmanacToolCard(BuildContext context, _ToolItem tool, bool isDark) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _handleToolTap(context, tool.id),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AlmanacTokens.cardSurface(isDark),
          border: Border.all(
            color: AlmanacTokens.inkRuleSubtle(isDark),
            width: 1.0,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        tool.title,
                        style: AlmanacTokens.serifHeadline(
                          isDark,
                          fontSize: 15.5,
                          fontWeight: FontWeight.w700,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        tool.subtitle,
                        style: AlmanacTokens.monoHeader(
                          isDark,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w500,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                if (tool.badge != null) ...[
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: AlmanacTokens.accentTerracotta(isDark),
                        width: 0.8,
                      ),
                    ),
                    child: Text(
                      tool.badge!.toUpperCase(),
                      style: AlmanacTokens.monoHeader(
                        isDark,
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                        color: AlmanacTokens.accentTerracotta(isDark),
                      ),
                    ),
                  ),
                ],
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  tool.category.toUpperCase(),
                  style: AlmanacTokens.monoHeader(
                    isDark,
                    fontSize: 9.5,
                    letterSpacing: 0.5,
                    color: AlmanacTokens.inkMuted(isDark),
                  ),
                ),
                Icon(
                  Icons.arrow_forward_rounded,
                  size: 14,
                  color: AlmanacTokens.accentTerracotta(isDark),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAlmanacDoubleRule(bool isDark) {
    final color = AlmanacTokens.inkRule(isDark);
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(height: 1.5, color: color),
        const SizedBox(height: 3.5),
        Container(height: 0.8, color: color),
      ],
    );
  }

  // ===========================================================================
  // THEME 2: EDITORIAL ACADEMIC SCHOLARLY CATALOGUE & DIRECTORY
  // ===========================================================================
  Widget _buildEditorialClassifiedsView(
    BuildContext context, {
    required bool isDark,
    required int vacantCount,
    required List<_ToolItem> displayTools,
    required bool isSearching,
    required bool isCategoryFiltered,
  }) {
    final topPadding = MediaQuery.paddingOf(context).top;
    final canPop = Navigator.of(context).canPop();
    final isTablet = MediaQuery.sizeOf(context).width >= 600;

    return Container(
      color: EditorialTokens.canvas(isDark),
      child: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 840),
          child: CustomScrollView(
            controller: widget.scrollController,
            physics: const AlwaysScrollableScrollPhysics(
              parent: BouncingScrollPhysics(),
            ),
            cacheExtent: 500.0,
            slivers: [
              // 1. Literary Masthead Header
              SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(20, topPadding + 14, 20, 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (canPop) ...[
                                GestureDetector(
                                  onTap: () {
                                    IrisHaptics.actionSoft();
                                    Navigator.pop(context);
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.all(7),
                                    margin: const EdgeInsets.only(right: 10),
                                    decoration: BoxDecoration(
                                      color: isDark ? const Color(0xFF1E2235) : Colors.white,
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                        color: isDark ? const Color(0xFF283042) : const Color(0xFFE8E2D6),
                                      ),
                                    ),
                                    child: Icon(
                                      Icons.arrow_back_rounded,
                                      size: 18,
                                      color: isDark ? Colors.white : const Color(0xFF1E1B18),
                                    ),
                                  ),
                                ),
                              ],
                              Text(
                                'ACADEMIC CATALOGUE · OXFORD STUDY',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 1.2,
                                  color: isDark ? const Color(0xFF8E9BAE) : const Color(0xFF5A4D41),
                                ),
                              ),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3.5),
                            decoration: BoxDecoration(
                              color: const Color(0xFF10B981).withValues(alpha: isDark ? 0.22 : 0.12),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: const Color(0xFF10B981).withValues(alpha: 0.6),
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  width: 5.5,
                                  height: 5.5,
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Color(0xFF10B981),
                                  ),
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  '$vacantCount ROOMS VACANT',
                                  style: GoogleFonts.spaceMono(
                                    fontSize: 9.5,
                                    fontWeight: FontWeight.w700,
                                    color: const Color(0xFF10B981),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'University Library & Scholarly Tools',
                        style: GoogleFonts.fraunces(
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -0.4,
                          color: isDark ? Colors.white : const Color(0xFF1E1B18),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // 2. Study Space Vacancy Hero Ticket Pass (if not searching)
              if (!isSearching && _activeCategory == 'All') ...[
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 6, 20, 16),
                    child: GestureDetector(
                      onTap: () {
                        IrisHaptics.actionSoft();
                        _handleToolTap(context, 'room_finder');
                      },
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: isDark ? const Color(0xFF181D2B) : Colors.white,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: isDark ? const Color(0xFF283042) : const Color(0xFFE8E2D6),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.05),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                color: const Color(0xFFEFA335).withValues(alpha: isDark ? 0.25 : 0.15),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Center(
                                child: Icon(
                                  Icons.meeting_room_rounded,
                                  color: Color(0xFFEFA335),
                                  size: 22,
                                ),
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'QUIET STUDY HALL RADAR',
                                    style: GoogleFonts.plusJakartaSans(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 0.8,
                                      color: const Color(0xFFEFA335),
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    '$vacantCount Quiet Study Halls Open Now',
                                    style: GoogleFonts.fraunces(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w800,
                                      color: isDark ? Colors.white : const Color(0xFF1E1B18),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const Icon(
                              Icons.arrow_forward_ios_rounded,
                              size: 14,
                              color: Color(0xFFEFA335),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],

              // 3. Search Capsule Input
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Container(
                    decoration: BoxDecoration(
                      color: isDark ? const Color(0xFF181D2B) : Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: isDark ? const Color(0xFF283042) : const Color(0xFFE8E2D6),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: isDark ? 0.20 : 0.04),
                          blurRadius: 6,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: Row(
                      children: [
                        Icon(
                          Icons.search_rounded,
                          size: 18,
                          color: isDark ? const Color(0xFF8E9BAE) : const Color(0xFF64748B),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextField(
                            controller: _searchController,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 13.5,
                              color: isDark ? Colors.white : const Color(0xFF1E1B18),
                            ),
                            decoration: InputDecoration(
                              hintText: 'Search scholarly tools, calculators & halls...',
                              hintStyle: GoogleFonts.plusJakartaSans(
                                fontSize: 13,
                                color: isDark ? const Color(0xFF64748B) : const Color(0xFF94A3B8),
                              ),
                              border: InputBorder.none,
                            ),
                          ),
                        ),
                        if (_searchQuery.isNotEmpty)
                          GestureDetector(
                            onTap: () {
                              _searchController.clear();
                              setState(() => _searchQuery = '');
                            },
                            child: const Icon(Icons.close_rounded, size: 16),
                          ),
                      ],
                    ),
                  ),
                ),
              ),

              // 4. Category Pills
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 14, 20, 16),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: _categories.map((cat) {
                        final isSelected = _activeCategory == cat;
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: GestureDetector(
                            onTap: () {
                              IrisHaptics.selectionClick();
                              setState(() => _activeCategory = cat);
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? (isDark ? const Color(0xFFF59E0B) : const Color(0xFFEFA335))
                                    : (isDark ? const Color(0xFF181D2B) : Colors.white),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                  color: isSelected
                                      ? Colors.transparent
                                      : (isDark ? const Color(0xFF283042) : const Color(0xFFE8E2D6)),
                                ),
                              ),
                              child: Text(
                                cat,
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 11.5,
                                  fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                                  color: isSelected
                                      ? const Color(0xFF1E1B18)
                                      : (isDark ? const Color(0xFFCBD5E1) : const Color(0xFF475569)),
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ),

              // 5. Tool Grid
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                sliver: SliverGrid(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: isTablet ? 3 : 2,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.15,
                  ),
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      final tool = displayTools[index];
                      return _buildEditorialToolCard(context, tool, isDark);
                    },
                    childCount: displayTools.length,
                  ),
                ),
              ),

              const SliverToBoxAdapter(
                child: SizedBox(height: 110),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEditorialToolCard(BuildContext context, _ToolItem tool, bool isDark) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _handleToolTap(context, tool.id),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF181D2B) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isDark ? const Color(0xFF283042) : const Color(0xFFE8E2D6),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.05),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        tool.title,
                        style: GoogleFonts.fraunces(
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                          color: isDark ? Colors.white : const Color(0xFF1E1B18),
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        tool.subtitle,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w500,
                          color: isDark ? const Color(0xFF8E9BAE) : const Color(0xFF64748B),
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                if (tool.badge != null) ...[
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEFA335).withValues(alpha: isDark ? 0.25 : 0.15),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      tool.badge!.toUpperCase(),
                      style: GoogleFonts.spaceMono(
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                        color: const Color(0xFFEFA335),
                      ),
                    ),
                  ),
                ],
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  tool.category.toUpperCase(),
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 9.5,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                    color: isDark ? const Color(0xFF8E9BAE) : const Color(0xFF64748B),
                  ),
                ),
                const Icon(
                  Icons.arrow_forward_rounded,
                  size: 14,
                  color: Color(0xFFEFA335),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ===========================================================================
  // THEME 3: NOTEBOOK / STATIONERY (PIN-UP CORKBOARD & DESK JOURNAL)
  // ===========================================================================
  Widget _buildNotebookClassifiedsView(
    BuildContext context, {
    required bool isDark,
    required int vacantCount,
    required List<_ToolItem> displayTools,
    required bool isSearching,
    required bool isCategoryFiltered,
  }) {
    final topPadding = MediaQuery.paddingOf(context).top;
    final canPop = Navigator.of(context).canPop();
    final isTablet = MediaQuery.sizeOf(context).width >= 600;

    return Container(
      color: NotebookTokens.canvas(isDark),
      child: CustomPaint(
        painter: NotebookGraphPaperPainter(
          isDark: isDark,
          gridSize: 22.0,
          marginX: 42.0,
        ),
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 840),
            child: CustomScrollView(
              controller: widget.scrollController,
              physics: const AlwaysScrollableScrollPhysics(
                parent: BouncingScrollPhysics(),
              ),
              slivers: [
                // 1. 3D Metallic Spiral Rings at Pad Top
                SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.only(top: topPadding + 6, left: 14, right: 14),
                    child: NotebookSpiralRings(ringCount: 12, isDark: isDark),
                  ),
                ),

                // 2. Notebook Masthead
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(48, 12, 20, 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (canPop) ...[
                                  GestureDetector(
                                    onTap: () {
                                      IrisHaptics.actionSoft();
                                      Navigator.pop(context);
                                    },
                                    child: Container(
                                      padding: const EdgeInsets.all(6),
                                      margin: const EdgeInsets.only(right: 10),
                                      decoration: BoxDecoration(
                                        color: isDark ? const Color(0xFF23302A) : Colors.white,
                                        borderRadius: BorderRadius.circular(8),
                                        border: Border.all(
                                          color: NotebookTokens.redDoodle(isDark).withValues(alpha: 0.5),
                                        ),
                                      ),
                                      child: Icon(
                                        Icons.arrow_back_rounded,
                                        size: 16,
                                        color: NotebookTokens.inkHeading(isDark),
                                      ),
                                    ),
                                  ),
                                ],
                                Text(
                                  'DESK JOURNAL · SUPPLIES',
                                  style: GoogleFonts.caveat(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                    color: NotebookTokens.redDoodle(isDark),
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: const Color(0xFF10B981).withValues(alpha: isDark ? 0.22 : 0.12),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: const Color(0xFF10B981).withValues(alpha: 0.6),
                                ),
                              ),
                              child: Text(
                                '$vacantCount SPACES FREE',
                                style: GoogleFonts.kalam(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  color: const Color(0xFF10B981),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Study Tools & Resource Desk',
                          style: NotebookTokens.boldScript(
                            isDark,
                            fontSize: 26,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 2),
                        CustomPaint(
                          size: const Size(140, 8),
                          painter: HandDrawnSquiggleUnderlinePainter(
                            color: NotebookTokens.redDoodle(isDark),
                            strokeWidth: 2.0,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // 3. Hero Yellow Sticky Note: Study Hall Radar (Breaks Bounds with 3D Tape)
                if (!isSearching && _activeCategory == 'All') ...[
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(36, 8, 20, 18),
                      child: GestureDetector(
                        onTap: () {
                          IrisHaptics.actionSoft();
                          _handleToolTap(context, 'room_finder');
                        },
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: NotebookTokens.stickyNote(isDark),
                                borderRadius: BorderRadius.circular(4),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.12),
                                    offset: const Offset(2, 5),
                                    blurRadius: 9,
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 44,
                                    height: 44,
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFEFA335).withValues(alpha: 0.25),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: const Center(
                                      child: Icon(
                                        Icons.meeting_room_rounded,
                                        color: Color(0xFF7A5813),
                                        size: 22,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'QUIET STUDY HALL RADAR',
                                          style: GoogleFonts.caveat(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w700,
                                            color: const Color(0xFF6B5826),
                                          ),
                                        ),
                                        Text(
                                          '$vacantCount Quiet Study Spaces Free Now',
                                          style: GoogleFonts.kalam(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w700,
                                            color: const Color(0xFF1C1917),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const Icon(
                                    Icons.arrow_forward_ios_rounded,
                                    size: 14,
                                    color: Color(0xFF6B5826),
                                  ),
                                ],
                              ),
                            ),
                            Positioned(
                              top: -10,
                              left: 24,
                              child: WashiTapeOverhang(
                                width: 56,
                                height: 18,
                                color: NotebookTokens.tapeFrosted,
                                rotation: -0.02,
                              ),
                            ),
                            Positioned(
                              bottom: 0,
                              right: 0,
                              child: CurledPaperCorner(
                                size: 20,
                                isDark: isDark,
                                paperColor: NotebookTokens.stickyNote(isDark),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],

                // 4. Sketched Search Box
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(40, 0, 20, 14),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(
                        color: isDark ? const Color(0xFF23302A) : Colors.white,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: isDark ? const Color(0xFF2F453B) : const Color(0xFFE5E0D6),
                          width: 1.2,
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.search_rounded,
                            size: 18,
                            color: NotebookTokens.redDoodle(isDark),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: TextField(
                              controller: _searchController,
                              style: GoogleFonts.kalam(
                                fontSize: 14,
                                color: NotebookTokens.inkHeading(isDark),
                              ),
                              decoration: InputDecoration(
                                hintText: 'Search notebook tools, calculators & halls...',
                                hintStyle: GoogleFonts.caveat(
                                  fontSize: 15,
                                  color: NotebookTokens.inkMuted(isDark),
                                ),
                                border: InputBorder.none,
                              ),
                            ),
                          ),
                          if (_searchQuery.isNotEmpty)
                            GestureDetector(
                              onTap: () {
                                _searchController.clear();
                                setState(() => _searchQuery = '');
                              },
                              child: const Icon(Icons.close_rounded, size: 16),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),

                // 5. Category Sticky Pills
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(40, 0, 20, 16),
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: _categories.map((cat) {
                          final isSelected = _activeCategory == cat;
                          return Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: GestureDetector(
                              onTap: () {
                                IrisHaptics.selectionClick();
                                setState(() => _activeCategory = cat);
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                decoration: BoxDecoration(
                                  color: isSelected
                                      ? NotebookTokens.highlighterYellow.withValues(alpha: 0.85)
                                      : (isDark ? const Color(0xFF23302A) : Colors.white),
                                  borderRadius: BorderRadius.circular(6),
                                  border: Border.all(
                                    color: isSelected
                                        ? const Color(0xFFEAB308)
                                        : (isDark ? const Color(0xFF2F453B) : const Color(0xFFE5E0D6)),
                                  ),
                                ),
                                child: Text(
                                  cat,
                                  style: GoogleFonts.kalam(
                                    fontSize: 12.5,
                                    fontWeight: isSelected ? FontWeight.w700 : FontWeight.w600,
                                    color: isSelected
                                        ? const Color(0xFF1C1917)
                                        : NotebookTokens.inkBody(isDark),
                                  ),
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),

                // 6. Tools Grid with Washi Tape Overhangs
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(36, 0, 20, 20),
                  sliver: SliverGrid(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: isTablet ? 3 : 2,
                      mainAxisSpacing: 14,
                      crossAxisSpacing: 12,
                      childAspectRatio: 1.15,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (context, index) {
                        final tool = displayTools[index];
                        return _buildNotebookToolCard(context, tool, isDark);
                      },
                      childCount: displayTools.length,
                    ),
                  ),
                ),

                const SliverToBoxAdapter(
                  child: SizedBox(height: 120),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNotebookToolCard(BuildContext context, _ToolItem tool, bool isDark) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _handleToolTap(context, tool.id),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF23302A) : Colors.white,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(
                color: isDark ? const Color(0xFF2F453B) : const Color(0xFFE5E0D6),
                width: 0.9,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: isDark ? 0.28 : 0.08),
                  offset: const Offset(1, 4),
                  blurRadius: 7,
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      tool.title,
                      style: GoogleFonts.kalam(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: NotebookTokens.inkHeading(isDark),
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      tool.subtitle,
                      style: GoogleFonts.caveat(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: NotebookTokens.inkMuted(isDark),
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      tool.category,
                      style: GoogleFonts.caveat(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: NotebookTokens.redDoodle(isDark),
                      ),
                    ),
                    const Icon(
                      Icons.arrow_forward_rounded,
                      size: 14,
                      color: Color(0xFFE11D48),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Positioned(
            top: -7,
            left: 14,
            child: WashiTapeOverhang(
              width: 38,
              height: 14,
              color: NotebookTokens.tapeYellow,
              rotation: 0.04,
            ),
          ),
        ],
      ),
    );
  }

  // ===========================================================================
  // THEME 4: LINE / SUBWAY TRANSIT (METRO INTERCHANGE & SYSTEM MAP)
  // ===========================================================================
  Widget _buildLineClassifiedsView(
    BuildContext context, {
    required bool isDark,
    required int vacantCount,
    required List<_ToolItem> displayTools,
    required bool isSearching,
    required bool isCategoryFiltered,
  }) {
    final topPadding = MediaQuery.paddingOf(context).top;
    final canPop = Navigator.of(context).canPop();
    final isTablet = MediaQuery.sizeOf(context).width >= 600;

    return Container(
      color: LineTokens.canvas(isDark),
      child: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 840),
          child: CustomScrollView(
            controller: widget.scrollController,
            physics: const AlwaysScrollableScrollPhysics(
              parent: BouncingScrollPhysics(),
            ),
            slivers: [
              // 1. Line Transit Header
              SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(20, topPadding + 14, 20, 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (canPop) ...[
                                GestureDetector(
                                  onTap: () {
                                    IrisHaptics.actionSoft();
                                    Navigator.pop(context);
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.all(6),
                                    margin: const EdgeInsets.only(right: 10),
                                    decoration: BoxDecoration(
                                      color: LineTokens.cardSurface(isDark),
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                        color: isDark ? const Color(0xFF28303C) : const Color(0xFFD6D1C4),
                                      ),
                                    ),
                                    child: Icon(
                                      Icons.arrow_back_rounded,
                                      size: 16,
                                      color: LineTokens.inkHeading(isDark),
                                    ),
                                  ),
                                ),
                              ],
                              Text(
                                'METRO TRANSIT · TOOLS HUB',
                                style: LineTokens.lineTag(isDark),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Central Interchange',
                            style: LineTokens.heroMonDate(isDark).copyWith(fontSize: 24),
                          ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: LineTokens.ledAmber,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          'OPERATIONAL',
                          style: GoogleFonts.archivoBlack(
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                            color: LineTokens.ledBlack,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // 2. Study Hall Beacon
              if (!isSearching && _activeCategory == 'All') ...[
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                    child: GestureDetector(
                      onTap: () {
                        IrisHaptics.actionSoft();
                        _handleToolTap(context, 'room_finder');
                      },
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: LineTokens.cardSurface(isDark),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: LineTokens.subwayYellow,
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.06),
                              offset: const Offset(0, 3),
                              blurRadius: 6,
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            StationStopNode(
                              isCurrentPosition: true,
                              isDark: isDark,
                              size: 22,
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'PLATFORM RADAR',
                                    style: LineTokens.lineTag(isDark),
                                  ),
                                  Text(
                                    '$vacantCount Study Platforms Available Now',
                                    style: GoogleFonts.archivoBlack(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w900,
                                      color: LineTokens.inkHeading(isDark),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const Icon(
                              Icons.arrow_forward_rounded,
                              size: 16,
                              color: LineTokens.subwayYellow,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],

              // 3. Search Bar
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(
                      color: LineTokens.cardSurface(isDark),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: isDark ? const Color(0xFF28303C) : const Color(0xFFD6D1C4),
                        width: 1.2,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.search_rounded,
                          size: 18,
                          color: LineTokens.inkMuted(isDark),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextField(
                            controller: _searchController,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 13.5,
                              color: LineTokens.inkHeading(isDark),
                            ),
                            decoration: InputDecoration(
                              hintText: 'Search station tools, calculators & halls...',
                              hintStyle: GoogleFonts.plusJakartaSans(
                                fontSize: 13,
                                color: LineTokens.inkMuted(isDark),
                              ),
                              border: InputBorder.none,
                            ),
                          ),
                        ),
                        if (_searchQuery.isNotEmpty)
                          GestureDetector(
                            onTap: () {
                              _searchController.clear();
                              setState(() => _searchQuery = '');
                            },
                            child: const Icon(Icons.close_rounded, size: 16),
                          ),
                      ],
                    ),
                  ),
                ),
              ),

              // 4. Category Pills
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 14, 20, 16),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: _categories.map((cat) {
                        final isSelected = _activeCategory == cat;
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: GestureDetector(
                            onTap: () {
                              IrisHaptics.selectionClick();
                              setState(() => _activeCategory = cat);
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? LineTokens.subwayYellow
                                    : LineTokens.cardSurface(isDark),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: isSelected
                                      ? LineTokens.subwayYellow
                                      : (isDark ? const Color(0xFF28303C) : const Color(0xFFD6D1C4)),
                                ),
                              ),
                              child: Text(
                                cat.toUpperCase(),
                                style: GoogleFonts.spaceMono(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  color: isSelected
                                      ? LineTokens.ledBlack
                                      : LineTokens.inkBody(isDark),
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ),

              // 5. Tools Grid
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                sliver: SliverGrid(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: isTablet ? 3 : 2,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.15,
                  ),
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      final tool = displayTools[index];
                      return _buildLineToolCard(context, tool, isDark);
                    },
                    childCount: displayTools.length,
                  ),
                ),
              ),

              const SliverToBoxAdapter(
                child: SizedBox(height: 120),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLineToolCard(BuildContext context, _ToolItem tool, bool isDark) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _handleToolTap(context, tool.id),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: LineTokens.cardSurface(isDark),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isDark ? const Color(0xFF28303C) : const Color(0xFFD6D1C4),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.06),
              offset: const Offset(0, 3),
              blurRadius: 6,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        tool.title.toUpperCase(),
                        style: GoogleFonts.archivoBlack(
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          color: LineTokens.inkHeading(isDark),
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        color: LineTokens.subwayYellow,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 3),
                Text(
                  tool.subtitle,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 11,
                    color: LineTokens.inkMuted(isDark),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  tool.category.toUpperCase(),
                  style: GoogleFonts.spaceMono(
                    fontSize: 9.5,
                    fontWeight: FontWeight.w700,
                    color: LineTokens.inkMuted(isDark),
                  ),
                ),
                const Icon(
                  Icons.arrow_forward_rounded,
                  size: 14,
                  color: LineTokens.subwayYellow,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ===========================================================================
  // THEME 5: POSTER / SWISS BRUTALISM (MONOLITHIC GROTESQUE DIRECTORY)
  // ===========================================================================
  Widget _buildPosterClassifiedsView(
    BuildContext context, {
    required bool isDark,
    required int vacantCount,
    required List<_ToolItem> displayTools,
    required bool isSearching,
    required bool isCategoryFiltered,
  }) {
    final topPadding = MediaQuery.paddingOf(context).top;
    final canPop = Navigator.of(context).canPop();
    final isTablet = MediaQuery.sizeOf(context).width >= 600;

    return Container(
      color: PosterTokens.canvas(isDark),
      child: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 840),
          child: CustomScrollView(
            controller: widget.scrollController,
            physics: const AlwaysScrollableScrollPhysics(
              parent: BouncingScrollPhysics(),
            ),
            slivers: [
              // 1. Top Swiss Monospace Tag Bar
              SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(20, topPadding + 14, 20, 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (canPop) ...[
                            GestureDetector(
                              onTap: () {
                                IrisHaptics.actionSoft();
                                Navigator.pop(context);
                              },
                              child: Container(
                                padding: const EdgeInsets.all(6),
                                margin: const EdgeInsets.only(right: 10),
                                decoration: BoxDecoration(
                                  color: PosterTokens.cardSurface(isDark),
                                  border: Border.all(
                                    color: PosterTokens.inkBorder(isDark),
                                    width: 1.5,
                                  ),
                                ),
                                child: Icon(
                                  Icons.arrow_back_rounded,
                                  size: 16,
                                  color: PosterTokens.inkHeading(isDark),
                                ),
                              ),
                            ),
                          ],
                          Text(
                            'IRIS / ARCHITECTURAL DIRECTORY',
                            style: GoogleFonts.spaceMono(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.2,
                              color: PosterTokens.inkHeading(isDark),
                            ),
                          ),
                        ],
                      ),
                      Text(
                        '$vacantCount ROOMS',
                        style: GoogleFonts.spaceMono(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.2,
                          color: PosterTokens.orangeHero,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // 2. High-Impact International Orange Hero Block
              if (!isSearching && _activeCategory == 'All') ...[
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 6, 20, 20),
                    child: GestureDetector(
                      onTap: () {
                        IrisHaptics.actionSoft();
                        _handleToolTap(context, 'room_finder');
                      },
                      child: Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: PosterTokens.orangeHero,
                          boxShadow: PosterTokens.extrudedBlockShadow(
                            isDark,
                            offset: 5.0,
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '00 · QUIET STUDY RADAR',
                              style: GoogleFonts.spaceMono(
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 1.2,
                                color: Colors.black,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              '$vacantCount QUIET HALLS OPEN NOW',
                              style: PosterTokens.heroMonolithicClock(isDark).copyWith(fontSize: 24),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],

              // 3. Brutalist Search Box
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(
                      color: PosterTokens.cardSurface(isDark),
                      border: Border.all(
                        color: PosterTokens.inkBorder(isDark),
                        width: 2.0,
                      ),
                      boxShadow: PosterTokens.extrudedBlockShadow(isDark, offset: 3.0),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.search_rounded,
                          size: 18,
                          color: PosterTokens.inkHeading(isDark),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextField(
                            controller: _searchController,
                            style: GoogleFonts.spaceMono(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: PosterTokens.inkHeading(isDark),
                            ),
                            decoration: InputDecoration(
                              hintText: 'SEARCH TOOLS & DIRECTORIES...',
                              hintStyle: GoogleFonts.spaceMono(
                                fontSize: 12,
                                color: PosterTokens.inkMuted(isDark),
                              ),
                              border: InputBorder.none,
                            ),
                          ),
                        ),
                        if (_searchQuery.isNotEmpty)
                          GestureDetector(
                            onTap: () {
                              _searchController.clear();
                              setState(() => _searchQuery = '');
                            },
                            child: const Icon(Icons.close_rounded, size: 16),
                          ),
                      ],
                    ),
                  ),
                ),
              ),

              // 4. Tabular Swiss Category Pills
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: _categories.map((cat) {
                        final isSelected = _activeCategory == cat;
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: GestureDetector(
                            onTap: () {
                              IrisHaptics.selectionClick();
                              setState(() => _activeCategory = cat);
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? PosterTokens.orangeHero
                                    : PosterTokens.cardSurface(isDark),
                                border: Border.all(
                                  color: PosterTokens.inkBorder(isDark),
                                  width: 2.0,
                                ),
                                boxShadow: isSelected
                                    ? PosterTokens.extrudedBlockShadow(isDark, offset: 3.0)
                                    : null,
                              ),
                              child: Text(
                                cat.toUpperCase(),
                                style: GoogleFonts.spaceMono(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  color: isSelected
                                      ? Colors.black
                                      : PosterTokens.inkHeading(isDark),
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ),

              // 5. Monolithic Tools Grid (01, 02, 03)
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                sliver: SliverGrid(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: isTablet ? 3 : 2,
                    mainAxisSpacing: 14,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.15,
                  ),
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      final tool = displayTools[index];
                      final indexStr = (index + 1).toString().padLeft(2, '0');
                      return _buildPosterToolCard(context, tool, indexStr, isDark);
                    },
                    childCount: displayTools.length,
                  ),
                ),
              ),

              const SliverToBoxAdapter(
                child: SizedBox(height: 120),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPosterToolCard(BuildContext context, _ToolItem tool, String indexStr, bool isDark) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _handleToolTap(context, tool.id),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: PosterTokens.cardSurface(isDark),
          border: Border.all(
            color: PosterTokens.inkBorder(isDark),
            width: 2.2,
          ),
          boxShadow: PosterTokens.extrudedBlockShadow(isDark, offset: 4.0),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      indexStr,
                      style: GoogleFonts.spaceMono(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: PosterTokens.orangeHero,
                      ),
                    ),
                    if (tool.badge != null)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                        decoration: BoxDecoration(
                          color: PosterTokens.inkBorder(isDark),
                        ),
                        child: Text(
                          tool.badge!.toUpperCase(),
                          style: GoogleFonts.spaceMono(
                            fontSize: 8.5,
                            fontWeight: FontWeight.w700,
                            color: isDark ? Colors.black : Colors.white,
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  tool.title.toUpperCase(),
                  style: GoogleFonts.spaceGrotesk(
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -0.2,
                    color: PosterTokens.inkHeading(isDark),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  tool.subtitle,
                  style: GoogleFonts.spaceMono(
                    fontSize: 10.5,
                    color: PosterTokens.inkMuted(isDark),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  tool.category.toUpperCase(),
                  style: GoogleFonts.spaceMono(
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                    color: PosterTokens.inkHeading(isDark),
                  ),
                ),
                const Icon(
                  Icons.arrow_forward_rounded,
                  size: 14,
                  color: PosterTokens.orangeHero,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExpressiveStickerView(
    BuildContext context, {
    required bool isDark,
    required int vacantCount,
    required List<_ToolItem> displayTools,
    required bool isSearching,
    required bool isCategoryFiltered,
  }) {
    final topPadding = MediaQuery.paddingOf(context).top;
    final canPop = Navigator.of(context).canPop();

    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 840),
        child: CustomScrollView(
          controller: widget.scrollController,
          physics: const ButterScrollPhysics(
            parent: AlwaysScrollableScrollPhysics(),
          ),
          cacheExtent: 500.0,
          slivers: [
            // 1. Illustrated Comic Header
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(20, topPadding + 14, 20, 12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    if (canPop) ...[
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          margin: const EdgeInsets.only(right: 12),
                          decoration: BoxDecoration(
                            color: StickerTokens.peach(isDark),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: StickerTokens.inkOutline(isDark),
                              width: 1.8,
                            ),
                            boxShadow: StickerTokens.stickerShadow(isDark, offset: 2.0),
                          ),
                          child: Icon(
                            Icons.arrow_back_rounded,
                            size: 18,
                            color: StickerTokens.inkOutline(isDark),
                          ),
                        ),
                      ),
                    ],
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Tools & Utilities',
                            style: GoogleFonts.poppins(
                              fontSize: 27,
                              fontWeight: FontWeight.w900,
                              letterSpacing: -0.5,
                              color: isDark ? const Color(0xFFF8FAFC) : const Color(0xFF2C1810),
                              height: 1.15,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'COMSATS life on easy mode ✨',
                            style: GoogleFonts.caveat(
                              fontSize: 16.5,
                              fontWeight: FontWeight.w700,
                              color: isDark ? const Color(0xFFFCD34D) : const Color(0xFF8C5000),
                            ),
                          ),
                        ],
                      ),
                    ),
                    DoodleSpeechBubble(
                      text: '$vacantCount VACANT!',
                      emoji: '🚪',
                      tailPosition: SpeechTailPosition.left,
                      hasHatchLines: true,
                      onTap: () => _handleToolTap(context, 'find_rooms'),
                    ),
                  ],
                ),
              ),
            ),

            // 2. Playful Search Capsule (Matching Mockup 1:1)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                child: _buildPlayfulSearchCapsule(context, isDark),
              ),
            ),

            // 3. Washi-Tape Category Tabs
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 10, 20, 16),
                child: _buildWashiTapeRow(isDark),
              ),
            ),

            // 4. Main Tool Content (Featured Hero + Core Links + Stacked Utilities OR Filtered List)
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              sliver: (isSearching || isCategoryFiltered)
                  ? _buildExpressiveFilteredList(context, isDark, displayTools)
                  : _buildExpressiveBentoSliver(context, isDark, vacantCount),
            ),

            const SliverToBoxAdapter(
              child: SizedBox(height: 120),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPlayfulSearchCapsule(BuildContext context, bool isDark) {
    final searchBg = isDark ? const Color(0xFF1E2430) : const Color(0xFFFBF7EE);
    final outlineColor = StickerTokens.inkOutline(isDark);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
      decoration: BoxDecoration(
        color: searchBg,
        borderRadius: BorderRadius.circular(999.0),
        border: Border.all(color: outlineColor, width: 1.8),
        boxShadow: StickerTokens.stickerShadow(isDark, offset: 2.5),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _searchController,
              focusNode: _searchFocusNode,
              onChanged: (val) {
                setState(() => _searchQuery = val);
              },
              style: GoogleFonts.poppins(
                fontSize: 13.5,
                fontWeight: FontWeight.w600,
                color: isDark ? Colors.white : const Color(0xFF2C221A),
              ),
              decoration: InputDecoration(
                hintText: 'Search rooms, calculators, timetables...',
                hintStyle: GoogleFonts.caveat(
                  fontSize: 16.5,
                  fontWeight: FontWeight.w600,
                  color: isDark ? const Color(0xFF94A3B8) : const Color(0xFF786252),
                ),
                border: InputBorder.none,
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
              ),
            ),
          ),
          if (_searchQuery.isNotEmpty) ...[
            GestureDetector(
              onTap: () {
                _searchController.clear();
                setState(() => _searchQuery = '');
              },
              child: Padding(
                padding: const EdgeInsets.all(4),
                child: Icon(Icons.close_rounded, size: 16, color: outlineColor),
              ),
            ),
            const SizedBox(width: 4),
          ],
          Icon(
            Icons.search_rounded,
            size: 21,
            color: outlineColor,
          ),
        ],
      ),
    );
  }

  Widget _buildWashiTapeRow(bool isDark) {
    final chips = [
      (label: 'All Tools', emoji: '🎒', category: 'All', rot: -1.0),
      (label: 'Academics', emoji: '📚', category: 'Academics', rot: 1.2),
      (label: 'Campus', emoji: '🏢', category: 'Campus & Rooms', rot: -0.8),
      (label: 'Schedules', emoji: '🗓️', category: 'Campus & Rooms', rot: 1.0),
      (label: 'Daily', emoji: '☕', category: 'Daily Utilities', rot: -1.2),
    ];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      physics: const BouncingScrollPhysics(),
      child: Row(
        children: chips.map((c) {
          final isSelected = _activeCategory == c.category;
          return Padding(
            padding: const EdgeInsets.only(right: 9),
            child: WashiTapeChip(
              label: c.label,
              emoji: c.emoji,
              isSelected: isSelected,
              rotationAngle: c.rot,
              onTap: () {
                setState(() => _activeCategory = c.category);
              },
            ),
          );
        }).toList(),
      ),
    );
  }

  SliverList _buildExpressiveBentoSliver(
    BuildContext context,
    bool isDark,
    int vacantCount,
  ) {
    return SliverList(
      delegate: SliverChildListDelegate([
        // A. FEATURED SECTION HEADER
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Featured',
              style: GoogleFonts.poppins(
                fontSize: 17,
                fontWeight: FontWeight.w800,
                color: isDark ? const Color(0xFFE2E8F0) : const Color(0xFF2C221A),
              ),
            ),
            Flexible(
              child: Text(
                'check Block A-D! 👉',
                style: StickerTokens.scriptAnnotation(isDark: isDark, fontSize: 13.5),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),

        // B. HERO ROOM FINDER STICKER CARD
        StickerCard(
          backgroundColor: StickerTokens.butter(isDark),
          padding: const EdgeInsets.all(16),
          onTap: () => _handleToolTap(context, 'find_rooms'),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: const Color(0xFF14B8A6).withValues(alpha: 0.22),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color(0xFF14B8A6),
                        width: 1.8,
                      ),
                    ),
                    child: const Icon(
                      Icons.meeting_room_rounded,
                      color: Color(0xFF0D9488),
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 10),
                  DoodleSpeechBubble(
                    text: '$vacantCount ROOMS FREE NOW!',
                    emoji: '✨',
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'ROOM FINDER',
                          style: GoogleFonts.poppins(
                            fontSize: 19,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -0.3,
                            color: isDark ? Colors.white : const Color(0xFF2C1810),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Hunt down quiet study spots & empty halls! 🎯',
                          style: GoogleFonts.poppins(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                            color: isDark ? const Color(0xFFCBD5E1) : const Color(0xFF594537),
                            height: 1.3,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  CampusIsometricMascot(isDark: isDark, size: 76),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),

        // C. CORE LINKS SECTION HEADER
        Text(
          'Core Links',
          style: GoogleFonts.poppins(
            fontSize: 17,
            fontWeight: FontWeight.w800,
            color: isDark ? const Color(0xFFE2E8F0) : const Color(0xFF2C221A),
          ),
        ),
        const SizedBox(height: 10),

        // D. 2-COLUMN BENTO GRID: FACULTY FINDER & CAMPUS SCHEDULES
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Left Card: Faculty Finder
            Expanded(
              child: StickerCard(
                backgroundColor: StickerTokens.lavender(isDark),
                padding: const EdgeInsets.all(14),
                onTap: () => _handleToolTap(context, 'faculty_directory'),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const SizedBox.shrink(),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                          decoration: BoxDecoration(
                            color: isDark ? const Color(0xFF2E2240) : const Color(0xFFDDD6FE),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: isDark ? const Color(0xFF8B5CF6) : const Color(0xFF7C3AED),
                              width: 1.2,
                            ),
                          ),
                          child: Text(
                            '215+ staff 🧑‍🏫',
                            style: GoogleFonts.poppins(
                              fontSize: 9.5,
                              fontWeight: FontWeight.w800,
                              color: isDark ? const Color(0xFFC4B5FD) : const Color(0xFF5B21B6),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Center(
                      child: CartoonProfessorsMascot(isDark: isDark, size: 54),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Faculty Finder',
                      style: GoogleFonts.poppins(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        color: isDark ? Colors.white : const Color(0xFF2C1810),
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      'Cabin search & office hours, live!',
                      style: GoogleFonts.poppins(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: isDark ? const Color(0xFFCBD5E1) : const Color(0xFF594537),
                        height: 1.25,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 12),

            // Right Card: Campus Schedules
            Expanded(
              child: StickerCard(
                backgroundColor: StickerTokens.sky(isDark),
                padding: const EdgeInsets.all(14),
                onTap: () => _handleToolTap(context, 'semester_schedule'),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const SizedBox.shrink(),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                          decoration: BoxDecoration(
                            color: isDark ? const Color(0xFF1E3A5F) : const Color(0xFFBAE6FD),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: isDark ? const Color(0xFF38BDF8) : const Color(0xFF0284C7),
                              width: 1.2,
                            ),
                          ),
                          child: Text(
                            'Campus-Wide ⏰',
                            style: GoogleFonts.poppins(
                              fontSize: 9.5,
                              fontWeight: FontWeight.w800,
                              color: isDark ? const Color(0xFF7DD3FC) : const Color(0xFF0369A1),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Center(
                      child: RunningAlarmClockMascot(isDark: isDark, size: 54),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Campus Schedules',
                      style: GoogleFonts.poppins(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        color: isDark ? Colors.white : const Color(0xFF2C1810),
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      'No clash, all intakes & programs!',
                      style: GoogleFonts.poppins(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: isDark ? const Color(0xFFCBD5E1) : const Color(0xFF594537),
                        height: 1.25,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),

        // E. FULL-WIDTH UTILITY CARDS
        // 1. CGPA Calculator
        StickerCard(
          backgroundColor: StickerTokens.peach(isDark),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          onTap: () => _handleToolTap(context, 'cgpa_calculator'),
          child: Row(
            children: [
              SmilingCalculatorMascot(isDark: isDark, size: 46),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            'CGPA Calculator',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.poppins(
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              color: isDark ? Colors.white : const Color(0xFF2C1810),
                            ),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: isDark ? const Color(0xFF3B2A1E) : const Color(0xFFFFEDD5),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                              color: isDark ? const Color(0xFFFB923C) : const Color(0xFFEA580C),
                              width: 1.2,
                            ),
                          ),
                          child: Text(
                            'Sim',
                            style: GoogleFonts.poppins(
                              fontSize: 9,
                              fontWeight: FontWeight.w800,
                              color: isDark ? const Color(0xFFFDBA74) : const Color(0xFFC2410C),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Simulate & forecast target grades 📊',
                      style: GoogleFonts.poppins(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                        color: isDark ? const Color(0xFFCBD5E1) : const Color(0xFF594537),
                      ),
                    ),
                  ],
                ),
              ),
              const JaggedStampBadge(label: 'NEW'),
            ],
          ),
        ),
        const SizedBox(height: 10),

        // 2. Makeup Lectures Searcher
        StickerCard(
          backgroundColor: StickerTokens.yellow(isDark),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          onTap: () => _handleToolTap(context, 'makeup_scheduler'),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF332F1A) : const Color(0xFFFEF08A),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: StickerTokens.inkOutline(isDark),
                    width: 1.5,
                  ),
                ),
                child: const Center(
                  child: Text('☕🗓️', style: TextStyle(fontSize: 18)),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Makeup Lectures Searcher',
                      style: GoogleFonts.poppins(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        color: isDark ? Colors.white : const Color(0xFF2C1810),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Conflict-free mutual free-slot engine 🕒',
                      style: GoogleFonts.poppins(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                        color: isDark ? const Color(0xFFCBD5E1) : const Color(0xFF594537),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),

        // 3. Document Workbench
        StickerCard(
          backgroundColor: StickerTokens.rose(isDark),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          onTap: () => _handleToolTap(context, 'doc_workspace'),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF361C26) : const Color(0xFFFECDD3),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: StickerTokens.inkOutline(isDark),
                    width: 1.5,
                  ),
                ),
                child: const Center(
                  child: Text('📄✏️', style: TextStyle(fontSize: 18)),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Document Workbench',
                      style: GoogleFonts.poppins(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        color: isDark ? Colors.white : const Color(0xFF2C1810),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Official COMSATS cover pages & exports',
                      style: GoogleFonts.poppins(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                        color: isDark ? const Color(0xFFCBD5E1) : const Color(0xFF594537),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),

        // 4. Department Classes
        StickerCard(
          backgroundColor: StickerTokens.sky(isDark),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          onTap: () => _handleToolTap(context, 'browse_classes'),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF1B2E44) : const Color(0xFFBAE6FD),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: StickerTokens.inkOutline(isDark),
                    width: 1.5,
                  ),
                ),
                child: const Center(
                  child: Icon(Icons.school_rounded, color: Color(0xFF0284C7), size: 22),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Browse Department Classes',
                      style: GoogleFonts.poppins(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        color: isDark ? Colors.white : const Color(0xFF2C1810),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'All student cohorts & section schedules',
                      style: GoogleFonts.poppins(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                        color: isDark ? const Color(0xFFCBD5E1) : const Color(0xFF594537),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),

        // 5. Transport Schedule
        StickerCard(
          backgroundColor: StickerTokens.mint(isDark),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          onTap: () => _handleToolTap(context, 'transport_schedule'),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF163228) : const Color(0xFFBBF7D0),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: StickerTokens.inkOutline(isDark),
                    width: 1.5,
                  ),
                ),
                child: const Center(
                  child: Icon(Icons.directions_bus_rounded, color: Color(0xFF059669), size: 22),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Transport Schedule',
                      style: GoogleFonts.poppins(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        color: isDark ? Colors.white : const Color(0xFF2C1810),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Campus bus shuttle departures & route stops',
                      style: GoogleFonts.poppins(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                        color: isDark ? const Color(0xFFCBD5E1) : const Color(0xFF594537),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ]),
    );
  }

  SliverList _buildExpressiveFilteredList(
    BuildContext context,
    bool isDark,
    List<_ToolItem> tools,
  ) {
    if (tools.isEmpty) {
      return SliverList(
        delegate: SliverChildListDelegate([
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 40),
            child: Center(
              child: Column(
                children: [
                  Icon(
                    Icons.search_off_rounded,
                    size: 48,
                    color: isDark ? Colors.white24 : Colors.black26,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'No tools found for "$_searchQuery"',
                    style: GoogleFonts.poppins(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: isDark ? Colors.white60 : Colors.black54,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ]),
      );
    }

    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context, index) {
          final tool = tools[index];
          final pastelColors = [
            StickerTokens.butter(isDark),
            StickerTokens.lavender(isDark),
            StickerTokens.sky(isDark),
            StickerTokens.peach(isDark),
            StickerTokens.rose(isDark),
            StickerTokens.mint(isDark),
            StickerTokens.yellow(isDark),
          ];
          final bgColor = pastelColors[index % pastelColors.length];

          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: StickerCard(
              backgroundColor: bgColor,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              onTap: () => _handleToolTap(context, tool.id),
              child: Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: tool.color.withValues(alpha: isDark ? 0.35 : 0.20),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: tool.color,
                        width: 1.5,
                      ),
                    ),
                    child: Center(
                      child: Icon(tool.icon, color: tool.color, size: 22),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          tool.title,
                          style: GoogleFonts.poppins(
                            fontSize: 15,
                            fontWeight: FontWeight.w900,
                            color: isDark ? Colors.white : const Color(0xFF2C1810),
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          tool.subtitle,
                          style: GoogleFonts.poppins(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w600,
                            color: isDark ? const Color(0xFFCBD5E1) : const Color(0xFF594537),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (tool.badge != null)
                    JaggedStampBadge(label: tool.badge!),
                ],
              ),
            ),
          );
        },
        childCount: tools.length,
      ),
    );
  }
}

// -----------------------------------------------------------------------------
// Data Contracts & Embedded Sub-Screens
// -----------------------------------------------------------------------------
class _ToolItem {
  final String id;
  final String title;
  final String subtitle;
  final String description;
  final IconData icon;
  final Color color;
  final String category;
  final String? badge;

  const _ToolItem({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.icon,
    required this.color,
    this.category = 'All',
    this.badge,
  });
}

