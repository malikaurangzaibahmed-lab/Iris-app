import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:material_3_expressive/material_3_expressive.dart';
import '../../core/theme_signals.dart';
import '../../services/ui_feedback.dart';
import 'glass_container_transform.dart';

/// Controller and state manager for global theme container morphing.
class ThemeMorphController {
  static ThemeMorphOverlayState? _activeState;

  static void _register(ThemeMorphOverlayState state) {
    _activeState = state;
    ThemeSignals.morphTransitionHandler = morphTo;
  }

  static void _unregister(ThemeMorphOverlayState state) {
    if (_activeState == state) {
      _activeState = null;
      ThemeSignals.morphTransitionHandler = null;
    }
  }

  /// Whether a container morph is currently in flight.
  static bool get isMorphing => _activeState?.isMorphing ?? false;

  /// Trigger a morph transition to [targetStyle] originating from [originRect] or [context].
  static Future<void> morphTo({
    required IrisThemeStyle targetStyle,
    Rect? originRect,
    GlobalKey? originKey,
    BuildContext? context,
  }) async {
    if (_activeState != null && _activeState!.mounted) {
      await _activeState!.startMorph(
        targetStyle: targetStyle,
        originRect: originRect,
        originKey: originKey,
        callerContext: context,
      );
    } else {
      await ThemeSignals.setThemeStyle(targetStyle);
    }
  }
}

/// An intelligent, authentic 7-theme container morphing overlay.
///
/// Wraps the application and executes high-performance 120 FPS container
/// morphing physics whenever Iris switches between any of the 7 themes:
/// - Liquid Glass (`fluidGlass`)
/// - Material 3 Expressive (`materialYou`)
/// - Almanac Botanical (`almanac`)
/// - Editorial Academic (`editorialAcademic`)
/// - Tactile Notebook (`notebook`)
/// - LINE Minimal (`line`)
/// - Swiss Poster (`poster`)
class ThemeMorphOverlay extends StatefulWidget {
  final Widget child;

  static final GlobalKey<ThemeMorphOverlayState> globalKey =
      GlobalKey<ThemeMorphOverlayState>();

  ThemeMorphOverlay({
    Key? key,
    required this.child,
  }) : super(key: key ?? globalKey);

  static Future<void> morph(
    BuildContext context, {
    required IrisThemeStyle targetStyle,
    Rect? originRect,
    GlobalKey? originKey,
  }) {
    return ThemeMorphController.morphTo(
      targetStyle: targetStyle,
      originRect: originRect,
      originKey: originKey,
      context: context,
    );
  }

  @override
  State<ThemeMorphOverlay> createState() => ThemeMorphOverlayState();
}

class ThemeMorphOverlayState extends State<ThemeMorphOverlay>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _morphAnimation;

  bool _isMorphing = false;
  bool get isMorphing => _isMorphing;

  IrisThemeStyle? _toStyle;
  Rect _startRect = Rect.zero;
  Color _monetSeed = ThemeSignals.defaultM3ESeedColor;

  @override
  void initState() {
    super.initState();
    ThemeMorphController._register(this);

    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 420),
    );

    _morphAnimation = CurvedAnimation(
      parent: _animController,
      curve: Curves.linear,
    );

    _animController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _cleanupMorph();
      }
    });
  }

  @override
  void dispose() {
    ThemeMorphController._unregister(this);
    _animController.dispose();
    super.dispose();
  }

  void _cleanupMorph() {
    if (mounted) {
      setState(() {
        _isMorphing = false;
      });
    }
  }

  Future<void> startMorph({
    required IrisThemeStyle targetStyle,
    Rect? originRect,
    GlobalKey? originKey,
    BuildContext? callerContext,
  }) async {
    if (_isMorphing || ThemeSignals.themeStyle.value == targetStyle) {
      return;
    }

    final screenSize = MediaQuery.sizeOf(context);

    final rect = IrisSpatialDepth.resolveOriginBounds(
      screenSize: screenSize,
      initialBounds: originRect,
      originKey: originKey,
      callerContext: callerContext,
      fallbackCardSize: const Size(140, 52),
    );

    _toStyle = targetStyle;
    _startRect = rect;
    _monetSeed = ThemeSignals.m3eSeedColor.value;
    _isMorphing = true;

    if (targetStyle == IrisThemeStyle.fluidGlass) {
      _animController.duration = const Duration(milliseconds: 440);
      _morphAnimation = CurvedAnimation(
        parent: _animController,
        curve: const Cubic(0.12, 0.95, 0.20, 1.04),
      );
      IrisHaptics.selectionClick();
      Future.delayed(const Duration(milliseconds: 120), () {
        IrisHaptics.actionSoft();
      });
    } else if (targetStyle == IrisThemeStyle.editorialAcademic ||
        targetStyle == IrisThemeStyle.almanac ||
        targetStyle == IrisThemeStyle.notebook) {
      _animController.duration = const Duration(milliseconds: 380);
      _morphAnimation = CurvedAnimation(
        parent: _animController,
        curve: Curves.easeOutCubic,
      );
      IrisHaptics.actionMedium();
    } else {
      _animController.duration = const Duration(milliseconds: 380);
      _morphAnimation = CurvedAnimation(
        parent: _animController,
        curve: M3EMotion.emphasizedDecelerate,
      );
      IrisHaptics.actionHeavy();
    }

    if (mounted) {
      setState(() {});
      _animController.forward(from: 0.0);
    }

    Future.delayed(const Duration(milliseconds: 130), () {
      ThemeSignals.setThemeStyle(targetStyle);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        widget.child,
        if (_isMorphing)
          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: _animController,
                builder: (context, _) {
                  return CustomPaint(
                    painter: _ThemeContainerMorphPainter(
                      progress: _morphAnimation.value,
                      startRect: _startRect,
                      toStyle: _toStyle ?? IrisThemeStyle.fluidGlass,
                      monetSeed: _monetSeed,
                    ),
                  );
                },
              ),
            ),
          ),
      ],
    );
  }
}

class _ThemeContainerMorphPainter extends CustomPainter {
  final double progress;
  final Rect startRect;
  final IrisThemeStyle toStyle;
  final Color monetSeed;

  _ThemeContainerMorphPainter({
    required this.progress,
    required this.startRect,
    required this.toStyle,
    required this.monetSeed,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;

    final center = startRect.center;
    final double maxDist = math.max(
      math.max(
        _dist(center, const Offset(0, 0)),
        _dist(center, Offset(size.width, 0)),
      ),
      math.max(
        _dist(center, Offset(0, size.height)),
        _dist(center, Offset(size.width, size.height)),
      ),
    );

    final targetRect = Rect.fromCenter(
      center: center,
      width: maxDist * 2.2,
      height: maxDist * 2.2,
    );

    final currentRect = Rect.lerp(startRect, targetRect, progress) ?? startRect;
    final double startRadius = math.min(startRect.height, startRect.width) / 2.0;
    final double currentRadius =
        ui.lerpDouble(startRadius, currentRect.width / 2.0, progress * 0.7) ??
            startRadius;

    switch (toStyle) {
      case IrisThemeStyle.fluidGlass:
        _paintLiquidGlassMorph(canvas, currentRect, currentRadius, center);
        break;
      case IrisThemeStyle.editorialAcademic:
        _paintEditorialAcademicMorph(canvas, currentRect, currentRadius);
        break;
      case IrisThemeStyle.almanac:
        _paintBespokeThemeMorph(
          canvas,
          currentRect,
          currentRadius,
          primary: const Color(0xFF4A6B5B),
          secondary: const Color(0xFFD4A373),
          surface: const Color(0xFFF6F3EC),
        );
        break;
      case IrisThemeStyle.notebook:
        _paintBespokeThemeMorph(
          canvas,
          currentRect,
          currentRadius,
          primary: const Color(0xFF2563EB),
          secondary: const Color(0xFFF59E0B),
          surface: const Color(0xFFFCFBF7),
        );
        break;
      case IrisThemeStyle.line:
        _paintBespokeThemeMorph(
          canvas,
          currentRect,
          currentRadius,
          primary: const Color(0xFF06C755),
          secondary: const Color(0xFF0EA5E9),
          surface: const Color(0xFFF7F9FA),
        );
        break;
      case IrisThemeStyle.poster:
        _paintBespokeThemeMorph(
          canvas,
          currentRect,
          currentRadius,
          primary: const Color(0xFFEF4444),
          secondary: const Color(0xFFFACC15),
          surface: const Color(0xFFF4F1EA),
        );
        break;
      case IrisThemeStyle.materialYou:
        _paintMaterialExpressiveMorph(canvas, currentRect, currentRadius);
        break;
    }
  }

  void _paintLiquidGlassMorph(
    Canvas canvas,
    Rect rect,
    double radius,
    Offset originCenter,
  ) {
    final rrect = RRect.fromRectAndRadius(rect, Radius.circular(radius));
    final double fadeAlpha =
        (1.0 - (progress - 0.70).clamp(0.0, 0.30) * 3.33).clamp(0.0, 1.0);

    final veilPaint = Paint()
      ..style = PaintingStyle.fill
      ..shader = ui.Gradient.radial(
        originCenter,
        rect.width / 2,
        [
          const Color(0xFF00F2FE).withValues(alpha: 0.18 * fadeAlpha),
          const Color(0xFF8B5CF6).withValues(alpha: 0.12 * fadeAlpha),
          Colors.transparent,
        ],
        const [0.0, 0.65, 1.0],
      );
    canvas.drawRRect(rrect, veilPaint);

    if (fadeAlpha > 0.05) {
      final bloomPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 14.0 * (1.0 - progress * 0.5)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 16.0)
        ..shader = ui.Gradient.sweep(
          originCenter,
          [
            const Color(0xFF00F2FE).withValues(alpha: 0.38 * fadeAlpha),
            const Color(0xFF8B5CF6).withValues(alpha: 0.42 * fadeAlpha),
            const Color(0xFFEC4899).withValues(alpha: 0.32 * fadeAlpha),
            const Color(0xFFF59E0B).withValues(alpha: 0.32 * fadeAlpha),
            const Color(0xFF00F2FE).withValues(alpha: 0.38 * fadeAlpha),
          ],
        );
      canvas.drawRRect(rrect, bloomPaint);
    }

    final rimPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.2 * (1.0 - progress * 0.4)
      ..shader = ui.Gradient.linear(
        rect.topLeft,
        rect.bottomRight,
        [
          const Color(0xFF00F2FE).withValues(alpha: 0.95 * fadeAlpha),
          const Color(0xFF8B5CF6).withValues(alpha: 0.90 * fadeAlpha),
          const Color(0xFFEC4899).withValues(alpha: 0.85 * fadeAlpha),
          const Color(0xFF3B82F6).withValues(alpha: 0.90 * fadeAlpha),
          const Color(0xFFF59E0B).withValues(alpha: 0.85 * fadeAlpha),
        ],
        const [0.0, 0.28, 0.55, 0.78, 1.0],
      );
    canvas.drawRRect(rrect, rimPaint);

    final glintPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1
      ..color = Colors.white.withValues(alpha: 0.78 * fadeAlpha);
    final innerRRect = RRect.fromRectAndRadius(
      rect.deflate(1.8),
      Radius.circular(math.max(0, radius - 1.8)),
    );
    canvas.drawRRect(innerRRect, glintPaint);
  }

  void _paintMaterialExpressiveMorph(
    Canvas canvas,
    Rect rect,
    double radius,
  ) {
    final rrect = RRect.fromRectAndRadius(rect, Radius.circular(radius));
    final double fadeAlpha =
        (1.0 - (progress - 0.72).clamp(0.0, 0.28) * 3.57).clamp(0.0, 1.0);

    final shadowPaint = Paint()
      ..color = Colors.black.withValues(alpha: (0.32 * fadeAlpha).clamp(0.0, 0.32))
      ..maskFilter =
          MaskFilter.blur(BlurStyle.normal, 20.0 * (1.0 - progress * 0.3));
    canvas.drawRRect(rrect.shift(const Offset(0, 5)), shadowPaint);

    final washPaint = Paint()
      ..style = PaintingStyle.fill
      ..shader = ui.Gradient.linear(
        rect.topLeft,
        rect.bottomRight,
        [
          monetSeed.withValues(alpha: 0.22 * fadeAlpha),
          Color.alphaBlend(Colors.white, monetSeed)
              .withValues(alpha: 0.14 * fadeAlpha),
        ],
      );
    canvas.drawRRect(rrect, washPaint);

    final tonalPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.6 * (1.0 - progress * 0.35)
      ..shader = ui.Gradient.linear(
        rect.topLeft,
        rect.bottomRight,
        [
          monetSeed.withValues(alpha: 0.92 * fadeAlpha),
          monetSeed.withValues(alpha: 0.50 * fadeAlpha),
          Color.alphaBlend(Colors.white, monetSeed)
              .withValues(alpha: 0.82 * fadeAlpha),
        ],
      );
    canvas.drawRRect(rrect, tonalPaint);
  }

  void _paintEditorialAcademicMorph(
    Canvas canvas,
    Rect rect,
    double radius,
  ) {
    _paintBespokeThemeMorph(
      canvas,
      rect,
      radius,
      primary: const Color(0xFFE5A83B),
      secondary: const Color(0xFFE06D53),
      surface: const Color(0xFFFAF7F2),
    );
  }

  void _paintBespokeThemeMorph(
    Canvas canvas,
    Rect rect,
    double radius, {
    required Color primary,
    required Color secondary,
    required Color surface,
  }) {
    final rrect = RRect.fromRectAndRadius(rect, Radius.circular(radius));
    final double fadeAlpha =
        (1.0 - (progress - 0.72).clamp(0.0, 0.28) * 3.57).clamp(0.0, 1.0);

    final shadowPaint = Paint()
      ..color = Colors.black.withValues(alpha: (0.24 * fadeAlpha).clamp(0.0, 0.24))
      ..maskFilter =
          MaskFilter.blur(BlurStyle.normal, 18.0 * (1.0 - progress * 0.3));
    canvas.drawRRect(rrect.shift(const Offset(0, 4)), shadowPaint);

    final washPaint = Paint()
      ..style = PaintingStyle.fill
      ..shader = ui.Gradient.linear(
        rect.topLeft,
        rect.bottomRight,
        [
          surface.withValues(alpha: 0.26 * fadeAlpha),
          primary.withValues(alpha: 0.14 * fadeAlpha),
        ],
      );
    canvas.drawRRect(rrect, washPaint);

    final rimPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.6 * (1.0 - progress * 0.35)
      ..shader = ui.Gradient.linear(
        rect.topLeft,
        rect.bottomRight,
        [
          primary.withValues(alpha: 0.92 * fadeAlpha),
          secondary.withValues(alpha: 0.78 * fadeAlpha),
          primary.withValues(alpha: 0.65 * fadeAlpha),
        ],
      );
    canvas.drawRRect(rrect, rimPaint);
  }

  double _dist(Offset a, Offset b) {
    final dx = a.dx - b.dx;
    final dy = a.dy - b.dy;
    return math.sqrt(dx * dx + dy * dy);
  }

  @override
  bool shouldRepaint(covariant _ThemeContainerMorphPainter oldDelegate) {
    return oldDelegate.progress != progress ||
        oldDelegate.startRect != startRect ||
        oldDelegate.toStyle != toStyle;
  }
}