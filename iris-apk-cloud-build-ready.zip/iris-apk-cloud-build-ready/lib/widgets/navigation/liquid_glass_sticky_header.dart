import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart' as lgw;
import '../../core/animations.dart';
import '../../core/glass.dart';
import '../../core/models.dart';
import '../../core/omni_brain.dart';
import '../../core/theme_signals.dart';
import '../../core/vital_theme.dart';
import '../../core/notebook_theme_tokens.dart';
import '../../core/line_theme_tokens.dart';
import '../../core/poster_theme_tokens.dart';
import '../../core/almanac_theme_tokens.dart';
import '../../core/editorial_theme_tokens.dart';
import '../../services/remote_config_service.dart';
import '../../services/ui_feedback.dart';
import '../iris_components.dart';
import 'package:iris/widgets/controls/iris_liquid_button.dart';
import '../../screens/faculty/faculty_schedule_view.dart' show NextLectureInfo;
import '../../services/helpdesk_faculty_service.dart' show FacultyProfile;

/// Specular glass canopy container for sticky collapsing headers.
///
/// Features:
/// 1. Zero top margin: Stretches seamlessly behind the status bar to y = 0.
/// 2. Rounded bottom: Sculpted bottom-only squircle curve with specular rim highlight.
/// 3. Frosted refraction: Hardware 16px sigma blur with adaptive ambient tint.
/// 4. Ambient bottom drop shadow onto the scrolling feed beneath.
class LiquidGlassStickyCanopy extends StatelessWidget {
  final double height;
  final double bottomRadius;
  final Color accentColor;
  final bool isDark;
  final String? imageAsset;
  final bool showAtmosphere;
  final double frostedOpacity;
  final Widget child;

  const LiquidGlassStickyCanopy({
    super.key,
    required this.height,
    required this.bottomRadius,
    required this.accentColor,
    required this.isDark,
    this.imageAsset,
    this.showAtmosphere = false,
    this.frostedOpacity = 0.85,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    final style = ThemeSignals.themeStyle.value;
    final cs = Theme.of(context).colorScheme;

    if (style == IrisThemeStyle.notebook) {
      return Container(
        height: height,
        decoration: BoxDecoration(
          color: NotebookTokens.cardSurface(isDark),
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(math.min(bottomRadius, 16.0)),
          ),
          border: Border(
            bottom: BorderSide(
              color: NotebookTokens.inkMuted(isDark).withValues(alpha: 0.35),
              width: 1.5,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.30 : 0.06),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: child,
      );
    }

    if (style == IrisThemeStyle.line) {
      return Container(
        height: height,
        decoration: BoxDecoration(
          color: LineTokens.cardSurface(isDark),
          border: Border(
            bottom: BorderSide(
              color: LineTokens.railLine(isDark),
              width: 2.0,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.40 : 0.08),
              blurRadius: 0,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: child,
      );
    }

    if (style == IrisThemeStyle.poster) {
      return Container(
        height: height,
        decoration: BoxDecoration(
          color: PosterTokens.cardSurface(isDark),
          border: Border(
            bottom: BorderSide(
              color: PosterTokens.inkBorder(isDark),
              width: 3.0,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: PosterTokens.inkBorder(isDark),
              offset: const Offset(0, 4),
              blurRadius: 0,
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: child,
      );
    }

    if (style == IrisThemeStyle.almanac) {
      return Container(
        height: height,
        decoration: BoxDecoration(
          color: AlmanacTokens.cardSurface(isDark),
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(math.min(bottomRadius, 12.0)),
          ),
          border: Border(
            bottom: BorderSide(
              color: AlmanacTokens.inkRule(isDark).withValues(alpha: 0.6),
              width: 1.5,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.30 : 0.05),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: child,
      );
    }

    if (style == IrisThemeStyle.editorialAcademic) {
      return Container(
        height: height,
        decoration: BoxDecoration(
          color: EditorialTokens.cardSurface(isDark),
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(math.min(bottomRadius, 18.0)),
          ),
          border: Border(
            bottom: BorderSide(
              color: EditorialTokens.cardBorder(isDark),
              width: 1.2,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.28 : 0.06),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: child,
      );
    }

    if (style == IrisThemeStyle.materialYou) {
      return Container(
        height: height,
        decoration: BoxDecoration(
          color: cs.surfaceContainer,
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(bottomRadius),
          ),
          border: Border(
            bottom: BorderSide(
              color: cs.outlineVariant.withValues(alpha: isDark ? 0.35 : 0.55),
              width: 1.0,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.28 : 0.08),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: child,
      );
    }

    final hasImage = imageAsset != null && imageAsset!.isNotEmpty;

    return ValueListenableBuilder<double>(
      valueListenable: ThemeSignals.glassTransparency,
      builder: (context, transparency, _) {
        final bool isOpaque = transparency <= 0.05;
        final double fallbackGlassAlpha = isOpaque
            ? 0.98
            : lerpDouble(0.98, isDark ? 0.48 : 0.55, transparency)!;
        final glassBgColor = isDark
            ? const Color(0xFF0B101E).withValues(alpha: fallbackGlassAlpha)
            : Colors.white.withValues(alpha: fallbackGlassAlpha);

        final double baseBlur = isOpaque ? 0.0 : lerpDouble(4.0, 16.0, transparency)!;
        final double effectiveBlur = hasImage
            ? (baseBlur * frostedOpacity.clamp(0.0, 1.0))
            : baseBlur;
        final double resolvedBlur = isOpaque ? 0.0 : IrisGlass.adaptiveBlur(context, effectiveBlur, min: 4.0);

        final double imageTintAlpha = hasImage
            ? ((isOpaque ? 0.85 : lerpDouble(0.70, 0.30, transparency)!) * frostedOpacity.clamp(0.0, 1.0))
            : 0.0;
        final effectiveGlassBgColor = hasImage
            ? (isDark
                ? const Color(0xFF020713).withValues(alpha: imageTintAlpha)
                : Colors.white.withValues(alpha: imageTintAlpha))
            : glassBgColor;

        return lgw.GlassBackdropGroup(
          child: Container(
          height: height,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(bottomRadius),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.12),
                blurRadius: 16,
                offset: const Offset(0, 5),
              ),
              BoxShadow(
                color: accentColor.withValues(alpha: isDark ? 0.20 : 0.12),
                blurRadius: 12,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(bottomRadius),
            ),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // 1. High-Resolution Comic Background Artwork (wrapped in RepaintBoundary for 120 FPS compositing)
                if (hasImage) ...[
                  Positioned.fill(
                    child: RepaintBoundary(
                      child: Image.asset(
                        imageAsset!,
                        fit: BoxFit.cover,
                        cacheWidth: 1080,
                        alignment: Alignment.topCenter,
                        errorBuilder: (context, error, stackTrace) => Container(
                          color: isDark ? const Color(0xFF0B101E) : const Color(0xFFF1F5F9),
                        ),
                      ),
                    ),
                  ),
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.black.withValues(alpha: isDark ? 0.48 : 0.32),
                            Colors.transparent,
                            Colors.black.withValues(alpha: isDark ? 0.62 : 0.45),
                          ],
                          stops: const [0.0, 0.40, 1.0],
                        ),
                      ),
                    ),
                  ),
                ],

                // 2. Hardware Frosted Glass Filter (Pure color-alpha + zero Opacity saveLayer overhead)
                if (!hasImage || (frostedOpacity > 0.05 && resolvedBlur > 0.1))
                  Positioned.fill(
                    child: IrisGlass.backdropFilter(
                      sigmaX: resolvedBlur,
                      sigmaY: resolvedBlur,
                      child: Container(
                        color: effectiveGlassBgColor,
                      ),
                    ),
                  )
                else if (hasImage && imageTintAlpha > 0.01)
                  Positioned.fill(
                    child: Container(
                      color: effectiveGlassBgColor,
                    ),
                  ),

                // 3. Specular Rim Border along the bottom curve
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    height: isOpaque ? 1.0 : 1.5,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          accentColor.withValues(alpha: isOpaque ? 0.05 : 0.15),
                          accentColor.withValues(
                            alpha: isOpaque
                                ? 0.35
                                : (isDark
                                    ? lerpDouble(0.45, 0.85, transparency)!
                                    : lerpDouble(0.55, 0.95, transparency)!),
                          ),
                          accentColor.withValues(alpha: isOpaque ? 0.05 : 0.15),
                        ],
                      ),
                    ),
                  ),
                ),

                // 4. Header Content Child
                Positioned.fill(
                  child: child,
                ),
              ],
            ),
          ),
          ),
        );
      },
    );
  }
}

/// Grand Pinned Sticky Collapsing Header for Home Dashboard Schedule Screen.
class HomeLiquidGlassStickyHeaderDelegate extends SliverPersistentHeaderDelegate {
  final double topPadding;
  final String displayName;
  final String greetingText;
  final String batch;
  final String period;
  final Color accentColor;
  final String? imageAsset;
  final bool isDark;
  final OmniBrain brain;
  final UniversityMemory memory;
  final List<ClassSession> schedule;
  final TemporalInsight insight;
  final ValueChanged<String>? onRoleChanged;
  final VoidCallback? onBatchTap;
  final VoidCallback? onToggleTheme;
  final VoidCallback? onAnnouncementsTap;
  final VoidCallback? onInsightTap;

  const HomeLiquidGlassStickyHeaderDelegate({
    required this.topPadding,
    required this.displayName,
    required this.greetingText,
    required this.batch,
    required this.period,
    required this.accentColor,
    this.imageAsset,
    required this.isDark,
    required this.brain,
    required this.memory,
    required this.schedule,
    required this.insight,
    this.onRoleChanged,
    this.onBatchTap,
    this.onToggleTheme,
    this.onAnnouncementsTap,
    this.onInsightTap,
  });

  @override
  double get minExtent => topPadding + 58.0;

  @override
  double get maxExtent => topPadding + 268.0;

  @override
  bool shouldRebuild(covariant HomeLiquidGlassStickyHeaderDelegate oldDelegate) {
    return oldDelegate.topPadding != topPadding ||
        oldDelegate.displayName != displayName ||
        oldDelegate.greetingText != greetingText ||
        oldDelegate.batch != batch ||
        oldDelegate.period != period ||
        oldDelegate.accentColor != accentColor ||
        oldDelegate.imageAsset != imageAsset ||
        oldDelegate.isDark != isDark ||
        oldDelegate.schedule != schedule ||
        oldDelegate.insight != insight ||
        oldDelegate.onInsightTap != onInsightTap;
  }

  String _getInitials(String name) {
    final clean = name.trim();
    if (clean.isEmpty) return 'IA';
    final parts = clean.split(RegExp(r'\s+'));
    if (parts.length >= 2) {
      final first = parts[0].isNotEmpty ? parts[0][0] : '';
      final second = parts[1].isNotEmpty ? parts[1][0] : '';
      return '$first$second'.toUpperCase();
    }
    return clean.substring(0, math.min(clean.length, 2)).toUpperCase();
  }

  Widget _buildIntegratedInsightCard(
    BuildContext context,
    bool isDark,
    Color pillColor,
  ) {
    final now = DateTime.now();
    final isLive = insight.isLive;
    final currentClass = brain.getCurrentClass(batch, now);

    final statusText = isLive
        ? 'Ongoing Class · ${insight.timeInfo ?? "35m remaining"}'
        : (insight.isUrgent
            ? 'Starting Soon · ${insight.timeInfo ?? "in 5m"}'
            : (insight.timeInfo != null
                ? '${insight.headline} · ${insight.timeInfo}'
                : insight.headline));

    final subjectTitle = currentClass?.subject ??
        ((insight.subject != null && insight.subject!.isNotEmpty)
            ? insight.subject!
            : (insight.headline != 'Break' && insight.headline != 'Free Time'
                ? insight.headline
                : insight.subline));

    final timeAndRoom = currentClass != null
        ? '${currentClass.startTime} - ${currentClass.endTime} · Room ${currentClass.room}'
        : ((insight.startTime != null &&
                insight.room != null &&
                insight.room!.isNotEmpty)
            ? '${insight.startTime} · Room ${insight.room}'
            : insight.subline);

    final teacherName = currentClass?.teacher ?? insight.teacherInfo;

    double classProgress = 0.08;
    if (currentClass != null && isLive) {
      final currentTime = now.hour + (now.minute / 60.0);
      final duration = LectureDuration.getActualDuration(currentClass);
      classProgress =
          ((currentTime - currentClass.safeStartVal) / duration).clamp(0.08, 1.0);
    } else if (insight.isUrgent) {
      classProgress = 0.35;
    }

    return ExpressiveInteractivePress(
      onTap: onInsightTap,
      pressedScale: 0.985,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: isDark
              ? const Color(0xFF030816).withValues(alpha: 0.65)
              : Colors.white.withValues(alpha: 0.58),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: (isLive ? const Color(0xFF34D399) : Colors.white).withValues(
              alpha: isDark ? 0.35 : 0.50,
            ),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: (isLive ? const Color(0xFF10B981) : pillColor).withValues(
                alpha: isDark ? 0.20 : 0.12,
              ),
              blurRadius: 14,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            // Status row with pulsing indicator
            Row(
              children: [
                Container(
                  width: 7,
                  height: 7,
                  decoration: BoxDecoration(
                    color: pillColor,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: pillColor,
                        blurRadius: 5,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 7),
                Expanded(
                  child: Text(
                    statusText,
                    style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w700,
                      color: isDark ? Colors.white70 : const Color(0xFF334155),
                      letterSpacing: 0.2,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                if (isLive || insight.isUrgent)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                      color: pillColor.withValues(alpha: 0.20),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'Live Hub',
                          style: TextStyle(
                            fontSize: 9.5,
                            fontWeight: FontWeight.w800,
                            color: pillColor,
                          ),
                        ),
                        const SizedBox(width: 3),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          size: 8,
                          color: pillColor,
                        ),
                      ],
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 5),

            // Large Bold Subject Title
            Text(
              subjectTitle,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                letterSpacing: -0.3,
                height: 1.2,
                color: isDark ? Colors.white : const Color(0xFF0F172A),
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),

            // Time, Room & Instructor Line
            Row(
              children: [
                Expanded(
                  child: Text(
                    timeAndRoom,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: (isDark ? Colors.white : Colors.black).withValues(
                        alpha: 0.65,
                      ),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                if (teacherName != null && teacherName.isNotEmpty) ...[
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      teacherName,
                      style: TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                        color: isDark ? Colors.white60 : const Color(0xFF475569),
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ],
            ),

            // Animated Progress Capsule Bar (for ongoing class)
            if (isLive || insight.isUrgent) ...[
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(99),
                child: Container(
                  height: 4.5,
                  decoration: BoxDecoration(
                    color: (isDark ? Colors.white : Colors.black).withValues(
                      alpha: 0.08,
                    ),
                    borderRadius: BorderRadius.circular(99),
                  ),
                  child: FractionallySizedBox(
                    alignment: Alignment.centerLeft,
                    widthFactor: classProgress.clamp(0.06, 1.0),
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [pillColor, pillColor.withValues(alpha: 0.75)],
                        ),
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    final extent = math.max(minExtent, maxExtent - shrinkOffset);
    final progress = ((shrinkOffset) / (maxExtent - minExtent)).clamp(0.0, 1.0);
    final bottomRadius = lerpDouble(28.0, 18.0, progress) ?? 24.0;
    final isM3 = ThemeSignals.isMaterialYou;
    final cs = Theme.of(context).colorScheme;

    final isLive = insight.isLive;
    final modeLabel = isLive
        ? 'LIVE CLASS'
        : (period == 'ramadan'
            ? '🌙 RAMADAN'
            : (period == 'sports_week'
                ? '🏆 GALA'
                : (period == 'midterms'
                    ? '✍️ MIDTERMS'
                    : (period == 'finals' ? '🎓 FINALS' : 'UPCOMING'))));

    final pillColor = isLive
        ? const Color(0xFF10B981)
        : (period == 'ramadan' || period == 'sports_week'
            ? const Color(0xFF10B981)
            : (period == 'midterms' || period == 'finals'
                ? const Color(0xFFF59E0B)
                : accentColor));

    // Cross-fade opacity between expanded and collapsed states
    final expandedOpacity = (1.0 - progress * 1.8).clamp(0.0, 1.0);
    final collapsedOpacity = ((progress - 0.40) * 1.8).clamp(0.0, 1.0);

    return LiquidGlassStickyCanopy(
      height: extent,
      bottomRadius: bottomRadius,
      accentColor: pillColor,
      isDark: isDark,
      imageAsset: imageAsset,
      showAtmosphere: progress < 0.20,
      frostedOpacity: (imageAsset != null && imageAsset!.isNotEmpty)
          ? (progress * 1.15).clamp(0.0, 1.0)
          : 1.0,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // ---------------------------------------------------------------
          // 1. EXPANDED UNIFIED HERO CANOPY VIEW (progress < 0.5)
          // ---------------------------------------------------------------
          if (expandedOpacity > 0.01)
            Positioned(
              top: topPadding + 6,
              left: 18,
              right: 18,
              bottom: 12,
              child: Opacity(
                opacity: expandedOpacity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Top Row: Avatar Monogram + Greeting/Name + Action Bell & Theme Toggle
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // Frosted Monogram Avatar Button with Menu
                        IrisGlassMenu(
                          autoAdjustToScreen: true,
                          menuPadding: const EdgeInsets.all(14),
                          menuWidth: 220,
                          menuBorderRadius: 24.0,
                          itemBorderRadius: 18.0,
                          settings: IrisGlass.widgetsSettings(
                            context,
                            blur: 16.0,
                            ambientStrength: 0.7,
                            lightAngle: 0.15 * math.pi,
                            thickness: 18.0,
                          ),
                          triggerBuilder: (menuCtx, toggleMenu) {
                            return ExpressiveInteractivePress(
                              onTap: toggleMenu,
                              pressedScale: 0.92,
                              child: Container(
                                width: 44,
                                height: 44,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                  border: Border.all(
                                    color: Colors.white.withValues(alpha: 0.95),
                                    width: 1.5,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.16),
                                      blurRadius: 10,
                                      offset: const Offset(0, 3),
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: Text(
                                    _getInitials(displayName),
                                    style: const TextStyle(
                                      color: Color(0xFF1E293B),
                                      fontWeight: FontWeight.w900,
                                      fontSize: 16,
                                      letterSpacing: 0.4,
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                          items: [
                            lgw.GlassMenuItem(
                              title: 'Student Mode',
                              titleStyle: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 13.5,
                                color: cs.primary,
                              ),
                              isSelected: true,
                              icon: const Icon(Icons.school_rounded, size: 18),
                              onTap: () {},
                            ),
                            lgw.GlassMenuItem(
                              title: 'Faculty Mode',
                              titleStyle: TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 13.5,
                                color: isDark ? Colors.white70 : Colors.black87,
                              ),
                              isSelected: false,
                              icon: const Icon(Icons.badge_rounded, size: 18),
                              onTap: () {
                                onRoleChanged?.call('faculty');
                              },
                            ),
                            const lgw.GlassMenuDivider(),
                            lgw.GlassMenuItem(
                              title: 'Change Batch',
                              titleStyle: TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 13.5,
                                color: isDark ? Colors.white70 : Colors.black87,
                              ),
                              icon: const Icon(Icons.layers_rounded, size: 18),
                              onTap: () => onBatchTap?.call(),
                            ),
                            const lgw.GlassMenuDivider(),
                            lgw.GlassMenuItem(
                              title: isM3 ? 'Switch to Fluid Glass' : 'Switch to Material You',
                              titleStyle: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 13.5,
                                color: VitalTokens.purple,
                              ),
                              icon: Icon(
                                isM3 ? Icons.water_drop_rounded : Icons.auto_awesome_rounded,
                                size: 18,
                                color: VitalTokens.purple,
                              ),
                              onTap: () {
                                final next = isM3 ? IrisThemeStyle.fluidGlass : IrisThemeStyle.materialYou;
                                ThemeSignals.switchThemeWithMorph(context, style: next);
                              },
                            ),
                          ],
                        ),
                        const SizedBox(width: 12),

                        // Greeting and Display Name
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                greetingText,
                                style: const TextStyle(
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.white,
                                  letterSpacing: 0.8,
                                  shadows: [
                                    Shadow(
                                      color: Colors.black87,
                                      blurRadius: 6,
                                      offset: Offset(0, 1),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 1),
                              Text(
                                displayName,
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: -0.4,
                                  color: Colors.white,
                                  shadows: [
                                    Shadow(
                                      color: Colors.black87,
                                      blurRadius: 8,
                                      offset: Offset(0, 1.5),
                                    ),
                                  ],
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),

                        // Quick Actions: Notifications & Theme Toggle
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            ExpressiveInteractivePress(
                              onTap: onAnnouncementsTap,
                              pressedScale: 0.90,
                              child: Stack(
                                clipBehavior: Clip.none,
                                children: [
                                  Container(
                                    width: 38,
                                    height: 38,
                                    decoration: BoxDecoration(
                                      color: Colors.white.withValues(alpha: 0.18),
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: Colors.white.withValues(alpha: 0.35),
                                        width: 1.2,
                                      ),
                                    ),
                                    child: const Center(
                                      child: Icon(
                                        Icons.notifications_none_rounded,
                                        size: 18,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                  ValueListenableBuilder<List<Map<String, dynamic>>>(
                                    valueListenable: RemoteConfigService.liveNotices,
                                    builder: (context, notices, _) {
                                      if (notices.isEmpty) return const SizedBox.shrink();
                                      return Positioned(
                                        top: 1,
                                        right: 1,
                                        child: Container(
                                          width: 8,
                                          height: 8,
                                          decoration: BoxDecoration(
                                            color: const Color(0xFFEF4444),
                                            shape: BoxShape.circle,
                                            border: Border.all(color: Colors.white, width: 1.5),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),
                            ExpressiveInteractivePress(
                              onTap: onToggleTheme,
                              pressedScale: 0.90,
                              child: Container(
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(
                                  color: Colors.white.withValues(alpha: 0.18),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Colors.white.withValues(alpha: 0.35),
                                    width: 1.2,
                                  ),
                                ),
                                child: Center(
                                  child: Icon(
                                    isDark ? Icons.light_mode_rounded : Icons.dark_mode_rounded,
                                    size: 17,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),

                    // Sub Row: Batch Pill + Mode status pill
                    Padding(
                      padding: const EdgeInsets.only(left: 56.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Active Batch Pill
                          ExpressiveInteractivePress(
                            onTap: onBatchTap,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.92),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: Colors.white, width: 1.2),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withValues(alpha: 0.10),
                                    blurRadius: 6,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Text(
                                batch,
                                style: const TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w800,
                                  color: Color(0xFF0F172A),
                                  letterSpacing: 0.3,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),

                          // Live Status Pill
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: const Color(0xFF064E3B).withValues(alpha: 0.90),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: pillColor.withValues(alpha: 0.90),
                                width: 1.2,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: pillColor.withValues(alpha: 0.35),
                                  blurRadius: 8,
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  width: 6.5,
                                  height: 6.5,
                                  decoration: BoxDecoration(
                                    color: pillColor,
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(
                                        color: pillColor,
                                        blurRadius: 4,
                                        spreadRadius: 1,
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  modeLabel,
                                  style: TextStyle(
                                    fontSize: 10.5,
                                    fontWeight: FontWeight.w900,
                                    color: pillColor,
                                    letterSpacing: 0.4,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Integrated Next Up / Live Class Hero Glass Card
                    _buildIntegratedInsightCard(context, isDark, pillColor),
                  ],
                ),
              ),
            ),

          // ---------------------------------------------------------------
          // 2. COLLAPSED STICKY MINI-HEADER (progress > 0.4)
          // ---------------------------------------------------------------
          if (collapsedOpacity > 0.01)
            Positioned(
              top: topPadding,
              left: 16,
              right: 16,
              bottom: 0,
              child: Opacity(
                opacity: collapsedOpacity,
                child: Center(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      // Mini Avatar
                      Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: isDark ? const Color(0xFF1E293B) : Colors.white,
                          border: Border.all(
                            color: pillColor.withValues(alpha: 0.5),
                            width: 1.2,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            _getInitials(displayName),
                            style: TextStyle(
                              color: isDark ? Colors.white : const Color(0xFF1E293B),
                              fontWeight: FontWeight.w900,
                              fontSize: 13,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),

                      // Compact Title + Batch Pill
                      Expanded(
                        child: Row(
                          children: [
                            Flexible(
                              child: Text(
                                displayName,
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: -0.3,
                                  color: isDark ? Colors.white : const Color(0xFF0F172A),
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                              decoration: BoxDecoration(
                                color: pillColor.withValues(alpha: isDark ? 0.20 : 0.12),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: pillColor.withValues(alpha: 0.35),
                                  width: 1.0,
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Container(
                                    width: 5,
                                    height: 5,
                                    decoration: BoxDecoration(
                                      color: pillColor,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                  const SizedBox(width: 5),
                                  Text(
                                    batch,
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w800,
                                      color: pillColor,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Mini Notifications Bell
                      ExpressiveInteractivePress(
                        onTap: onAnnouncementsTap,
                        pressedScale: 0.90,
                        child: Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            color: isDark ? Colors.white12 : Colors.black.withValues(alpha: 0.05),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.notifications_none_rounded,
                            size: 16,
                            color: isDark ? Colors.white : Colors.black87,
                          ),
                        ),
                      ),
                      const SizedBox(width: 6),

                      // Mini Theme Toggle
                      ExpressiveInteractivePress(
                        onTap: onToggleTheme,
                        pressedScale: 0.90,
                        child: Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            color: isDark ? Colors.white12 : Colors.black.withValues(alpha: 0.05),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            isDark ? Icons.light_mode_rounded : Icons.dark_mode_rounded,
                            size: 15,
                            color: isDark ? Colors.white : Colors.black87,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// Pinned Sticky Collapsing Header for Tools & Utilities Screen.
class ToolsLiquidGlassStickyHeaderDelegate extends SliverPersistentHeaderDelegate {
  final double topPadding;
  final int vacantCount;
  final bool isDark;
  final VoidCallback? onBack;
  final bool canPop;

  const ToolsLiquidGlassStickyHeaderDelegate({
    required this.topPadding,
    required this.vacantCount,
    required this.isDark,
    this.onBack,
    this.canPop = false,
  });

  @override
  double get minExtent => topPadding + 56.0;

  @override
  double get maxExtent => topPadding + 104.0;

  @override
  bool shouldRebuild(covariant ToolsLiquidGlassStickyHeaderDelegate oldDelegate) {
    return oldDelegate.topPadding != topPadding ||
        oldDelegate.vacantCount != vacantCount ||
        oldDelegate.isDark != isDark ||
        oldDelegate.canPop != canPop;
  }

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    final extent = math.max(minExtent, maxExtent - shrinkOffset);
    final progress = ((shrinkOffset) / (maxExtent - minExtent)).clamp(0.0, 1.0);
    final bottomRadius = lerpDouble(24.0, 18.0, progress) ?? 20.0;
    const accentColor = Color(0xFF14B8A6);

    final expandedOpacity = (1.0 - progress * 2.2).clamp(0.0, 1.0);
    final collapsedOpacity = ((progress - 0.45) * 2.2).clamp(0.0, 1.0);

    return LiquidGlassStickyCanopy(
      height: extent,
      bottomRadius: bottomRadius,
      accentColor: accentColor,
      isDark: isDark,
      imageAsset: 'assets/headers/header_academics_hub.jpg',
      frostedOpacity: (progress * 1.2).clamp(0.0, 1.0),
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Expanded View
          if (expandedOpacity > 0.01)
            Positioned(
              top: topPadding + 8,
              left: 20,
              right: 20,
              bottom: 10,
              child: Opacity(
                opacity: expandedOpacity,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    if (canPop) ...[
                      ExpressiveInteractivePress(
                        onTap: onBack,
                        pressedScale: 0.92,
                        child: Container(
                          padding: const EdgeInsets.all(9),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.20),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.4),
                              width: 1.0,
                            ),
                          ),
                          child: const Icon(
                            Icons.arrow_back_ios_new_rounded,
                            size: 15,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                    ],
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Text(
                            'Tools & Utilities',
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              letterSpacing: -0.6,
                              color: Colors.white,
                              shadows: [
                                Shadow(
                                  color: Colors.black87,
                                  blurRadius: 8,
                                  offset: Offset(0, 1),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'Campus spaces, calculators & academic tools',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: Colors.white70,
                              shadows: [
                                Shadow(
                                  color: Colors.black87,
                                  blurRadius: 4,
                                  offset: Offset(0, 1),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: accentColor.withValues(alpha: 0.25),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: accentColor.withValues(alpha: 0.6),
                          width: 1.0,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 6,
                            height: 6,
                            decoration: const BoxDecoration(
                              color: Color(0xFF34D399),
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            '$vacantCount Vacant',
                            style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

          // Collapsed Sticky Mini View
          if (collapsedOpacity > 0.01)
            Positioned(
              top: topPadding,
              left: 18,
              right: 18,
              bottom: 0,
              child: Opacity(
                opacity: collapsedOpacity,
                child: Center(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      if (canPop) ...[
                        ExpressiveInteractivePress(
                          onTap: onBack,
                          pressedScale: 0.92,
                          child: Container(
                            padding: const EdgeInsets.all(7),
                            decoration: BoxDecoration(
                              color: isDark ? Colors.white12 : Colors.black.withValues(alpha: 0.05),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              Icons.arrow_back_ios_new_rounded,
                              size: 14,
                              color: isDark ? Colors.white : Colors.black87,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                      ],
                      Expanded(
                        child: Text(
                          'Tools & Utilities',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                            letterSpacing: -0.3,
                            color: isDark ? Colors.white : const Color(0xFF0F172A),
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: accentColor.withValues(alpha: isDark ? 0.25 : 0.15),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: accentColor.withValues(alpha: 0.4),
                            width: 1.0,
                          ),
                        ),
                        child: Text(
                          '$vacantCount Vacant',
                          style: const TextStyle(
                            fontSize: 10.5,
                            fontWeight: FontWeight.w800,
                            color: accentColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// Pinned Sticky Collapsing Header for Iris Hub & Settings Screen.
class IrisHubLiquidGlassStickyHeaderDelegate extends SliverPersistentHeaderDelegate {
  final double topPadding;
  final String userRole;
  final bool isDark;
  final VoidCallback? onBack;
  final bool canPop;

  const IrisHubLiquidGlassStickyHeaderDelegate({
    required this.topPadding,
    required this.userRole,
    required this.isDark,
    this.onBack,
    this.canPop = false,
  });

  @override
  double get minExtent => topPadding + 56.0;

  @override
  double get maxExtent => topPadding + 104.0;

  @override
  bool shouldRebuild(covariant IrisHubLiquidGlassStickyHeaderDelegate oldDelegate) {
    return oldDelegate.topPadding != topPadding ||
        oldDelegate.userRole != userRole ||
        oldDelegate.isDark != isDark ||
        oldDelegate.canPop != canPop;
  }

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    final extent = math.max(minExtent, maxExtent - shrinkOffset);
    final progress = ((shrinkOffset) / (maxExtent - minExtent)).clamp(0.0, 1.0);
    final bottomRadius = lerpDouble(24.0, 18.0, progress) ?? 20.0;
    final accentColor = VitalTokens.purple;

    final expandedOpacity = (1.0 - progress * 2.2).clamp(0.0, 1.0);
    final collapsedOpacity = ((progress - 0.45) * 2.2).clamp(0.0, 1.0);

    return LiquidGlassStickyCanopy(
      height: extent,
      bottomRadius: bottomRadius,
      accentColor: accentColor,
      isDark: isDark,
      imageAsset: 'assets/headers/header_iris_hub.jpg',
      frostedOpacity: (progress * 1.2).clamp(0.0, 1.0),
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Expanded View
          if (expandedOpacity > 0.01)
            Positioned(
              top: topPadding + 8,
              left: 20,
              right: 20,
              bottom: 10,
              child: Opacity(
                opacity: expandedOpacity,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    if (canPop) ...[
                      ExpressiveInteractivePress(
                        onTap: onBack,
                        pressedScale: 0.92,
                        child: Container(
                          padding: const EdgeInsets.all(9),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.20),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.4),
                              width: 1.0,
                            ),
                          ),
                          child: const Icon(
                            Icons.arrow_back_ios_new_rounded,
                            size: 15,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                    ],
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Text(
                            'Iris Hub & Settings',
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              letterSpacing: -0.6,
                              color: Colors.white,
                              shadows: [
                                Shadow(
                                  color: Colors.black87,
                                  blurRadius: 8,
                                  offset: Offset(0, 1),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'Preferences, visual style, sync & profile',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: Colors.white70,
                              shadows: [
                                Shadow(
                                  color: Colors.black87,
                                  blurRadius: 4,
                                  offset: Offset(0, 1),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: accentColor.withValues(alpha: 0.30),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: accentColor.withValues(alpha: 0.6),
                          width: 1.0,
                        ),
                      ),
                      child: Text(
                        userRole.toUpperCase(),
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

          // Collapsed Sticky Mini View
          if (collapsedOpacity > 0.01)
            Positioned(
              top: topPadding,
              left: 18,
              right: 18,
              bottom: 0,
              child: Opacity(
                opacity: collapsedOpacity,
                child: Center(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      if (canPop) ...[
                        ExpressiveInteractivePress(
                          onTap: onBack,
                          pressedScale: 0.92,
                          child: Container(
                            padding: const EdgeInsets.all(7),
                            decoration: BoxDecoration(
                              color: isDark ? Colors.white12 : Colors.black.withValues(alpha: 0.05),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              Icons.arrow_back_ios_new_rounded,
                              size: 14,
                              color: isDark ? Colors.white : Colors.black87,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                      ],
                      Expanded(
                        child: Text(
                          'Iris Hub',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                            letterSpacing: -0.3,
                            color: isDark ? Colors.white : const Color(0xFF0F172A),
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: accentColor.withValues(alpha: isDark ? 0.25 : 0.15),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: accentColor.withValues(alpha: 0.4),
                            width: 1.0,
                          ),
                        ),
                        child: Text(
                          userRole.toUpperCase(),
                          style: TextStyle(
                            fontSize: 10.5,
                            fontWeight: FontWeight.w800,
                            color: accentColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ============================================================================
// FACULTY SCHEDULE LIQUID GLASS STICKY HEADER DELEGATE
// ============================================================================

/// Grand Pinned Sticky Collapsing Canopy for Faculty Schedule Dashboard.
///
/// Features:
/// 1. Flush top canopy stretching behind status bar to y = 0.
/// 2. High-res comic campus artwork ('assets/headers/header_faculty_hub.jpg').
/// 3. Monogram avatar with IrisGlassMenu actions (Switch teacher, Role switch, Refresh).
/// 4. Integrated hero Live/Next lecture card with room, time, batch, and progress bar.
/// 5. Smooth 120 FPS collapse curve from 276dp to 62dp sticky mini-header.
class FacultyLiquidGlassStickyHeaderDelegate extends SliverPersistentHeaderDelegate {
  final double topPadding;
  final String teacherName;
  final FacultyProfile? profile;
  final List<ClassSession> schedule;
  final DateTime now;
  final String dateLabel;
  final TemporalInsight insight;
  final NextLectureInfo? nextLectureInfo;
  final String period;
  final bool isDark;
  final OmniBrain brain;
  final VoidCallback onOpenTeacherPicker;
  final VoidCallback? onToggleTheme;
  final Future<void> Function() onRefresh;
  final ValueChanged<String>? onRoleChanged;
  final ValueChanged<String>? onBatchChanged;
  final Future<void> Function(ClassSession session)? onAddMakeupClass;

  const FacultyLiquidGlassStickyHeaderDelegate({
    required this.topPadding,
    required this.teacherName,
    this.profile,
    required this.schedule,
    required this.now,
    required this.dateLabel,
    required this.insight,
    this.nextLectureInfo,
    required this.period,
    required this.isDark,
    required this.brain,
    required this.onOpenTeacherPicker,
    this.onToggleTheme,
    required this.onRefresh,
    this.onRoleChanged,
    this.onBatchChanged,
    this.onAddMakeupClass,
  });

  @override
  double get minExtent => topPadding + 62.0;

  @override
  double get maxExtent => topPadding + 276.0;

  @override
  bool shouldRebuild(covariant FacultyLiquidGlassStickyHeaderDelegate oldDelegate) {
    return oldDelegate.topPadding != topPadding ||
        oldDelegate.teacherName != teacherName ||
        oldDelegate.profile != profile ||
        oldDelegate.schedule != schedule ||
        oldDelegate.insight != insight ||
        oldDelegate.nextLectureInfo != nextLectureInfo ||
        oldDelegate.period != period ||
        oldDelegate.isDark != isDark;
  }

  String _getInitials(String name) {
    final clean = name.trim();
    if (clean.isEmpty) return 'FC';
    final parts = clean.split(RegExp(r'\s+'));
    if (parts.length >= 2) {
      final first = parts[0].isNotEmpty ? parts[0][0] : '';
      final second = parts[1].isNotEmpty ? parts[1][0] : '';
      return '$first$second'.toUpperCase();
    }
    return clean.substring(0, math.min(clean.length, 2)).toUpperCase();
  }

  String _getSmartGreeting(int hour) {
    if (hour >= 5 && hour < 12) return 'MORNING';
    if (hour >= 12 && hour < 17) return 'AFTERNOON';
    if (hour >= 17 && hour < 21) return 'EVENING';
    return 'NIGHT';
  }

  Widget _buildIntegratedFacultyLectureCard(
    BuildContext context,
    bool isDark,
    Color pillColor,
  ) {
    if (nextLectureInfo != null) {
      final session = nextLectureInfo!.session;
      final isLive = nextLectureInfo!.isLive;
      final timingLabel = nextLectureInfo!.timingLabel;

      final currentHour = now.hour + (now.minute / 60.0);
      final duration = math.max(0.2, session.safeEndVal - session.safeStartVal);
      final elapsed = (currentHour - session.safeStartVal).clamp(0.0, duration);
      final classProgress = (elapsed / duration).clamp(0.0, 1.0);

      return ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Container(
          decoration: BoxDecoration(
            color: isDark
                ? const Color(0xFF0F172A).withValues(alpha: 0.88)
                : Colors.white.withValues(alpha: 0.94),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isDark
                  ? Colors.white.withValues(alpha: 0.16)
                  : Colors.black.withValues(alpha: 0.08),
              width: 1.0,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
                blurRadius: 18,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              // Top Status Badge & Timing
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3.5),
                    decoration: BoxDecoration(
                      color: pillColor.withValues(alpha: isDark ? 0.22 : 0.14),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: pillColor.withValues(alpha: 0.40),
                        width: 1.0,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: pillColor,
                          ),
                        ),
                        const SizedBox(width: 5),
                        Text(
                          isLive ? 'ONGOING LECTURE' : 'NEXT LECTURE',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.6,
                            color: pillColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  Text(
                    timingLabel,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: isDark ? Colors.white70 : const Color(0xFF475569),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 7),

              // Subject Title
              Text(
                session.subject,
                style: TextStyle(
                  fontSize: 14.5,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.3,
                  color: isDark ? Colors.white : const Color(0xFF0F172A),
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),

              // Time, Room & Section Row
              Row(
                children: [
                  Icon(
                    Icons.access_time_rounded,
                    size: 13,
                    color: isDark ? Colors.white54 : const Color(0xFF64748B),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '${session.startTime} - ${session.endTime}',
                    style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w600,
                      color: isDark ? Colors.white70 : const Color(0xFF475569),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Icon(
                    Icons.meeting_room_rounded,
                    size: 13,
                    color: isDark ? Colors.white54 : const Color(0xFF64748B),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    'Room ${session.room}',
                    style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w600,
                      color: isDark ? Colors.white70 : const Color(0xFF475569),
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                      color: isDark
                          ? Colors.white.withValues(alpha: 0.08)
                          : Colors.black.withValues(alpha: 0.05),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      session.batchKey.batch,
                      style: TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w700,
                        color: isDark ? Colors.white70 : const Color(0xFF334155),
                      ),
                    ),
                  ),
                ],
              ),

              // Progress bar if live
              if (isLive) ...[
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(99),
                  child: Container(
                    height: 4.5,
                    decoration: BoxDecoration(
                      color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(99),
                    ),
                    child: FractionallySizedBox(
                      alignment: Alignment.centerLeft,
                      widthFactor: classProgress.clamp(0.06, 1.0),
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [pillColor, pillColor.withValues(alpha: 0.75)],
                          ),
                          borderRadius: BorderRadius.circular(99),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      );
    }

    // When no lectures remain today / Free Schedule
    final location = profile?.location.isNotEmpty == true && profile!.location != 'Not Specified'
        ? (profile!.location.toLowerCase().contains('room') || profile!.location.toLowerCase().contains('cabin')
            ? profile!.location
            : 'Cabin ${profile!.location}')
        : 'Campus Office';

    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Container(
        decoration: BoxDecoration(
          color: isDark
              ? const Color(0xFF0F172A).withValues(alpha: 0.88)
              : Colors.white.withValues(alpha: 0.94),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isDark
                ? Colors.white.withValues(alpha: 0.16)
                : Colors.black.withValues(alpha: 0.08),
            width: 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.35 : 0.08),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3.5),
                  decoration: BoxDecoration(
                    color: const Color(0xFF10B981).withValues(alpha: isDark ? 0.22 : 0.14),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: const Color(0xFF10B981).withValues(alpha: 0.40),
                      width: 1.0,
                    ),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.check_circle_rounded, size: 11, color: Color(0xFF10B981)),
                      SizedBox(width: 5),
                      Text(
                        'ALL LECTURES DONE TODAY',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.6,
                          color: Color(0xFF10B981),
                        ),
                      ),
                    ],
                  ),
                ),
                const Spacer(),
                Text(
                  location,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: isDark ? Colors.white60 : const Color(0xFF64748B),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 7),
            Text(
              'No upcoming lectures scheduled today 🎉',
              style: TextStyle(
                fontSize: 14.5,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.3,
                color: isDark ? Colors.white : const Color(0xFF0F172A),
              ),
            ),
            const SizedBox(height: 3),
            Text(
              'Ideal time for student consultations, research, or office hours.',
              style: TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w500,
                color: isDark ? Colors.white60 : const Color(0xFF64748B),
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    final extent = math.max(minExtent, maxExtent - shrinkOffset);
    final progress = ((shrinkOffset) / (maxExtent - minExtent)).clamp(0.0, 1.0);
    final bottomRadius = lerpDouble(28.0, 18.0, progress) ?? 24.0;

    final String imageAsset = (period == 'sports_week')
        ? 'assets/headers/header_sports_gala.jpg'
        : (period == 'ramadan')
            ? 'assets/headers/header_ramadan_mode.jpg'
            : (period == 'midterms')
                ? 'assets/headers/header_midterms_mode.jpg'
                : (period == 'finals')
                    ? 'assets/headers/header_finals_week.jpg'
                    : 'assets/headers/header_faculty_hub.jpg';

    final pillColor = (nextLectureInfo?.isLive == true)
        ? const Color(0xFF10B981)
        : ((period == 'sports_week' || period == 'ramadan')
            ? const Color(0xFF10B981)
            : const Color(0xFF8B5CF6));

    final expandedOpacity = (1.0 - progress * 1.8).clamp(0.0, 1.0);
    final collapsedOpacity = ((progress - 0.40) * 1.8).clamp(0.0, 1.0);

    final designation = profile?.designation.isNotEmpty == true
        ? profile!.designation
        : 'Faculty Advisor';

    final initials = _getInitials(teacherName);
    final greetingWord = _getSmartGreeting(now.hour);
    final greetingText = 'GOOD $greetingWord';

    return LiquidGlassStickyCanopy(
      height: extent,
      bottomRadius: bottomRadius,
      accentColor: pillColor,
      isDark: isDark,
      imageAsset: imageAsset,
      showAtmosphere: progress < 0.20,
      frostedOpacity: (progress * 1.15).clamp(0.0, 1.0),
      child: Stack(
        fit: StackFit.expand,
        children: [
          // -----------------------------------------------------------------
          // 1. EXPANDED UNIFIED HERO CANOPY VIEW (progress < 0.5)
          // -----------------------------------------------------------------
          if (expandedOpacity > 0.01)
            Positioned(
              top: topPadding + 6,
              left: 18,
              right: 18,
              bottom: 12,
              child: Opacity(
                opacity: expandedOpacity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Top Row: Avatar Monogram + Greeting/Name + Action Buttons
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // Monogram Avatar Button with Menu
                        IrisGlassMenu(
                          autoAdjustToScreen: true,
                          menuPadding: const EdgeInsets.all(14),
                          menuWidth: 220,
                          menuBorderRadius: 24.0,
                          itemBorderRadius: 18.0,
                          settings: IrisGlass.widgetsSettings(
                            context,
                            blur: 16.0,
                            ambientStrength: 0.7,
                            lightAngle: 0.15 * math.pi,
                            thickness: 18.0,
                          ),
                          triggerBuilder: (menuCtx, toggleMenu) {
                            return ExpressiveInteractivePress(
                              onTap: toggleMenu,
                              pressedScale: 0.92,
                              child: Container(
                                width: 44,
                                height: 44,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                  border: Border.all(
                                    color: Colors.white.withValues(alpha: 0.95),
                                    width: 1.5,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.16),
                                      blurRadius: 10,
                                      offset: const Offset(0, 3),
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: Text(
                                    initials,
                                    style: const TextStyle(
                                      color: Color(0xFF1E293B),
                                      fontWeight: FontWeight.w900,
                                      fontSize: 15,
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                          items: [
                            lgw.GlassMenuItem(
                              title: 'Switch Instructor',
                              icon: const Icon(Icons.person_search_rounded, size: 18, color: Color(0xFF8B5CF6)),
                              onTap: onOpenTeacherPicker,
                            ),
                            lgw.GlassMenuItem(
                              title: 'Switch to Student',
                              icon: const Icon(Icons.school_rounded, size: 18, color: Color(0xFF10B981)),
                              onTap: () => onRoleChanged?.call('student'),
                            ),
                            const lgw.GlassMenuDivider(),
                            lgw.GlassMenuItem(
                              title: 'Refresh Timetable',
                              icon: const Icon(Icons.refresh_rounded, size: 18, color: Color(0xFF0284C7)),
                              onTap: () {
                                IrisHaptics.actionSoft();
                                onRefresh();
                              },
                            ),
                            const lgw.GlassMenuDivider(),
                            lgw.GlassMenuItem(
                              title: ThemeSignals.isMaterialYou ? 'Switch to Liquid Glass' : 'Switch to Material You',
                              icon: Icon(
                                ThemeSignals.isMaterialYou ? Icons.water_drop_rounded : Icons.auto_awesome_rounded,
                                size: 18,
                                color: VitalTokens.purple,
                              ),
                              onTap: () {
                                final next = ThemeSignals.isMaterialYou
                                    ? IrisThemeStyle.fluidGlass
                                    : IrisThemeStyle.materialYou;
                                ThemeSignals.switchThemeWithMorph(context, style: next);
                              },
                            ),
                          ],
                        ),
                        const SizedBox(width: 12),

                        // Greeting + Teacher Name + Designation Pill
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    greetingText,
                                    style: TextStyle(
                                      fontSize: 10.5,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 1.1,
                                      color: Colors.white.withValues(alpha: 0.88),
                                      shadows: const [
                                        Shadow(
                                          color: Colors.black38,
                                          blurRadius: 6,
                                          offset: Offset(0, 1),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1.5),
                                    decoration: BoxDecoration(
                                      color: pillColor.withValues(alpha: 0.85),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      designation.toUpperCase(),
                                      style: const TextStyle(
                                        fontSize: 9,
                                        fontWeight: FontWeight.w900,
                                        color: Colors.white,
                                        letterSpacing: 0.4,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 2),
                              Text(
                                teacherName,
                                style: const TextStyle(
                                  fontSize: 17,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: -0.4,
                                  color: Colors.white,
                                  shadows: [
                                    Shadow(
                                      color: Colors.black45,
                                      blurRadius: 8,
                                      offset: Offset(0, 2),
                                    ),
                                  ],
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),

                        // Change Instructor Action Button
                        ExpressiveInteractivePress(
                          onTap: onOpenTeacherPicker,
                          pressedScale: 0.92,
                          child: Container(
                            padding: const EdgeInsets.all(9),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.20),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Colors.white.withValues(alpha: 0.40),
                                width: 1.0,
                              ),
                            ),
                            child: const Icon(
                              Icons.swap_horiz_rounded,
                              size: 16,
                              color: Colors.white,
                            ),
                          ),
                        ),
                        if (onToggleTheme != null) ...[
                          const SizedBox(width: 8),
                          ExpressiveInteractivePress(
                            onTap: onToggleTheme,
                            pressedScale: 0.92,
                            child: Container(
                              padding: const EdgeInsets.all(9),
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.20),
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Colors.white.withValues(alpha: 0.40),
                                  width: 1.0,
                                ),
                              ),
                              child: Icon(
                                isDark ? Icons.light_mode_rounded : Icons.dark_mode_rounded,
                                size: 16,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),

                    // Integrated Live/Next Lecture Hero Card
                    _buildIntegratedFacultyLectureCard(context, isDark, pillColor),
                  ],
                ),
              ),
            ),

          // -----------------------------------------------------------------
          // 2. COLLAPSED COMPACT STICKY GLASS BAR VIEW (progress > 0.4)
          // -----------------------------------------------------------------
          if (collapsedOpacity > 0.01)
            Positioned(
              top: topPadding,
              left: 18,
              right: 18,
              bottom: 0,
              child: Opacity(
                opacity: collapsedOpacity,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Monogram Mini Avatar
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: pillColor,
                        boxShadow: [
                          BoxShadow(
                            color: pillColor.withValues(alpha: 0.40),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Center(
                        child: Text(
                          initials,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),

                    // Teacher Name
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            teacherName,
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w800,
                              letterSpacing: -0.3,
                              color: isDark ? Colors.white : const Color(0xFF0F172A),
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(
                            dateLabel,
                            style: TextStyle(
                              fontSize: 10.5,
                              fontWeight: FontWeight.w600,
                              color: isDark ? Colors.white60 : const Color(0xFF64748B),
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Live Status Pill
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                      decoration: BoxDecoration(
                        color: pillColor.withValues(alpha: isDark ? 0.25 : 0.15),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: pillColor.withValues(alpha: 0.45),
                          width: 1.0,
                        ),
                      ),
                      child: Text(
                        nextLectureInfo?.isLive == true ? 'LIVE NOW' : 'FACULTY',
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                          color: pillColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ============================================================================
// FACULTY TOOLS LIQUID GLASS STICKY HEADER DELEGATE
// ============================================================================

/// Pinned Sticky Collapsing Canopy for Faculty Academic Tools Suite.
class FacultyToolsLiquidGlassStickyHeaderDelegate extends SliverPersistentHeaderDelegate {
  final double topPadding;
  final String teacherName;
  final bool isDark;
  final VoidCallback? onBack;
  final bool canPop;

  const FacultyToolsLiquidGlassStickyHeaderDelegate({
    required this.topPadding,
    required this.teacherName,
    required this.isDark,
    this.onBack,
    this.canPop = false,
  });

  @override
  double get minExtent => topPadding + 56.0;

  @override
  double get maxExtent => topPadding + 104.0;

  @override
  bool shouldRebuild(covariant FacultyToolsLiquidGlassStickyHeaderDelegate oldDelegate) {
    return oldDelegate.topPadding != topPadding ||
        oldDelegate.teacherName != teacherName ||
        oldDelegate.isDark != isDark ||
        oldDelegate.canPop != canPop;
  }

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    final extent = math.max(minExtent, maxExtent - shrinkOffset);
    final progress = ((shrinkOffset) / (maxExtent - minExtent)).clamp(0.0, 1.0);
    final bottomRadius = lerpDouble(24.0, 18.0, progress) ?? 20.0;
    const accentColor = Color(0xFF8B5CF6);

    final expandedOpacity = (1.0 - progress * 2.2).clamp(0.0, 1.0);
    final collapsedOpacity = ((progress - 0.45) * 2.2).clamp(0.0, 1.0);

    return LiquidGlassStickyCanopy(
      height: extent,
      bottomRadius: bottomRadius,
      accentColor: accentColor,
      isDark: isDark,
      imageAsset: 'assets/headers/header_faculty_hub.jpg',
      frostedOpacity: (progress * 1.2).clamp(0.0, 1.0),
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Expanded View
          if (expandedOpacity > 0.01)
            Positioned(
              top: topPadding + 8,
              left: 20,
              right: 20,
              bottom: 10,
              child: Opacity(
                opacity: expandedOpacity,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    if (canPop) ...[
                      ExpressiveInteractivePress(
                        onTap: onBack,
                        pressedScale: 0.92,
                        child: Container(
                          padding: const EdgeInsets.all(9),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.20),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.4),
                              width: 1.0,
                            ),
                          ),
                          child: const Icon(
                            Icons.arrow_back_ios_new_rounded,
                            size: 15,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                    ],
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Text(
                            'Faculty Tools',
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              letterSpacing: -0.6,
                              color: Colors.white,
                              shadows: [
                                Shadow(
                                  color: Colors.black45,
                                  blurRadius: 8,
                                  offset: Offset(0, 2),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'Classroom workflows, room intelligence & scheduling',
                            style: TextStyle(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w600,
                              color: Colors.white70,
                              shadows: [
                                Shadow(
                                  color: Colors.black38,
                                  blurRadius: 4,
                                  offset: Offset(0, 1),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: accentColor.withValues(alpha: 0.28),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(
                          color: accentColor.withValues(alpha: 0.50),
                          width: 1.0,
                        ),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.auto_awesome_rounded, size: 12, color: Colors.white),
                          SizedBox(width: 5),
                          Text(
                            'Academic Suite',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

          // Collapsed View
          if (collapsedOpacity > 0.01)
            Positioned(
              top: topPadding,
              left: 20,
              right: 20,
              bottom: 0,
              child: Opacity(
                opacity: collapsedOpacity,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    if (canPop) ...[
                      ExpressiveInteractivePress(
                        onTap: onBack,
                        pressedScale: 0.92,
                        child: Icon(
                          Icons.arrow_back_ios_new_rounded,
                          size: 18,
                          color: isDark ? Colors.white : const Color(0xFF0F172A),
                        ),
                      ),
                      const SizedBox(width: 10),
                    ],
                    Expanded(
                      child: Text(
                        'Faculty Tools',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -0.3,
                          color: isDark ? Colors.white : const Color(0xFF0F172A),
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3.5),
                      decoration: BoxDecoration(
                        color: accentColor.withValues(alpha: isDark ? 0.25 : 0.15),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: accentColor.withValues(alpha: 0.4),
                          width: 1.0,
                        ),
                      ),
                      child: const Text(
                        'ACADEMIC SUITE',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          color: accentColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ============================================================================
// ACADEMICS / DEPARTMENT CLASSES LIQUID GLASS STICKY HEADER DELEGATE
// ============================================================================

/// Pinned Sticky Collapsing Canopy for Academics Mode & Department Classes Screen.
class AcademicsLiquidGlassStickyHeaderDelegate extends SliverPersistentHeaderDelegate {
  final double topPadding;
  final bool isDark;
  final String period;
  final bool canPop;
  final VoidCallback? onBack;
  final VoidCallback? onJumpToMyBatch;
  final VoidCallback? onShare;
  final bool hasBatch;
  final bool isFaculty;
  final String? batchText;

  const AcademicsLiquidGlassStickyHeaderDelegate({
    required this.topPadding,
    required this.isDark,
    required this.period,
    this.canPop = false,
    this.onBack,
    this.onJumpToMyBatch,
    this.onShare,
    this.hasBatch = false,
    this.isFaculty = false,
    this.batchText,
  });

  @override
  double get minExtent => topPadding + 58.0;

  @override
  double get maxExtent => topPadding + 116.0;

  @override
  bool shouldRebuild(covariant AcademicsLiquidGlassStickyHeaderDelegate oldDelegate) {
    return oldDelegate.topPadding != topPadding ||
        oldDelegate.isDark != isDark ||
        oldDelegate.period != period ||
        oldDelegate.canPop != canPop ||
        oldDelegate.hasBatch != hasBatch ||
        oldDelegate.isFaculty != isFaculty ||
        oldDelegate.batchText != batchText;
  }

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    final extent = math.max(minExtent, maxExtent - shrinkOffset);
    final progress = ((shrinkOffset) / (maxExtent - minExtent)).clamp(0.0, 1.0);
    final bottomRadius = lerpDouble(24.0, 18.0, progress) ?? 20.0;
    const accentColor = Color(0xFF0284C7);

    final expandedOpacity = (1.0 - progress * 2.2).clamp(0.0, 1.0);
    final collapsedOpacity = ((progress - 0.45) * 2.2).clamp(0.0, 1.0);

    String subText = 'Browse classes for any program or semester.';
    if (period == 'ramadan') {
      subText = '🌙 RAMADAN ACTIVE: Compressed timings in effect.';
    } else if (period == 'midterms') {
      subText = '📝 MIDTERMS ACTIVE: Showing exam paper datesheets.';
    } else if (period == 'finals') {
      subText = '🎓 FINALS ACTIVE: Showing final datesheets & halls.';
    } else if (period == 'sports_week') {
      subText = '🏆 SPORTS GALA ACTIVE: Campus athletic fixtures live.';
    }

    return LiquidGlassStickyCanopy(
      height: extent,
      bottomRadius: bottomRadius,
      accentColor: accentColor,
      isDark: isDark,
      imageAsset: 'assets/headers/header_academics_hub.jpg',
      frostedOpacity: (progress * 1.2).clamp(0.0, 1.0),
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Expanded View
          if (expandedOpacity > 0.01)
            Positioned(
              top: topPadding + 8,
              left: 20,
              right: 20,
              bottom: 10,
              child: Opacity(
                opacity: expandedOpacity,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    if (canPop) ...[
                      ExpressiveInteractivePress(
                        onTap: onBack,
                        pressedScale: 0.92,
                        child: Container(
                          padding: const EdgeInsets.all(9),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.20),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.4),
                              width: 1.0,
                            ),
                          ),
                          child: const Icon(
                            Icons.arrow_back_ios_new_rounded,
                            size: 15,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                    ],
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            children: [
                              const Expanded(
                                child: Text(
                                  'Department Classes',
                                  style: TextStyle(
                                    fontSize: 21,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: -0.6,
                                    color: Colors.white,
                                    shadows: [
                                      Shadow(
                                        color: Colors.black45,
                                        blurRadius: 8,
                                        offset: Offset(0, 2),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              if (hasBatch && onJumpToMyBatch != null) ...[
                                IrisLiquidButton(
                                  text: isFaculty ? (batchText ?? 'Batches') : 'My Batch',
                                  icon: Icons.bolt_rounded,
                                  onTap: onJumpToMyBatch,
                                  height: 28,
                                  fontSize: 10.5,
                                  iconSize: 13,
                                  padding: const EdgeInsets.symmetric(horizontal: 8),
                                  color: Colors.white,
                                  isDark: isDark,
                                  borderSide: BorderSide(
                                    color: Colors.white.withValues(alpha: 0.4),
                                    width: 1.0,
                                  ),
                                ),
                                const SizedBox(width: 8),
                              ],
                              if (onShare != null)
                                IrisLiquidButton(
                                  text: 'Share',
                                  icon: Icons.share_rounded,
                                  onTap: onShare,
                                  height: 28,
                                  fontSize: 10.5,
                                  iconSize: 13,
                                  padding: const EdgeInsets.symmetric(horizontal: 10),
                                  color: Colors.white,
                                  isDark: isDark,
                                  borderSide: BorderSide(
                                    color: Colors.white.withValues(alpha: 0.4),
                                    width: 1.0,
                                  ),
                                ),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(
                            subText,
                            style: const TextStyle(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w600,
                              color: Colors.white70,
                              shadows: [
                                Shadow(
                                  color: Colors.black38,
                                  blurRadius: 4,
                                  offset: Offset(0, 1),
                                ),
                              ],
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

          // Collapsed View
          if (collapsedOpacity > 0.01)
            Positioned(
              top: topPadding,
              left: 20,
              right: 20,
              bottom: 0,
              child: Opacity(
                opacity: collapsedOpacity,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    if (canPop) ...[
                      ExpressiveInteractivePress(
                        onTap: onBack,
                        pressedScale: 0.92,
                        child: Icon(
                          Icons.arrow_back_ios_new_rounded,
                          size: 18,
                          color: isDark ? Colors.white : const Color(0xFF0F172A),
                        ),
                      ),
                      const SizedBox(width: 10),
                    ],
                    Expanded(
                      child: Text(
                        'Department Classes',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -0.3,
                          color: isDark ? Colors.white : const Color(0xFF0F172A),
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3.5),
                      decoration: BoxDecoration(
                        color: accentColor.withValues(alpha: isDark ? 0.25 : 0.15),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: accentColor.withValues(alpha: 0.4),
                          width: 1.0,
                        ),
                      ),
                      child: const Text(
                        'ACADEMICS HUB',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          color: accentColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
