import 'sports_gala_view.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iris/core/models.dart';
import 'package:iris/core/omni_brain.dart';
import 'package:iris/core/poster_theme_tokens.dart';
import 'package:iris/services/remote_config_service.dart';
import 'package:iris/services/ui_feedback.dart';
import 'package:iris/widgets/iris_components.dart';
import 'package:iris/widgets/effects/glass_container_transform.dart';
import 'package:iris/screens/settings/announcements_screen.dart';

/// Authentic Swiss Brutalism & International Typographic Schedule View
/// (Modeled with 100% pixel fidelity after Poster · Light.png & Poster · Dark.png).
/// Features monolithic grotesque numbers, high-impact International Orange hero block,
/// stark 3D extruded drop-block shadows, and heavyweight architectural rules.
class PosterScheduleView extends StatelessWidget {
  final OmniBrain brain;
  final String batch;
  final int activeDayIndex; // 1=Mon ... 7=Sun
  final ValueChanged<int> onDaySelected;
  final Future<void> Function() onRefresh;
  final VoidCallback onOpenBatchSelector;
  final ScrollController? scrollController;
  final List<String> pendingChanges;
  final VoidCallback? onDismissChanges;
  final String? userName;
  final bool isFaculty;
  final String? teacherName;

  static const List<String> _months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];
  static const List<String> _weekdays = [
    'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'
  ];

  const PosterScheduleView({
    super.key,
    required this.brain,
    required this.batch,
    required this.activeDayIndex,
    required this.onDaySelected,
    required this.onRefresh,
    required this.onOpenBatchSelector,
    this.scrollController,
    this.pendingChanges = const [],
    this.onDismissChanges,
    this.userName,
    this.isFaculty = false,
    this.teacherName,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final topPadding = MediaQuery.paddingOf(context).top;
    final now = DateTime.now();
    final todayWeekday = now.weekday; // 1=Mon ... 7=Sun
    final isViewingToday = activeDayIndex == todayWeekday;

    final currentClass = isViewingToday
        ? (isFaculty && teacherName != null
            ? brain.getCurrentClassForTeacher(teacherName!, now)
            : brain.getCurrentClass(batch, now))
        : null;
    final nextClass = isViewingToday
        ? (isFaculty && teacherName != null
            ? brain.getNextClassForTeacher(teacherName!, now)
            : brain.getNextClass(batch, now))
        : null;
    final rawSessions = isFaculty && teacherName != null
        ? brain.getMergedDayScheduleForTeacher(teacherName!, activeDayIndex)
        : brain.getMergedDaySchedule(batch, activeDayIndex);
    final sortedSessions = List<ClassSession>.from(rawSessions)
      ..sort((a, b) => a.safeStartVal.compareTo(b.safeStartVal));

    final isLive = currentClass != null;
    final targetClass = currentClass ?? nextClass ?? (sortedSessions.isNotEmpty ? sortedSessions.first : null);
    final borderColor = PosterTokens.inkBorder(isDark);

    return Container(
      color: PosterTokens.canvas(isDark),
      child: IrisRefreshIndicator(
        onRefresh: onRefresh,
        color: PosterTokens.orangeHero,
        backgroundColor: isDark ? Colors.black : Colors.white,
        child: CustomScrollView(
          controller: scrollController,
          physics: const AlwaysScrollableScrollPhysics(
            parent: BouncingScrollPhysics(),
          ),
          slivers: [
            // 1. Top Swiss Monospace Tag Bar
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(20, topPadding + 14, 20, 10),
                child: _buildTopTagBar(context, isDark, now),
              ),
            ),

            // 2. High-Impact International Orange Monolithic Hero Block
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
                child: _buildOrangeHeroBlock(
                  context,
                  isDark: isDark,
                  targetClass: targetClass,
                  isLive: isLive,
                  isViewingToday: isViewingToday,
                  activeDayIndex: activeDayIndex,
                  totalSessions: sortedSessions.length,
                  now: now,
                ),
              ),
            ),

            // 3. Tabular 7-Day Swiss Calendar Box
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                child: _buildTabularCalendarBox(context, isDark, now, borderColor),
              ),
            ),

            // 3B. Sports Week Brutalist Notice Block
            ValueListenableBuilder<String>(
              valueListenable: RemoteConfigService.activeAcademicPeriod,
              builder: (context, activePeriod, _) {
                if (activePeriod == 'sports_week') {
                  return SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 20),
                      child: StudentsWeekInfoCard(isFaculty: isFaculty),
                    ),
                  );
                }
                return const SliverToBoxAdapter(child: SizedBox.shrink());
              },
            ),

            // 4. Monolithic Class Rows (01, 02, 03)
            if (sortedSessions.isEmpty) ...[
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
                  child: _buildEmptyStateBlock(isDark, borderColor),
                ),
              ),
            ] else ...[
              SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final session = sortedSessions[index];
                    final isSessionLive = isLive && currentClass.id == session.id;
                    final formattedIndex = (index + 1).toString().padLeft(2, '0');

                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: _buildClassRow(
                        context,
                        isDark: isDark,
                        indexStr: formattedIndex,
                        session: session,
                        isLive: isSessionLive,
                        borderColor: borderColor,
                        isLast: index == sortedSessions.length - 1,
                      ),
                    );
                  },
                  childCount: sortedSessions.length,
                ),
              ),
            ],

            // 5. Monospace Sync Footer
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 24, 20, 120),
                child: ValueListenableBuilder<DateTime?>(
                  valueListenable: RemoteConfigService.lastTimetableUpdateTime,
                  builder: (context, lastSync, _) {
                    final syncTime = lastSync ?? RemoteConfigService.lastConfigUpdateTime.value ?? DateTime.now();
                    final h12 = syncTime.hour % 12 == 0 ? 12 : syncTime.hour % 12;
                    final ampm = syncTime.hour >= 12 ? 'PM' : 'AM';
                    final mPad = syncTime.minute.toString().padLeft(2, '0');
                    final monthStr = _months[syncTime.month - 1].toUpperCase();
                    return Text(
                      'SYNCED $monthStr ${syncTime.day} · $h12:$mPad $ampm',
                      style: GoogleFonts.spaceMono(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.0,
                        color: PosterTokens.inkHeading(isDark),
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 1. Top Swiss Monospace Tag Bar
  // ---------------------------------------------------------------------------
  Widget _buildTopTagBar(BuildContext context, bool isDark, DateTime now) {
    final activeDate = _getDateForSelectedDay(now);
    final dayStr = _weekdays[activeDate.weekday - 1].toUpperCase();
    final dNum = activeDate.day.toString().padLeft(2, '0');
    final mNum = activeDate.month.toString().padLeft(2, '0');
    final dateStr = '$dayStr $dNum.$mNum';
    final allBatches = brain.memory.allBatches;
    final batchCode = isFaculty
        ? (teacherName?.trim().isNotEmpty == true ? teacherName!.trim() : 'FACULTY')
        : (batch.trim().isNotEmpty
            ? batch.trim()
            : (allBatches.isNotEmpty ? allBatches.first : 'COMSATS'));

    return Wrap(
      alignment: WrapAlignment.spaceBetween,
      crossAxisAlignment: WrapCrossAlignment.center,
      spacing: 8,
      runSpacing: 6,
      children: [
        GestureDetector(
          onTap: () {
            IrisHaptics.actionSoft();
            onOpenBatchSelector();
          },
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'IRIS / $batchCode',
                style: GoogleFonts.spaceMono(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.2,
                  color: PosterTokens.inkHeading(isDark),
                ),
              ),
              const SizedBox(width: 4),
              Icon(
                Icons.arrow_drop_down_rounded,
                size: 16,
                color: PosterTokens.inkHeading(isDark),
              ),
            ],
          ),
        ),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            GestureDetector(
              onTap: () {
                IrisHaptics.actionMedium();
                pushGlassContainerMorphRoute(
                  context,
                  page: const AnnouncementsScreen(),
                  accentColor: PosterTokens.orangeHero,
                );
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF1C222B) : const Color(0xFFD6D2C4),
                  border: Border.all(
                    color: PosterTokens.inkBorder(isDark),
                    width: 1.2,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.campaign_rounded,
                      size: 13,
                      color: PosterTokens.orangeHero,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      'DISPATCH',
                      style: GoogleFonts.spaceMono(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.8,
                        color: PosterTokens.inkHeading(isDark),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              dateStr,
              style: GoogleFonts.spaceMono(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.2,
                color: PosterTokens.inkHeading(isDark),
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // 2. High-Impact International Orange Monolithic Hero Block
  // ---------------------------------------------------------------------------
  Widget _buildOrangeHeroBlock(
    BuildContext context, {
    required bool isDark,
    required ClassSession? targetClass,
    required bool isLive,
    required bool isViewingToday,
    required int activeDayIndex,
    required int totalSessions,
    required DateTime now,
  }) {
    final nowH24 = now.hour.toString().padLeft(2, '0');
    final nowM = now.minute.toString().padLeft(2, '0');
    final nowTimeStr = '$nowH24:$nowM';
    final countdownStr = targetClass != null
        ? _computeCountdown(targetClass, isLive: isLive, now: now)
        : '0:00';

    final dayName = _weekdays[(activeDayIndex - 1).clamp(0, 6)].toUpperCase();
    final bool isFutureDayClass = isViewingToday && targetClass != null && targetClass.dayIndex != now.weekday;
    final String tagText;
    if (isViewingToday) {
      if (isLive) {
        tagText = 'ONGOING CLASS · NOW $nowTimeStr';
      } else if (isFutureDayClass) {
        var daysAhead = (targetClass.dayIndex - now.weekday + 7) % 7;
        if (daysAhead == 0) daysAhead = 7;
        final dayLabel = daysAhead == 1 ? 'TOMORROW' : _weekdays[(targetClass.dayIndex - 1).clamp(0, 6)].toUpperCase();
        tagText = 'NEXT CLASS $dayLabel · NOW $nowTimeStr';
      } else {
        tagText = 'NEXT CLASS IN · NOW $nowTimeStr';
      }
    } else {
      tagText = '$dayName SCHEDULE · $totalSessions ${totalSessions == 1 ? "SESSION" : "SESSIONS"}';
    }

    final displayBig = isViewingToday
        ? countdownStr
        : (targetClass != null ? targetClass.startTime : 'ALL CLEAR');

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
      decoration: BoxDecoration(
        color: PosterTokens.orangeHero,
        borderRadius: BorderRadius.zero,
        boxShadow: PosterTokens.extrudedBlockShadow(
          isDark,
          offset: 5.0,
          color: isDark ? Colors.black : const Color(0xFF000000),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Subheader tag
          Text(
            tagText,
            style: GoogleFonts.spaceMono(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.2,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 10),

          // Giant Monolithic Display Clock / Start Time
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              displayBig,
              style: PosterTokens.heroMonolithicClock(isDark),
            ),
          ),
          const SizedBox(height: 14),

          // Bottom Metadata Row
          if (targetClass != null) ...[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerLeft,
                    child: Text(
                      targetClass.subject.toUpperCase(),
                      maxLines: 1,
                      softWrap: false,
                      style: PosterTokens.heroOrangeTitle(isDark),
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      isViewingToday
                          ? (isFutureDayClass
                              ? '${(targetClass.dayIndex - now.weekday + 7) % 7 == 1 ? "TOMORROW" : _weekdays[(targetClass.dayIndex - 1).clamp(0, 6)].toUpperCase()} ${targetClass.startTime}'
                              : targetClass.startTime)
                          : 'FIRST CLASS',
                      style: GoogleFonts.archivoBlack(
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        color: Colors.black,
                      ),
                    ),
                    Text(
                      targetClass.room,
                      style: GoogleFonts.archivoBlack(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        color: Colors.black,
                      ),
                    ),
                    Text(
                      (isFaculty
                              ? (targetClass.displayBatch.isNotEmpty
                                  ? targetClass.displayBatch
                                  : 'FACULTY')
                              : targetClass.teacher)
                          .toUpperCase(),
                      style: GoogleFonts.archivoBlack(
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ] else ...[
            Text(
              'FREE SCHEDULE FOR TODAY',
              style: PosterTokens.heroOrangeTitle(isDark),
            ),
          ],
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 3. Tabular 7-Day Swiss Calendar Box
  // ---------------------------------------------------------------------------
  Widget _buildTabularCalendarBox(
    BuildContext context,
    bool isDark,
    DateTime now,
    Color borderColor,
  ) {
    const daysInitials = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    final weekStart = now.subtract(Duration(days: now.weekday % 7));
    final currentSelectedStripIndex = activeDayIndex % 7;

    return Container(
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF101419) : Colors.white,
        border: Border.all(color: borderColor, width: 2.5),
        boxShadow: PosterTokens.extrudedBlockShadow(isDark, offset: 4.0),
      ),
      child: Row(
        children: List.generate(7, (index) {
          final dayDate = weekStart.add(Duration(days: index));
          final isSelected = currentSelectedStripIndex == index;
          final isLast = index == 6;

          final cellBg = isSelected
              ? (isDark ? Colors.white : Colors.black)
              : Colors.transparent;

          final textColor = isSelected
              ? (isDark ? Colors.black : Colors.white)
              : (isDark ? Colors.white : Colors.black);

          return Expanded(
            child: GestureDetector(
              onTap: () {
                IrisHaptics.selectionClick();
                final targetDay = index == 0 ? 7 : index;
                onDaySelected(targetDay);
              },
              behavior: HitTestBehavior.opaque,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: cellBg,
                  border: Border(
                    right: isLast
                        ? BorderSide.none
                        : BorderSide(color: borderColor, width: 2.0),
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      daysInitials[index],
                      style: GoogleFonts.spaceMono(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: textColor,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${dayDate.day}',
                      style: GoogleFonts.archivoBlack(
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        color: textColor,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 4. Monolithic Class Rows (01, 02, 03)
  // ---------------------------------------------------------------------------
  Widget _buildClassRow(
    BuildContext context, {
    required bool isDark,
    required String indexStr,
    required ClassSession session,
    required bool isLive,
    required Color borderColor,
    required bool isLast,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: borderColor, width: 2.2),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Monolithic Number (01, 02)
          SizedBox(
            width: 78,
            child: Text(
              indexStr,
              style: PosterTokens.classIndexNumber(isDark),
            ),
          ),

          const SizedBox(width: 8),

          // Class Info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  session.subject.toUpperCase(),
                  style: PosterTokens.classTitle(isDark),
                ),
                const SizedBox(height: 4),
                Text(
                  '${session.startTime}–${session.endTime} · ${isFaculty ? (session.displayBatch.isNotEmpty ? session.displayBatch : "Class") : session.teacher}',
                  style: GoogleFonts.spaceMono(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: PosterTokens.inkMuted(isDark),
                  ),
                ),
                if (isFaculty && session.isCombinedLecture) ...[
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: PosterTokens.orangeHero.withValues(alpha: 0.2),
                      border: Border.all(color: PosterTokens.orangeHero, width: 1.2),
                    ),
                    child: Text(
                      'COMBINED SECTION',
                      style: GoogleFonts.spaceMono(
                        fontSize: 9.5,
                        fontWeight: FontWeight.w700,
                        color: isDark ? Colors.white : Colors.black,
                        letterSpacing: 0.6,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),

          const SizedBox(width: 12),

          // Sharp 3D Extruded Room Box
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: isLive ? PosterTokens.orangeHero : (isDark ? const Color(0xFF181E27) : Colors.white),
              border: Border.all(color: borderColor, width: 2.2),
              boxShadow: [
                BoxShadow(
                  offset: const Offset(3, 3),
                  color: borderColor,
                  blurRadius: 0,
                ),
              ],
            ),
            child: Text(
              session.room,
              style: GoogleFonts.archivoBlack(
                fontSize: 14,
                fontWeight: FontWeight.w900,
                color: isLive ? Colors.black : PosterTokens.inkHeading(isDark),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyStateBlock(bool isDark, Color borderColor) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        border: Border.all(color: borderColor, width: 2.2),
        boxShadow: PosterTokens.extrudedBlockShadow(isDark, offset: 4.0),
      ),
      child: Column(
        children: [
          Text(
            'NO CLASSES SCHEDULED',
            style: GoogleFonts.archivoBlack(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              color: PosterTokens.inkHeading(isDark),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'ENJOY YOUR STUDY OR LEISURE TIME.',
            style: GoogleFonts.spaceMono(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: PosterTokens.inkMuted(isDark),
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------
  DateTime _getDateForSelectedDay(DateTime now) {
    final currentDay = now.weekday;
    final diff = activeDayIndex - currentDay;
    return now.add(Duration(days: diff));
  }

  String _computeCountdown(ClassSession session, {required bool isLive, required DateTime now}) {
    final currentHour = now.hour + (now.minute / 60.0);
    if (isLive) {
      final diff = session.actualEndVal - currentHour;
      if (diff <= 0) return '0:00';
      final totalMins = (diff * 60).round();
      final h = totalMins ~/ 60;
      final m = totalMins % 60;
      return '$h:${m.toString().padLeft(2, '0')}';
    }

    if (session.dayIndex == now.weekday && session.safeStartVal > currentHour) {
      final diff = session.safeStartVal - currentHour;
      final totalMins = (diff * 60).round();
      final h = totalMins ~/ 60;
      final m = totalMins % 60;
      return '$h:${m.toString().padLeft(2, '0')}';
    }

    if (session.dayIndex != now.weekday) {
      var daysAhead = (session.dayIndex - now.weekday + 7) % 7;
      if (daysAhead == 0) daysAhead = 7;
      final totalMins = ((24.0 - currentHour) * 60 +
              (daysAhead - 1) * 24 * 60 +
              session.safeStartVal * 60)
          .round();
      final h = totalMins ~/ 60;
      final m = totalMins % 60;
      if (h >= 24) {
        return '${daysAhead}D ${h % 24}H';
      }
      return '$h:${m.toString().padLeft(2, '0')}';
    }

    return '0:00';
  }
}
